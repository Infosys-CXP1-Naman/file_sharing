# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
  - 4.2 Inactive Triggers - Non-Executing Code Register
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Bodyshop Repair Orders - VH_RO
    - Working-Day Holiday Calendar - WD_BTN
    - Bodyshop Panel Tracking Records - VT_VTS
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter (Report User - at search entry)
    - Report Results (System - populated after Search)
    - Session and Global Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-006 - D2KWUTIL.TRANSLATETYPE
    - SP-007 - GENERAL.ASK_CONFIRM
    - SP-008 - GENERAL.CHECK_FORM_FAILURE
    - SP-009 - GENERAL.DISP_TEXT
    - SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL
    - SP-011 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT
    - SP-012 - WEBUTIL.BLOCKING
    - SP-013 - WEBUTIL.CHECKLIBS
    - SP-014 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-015 - WEBUTIL.CLOSEBLOB
    - SP-016 - WEBUTIL.CLOSEFILE
    - SP-017 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-018 - WEBUTIL.ERROR
    - SP-019 - WEBUTIL.ERRORALERT
    - SP-020 - WEBUTIL.EXECUTE
    - SP-021 - WEBUTIL.FCLOSE
    - SP-022 - WEBUTIL.FOPEN
    - SP-023 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-024 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-025 - WEBUTIL.GETCLIENTSETTING
    - SP-026 - WEBUTIL.GETIMPLCLASS
    - SP-027 - WEBUTIL.GETLASTERROR
    - SP-028 - WEBUTIL.GETLASTERRORARGS
    - SP-029 - WEBUTIL.GETNUMBER
    - SP-030 - WEBUTIL.GETOSFAMILY
    - SP-031 - WEBUTIL.GETOUTPUT
    - SP-032 - WEBUTIL.GETPROPERTY
    - SP-033 - WEBUTIL.GETSTRING
    - SP-034 - WEBUTIL.GETVAR
    - SP-035 - WEBUTIL.GET_LINE
    - SP-036 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-037 - WEBUTIL.ID_NULL
    - SP-038 - WEBUTIL.INIT
    - SP-039 - WEBUTIL.INITWEBUTIL
    - SP-040 - WEBUTIL.ISERROR
    - SP-041 - WEBUTIL.IS_OPEN
    - SP-042 - WEBUTIL.LENGTH
    - SP-043 - WEBUTIL.LOG
    - SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-045 - WEBUTIL.PUT_LINE
    - SP-046 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-047 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-048 - WEBUTIL.REGISTERBEAN
    - SP-049 - WEBUTIL.REGISTER_FUNCTION
    - SP-050 - WEBUTIL.RELEASE_PROCESS
    - SP-051 - WEBUTIL.SETCLIENTSETTING
    - SP-052 - WEBUTIL.SETDATA
    - SP-053 - WEBUTIL.SETPROPERTY
    - SP-054 - WEBUTIL.SHOWBEANS
    - SP-055 - WEBUTIL.WRITEDATA
    - SP-056 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-057 - ADD_ERROR
    - SP-058 - ADD_EXTERNAL_ERRORS
    - SP-059 - BOOLTOCHAR
    - SP-060 - CLEAN_ERROR_STACK
    - SP-061 - DEBUGLOG
    - SP-062 - GET_ENVIRONMENT_STRING
    - SP-063 - READ_REGISTRY
    - SP-064 - REGISTER_FUNCTION_CALL
    - SP-065 - SETDEBUG
    - SP-066 - STRIPDIRSEP
    - SP-067 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_BODYSHOP_GROUP_PROD - Business Requirements Document |
| Form Module Name | VR_BODYSHOP_GROUP_PROD |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_bodyshop_group_prod Bodyshop Group Productivity Report form, its purpose, and roles referenced in the module.*

The **vr_bodyshop_group_prod** Oracle Forms module is the dealership **Bodyshop Group Productivity Report** screen. A bodyshop manager or reporting user opens the form, selects a billing date range by entering a start date and an end date, and triggers the productivity search. The application then retrieves all bodyshop repair orders raised within that period that belong to the bodyshop category, groups the results by repair bay group, and calculates a set of key performance metrics for each group - the number of working days in the period (excluding public holidays), the count of job cards completed, the total panel count, the total labour amount generated, and the derived vehicle, panel, and labour productivity ratios. The results are displayed on screen row by row. Once the summary is visible, the user may export the entire result set to a comma-separated file that opens directly in a browser window for further review or printing. Both the on-screen search and the export apply the same date-range validation rules - the end date may not exceed today's date and may not precede the start date - before the report is produced.

### Key Stakeholders

*Who uses vr_bodyshop_group_prod*

| Stakeholder | Role |
| :--- | :--- |
| **Bodyshop Manager / Reporting User** | Primary interactive user. Opens the form, enters the billing date range, triggers the productivity search, reviews the group metrics on screen, and exports results to a spreadsheet file when required. |
| **Dealership Management** | Downstream consumer of the productivity report. Reviews the exported CSV file or on-screen figures to monitor bay utilisation, panel throughput, and labour revenue performance across bodyshop groups. |

---

---

## 3. System Context

*Describes the vr_bodyshop_group_prod module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_bodyshop_group_prod** module is the Dealer Management System **Bodyshop Group Productivity Report** screen. It provides bodyshop managers with a consolidated view of repair bay group performance over a user-defined billing period, and connects the bodyshop operational data with reporting and export activities.

**System purpose:** Retrieve, calculate, and display bodyshop group productivity metrics - including working days, job card counts, panel counts, labour amounts, and derived productivity ratios - for a selected billing date range, and export the results to a file as implemented in the vr_bodyshop_group_prod Oracle Forms module.

**In scope:**

- Enter and validate a billing date range (start and end date) for the productivity report
- Validate that neither date exceeds today and that the end date is not earlier than the start date
- Retrieve all bodyshop repair orders (BANDP category) within the date range, scoped to the current dealer group, dealer, and location
- Aggregate repair orders by bay group: count job cards, sum panel counts, and sum labour amounts
- Calculate the number of non-holiday working days in the selected period for each group
- Derive vehicle productivity, panel productivity, and labour productivity ratios per group
- Display the aggregated group metrics on screen in a multi-row results block
- Export the full result set to a CSV file that opens in the browser for download or printing

**Process Name:** Bodyshop Group Productivity Report

**Process Owner:** Bodyshop Manager

**Process Objective:** Enter a billing date range, validate the inputs, retrieve and calculate bodyshop group productivity metrics from repair order data, display the results, and optionally export them to a spreadsheet file.

**Process Trigger:** Bodyshop manager or reporting user opens the form to review group-level bodyshop performance for a specific period

**Process Flow:**

The complete bodyshop group productivity report process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The user opens the Bodyshop Group Productivity Report screen.
         The form registers the session and initialises pagination counters.
         The report title is pre-loaded from the session context.

STEP 2 ── ENTER FROM BILL DATE
         The user enters the start of the billing date range (From Bill Date).
         The system validates that the entered date is not null.
         The system validates that the entered date does not exceed today's date.

STEP 3 ── NAVIGATE TO END DATE
         After a valid From Bill Date is entered, focus moves to the To Bill Date field.

STEP 4 ── ENTER TO BILL DATE
         The user enters the end of the billing date range (To Bill Date).
         The system validates that the To Bill Date does not exceed today's date.
         The system validates that the To Bill Date is not earlier than the From Bill Date.

STEP 5 ── TRIGGER SEARCH
         The user clicks the Search button.
         The system re-validates the full date range before proceeding.
         ├── VALIDATION FAILS: An alert is shown identifying the invalid condition;
                               focus returns to the To Bill Date field.
         └── VALIDATION PASSES: The system proceeds to query the repair order data.

STEP 6 ── RETRIEVE REPAIR ORDERS
         The system queries all bodyshop repair orders (BANDP category) within the
         date range, scoped to the current parent group, dealer, and location.
         Orders are grouped by bay group code.

STEP 7 ── CALCULATE PANELS PER ORDER
         For each repair order in the result, the system calls the panel-count
         function to sum the number of panels processed for that job card.

STEP 8 ── COUNT WORKING DAYS
         The system calls the working-day count function for each group, passing
         the date range and location details.
         The function counts calendar days and excludes any dates listed as holidays
         for the dealership location.

STEP 9 ── CALCULATE PRODUCTIVITY RATIOS
         The system calculates three productivity ratios per group using the
         working-day count as the denominator:
         - Vehicle productivity (job cards per working day)
         - Panel productivity (panels per working day)
         - Labour productivity (labour amount per working day)
         All ratios are rounded to two decimal places.

STEP 10 ── DISPLAY RESULTS
          The system populates the results block with one row per bay group,
          showing group code, working days, job count, panel count, labour amount,
          and the three productivity ratios.

STEP 11 ── REVIEW RESULTS
          The user reviews the on-screen group productivity figures.
          No editing of result rows is permitted.

STEP 12 ── EXPORT TO CSV (optional)
          The user clicks the Export to Excel button to export the results.
          The system re-validates the date range before exporting.
          ├── VALIDATION FAILS: An alert is shown; focus returns to the date field.
          └── VALIDATION PASSES: The system builds a dynamic query for the full
                                  result set including the column header row.

STEP 13 ── GENERATE CSV FILE
          The system executes the export query and writes the result rows,
          including a header line, to a CSV file on the application server.
          The file name is prefixed with the user ID and a timestamp to ensure uniqueness.

STEP 14 ── OPEN FILE IN BROWSER
          The system opens the generated CSV file in the user's browser window,
          allowing the user to download or print the report.

STEP 15 ── EXIT FORM
          The user closes the form.
          The system clears the session counters and deregisters the module
          from the database session tracking.
```

**Major process interactions:**

- **Repair order data** - the bodyshop repair order table is the primary source for all group-level job counts, panel data, and labour amounts
- **Holiday calendar** - the dealership working-day holiday table is consulted to exclude non-working days from the productivity period calculation
- **Vehicle tracking service** - the vehicle tracking table provides the per-repair-order panel count used in the aggregation
- **Application server file system** - the export writes CSV output to the server and serves it via the web browser
- **DMS session management** - the form registers and deregisters itself with the database session module for audit and monitoring purposes

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration

**Business Description:**
When the Bodyshop Group Productivity report form is opened, the system automatically registers the current session so that database activity can be identified and traced to this form, seeds the report description and application identifier into the session context, maximises the application window, pre-populates the billing date range to cover the previous month up to today, and loads the copyright declaration. This all happens before the user interacts with any screen field.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has launched the Bodyshop Group Productivity report form.

**Main Flow:**

**Step 1 - Session context registered at form startup**
As the form opens, the system immediately records the name of this form module (`vr_bshop_group_prod`) as the active client context in the database session. It also sets the module identifier in the database's application tracking to this form's name, clearing any action name carried over from a previous navigation.

**Step 2 - Report description and application identifier seeded**
The system assigns the report description *"Group Productivity Report (For Job Card Billed and Punched in VTS Bodyshop)"* to the session-level report description variable (`global.report_desc`) and copies it into the on-screen report description display field. The application identifier (`global.app_id`) is set to `vr_bshop_group_prod` and mirrored to the session parameter `p_app_id`.

**Step 3 - Application window maximised**
The system maximises both the MDI container window and the form's main window (`WN_MAIN`) so the report screen fills the available display area on opening.

**Step 4 - Billing date range pre-populated**
The system queries the current date and automatically sets the From Bill Date to the first day of the previous calendar month and the To Bill Date to today's date. This gives the user a sensible default date range covering the most recent completed month without requiring manual entry.

**Step 5 - Copyright declaration loaded**
The system retrieves the standard copyright declaration text from the database (`SF_COPYRIGHT_DECLARATION`) and places it in the copyright display field on the query panel.

---

---

#### Requirement ID: BR-002

**Requirement Title:** From Bill Date Validation

**Business Description:**
When the user finishes entering the start date for the billing period they want to report on, the system validates the date before allowing navigation to the next field. The date must be provided and must not be in the future. These checks ensure that any report generated will cover a real, completed billing period rather than future data that does not yet exist.

**Actors:** Report User

**Preconditions:**
- The report form is open and the user has entered a value in the start date field of the report filter.

**Main Flow:**

**Step 1 - Start date presence checked**
When the user leaves the start date field, the system first checks whether a date has actually been entered. If the field is blank, the user is shown an alert and must provide a date before proceeding.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Start date is blank - *"From Date can not be null"*; the trigger is aborted and the cursor stays on the start date field.

**Step 2 - Start date checked against today**
Immediately after confirming the date is present, the system checks whether the entered start date is later than today's date. A start date in the future is not valid because bodyshop billing records only exist up to the current date.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-02** - Start date is after today - *"From Date cannot be greater than Current Date"*; the trigger is aborted and the cursor stays on the start date field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Start date must be provided | WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT - IS NULL check | When the user tabs off or moves focus away from the From Bill Date field | Ensures the user has supplied a start date before the system attempts any further validation or search | Alert shown: *"From Date can not be null"*; navigation blocked |
| Start date must not be in the future | WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT - comparison against current system date | Immediately after the null check passes, on the same tab/navigation event | Prevents users from requesting reports for future billing periods for which no data exists | Alert shown: *"From Date cannot be greater than Current Date"*; navigation blocked |

**Step 3 - Focus directed to the To Bill Date field**
When both validation checks pass, the form moves focus directly to the To Bill Date field (`CB_DOC_QUERY.TO_BILL_DT`), overriding the default tab order so the user progresses to the next mandatory date filter without navigating through other fields.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) Start date is blank: alert *"From Date can not be null"* is shown; the trigger fails and the cursor remains on the start date field.
- **BR-002-AF-02** - (from Step 2) Start date is after today: alert *"From Date cannot be greater than Current Date"* is shown; the trigger fails and the cursor remains on the start date field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Must not be blank; must not be after today's date | Alert *"From Date can not be null"* when blank; alert *"From Date cannot be greater than Current Date"* when in the future |

---

---

#### Requirement ID: BR-003

**Requirement Title:** To Bill Date Validation and Default

**Business Description:**
When the user finishes entering the end date of the billing period, the system validates the date against three business rules before allowing the form to proceed. The end date must not be in the future, must not be earlier than the start date, and the total period must not exceed one calendar month. If the end date field is left blank, the system automatically defaults it to today's date. These rules ensure the report covers a valid and manageable date range.

**Actors:** Report User

**Preconditions:**
- The start date for the billing period has been provided and validated.
- The user has entered or left blank the end date for the billing period.

**Main Flow:**

**Step 1 - End date defaulted to today if blank**
If the user navigates away from the end date field without entering a value, the system automatically sets the end date to today's date so that the report covers all activity up to the current day.

**Step 2 - End date checked against today**
The system checks whether the entered (or defaulted) end date is after today. An end date in the future is not valid because billing records do not yet exist for future dates.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - End date is after today - *"To Date cannot be greater than Current Date"*; the trigger is aborted and the cursor stays on the end date field.

**Step 3 - End date checked against start date**
The system checks whether the end date is earlier than the start date. A report period where the end precedes the start is not meaningful and is rejected.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-02** - End date is before start date - *"To Date cannot be less than From Date"*; the trigger is aborted and the cursor stays on the end date field.

**Step 4 - Date range checked against one-month maximum**
The system checks that the gap between start date and end date does not exceed 31 days. Reports are constrained to a maximum of one month to keep run times and data volumes manageable.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-03** - Date range exceeds 31 days - *"Report can be generated for maximum 1 Month"*; the trigger is aborted and the cursor is set to the end date field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| End date must not be in the future | WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT - comparison against current system date | When the user tabs off or moves focus away from the To Bill Date field | Prevents reports being requested for future billing periods for which no records exist | Alert shown: *"To Date cannot be greater than Current Date"*; navigation blocked |
| End date must not be earlier than start date | WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT - comparison of TO_BILL_DT against FROM_JC_BILL_DT | Immediately after the future-date check passes | Ensures the report period is logically valid (end must be on or after start) | Alert shown: *"To Date cannot be less than From Date"*; navigation blocked |
| Date range must not exceed one month | WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT - difference of TO_BILL_DT minus FROM_JC_BILL_DT compared to 31 | Immediately after the date-order check passes | Limits report data volume and run time to a single calendar month | Alert shown: *"Report can be generated for maximum 1 Month"*; cursor set to end date field; navigation blocked |

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 2) End date is after today: alert *"To Date cannot be greater than Current Date"* is shown; trigger fails; cursor stays on the end date field.
- **BR-003-AF-02** - (from Step 3) End date is before start date: alert *"To Date cannot be less than From Date"* is shown; trigger fails; cursor stays on the end date field.
- **BR-003-AF-03** - (from Step 4) Date range exceeds 31 days: alert *"Report can be generated for maximum 1 Month"* is shown; trigger fails; cursor is set to the end date field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Bill Date (`TO_BILL_DT`) | Conditional - defaults to today if blank | Date | DD-MM-RRRR | N/A | N/A | From Bill Date must be provided | Must not be after today; must not be earlier than From Bill Date; range with From Bill Date must not exceed 31 days | Alert per each violated rule (see Step 2-4 outcomes) |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Already validated at entry; used here for cross-validation of date order and range | N/A - validated in BR-002 |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Bodyshop Group Productivity Search and Results Display

**Business Description:**
When the user presses the Search button after entering the billing date range, the system queries the bodyshop repair order records for the current dealership and groups the results by work group. For each group the system calculates the number of working days in the period (excluding the dealership's declared holidays), counts the number of job cards completed, totals the panel count and labour amount, and derives the vehicle productivity, panel productivity, and labour productivity ratios. The results are displayed on screen in a multi-row grid, one row per work group, giving management a consolidated view of bodyshop productivity across all groups for the selected period.

**Actors:** Report User

**Preconditions:**
- A valid billing start date and end date have been entered, covering a period that does not exceed one month and does not extend into the future.

**Main Flow:**

**Step 1 - Date filter re-validated on Search**
When the user presses the Search button, the system first re-checks whether the end date is after today and whether the end date is before the start date. If either condition is violated, the cursor is sent back to the end date field and search processing stops.

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - End date is after today at time of search - *"To Date cannot be greater than Current Date"*; cursor is set to the end date field; search is aborted.
- **BR-004-ES-02** - End date is before start date at time of search - *"To Date cannot be less than From Date"*; cursor is set to the end date field; search is aborted.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| End date must not be in the future | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH - comparison of TO_BILL_DT against current system date | When the user presses the Search button | Guards against running a search on a future date range even if field-level validation was bypassed | Alert shown: *"To Date cannot be greater than Current Date"*; cursor moves to end date field; processing stops |
| End date must not be earlier than start date | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH - comparison of FROM_JC_BILL_DT against TO_BILL_DT | Immediately after the future-date check on the Search button | Guards against an inverted date range when the Search button is pressed | Alert shown: *"To Date cannot be less than From Date"*; cursor moves to end date field; processing stops |

**Step 2 - Working days calculated for each group**
The system queries the bodyshop repair order records for the current dealership, grouping by work group. For each group it calls the working-day counter to determine how many business days fall within the selected date range, consulting the dealership's holiday calendar to exclude non-working days.

*Procedures called:*
- **PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT** ([SP-004](#SP-004--PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT)) - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT - counts the number of working days in the selected billing period for the dealership, excluding any days registered as holidays in the dealership's holiday calendar.
    * **Step 1** - Accept the reporting period start and end dates together with the dealership identifier as input.
    * **Step 2** - Iterate through each calendar day from the start date up to and including the end date.
    * **Step 3** - For each day, check the dealership's holiday calendar to determine whether that day is recorded as a non-working day.
    * **Step 4** - If the day is not in the holiday calendar, count it as a working day; otherwise skip it.
    * **Step 5** - Return the total number of working days counted for the period.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Working day count derived from dealership holiday calendar | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT [SP-004] - queries WD_BTN holiday table for each day in the range | When the Search button is pressed and each group row is being calculated | Ensures productivity ratios are based on actual working days, not raw calendar days | No error raised on missing holiday records; missing days default to being counted as working days |

**Step 3 - Panel count retrieved for each repair order**
Within the same query the system retrieves the total number of panels repaired per repair order in the period by calling the panel-count function for each job card.

*Procedures called:*
- **PKG_VTS_BODYSHOP.SF_GET_PANEL** ([SP-003](#SP-003--PKG_VTS_BODYSHOP.SF_GET_PANEL)) - PKG_VTS_BODYSHOP.SF_GET_PANEL - retrieves the total number of body panels recorded against a specific repair order in the bodyshop tracking records.
    * **Step 1** - Accept the repair order number together with the dealership and location identifiers as input.
    * **Step 2** - Query the bodyshop tracking records for that repair order and sum the total panel count.
    * **Step 3** - Return the total panel count, returning zero if no tracking records are found for that repair order.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Panel count defaults to zero when no tracking records exist | PKG_VTS_BODYSHOP.SF_GET_PANEL [SP-003] - NVL(LV_PANEL, 0) in function body | When the Search button is pressed and the panel count is being aggregated for each group | Prevents a null panel count from causing arithmetic errors in the productivity ratio calculations | Zero is returned; the group row is still displayed with a zero panel count |

**Step 4 - Productivity ratios calculated and displayed**
The system groups the repair orders by work group and sums the job card count, total panel count, and total labour amount for each group. It then divides each sum by the number of working days for that group to produce the vehicle productivity (jobs per working day), panel productivity (panels per working day), and labour productivity (labour amount per working day). The results panel is cleared, and the calculated figures for each group are written into the on-screen results rows.

**Step 5 - Focus moved to Export button**
After the results grid is populated, the system moves the screen focus to the Export to Excel button so the user can immediately export if desired.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Must not be blank; not after today; used as lower bound for bodyshop record filter | Alert shown and search aborted if violated |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | From Bill Date provided | Must not be after today; must not be before From Bill Date | Alert shown and search aborted if violated |
| Group Code (`NO_OF_BAYS`) | Read-only display | Alphanumeric | N/A | N/A | N/A | Search executed | System-populated from query results; one row per work group | N/A |
| Number of Working Days (`NO_OF_WORK_DAYS`) | Read-only display | Numeric | N/A | N/A | N/A | Search executed | System-calculated via working-day counter | N/A |
| Number of Vehicles Repaired (`NO_OF_VEH_REP`) | Read-only display | Numeric | 999D00 | N/A | N/A | Search executed | System-calculated: count of job cards in the period for the group | N/A |
| Number of Panels (`NO_OF_PANELS`) | Read-only display | Numeric | N/A | N/A | N/A | Search executed | System-calculated: sum of panel counts for all repair orders in the group | N/A |
| Labour Amount Generated (`LAB_GEN`) | Read-only display | Numeric | 9999999D00 | N/A | N/A | Search executed | System-calculated: sum of labour amounts for the group | N/A |
| Bay Productivity (`BAY_PROD`) | Read-only display | Numeric | 999D00 | N/A | N/A | Search executed | System-calculated: vehicles per working day, rounded to 2 decimal places | N/A |
| Panel Productivity (`PANEL_PROD`) | Read-only display | Numeric | N/A | N/A | N/A | Search executed | System-calculated: panels per working day, rounded to 2 decimal places | N/A |
| Labour Productivity (`LABOUR_PROD`) | Read-only display | Numeric | 9999999D00 | N/A | N/A | Search executed | System-calculated: labour amount per working day, rounded to 2 decimal places | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Export Bodyshop Group Productivity Results to Excel

**Business Description:**
After the productivity results have been calculated and displayed on screen, the user can press the Export to Excel button to save the results as a comma-separated file and open it directly in the browser. The export includes the same columns shown on screen - group code, number of working days, job count, panel count, labour amount, vehicle productivity, panel productivity, and labour productivity - for all groups in the selected date range. This allows managers to save, share, and further analyse the productivity figures outside the reporting form.

**Actors:** Report User

**Preconditions:**
- A valid billing date range has been entered.
- The productivity results have been retrieved and are displayed on screen.

**Main Flow:**

**Step 1 - Export query assembled and query text stored**
When the user presses the Export to Excel button, the system first re-constructs the same query used for the on-screen display but formatted for CSV output. The query text is stored in an internal text field for reference. The date range for the export uses the start date and an adjusted end date that adds one day to ensure the upper boundary is inclusive.

**Step 2 - CSV file generated and delivered via browser**
The system calls the export utility to execute the assembled query, build the CSV output, and deliver the file to the user's browser.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - generates a CSV file from the provided query, writes it to the configured server path, and opens it in the user's browser as a new window.
    * **Step 1** - Derive a unique filename using the logged-in user's identifier and the current date and time.
    * **Step 2** - If the filename path contains spaces, redirect the file to the root of the default drive and inform the user that the original path could not be used.
    * **Step 3** - Create an in-memory record group from the provided query to hold the result rows.
    * **Step 4** - Count the total number of rows in the result; if the count exceeds 65,535 rows, warn the user that the output will be truncated to that limit.
    * **Step 5** - Read the configured export directory path from the server's path configuration file.
    * **Step 6** - Write each result row as a line in a CSV file at the resolved server path.
    * **Step 7** - Open the completed CSV file in the user's browser as a new window.
    * **Step 8** - If any error occurs during file operations, show the error code and error text and abort with a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Filename path must not contain spaces | VIEW_EXCEL_REP [SP-001] - INSTR(FILENAME, ' ') > 0 check | When the Export to Excel button is pressed and the file path is being resolved | Prevents file-save failures caused by directory names that contain spaces; file is redirected to the default drive root | Message shown: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; export continues with redirected path |
| Export row count must not exceed Excel limit | VIEW_EXCEL_REP [SP-001] - the_rowcount > 65536 check | After the in-memory result set is populated | Prevents the CSV file from exceeding the maximum row capacity supported by Excel | Message shown: *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues with the first 65,535 rows |
| Server path configuration file must be readable | VIEW_EXCEL_REP [SP-001] - TEXT_IO.FOPEN on /reports/DMS/excelpath.txt followed by WHEN OTHERS exception handler | When the export path configuration is being read | Ensures the system can resolve the correct server directory to write the CSV file | On WHEN OTHERS in the export utility: message *"Error  -"* followed by the system error code and text (dynamic); trigger failure raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-WS-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; export redirected to drive root and continues.
- **BR-005-WS-02** - Result set exceeds Excel row limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; output truncated to 65,535 rows.
- **BR-005-ES-01** - Unhandled error during file operations - message *"Error  -"* followed by the system's own error code and error text (dynamic, from ERROR_CODE and ERROR_TEXT); trigger failure raised.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Embedded in the export query as the lower date bound | N/A |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | From Bill Date provided | Embedded in the export query; upper bound used is TO_BILL_DT + 1 | N/A |
| Query Text (`TXT`) | Auto-populated | Text | Up to 5000 characters | N/A | N/A | Export button pressed | System-assigned; holds the assembled CSV query string | N/A |


---

---

#### Requirement ID: BR-006

**Requirement Title:** Form-Level Message and Error Interception

**Business Description:**
The form intercepts specific Oracle Forms runtime messages and re-routes them through the standard display mechanism used across all forms in the application suite. This ensures that concurrency conflicts (where another user has modified a record simultaneously) and date-entry format errors are presented to the user in a consistent, clearly formatted style rather than raw system messages. Only the specific message codes that are handled this way are affected; all other standard messages pass through unchanged.

**Actors:** System (automatic on any form message event)

**Preconditions:**
- The form is open and an Oracle Forms runtime message has been raised.

**Main Flow:**

**Step 1 - Message code checked for interception**
When any Oracle Forms runtime message fires, the system checks whether the message code is one of the two codes designated for special handling. If the code does not match, the message is left for Oracle Forms to display in its default manner.

**Step 2 - Matching message re-displayed through the standard mechanism**
If the message code matches one of the two designated codes, the system passes the error type, numeric code, and descriptive text to the standard display utility to show the combined message as an error alert. After displaying the message, the trigger fails, preventing the underlying Forms action from proceeding.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a formatted message alert to the user using the application's standard notification style. Called with the error type, code, and text combined into a single string with the severity label "Error". (EXTERNAL / NOT IN BUNDLE - full implementation not verifiable from supplied source.)
    * **Step 1** - Receive the message text and severity level as input.
    * **Step 2** - Display the message to the user in the application's standard alert format.
    * **Step 3** - Return control to the calling trigger after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Only the two designated message codes are intercepted | ON-MESSAGE in Form - IF errnum in (40209, 40207) | When any Oracle Forms message event fires during form operation | Restricts interception to the specific codes that require consistent presentation; avoids overriding unrelated system messages | For non-matching codes, the trigger ends without action and Oracle Forms displays the message in its default manner |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Matching message code intercepted - the combined error type, code, and text (dynamic: format is error-type prefix, numeric code, colon, and descriptive error text) is displayed via the standard alert utility as an error; the triggering Forms action is aborted.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) Message code does not match the two designated codes: the trigger ends without displaying anything; Oracle Forms handles the message through its default channel.

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form Exit and Session Cleanup

**Business Description:**
When the user presses the keyboard shortcut to exit the form, the system clears the session registration details recorded at startup, removes the working variables used for pagination control, and then closes the form without prompting to save any unsaved data. This ensures that when the form is closed, the database session context is left clean and ready for the next form the user navigates to.

**Actors:** Report User (via keyboard exit action)

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Session context cleared**
The system clears the active client context and module name recorded in the database session when this form was opened, resetting them to empty so the session no longer reports this form as active.

**Step 2 - Pagination control variables removed**
The system removes the three global working variables used for controlling result-set pagination ranges, releasing those session memory slots.

**Step 3 - Form closed without validation**
The form closes immediately without checking for unsaved changes or prompting the user to save. Any pending data changes are discarded silently.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Report Description Refresh on Clear Form

**Business Description:**
When the user triggers the form-clear keyboard action, the system refreshes the report description displayed at the top of the screen from the session-level value stored for this form. The remaining form-reset logic (clearing data blocks, resetting filter fields, re-enabling navigation buttons) that was once part of this action is currently disabled and does not execute.

**Actors:** Report User (via keyboard clear-form action)

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Report description refreshed from session value**
The system copies the report description held in the session context into the report description display field at the top of the screen, ensuring the heading reflects the session-level label for this form.

*(COMMENTED OUT / INACTIVE - does not execute)* A previously implemented block of logic that would have cleared the form, reset the query filter fields, re-enabled navigation buttons, and re-applied document-type-specific field settings has been commented out and does not run when this action is triggered.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display text | Up to 200 characters | N/A | Session value for report description | Form open | System-assigned from session context; not user-editable | N/A |

---

---

### 4.2 Inactive Triggers - Non-Executing Code Register

The following triggers exist in the form source but are currently inactive (commented out, replaced by a `null;` no-op, or empty). They do not execute and deliver no business behaviour. They are registered here for completeness per source-coverage requirements.

| Trigger | Level / Owner | Status | Former / Intended Purpose (from commented code) |
| ------- | ------------- | ------ | ----------------------------------------------- |
| ON-ERROR | Form | INACTIVE - replaced with `null;` as first statement; all logic commented out | Was intended to intercept error codes 40209 and 40207 (concurrency conflict and invalid date errors) and display them via the standard alert mechanism, equivalent to the active ON-MESSAGE logic in BR-006 |
| KEY-LISTVAL | Form | INACTIVE - empty body | Platform default LOV invocation; no custom business logic |
| KEY-COMMIT | Form | INACTIVE - empty body | Platform default commit shortcut; no custom business logic |
| KEY-OTHERS | Object Group OG_GROUP | INACTIVE - body is `null;` | Suppresses all unhandled key events; no custom business logic |
| KEY-UP | Block CB_DOC_QUERY | INACTIVE - body is `NULL;` | Would have suppressed upward keyboard navigation in the query filter block; no business logic |
| KEY-DOWN | Block CB_DOC_QUERY | INACTIVE - body is `NULL;` | Would have suppressed downward keyboard navigation in the query filter block; no business logic |
| FT_CANCEL | Object Group OG_GROUP | INACTIVE - body is `null;`; all cancel-with-confirmation logic commented out | Was intended to prompt the user to confirm discarding unsaved changes (via `GENERAL.ASK_CONFIRM`) and then clear the form; no logic executes |
| FT_DEL | Object Group OG_GROUP | INACTIVE - body is `null;`; all delete-with-confirmation logic commented out | Was intended to confirm deletion via `GENERAL.ASK_CONFIRM('Are you sure to Delete')` and then delete the current record; no logic executes |
| FT_LIST | Object Group OG_GROUP | INACTIVE - body is `null;`; LOV invocation commented out | Was intended to invoke the list of values for the current field; no logic executes |
| FT_SAVE | Object Group OG_GROUP | INACTIVE on this form - Save button (`PB_BLK.PB_SAVE`) is disabled; body executes `DO_KEY('COMMIT_FORM')` only when the button is enabled | No save action is applicable on this read-only reporting form; the commit path is unreachable in normal operation |
| FT_INSERT | Object Group OG_GROUP | INACTIVE on this form - Insert button (`PB_BLK.PB_INSERT`) is disabled; body references placeholder block `BLOCK_NAME` which does not exist on this form | Template placeholder; no applicable data-entry block exists |
| FT_PRINT | Object Group OG_GROUP | INACTIVE - body executes `NULL;` inside the enabled guard; print code has not been implemented | Placeholder for future print functionality; no print logic executes |
| WHEN-BUTTON-PRESSED | Item WEBUTIL.DUMMY | INACTIVE - empty body | WebUtil framework placeholder; no custom business logic |
| WHEN-CUSTOM-ITEM-EVENT | Items WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_BROWSER_FUNCTIONS | INACTIVE - empty bodies | WebUtil framework event handlers; no custom business logic |

> **Format mask entries** - the slice records the following item-level display format masks as trigger-like entries; they are item properties (not executable PL/SQL): `NO_OF_VEH_REP` = `999D00`, `LAB_GEN` = `9999999D00`, `BAY_PROD` = `999D00`, `LABOUR_PROD` = `9999999D00`, `AVG_VEH` = `999D00`, `AVG_LAB` = `9999999D00`, `AVG_BAY_PROD` = `999D00`, `AVG_LAB_PROD` = `9999999D00`. These control how numeric values are displayed on screen and are already reflected in the Field Length/Format column of the BR-004 Data Elements table.

---

## 5. Business Rules Catalogue

Catalogue of discrete business rules enforced by the form's triggers and program units.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Bill Date is mandatory | Validation | BR-002 | From Bill Date field is left blank when the user moves off it | Show alert *"From Date can not be null"* and block navigation away from the field | Prevents searches being submitted without a start date, which would return meaningless or unbounded results |
| BRC-002 | From Bill Date must not be in the future | Validation | BR-002 | From Bill Date entered is after today's date | Show alert *"From Date cannot be greater than Current Date"* and block navigation away from the field | Prevents reports being requested for future periods where no billing data exists |
| BRC-003 | To Bill Date must not be in the future | Validation | BR-003 | To Bill Date entered is after today's date | Show alert *"To Date cannot be greater than Current Date"* and block navigation | Prevents the report from being run against future periods that have no records |
| BRC-004 | To Bill Date must not precede From Bill Date | Validation | BR-003 | To Bill Date is earlier than From Bill Date | Show alert *"To Date cannot be less than From Date"* and block navigation | Prevents an inverted date range that would return zero records and mislead users |
| BRC-005 | Reporting period limited to one month | Constraint | BR-003 | Difference between To Bill Date and From Bill Date exceeds 31 days | Show alert *"Report can be generated for maximum 1 Month"*, set cursor to To Bill Date, and block navigation | Limits report data volume and processing time to a manageable single-month window |
| BRC-006 | To Bill Date defaults to today when blank | Derivation | BR-003 | To Bill Date field is blank when the user navigates off it | Automatically populate To Bill Date with today's date | Provides a convenient default so the user does not need to re-enter today's date as the end of the period |
| BRC-007 | Search button re-validates To Date against today | Validation | BR-004 | To Bill Date is after today at the moment the Search button is pressed | Show alert *"To Date cannot be greater than Current Date"*, move cursor to To Bill Date, and abort search | Guards against stale filter values reaching the database query if field-level validation was bypassed |
| BRC-008 | Search button re-validates date order | Validation | BR-004 | From Bill Date is after To Bill Date at the moment the Search button is pressed | Show alert *"To Date cannot be less than From Date"*, move cursor to To Bill Date, and abort search | Ensures the query executes with a logically valid date range even if field validation was bypassed |
| BRC-009 | Export file path must not contain spaces | Constraint | BR-005 | The system-generated file path for the CSV export contains one or more space characters | Redirect the output file to the root of the default drive; show message *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; continue with the redirected path | Prevents silent save failures caused by directory paths with spaces that the file-writing utility cannot resolve |
| BRC-010 | Excel export row count capped at 65,535 | Constraint | BR-005 | Result set for the CSV export contains more than 65,536 rows | Truncate output to 65,535 rows; show message *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents the CSV file from exceeding the maximum row limit that Microsoft Excel can open |
| BRC-011 | Specific runtime messages displayed via standard alert | Validation | BR-006 | Oracle Forms runtime message code is 40209 (record modified by another user) or 40207 (invalid date entry) | Pass the message type, code, and text to the standard display utility as an error alert, then abort the triggering action | Ensures concurrency-conflict and date-format messages are presented consistently rather than as raw Oracle Forms system messages |
| BRC-012 | Report description refreshed on form-clear action | Derivation | BR-008 | User triggers the keyboard form-clear action | Copy the session-level report description value into the report description display field | Keeps the on-screen report heading in sync with the session-assigned label for this form after a clear action |

**Total Business Rules Identified: 12**

---

## 6. Data Requirements

*This form is a read-only productivity reporting tool that reads bodyshop repair order data filtered by dealership and billing date range, references the dealership's holiday calendar to calculate working days, aggregates panel counts from the bodyshop tracking records, and displays the derived productivity metrics on screen. No records are created or committed by this form.*

### 6.1 Business Entities and Relationships

*The form reads from the bodyshop repair order table as its primary data source. The holiday calendar and bodyshop tracking tables are read by the backend calculation functions to support working-day counting and panel aggregation.*

#### Bodyshop Repair Orders - VH_RO

The vehicle repair order table is the primary data source for this report. The form queries it to count completed bodyshop job cards (`RCATEG_CD = 'BANDP'`), sum the total labour amount, and group results by work group code, all filtered by the dealership, parent group, location, and the user-selected billing date range. This table is read-only in this form; no records are inserted, updated, or deleted.

#### Working-Day Holiday Calendar - WD_BTN

The dealership's holiday calendar records non-working days by dealer, parent group, and location. The working-day counter function reads this table to determine which days within the selected date range should be excluded from the productivity ratios. This table is read-only.

#### Bodyshop Panel Tracking Records - VT_VTS

The vehicle tracking and staging records table holds panel-level detail for each repair order. The panel-count function reads this table to sum the total number of panels repaired per job card. This table is read-only.

#### Entity Relationships

The repair order table drives the primary query. The holiday calendar is joined on the dealer, parent group, and location identifiers to exclude non-working days when the working-day count is calculated. The panel tracking records are joined to the repair order on the repair order number to sum panel counts per order.

```
VH_RO (Bodyshop Repair Orders)
        ├── WD_BTN (Holiday Calendar)     <- joined by parent_group, dealer_map_cd, loc_cd to count working days per group
        └── VT_VTS (Panel Tracking Records)  <- joined by parent_group, dealer_map_cd, loc_cd, ro_num to sum panels per repair order
```

### 6.2 Data Capture Requirements

*All data entry on this form is restricted to the search filter (billing date range). All other fields are system-calculated display values. No database records are created or updated.*

#### Report Filter (Report User - at search entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| From Bill Date (`FROM_JC_BILL_DT`) | Yes | Start date of the billing period to report on, entered by the user | Must not be blank; must not be after today's date |
| To Bill Date (`TO_BILL_DT`) | Conditional | End date of the billing period to report on; defaults to today if left blank | Must not be after today; must not be earlier than From Bill Date; the range between From and To dates must not exceed 31 days |

#### Report Results (System - populated after Search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Group Code (`NO_OF_BAYS`) | Auto-Populated | Work group identifier; one row per work group found in the selected date range | System-populated from query results; read-only |
| Number of Working Days (`NO_OF_WORK_DAYS`) | Auto-Populated | Count of working days in the selected period for the group, excluding declared holidays | System-calculated via working-day counter; read-only |
| Number of Vehicles Repaired (`NO_OF_VEH_REP`) | Auto-Populated | Count of bodyshop job cards completed within the date range for the group (format: 999D00) | System-calculated; read-only |
| Number of Panels (`NO_OF_PANELS`) | Auto-Populated | Total count of body panels repaired across all job cards in the group for the period | System-calculated via panel-count function; read-only |
| Labour Amount Generated (`LAB_GEN`) | Auto-Populated | Total labour amount billed across all job cards in the group (format: 9999999D00) | System-calculated; read-only |
| Bay Productivity (`BAY_PROD`) | Auto-Populated | Vehicles repaired per working day for the group, rounded to 2 decimal places (format: 999D00) | System-calculated; read-only |
| Panel Productivity (`PANEL_PROD`) | Auto-Populated | Panels repaired per working day for the group, rounded to 2 decimal places | System-calculated; read-only |
| Labour Productivity (`LABOUR_PROD`) | Auto-Populated | Labour amount per working day for the group, rounded to 2 decimal places (format: 9999999D00) | System-calculated; read-only |
| Report Description (`REPORT_DESC`) | Auto-Populated | Heading label for the report, sourced from the session-level report description value | System-assigned; not user-editable |
| Query Text (`TXT`) | Auto-Populated | Internal text field holding the assembled export query string; not displayed to users | System-assigned during export; not user-editable |

#### Session and Global Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Code (`global.dealer`) | Auto-Populated | Dealership identifier from the active session; used as a filter on all database queries | Set externally before form entry; not user-editable in this form |
| Parent Group (`global.parent_group`) | Auto-Populated | Parent group identifier from the active session; applied as a filter alongside the dealer code | Set externally before form entry; not user-editable in this form |
| Location Code (`global.loc_cd`) | Auto-Populated | Location identifier from the active session; applied as a filter on all database queries | Set externally before form entry; not user-editable in this form |
| User ID (`global.userid`) | Auto-Populated | Logged-in user identifier; used to compose the export filename | Set externally before form entry; not user-editable in this form |
| Report Description (session) (`global.report_desc`) | Auto-Populated | Session-level label for this report; copied into the on-screen heading field | Set externally; refreshed on clear-form action |
| Pagination - From (`global.from_no`) | Auto-Populated | Lower bound for result-set pagination control; initialised to 1 by the global initialisation procedure | Set by the form; erased on form exit |
| Pagination - To (`global.to_no`) | Auto-Populated | Upper bound for result-set pagination control; initialised to 10 by the global initialisation procedure | Set by the form; erased on form exit |
| Pagination - Increment (`global.increment_no`) | Auto-Populated | Page size for result-set pagination control; initialised to 10 by the global initialisation procedure | Set by the form; erased on form exit |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Bodyshop Holiday Calendar (WD_BTN) | Records non-working days by dealership and location so that productivity ratios are based on actual working days rather than raw calendar days | Called for each day in the selected date range when the Search button is pressed and when building the export query |
| Bodyshop Panel Tracking Records (VT_VTS) | Stores the number of body panels repaired per repair order; used to total panel counts by work group | Called per repair order in the query when the Search button is pressed and when building the export query |
| Repair Order Records - Body and Paint category (VH_RO, RCATEG_CD filter) | Provides the core bodyshop job card counts and labour amounts for the selected dealership, date range, and work groups | Queried when the Search button is pressed and when the export query is assembled |
| Export Path Configuration File (/reports/DMS/excelpath.txt) | Specifies the server directory path to which the CSV export file is written | Read during the Export to Excel operation by the export utility (EXTERNAL / NOT IN BUNDLE - file exists on the forms server) |

### 6.4 Data Lifecycle

*This form is a read-only reporting tool. It reads existing records but does not create, update, or delete any database rows.*

**Creation**

- No records are created by this form. All data displayed on screen is derived by querying existing repair order, holiday calendar, and panel tracking records in the database.

**Updates**

- No records are updated by this form. The productivity figures displayed are computed on demand from existing source data and are not written back to any table.

**Save and Commit**

- No save or commit operations are performed. The form operates in a query-only mode; there is no data-entry commit path.
- The export function (Export to Excel button) writes a CSV file to the server file system; this is a file-system operation, not a database commit.

**Retention and Audit**

- The form does not create or update any audit or modification timestamps. Session context (module name and client info) is registered in the database session via `DBMS_APPLICATION_INFO` when the form opens and cleared when it exits, but this is a session-level tracking mechanism, not a persistent audit record.
- The generated CSV export file is written to the server path configured in the export path file; no retention or clean-up policy for these files is implemented within the form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | USERID | GROUP_CD |  | VH_RO | GROUP_CD | Shows the GROUP_CD taken from the enquiry's related records. |
| 2 | From Bill Date / To Bill Date (date range entered by user) | NO. OF DAYS. |  | WD_BTN |  | Shows the NO. OF DAYS. linked to WD_BTN, looked up via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT. |
| 3 | USERID | NO.OF JOB |  | VH_RO | NO_OF_JC | Shows the NO.OF JOB taken from the enquiry's related records. |
| 4 | USERID | PANELS |  | VH_RO | PANEL_CNT | Shows the PANELS taken from VH_RO.PANEL_CNT, looked up via PKG_VTS_BODYSHOP.SF_GET_PANEL. |
| 5 | USERID | LAB AMT |  | VH_RO | LAB_AMT | Shows the LAB AMT taken from the enquiry's related records. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| BANDP | Body and Paint - the bodyshop repair category code used to filter repair orders to the bodyshop department | Body & Paint | Bodyshop, Repair Category |
| Bay Productivity | Number of job cards completed per working day for a bodyshop bay group; one of three key productivity metrics in this report | Vehicle Productivity | Panel Productivity, Labour Productivity |
| Bodyshop | The vehicle body repair and paint department within a dealership | Body Shop | BANDP, Bay Group |
| Bay Group | A named grouping of bodyshop repair bays used to aggregate and compare productivity across different workshop areas | Group Code | Bodyshop, CB_DOC |
| Bill Date | The date on which a repair order is invoiced or billed to the customer; used as the primary date filter in the report | Billing Date | Repair Order, Date Range |
| CB_DOC | Control block in the form that holds the calculated productivity results for each bay group | Results Block | CB_DOC_QUERY |
| CB_DOC_QUERY | Control block in the form that holds the search criteria (billing date range) entered by the user | Search Block | CB_DOC |
| CSV | Comma-Separated Values - the file format used for the productivity report export; opens in the user's browser for download or printing | Spreadsheet Export | Export, Excel |
| DMS | Dealer Management System - the integrated dealership software platform within which this form operates | - | Dealership, Form Module |
| DPL | Shared Oracle Forms program library providing common utility procedures and functions used across DMS forms | DPL.pld | PLD, Shared Library |
| From Bill Date | The start date of the billing date range entered by the user to filter repair orders | Start Date | To Bill Date, Date Range |
| Global Variable | A session-level variable persisted across Oracle Forms blocks and triggers within a single form session | :GLOBAL.* | Session Context |
| Holiday Calendar | The dealership-specific table of non-working days used to exclude public holidays when counting working days | WD_BTN | Working Day |
| Job Card | A repair order document recording a vehicle service or repair job; counted per group to measure throughput | RO, Repair Order | VH_RO, BANDP |
| Labour Productivity | Total labour amount generated per working day for a bay group; one of the three derived productivity metrics | Labour Prod | Bay Productivity, Panel Productivity |
| LOV | List of Values - a dropdown selection popup in Oracle Forms; no LOVs are defined in this form | Dropdown | Record Group |
| OLB | Oracle Object Library - a compiled library of reusable form objects; this form uses DPL.olb as its parent | Object Library | DPL |
| Panel Count | The total number of body panels repaired across all job cards for a bay group in the selected period | PANEL_CNT | VT_VTS, sf_get_panel |
| Panel Productivity | Total panels repaired per working day for a bay group; one of the three derived productivity metrics | Panel Prod | Bay Productivity, Labour Productivity |
| PCK | PL/SQL Package - a database-stored package containing procedures and functions; PKG_VTS_BODYSHOP is the PCK used by this form | Package | PKG_VTS_BODYSHOP |
| PKG_VTS_BODYSHOP | Database PL/SQL package providing panel-count and working-day-count functions used by the form to calculate productivity metrics | - | sf_get_panel, sf_get_working_day_cnt |
| PLD | Oracle Forms Program Library - a compiled shared library of PL/SQL procedures attached to forms at runtime; DPL.pld and webutil.pld are used here | Program Library | DPL, WEBUTIL |
| Repair Order | The primary vehicle service document; the data source for all job counts and amounts in this report | RO, Job Card | VH_RO, Bill Date |
| sf_get_panel | Database function in PKG_VTS_BODYSHOP that returns the total panel count for a specific repair order | - | PKG_VTS_BODYSHOP, Panel Count |
| sf_get_working_day_cnt | Database function in PKG_VTS_BODYSHOP that counts non-holiday working days between two dates for a dealership location | - | PKG_VTS_BODYSHOP, Working Day |
| To Bill Date | The end date of the billing date range entered by the user to filter repair orders | End Date | From Bill Date, Date Range |
| VH_RO | Database table containing vehicle repair order records; the primary data source for this report | Repair Order Table | Job Card, Bill Date |
| VT_VTS | Database table containing vehicle tracking and shift data; used to retrieve panel counts per repair order | Vehicle Tracking Table | sf_get_panel, Panel Count |
| WEBUTIL | Oracle Forms WebUtil integration library providing browser and file-system utility functions; used to serve the CSV export file | webutil.pld | DPL, OLB |
| WD_BTN | Database table listing non-working (holiday) dates for each dealership location; used to exclude holidays from the working-day count | Holiday Table | sf_get_working_day_cnt, Working Day |
| Working Day | A calendar day that is not listed in the holiday table for the dealership location; the denominator used in all productivity ratio calculations | Non-Holiday Day | sf_get_working_day_cnt, WD_BTN |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_bodyshop_group_prod (VR_BODYSHOP_GROUP_PROD)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Group Productivity Report (inherited from DPL.olb object group; no form-defined window present beyond the inherited WN_MAIN)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_VTS_BODYSHOP
- Source artifacts: `vr_bshop_group_prod_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); PCK `PKG_VTS_BODYSHOP.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier read at form startup; used to scope session context and referenced in Excel export call variants |
| APP_LOG | Char | Trigger | Application log flag or path set at session initialisation; used for audit or diagnostic logging |
| COMP_FA | Char | ProgramUnit / Trigger | Company or franchise code used to filter bodyshop repair order data |
| CURRENCY | Char | Trigger | Currency code for the current session; used to format monetary display values on the report |
| DEALER | Char | ProgramUnit / Trigger | Dealer map code identifying the dealership for data filtering |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session; used to bound period-based queries |
| FIN_END | Char | Trigger | Financial year end date for the current session; used to bound period-based queries |
| FROM_NO | Number | ProgramUnit / Trigger | Starting record number for pagination of result set |
| FROM_REC | Number | ProgramUnit / Trigger | Starting record index used in commented-out populate pagination logic |
| INCREMENT_NO | Number | ProgramUnit / Trigger | Page size increment for navigating result set pages |
| LOC_CD | Char | ProgramUnit / Trigger | Location code used to filter bodyshop repair orders by site |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent dealer group code used to scope all data queries |
| PRINCIPAL | Char | Trigger | Principal identifier used in commented-out Excel export variant |
| P_FIN_YR | Char | Trigger | Financial year parameter propagated from the calling context; used to filter period-based report data |
| REPORT_DESC | Char | Trigger | Report title or description displayed on the form canvas |
| REP_SERVER | Char | Trigger | Report server name read at session initialisation; used when submitting Oracle Reports jobs |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the current session |
| TO_NO | Number | ProgramUnit / Trigger | Ending record number for pagination of result set |
| TO_REC | Number | ProgramUnit / Trigger | Ending record index used in commented-out populate pagination logic |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID used to generate unique CSV export file names |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used for report headers and session context |

### 8.1.2 Form Parameters

*All 2 ModuleParameter entries from vr_bshop_group_prod_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_RO_NUM | Char | - | Repair order number passed in at startup; used in commented-out Excel generation logic to filter job card billing data |
| P_APP_ID | Char | - | Application identifier passed at startup; referenced in commented-out Excel export call variant |

**Total Parameters:** 2

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | 1 | N/N/N/N | Default | Control block - entry point for date-range search criteria |
| CB_DOC | - | 5 | N/N/N/N | Default | Control block - displays bodyshop group productivity results populated programmatically by the SEARCH button trigger |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_bshop_group_prod_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_bshop_group_prod_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_bshop_group_prod_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DOC_QUERY | 7 | 0 | 7 |
| CB_DOC | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **45** | **0** | **45** |

**Item detail (all 45 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | FROM_JC_BILL_DT | false | Start date for the bill date range filter |
| CB_DOC_QUERY | TO_BILL_DT | false | End date for the bill date range filter |
| CB_DOC_QUERY | SEARCH | false | Button - triggers bodyshop group productivity search |
| CB_DOC_QUERY | PB_EXCEL | false | Button - exports productivity results to a CSV/Excel file |
| CB_DOC_QUERY | TXT | false | Hidden text item holding the dynamic SQL query string for Excel export |
| CB_DOC_QUERY | COPYRIGHT_DECLARATION | false | Display field for copyright declaration text |
| CB_DOC_QUERY | REPORT_DESC | false | Display field showing the report title or description |
| CB_DOC | NO_OF_BAYS | false | Bodyshop group code identifying the bay group |
| CB_DOC | NO_OF_WORK_DAYS | false | Number of working days in the selected date range for the group |
| CB_DOC | NO_OF_VEH_REP | false | Number of job cards (vehicles repaired) in the period |
| CB_DOC | NO_OF_PANELS | false | Total panel count for the group in the period |
| CB_DOC | LAB_GEN | false | Total labour amount generated in the period |
| CB_DOC | BAY_PROD | false | Bay productivity - job cards per working day for the group |
| CB_DOC | PANEL_PROD | false | Panel productivity - panels per working day for the group |
| CB_DOC | LABOUR_PROD | false | Labour productivity - labour amount per working day for the group |
| CB_DOC | AVG_WORK | false | Average working days across all groups in the result |
| CB_DOC | AVG_VEH | false | Average number of vehicles repaired across all groups |
| CB_DOC | AVG_PANEL | false | Average panel count across all groups |
| CB_DOC | AVG_LAB | false | Average labour amount across all groups |
| CB_DOC | AVG_BAY_PROD | false | Average bay productivity across all groups |
| CB_DOC | AVG_GRP_PANEL | false | Average group panel productivity across all groups |
| CB_DOC | AVG_LAB_PROD | false | Average labour productivity across all groups |
| CB_ERR | TXT_ERR | false | Inherited display-only text item on the CN_ERR error canvas; shows runtime error message text to the user (inherited from DPL.olb CB_ERR block) |
| PB_BLK | PB_EXIT | false | Inherited toolbar button - exits the current form (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_LIST | false | Inherited toolbar button - invokes the LOV for the current item (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button - inserts a new record in the current block (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PM_CONT | false | Inherited toolbar button - continues or confirms the current operation (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_DEL | false | Inherited toolbar button - deletes the current record (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button - cancels pending changes in the current block (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button - saves (commits) pending changes (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button - initiates a print action for the current report or screen (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_CUT | false | Inherited toolbar button - cuts the selected text or record value (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_COPY | false | Inherited toolbar button - copies the selected text or record value (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button - pastes clipboard content into the current item (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_ERR_EXIT | false | Inherited error-canvas button - closes the error window without further action (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_ERR_OK | false | Inherited error-canvas button - acknowledges and dismisses the error dialog (inherited from DPL.olb PB_BLK block) |
| WEBUTIL | DUMMY | false | Placeholder item required by the WebUtil framework to anchor the WEBUTIL block (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item exposing client machine information functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item exposing client-side file system functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item exposing host command execution functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item exposing session-level utility functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item exposing client-to-server and server-to-client file transfer functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item exposing OLE automation functions for client-side Office integration (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item exposing native C API call functions on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item exposing browser control and navigation functions (inherited from webutil.olb) |

### 8.4 List of Values

*No LOVs found in vr_bshop_group_prod_fmb.xml.*

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | ProgramUnit: VIEW_EXCEL_REP (inherited from webutil.olb; displayed when a WebUtil client-server operation fails) |
| AL_PRINT | Print | (set at runtime) | DPL library routine GENERAL.ASK_CONFIRM / PROC_REPORT_CALL; displayed to confirm or report the outcome of a print action (inherited from DPL.olb) |
| AL_ERRINFO | Error | (set at runtime) | DPL library routine GENERAL.DISP_TEXT; displayed when an error-level message must be shown to the user (inherited from DPL.olb) |
| AL_NOTE | Note | (set at runtime) | DPL library routine GENERAL.DISP_TEXT; displayed for informational messages (inherited from DPL.olb) |
| AL_CONFIRM | Caution | (set at runtime) | DPL library routine GENERAL.ASK_CONFIRM; displayed to request user confirmation before a destructive or irreversible action (inherited from DPL.olb) |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| SET_GLOBAL | Procedure | None (no sub-calls; directly assigns :global variables) | Initialises pagination globals: sets :global.from_no to 1, :global.to_no to 10, and :global.increment_no to 10 at form startup |
| POPULATE | Unknown | **COMMENTED OUT / INACTIVE** (would have called CB_DOC block, DOC_DET.V_DOC_TAB) | **COMMENTED OUT / INACTIVE** - Was intended to populate CB_DOC block from an in-memory PL/SQL table (DOC_DET.V_DOC_TAB) using global pagination variables |
| DOC_DET | Unknown | **COMMENTED OUT / INACTIVE** (package spec only; no sub-calls) | **COMMENTED OUT / INACTIVE** - Was a form-local package spec declaring an in-memory document table (V_DOC_TAB) for caching query results |
| EXCEL_GENERATION | Unknown | **COMMENTED OUT / INACTIVE** (would have called VH_RO, GM_CIN, VM_RCATEG, Text_IO, Web.Show_Document, GENERAL.DISP_TEXT) | **COMMENTED OUT / INACTIVE** - Was intended to generate a CSV export of job card billing details using an in-memory result set and write it to a server file |
| VIEW_EXCEL_REP | Procedure | WEBUTIL.ID_NULL (via webutil.pld), Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Find_Column, Get_Group_Char_Cell, Text_IO.Fopen, Text_IO.Get_Line, Text_IO.Fclose, Text_IO.Put_Line, Web.Show_Document | Generates a CSV file on the application server from a dynamic SQL query and opens it in the browser; called by the Export to Excel button |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Presents a confirmation dialog (using AL_CONFIRM or AL_PRINT alert) and returns the user's choice; used before destructive or print actions |
| GENERAL.DISP_TEXT | Library routine | Form level; ProgramUnit: EXCEL_GENERATION (commented out) | Displays an informational or error message dialog using AL_NOTE or AL_ERRINFO alert; called from ON-MESSAGE trigger and formerly from EXCEL_GENERATION |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code and displays it as an Error, Note, or Caution dialog; referenced in the commented-out ON-ERROR handler |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | ON-ERROR | Commented-out code called GENERAL.RAISE_ERROR for ORA-02292 constraint violations and GENERAL.DISP_TEXT for various Forms error codes | Replaced by `null;` stub; error-handling logic preserved in comments for reference |
| **Inactive stub** | Form | - | KEY-CLRFRM | Commented-out code erased pagination globals, cleared the form, reset document type, and re-initialised control items including date ranges and block permissions | Replaced by `null;` stub; the active line only restores :report_desc from the global |
| **Inactive stub** | Form | - | FT_CANCEL | Trigger body is `null;`; formerly would have cancelled pending changes via the inherited DPL toolbar cancel action | Inherited FT_CANCEL trigger overridden with null stub; cancel behaviour suppressed in this form |
| **Inactive stub** | Form | - | FT_DEL | Trigger body is `null;`; formerly would have deleted the current record via the inherited DPL toolbar delete action | Inherited FT_DEL trigger overridden with null stub; delete behaviour suppressed in this read-only report form |
| **Inactive stub** | Form | - | FT_LIST | Trigger body is `null;`; formerly would have invoked the LOV for the current item via the inherited DPL toolbar list action | Inherited FT_LIST trigger overridden with null stub; LOV toolbar button suppressed in this form |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Commented-out code initialised session globals (PARENT_GROUP, DEALER, LOC_CD, COMP_FA, USERID, REPORT_DESC, CURRENCY, etc.) by reading from a session context or parameter list, called SET_GLOBAL, and set up the initial form state | Inherited WHEN-NEW-FORM-INSTANCE from DPL.olb is present; form-level override body is fully commented out, deferring initialisation to the inherited trigger |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-UP | Trigger body is `null;`; no former behaviour documented | Inherited stub from DPL.olb object group override; suppresses default upward block-navigation behaviour within the query block |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-DOWN | Trigger body is `null;`; no former behaviour documented | Inherited stub from DPL.olb object group override; suppresses default downward block-navigation behaviour within the query block |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (39 triggers):**
*vr_bshop_group_prod_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **INACTIVE STUB** - Active code is `null;`; commented-out block handles Forms and Oracle errors by calling GENERAL.DISP_TEXT or GENERAL.RAISE_ERROR |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms messages 40209 and 40207 and displays them via GENERAL.DISP_TEXT instead of the default message handler |
| KEY-EXIT | Form | - | Form level | Clears database application info, erases pagination globals (from_no, to_no, increment_no), and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Empty trigger body; suppresses default LOV invocation key behaviour |
| KEY-COMMIT | Form | - | Form level | Empty trigger body; suppresses default commit key behaviour |
| KEY-CLRFRM | Form | - | Form level | **INACTIVE STUB** - Active code only restores :report_desc from global; commented-out block reset the form, re-initialised globals, and restored control item states |
| KEY-UP | Form | - | Form level | Inherited form-level KEY-UP trigger from DPL.olb object group; suppresses or redirects default upward navigation at form scope (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited form-level KEY-DOWN trigger from DPL.olb object group; suppresses or redirects default downward navigation at form scope (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited form-level KEY-PRVBLK trigger from DPL.olb object group; suppresses or redirects previous-block navigation (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited form-level KEY-NXTBLK trigger from DPL.olb object group; suppresses or redirects next-block navigation (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited form-level KEY-PREV-ITEM trigger from DPL.olb object group; controls backward item navigation across the form (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited form-level KEY-NEXT-ITEM trigger from DPL.olb object group; controls forward item navigation across the form (inherited) |
| KEY-OTHERS | Form | - | Form level | Inherited form-level KEY-OTHERS trigger from DPL.olb object group; suppresses unhandled key actions at form scope (inherited) |
| FT_SAVE | Form | - | Form level | Inherited toolbar Save trigger from DPL.olb; commits pending changes when the Save toolbar button is pressed (inherited) |
| FT_CANCEL | Form | - | Form level | **INACTIVE STUB** - Trigger body is `null;`; inherited DPL cancel action suppressed in this read-only report form |
| FT_INSERT | Form | - | Form level | Inherited toolbar Insert trigger from DPL.olb; inserts a new record when the Insert toolbar button is pressed (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE STUB** - Trigger body is `null;`; inherited DPL delete action suppressed in this read-only report form |
| FT_LIST | Form | - | Form level | **INACTIVE STUB** - Trigger body is `null;`; inherited DPL LOV toolbar action suppressed in this form |
| FT_PRINT | Form | - | Form level | Inherited toolbar Print trigger from DPL.olb; initiates a print action when the Print toolbar button is pressed (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT** - Inherited WHEN-NEW-FORM-INSTANCE from DPL.olb is present; form-level override is fully commented out; session globals and initial form state are initialised by the inherited trigger (inherited) |
| PRE-FORM | Form | - | Form level | Registers the form module name with Oracle's DBMS_APPLICATION_INFO for session-level tracking |
| KEY-UP | CB_DOC_QUERY | - | CB_DOC_QUERY | **INACTIVE STUB** - Trigger body is `null;`; suppresses upward navigation within the query block |
| KEY-DOWN | CB_DOC_QUERY | - | CB_DOC_QUERY | **INACTIVE STUB** - Trigger body is `null;`; suppresses downward navigation within the query block |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Validates the From Bill Date: rejects null value and rejects date greater than current date |
| KEY-NEXT-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Navigates focus to the To Bill Date field after the From Bill Date is entered |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | TO_BILL_DT | CB_DOC_QUERY.TO_BILL_DT | Validates the To Bill Date: rejects date greater than current date and rejects date earlier than From Bill Date |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | SEARCH | CB_DOC_QUERY.SEARCH | Validates date range, then queries PKG_VTS_BODYSHOP for bodyshop group productivity metrics (working days, job counts, panel counts, labour amounts) and populates the CB_DOC block |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | PB_EXCEL | CB_DOC_QUERY.PB_EXCEL | Validates date range, builds a dynamic SQL query for bodyshop group productivity data, and exports the results to a CSV file via VIEW_EXCEL_REP |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button trigger - exits the current form session (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button trigger - invokes the LOV for the currently focused item (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button trigger - inserts a new record in the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button trigger - continues or confirms the current pending operation (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button trigger - deletes the current record (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button trigger - cancels pending changes in the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button trigger - saves (commits) pending changes (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button trigger - initiates a print action for the current report or screen (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button trigger - cuts the selected text or record value to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button trigger - copies the selected text or record value to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button trigger - pastes clipboard content into the currently focused item (inherited) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Group Productivity Report (1.1.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN (inherited) |
| CN_MAIN | Content | WN_MAIN (inherited) |
| CN_ERR | Content | WIN_ERR (inherited) |

---

### 8.9 Editors

*No editors found in vr_bshop_group_prod_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_bshop_group_prod_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_bshop_group_prod_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_bshop_group_prod_fmb.xml.*

## 9. Object Library

*This form references two Object Library files: the DPL shared library (`DPL_olb.xml`) which provides property classes and visual attributes for standard form items, and the WebUtil library (`webutil_olb.xml`) which provides the WebUtil integration object group.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items | not used directly in this form | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio-button items | not used directly in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons | not used directly in this form | N/A |
| VA_DESC | VisualAttribute | Visual attribute for descriptive text items | not used directly in this form | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric items | not used directly in this form | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory fields | not used directly in this form | N/A |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts | not used directly in this form | N/A |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts | not used directly in this form | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for standard text items | not used directly in this form | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for push buttons | not used directly in this form | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert displays | not used directly in this form | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for title/heading items | not used directly in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date items | not used directly in this form | N/A |
| VA_LOV | VisualAttribute | Visual attribute for list-of-values items | not used directly in this form | N/A |
| VA_DISP | VisualAttribute | Visual attribute for display-only items | not used directly in this form | N/A |
| PC_DESC | PropertyClass | Property class for descriptive text items | not used in this form | N/A |
| PC_SC_DATE | PropertyClass | Property class for date fields (PROPERTY CLASS FOR DATE) | not used in this form | N/A |
| PC_TITLE | PropertyClass | Property class for title/text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-record blocks | not used in this form | N/A |
| PC_DISP | PropertyClass | Property class for display-only items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_LOV | PropertyClass | Property class for list-of-values items (PROPERTY CLASS FOR LIST OF VALUES) | not used in this form | N/A |
| PC_FORM | PropertyClass | Property class for the form module itself | 1 | VR_BODYSHOP_GROUP_PROD (form module) |
| PC_DISP_DATE | PropertyClass | Property class for display date items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display numeric items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_DATE | PropertyClass | Property class for date entry fields (PROPERTY CLASS FOR DATE) | 2 | FROM_JC_BILL_DT, TO_BILL_DT |
| PC_DTTIME | PropertyClass | Property class for date-and-time items | not used in this form | N/A |
| PC_CB | PropertyClass | Property class for check-box items | not used in this form | N/A |
| PC_ALERT | PropertyClass | Property class for alert items | not used in this form | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date fields (PROPERTY CLASS FOR DATE) | not used in this form | N/A |
| PC_RB | PropertyClass | Property class for radio-button items | not used in this form | N/A |
| PC_WIND | PropertyClass | Property class for window objects (PROPERTY CLASS FOR WINDOWS) | not used in this form | N/A |
| PC_CANV | PropertyClass | Property class for canvas objects | not used in this form | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | 1 | SEARCH |
| PC_TEXT | PropertyClass | Property class for standard text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_UTEXT | PropertyClass | Property class for updatable text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory updatable text items (PROPERTY CLASS FOR TEXT ITEMS) | not used in this form | N/A |
| PC_NUM | PropertyClass | Property class for numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | not used in this form | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (PROPERTY CLASS FOR NUMERIC ITEMS) | not used in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | not used in this form | N/A |
| PC_SCROLL | PropertyClass | Property class for scrollable items | not used in this form | N/A |
| WEBUTIL | ObjectGroup | WebUtil integration object group - subclassed into the form to provide client-side file, session, host, file-transfer, OLE, C-API, and browser utility functions | 5 | WEBUTIL block, WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW, WEBUTIL_ERROR, WEBUTIL item group |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil object group variant without OLE support | not subclassed in this form | N/A |

---

## 10. Record Groups

*No record groups found in `vr_bshop_group_prod_fmb.xml`.*

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | - | No |
| CB_DOC | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle pseudo-table - used as anchor row for the CSV column header in the Excel export query, and as a lightweight SELECT target during form initialisation |
| `VH_RO` | - | Trigger WHEN-BUTTON-PRESSED | Vehicle repair order table - source of bodyshop job card records filtered by dealer, group, location, and bill date range |

**Total Referenced Objects:** 2

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Counts the number of working days in the selected billing period by iterating through each calendar day and excluding days registered in the dealership's holiday calendar |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_PANEL | Retrieves the total number of body panels repaired for a given repair order from the bodyshop tracking records |
| BR-005 | VIEW_EXCEL_REP | Generates a CSV file from a provided SQL query, writes it to the configured server path, and opens the file in the user's browser |
| BR-006 | GENERAL.DISP_TEXT | Displays a formatted message alert to the user using the application's standard notification style |
| BR-006 | GENERAL.ASK_CONFIRM | Presents a confirmation dialog to the user before proceeding with potentially destructive or irreversible toolbar button actions |
| BR-006 | GENERAL.CHECK_FORM_FAILURE | Examines the Forms runtime failure state after a commit operation and raises an application error if the commit did not succeed |
| BR-001, BR-007 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers or clears the active form module identifier in the Oracle database session client-info slot |
| BR-001, BR-007 | DBMS_APPLICATION_INFO.SET_MODULE | Registers or clears the active form module name and action in the Oracle database session module-tracking slot |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatch routine; routes asynchronous client-side bean events to the appropriate WebUtil package handler for file transfer, host execution, browser control, and session callbacks |
| - | WEBUTIL.ID_NULL | Checks whether a WebUtil or Forms handle is null; used in VIEW_EXCEL_REP to test for an existing record group before deletion and recreation |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a named DLL via the D2KWUTIL client-side utility library; part of WebUtil/D2KWUTIL initialisation infrastructure |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Returns a debug string from the D2KWUTIL library; used internally during WebUtil diagnostic and initialisation routines |
| - | D2KWUTIL.D2KWUTIL_GETDOSENV | Retrieves a DOS/OS environment variable value via the D2KWUTIL client-side library |
| - | D2KWUTIL.D2KWUTIL_GETREGKEY | Reads a Windows registry key value via the D2KWUTIL client-side library |
| - | D2KWUTIL.TRANSLATETYPE | Translates an internal D2KWUTIL type identifier to its string representation; used during WebUtil initialisation |

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Database function (package) | Trigger WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH; trigger WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL | Counts the number of working days between two dates (inclusive) for a dealership location by iterating day by day and excluding dates present in the WD_BTN holiday table. Used as the denominator in all productivity ratio calculations (vehicle, panel, and labour productivity). Returns an integer count of non-holiday days. |
| PKG_VTS_BODYSHOP.SF_GET_PANEL | Database function (package) | Trigger WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH; embedded in export query in trigger WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL | Returns the total panel count for a specific repair order by summing the PANEL_WNSHLD column from VT_VTS, filtered by parent group, dealer, location, and repair order number. Called once per repair order in the SEARCH cursor to aggregate panel counts per bodyshop group. Returns 0 when no matching record exists. |
| VIEW_EXCEL_REP | Form program unit (procedure) | Trigger WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL | Creates a record group from a SQL query, writes all result rows to a CSV file on the server, and opens the file via a browser URL. Uses WEBUTIL.ID_NULL to check for a pre-existing record group before deletion and recreation, then calls WEB.SHOW_DOCUMENT to deliver the file to the user's browser. |
| GENERAL.DISP_TEXT | External package procedure (DPL.pld / GENERAL library) | Trigger ON-MESSAGE (form-level, active); referenced in trigger ON-ERROR (form-level, inactive) | Displays a modal message dialog to the user. Sets the AL_ERRINFO alert when the title is 'ERROR' and AL_NOTE for all other titles. Used in ON-MESSAGE to present Forms informational messages (codes 40209 and 40207) in a formatted dialog instead of the default status bar message. |
| GENERAL.ASK_CONFIRM | External package function (DPL.pld / GENERAL library) | Trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_COPY; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_CUT; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_DEL; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_INSERT; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_LIST; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_PASTE; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_PRINT; trigger WHEN-BUTTON-PRESSED on PB_BLK.PB_SAVE; trigger WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Presents a confirmation dialog to the user and returns a numeric result indicating the user's choice. Called from every inherited toolbar button trigger (PB_BLK push buttons) and the WEBUTIL dummy item trigger, allowing each button action to prompt the user before proceeding with potentially destructive or irreversible operations such as delete, cut, paste, insert, save, copy, print, list, and exit. |
| GENERAL.CHECK_FORM_FAILURE | External package procedure (DPL.pld / GENERAL library) | Trigger KEY-COMMIT (form-level) | Examines the Forms runtime failure state after a commit operation and raises an application error if the commit did not succeed. Ensures that any database error encountered during save processing is surfaced to the user rather than silently ignored. |
| GENERAL.RAISE_ERROR | External package procedure (DPL.pld / GENERAL library) - **INACTIVE** | Trigger ON-ERROR (form-level, commented out / inactive) | Was intended to look up an error message by code and display it as an Error, Note, or Caution dialog via GENERAL.DISP_TEXT. The ON-ERROR trigger body is `null;` so this routine is never invoked at runtime. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | Trigger PRE-FORM (form open); trigger KEY-EXIT (form exit) | Sets or clears the client-info identifier in the current Oracle database session for monitoring and tracing purposes. |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | Trigger PRE-FORM (form open); trigger KEY-EXIT (form exit) | Sets or clears the module name and action name in the current Oracle database session for performance monitoring. |
| WEB.SHOW_DOCUMENT | Oracle Forms built-in (WEB package) | Program unit VIEW_EXCEL_REP | Opens a specified URL in a new browser window; used by VIEW_EXCEL_REP to deliver the generated CSV file to the user's browser. |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil library procedure (webutil.pld / WEBUTIL_CORE) | Trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_C_API_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILE_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_HOST_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_OLE_FUNCTIONS; trigger WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine. Each WEBUTIL block item fires WHEN-CUSTOM-ITEM-EVENT when the client-side WebUtil Java bean raises an asynchronous event; the trigger delegates immediately to CustomEventHandler, passing the event name and its serialised parameter string. The routine decodes the event and routes it to the appropriate WebUtil package handler, enabling client-side file transfer, host execution, OLE, browser control, session, and client-info callbacks to complete their server-side processing. |
| WEBUTIL.ID_NULL | WebUtil library function (webutil.pld / WEBUTIL_C_API) | Program unit VIEW_EXCEL_REP | Checks whether a supplied WebUtil or Forms handle is null. In VIEW_EXCEL_REP, called to test whether a record group named DataRecordSet already exists before attempting to delete and recreate it. Returns TRUE when the handle is null (not found), FALSE when it refers to a valid object. |
| D2KWUTIL.ATTEMPT_DLL_LOAD | D2KWUTIL client-side library procedure | WebUtil / D2KWUTIL initialisation infrastructure (internal to webutil.pld) | Attempts to load a named DLL via the D2KWUTIL client-side utility library as part of WebUtil initialisation. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | D2KWUTIL client-side library function | WebUtil / D2KWUTIL diagnostic and initialisation routines (internal to webutil.pld) | Returns a debug string from the D2KWUTIL library; used internally during WebUtil diagnostic and initialisation processing. |
| D2KWUTIL.D2KWUTIL_GETDOSENV | D2KWUTIL client-side library function | WebUtil / D2KWUTIL initialisation infrastructure (internal to webutil.pld) | Retrieves a DOS/OS environment variable value via the D2KWUTIL client-side library during WebUtil initialisation. |
| D2KWUTIL.D2KWUTIL_GETREGKEY | D2KWUTIL client-side library function | WebUtil / D2KWUTIL initialisation infrastructure (internal to webutil.pld) | Reads a Windows registry key value via the D2KWUTIL client-side library during WebUtil initialisation. |
| D2KWUTIL.TRANSLATETYPE | D2KWUTIL client-side library function | WebUtil / D2KWUTIL initialisation infrastructure (internal to webutil.pld) | Translates an internal D2KWUTIL type identifier to its string representation during WebUtil initialisation. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-VTS-BODYSHOP | PKG_VTS_BODYSHOP | Bodyshop vehicle tracking and productivity calculation engine - exposes functions to count panels repaired per job card and to count working days in a date range, excluding public holidays, for a given dealership location and group | The form depends on this package to calculate and return the key bodyshop productivity metrics - working days and panel counts - that are displayed on screen and included in the exported report | sf_get_panel returns the total panel count for a repair order from VT_VTS; sf_get_working_day_cnt counts non-holiday working days in the specified date range by consulting the WD_BTN holiday table; both functions return numeric values greater than or equal to zero; division-based productivity ratios computed in form SQL use these return values |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_VTS_BODYSHOP.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_panel | Function | function sf_get_panel(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_comp varchar2, p_ronum varchar2) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Returns the total panel count for a specific repair order by summing the PANEL_WNSHLD column from VT_VTS, filtered by parent group, dealer, location, and repair order number. Called once per repair order in the SEARCH cursor to aggregate panel counts per bodyshop group. Returns 0 when no matching record exists. |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_working_day_cnt | Function | function sf_get_working_day_cnt(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_frm_dt date, p_to_dt date) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Counts the number of working days between two dates (inclusive) for a dealership location by iterating day by day and excluding dates present in the WD_BTN holiday table. Used as the denominator in all productivity ratio calculations (vehicle, panel, and labour productivity). Returns an integer count of non-holiday days. |

**Total Matched Package Routines (called from form XML):** 2

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| sf_get_panel | Number | 0 or positive integer (panel count) | Total number of panels repaired for the given repair order; returns 0 when no VT_VTS record exists |
| sf_get_working_day_cnt | Number | 0 or positive integer (day count) | Number of working days (excluding holidays in WD_BTN) between the from and to dates inclusive |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user and returns a numeric result indicating the user's choice. Called from every inherited toolbar button trigger (PB_BLK push buttons) as well as the WEBUTIL dummy item trigger, allowing each button action to prompt the user before proceeding with potentially destructive or irreversible operations such as delete, cut, paste, insert, save, copy, print, list, and exit. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Examines the Forms runtime failure state after a commit operation and raises an application error if the commit did not succeed. Called in the KEY-COMMIT trigger to ensure that any database error encountered during save processing is surfaced to the user rather than silently ignored. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-MESSAGE in Form | Displays a modal message dialog to the user. Sets the AL_ERRINFO alert when title_string is 'ERROR' and AL_NOTE for all other titles. Used in ON-MESSAGE to present Forms informational messages (codes 40209 and 40207) to the user in a formatted dialog instead of the default status bar message. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_bshop_group_prod_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | **COMMENTED OUT / INACTIVE** - Was intended to look up an error message by code, then display it as an Error, Note, or Caution dialog via GENERAL.DISP_TEXT. The ON-ERROR trigger body is `null;` so this routine is never invoked at runtime. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine. Each WEBUTIL block item fires WHEN-CUSTOM-ITEM-EVENT when the client-side WebUtil Java bean raises an asynchronous event; the trigger delegates immediately to CustomEventHandler, passing the event name and its serialised parameter string. The routine decodes the event and routes it to the appropriate WebUtil package handler, enabling client-side file transfer, host execution, OLE, browser control, session, and client-info callbacks to complete their server-side processing. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a supplied WebUtil or Forms handle is null. In VIEW_EXCEL_REP, called to test whether a record group named DataRecordSet already exists before attempting to delete and recreate it. Returns TRUE when the handle is null (not found), FALSE when it refers to a valid object. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Bodyshop Group Productivity Query | VH_RO (queried), PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT, PKG_VTS_BODYSHOP.SF_GET_PANEL | dealerMapCd, parentGroup, locCd, fromBillDate, toBillDate | Array of group productivity records: groupCode, workingDays, jobCount, panelCount, labourAmount, bayProductivity, panelProductivity, labourProductivity | Queries bodyshop repair orders for the specified dealership and date range, groups by work group, and returns the productivity metrics per group including working-day counts and panel totals | `GET /bodyshop/productivity/groups?dealerMapCd={}&parentGroup={}&locCd={}&fromDate={}&toDate={}` |
| MS-002 | Working Day Count | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT, WD_BTN | parentGroup, dealerMapCd, locCd, fromDate, toDate | workingDayCount (integer) | Counts the number of working days in a date range for a specific dealership by excluding days registered in the holiday calendar | `GET /bodyshop/working-days/count?parentGroup={}&dealerMapCd={}&locCd={}&fromDate={}&toDate={}` |
| MS-003 | Repair Order Panel Count | PKG_VTS_BODYSHOP.SF_GET_PANEL, VT_VTS | parentGroup, dealerMapCd, locCd, compFa, roNum | panelCount (number) | Retrieves the total number of body panels recorded against a specific repair order from the bodyshop tracking records | `GET /bodyshop/repair-orders/{roNum}/panel-count?parentGroup={}&dealerMapCd={}&locCd={}&compFa={}` |
| MS-004 | Bodyshop Productivity Report Export | VH_RO, PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT, PKG_VTS_BODYSHOP.SF_GET_PANEL | dealerMapCd, parentGroup, locCd, fromBillDate, toBillDate, userId | CSV file download (attachment) with columns: GROUP_CD, NO. OF DAYS, NO. OF JOB, PANELS, LAB AMT, VEHICLE PRODUCTIVITY, PANEL PRODUCTIVITY, LABOUR PRODUCTIVITY | Generates and delivers a CSV export of the bodyshop group productivity data for the selected dealership and date range | `GET /bodyshop/productivity/groups/export?dealerMapCd={}&parentGroup={}&locCd={}&fromDate={}&toDate={}` |

**Total Microservices Identified: 4**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Open and Session Registration | Form launched by the user (PRE-FORM) | 1. System registers the form module name as the active database session context | None | Session registered; form displays and awaits user input |
| WF-002 | Billing Date Range Entry and Validation | User enters the From Bill Date and To Bill Date filter fields | 1. User enters From Bill Date; system validates it is not blank and not in the future. 2. User navigates to To Bill Date field; system defaults to today if blank, then validates not in the future, not before From Bill Date, and range does not exceed 31 days | From Bill Date blank -> error, block navigation. From Bill Date in the future -> error, block navigation. To Bill Date in the future -> error, block navigation. To Bill Date before From Bill Date -> error, block navigation. Date range exceeds 31 days -> error, redirect cursor to To Bill Date | Date range accepted; user ready to search |
| WF-003 | Bodyshop Group Productivity Search | User presses the Search button | 1. System re-validates the date range (end date not in future, end not before start). 2. System queries repair orders grouped by work group. 3. For each group: working-day count calculated; panel count retrieved per order; productivity ratios derived. 4. Results block cleared and populated. 5. Focus moved to Export button | Date validation fails at search time -> error alert, cursor to To Bill Date, search aborted | Results grid populated with one row per work group; focus on Export to Excel button |
| WF-004 | Export Productivity Results to CSV | User presses the Export to Excel button | 1. System assembles the export query with the current date range. 2. Export utility derives unique filename from user ID and timestamp. 3. If filename path contains spaces, file redirected to default drive root and user informed. 4. Result set created from query; if row count exceeds 65,535, output is truncated and user warned. 5. Export path read from server configuration file. 6. CSV file written to server path. 7. File opened in user's browser | File path contains spaces -> path redirected, warning shown, export continues. Row count exceeds Excel limit -> truncated to 65,535 rows, warning shown. Any file-operation error -> error message shown, trigger failure raised | CSV file delivered to user's browser for download |
| WF-005 | Form Message Interception | Any Oracle Forms runtime message raised (ON-MESSAGE) | 1. System checks whether the message code is one of the two designated codes (concurrency conflict or invalid date entry). 2. If matched, the message is re-displayed via the standard alert mechanism and the triggering action is aborted. 3. If not matched, message passes to Oracle Forms default handling | Message code not in designated set -> default Oracle Forms handling; no custom action | User sees message in standard format (for designated codes) or in Oracle Forms default format (for all other codes) |
| WF-006 | Form Exit and Session Cleanup | User triggers the keyboard exit action (KEY-EXIT) | 1. Session context (client info and module name) cleared in the database session. 2. Global pagination variables erased. 3. Form closed without validating unsaved data | None | Form closed; database session context cleared; global variables released |
| WF-007 | Report Description Refresh (Clear Form) | User triggers the keyboard clear-form action (KEY-CLRFRM) | 1. Report description display field refreshed from the session-level report description value | None | Report description heading updated from session value; no other form state changed (full form-reset logic is inactive) |

**Total Workflows Identified: 7**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is tested, then returns whether it is null to control group deletion and recreation |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | DISP_TEXT | Business Logic | Trigger: ON-MESSAGE in Form | /api/v1/pld/disp_text | When a Forms message is intercepted, then displays the message text and type in a modal alert dialog |
| PLD-002 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | **COMMENTED OUT / INACTIVE** - When an error code is supplied, then looks up the message and raises the appropriate Error, Note, or Caution dialog |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_bshop_group_prod_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_VTS_BODYSHOP.sf_get_panel | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_panel | When a repair order is included in the productivity query, then returns the total panel count from VT_VTS for that repair order |
| PCK-002 | PKG_VTS_BODYSHOP.sf_get_working_day_cnt | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_working_day_cnt | When a date range is provided, then returns the count of non-holiday working days by excluding dates found in the WD_BTN table |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Bodyshop Repair Orders (VH_RO) | Oracle table - SELECT | Provides the primary data source for job card counts, labour amounts, and group identifiers used in the productivity calculation | Form reads: repair order records filtered by dealer, parent group, location, body-and-paint category, and billing date range | No explicit error handler in the calling trigger; exceptions would propagate to the Oracle Forms default error handler |
| Bodyshop Panel Tracking (VT_VTS) | Oracle table - SELECT (via PKG_VTS_BODYSHOP.SF_GET_PANEL) | Provides panel counts per repair order for aggregation in the productivity calculation | Function reads: panel count summed from tracking records matching repair order number, dealer, parent group, and location | Function returns NVL(count, 0) - no exception raised for missing records |
| Dealership Holiday Calendar (WD_BTN) | Oracle table - SELECT (via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT) | Provides the list of non-working days for the dealership so that productivity ratios are based on actual working days | Function reads: holiday count per calendar day for the dealer, parent group, and location; days with a holiday record are excluded from the working-day count | WHEN OTHERS exception in the function sets holiday count to 0, meaning the day defaults to being counted as a working day |
| DUAL | Oracle built-in table - SELECT | Used in the export query to produce the CSV header row as a constant string | Form reads: constant column header string for the CSV first row | No error handling required for DUAL queries |
| Oracle Database Session Context (DBMS_APPLICATION_INFO) | Oracle built-in package | Registers and clears the form's identity in the database session for monitoring and tracing | Form writes: client info and module name at form open; clears both at form exit | No error handling; Oracle built-in - failures would surface as Oracle errors |

### 20.2 External System Integrations

This form has no integrations with external systems in the traditional sense (no calls to external REST APIs, messaging systems, or third-party services). The one external dependency is the Oracle Forms WebUtil library, which is a client-side extension for file and browser operations:

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle WebUtil library (WEBUTIL) | Forms client-side library (subclassed object group) | Provides the foundation for client-side file I/O, browser operations (WEB.SHOW_DOCUMENT), and session/host utilities used by the export function | Oracle Forms client-server API | N/A - library loaded at form startup via WebUtil object group subclass | Library provides Text_IO file operations and WEB.SHOW_DOCUMENT browser call used in VIEW_EXCEL_REP | Errors surface in the VIEW_EXCEL_REP WHEN OTHERS handler, which displays *"Error  -"* followed by the dynamic error code and text and raises a trigger failure |

### 20.3 Report Integrations

No Oracle Reports are called by this form. The `reference_data.reports` list in the functional slice is empty. The export functionality in BR-005 uses a form program unit (VIEW_EXCEL_REP) to write a CSV file directly and open it via a browser URL - this is not an Oracle Reports integration.

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| (none - no Oracle Reports calls in this form) | N/A | N/A | N/A | N/A |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_BODYSHOP_GROUP_PROD form.

### 21.1 Catalogue Index

67 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-007](#SP-007--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-008](#SP-008--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-009](#SP-009--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-010](#SP-010--PKG_VTS_BODYSHOP.SF_GET_PANEL) | PKG_VTS_BODYSHOP.SF_GET_PANEL |
| [SP-011](#SP-011--PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT) | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT |
| [SP-012](#SP-012--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-013](#SP-013--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-014](#SP-014--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-015](#SP-015--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-016](#SP-016--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-017](#SP-017--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-018](#SP-018--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-019](#SP-019--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-020](#SP-020--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-021](#SP-021--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-022](#SP-022--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-023](#SP-023--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-026](#SP-026--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-027](#SP-027--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-028](#SP-028--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-029](#SP-029--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-030](#SP-030--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-031](#SP-031--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-032](#SP-032--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-033](#SP-033--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-034](#SP-034--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-035](#SP-035--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-036](#SP-036--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-037](#SP-037--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-038](#SP-038--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-039](#SP-039--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-040](#SP-040--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-041](#SP-041--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-042](#SP-042--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-043](#SP-043--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-045](#SP-045--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-047](#SP-047--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-048](#SP-048--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-049](#SP-049--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-050](#SP-050--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-052](#SP-052--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-053](#SP-053--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-054](#SP-054--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-055](#SP-055--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-056](#SP-056--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-057](#SP-057--ADD_ERROR) | ADD_ERROR |
| [SP-058](#SP-058--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-059](#SP-059--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-060](#SP-060--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-061](#SP-061--DEBUGLOG) | DEBUGLOG |
| [SP-062](#SP-062--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-063](#SP-063--READ_REGISTRY) | READ_REGISTRY |
| [SP-064](#SP-064--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-065](#SP-065--SETDEBUG) | SETDEBUG |
| [SP-066](#SP-066--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-067](#SP-067--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV-formatted Excel report from a dynamic SQL query and streams it to the user's browser. When triggered from the workshop group production screen, the procedure builds a record group from the supplied query, writes each data row to a server-side CSV file whose name is derived from the current user ID and timestamp, and then opens the file in a new browser window via a pre-configured URL path read from a server configuration file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-021](#SP-021--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-022](#SP-022--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-035](#SP-035--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-045](#SP-045--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the current user ID from the global variable ':global.userid' and combine it with the current date/time (formatted YYYYMMDDHHMISS) to produce a unique CSV filename (e.g., JDOE20240101120000.csv).
- Step 2 - Assign the generated filename to the working FILENAME variable. If the filename is NULL the assignment is skipped (no-op branch).
- Step 3 - Validate the FILENAME for embedded spaces in the folder path. If spaces are detected, override the path to 'C:\' and display a warning message informing the user that the file will be stored on the C drive as a default.
- Step 4 - Check whether a record group named 'DataRecordSet' already exists using WEBUTIL.ID_NULL (SP-037). If it exists, delete it to avoid stale data conflicts before recreating it.
- Step 5 - Create a new record group named 'DataRecordSet' from the dynamic SQL supplied in p_query, then populate it and capture the total row count.
- Step 6 - Enforce the Excel row limit: if the row count exceeds 65,536, display a truncation warning message and cap the row count at 65,535.
- Step 7 - Derive the server-side file path by prepending the fixed directory '/iashome/ias/reports/printer/' to the base filename (stripping any Windows path prefix).
- Step 8 - Read the URL base path from the server configuration file '/reports/DMS/excelpath.txt' using TEXT_IO.FOPEN / TEXT_IO.GET_LINE / TEXT_IO.FCLOSE (backed by WEBUTIL.FOPEN SP-022, WEBUTIL.GET_LINE SP-035, WEBUTIL.FCLOSE SP-021). Concatenate this URL base path with the base filename to form the full browser-accessible URL (formserverpath).
- Step 9 - Open the server-side CSV file for writing using TEXT_IO.FOPEN (WEBUTIL.FOPEN SP-022).
- Step 10 - Locate the record group column identified by p_column_name, then iterate through all rows (up to the capped row count), retrieving each cell value with GET_GROUP_CHAR_CELL and writing it as a line to the CSV file using TEXT_IO.PUT_LINE (WEBUTIL.PUT_LINE SP-045).
- Step 11 - Close the CSV file using TEXT_IO.FCLOSE (WEBUTIL.FCLOSE SP-021) and open the generated file in a new browser window via WEB.SHOW_DOCUMENT using the formserverpath URL.
- Step 12 - On any exception, display the Oracle error code and error text, then raise FORM_TRIGGER_FAILURE to halt further form processing.

---
**Decision Points**

DP-001

Condition:
The generated vcFile value is NULL.

TRUE:
No assignment is made; the FILENAME variable retains its prior (uninitialized) state (null branch - no operation).

FALSE:
FILENAME is assigned the generated CSV filename (userid + timestamp + '.csv').

---

DP-002

Condition:
The FILENAME contains a space character within the folder path (INSTR(FILENAME,' ') > 0).

TRUE:
The path is overridden to 'C:\<basefilename>' and a warning message is displayed to the user.

FALSE:
The original FILENAME path is retained unchanged.

---

DP-003

Condition:
A record group named 'DataRecordSet' already exists (WEBUTIL.ID_NULL returns FALSE for rg_id).

TRUE:
The existing record group is deleted before a new one is created.

FALSE:
No deletion is performed; processing continues directly to record group creation.

---

DP-004

Condition:
The populated record group row count exceeds 65,536 rows.

TRUE:
A truncation warning message is displayed and the effective row count is capped at 65,535.

FALSE:
The full row count is used without modification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The CSV filename must be unique per execution; it is constructed by concatenating the current user ID (from ':global.userid') with the system date/time formatted as YYYYMMDDHHMISS, suffixed with '.csv'.
- BR-002 - If any folder segment in the resolved file path contains a space, the file must be redirected to the root of the C drive ('C:\') to ensure the file can be saved; the user must be notified of this override.
- BR-003 - The record group 'DataRecordSet' must be cleared before each execution to prevent stale or duplicate data from a prior invocation from contaminating the current report.
- BR-004 - The maximum number of rows written to the CSV file must not exceed 65,535, corresponding to the Excel row limit; any excess rows are silently truncated and the user must be warned.
- BR-005 - The server-side URL base path for the generated file must be read dynamically from the configuration file '/reports/DMS/excelpath.txt' at runtime; it must not be hard-coded in the procedure.
- BR-006 - The generated CSV file must be opened in a new browser window ('_blank') so as not to disrupt the current Oracle Forms session.
- BR-007 - Any runtime exception must surface the Oracle error code and error text to the user and terminate form trigger processing via FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, 
 												 p_query VARCHAR2,
 												 p_column_name VARCHAR2) 
IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);

	vcfile varchar2(150);
	lv_user  varchar2(150);
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);

begin
	lv_user := name_in(':global.userid'); 
	vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS'); 
	vcFile := vcFile||'.csv';

	if vcFile is null then
		null;
	else
		filename:=vcFile;
	end if;
	
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;
--message('1 '||filename);	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
--message('2 '||server_file);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
--message('3');	
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
--message('4');	
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
--message('5');	
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
--message('6');
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	end loop;
    text_io.fclose(myfile);   
	 	web.show_document(formserverpath,'_blank');
--message('7');
exception when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
 
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The procedure normalises the target path, confirms the DLL file is accessible, loads the library, and-when instructed-increments the global DLL load counter and marks the API as enabled. It returns the resulting ORA_FFI library handle to the caller (REGISTER_FUNCTION_CALL), allowing dependent foreign-function registrations to proceed only against a successfully loaded library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-066](#SP-066--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip path validation and proceed directly to the library load attempt.
- Step 2 - Normalise TargetPath by passing it through STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\'), ensuring a consistently formatted path regardless of how the caller supplied it. This also discards any secondary paths that may have been concatenated in the value.
- Step 3 - Attempt to open the file at the concatenated location (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the DLL file physically exists at the specified location.
- Step 4 - If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; the open was purely an existence check.
- Step 5 - If the file cannot be opened, invoke DEBUGLOG (severity 99) recording the procedure name 'Attempt_DLL_LOAD' and a message identifying the DLL and the path where it was not found, then raise the BadLocation exception to abort processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into memory and capture the returned library handle in hDLL.
- Step 7 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE.
- Step 8 - Return hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return hDLL (which will be null at that point) to the caller, allowing the caller to detect the failure via a null handle.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP, append a backslash, and perform the file-existence check before attempting the library load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the file at TargetPath || TargetDLL

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Invoke DEBUGLOG at severity 99 with the DLL name and path details, then raise BadLocation to abort the load attempt.

---

DP-003

Condition: LoadCount parameter is TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition: An unhandled exception is raised during the library load phase (WHEN OTHERS in the outer exception handler)

TRUE: Set API_ENABLED to FALSE and return a null hDLL handle to the caller.

FALSE: No exception; return the populated hDLL handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain only a single directory path; if multiple paths are present in the value, only the first segment (as produced by STRIPDIRSEP) is used and any additional content is discarded.
- BR-002 - A trailing backslash separator must always be appended to TargetPath after normalisation, ensuring ORA_FFI.LOAD_LIBRARY receives a consistently formatted directory path.
- BR-003 - The physical existence of the DLL file must be confirmed via a read-mode file open before any library load is attempted when TargetPath is supplied; a DLL that cannot be opened at the specified location must not be loaded.
- BR-004 - A failed file-existence check must be logged via DEBUGLOG at severity level 99, capturing the procedure context and the unresolvable file location, before the BadLocation exception is raised.
- BR-005 - The package-level counter DLL_LOAD_COUNT must be incremented and API_ENABLED must be set to TRUE only when the LoadCount parameter is explicitly TRUE and the library load succeeds.
- BR-006 - If the library load fails for any reason, API_ENABLED must be set to FALSE and a null library handle must be returned, signalling load failure to the caller without raising an unhandled exception.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to an underlying C library routine within the D2KWUTIL package. It is invoked by the WINDEBUG stored procedure to emit diagnostic or debug messages through the registered C function handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the C function handle (hFunc) that identifies the target native C routine registered via ORA_FFI, and the debug text string (Text) to be transmitted.
- Step 2 - Delegate execution directly to the underlying C implementation identified by the PRAGMA INTERFACE directive (interface code 11265), passing both the function handle and the text string as arguments.
- Step 3 - Return control to the calling procedure (WINDEBUG) upon completion; no output value is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a direct foreign-function call with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc); the handle must have been previously registered and bound to the native C routine before invocation.
- BR-002 - The Text parameter must be a VARCHAR2 value; no transformation or validation of the debug string is performed by this procedure before it is forwarded to the C layer.
- BR-003 - This procedure operates exclusively as a C foreign-function interface bridge (PRAGMA INTERFACE, C, interface code 11265) and performs no database reads or writes.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to retrieve and expand a DOS/operating-system environment variable string. Invoked via the ORA_FFI foreign-function interface, it accepts a function handle together with a source environment variable name and an output buffer, then returns an integer result code indicating the outcome of the environment-variable lookup.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the underlying OS-level routine responsible for resolving environment variables.
- Step 2 - Accept the source environment variable name or token (SourceStr) as an IN OUT parameter to be passed to the foreign function.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved/expanded value of the environment variable.
- Step 4 - Accept the input buffer length (InBuffLen) to define the maximum number of characters the foreign function may write into ExpandStr.
- Step 5 - Delegate execution to the foreign function identified by hFunc, passing SourceStr, ExpandStr, and InBuffLen as arguments.
- Step 6 - Return a PLS_INTEGER result code that reflects the success or failure of the environment-variable retrieval operation to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld).

---
**Decision Points**

No explicit conditional decision points are determinable from the available specification. The function delegates all branching logic to the foreign function referenced by hFunc; the returned PLS_INTEGER result code is the sole indicator of outcome and is evaluated by the calling routine GET_ENVIRONMENT_STRING.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle identifies the OS-level foreign function and is a mandatory prerequisite for any environment-variable resolution.
- BR-002 - The caller is responsible for supplying InBuffLen to constrain the write length into ExpandStr, preventing buffer overrun in the foreign-function call.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT; the calling routine GET_ENVIRONMENT_STRING must therefore allocate and pass pre-initialised VARCHAR2 variables and must read back their values after the call.
- BR-004 - The returned PLS_INTEGER result code is the authoritative indicator of whether the environment-variable lookup succeeded; the caller must inspect this value to determine subsequent processing.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it delegates the call to a native external function via ORA_FFI and returns the registry value in the RegValue output parameter together with a PLS_INTEGER return code indicating success or failure. It is invoked by the READ_REGISTRY stored procedure in D2kwutil.pld to expose Windows registry data to Oracle Forms at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc), the registry root identifier (RegRoot), the registry path (RegPath), the registry entry name (RegEntry), the buffer to hold the retrieved value (RegValue), the maximum value length (RegValueLength), and the expand-flag (RegDontExpand) as input arguments.
- Step 2 - Pass all parameters to the bound native external function referenced by hFunc using the ORA_FFI mechanism, which performs the actual Windows registry read operation outside the PL/SQL engine.
- Step 3 - Receive the registry value string returned by the native call and populate the IN OUT parameter RegValue with that result; RegPath and RegEntry are also declared IN OUT and are passed through to the external call as required by the FFI binding.
- Step 4 - Return a PLS_INTEGER result code to the caller (READ_REGISTRY) indicating the outcome of the registry read operation (e.g., success or a Windows error code).

---
**Decision Points**

No explicit decision points are determinable from the available source. The function specification contains no conditional logic; branching, if any, is encapsulated within the bound native external function invoked through ORA_FFI and is not visible in the PL/SQL layer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_FFI function handle (hFunc) that has been bound to the underlying native registry-access library prior to invocation; no internal binding or initialisation is performed within this function.
- BR-002 - RegValueLength must accurately reflect the maximum capacity of the RegValue buffer to prevent truncation or overflow of the returned registry value string.
- BR-003 - RegDontExpand controls whether environment-variable references within the registry value are expanded by the native call; the caller (READ_REGISTRY) is responsible for supplying the correct flag value according to the required retrieval behaviour.
- BR-004 - RegRoot must be a valid Windows registry root constant (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) expressed as a PLS_INTEGER; supplying an invalid root will result in a non-success return code from the native function.
- BR-005 - The return code (PLS_INTEGER) must be evaluated by the calling routine READ_REGISTRY to determine whether the registry key was successfully retrieved before the value in RegValue is used.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data-type name supplied by the caller into the corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer before a native library call is registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data-type token.
- Step 2 - Normalise the input to upper case and store it in the local variable vcType to ensure case-insensitive matching.
- Step 3 - Evaluate vcType against each recognised type token in sequence using an IF-ELSIF chain.
- Step 4 - For each matched token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR; 'CHAR' maps to ORA_FFI.C_CHAR; '*INT' maps to ORA_FFI.C_INT_PTR; 'INT' maps to ORA_FFI.C_INT; '*LONG' maps to ORA_FFI.C_LONG_PTR; 'LONG' maps to ORA_FFI.C_LONG; '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR; 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT; '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR; 'DOUBLE' maps to ORA_FFI.C_DOUBLE; '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 5 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001

Condition: vcType = '*CHAR'

TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer to character type).

FALSE: Evaluation continues to the next condition.

---

DP-002

Condition: vcType = 'CHAR'

TRUE: iRC is set to ORA_FFI.C_CHAR (character type).

FALSE: Evaluation continues to the next condition.

---

DP-003

Condition: vcType = '*INT'

TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer to integer type).

FALSE: Evaluation continues to the next condition.

---

DP-004

Condition: vcType = 'INT'

TRUE: iRC is set to ORA_FFI.C_INT (integer type).

FALSE: Evaluation continues to the next condition.

---

DP-005

Condition: vcType = '*LONG'

TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer to long integer type).

FALSE: Evaluation continues to the next condition.

---

DP-006

Condition: vcType = 'LONG'

TRUE: iRC is set to ORA_FFI.C_LONG (long integer type).

FALSE: Evaluation continues to the next condition.

---

DP-007

Condition: vcType = '*SHORT' OR vcType = '*BYTE'

TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer to short/byte type).

FALSE: Evaluation continues to the next condition.

---

DP-008

Condition: vcType = 'SHORT' OR vcType = 'BYTE'

TRUE: iRC is set to ORA_FFI.C_SHORT (short/byte type).

FALSE: Evaluation continues to the next condition.

---

DP-009

Condition: vcType = '*DOUBLE'

TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer to double type).

FALSE: Evaluation continues to the next condition.

---

DP-010

Condition: vcType = 'DOUBLE'

TRUE: iRC is set to ORA_FFI.C_DOUBLE (double type).

FALSE: Evaluation continues to the next condition.

---

DP-011

Condition: vcType = '*VOID'

TRUE: iRC is set to ORA_FFI.C_VOID_PTR (pointer to void type).

FALSE: No assignment is made; iRC remains NULL and is returned as NULL to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is converted to upper case before matching; the function therefore accepts type tokens in any case (e.g., 'int', 'Int', 'INT' are all treated identically).
- BR-002 - The tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-003 - Only the eleven recognised type tokens ('*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT', '*BYTE', 'SHORT', 'BYTE', '*DOUBLE', 'DOUBLE', '*VOID') are valid inputs; any unrecognised token results in a NULL return value, as no default or exception handling is defined.
- BR-004 - The function performs no database interaction and has no external dependencies; it operates solely as an in-memory lookup table mapping string type names to ORA_FFI integer constants.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-007 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function allows calling screens to present a dynamic confirmation message and branch their processing based on whether the user confirmed or dismissed the prompt.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text (confirm_msg) passed by the calling trigger.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert dialog to the user via SHOW_ALERT and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (confirmation), or 0 for any other button press (rejection/dismissal).

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert dialog)

TRUE: The function returns 1, indicating the user confirmed the action.

FALSE: The function returns 0, indicating the user did not confirm (pressed any other available button or dismissed the dialog).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert dialog used for confirmation must be the predefined Oracle Forms alert named AL_CONFIRM; no other alert object is used by this function.
- BR-002 - The confirmation message displayed to the user is fully determined by the confirm_msg input parameter, allowing the calling context (vr_bshop_group_prod_fmb WHEN-BUTTON-PRESSED trigger) to supply a context-specific message at runtime.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response yields a return value of 0, ensuring a binary confirmed/not-confirmed outcome for the caller.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-008 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Checks whether the most recent Oracle Forms operation succeeded and, if not, surfaces the appropriate error message to the user before halting further trigger processing. The procedure distinguishes between Oracle database errors (ORA) and Oracle Forms runtime errors (FRM), routing each to the correct error-text source before raising a form trigger failure to abort the calling KEY-COMMIT trigger.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in FORM_SUCCESS function to determine whether the preceding Forms operation completed without error.
- Step 2 - If FORM_SUCCESS returns FALSE, inspect the ERROR_TYPE built-in to classify the failure as either an Oracle database error ('ORA') or an Oracle Forms runtime error ('FRM').
- Step 3 - If ERROR_TYPE is 'ORA', call GENERAL.DISP_TEXT passing SQLERRM (the current Oracle database error message) and the severity label 'Error' to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM', call GENERAL.DISP_TEXT passing ERROR_TEXT (the Forms runtime error message) and the severity label 'Error' to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to halt execution of the KEY-COMMIT trigger and prevent the commit from proceeding.
- Step 6 - If FORM_SUCCESS returns TRUE, no action is taken and control returns normally to the caller.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (i.e., the preceding Forms operation did not succeed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No error has occurred; the procedure exits without action and the KEY-COMMIT trigger continues normally.

---

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated from an Oracle database error).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM and severity 'Error' to present the Oracle database error message to the user.

FALSE: Evaluate whether ERROR_TYPE = 'FRM' (see DP-003).

---

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated from an Oracle Forms runtime error).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT and severity 'Error' to present the Forms runtime error message to the user.

FALSE: No matching error type is identified; no message is displayed, but FORM_TRIGGER_FAILURE is still raised to abort the trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation initiated via the KEY-COMMIT trigger must not proceed if the preceding Forms operation did not succeed; FORM_TRIGGER_FAILURE is unconditionally raised whenever FORM_SUCCESS is FALSE.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported to the user using the database-level error message obtained from SQLERRM, ensuring the technical Oracle error detail is visible.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be reported to the user using the Forms-level error message obtained from ERROR_TEXT, preserving the Forms-specific error description.
- BR-004 - All error messages surfaced by this procedure must be classified with severity 'Error' when passed to GENERAL.DISP_TEXT, ensuring consistent error-level presentation across both error types.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-009 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- vr_bshop_group_prod_fmb.xml [Trigger: ON-MESSAGE]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a supplied message and title. The procedure selects the appropriate Oracle Forms alert object based on whether the title indicates an error condition, then presents the alert with the provided text. It is used both as a general notification mechanism and as an error-reporting utility invoked by CHECK_FORM_FAILURE and the ON-MESSAGE trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive two input parameters: the message body (text_string) and the dialog title (title_string).
- Step 2 - Evaluate whether the title_string value, converted to upper case, equals 'ERROR' to determine which alert object to use.
- Step 3 - Assign the alert name 'AL_ERRINFO' if the title indicates an error; otherwise assign 'AL_NOTE' for informational or other messages.
- Step 4 - Set the TITLE property of the selected alert object to the supplied title_string using SET_ALERT_PROPERTY.
- Step 5 - Set the ALERT_MESSAGE_TEXT property of the selected alert object to the supplied text_string using SET_ALERT_PROPERTY.
- Step 6 - Display the configured alert to the user by calling SHOW_ALERT, capturing the user's response in the local variable p_alert_id (response is not acted upon further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert object 'AL_ERRINFO' is selected, indicating that the message represents an error condition.

FALSE:
The alert object 'AL_NOTE' is selected, indicating that the message is informational or of a non-error nature.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title comparison is case-insensitive; any casing variant of the word 'ERROR' routes the display to the error alert object 'AL_ERRINFO'.
- BR-002 - All non-error titles (i.e., any title_string whose upper-case value is not 'ERROR') must use the informational alert object 'AL_NOTE'.
- BR-003 - The alert title and message text must always be set dynamically from the supplied parameters immediately before the alert is shown, ensuring the displayed content reflects the current call context.
- BR-004 - The user's acknowledgement response returned by SHOW_ALERT is captured but not evaluated; the procedure treats all alert interactions as simple acknowledgements with no branching on the response.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Calculates and returns the total windshield panel count for a specific repair order by summing the PANEL_WNSHLD values recorded in VT_VTS. The result is used by the bodyshop group production screen to determine the aggregate panel quantity associated with a given parent group, dealer map code, location, and repair order number.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the five input parameters: parent group code (p_pgroup), dealer map code (p_dealermap), location code (p_loc), company code (p_comp), and repair order number (p_ronum).
- Step 2 - Initialise the local numeric variable LV_PANEL to zero as a default return value.
- Step 3 - Query the VT_VTS table, filtering rows where PARENT_GROUP matches p_pgroup, DEALER_MAP_CD matches p_dealermap, LOC_CD matches p_loc, and RO_NUM matches p_ronum; aggregate the PANEL_WNSHLD column using SUM.
- Step 4 - Store the aggregated result into LV_PANEL.
- Step 5 - Apply NVL to LV_PANEL so that a NULL aggregate (i.e. no matching rows) is converted to zero.
- Step 6 - Return the final numeric value to the caller.

---
**Decision Points**

DP-001

Condition:
The SUM of PANEL_WNSHLD across all matching VT_VTS rows evaluates to NULL (no rows satisfy the WHERE clause filter on PARENT_GROUP, DEALER_MAP_CD, LOC_CD, and RO_NUM).

TRUE:
NVL converts the NULL result to 0, and the function returns 0 to the caller.

FALSE:
The actual numeric sum is returned directly to the caller.

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
**Business Rules**

- BR-001 - The windshield panel total must be derived exclusively from VT_VTS rows that match all four filter criteria simultaneously: parent group code, dealer map code, location code, and repair order number; partial matches are excluded.
- BR-002 - The function must always return a non-negative numeric value; a NULL aggregate resulting from no matching records is treated as zero, ensuring the caller never receives a NULL.
- BR-003 - The p_comp (company) parameter is accepted as part of the function signature but is not applied as a filter in the VT_VTS query; panel totals are therefore calculated across all companies for the given repair order context.
- BR-004 - The panel quantity returned represents the sum of windshield panels (PANEL_WNSHLD) only; other panel types stored in VT_VTS are not included in this calculation.

---
**Implementation Logic**

```plsql

  function sf_get_panel(p_pgroup    varchar2,
                        p_dealermap number,
                        p_loc       varchar2,
                        p_comp      varchar2,
                        p_ronum     varchar2) RETURN NUMBER IS

    LV_PANEL NUMBER := 0;

  BEGIN
    SELECT sum(panel_wnshld)
      into LV_PANEL
      FROM VT_VTS
     WHERE parent_group = p_pgroup
       and dealer_map_cd = p_dealermap
       and loc_cd = p_loc
       and ro_NUM = p_ronum;

    RETURN NVL(LV_PANEL, 0);
  END sf_get_panel;
```

#### SP-011 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Calculates the number of working days between two dates (inclusive) for a given production group, dealer map, and location. Each calendar day in the range is checked against the WD_BTN holiday/leave table; days that are not recorded as leave days are counted as working days. The function returns the total working-day count as a number.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_frm_dt | date | IN |
| p_to_dt | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Truncate both the from-date (p_frm_dt) and to-date (p_to_dt) to midnight to eliminate any time component, storing them as lv_start_dt and lv_end_dt respectively.
- Step 2 - Initialise the working-day counter (lv_day_cnt) and the holiday counter (LV_HOLIDAY_CNT) to zero.
- Step 3 - Enter a loop that iterates one calendar day at a time, beginning at lv_start_dt and terminating when lv_start_dt exceeds lv_end_dt (i.e., equals lv_end_dt + 1), thereby covering the date range inclusively.
- Step 4 - For each day in the loop, query WD_BTN to count rows where parent_group matches p_pgroup, dealer_map_cd matches p_dealermap, loc_cd matches p_loc, and LEAVE_DATE equals the current loop date (lv_start_dt). The result is stored in LV_HOLIDAY_CNT. If the query raises any exception, LV_HOLIDAY_CNT defaults to 0.
- Step 5 - Evaluate LV_HOLIDAY_CNT: if it equals 0 (no holiday/leave record found for that day), increment lv_day_cnt by 1; otherwise leave lv_day_cnt unchanged.
- Step 6 - Advance lv_start_dt by one day and repeat from Step 4.
- Step 7 - After the loop completes, return lv_day_cnt as the total number of working days in the specified range.

---
**Decision Points**

DP-001

Condition:
lv_start_dt = lv_end_dt + 1 (current loop date has passed the end date)

TRUE:
Exit the loop; no further days need to be evaluated.

FALSE:
Continue processing the current day - query WD_BTN and assess whether it is a working day.

---

DP-002

Condition:
LV_HOLIDAY_CNT = 0 (no leave/holiday record exists in WD_BTN for the current date, group, dealer map, and location)

TRUE:
The day is treated as a working day; increment lv_day_cnt by 1.

FALSE:
The day is treated as a non-working day (holiday/leave); lv_day_cnt is not incremented.

---

DP-003

Condition:
The SELECT COUNT(*) query against WD_BTN raises an exception

TRUE:
LV_HOLIDAY_CNT is set to 0 by the exception handler, causing the day to be counted as a working day.

FALSE:
LV_HOLIDAY_CNT retains the value returned by the query and is evaluated normally in DP-002.

---
**Database Interactions**

- DB-001 - Read WD_BTN - Reads data from WD_BTN for lookup or validation.
**Business Rules**

- BR-001 - The working-day range is inclusive of both the from-date and the to-date; the loop exits only when the current date exceeds the to-date.
- BR-002 - Date values are truncated to midnight before processing to ensure consistent day-level comparisons regardless of any time component passed by the caller.
- BR-003 - A day is classified as a non-working day only if a matching record exists in WD_BTN for the combination of parent_group, dealer_map_cd, loc_cd, and LEAVE_DATE; all other days are classified as working days.
- BR-004 - The holiday lookup is scoped to the specific production group (p_pgroup), dealer map (p_dealermap), and location (p_loc), ensuring that leave calendars are applied per organisational unit rather than globally.
- BR-005 - Any database exception raised during the WD_BTN lookup is silently suppressed and treated as no holiday record found (LV_HOLIDAY_CNT = 0), preserving the working-day count for that date.

---
**Implementation Logic**

```plsql

  function sf_get_working_day_cnt(p_pgroup    varchar2,
                                  p_dealermap number,
                                  p_loc       varchar2,
                                  p_frm_dt    date,
                                  p_to_dt     date) RETURN NUMBER IS
    lv_start_dt    date;
    lv_end_dt      date;
    lv_day_cnt     number := 0;
    LV_HOLIDAY_CNT number := 0;
  begin
    begin
      lv_start_dt := trunc(p_frm_dt);
      lv_end_dt   := trunc(p_to_dt);
      LOOP
        exit when lv_start_dt = lv_end_dt + 1;
        begin
          SELECT COUNT(*)
            INTO LV_HOLIDAY_CNT
            FROM WD_BTN
           where parent_group = p_pgroup
             and dealer_map_cd = p_dealermap
             and loc_cd = p_loc
             and LEAVE_DATE = lv_start_dt;
        exception
          when others then
            LV_HOLIDAY_CNT := 0;
        end;
        if LV_HOLIDAY_CNT = 0 then
          lv_day_cnt := lv_day_cnt + 1;
        end if;
        lv_start_dt := lv_start_dt + 1;
      END LOOP;
    end;
    return lv_day_cnt;
  end sf_get_working_day_cnt;
```

#### SP-012 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before continuing. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-020](#SP-020--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing the cmd parameter and the BLOCKING_MODE constant to request synchronous (blocking) execution.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, allowing the caller to reference or track the completed process.

---
**Decision Points**

No conditional decision points exist within this function. All branching and execution-mode handling is delegated entirely to WEBUTIL.EXECUTE; WEBUTIL.BLOCKING unconditionally passes BLOCKING_MODE on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always invoke WEBUTIL.EXECUTE with BLOCKING_MODE; non-blocking or asynchronous execution is not permitted through this entry point.
- BR-002 - The cmd parameter must be supplied by the caller; the function applies no default value or null-guard, so the caller is responsible for providing a valid, non-null command string.
- BR-003 - The return value is the PROCESS_ID yielded by WEBUTIL.EXECUTE; the caller must capture this value if process identification or status tracking is required after the blocking call completes.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-013 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library declared in the property bundle for the package, the procedure compares the installed version recorded in the client settings against the expected version. Where a library is absent, outdated, or a forced re-download flag is active, the procedure downloads the library from the configured URL to the client system library location and records the new version in the client settings. Any download failure is written to the WebUtil log.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-017](#SP-017--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-047](#SP-047--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) that identifies which set of system libraries must be checked.
- Step 2 - Enter a loop and, on each iteration, read a library specification entry from the property bundle using the composite key 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>'. If no entry is found for the OS-architecture-specific key, retry with the OS-family-only key 'install.syslib.<OSFamily>.<packageID>.<index>'.
- Step 3 - If no library specification is found for the current index, exit the loop; all libraries for the package have been processed.
- Step 4 - Parse the library specification string (pipe-delimited) to extract: library file name (field 1), expected file size (field 2), expected version string (field 3), and a progress-display flag indicating whether a progress indicator should be shown during download (field 4).
- Step 5 - Query the client settings store via WEBUTIL.GETCLIENTSETTING using the key 'syslib.<libName>' to retrieve the currently installed version of the library.
- Step 6 - Evaluate whether a download is required: if the installed version is null, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 7 - If a download is required, resolve the download base URL from the property bundle using the most specific available key: first 'install.syslib.location.<OSFamily>.<OSArch>', then 'install.syslib.location.<OSFamily>', then 'install.syslib.location'.
- Step 8 - Invoke WEBUTIL.DOWNLOADFROMURLINT to download the library file from the resolved URL appended with the library file name, targeting the system library install location (location type 1), using the expected file size, the progress flag, and localised progress dialog titles retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 9 - If the download succeeds, record the new version in the client settings store via WEBUTIL.SETCLIENTSETTING using the key 'syslib.<libName>'.
- Step 10 - If the download fails, write a failure message to the WebUtil log via WEBUTIL.LOG, marking it as an error, and continue processing any remaining libraries.
- Step 11 - Increment the library index and return to Step 2 to process the next library in the package.

---
**Decision Points**

DP-001

Condition: A library specification exists in the property bundle for the OS-architecture-specific key 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>'.

TRUE: Use this specification for the current library entry.

FALSE: Attempt to read the specification using the OS-family-only fallback key 'install.syslib.<OSFamily>.<packageID>.<index>'.

---

DP-002

Condition: The library specification resolved from the property bundle (after both key attempts) is null.

TRUE: Exit the loop; no further libraries exist for this package.

FALSE: Parse the specification and continue processing the library.

---

DP-003

Condition: The installed version retrieved from the client settings is null, does not match the expected version defined in the property bundle, or the REDOWNLOAD_SYSLIB flag is active.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is current; skip download and advance to the next library.

---

DP-004

Condition: A download URL exists in the property bundle for the OS-architecture-specific key 'install.syslib.location.<OSFamily>.<OSArch>'.

TRUE: Use this URL as the base download location.

FALSE: Attempt the OS-family-only key 'install.syslib.location.<OSFamily>'.

---

DP-005

Condition: A download URL exists in the property bundle for the OS-family-only key 'install.syslib.location.<OSFamily>'.

TRUE: Use this URL as the base download location.

FALSE: Fall back to the generic key 'install.syslib.location'.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the expected version string against the library name in the client settings via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a download failure message via WEBUTIL.LOG and continue to the next library without updating client settings.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are stored in the property bundle and must be keyed by OS family, OS architecture, package identifier, and a sequential integer index; the procedure reads entries until no specification is found for the current index.
- BR-002 - A more specific OS-architecture key takes precedence over an OS-family-only key when resolving a library specification; the OS-family key is only consulted if the architecture-specific key returns no value.
- BR-003 - A library specification entry must be pipe-delimited and contain at minimum: library file name (field 1), expected file size in bytes (field 2), expected version string (field 3), and a boolean progress-display indicator (field 4).
- BR-004 - A library is considered current only when the version string recorded in the client settings exactly matches the version string declared in the property bundle; any mismatch, absence of a recorded version, or activation of the REDOWNLOAD_SYSLIB flag mandates a fresh download.
- BR-005 - The download base URL is resolved with a three-level fallback: OS-family plus architecture specific, OS-family only, then generic; the most specific available URL is used.
- BR-006 - Downloaded system libraries are installed to the designated system library location (location type 1 as passed to WEBUTIL.DOWNLOADFROMURLINT); the full download path is formed by appending the library file name to the resolved base URL.
- BR-007 - Progress dialog titles displayed during download must be retrieved from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localised text is presented to the user.
- BR-008 - The client settings store is updated with the new version string only upon confirmed successful download; a failed download must not update the stored version, and the failure must be logged as an error via WEBUTIL.LOG.
- BR-009 - Processing continues for all remaining libraries in the package even if a download fails for one library; the procedure does not abort on a single failure.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-014 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the provided integer key. This procedure ensures that stale or consumed callback registrations are cleaned up, preventing unintended re-execution of callback triggers within the WebUtil processing context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) identifying the target callback entry in the internal m_callbacks collection.
- Step 2 - Check whether an entry for the supplied callbackKey currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection, effectively deregistering the callback trigger.
- Step 4 - If the entry does not exist, take no action and exit silently.

---
**Decision Points**

DP-001

Condition: The m_callbacks collection contains an entry for the supplied callbackKey (m_callbacks.exists(callbackKey) evaluates to TRUE).

TRUE: The entry is deleted from the m_callbacks collection via m_callbacks.delete(callbackKey), removing the callback registration.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A callback entry is only deleted if it currently exists in the m_callbacks collection; the procedure must not raise an error when the specified key is absent.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to a valid index within the m_callbacks collection; no type coercion or default substitution is applied.
- BR-003 - Deletion is performed on a single, specific entry identified by callbackKey; no bulk or cascading removal of other collection entries is permitted.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-015 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, releasing any server-side resources associated with the BLOB session referenced by the supplied checksum.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must identify a previously opened BLOB handle; the validity and existence of that handle are enforced by WebUtil_DB.CloseBlob.
- BR-002 - The outcome of the close operation (success or failure) is communicated exclusively through the BOOLEAN return value; no exceptions are raised at this layer.
- BR-003 - This function acts solely as a pass-through wrapper; no additional processing, logging, or state changes are performed beyond invoking WebUtil_DB.CloseBlob.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-016 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file handle represented by the supplied Java object. The procedure delegates the close operation to the native Java class oracle/forms/webutil/fileTransfer/AppServerFileReader by invoking its closeFile method via the JNI bridge, ensuring that file resources held on the application server are properly released after a file transfer or read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents the currently open AppServerFileReader file handle on the application server.
- Step 2 - Reset the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the closeFile method on the AppServerFileReader Java class through JNI.CALL_BOOLEAN_METHOD, passing the object reference and an empty argument signature '()Z'.
- Step 4 - Return the Boolean result produced by the Java closeFile method to the caller (WEBUTIL.SETDATA), indicating whether the file was closed successfully.

---
**Decision Points**

DP-001

Condition: The JNI.CALL_BOOLEAN_METHOD call to oracle/forms/webutil/fileTransfer/AppServerFileReader.closeFile returns TRUE or FALSE.

TRUE: The file handle on the application server was closed successfully; the Boolean value TRUE is returned to the invoking routine WEBUTIL.SETDATA.

FALSE: The file handle could not be closed; the Boolean value FALSE is returned to the invoking routine WEBUTIL.SETDATA, signalling that the close operation did not complete as expected.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list (args) must be cleared to NULL before every invocation of the Java closeFile method to prevent residual arguments from corrupting the method call.
- BR-002 - The file close operation must be executed against the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class using the exact method signature '()Z'; any deviation will cause the JNI call to fail.
- BR-003 - The function must propagate the Boolean return value from the Java layer back to the caller without modification, as that value is the sole indicator of whether the server-side file resource was successfully released.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-017 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a specified URL to a client-side destination by constructing a delimited parameter string and delegating the transfer request to the WebUtil Core bean. The function returns TRUE if the download completes successfully and FALSE if a recoverable error occurs, raising FORM_TRIGGER_FAILURE for unrecoverable bean-level failures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its character representation. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its character representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to the submit string, each separated by the pipe delimiter.
- Step 7 - Submit the fully assembled parameter string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the WUC_PACKAGE context and the WUC_URL_DOWNLOAD property key.
- Step 8 - Retrieve the result from the bean by calling WebUtil_Core.getProperty with the same context and property key.
- Step 9 - Return TRUE if the retrieved result equals the string 'TRUE'; otherwise return FALSE.
- Step 10 - On CLIENT_FILE_NULL exception, log error code 130 via WebUtil_Core.Error and return FALSE.
- Step 11 - On URL_NULL exception, log error code 25 via WebUtil_Core.Error and return FALSE.
- Step 12 - On BEAN_NOT_REGISTERED exception, display an alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE.
- Step 13 - On PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception, which is caught in the exception block, logs error code 25, and returns FALSE.

FALSE: Continue to clientDestination validation.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception, which is caught in the exception block, logs error code 130, and returns FALSE.

FALSE: Continue to submit string construction.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append the literal '0' as the specialDestination segment of the submit string.

FALSE: Append the character representation of the supplied specialDestination value.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append the literal '0' as the fileSize segment of the submit string.

FALSE: Append the character representation of the supplied fileSize value.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' as the progress-indicator segment of the submit string.

FALSE: Append 'Y', enabling progress display during the download.

---

DP-006

Condition: Result returned by WebUtil_Core.getProperty equals the string 'TRUE'

TRUE: Function returns TRUE, indicating the download completed successfully.

FALSE: Function returns FALSE, indicating the download did not complete successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is an invalid input and causes the function to return FALSE after logging error code 25.
- BR-002 - A client destination path must be provided; a null clientDestination is an invalid input and causes the function to return FALSE after logging error code 130.
- BR-003 - The specialDestination parameter must be an integer in the range 0-2 inclusive; any null, negative, or out-of-range value is silently normalised to 0.
- BR-004 - The fileSize parameter must be a non-null integer; a null value is silently normalised to 0.
- BR-005 - Optional progress display parameters (progressTitle, progressSubTitle, progressMessage) that are null are substituted with a single space to preserve the fixed-position pipe-delimited format required by the WebUtil Core bean.
- BR-006 - The pipe character ('|') is used exclusively as the field delimiter within the submit string; all parameter values are concatenated in a fixed positional order.
- BR-007 - If the WebUtil Core bean is not registered, the function must not return silently; it raises FORM_TRIGGER_FAILURE after displaying an alert identifying the missing bean class.
- BR-008 - A PROPERTY_ERROR from the WebUtil Core bean is treated as an unrecoverable condition and raises FORM_TRIGGER_FAILURE without returning a boolean result.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-018 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program-unit name, and up to three optional argument values, then writes that string to the WUC_ERROR_MSG property of the identified WebUtil package instance via Webutil_Core.setProperty. This centralises error reporting for WebUtil operations so that the calling context (WEBUTIL_CORE.CUSTOMEVENTHANDLER) can inspect or propagate a consistently formatted error payload.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text by concatenating the literal prefix 'ERROR', the error code zero-padded to three digits, a pipe delimiter, and the program-unit name (pu_name) to form the base message string.
- Step 2 - Evaluate whether arg1 is not null; if so, append a pipe delimiter followed by the value of arg1 to the error text.
- Step 3 - Evaluate whether arg2 is not null; if so, append a pipe delimiter followed by the value of arg2 to the error text.
- Step 4 - Evaluate whether arg3 is not null; if so, append a pipe delimiter followed by the value of arg3 to the error text.
- Step 5 - Call Webutil_Core.setProperty, passing the packageID, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to store the error message against the target WebUtil package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; no change is made.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; no change is made.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; no change is made.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error code must be formatted as a zero-padded three-digit integer (e.g., code 5 becomes '005') when embedded in the error message, ensuring a fixed-width, parseable code segment.
- BR-002 - The error message string must follow the pipe-delimited format 'ERROR<code>|<pu_name>[|<arg1>][|<arg2>][|<arg3>]'; each optional argument is included only when its value is not null.
- BR-003 - The assembled error message must be stored against the property key 'WUC_ERROR_MSG' on the WebUtil package instance identified by packageID; no other storage mechanism is used.
- BR-004 - Optional arguments arg1, arg2, and arg3 default to null; their inclusion in the message is conditional, meaning callers may supply between zero and three supplementary arguments without altering the mandatory message structure.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-019 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user via a pre-registered Forms alert dialog. The procedure is a centralised error-notification utility called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE whenever a bean-not-registered or bean-not-found condition must be communicated. If the alert object is unavailable, the message is surfaced through the standard Forms MESSAGE built-in instead.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error text string (errText) describing the WebUtil error condition to be displayed.
- Step 2 - Call WEBUTIL.ID_NULL (SP-037) to test whether the module-level alert handle m_errorAlert refers to a valid, registered Forms alert object.
- Step 3 - If the alert handle is valid, set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded, as the button choice is not relevant to processing.
- Step 5 - If the alert handle is not valid (ID_NULL returns TRUE), fall back to the Forms MESSAGE built-in, concatenating the literal prefix 'WebUtil Error: ' with errText to inform the user.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert is not null and refers to a valid registered Forms alert object.

TRUE:
Set the alert's ALERT_MESSAGE_TEXT property to errText and display the alert via SHOW_ALERT; the user sees a modal alert dialog titled 'WebUtil Error'.

FALSE:
Bypass the alert mechanism and issue a Forms MESSAGE call with the text 'WebUtil Error: ' concatenated with errText, surfacing the error through the standard Forms status-line or message dialog.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is the sole centralised channel for surfacing WebUtil bean-related errors (bean not registered, bean not found); callers must not implement their own error display for these conditions.
- BR-002 - The alert title is not modified at runtime; it must already be set to 'WebUtil Error' in the alert's design-time property to ensure consistent presentation.
- BR-003 - The return value of SHOW_ALERT is deliberately ignored; the user's button selection on the error alert has no effect on subsequent processing.
- BR-004 - When the alert handle m_errorAlert is invalid or unregistered, the procedure must still deliver the error message to the user via the Forms MESSAGE built-in, ensuring no error condition is silently swallowed.
- BR-005 - Validity of the alert handle is determined exclusively by WEBUTIL.ID_NULL (SP-037); no other null-check mechanism is used.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-020 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell or system command for execution on the client machine via the WebUtil host utility bean. The procedure sets the desired execution mode and the command string as properties on the WebUtil host package bean, then retrieves the resulting process handle, returning it as a PROCESS_ID. If the required WebUtil bean is not registered on the client, an error alert is raised and no process is launched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input parameters.
- Step 2 - Evaluate whether cmd is non-null; if cmd is null the function performs no action and returns an uninitialised PROCESS_ID.
- Step 3 - Set the execution mode on the WebUtil host package bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Submit the command for execution by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the client-side bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE and convert the returned string value to a number, storing it in procId.handle.
- Step 6 - Return the populated PROCESS_ID record to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and halt execution without returning a valid process handle.

---
**Decision Points**

DP-001

Condition: cmd IS NOT NULL

TRUE: Set the execution mode property, submit the command to the WebUtil host bean, retrieve and store the resulting process handle in procId.handle, then return procId.

FALSE: Skip all bean interactions and return an uninitialised PROCESS_ID to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property set or get operations.

TRUE: Display an error alert containing the implementation class name of the WebUtil host package, indicating that WEBUTIL_HOST.Execute will not function, and terminate the procedure without returning a process handle.

FALSE: No exception occurs; normal processing continues and a valid PROCESS_ID is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A command string (cmd) must be non-null for any client-side execution to be attempted; a null cmd results in no action and an empty PROCESS_ID being returned.
- BR-002 - The execution mode (exemode) must be supplied and is applied to the WebUtil host bean before the command is dispatched; the bean uses this value to determine how the process is launched on the client.
- BR-003 - The WebUtil host utility bean (WUH_PACKAGE) must be registered and available on the client; if it is not registered, execution is blocked and the user is notified via an error alert referencing the missing implementation class.
- BR-004 - The process handle returned by the bean is stored as a numeric value within the PROCESS_ID record; the raw string response from WebUtil_Core.getProperty is explicitly converted to a number before assignment.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-021 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened through the WebUtil file I/O framework. The procedure nullifies the file handle after issuing the close command to the WebUtil bean, and raises a terminal error if the required bean is unavailable or if the close operation itself fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-026](#SP-026--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type IN OUT parameter) passed by the calling routine (VIEW_EXCEL_REP).
- Step 2 - Check whether the file handle is currently open by testing file.handle IS NOT NULL.
- Step 3 - If the handle is not null, invoke WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_CLOSE command to instruct the WebUtil bean to close the physical file on the client.
- Step 4 - After a successful close, set file.handle to NULL to mark the file object as closed and prevent reuse of a stale handle.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that includes the implementation class name retrieved by WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass), then raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a property-level error occurs during the close operation (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR immediately to abort processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Issue the WUF_TEXTIO_CLOSE command via WebUtil_Core.setProperty to close the physical client-side file, then set file.handle to NULL.

FALSE:
Skip the close operation entirely; no action is taken and no error is raised.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close attempt

TRUE:
Call WEBUTIL.ERRORALERT to present a user-facing message that includes the bean implementation class name (obtained from WEBUTIL.GETIMPLCLASS), then raise TOOL_ERR.TOOL_ERROR to terminate execution.

FALSE:
Exception does not occur; normal processing continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the close attempt

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to terminate execution; no user-facing alert is displayed.

FALSE:
Exception does not occur; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is non-null; a null handle is silently treated as already closed, preventing errors on redundant close calls.
- BR-002 - Once the WebUtil bean successfully closes the file, the handle must be set to NULL immediately to ensure the file object cannot be reused in a partially open state.
- BR-003 - If the WebUtil bean required for client-side file I/O is not registered, the procedure must surface a meaningful error message to the user via WEBUTIL.ERRORALERT, incorporating the expected implementation class name retrieved by WEBUTIL.GETIMPLCLASS, before terminating.
- BR-004 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions are treated as fatal; in both cases TOOL_ERR.TOOL_ERROR is raised to ensure the calling routine (VIEW_EXCEL_REP) is notified of the failure and does not continue with an invalid file state.
- BR-005 - No direct database interactions are performed; all file operations are delegated exclusively to the WebUtil client-side bean via the WebUtil_Core framework.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-022 - WEBUTIL.FOPEN

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text I/O by delegating to the WebUtil Java bean layer. The function validates the requested file path and access mode, communicates the open request to the client-side bean via WEBUTIL.GETPROPERTY (through WebUtil_Core), and returns a file handle that the calling routine (VIEW_EXCEL_REP) can use for subsequent read, write, or append operations on the client file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-032](#SP-032--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append); raise TOOL_ERROR if not.
- Step 2 - Validate the file specification: confirm that the `spec` parameter is neither NULL nor an empty string; raise TOOL_ERROR if either condition is true.
- Step 3 - Transmit the file path to the client bean by calling WebUtil_Core.setProperty with property key WUF_FILENAME and the value of `spec`.
- Step 4 - Transmit the file mode to the client bean by calling WebUtil_Core.setProperty with property key WUF_TEXTIO_FILEMODE and the value of `filemode`.
- Step 5 - Transmit the character set to the client bean: if `charSet` is NULL, set property WUF_TEXTIO_CHARSET to the literal string '(null)'; otherwise set it to the supplied `charSet` value.
- Step 6 - Request the client bean to open the file by invoking WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) with property key WUF_TEXTIO_OPEN; the bean attempts the file open and returns a Java handle string.
- Step 7 - Validate the returned handle: if the handle is NULL, empty, or equal to '-1', the file was not successfully opened; raise TOOL_ERROR.
- Step 8 - Convert the valid handle string to a numeric value, assign it to the `handle` field of the local `file_type` record, and return that record to the caller as the open file reference.

---
**Decision Points**

DP-001

Condition:
The `filemode` parameter (converted to lower case) is NOT one of the values 'r', 'w', or 'a'.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately; processing stops and no file open attempt is made.

FALSE:
Proceed to validate the file specification (DP-002).

---

DP-002

Condition:
The `spec` parameter is NULL or is an empty string.

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately; processing stops and no file open attempt is made.

FALSE:
Proceed to transmit file path, mode, and character set to the client bean.

---

DP-003

Condition:
The `charSet` parameter is NULL.

TRUE:
Set the WUF_TEXTIO_CHARSET property to the literal string '(null)' to signal the bean that no explicit character set was requested.

FALSE:
Set the WUF_TEXTIO_CHARSET property to the caller-supplied `charSet` value.

---

DP-004

Condition:
The Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is NULL, an empty string, or the sentinel value '-1'.

TRUE:
The client-side file open failed; raise TOOL_ERR.TOOL_ERROR.

FALSE:
Convert the handle to a number, populate the `file_type` record, and return it to the caller.

---

DP-005

Condition:
A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during processing.

TRUE:
Display an error alert identifying the missing bean class, then raise TOOL_ERR.TOOL_ERROR and return NULL; CLIENT_TEXT_IO.fopen will not function without the registered bean.

FALSE:
Not applicable (exception not raised); normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file access mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively; any other value is rejected before any client interaction occurs.
- BR-002 - A non-null, non-empty file path specification must be provided; attempting to open a file without a path is a hard error.
- BR-003 - The character set parameter is optional; when omitted (NULL), the bean is explicitly instructed via the literal '(null)' to apply its default character set rather than leaving the property unset.
- BR-004 - The client-side file open is performed exclusively through the WebUtil Java bean via WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty); the function has no direct file-system access of its own.
- BR-005 - A handle value of NULL, empty string, or '-1' returned by the bean is treated as a failed open and must not be converted or returned to the caller.
- BR-006 - The WebUtil bean (WUF_PACKAGE) must be registered in the client runtime environment; if it is not, a descriptive alert is raised and the function terminates with TOOL_ERROR rather than silently failing.
- BR-007 - A VALUE_ERROR during numeric conversion of the Java handle (e.g., non-numeric handle string) is escalated as TOOL_ERR.TOOL_ERROR, ensuring the caller always receives a typed error rather than an unhandled Oracle exception.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-023 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the callback trigger name associated with a given numeric key from the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback reference, enabling the WebUtil framework to dispatch the correct trigger during data callback processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer callback key (callbackKey) supplied by the calling routine.
- Step 2 - Use callbackKey as an index into the package-level associative array m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup with no branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey value must correspond to a valid, pre-existing entry in the m_callbacks collection; supplying an unregistered key will raise a NO_DATA_FOUND or subscript error at runtime.
- BR-002 - The function returns the trigger name exactly as stored in m_callbacks, without transformation or validation of the returned value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-024 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the pre-populated module-level variable m_clientOSFamily, allowing calling code (such as WEBUTIL.GETVAR) to retrieve the client OS family classification without performing any additional computation or database access.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires the client OS family identifier.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-determined OS family value for the current client session.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller with no transformation or validation.

---
**Decision Points**

No decision points exist in this function. The implementation unconditionally returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the value of m_clientOSFamily as-is; no default, override, or fallback value is applied within this function.
- BR-002 - The client OS family value must have been set in m_clientOSFamily prior to invocation; this function is a read-only accessor and does not initialise or modify the variable.
- BR-003 - The return type is PLS_INTEGER, meaning the OS family is represented as a numeric classifier; callers are responsible for interpreting the numeric value against the defined OS family constants.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-025 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set a request on the WUC_PACKAGE bean and immediately reads back the resolved value, returning it to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate local client settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input property name (propertyName) from the calling routine.
- Step 2 - Evaluate whether propertyName is non-null; if null, skip all processing and return a null result.
- Step 3 - Call WebUtil_Core.setProperty targeting the WUC_PACKAGE bean with the key WUC_GET_LOCAL_PROPERTY and the supplied property name, instructing the bean to resolve the requested client setting.
- Step 4 - Call WebUtil_Core.getProperty targeting the same WUC_PACKAGE bean and key WUC_GET_LOCAL_PROPERTY to retrieve the resolved value, storing it in the local variable result.
- Step 5 - Return result (the retrieved client setting value) to the caller.
- Step 6 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean interaction, display an error alert identifying the unregistered implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a WebUtil_Core.PROPERTY_ERROR exception is raised, raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to set the property on the WebUtil_Core WUC_PACKAGE bean and retrieve the resolved client setting value.

FALSE: Skip bean interaction entirely and return NULL to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean interaction

TRUE: Display an error alert identifying the missing implementation class (obtained via WebUtil_Core.getImplClass for WUC_PACKAGE) and raise FORM_TRIGGER_FAILURE.

FALSE: Continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during bean interaction

TRUE: Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any bean interaction; the function must return NULL immediately without calling WebUtil_Core set or get operations.
- BR-002 - The client setting must be retrieved exclusively through the WebUtil_Core WUC_PACKAGE bean using the designated key WUC_GET_LOCAL_PROPERTY; no direct data source access is performed.
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, the function must surface a descriptive error alert naming the unregistered implementation class and must terminate form processing via FORM_TRIGGER_FAILURE.
- BR-004 - If a property error occurs during bean interaction, form processing must be halted immediately via FORM_TRIGGER_FAILURE; no partial or default value may be returned.
- BR-005 - The returned property value must not exceed 255 characters, as enforced by the result variable declaration.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-026 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class suffix for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Retrieve the implementation class suffix from the internal collection m_implClasses using packageID as the index key.
- Step 3 - Prepend the constant WEBUTIL_JAVA_ROOT to the retrieved class suffix to form the fully qualified Java class name.
- Step 4 - Return the concatenated fully qualified class name to the caller (WEBUTIL.FCLOSE).

---
**Decision Points**

No conditional decision points exist in this function. The function unconditionally concatenates WEBUTIL_JAVA_ROOT with the m_implClasses entry at the given index and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid, pre-populated index in the m_implClasses collection; no bounds or existence check is performed, so an invalid packageID will raise a runtime error.
- BR-002 - The fully qualified Java class name is always constructed by prepending the WEBUTIL_JAVA_ROOT constant to the implementation class suffix; neither component may be substituted or overridden at call time.
- BR-003 - This function produces no side effects and performs no database interactions; it is a pure lookup-and-concatenation operation.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-027 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function delegates to the underlying JNI layer to invoke the native Java method getLastError on the supplied object instance, returning an integer error code that the caller (WEBUTIL.SETDATA) can inspect to determine whether the most recent file-transfer operation completed successfully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) passed in by the caller.
- Step 2 - Reset the JNI argument list by setting args to NULL, ensuring no stale arguments are forwarded to the Java method.
- Step 3 - Invoke the Java instance method getLastError on the supplied obj via JNI.CALL_INT_METHOD, targeting the class oracle/forms/webutil/fileTransfer/AppServerFileReader with method signature ()I (no parameters, integer return).
- Step 4 - Return the integer error code produced by the Java method to the caller.

---
**Decision Points**

No conditional decision points exist within this function. The function unconditionally resets the argument list and invokes the Java method, returning whatever integer value the JNI call yields.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly set to NULL before the JNI call to prevent any previously populated arguments from being passed to the Java method.
- BR-002 - The function must target the exact Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and method signature ()I; any deviation would result in an incorrect or failed JNI invocation.
- BR-003 - The function returns a NUMBER representing the last error code; a return value of zero conventionally indicates no error, while a non-zero value signals a file-transfer error condition for the caller to handle.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-028 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying Java Native Interface layer to obtain the error argument details from the active WebUtil file-transfer object, returning the result as a VARCHAR2 value for use by the calling routine (WEBUTIL.SETDATA).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents the active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data influences the outgoing JNI call.
- Step 3 - Invoke the Java method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing FALSE (non-static call), the object reference, the fully qualified class name, the method name, the method signature returning a Java String, and the cleared args value.
- Step 4 - Return the VARCHAR2 string result produced by the JNI call to the caller, representing the error argument details from the last error recorded by AppServerFileReader.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI method call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call is made, ensuring that no previously accumulated argument data is inadvertently forwarded to the Java method.
- BR-002 - The Java method must be invoked as an instance (non-static) method on the supplied obj reference; the FALSE flag passed to JNI.CALL_STRING_METHOD enforces this constraint.
- BR-003 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader and the target method signature is ()Ljava/lang/String;; these values are hard-coded and must not be altered, as they directly identify the error-argument accessor on the AppServerFileReader contract.
- BR-004 - The function returns the raw string value supplied by the JNI layer without transformation; any interpretation or handling of the error argument content is the responsibility of the invoking routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-029 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and returns its value as a NUMBER. The procedure delegates string extraction to WEBUTIL.GETSTRING and applies a TO_NUMBER conversion to the result, providing callers with a type-safe numeric value without requiring them to perform explicit conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-033](#SP-033--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-033), which locates and extracts the raw VARCHAR2 value at the specified field position within the delimited source string.
- Step 3 - Apply Oracle's TO_NUMBER function to the VARCHAR2 value returned by WEBUTIL.GETSTRING, converting it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

- DP-001

  Condition: The UnTerminated parameter is passed as TRUE.

  TRUE: WEBUTIL.GETSTRING treats the field at Field_position as the last field in the string even if no trailing delimiter is present, extracting the remainder of the source string as the field value.

  FALSE: WEBUTIL.GETSTRING applies standard delimited parsing, expecting the field to be bounded by delimiter characters on both sides (or by the string boundary on the right for the final field when a trailing delimiter exists).

- DP-002

  Condition: The Delimiter parameter is explicitly supplied by the caller.

  TRUE: WEBUTIL.GETSTRING uses the caller-supplied character as the field separator when parsing Source_string.

  FALSE: WEBUTIL.GETSTRING uses the default delimiter (comma) to parse Source_string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The source string must contain a parseable numeric value at the specified field position; if the extracted string is non-numeric, Oracle's TO_NUMBER will raise a VALUE_ERROR, and the calling context is responsible for handling this exception.
- BR-002 - Field position is 1-based and must correspond to a valid position within the delimited source string; positional resolution is fully delegated to WEBUTIL.GETSTRING (SP-033).
- BR-003 - The delimiter defaults to a comma if not supplied; callers using a non-comma separator must explicitly provide the Delimiter argument.
- BR-004 - The UnTerminated flag defaults to FALSE; callers must explicitly set it to TRUE only when the target field occupies the final position in a string that lacks a trailing delimiter.
- BR-005 - This function performs no database interactions; all processing is in-memory string manipulation followed by type conversion.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-030 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string. The function maps the raw OS name to a predefined platform constant (WIN32, MAC, LINUX, SOLARIS, HP, AIX, or UNKNOWN) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluating the string. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for WebUtil bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all classification logic and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily is null, evaluate l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not found, evaluate l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not found, evaluate l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not found, evaluate l_osName for the substrings 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris variant was found, evaluate l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not found, evaluate l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, persisting it as the session-level cache.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name classification (Steps 4-10) to determine and cache the platform constant.

FALSE: Skip classification entirely and return the already-cached m_clientOSFamily value.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to evaluate the next OS family candidate (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to evaluate the next OS family candidate (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to evaluate the next OS family candidate (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to evaluate the next OS family candidate (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to evaluate the next OS family candidate (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no further classification is attempted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is always performed case-insensitively; the input string is converted to lowercase before any substring evaluation, ensuring that OS name variants with mixed casing are correctly classified.
- BR-002 - Platform classification follows a strict priority order: Windows is evaluated first, followed by Mac, Linux, Solaris/SunOS, HP-UX, and AIX; the first matching condition wins and subsequent checks are skipped.
- BR-003 - Solaris is identified by either the substring 'solaris' or 'sunos', making it the only platform that maps from two distinct OS name patterns.
- BR-004 - If the supplied OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default classification.
- BR-005 - The resolved platform value is cached in the module-level variable m_clientOSFamily after the first successful evaluation; all subsequent calls within the same session return the cached value without re-processing the OS name string, regardless of the osName argument passed.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-031 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a given process handle and output property by iteratively polling the WebUtil client-side bean via WebUtil_Core. The function accumulates each returned line into an OUTPUT_ARRAY and returns the complete array to the caller (WEBUTIL.GET_STANDARD_OUTPUT). It also ensures WebUtil_Core is initialised before execution begins.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-038](#SP-038--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise local variables: an empty OUTPUT_ARRAY (lines), a loop counter (i = 1), a VARCHAR2 buffer for raw bean responses, and a status flag defaulted to 'X' (empty).
- Step 2 - Set the process handle on the WebUtil client-side bean by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the incoming process parameter.
- Step 3 - Enter a polling loop: call WebUtil_Core.getProperty with the WUH_PACKAGE constant and the caller-supplied prop parameter to retrieve the next buffered output line.
- Step 4 - Extract the first character of the returned buffer as the status indicator ('Y' = more lines to follow, 'N' = last line, 'X' = buffer empty).
- Step 5 - If status is not 'X', strip the leading status character from the buffer and store the remaining text as the next element in the lines array, then increment the counter.
- Step 6 - Exit the loop when status is not 'Y' (i.e., the last line 'N' has been processed or the buffer was empty 'X').
- Step 7 - Return the populated OUTPUT_ARRAY to the caller.
- Step 8 - On exception WebUtil_Core.BEAN_NOT_REGISTERED, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function; no array is returned in this path.
- Step 9 - The package initialisation block calls Webutil_Core.Init to ensure the WebUtil core component is instantiated before any function in the package executes.

---
**Decision Points**

DP-001

Condition: Status character extracted from the buffer equals 'X' (buffer was empty).

TRUE: The current buffer value is discarded; no entry is added to the lines array and the loop exit condition is evaluated.

FALSE: The remainder of the buffer (characters 2 onward) is appended to the lines array and the counter is incremented.

---

DP-002

Condition: Status character equals 'Y' (more output lines remain on the bean).

TRUE: The loop continues and WebUtil_Core.getProperty is called again to retrieve the next line.

FALSE: The loop exits (status is either 'N' - last line retrieved - or 'X' - empty buffer), and the accumulated lines array is returned.

---

DP-003

Condition: Exception WebUtil_Core.BEAN_NOT_REGISTERED is raised during bean interaction.

TRUE: An error alert is displayed to the user identifying the unregistered bean class; function execution terminates without returning an array.

FALSE: Normal processing continues through the polling loop and the array is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be set on the WebUtil bean (via WebUtil_Core.setProperty) before any output lines are retrieved; the handle is sourced exclusively from the incoming PROCESS_ID parameter.
- BR-002 - Output lines are retrieved one at a time in sequence; each call to WebUtil_Core.getProperty returns exactly one buffered line prefixed by a single-character status code.
- BR-003 - A status of 'Y' signals that additional lines exist and retrieval must continue; a status of 'N' signals the final line; a status of 'X' signals an empty buffer and also terminates the loop.
- BR-004 - Only non-empty buffer responses (status ≠ 'X') are stored in the output array; empty responses are silently skipped.
- BR-005 - If the required WebUtil client-side bean is not registered, the function must not return partial output; instead it raises a user-facing error alert and halts, ensuring the caller is not given an incomplete or misleading result.
- BR-006 - WebUtil_Core.Init must be executed at package initialisation time to guarantee the core WebUtil infrastructure is available before GetOutput or any sibling function is invoked.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-032 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Given a property key, the function calls the standard Java method java.lang.System.getProperty and returns the corresponding string value to the caller (WEBUTIL.FOPEN or WEBUTIL.REGISTERBEAN), enabling Oracle Forms WebUtil to inspect the host JVM environment without direct database access.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key string (a0) that identifies the Java system property to be retrieved (e.g., 'file.separator', 'os.name').
- Step 2 - Initialise a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1) and storing the handle in the shared args variable.
- Step 3 - Populate the argument list with the property key by calling JNI.ADD_STRING_ARG(args, a0), binding a0 as a java.lang.String argument.
- Step 4 - Invoke the Java static method java.lang.System.getProperty via JNI.CALL_STRING_METHOD, passing the class path 'java/lang/System', method name 'getProperty', and the JNI method signature '(Ljava/lang/String;)Ljava/lang/String;' together with the prepared argument list.
- Step 5 - Return the string value produced by JNI.CALL_STRING_METHOD directly to the caller; if the property does not exist, the Java method returns NULL and that NULL is propagated back.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and unconditionally returns the result of JNI.CALL_STRING_METHOD to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key supplied in parameter a0 must be a valid java.lang.String value; the JNI layer passes it verbatim to java.lang.System.getProperty without transformation or validation within this function.
- BR-002 - The function returns NULL when the requested Java system property does not exist, mirroring the native behaviour of java.lang.System.getProperty; callers (WEBUTIL.FOPEN, WEBUTIL.REGISTERBEAN) are responsible for handling a NULL return value.
- BR-003 - No database tables are read or written; all processing is delegated entirely to the JVM via the JNI bridge, ensuring that the function has no transactional side-effects on the Oracle schema.
- BR-004 - The JNI argument list is created with a fixed capacity of exactly one argument, enforcing that only a single property key may be resolved per invocation.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-033 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string at a specified field position. Given a delimiter-separated string, the function locates the Nth occurrence of the delimiter to isolate and return the substring occupying the requested field position. It is used internally within the WEBUTIL package, notably by WEBUTIL.GETNUMBER, to parse structured string values before further type conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position (1-based), an optional flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaulting to comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If the UnTerminated flag is TRUE, append the delimiter to the working copy so that the final token in the string is bounded and can be located consistently by subsequent position searches.
- Step 4 - Determine the start pointer (iPtrStart): if Field_Position is greater than 1, locate the delimiter occurrence immediately before the requested field (occurrence Field_Position - 1) and advance the pointer past the delimiter by adding the length of the delimiter string; otherwise set iPtrStart to 1 (the beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the delimiter at occurrence Field_Position within the working copy.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which represents the token at the requested field position.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any position searching begins, ensuring the last token is correctly bounded.

FALSE: The source string is used as-is; no modification is made to the working copy.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_Position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the requested token.

FALSE: The start pointer is set to 1, meaning extraction begins at the very start of the string (i.e., the first token is being requested).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates on a working copy of the source string and never mutates the original input parameter.
- BR-002 - When the source string does not include a trailing delimiter after the last token (UnTerminated = TRUE), the delimiter must be appended before parsing to ensure the final token is extractable using the same positional logic applied to all other tokens.
- BR-003 - Field positions are 1-based; a Field_Position of 1 always starts extraction from the beginning of the string without searching for a preceding delimiter.
- BR-004 - The delimiter defaults to a comma if not explicitly supplied by the caller, supporting standard CSV-style string parsing.
- BR-005 - The function returns only the content between the two bounding delimiter positions; the delimiter characters themselves are excluded from the returned token.
- BR-006 - The working copy is limited to varchar2(32000), establishing the maximum supported source string length for parsing operations.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-034 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR retrieves the value of a named configuration or environment variable from the client machine. The retrieval strategy is determined by the client operating system: on Windows, the procedure first queries the Oracle registry key and falls back to the Windows environment string if the registry yields no value; on Unix, it executes the 'env' command and parses its output to locate the variable. Mac and unknown platforms are explicitly unsupported and return no value.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-062](#SP-062--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-063](#SP-063--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-012](#SP-012--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-036](#SP-036--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-050](#SP-050--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and the current value holder (VARVALUE) as input parameters.
- Step 2 - Call WEBUTIL.GETCLIENTOSFAMILY (via WebUtil_Core.GetClientOSFamily) to determine the client operating-system family.
- Step 3 - If the client OS is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' using READ_REGISTRY (Client_Win_API_Environment.read_registry).
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value as a Windows environment variable using GET_ENVIRONMENT_STRING (CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING).
- Step 5 - If the client OS is Mac (CLIENT_PLATFORM_MAC) or unknown (CLIENT_PLATFORM_UNKNOWN), take no action and leave VARVALUE unchanged (NULL).
- Step 6 - For all other OS families (Unix), execute the shell command 'env' synchronously using WEBUTIL.BLOCKING (WebUtil_HOST.Blocking), which returns a process handle.
- Step 7 - Retrieve the full standard output of the 'env' command as an array using WEBUTIL.GET_STANDARD_OUTPUT (WebUtil_HOST.Get_Standard_Output).
- Step 8 - Release the process handle using WEBUTIL.RELEASE_PROCESS (WebUtil_HOST.Release_Process).
- Step 9 - Iterate over each line of the 'env' output; for each line, locate the '=' delimiter and compare the key portion to VARNAME. When a match is found, extract the value portion and assign it to VARVALUE, then exit the loop.
- Step 10 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001
Condition: Client OS family equals CLIENT_PLATFORM_WIN32.
TRUE: Attempt registry lookup under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' for VARNAME, then fall back to environment string if needed (see DP-002).
FALSE: Proceed to DP-003.

DP-002
Condition: Registry lookup result (READ_REGISTRY) is NULL or empty string.
TRUE: Retrieve the variable value using GET_ENVIRONMENT_STRING and assign it to VARVALUE.
FALSE: Use the registry value already assigned to VARVALUE; no further lookup is performed.

DP-003
Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.
TRUE: Take no action; VARVALUE remains unchanged.
FALSE: Client is a Unix platform; proceed to execute the 'env' command.

DP-004
Condition: A '=' delimiter is found (iPos > 0) in the current line of 'env' output.
TRUE: Extract the key (left of '=') and compare it to VARNAME (see DP-005).
FALSE: Skip the current line and continue iterating.

DP-005
Condition: The extracted key from the current 'env' output line equals VARNAME.
TRUE: Assign the value portion (right of '=') to VARVALUE and exit the loop.
FALSE: Continue to the next line in the output array.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is always the primary source for the variable; the environment string is only consulted as a fallback when the registry returns no value.
- BR-002 - On Mac and unknown client platforms, variable retrieval is not supported; the procedure returns without populating VARVALUE.
- BR-003 - On Unix clients, variable resolution is performed exclusively by parsing the output of the 'env' shell command; direct registry or API calls are not used.
- BR-004 - For Unix parsing, only lines containing a '=' character are considered valid environment variable entries; lines without '=' are ignored.
- BR-005 - On Unix, the loop exits immediately upon the first matching variable name, ensuring only the first occurrence is returned.
- BR-006 - A NO_DATA_FOUND exception at any stage results in VARVALUE being set to NULL, preventing unhandled errors from propagating to the caller.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-035 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side file and returns it to the caller. The procedure delegates the physical read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, then interprets the raw buffer to distinguish a genuine text line from an end-of-file condition. It is invoked as part of the Excel report viewing flow in VIEW_EXCEL_REP.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle (file.handle) supplied by the caller as part of the file_type IN parameter.
- Step 2 - Pass the file handle to the WebUtil PJC by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the next line of text from the client file by reading the WUF_TEXTIO_GETLINE property from the WUF_PACKAGE component via WebUtil_Core.getProperty; the result is stored in a local VARCHAR2 buffer (up to 4 000 characters).
- Step 4 - Inspect the buffer value: if it equals CHR(10) (a lone newline character), interpret this as the PJC's end-of-file sentinel and raise NO_DATA_FOUND to signal the caller that no more lines are available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer content to the OUT parameter item and return normally to the caller.
- Step 6 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class, then raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 7 - If a property read/write error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition:
The value returned in the buffer from WebUtil_Core.getProperty equals CHR(10) (a lone newline character).

TRUE:
The procedure interprets the value as the PJC end-of-file sentinel and raises NO_DATA_FOUND, signalling the caller that the end of the file has been reached.

FALSE:
The buffer contains a genuine line of text; the procedure assigns the buffer value to the OUT parameter item and returns successfully.

---

DP-002

Condition:
A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the property set or get calls.

TRUE:
An error alert is displayed identifying the unregistered implementation class, and TOOL_ERR.TOOL_ERROR is raised to terminate processing.

FALSE:
No bean-registration error occurred; processing continues normally.

---

DP-003

Condition:
A WebUtil_Core.PROPERTY_ERROR exception is raised during the property set or get calls.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to terminate processing.

FALSE:
No property error occurred; processing continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure relies on a PJC convention whereby a lone newline character (CHR(10)) in the read buffer exclusively signals end-of-file; a genuine text line returned by the PJC will never contain only CHR(10).
- BR-002 - The maximum length of a single line that can be read and returned is 4 000 characters, as enforced by the local buffer declaration (VARCHAR2(4 000 CHAR)).
- BR-003 - If the WebUtil bean required to perform the client-side file read is not registered, the procedure must not silently fail; it must alert the user and raise a terminal error (TOOL_ERR.TOOL_ERROR).
- BR-004 - Any property-level error returned by the WebUtil PJC layer must cause the procedure to raise TOOL_ERR.TOOL_ERROR, ensuring that callers in the Excel report flow are notified of the failure rather than receiving incomplete or corrupt data.
- BR-005 - The procedure has no direct database interactions; all file I/O is performed entirely on the client side through the WebUtil PJC mechanism.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-036 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream captured from a host process by delegating to the generic output-retrieval function WEBUTIL.GETOUTPUT with the fixed stream identifier 'WUH_STDOUT'. This provides callers with a typed, single-purpose entry point for reading standard output without needing to know the internal stream key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-031](#SP-031--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (PROCESS_ID) that references the host process whose standard output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT, passing the supplied process identifier and the hard-coded stream label 'WUH_STDOUT' to select the standard output stream.
- Step 3 - Return the OUTPUT_ARRAY result produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

None. The function contains no conditional branching; it unconditionally delegates to WEBUTIL.GETOUTPUT with a fixed stream identifier and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve standard output is always 'WUH_STDOUT'; this value is hard-coded and cannot be overridden by the caller.
- BR-002 - The function accepts exactly one input, the PROCESS_ID of the target host process, and returns an OUTPUT_ARRAY; no other output parameters are produced.
- BR-003 - All output-retrieval logic is governed by WEBUTIL.GETOUTPUT (SP-031); this function acts solely as a named convenience wrapper for the standard output stream.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-037 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle reference is uninitialised (null). Callers use the returned Boolean to guard against operating on an invalid or unallocated pointer before invoking further WebUtil operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming handle (Pointer type) as an input parameter.
- Step 2 - Inspect the internal field `hnd` of the supplied handle to determine whether it holds a null value.
- Step 3 - Return TRUE to the caller if `hnd` is null, indicating the handle is uninitialised.
- Step 4 - Return FALSE to the caller if `hnd` is not null, indicating the handle is valid and populated.

---
**Decision Points**

DP-001

Condition:
The `hnd` attribute of the supplied handle parameter is null.

TRUE:
The function returns TRUE, signalling to the caller that the handle is uninitialised and should not be used for further processing.

FALSE:
The function returns FALSE, signalling to the caller that the handle is valid and may be safely used in subsequent operations.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal `hnd` attribute; no other attribute or external state is evaluated.
- BR-002 - The function must return a Boolean value in all execution paths; no exception or default null return is permitted.
- BR-003 - The function is read-only and must not modify the supplied handle or any application state during evaluation.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-038 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT is a package initialisation procedure within the WEBUTIL_CORE package. Its sole responsibility is to trigger the package-level initialisation block, which in turn calls WEBUTIL.INITWEBUTIL (SP-039) to set up the WebUtil utility framework. The procedure itself performs no discrete processing; entering the package is sufficient to invoke the BEGIN block that executes INITWEBUTIL.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-039](#SP-039--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.INIT is called (invoked from WEBUTIL.GETOUTPUT via webutil.pld).
- Step 2 - The procedure body executes a NULL statement, performing no independent processing, as the act of entering the package is sufficient to trigger initialisation.
- Step 3 - The WEBUTIL_CORE package-level BEGIN block executes automatically upon package entry, calling WEBUTIL.INITWEBUTIL (SP-039) to initialise the WebUtil utility framework.
- Step 4 - Control returns to the calling routine (WEBUTIL.GETOUTPUT) with the WebUtil utility fully initialised.

---
**Decision Points**

No decision points exist within WEBUTIL.INIT. The procedure body contains only a NULL statement, and the package initialisation block unconditionally calls WEBUTIL.INITWEBUTIL with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must contain no active logic; entering the WEBUTIL_CORE package is the mechanism that triggers initialisation, making any explicit processing within the procedure body unnecessary.
- BR-002 - Initialisation of the WebUtil utility framework is delegated entirely to WEBUTIL.INITWEBUTIL (SP-039), which is invoked unconditionally through the package-level BEGIN block upon first entry to the package.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-039 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil runtime environment when the form loads. The procedure registers the Java implementation class for each WebUtil functional package, verifies that the mandatory WebUtil object group (including its error alert and bean areas) is present in the calling form, optionally navigates to and renders the WebUtil bean areas, and determines the server-side file-path separator based on the host operating system. It is invoked by WEBUTIL.INIT and must complete successfully before any WebUtil capability can be used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-054](#SP-054--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to be used as navigation reference points throughout initialisation.
- Step 2 - Populate the internal implementation-class registry (m_implClasses) by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java class name, establishing the runtime binding for all WebUtil functional areas.
- Step 3 - Check whether the WebUtil error alert (m_errorAlert) exists in the form by calling WEBUTIL.ID_NULL. If the alert is absent, display an error message and pause, halting further initialisation because the WebUtil object group is not available.
- Step 4 - If the error alert is present, evaluate whether explicit bean instantiation is required (FLAG_EXPICIT_INSTANCIATE is TRUE) and the form is currently in NORMAL mode (SYSTEM.MODE = 'NORMAL').
- Step 5 - When both conditions in Step 4 are met, verify that the WebUtil dummy item exists (WEBUTIL.ID_NULL check on hDummy). If it exists, navigate to the dummy item via GO_ITEM to trigger bean area rendering.
- Step 6 - After navigating to the dummy item, compare the block of the original cursor position with the block of the dummy item. If they are in the same block, move to the next block (NEXT_BLOCK); otherwise return focus to the original cursor position (GO_ITEM(startPoint)).
- Step 7 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without forcing visibility, completing the bean setup phase.
- Step 8 - If the dummy item does not exist (Step 5 negative branch), take no action, deferring bean setup responsibility to the calling developer.
- Step 9 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN', set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns TRUE (the WebUtil error alert is not present in the form).

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', pause execution, and abort further initialisation.

FALSE: Proceed with bean area setup and server OS detection (DP-002 onwards).

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to check for the dummy item and perform explicit bean instantiation (DP-003).

FALSE: Skip explicit bean instantiation entirely; continue to server OS detection (Step 9).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) returns FALSE (the WebUtil dummy item exists in the form, indicating the standard object group is in use).

TRUE: Navigate to the dummy item, resolve block positioning, call WEBUTIL.SHOWBEANS(false) to render bean areas.

FALSE: Take no action; the developer is responsible for managing bean area setup independently.

---

DP-004

Condition: After navigating to the dummy item, GET_ITEM_PROPERTY(startPoint, BLOCK_NAME) equals GET_ITEM_PROPERTY(hDummy, BLOCK_NAME) (the original cursor and the dummy item are in the same block).

TRUE: Execute NEXT_BLOCK to move focus out of the shared block before calling WEBUTIL.SHOWBEANS.

FALSE: Return focus to the original cursor item via GO_ITEM(startPoint).

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server operating system name contains 'WIN').

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil object group, including its error alert (m_errorAlert), must be present in the calling form before any WebUtil functionality can operate; absence of the error alert is treated as a fatal configuration error and initialisation is halted.
- BR-002 - Explicit bean instantiation via navigation is performed only when the form is in NORMAL mode; Enter-Query mode is explicitly excluded to avoid navigation conflicts (per Bug 2955789 resolution).
- BR-003 - Explicit bean instantiation is further gated by the FLAG_EXPICIT_INSTANCIATE flag, allowing the behaviour to be enabled or disabled as a configurable workaround without code changes.
- BR-004 - If the standard WebUtil object group is not used (dummy item absent), the procedure defers all bean area setup to the developer; no error is raised in this scenario.
- BR-005 - When navigating for bean instantiation, the procedure must restore or avoid disrupting the user's original cursor position: if the dummy item shares a block with the original cursor, focus advances to the next block; otherwise focus returns directly to the original item.
- BR-006 - The server file-path separator (m_serverFileSep) must be resolved once at initialisation time based on the server OS and stored for use by subsequent WebUtil file-handling operations; Windows environments use backslash and all other environments use forward slash.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-040 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Boolean indicator of whether the most recent WebUtil operation resulted in an error. The function evaluates the internal error-tracking variable `m_lastError` and returns TRUE if a non-zero error code is present, allowing callers such as WEBUTIL.LOG to branch their processing based on the current error state.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the value of the module-level variable `m_lastError`, which holds the error code set by the most recent WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition exists.
- Step 3 - Return TRUE if `m_lastError` is not equal to zero (error condition present), or FALSE if `m_lastError` equals zero (no error condition).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, indicating that the last WebUtil operation recorded a non-zero error code and an error condition is active.

FALSE: The function returns FALSE, indicating that `m_lastError` is zero and no error condition is currently recorded.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An error condition is defined exclusively by a non-zero value in `m_lastError`; a value of zero always represents a clean (no-error) state.
- BR-002 - The function performs a read-only evaluation; it does not modify `m_lastError` or any other state variable.
- BR-003 - The function accepts no input parameters; its result is derived solely from the current value of the shared module-level variable `m_lastError` at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-041 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed in via the 'file' input parameter.
- Step 2 - Inspect the 'handle' attribute of the FILE_TYPE record to determine whether it holds a non-NULL value.
- Step 3 - If the handle is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate the file is currently open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling that no open file handle exists for the supplied FILE_TYPE record.

FALSE: The function returns TRUE, signalling that a valid open file handle exists for the supplied FILE_TYPE record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its 'handle' attribute is NOT NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs a read-only inspection of the FILE_TYPE record and does not alter the state of the file or its handle under any circumstance.
- BR-003 - The function returns a strict BOOLEAN result (TRUE or FALSE); no intermediate or indeterminate state is permitted.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-042 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java java.io.File.length() method via the JNI bridge, providing Oracle Forms PL/SQL callers with the ability to determine the size of a client-side or server-side file without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object reference (obj) passed by the calling routine as an ORA_JAVA.JOBJECT handle.
- Step 2 - Reset the JNI argument list by setting args to NULL, ensuring no stale arguments are carried into the method call.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the object reference, the fully-qualified class name 'java/io/File', the method name 'length', and the method descriptor '()J' (no parameters, returns a long).
- Step 4 - Return the numeric result (file size in bytes) obtained from the JNI call to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. The implementation follows a single, unconditional execution path: clear arguments, call the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates exclusively on a valid ORA_JAVA.JOBJECT reference representing a java.io.File instance; the caller is responsible for supplying a properly initialised File object.
- BR-002 - The argument list (args) must be explicitly set to NULL before the JNI call to prevent unintended parameter passing to the zero-argument Java method.
- BR-003 - The file length is returned as a NUMBER derived from a Java long value; the result represents the file size in bytes as reported by the underlying operating system via java.io.File.length().
- BR-004 - This function has no database interactions; it operates entirely through the JNI bridge to the Java runtime and does not read from or write to any database table.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-043 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to a server-side log file on behalf of the WebUtil framework. On first invocation it initialises the logging configuration by reading three property-bundle settings (enabled flag, errors-only flag, and target file path), communicates the resolved logging mode to the client-side bean via a property, and then appends the supplied message to the log file-optionally prefixing it with the client IP address and username. If logging is misconfigured or the file cannot be written, the procedure disables logging and raises an appropriate alert or framework error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-040](#SP-040--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-041](#SP-041--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level logging cache variable (m_loggingAllowed) has been initialised. If it is NULL, proceed to Steps 2-7; otherwise skip directly to Step 8.
- Step 2 - Read the 'logging.enabled' property from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and store the result (TRUE/FALSE) in m_loggingAllowed.
- Step 3 - Read the 'logging.errorsonly' property from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and store the result in m_loggingErrorsOnly.
- Step 4 - Read the 'logging.file' property from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and store the file path in m_loggingFile.
- Step 5 - If logging is enabled but no file path was returned, set m_loggingAllowed to FALSE and raise error WUC-008: if no bean is registered yet, display the error message via WEBUTIL.ERRORALERT; otherwise communicate the disabled state to the bean (WUC_SRV_LOGGING = '0') and raise the error through the framework.
- Step 6 - If at least one bean is registered, communicate the resolved logging mode to the client-side bean by setting the WUC_SRV_LOGGING property: '1' for errors-only mode, '2' for full logging, or '0' for disabled.
- Step 7 - Logging cache initialisation is complete.
- Step 8 - If m_loggingAllowed is TRUE, evaluate whether the current message qualifies for writing: it qualifies if errors-only mode is OFF, or if errors-only mode is ON and the isError parameter is TRUE.
- Step 9 - Open the log file in append mode (TEXT_IO.FOPEN). If the file cannot be opened, raise NO_DATA_FOUND to trigger the exception handler.
- Step 10 - Write the message to the log file. If m_clientIP is populated, prefix the message with the client IP address and username; otherwise write the message as supplied.
- Step 11 - Close the log file (TEXT_IO.FCLOSE).
- Step 12 - On exception: if the Oracle error code is -302000 (file write failure), raise error WUC-007 via WEBUTIL.ERRORALERT (no bean registered) or via the framework (bean registered), set WUC_SRV_LOGGING to '0', and permanently disable logging by setting m_loggingAllowed to FALSE. Any other exception is re-raised.

---
**Decision Points**

DP-001

Condition: m_loggingAllowed IS NULL (logging cache not yet initialised).

TRUE: Read the three logging properties from the property bundle, validate the configuration, and set the module-level cache variables before proceeding to the write phase.

FALSE: Skip initialisation and proceed directly to the write phase using the already-cached values.

---

DP-002

Condition: Logging is enabled (m_loggingAllowed = TRUE) but the resolved log file path (m_loggingFile) is NULL.

TRUE: Disable logging (m_loggingAllowed := FALSE) and raise error WUC-008 - via WEBUTIL.ERRORALERT if no bean is registered, or via the framework property/error mechanism if a bean is registered.

FALSE: Retain the enabled state and continue with bean notification.

---

DP-003

Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the time the logging cache is being initialised.

TRUE: Set the WUC_SRV_LOGGING client-side property to reflect the resolved mode ('0' = disabled, '1' = errors-only, '2' = full logging).

FALSE: Skip the bean property update; the property will be set when a bean is eventually registered.

---

DP-004

Condition: m_loggingAllowed is TRUE AND (m_loggingErrorsOnly is FALSE OR (m_loggingErrorsOnly is TRUE AND isError is TRUE)).

TRUE: Open the log file and write the message.

FALSE: Suppress the message; no file I/O is performed.

---

DP-005

Condition: m_clientIP IS NULL at the time of writing.

TRUE: Write the message to the log file without any prefix.

FALSE: Prefix the message with the client IP address and username before writing.

---

DP-006

Condition: An exception is caught and the Oracle error code equals -302000 (file write failure).

TRUE: Raise error WUC-007 (via WEBUTIL.ERRORALERT if no bean is registered, or via the framework if a bean is registered), set WUC_SRV_LOGGING to '0', and permanently disable logging.

FALSE: Re-raise the exception to the caller without suppressing it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and file path) is read from the property bundle exactly once per session; the resolved values are cached in module-level variables and reused on all subsequent calls.
- BR-002 - Logging is only active when both the 'logging.enabled' property resolves to 'true' (case-insensitive) and a non-null file path is provided via 'logging.file'; the absence of a file path unconditionally disables logging regardless of the enabled flag.
- BR-003 - When errors-only mode is active (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently discarded.
- BR-004 - Log entries are appended to the existing log file; the file is opened in append mode ('A') on every write and closed immediately after, ensuring no log data is overwritten.
- BR-005 - If a client IP address is available (m_clientIP IS NOT NULL), every log entry is prefixed with the client IP address and username to support audit traceability.
- BR-006 - The client-side bean is notified of the server-side logging mode via the WUC_SRV_LOGGING property ('0' = disabled, '1' = errors-only, '2' = full) only when at least one bean is registered at the time of cache initialisation.
- BR-007 - When no bean is registered and an error condition arises (missing file path WUC-008, or write failure WUC-007), the error is surfaced to the user through WEBUTIL.ERRORALERT using a plain English message.
- BR-008 - A file write failure (Oracle error -302000) permanently disables logging for the remainder of the session (m_loggingAllowed := FALSE) to prevent repeated failed write attempts; all other exceptions are propagated to the caller.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path by checking, in priority order, a Forms global variable, an environment variable, and a Forms parameter, raising a descriptive error if no path can be determined or if the file cannot be read.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-019](#SP-019--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to resolve the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global is unset, query the operating-system environment variable identified by WEBUTIL_CONFIG_ENV for the file path.
- Step 3 - If the environment variable also yields no value, fall back to the Forms parameter identified by WEBUTIL_CONFIG_PARAM.
- Step 4 - If all three sources yield a null path, raise NO_DATA_FOUND to trigger the error-handling block.
- Step 5 - Persist the resolved file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL for reuse by subsequent calls.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.
- Step 7 - Read the file line by line in a loop; on end-of-file (NO_DATA_FOUND within the loop), exit the loop.
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the first '=' character; skip lines that contain no '=' (i.e., no key-value pair).
- Step 10 - For valid key-value lines, increment the property index, store the trimmed, lower-cased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key against the lower-cased input propertyKey; if they match, capture the corresponding value as the result to be returned.
- Step 12 - After processing all lines, close the configuration file.
- Step 13 - Return the captured result value (NULL if the key was not found in the file).
- Step 14 - On NO_DATA_FOUND in the outer exception block (no config file path resolved): if no bean package is registered yet, invoke WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - On SQLCODE -302000 (file-read failure): if no bean package is registered yet, invoke WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 16 - For any other unhandled exception, re-raise to the caller.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.
TRUE: Clear the local configFile variable and attempt to resolve the path from the environment variable WEBUTIL_CONFIG_ENV.
FALSE: Use the value held in WEBUTIL_CONFIG_GLOBAL as the configuration file path and proceed to open the file.

DP-002
Condition: The environment variable WEBUTIL_CONFIG_ENV returns a non-null file path.
TRUE: Use the environment-variable value as the configuration file path.
FALSE: Attempt to resolve the path from the Forms parameter WEBUTIL_CONFIG_PARAM.

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null file path.
TRUE: Use the parameter value as the configuration file path.
FALSE: Raise NO_DATA_FOUND; no configuration file path is available.

DP-004
Condition: The first character of a file line is '#'.
TRUE: Skip the line entirely (treated as a comment).
FALSE: Proceed to check the line for a key-value pair.

DP-005
Condition: The line contains an '=' character (pos > 0).
TRUE: Parse the line into a key-value pair and store it in m_propertyBundle.
FALSE: Skip the line; it does not represent a valid property entry.

DP-006
Condition: The parsed property key matches the lower-cased input propertyKey.
TRUE: Capture the corresponding property value as the function result.
FALSE: Continue reading subsequent lines without updating the result.

DP-007
Condition: Outer exception is NO_DATA_FOUND (no config file path resolved) and m_registeredPackages is empty (no bean registered).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified', set m_config_error to TRUE, and return NULL.
FALSE: Delegate error reporting to Webutil_Core.Error, set m_config_error to TRUE, and return NULL.

DP-008
Condition: Outer exception SQLCODE equals -302000 (file unreadable) and m_registeredPackages is empty (no bean registered).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File', set m_config_error to TRUE, and return NULL.
FALSE: Delegate error reporting to Webutil_Core.Error, set m_config_error to TRUE, and return NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing cannot continue.
- BR-002 - Once the configuration file path is successfully resolved from any source, it must be written back to the Forms global variable WEBUTIL_CONFIG_GLOBAL to ensure consistent reuse by subsequent invocations.
- BR-003 - Lines beginning with '#' are treated as comments and must be excluded from property parsing.
- BR-004 - Only lines containing an '=' character are treated as valid property entries; lines without '=' are silently ignored.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed, ensuring case-insensitive and whitespace-tolerant key lookup.
- BR-006 - Property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped, ensuring clean values regardless of file line-ending format.
- BR-007 - When no configuration file path can be determined (WUC-005) or the file cannot be read (WUC-006), the module-level error flag m_config_error must be set to TRUE and the function must return NULL, preventing further processing from relying on an unpopulated property bundle.
- BR-008 - Error messages WUC-005 and WUC-006 are surfaced via WEBUTIL.ERRORALERT only when no bean package has been registered (m_registeredPackages is empty); when a bean is registered, error reporting is delegated to Webutil_Core.Error.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-045 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the text content and a newline instruction to the WebUtil client bean. The procedure is used within Excel report generation (VIEW_EXCEL_REP) to append individual lines of data to a file handle previously opened on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle) and the text string (item) to be written as input parameters.
- Step 2 - Pass the file handle to the WebUtil client bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Pass the text content to the WebUtil client bean by setting the WUF_TEXTIO_PUT property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 4 - Signal a newline by setting the WUF_TEXTIO_NEWLINE property to 1 on the WUF_PACKAGE component via WebUtil_Core.setProperty, causing the client bean to append a line terminator after the written text.
- Step 5 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), raise an informational error alert identifying the missing bean class and re-raise a TOOL_ERROR to halt processing.
- Step 6 - If any property-setting operation fails (PROPERTY_ERROR exception), re-raise a TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The WebUtil client bean for WUF_PACKAGE is registered and available on the client at the time of the three setProperty calls.

TRUE:
All three properties (WUF_TEXTIO_HANDLE, WUF_TEXTIO_PUT, WUF_TEXTIO_NEWLINE) are set successfully; the line is written to the client file and the procedure completes normally.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; WebUtil_Core.ErrorAlert displays a message identifying the missing bean class and advising that CLIENT_TEXT_IO.put_line will not work, after which TOOL_ERR.TOOL_ERROR is raised to stop execution.

---

DP-002

Condition:
A property-setting operation raises a PROPERTY_ERROR exception (e.g., the property value is invalid or the bean rejects the update).

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to halt processing; no partial write is committed.

FALSE:
No property error occurs; processing continues normally through all three setProperty calls.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil client bean identified by WUF_PACKAGE must be registered on the client before this procedure is called; absence of the bean is treated as a fatal error that prevents file write operations.
- BR-002 - A newline character is always appended after the text item (WUF_TEXTIO_NEWLINE is unconditionally set to 1); the procedure always writes a full line, never a partial line without a terminator.
- BR-003 - Any failure during property transmission to the client bean (BEAN_NOT_REGISTERED or PROPERTY_ERROR) must result in TOOL_ERR.TOOL_ERROR being raised, ensuring the calling process (e.g., VIEW_EXCEL_REP) is notified of the failure and does not continue writing to an unusable file handle.
- BR-004 - The file handle passed in the file parameter must be a valid, previously opened file_type reference; this procedure does not open or validate the file itself and relies on the caller to supply a correct handle.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-046 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been populated, it delegates to WEBUTIL.POPULATEPROPERTYBUNDLE to load it before performing the lookup. This function supports configuration-driven behaviour for routines such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, reusable mechanism for reading named configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, return NULL immediately without attempting any lookup.
- Step 3 - If no configuration error exists but the property bundle is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested propertyKey, and assign its return value as the result.
- Step 4 - If the property bundle is already populated (count > 0), iterate through all entries in m_propertyBundle and compare each entry's propertyKey (stored in lower case) against the lower-case equivalent of the supplied propertyKey.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the result value to the caller; this will be NULL if no matching key was found, if the bundle could not be populated, or if a prior configuration error was detected.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no further processing is performed, indicating a previously encountered configuration file read failure.

FALSE: Proceed to evaluate the state of the property bundle.

---

DP-002

Condition: The property bundle (m_propertyBundle) contains zero entries (propCount = 0).

TRUE: Call WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to load the bundle and obtain the result value directly from that call.

FALSE: The bundle is already loaded; iterate through existing entries to locate the matching key.

---

DP-003

Condition: During iteration, the current entry's propertyKey (lower-cased) matches the lower-cased value of the supplied propertyKey.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop.

FALSE: Continue iterating to the next entry; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been recorded (m_config_error = TRUE), the function must return NULL without attempting to read or populate the property bundle, preventing repeated or cascading failures.
- BR-002 - Property key comparisons must be performed in a case-insensitive manner; all stored keys are held in lower case and the supplied key is converted to lower case before comparison, ensuring consistent lookups regardless of the case used by the caller.
- BR-003 - If the in-memory property bundle is empty at the time of the call, WEBUTIL.POPULATEPROPERTYBUNDLE must be invoked to initialise it; the function may not perform a direct lookup against an unpopulated bundle.
- BR-004 - Once a matching property key is found during iteration, the loop must exit immediately; only the first matching entry's value is returned, preventing duplicate-key ambiguity.
- BR-005 - The return value is NULL when no matching key exists in the bundle, when the bundle cannot be populated, or when a prior configuration error is present; callers must handle a NULL result as a valid outcome.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-047 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key from the supplied property key and optional arguments, then delegating the read/write cycle to the WebUtil Core property mechanism. The function is currently used by WEBUTIL.CHECKLIBS to obtain localised text (e.g., a progress bar title) at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the mandatory property key (propertyKey) and an optional arguments string (args) as input.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WUC_TRANS_MSG property slot of the WUC_PACKAGE package via Webutil_Core.setProperty, triggering the message-bundle resolution on the WebUtil layer.
- Step 4 - Read back the resolved translated message string from the same WUC_TRANS_MSG property slot via Webutil_Core.getProperty.
- Step 5 - Return the resolved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed sequence of set and get operations without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and arguments are always concatenated with a pipe character ('|') as the delimiter before being passed to the message bundle resolver, ensuring a consistent lookup format.
- BR-002 - The args parameter is optional (defaults to NULL); when omitted, the composite lookup value will be in the form 'propertyKey|', with a trailing pipe delimiter still present.
- BR-003 - Message bundle resolution is performed exclusively through Webutil_Core.setProperty and Webutil_Core.getProperty using the fixed package identifier WUC_PACKAGE and the property name WUC_TRANS_MSG; no direct database or file access is performed by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-048 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the server-side Forms session on its first contact. For each bean, the procedure resolves its internal package identifier, captures one-time client environment data (IP address, OS, architecture, username, locale, path and file separators), determines the system-library download directory, sets heartbeat and server-logging preferences on the client bean, and triggers library availability checks for both the new package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-013](#SP-013--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-025](#SP-025--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-030](#SP-030--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-032](#SP-032--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-034](#SP-034--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-046](#SP-046--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-051](#SP-051--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding WEBUTIL_CORE package-ID constant; unrecognised short names leave packageID unset.
- Step 3 - If the module-level client IP (m_clientIP) is null, this is the first bean registration for the session: parse positions 2-8 of clientInfo to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), clientOSArch, m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode; set the checkUserLibs flag to TRUE and detect 64-bit architecture by inspecting the arch string.
- Step 4 - If the resolved packageID does not yet exist in the m_registeredPackages associative array, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE; duplicate bean instances (e.g. in multi-row blocks) are silently ignored.
- Step 5 - When checkUserLibs is TRUE, reset REDOWNLOAD_SYSLIB to FALSE, then resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 6 - Read the OS-family- and architecture-specific client system-library directory from the property bundle (key 'install.syslib.location.client.<osfamily>.<osarch>'); if not found, retry with the OS-family-only key ('install.syslib.location.client.<osfamily>').
- Step 7 - If no client library directory is configured, push a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config token, letting the client default to its JRE location.
- Step 8 - If a client library directory is configured, substitute the '$(SERVERHOST)' placeholder with the resolved server host name, push the full WUC_SYSLIB_DIR property (directory + server host + config), retrieve the previously stored directory via WEBUTIL.GETCLIENTSETTING, and if it differs from the new value, persist the new value with WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 9 - Retrieve and store the WebUtil bean version into WEBUTIL_CORE.WEBUTIL_VERSION via WEBUTIL.GETPROPERTY.
- Step 10 - If the property bundle key 'logging.connections' equals 'true' (case-insensitive), write a connection log entry (form name, client OS, locale) via WEBUTIL.LOG.
- Step 11 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS for the resolved packageID to verify that all required client libraries for that bean are present.
- Step 12 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 13 - Read the 'BlockAllowHeartBeat' property bundle key; if its lowercase value is 'true', 'yes', or '1', push WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise push '0'.
- Step 14 - Evaluate the logging flags and push the WUC_SRV_LOGGING property to the client bean: '1' for errors-only logging, '2' for full logging, '0' for logging disabled.
- Step 15 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal 'user' to check and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains unset; subsequent steps that reference packageID may not execute correctly.

DP-002
Condition: m_clientIP IS NULL (first bean registration in the current session).
TRUE: Client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo and stored in module-level variables; checkUserLibs is set to TRUE.
FALSE: Client environment parsing is skipped; checkUserLibs remains FALSE.

DP-003
Condition: clientOSArch string contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit).
FALSE: m_clientOSArch retains its default value (0 / not 64-bit).

DP-004
Condition: m_registeredPackages does NOT contain an entry for packageID.
TRUE: The bean is recorded in m_registeredPackages against the current trigger item; newPackage is set to TRUE.
FALSE: The bean is already registered (e.g. duplicate in a multi-row block); no action is taken and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.GETVAR returns a non-null value for 'COMPUTERNAME'.
TRUE: serverHost is set from the 'COMPUTERNAME' environment variable.
FALSE: WEBUTIL.GETVAR is called again with 'HOST' to obtain serverHost.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family- and architecture-specific syslib key.
TRUE: clientLibDir is set to that value.
FALSE: WEBUTIL.READFROMPROPERTYBUNDLE is called again with the OS-family-only key.

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is set to ':serverHost:config' (client defaults to JRE location); no client-setting comparison is performed.
FALSE: The configured directory is used; '$(SERVERHOST)' is substituted, WUC_SYSLIB_DIR is pushed with the full path, and the stored directory is compared with the new one (see DP-008).

DP-008
Condition: Previously stored client syslib directory (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: No update is made; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: LOWER(WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections')) = 'true'.
TRUE: A connection log entry is written via WEBUTIL.LOG containing the form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called for the resolved packageID to verify client library availability for the new bean.
FALSE: Library check for the specific bean package is skipped.

DP-011
Condition: LOWER(blockAllowHeartBeat) IN ('true', 'yes', '1').
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the client bean, instructing it to block heartbeat activity.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', allowing normal heartbeat behaviour.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only) on the client bean.
FALSE: Evaluated further in DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE, per DP-012 fall-through).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging) on the client bean.
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled) on the client bean.

DP-014
Condition: checkUserLibs is TRUE (re-evaluated after newPackage check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Each known WebUtil bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) must map to a unique WEBUTIL_CORE package-ID constant; any bean short name not in this list will not be assigned a packageID.
- BR-002 - Client environment data (IP, OS, architecture, username, separators, locale) is captured exactly once per Forms session, on the first bean registration; subsequent bean registrations within the same session do not overwrite these values.
- BR-003 - Only the first instance of a given bean package is registered per form; if the same bean appears in a multi-row block or is otherwise duplicated, only the first occurrence is recorded in m_registeredPackages.
- BR-004 - The system-library client directory is resolved by first attempting an OS-family- and architecture-specific property bundle key, then falling back to an OS-family-only key; if neither is defined, the client is responsible for determining its own library location (defaulting to the JRE).
- BR-005 - The '$(SERVERHOST)' placeholder in the configured client library directory must be replaced with the runtime server host name before the value is transmitted to the client.
- BR-006 - If the resolved client system-library directory differs from the value previously stored via WEBUTIL.GETCLIENTSETTING, the new directory must be persisted with WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag must be set to TRUE to trigger a re-download.
- BR-007 - Connection logging is conditional on the property bundle key 'logging.connections' being set to 'true' (case-insensitive); no connection record is written unless this key is explicitly enabled.
- BR-008 - The BlockAllowHeartBeat configuration variable accepts only the values 'true', 'yes', or '1' (case-insensitive) to activate heartbeat blocking; any other value results in heartbeat being permitted.
- BR-009 - Server-side logging preferences (errors-only, full, or disabled) must be communicated to the client bean via the WUC_SRV_LOGGING property so that the bean avoids sending unnecessary messages to the server.
- BR-010 - Library availability checks (WEBUTIL.CHECKLIBS) for a specific bean package are performed only when that package is newly registered in the current session; user library checks are performed only during the first bean registration of the session.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-049 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent calls. The procedure communicates the library/function specification to the WebUtil core component, retrieves the resulting handle token, and tracks the total count of successfully registered function handles within the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and write the combined specification to the WebUtil core property WUL_FUNCTION_SPEC on the WUL_PACKAGE component, signalling the bean layer which function is to be registered.
- Step 3 - Read back the WUL_REGISTER_FUNCTION property from the WUL_PACKAGE component; the bean layer returns an 8-character string token representing the allocated handle.
- Step 4 - Convert the string token to a numeric value and store it in the hnd field of a local FunctionHandle variable (funcHnd).
- Step 5 - Invoke WEBUTIL.ID_NULL to test whether the returned FunctionHandle is valid (non-null). If the handle is valid, increment the session-level counter m_funcHandleCount by 1.
- Step 6 - Return the populated FunctionHandle to the caller.
- Step 7 (Exception - BEAN_NOT_REGISTERED) - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 8 (Exception - PROPERTY_ERROR) - If a property read/write error occurs, raise FORM_TRIGGER_FAILURE to abort processing.
- Step 9 (Exception - VALUE_ERROR) - If the string-to-number conversion of the handle token fails, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(funcHnd) returns FALSE (i.e., the FunctionHandle returned by the bean layer is not null/invalid).

TRUE (handle is valid): Increment the session-level registered-function counter m_funcHandleCount by 1 and return the handle to the caller.

FALSE (handle is null/invalid): Skip the counter increment; return the unpopulated FunctionHandle to the caller without updating the count.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the WebUtil core property interaction.

TRUE: Display an error alert identifying the missing WebUtil implementation class and raise FORM_TRIGGER_FAILURE, halting further execution.

FALSE: Continue normal processing.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during the WebUtil core property interaction.

TRUE: Raise FORM_TRIGGER_FAILURE, halting further execution.

FALSE: Continue normal processing.

---

DP-004

Condition: A VALUE_ERROR exception is raised when converting the string handle token to a number.

TRUE: Raise TOOL_ERR.TOOL_ERROR, halting further execution.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The library name and function name must both be supplied; they are concatenated with a pipe character ('|') as the delimiter before being passed to the WebUtil core layer as a single function specification string.
- BR-002 - The WebUtil bean identified by WUL_PACKAGE must be registered and available at the time of invocation; if it is not, the procedure raises a fatal form error and execution cannot continue.
- BR-003 - The handle token returned by the bean layer must be convertible to a numeric value; a non-numeric token is treated as a fatal error (TOOL_ERR.TOOL_ERROR).
- BR-004 - Only a FunctionHandle that passes the WEBUTIL.ID_NULL validity check (i.e., is non-null) is counted toward the session-level registered-function total (m_funcHandleCount).
- BR-005 - The function returns a FunctionHandle in all non-exception paths, including the case where the handle is null; callers are responsible for validating the returned handle before use.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-050 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This procedure ensures that process resources managed by the WebUtil host utility are properly deallocated after use, preventing stale or orphaned process handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) identifying the host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE bean, passing the current handle value, signalling to the WebUtil infrastructure that the process slot is to be vacated.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the same handle to deregister any callback trigger that was registered against the process, ensuring no residual event listeners remain.
- Step 4 - Set process.handle to NULL, marking the caller's PROCESS_ID variable as released and preventing any further use of the now-invalid handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, surface a descriptive error alert via WebUtil_Core.ErrorAlert, identifying the missing implementation class and stating that WEBUTIL_HOST.Release_Process will not function, then allow the exception to be handled gracefully without propagating.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean (i.e., the required WebUtil bean is not registered in the current session).

TRUE: WebUtil_Core.ErrorAlert is called with a message composed of the implementation class name (retrieved via WebUtil_Core.getImplClass for WUH_PACKAGE) and a statement that WEBUTIL_HOST.Release_Process will not work; normal release steps are aborted.

FALSE: The procedure completes all three release steps (setProperty, ClearCallbackTrigger, null assignment) successfully and returns the nullified PROCESS_ID to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The PROCESS_ID parameter is both read and written (IN OUT); the caller's handle is unconditionally set to NULL upon successful completion, enforcing that a released handle cannot be reused.
- BR-002 - Both the property clear (setProperty) and the callback deregistration (ClearCallbackTrigger) must be performed using the same handle value before that handle is nullified, ensuring the WebUtil infrastructure is fully cleaned up before the reference is discarded.
- BR-003 - If the WUH_PACKAGE bean is not registered, the procedure must not silently fail; it must surface an error alert that includes the implementation class name, providing the end user or administrator with sufficient information to diagnose the missing bean.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-051 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named client-side configuration property and its value to the WebUtil core bean running on the client machine. The procedure packages the property name and value into a single key=value string and delegates the call to WebUtil_Core.setProperty, targeting the WUC_SET_LOCAL_PROPERTY action on the WUC_PACKAGE bean. It is invoked during library initialisation (WEBUTIL.CHECKLIBS) and bean registration (WEBUTIL.REGISTERBEAN) to ensure client-side settings are applied before dependent WebUtil functionality is exercised.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the client setting identifier (propertyName) and its intended value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; only a non-null property name constitutes a valid, actionable request.
- Step 3 - Concatenate propertyName and propertyValue into a single 'name=value' string and pass it to WebUtil_Core.setProperty, specifying the WebUtil_Core.WUC_PACKAGE target bean and the WebUtil_Core.WUC_SET_LOCAL_PROPERTY action constant.
- Step 4 - If the WebUtil_Core bean has not yet been registered (BEAN_NOT_REGISTERED exception), raise an error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If the property assignment itself fails (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.
- Step 6 - If no exception is raised, the procedure completes silently; the client setting is now active on the client tier.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue as 'propertyName=propertyValue' and invoke WebUtil_Core.setProperty to apply the setting on the client.

FALSE: Skip the setProperty call entirely; the procedure exits without performing any action or raising an error.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Display an error alert identifying the missing WebUtil_Core bean class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No BEAN_NOT_REGISTERED exception; processing continues normally or is governed by DP-003.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raise FORM_TRIGGER_FAILURE immediately to abort the current form trigger; no additional alert is displayed.

FALSE: No PROPERTY_ERROR exception; the procedure completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted to the WebUtil core bean if propertyName is not null; a null property name is silently ignored and no error is raised.
- BR-002 - The property name and value must be combined into a single 'name=value' string before being passed to WebUtil_Core.setProperty; they are never transmitted as separate arguments to the bean action.
- BR-003 - The target bean and action are fixed at WebUtil_Core.WUC_PACKAGE and WebUtil_Core.WUC_SET_LOCAL_PROPERTY respectively; callers cannot redirect the setting to a different bean or action.
- BR-004 - If the WebUtil_Core bean is not registered at the time of the call, the form must be halted via FORM_TRIGGER_FAILURE after presenting a descriptive error alert; silent continuation is not permitted.
- BR-005 - A PROPERTY_ERROR returned by the bean layer must also halt the form via FORM_TRIGGER_FAILURE; the error is treated as unrecoverable within this procedure.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-052 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via the WebUtil_DB_LOCAL subsystem or a server-side file via the JAVA_APPSERV_WRITER Java object. It tracks the remaining chunk count and, once all chunks have been received, finalises the transfer by closing the target resource, recording overall upload success, firing any registered callback trigger, and clearing that trigger registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-014](#SP-014--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-015](#SP-015--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-016](#SP-016--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-023](#SP-023--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-027](#SP-027--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-028](#SP-028--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-055](#SP-055--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or an empty string, mark the upload as failed (m_uploadSucceeded := false) and take no further action.
- Step 2 - Determine the write destination: if the session flag m_toDB is TRUE, delegate the write to WebUtil_DB_LOCAL.WriteData; otherwise call JAVA_APPSERV_WRITER.WriteData against the persistent Java object m_persistObj.
- Step 3 - Handle a file-write failure: if JAVA_APPSERV_WRITER.WriteData returns FALSE, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception to abort processing.
- Step 4 - Decrement the outstanding chunk counter (m_chunks := m_chunks - 1).
- Step 5 - Check whether all chunks have been received (m_chunks = 0). If not, return without further action.
- Step 6 - When all chunks are received and the destination is a database BLOB (m_toDB = TRUE), call WebUtil_DB_Local.CloseBlob passing the expected file size (m_fileSize). If successful, set m_uploadSucceeded := true; otherwise log the error via WebUtil_core.Error using WebUtil_DB_Local.getLastError.
- Step 7 - When all chunks are received and the destination is a server file (m_toDB = FALSE), call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded := true; otherwise retrieve the error code and arguments, log the error, delete the global Java reference (ORA_JAVA.DELETE_GLOBAL_REF), and raise READWRITE_ERROR.
- Step 8 - After a successful close, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1). If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 9 - Unconditionally clear the callback trigger registration by calling WEBUTIL.CLEARCALLBACKTRIGGER(-1).

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Mark m_uploadSucceeded as FALSE and exit the procedure without writing any data.

FALSE: Proceed to determine the write destination and write the chunk.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database BLOB using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the chunk to the server file system using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path branch only)

TRUE: Retrieve error details, log the error via WebUtil_core.Error, and raise READWRITE_ERROR.

FALSE: Continue processing (decrement chunk counter).

---

DP-004

Condition: m_chunks = 0 after decrement (all expected chunks have been received)

TRUE: Proceed to close the target resource and finalise the upload.

FALSE: Return without closing; await further chunks.

---

DP-005

Condition: m_toDB is TRUE (evaluated only when m_chunks = 0)

TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob and assess the result.

FALSE: Close the server file via JAVA_APPSERV_WRITER.CloseFile and assess the result.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob returns TRUE (database-close branch)

TRUE: Set m_uploadSucceeded := true.

FALSE: Log the error using WebUtil_DB_Local.getLastError; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE (file-close branch)

TRUE: Set m_uploadSucceeded := true.

FALSE: Retrieve error details, log the error, delete the global Java object reference, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name (evaluated after successful close)

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData value is treated as an error condition; the procedure sets the upload-success flag to FALSE and performs no write operation for that invocation.
- BR-002 - Every call to SETDATA that supplies valid data must write exactly that chunk to the active transfer destination before decrementing the chunk counter; partial writes that fail at the file-system level cause an immediate READWRITE_ERROR exception.
- BR-003 - The transfer destination (database BLOB vs. server file) is determined exclusively by the session-level flag m_toDB, which must be set prior to the first SETDATA call; SETDATA itself does not alter this routing decision.
- BR-004 - The procedure tracks upload progress through the pre-initialised counter m_chunks; finalisation logic (resource close, success flag, callback) is triggered only when this counter reaches zero, ensuring all expected chunks have been processed.
- BR-005 - On completion of the final chunk, the target resource must be explicitly closed (CloseBlob for database targets, CloseFile for file-system targets) with the expected file size (m_fileSize) supplied; a failure to close is treated as an error and m_uploadSucceeded is not set to TRUE.
- BR-006 - When a file-close failure occurs on the file-system path, the global Java object reference (m_persistObj) must be deleted via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR, preventing resource leaks.
- BR-007 - If a callback trigger has been registered (WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null value) at the time the final chunk is successfully closed, that trigger is executed immediately as part of the finalisation sequence.
- BR-008 - The callback trigger registration is always cleared via WEBUTIL.CLEARCALLBACKTRIGGER(-1) after the final chunk is processed, regardless of whether a trigger was executed, ensuring no stale trigger reference persists for subsequent transfers.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-053 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value by delegating directly to the Java runtime via the JNI bridge. The function passes the property key (a0) and its new value (a1) to java.lang.System.setProperty and returns the previous value of the property as a VARCHAR2 string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Allocate a JNI argument list sized for two arguments using JNI.CREATE_ARG_LIST(2).
- Step 3 - Append the property key string (a0) to the argument list via JNI.ADD_STRING_ARG.
- Step 4 - Append the new property value string (a1) to the argument list via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty through JNI.CALL_STRING_METHOD, passing the populated argument list.
- Step 6 - Return the VARCHAR2 result, which represents the previous value of the property as returned by the Java runtime.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure follows a linear execution path from argument construction through JNI invocation to result return.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key (a0) and property value (a1) must both be supplied as non-null VARCHAR2 values, as they are passed directly to the Java runtime without intermediate validation.
- BR-002 - The JNI argument list must be constructed with exactly two string arguments in the order key then value, matching the signature of java.lang.System.setProperty(String, String).
- BR-003 - The function returns the previous value of the named system property as reported by the Java runtime; callers requiring the old value must capture the return result.
- BR-004 - This function operates exclusively through the JNI bridge and has no database interactions; all side effects are confined to the Java Virtual Machine system property store.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-054 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the current cursor item so focus can be restored when the window is subsequently hidden. This routine is invoked exclusively during WebUtil initialisation and must not execute while the form is in Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-037](#SP-037--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Locate the WebUtil hidden window handle by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store it in the local variable hWin.
- Step 3 - Check whether the form system mode is 'NORMAL'. If the form is in any other mode (e.g. Enter Query Mode), all subsequent processing is skipped entirely to avoid runtime errors.
- Step 4 - Verify that hWin is a valid, non-null window handle using WEBUTIL.ID_NULL (SP-037). If the handle is null (window not found), all subsequent processing is skipped.
- Step 5 - Evaluate the 'show' flag to determine the required action (show or hide the window).
- Step 6 - If 'show' is TRUE: record the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and storing the result in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the window using SHOW_WINDOW; then navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 7 - If 'show' is FALSE: check whether m_infoFrom holds a valid item handle using WEBUTIL.ID_NULL (SP-037); if valid, navigate focus back to m_infoFrom to restore the user's previous cursor position; then hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'

TRUE: Proceed to evaluate the window handle and the show/hide logic.

FALSE: Exit the procedure immediately without performing any window or focus operations, preventing errors during Enter Query Mode.

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) is FALSE (i.e. the hidden window handle is valid and non-null)

TRUE: Proceed to evaluate the 'show' parameter and act on the window.

FALSE: Exit the procedure without performing any window or focus operations, as the target window does not exist.

---

DP-003

Condition: The 'show' input parameter is TRUE

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the hidden window, and move focus to WEBUTIL_DUMMY_ITEM.

FALSE: Evaluate whether m_infoFrom is a valid item handle (DP-004) and then hide the window.

---

DP-004

Condition: WEBUTIL.ID_NULL(m_infoFrom) is FALSE (i.e. a prior cursor item was recorded and is valid)

TRUE: Navigate focus back to m_infoFrom before hiding the window, restoring the user's previous cursor position.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not perform any window or focus operations when the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this restriction explicitly guards against the defect documented as Bug 2955789.
- BR-002 - The WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) must exist and return a valid, non-null handle before any show or hide action is attempted; validity is confirmed via WEBUTIL.ID_NULL (SP-037).
- BR-003 - When displaying the hidden window, the current cursor item (SYSTEM.CURSOR_ITEM) must be captured and stored in m_infoFrom prior to moving focus away, so that focus can be accurately restored on hide.
- BR-004 - The window title must be set to the string 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, ensuring the displayed version label is always current.
- BR-005 - Focus restoration to m_infoFrom on hide is conditional: it is performed only if m_infoFrom holds a valid, non-null item handle as determined by WEBUTIL.ID_NULL (SP-037); if the handle is null, focus restoration is silently skipped.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-055 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the AppServerFileWriter Java class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called exclusively by WEBUTIL.SETDATA to physically write data to a server-side file during a file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string payload (a0) to the argument list by calling JNI.ADD_STRING_ARG.
- Step 4 - Invoke the WriteData method on the AppServerFileWriter Java class via JNI.CALL_BOOLEAN_METHOD, passing the object reference, the fully qualified class path, the method name, the JNI method signature, and the prepared argument list.
- Step 5 - Return the Boolean result received from the JNI call to the caller (WEBUTIL.SETDATA), indicating success or failure of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function constructs the JNI call and returns the Boolean result from the Java layer directly; all branching on success or failure is delegated to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 string (a0); the function does not perform any transformation or validation on the value before passing it to the Java layer.
- BR-002 - The Java object reference (obj) must represent a valid, pre-initialised AppServerFileWriter instance; the function does not create or validate the object itself.
- BR-003 - The function must return the Boolean result from the JNI call unmodified, allowing the caller (WEBUTIL.SETDATA) to determine whether the write succeeded.
- BR-004 - The JNI method signature '(Ljava/lang/String;)Z' is fixed; the function always targets the oracle/forms/webutil/fileTransfer/AppServerFileWriter class and its WriteData method, ensuring the correct server-side file-writer implementation is invoked.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-056 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_bshop_group_prod_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil bean layer (WHEN-CUSTOM-ITEM-EVENT trigger in vr_bshop_group_prod_fmb). It receives an event name and a delimited parameter string from the client-side bean, extracts the data payload and multi-part chunk metadata, and routes execution to the appropriate WebUtil handler routine based on the event type. Supported events cover logging, error reporting, bean registration, host-command callbacks, and file-transfer data receipt.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-018](#SP-018--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-029](#SP-029--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-048](#SP-048--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-052](#SP-052--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-053](#SP-053--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming EventName against the five permitted values ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); raise an internal unhandled exception immediately if the name is not recognised.
- Step 2 - Extract the data payload string from EventParameters by calling get_parameter_attr for the key 'WUC_DATA', storing the result in dataPayload.
- Step 3 - Extract the multi-part chunk descriptor from EventParameters by calling get_parameter_attr for the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using DelimStr.getNumber to derive chunkNumber (position 1) and PayloadChunks (position 2), both delimited by '/', establishing how many client messages compose the complete payload.
- Step 5 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG (WEBUTIL_CORE.log) with dataPayload and the non-error flag (false).
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG (WEBUTIL_CORE.log) with dataPayload and the error flag (true).
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (registerBean) with dataPayload to register the bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a number and store it in m_lastCallback; if conversion succeeds and m_lastCallback is not null, execute the corresponding trigger from the m_callbacks collection; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is null after conversion, call WEBUTIL.LOG to record that no callback trigger was specified.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to deliver the file-transfer chunk, then call WEBUTIL.SETPROPERTY to mark the 'WUT_TRANSFER_EVENT' property as 'RECEIVED' on the WUT package.
- Step 6 - On an unhandled event name exception, suppress silently (no action). All other exceptions are re-raised to the caller.

---
**Decision Points**

DP-001

Condition: EventName is not one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'.

TRUE: Raise the internal unhandled exception; execution exits the procedure silently with no further processing.

FALSE: Continue to extract payload and multi-part metadata, then proceed to event-specific routing.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to false (informational log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to true (error log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT' and TO_NUMBER conversion of dataPayload succeeds.

TRUE: Store the numeric value in m_lastCallback and proceed to DP-006.

FALSE (INVALID_NUMBER): Call WEBUTIL.ERROR reporting error code 408 for WEBUTIL_CORE.CustomEventHandler; m_lastCallback remains unset.

---

DP-006

Condition: m_lastCallback IS NOT NULL (within 'WUH_CALLBACK_EVENT' branch).

TRUE: Execute the trigger identified by m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record that the callback trigger for the host command was not specified (error flag true).

---

DP-007

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to set the transfer event status to 'RECEIVED'.

FALSE: No further routing; the event-name if-elsif chain is exhausted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five explicitly whitelisted event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; any other event name is silently discarded with no error surfaced to the caller (Bug 2839033 guard).
- BR-002 - The data payload and multi-part chunk descriptor must always be extracted from EventParameters before any event-specific logic executes, regardless of event type.
- BR-003 - For 'WUH_CALLBACK_EVENT', the payload must be a valid number representing a callback index; an INVALID_NUMBER conversion triggers error code 408 via WEBUTIL.ERROR rather than allowing an unhandled exception to propagate.
- BR-004 - A 'WUH_CALLBACK_EVENT' with a null or unconvertible callback index must not attempt trigger execution; WEBUTIL.LOG must record the missing callback condition instead.
- BR-005 - For 'WUT_TRANSFER_EVENT', the transfer data must be stored via WEBUTIL.SETDATA and the event status must be confirmed as 'RECEIVED' via WEBUTIL.SETPROPERTY before the procedure exits, ensuring the file-transfer subsystem is notified of successful receipt.
- BR-006 - Non-whitelisted event exceptions are suppressed silently; all other unexpected exceptions are re-raised to preserve standard Oracle Forms error-handling behaviour.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-057 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error condition by setting a global error flag, composing a structured error message that identifies the calling routine and the error text, and forwarding the composed message to the debug logging facility. This procedure provides a centralised error-registration mechanism used by multiple utility procedures to ensure that error state and context are captured consistently before control returns to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition is now active.
- Step 3 - Compose the global ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, thereby capping the stored message length and preserving the originating routine context.
- Step 4 - Invoke DEBUGLOG (SP-061) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK string, so that the error is written to the debug log for diagnostic purposes.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The global error flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, indicating that at least one error has occurred in the current execution context.
- BR-002 - The error message stored in ERROR_STACK must always be prefixed with the name of the calling function followed by a colon-space separator, ensuring traceability to the originating routine.
- BR-003 - The error text portion of ERROR_STACK is truncated to a maximum of 1,968 characters to prevent value errors caused by oversized string assignments.
- BR-004 - Every registered error must be forwarded to DEBUGLOG (SP-061) at severity level 99, ensuring that all error conditions are captured in the debug log regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-058 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates error messages from the Oracle Forms tool error stack (tool_err) into a single string buffer for return to the caller. If no tool-level errors exist but a SQL error is present, the function falls back to capturing the current SQLERRM message. The returned string provides a consolidated error narrative that the invoking routine can use for display or logging.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a counter variable (iCounter) and a varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error text.
- Step 2 - Check whether the tool error stack (tool_err.nerrors) contains one or more errors.
- Step 3 - If tool errors exist, iterate through each error on the stack (1 to tool_err.nerrors). For each iteration, append a newline character followed by the current tool error message (tool_err.message) to vcErrBuff, then pop that error off the stack with tool_err.pop.
- Step 4 - If appending a message would cause vcErrBuff to exceed its maximum length, a VALUE_ERROR exception is raised; the loop exits immediately to prevent overflow, and any messages already accumulated are preserved.
- Step 5 - If the tool error stack is empty but SQLERRM is not null, append a newline followed by the SQLERRM text to vcErrBuff as a fallback error source.
- Step 6 - Return vcErrBuff (which may be NULL if no errors were found, or contain one or more newline-delimited error messages) to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Enter the loop to collect and concatenate each error message from the tool error stack into vcErrBuff, popping each entry after it is read.

FALSE: Skip the loop and evaluate the SQLERRM fallback condition (DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE: Append a newline and the SQLERRM text to vcErrBuff as the sole error message.

FALSE: vcErrBuff remains unchanged (empty/null); no error text is added.

---

DP-003

Condition: Appending the next tool_err.message to vcErrBuff raises a VALUE_ERROR exception (buffer capacity of 1968 characters would be exceeded)

TRUE: Exit the iteration loop immediately, preserving all messages accumulated so far; remaining stack entries are not processed.

FALSE: Continue appending messages and popping stack entries until the loop completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer is capped at 1968 characters; any tool error message that would cause the buffer to exceed this limit is silently discarded and loop processing stops, ensuring the function never raises an unhandled overflow error to the caller.
- BR-002 - Tool error stack messages (tool_err) take precedence over SQL engine errors (SQLERRM); the SQLERRM fallback is only used when the tool error stack is empty.
- BR-003 - Each tool error message is separated from the previous content by a newline character (chr(10)), ensuring individual messages remain distinguishable within the concatenated buffer.
- BR-004 - Every tool error entry that is successfully read must be removed from the stack via tool_err.pop, preventing duplicate processing if the stack is inspected again by the caller.
- BR-005 - The function returns a varchar2 value; if no tool errors and no SQL error are present, the return value is null, which the caller must handle as a no-error condition.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-059 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by calling routines such as GET_ENVIRONMENT_STRING and READ_REGISTRY, which require a character representation of a boolean flag for further string-based processing or output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive a single BOOLEAN input parameter (ThisBoolean) from the calling routine.
- Step 2 - Evaluate the boolean value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition: ThisBoolean evaluates to TRUE.

TRUE: The function returns the VARCHAR2 string 'TRUE' to the caller.

FALSE: The function returns the VARCHAR2 string 'FALSE' to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; the only permitted return values are the string literals 'TRUE' and 'FALSE'.
- BR-002 - A BOOLEAN input that is not TRUE (including FALSE and NULL) results in the return value 'FALSE', as the logic applies no separate NULL check before the ELSE branch.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-060 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state used by calling procedures (GET_ENVIRONMENT_STRING and READ_REGISTRY) by clearing the error flag and emptying the accumulated error message stack. This ensures that any prior error condition does not carry over into a subsequent operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, removing any previously accumulated error messages from the stack.

---
**Decision Points**

No conditional decision points exist in this procedure. All steps execute unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be reset to FALSE before each new operation to prevent a stale error flag from incorrectly signalling a failure in a subsequent call.
- BR-002 - ERROR_STACK must be cleared to NULL before each new operation to ensure that error messages from a previous execution do not contaminate the error context of the next execution.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-061 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the configured debug output channel (a Windows debug viewer or a flat log file) when the current debug state is active and the message's severity level is within the permitted threshold. It is called by multiple utility procedures throughout D2kwutil.pld to record processing events, errors, and state transitions at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-065](#SP-065--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-067](#SP-067--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Check whether debugging is globally active (iDebugState ≠ 0); if debugging is inactive, exit immediately with no action.
- Step 2 - Check whether debugging has been temporarily paused (bDebugPaused = TRUE); if paused, exit immediately with no action.
- Step 3 - Compare the incoming DebugLevel against the configured threshold (iDebugLevel); if DebugLevel exceeds the threshold, exit immediately with no action.
- Step 4 - If a timestamp is enabled (bDebugTimeStamp = TRUE), format the current system time as HH24:MI:SS and append a '> ' separator to form vcDateStamp.
- Step 5 - Construct the full debug string (vcDebugString) by concatenating a zero-padded severity level indicator, the optional timestamp, the calling routine name padded to 30 characters, and a truncated portion of LogString so the total does not exceed 2,000 characters.
- Step 6 - Evaluate the active debug output mode (iDebugState).
- Step 7 - If iDebugState = 2 (Windows debug viewer mode) and the debug API is available (DEBUG_API_ENABLED = TRUE), write vcDebugString to the Windows debug viewer via WINDEBUG.
- Step 8 - If iDebugState = 2 but the debug API is unavailable, fall back to file logging by calling SETDEBUG to reconfigure output to the file channel (defaulting to 'd2kwutil.log'), log a warning message, re-invoke DEBUGLOG recursively to write the original message to the file, and set the bDebugType2Required flag to TRUE to remember that a Windows debug session was interrupted.
- Step 9 - If iDebugState ≠ 2 and the bDebugType2Required flag is TRUE and the debug API has since become available, call SETDEBUG to restore Windows debug viewer mode, log a restoration message, clear bDebugType2Required, and re-invoke DEBUGLOG recursively to write the original message to the now-restored Windows debug viewer.
- Step 10 - If iDebugState ≠ 2 and no API recovery is needed, open the configured log file in append mode using TEXT_IO, write vcDebugString as a new line, and close the file.
- Step 11 - If any unhandled exception occurs during the above steps, suppress the error and set iDebugState to 0, disabling further debug logging to prevent diagnostic code from disrupting application execution.

---
**Decision Points**

DP-001
Condition: iDebugState = 0
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to DP-002.

DP-002
Condition: bDebugPaused = TRUE
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to DP-003.

DP-003
Condition: DebugLevel > iDebugLevel
TRUE: Procedure exits immediately; the message is below the active verbosity threshold and is suppressed.
FALSE: Processing continues; the message is within the permitted threshold and will be logged.

DP-004
Condition: bDebugTimeStamp = TRUE
TRUE: The current system time (HH24:MI:SS) is formatted and prepended to the debug string.
FALSE: No timestamp is included in the debug string.

DP-005
Condition: iDebugState = 2 (Windows debug viewer mode)
TRUE: Processing attempts to write to the Windows debug viewer (DP-006).
FALSE: Processing attempts file or API-recovery logging (DP-007).

DP-006
Condition: DEBUG_API_ENABLED = TRUE (within iDebugState = 2 branch)
TRUE: vcDebugString is written to the Windows debug viewer via WINDEBUG.
FALSE: SETDEBUG is called to switch output to file mode; a warning is logged; the original message is re-logged recursively to the file; bDebugType2Required is set to TRUE.

DP-007
Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (within iDebugState ≠ 2 branch)
TRUE: SETDEBUG is called to restore Windows debug viewer mode; a restoration message is logged; bDebugType2Required is cleared; the original message is re-logged recursively to the Windows debug viewer.
FALSE: vcDebugString is appended to the configured log file via TEXT_IO.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState = 0; no output is produced and no resources are consumed.
- BR-002 - Logging is suppressed entirely when bDebugPaused = TRUE, allowing temporary suspension of output without disabling the debug subsystem.
- BR-003 - A message is only logged if its DebugLevel does not exceed the configured iDebugLevel threshold, ensuring low-priority messages are filtered out at higher verbosity settings.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit after the fixed prefix components are assembled.
- BR-005 - When iDebugState = 2 and the Windows debug API is unavailable, the procedure automatically degrades to file logging by invoking SETDEBUG, ensuring continuity of diagnostic output rather than silent failure.
- BR-006 - The fallback log file defaults to 'd2kwutil.log' when no explicit debug file name (vcDebugFile) has been configured.
- BR-007 - Once the Windows debug API becomes available again after a fallback (bDebugType2Required = TRUE and DEBUG_API_ENABLED = TRUE), the procedure automatically restores Windows debug viewer mode via SETDEBUG before writing the pending message, maintaining the originally intended output channel.
- BR-008 - Any unhandled exception within DEBUGLOG is silently caught and iDebugState is set to 0, preventing diagnostic instrumentation from propagating errors into the calling business logic.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-062 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUtil native library call D2KWUTIL_GETDOSENV. The function is available only when the WIN_API layer is enabled; if the variable cannot be resolved, it either raises an exception or returns NULL depending on the caller's preference. It is invoked by WEBUTIL.GETVAR to surface environment-variable values to Oracle Forms at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-059](#SP-059--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-060](#SP-060--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (via Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the string representation of RaiseExceptions (obtained via BOOLTOCHAR).
- Step 2 - Reset the error stack: call CLEAN_ERROR_STACK to clear any previously recorded WIN_API errors before processing begins.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check API availability: evaluate WIN_API.API_ENABLED.
- Step 5 - If the API is available, register the native function handle by calling REGISTER_FUNCTION_CALL, supplying the function slot iGetDOSEnv, the external name 'd2kwutil_GetDOSEnv', and its parameter-type signature ('LONG','*CHAR,*CHAR,LONG').
- Step 6 - Prepare the call buffers: wrap VariableName in '%' delimiters to form vcBuff1 (the environment-variable token), initialise vcBuff2 as a 512-character null-padded output buffer, and set iBuff1 to 512 as the buffer length.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing vcBuff1, vcBuff2, and iBuff1; capture the integer return code in iRC.
- Step 8 - Log the result: call DEBUGLOG at trace level 99 to record the returned value length (iRC) and the resolved value (vcBuff2).
- Step 9 - If the API is not available, raise the WIN_API.NOT_AVAILABLE exception.
- Step 10 - Evaluate the resolution outcome: if iRC = 0 or vcBuff2 still equals the unexpanded token vcBuff1, the variable was not found; call ADD_ERROR to record the failure message.
- Step 11 - If the variable was not found and RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise return NULL.
- Step 12 - If the variable was resolved successfully, return vcBuff2 (the environment-variable value).
- Step 13 - Exception handling: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the WIN_API.NoAPI message then re-raise; for all other exceptions, call ADD_ERROR with WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Register the native function handle via REGISTER_FUNCTION_CALL, prepare call buffers, and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to attempt resolution of the environment variable.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all resolution logic.

---

DP-002

Condition: iRC = 0 OR vcBuff2 equals the unexpanded token vcBuff1 (i.e., the environment variable could not be resolved).

TRUE: Call ADD_ERROR to record the failure, then proceed to DP-003 to determine how to signal the failure to the caller.

FALSE: Return vcBuff2 as the resolved environment-variable value.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND so the caller receives an exception.

FALSE: Return NULL to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment-variable lookup when WIN_API.API_ENABLED is TRUE; if the API layer is unavailable, the function raises WIN_API.NOT_AVAILABLE unconditionally and no resolution is attempted.
- BR-002 - The environment-variable name must be wrapped in '%' delimiters (forming the token '%VariableName%') before being passed to D2KWUTIL.D2KWUTIL_GETDOSENV; this is the required format for the native call.
- BR-003 - A resolution is considered failed if the native call returns iRC = 0 or if the output buffer vcBuff2 still contains the unexpanded token; in either case an error is recorded via ADD_ERROR.
- BR-004 - The caller controls the failure-signalling behaviour through the RaiseExceptions parameter: TRUE causes a NO_DATA_FOUND exception to propagate; FALSE causes a silent NULL return, allowing the caller to handle the absence of the variable without exception handling.
- BR-005 - The output buffer is fixed at 512 characters; environment-variable values exceeding this length will be truncated.
- BR-006 - All exceptions except NO_DATA_FOUND are enriched with external error detail via ADD_EXTERNAL_ERRORS before being re-raised, ensuring the full error context is preserved for upstream handlers.
- BR-007 - Diagnostic logging via DEBUGLOG is performed unconditionally at both entry and after the native call, recording input arguments and resolution results at trace level 99.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-063 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows registry for a given registry path and entry key. It translates the root hive portion of the supplied path into a numeric constant, delegates the low-level registry read to the D2KWUTIL native library call D2KWUTIL_GETREGKEY, and returns the value as a VARCHAR2 string. Callers may opt into exception-raising mode; otherwise the function returns NULL on failure and logs all errors to the WIN_API error stack via ADD_ERROR.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-059](#SP-059--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-060](#SP-060--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the input arguments RegPath, RegEntry, and the string representation of RaiseExceptions (obtained via BOOLTOCHAR).
- Step 2 - Clear the error stack: call CLEAN_ERROR_STACK to reset any previously accumulated WIN_API errors before processing begins.
- Step 3 - Check API availability: evaluate WIN_API.API_ENABLED; if FALSE, raise the WIN_API.NOT_AVAILABLE exception immediately, bypassing all further logic.
- Step 4 - Register the native function handle: call REGISTER_FUNCTION_CALL to bind the iGetRegKey handle to the D2KWUTIL_GETREGKEY native entry point with its expected signature ('INT','INT,*CHAR,*CHAR,*CHAR,INT,INT').
- Step 5 - Resolve the registry root hive: extract the portion of RegPath preceding the first backslash, convert it to upper case, and map it to the corresponding numeric constant (0 = HKEY_LOCAL_MACHINE, 1 = HKEY_CLASSES_ROOT, 2 = HKEY_CURRENT_USER, 3 = HKEY_USERS, 4 = HKEY_CURRENT_CONFIG). If the root hive is unrecognised, log an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call buffers: set the sub-path buffer (vcBuff1) to the portion of RegPath after the first backslash, set the entry name buffer (vcBuff2) to RegEntry, initialise the 2000-byte result buffer (vcBuff3) padded with CHR(0), and set the buffer length indicator (iBuff2) to 2000.
- Step 7 - Apply compatibility flag: if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3 to 1 to suppress environment-variable expansion and log a compatibility debug message via DEBUGLOG; otherwise set iBuff3 to 0 to allow expansion.
- Step 8 - Execute the native registry read: invoke D2KWUTIL_GETREGKEY with the resolved function handle, root hive constant, sub-path, entry name, result buffer, buffer length, and expansion flag; capture the integer return code in iRC.
- Step 9 - Log the raw result: call DEBUGLOG (severity 99) recording iRC and the contents of vcBuff3.
- Step 10 - Evaluate the return code and handle errors: inspect iRC for the four defined failure codes (-1 entry not found, -2 unsupported data type, -3 value exceeds buffer, -4 environment string expansion failure); for each, call ADD_ERROR with a descriptive message, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on the RaiseExceptions flag.
- Step 11 - Return the registry value: if iRC indicates success (none of the error codes apply), return vcBuff3 containing the retrieved registry value string.
- Step 12 - Exception handling: re-raise NO_DATA_FOUND and VALUE_ERROR as-is; on WIN_API.NOT_AVAILABLE call ADD_ERROR with the NoAPI message then re-raise; on any other exception call ADD_ERROR with the generic error message concatenated with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root hive resolution, and the registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately; no registry access is attempted.

DP-002
Condition: The extracted root hive string (upper-cased prefix of RegPath before the first backslash) matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant to iBuff1 and continue.
FALSE: Call ADD_ERROR reporting an invalid registry key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (subsequent call to D2KWUTIL_GETREGKEY will use an uninitialised iBuff1).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE.
TRUE: Set iBuff3 to 0, allowing D2KWUTIL_GETREGKEY to expand environment variable references within the registry value.
FALSE: Set iBuff3 to 1, suppressing environment variable expansion; log a compatibility debug message via DEBUGLOG.

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (registry entry not found).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent error codes (DP-005 through DP-007).

DP-005
Condition: iRC equals -2 (registry value is an unsupported data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent error codes (DP-006 through DP-007).

DP-006
Condition: iRC equals -3 (registry value length exceeds the 2000-byte buffer).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise VALUE_ERROR.
FALSE: Evaluate DP-007.

DP-007
Condition: iRC equals -4 (environment string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: No error condition applies; return vcBuff3 as the retrieved registry value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute when the WIN_API layer is available (WIN_API.API_ENABLED is TRUE); if the API is unavailable the WIN_API.NOT_AVAILABLE exception is raised unconditionally, regardless of the RaiseExceptions flag.
- BR-002 - RegPath must begin with one of exactly five recognised Windows registry root hives (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other root hive is treated as an error.
- BR-003 - The registry value buffer is fixed at 2000 bytes; any registry entry whose value exceeds this limit is treated as a retrieval failure with return code -3 and raises VALUE_ERROR when RaiseExceptions is TRUE.
- BR-004 - Environment variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when FALSE, expansion is suppressed to maintain compatibility with calling contexts that do not expect expanded strings.
- BR-005 - When RaiseExceptions is FALSE, all recoverable error conditions (entry not found, unsupported type, buffer overflow, expansion failure) result in a NULL return value rather than a raised exception, allowing callers to handle absence of a registry value gracefully.
- BR-006 - When RaiseExceptions is TRUE, all recoverable error conditions result in a raised exception (NO_DATA_FOUND for codes -1, -2, -4; VALUE_ERROR for code -3), giving callers the option to enforce mandatory registry values.
- BR-007 - Every error condition, including unhandled exceptions, must be recorded on the WIN_API error stack via ADD_ERROR before the exception is propagated; for unhandled exceptions the error message is supplemented with output from ADD_EXTERNAL_ERRORS.
- BR-008 - Debug logging at severity level 99 must be performed at function entry (recording all input arguments) and immediately after the D2KWUTIL_GETREGKEY call (recording the return code and retrieved value), providing a full audit trail of each registry read attempt.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-064 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

REGISTER_FUNCTION_CALL ensures that a named DLL function is correctly registered with the Oracle FFI layer before it is invoked. It verifies that the target DLL is loaded, registers the function handle along with all typed parameters and the return type, and caches a load-count marker to avoid redundant re-registration. If the DLL is unavailable or FFI registration fails, the procedure disables the API and raises NO_DATA_FOUND to halt further processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-049](#SP-049--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the current session by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not yet loaded), delegate to D2KWUTIL.ATTEMPT_DLL_LOAD, passing DLL_Path and DLL_NAME, to attempt a fresh load and obtain a new DLL handle.
- Step 3 - If ATTEMPT_DLL_LOAD also raises an FFI error, set the package flag API_ENABLED to FALSE, record an error via ADD_ERROR with source 'D2KWUTIL' and a message indicating the DLL was not found, then raise NO_DATA_FOUND to abort.
- Step 4 - Check whether the function has already been registered by testing whether FunctionLoad(FunctionId) exists and whether its stored load-count equals the current DLL_LOAD_COUNT. If either condition fails, proceed with (re-)registration.
- Step 5 - Register the function handle by calling ORA_FFI.REGISTER_FUNCTION against the current DLL handle, using FunctionName and the C_STD calling convention, and store the result in FunctionHandle(FunctionId).
- Step 6 - If FunctionName is not 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (level 99, routine 'Register_Function_Call') indicating whether this is an initial registration or a re-registration, including the current DLL_LOAD_COUNT.
- Step 7 - Parse the FunctionArgs string by appending a trailing comma and iterating: for each comma-delimited token, call D2KWUTIL.TRANSLATETYPE to convert the type token to its FFI constant, then register it as a parameter via ORA_FFI.REGISTER_PARAMETER against the function handle. Continue until the argument string is exhausted, NULL, or equals 'VOID,'.
- Step 8 - If FunctionReturn is not 'VOID' (case-insensitive) and is not NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the result as the function's return type via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store DLL_LOAD_COUNT in FunctionLoad(FunctionId) to mark this function as registered for the current DLL load cycle, preventing unnecessary future re-registration.
- Step 10 - In the outer exception handler, if any FFI error occurs during registration, call ADD_ERROR with the FunctionName and a combined error message built from Win_API.UError and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL by DLL_NAME.

TRUE: DLL_HANDLE is set and processing continues to the registration check (DP-002).

FALSE: An FFI error is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is invoked to reload the DLL (see DP-002b).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds after FIND_LIBRARY failed.

TRUE: A new DLL_HANDLE is obtained and processing continues to the registration check.

FALSE: An FFI error is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised to abort.

---

DP-003

Condition: FunctionLoad(FunctionId) does not exist OR FunctionLoad(FunctionId) does not equal DLL_LOAD_COUNT.

TRUE: The function is not yet registered or the DLL has been reloaded; the full registration sequence (Steps 5-9) is executed.

FALSE: The function is already registered for the current DLL load cycle; the registration block is skipped entirely.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: The DEBUGLOG diagnostic call is suppressed to avoid recursive logging.

FALSE: DEBUGLOG is called to record whether this is an initial registration or a re-registration.

---

DP-005

Condition: FunctionLoad(FunctionId) does not exist (within the DEBUGLOG branch).

TRUE: DEBUGLOG records an 'Initial Reg' message.

FALSE: DEBUGLOG records a 'Re-Registration' message including the previous load count.

---

DP-006

Condition: The remaining FunctionArgs string is not NULL, not equal to ',', and not equal to 'VOID,'.

TRUE: The next comma-delimited type token is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered as a parameter; the loop continues.

FALSE: Parameter registration loop exits.

---

DP-007

Condition: The current comma position (iOffset) equals the total length of the vcArgs string.

TRUE: vcArgs is set to NULL to terminate the loop after registering the last parameter.

FALSE: vcArgs is advanced past the current comma to process the next token.

---

DP-008

Condition: FunctionReturn is not 'VOID' (case-insensitive) AND FunctionReturn is not NULL.

TRUE: D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and the result is registered as the FFI return type.

FALSE: No return type is registered (procedure-style call or explicitly void function).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or recoverable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and the call is aborted.
- BR-002 - API_ENABLED must be set to FALSE whenever the DLL cannot be loaded, ensuring that subsequent callers do not attempt to invoke unavailable native functions.
- BR-003 - A function is re-registered only when its cached load-count (FunctionLoad(FunctionId)) is absent or differs from the current DLL_LOAD_COUNT, preventing redundant FFI registration overhead within the same DLL load cycle.
- BR-004 - All parameter type tokens supplied in FunctionArgs must be translated through D2KWUTIL.TRANSLATETYPE before being passed to the FFI layer; raw string type names are not accepted directly by ORA_FFI.
- BR-005 - A return type is registered only when FunctionReturn is non-NULL and not equal to 'VOID' (case-insensitive); void or unspecified returns must not produce an FFI return-type registration.
- BR-006 - The function 'd2kwutil_DebugString' is explicitly excluded from DEBUGLOG tracing during its own registration to prevent recursive logging.
- BR-007 - On any FFI error during the registration sequence, ADD_ERROR must be called with the FunctionName and a combined error message from ADD_EXTERNAL_ERRORS before raising NO_DATA_FOUND, ensuring the error is surfaced to the caller.
- BR-008 - FunctionArgs must be supplied as a comma-delimited string; the procedure appends a trailing comma internally and treats a NULL, bare-comma, or 'VOID,' value as the signal to skip parameter registration.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-065 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the debug output type (file, screen, or off), the target log file name, the verbosity level, and whether log entries should include a timestamp. Once configured, the procedure activates or deactivates the logging state and records an initialisation entry via DEBUGLOG to confirm the new logging mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-061](#SP-061--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Persist the incoming TimeStamp flag to the package-level variable bDebugTimeStamp, controlling whether subsequent log entries include a timestamp.
- Step 2 - Persist the incoming DebugFile value to the package-level variable vcDebugFile, identifying the target output file for file-based logging.
- Step 3 - Persist the incoming DebugLevel value to the package-level variable iDebugLevel, setting the verbosity threshold for all subsequent debug calls.
- Step 4 - Evaluate the DebugType parameter to determine the logging mode to activate (see Decision Points).
- Step 5 - Set the package-level state variable iDebugState to the resolved mode (1 = file logging, 2 = screen/alternate logging, 0 = logging off).
- Step 6 - Call DEBUGLOG at level 0 with the caller identifier 'SetDebug' and a mode-specific confirmation message to record that the logging configuration has changed.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging) and call DEBUGLOG with the message 'Logging to File ' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (alternate/screen logging) and call DEBUGLOG with the message 'Logging Started'.

FALSE: Call DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, disabling all logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType must be 1 to enable file-based logging; any value other than 1 or 2 is treated as a request to stop logging entirely (iDebugState = 0).
- BR-002 - DebugFile defaults to NULL and is only meaningful when DebugType = 1; for all other modes the file name is stored but not used to route output.
- BR-003 - DebugLevel defaults to 98, establishing the maximum verbosity threshold unless the caller explicitly supplies a lower value.
- BR-004 - TimeStamp defaults to FALSE; timestamp decoration on log entries is opt-in and must be explicitly requested by the caller.
- BR-005 - Every invocation of SETDEBUG must produce exactly one DEBUGLOG entry at level 0 confirming the resulting logging state, ensuring an audit trail of configuration changes.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-066 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning a clean, single-path value ready for use in DLL load operations invoked by D2KWUTIL.ATTEMPT_DLL_LOAD.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a working copy of the input path (InPath) into a local variable (vcPath) to preserve the original parameter.
- Step 2 - Search vcPath for the first occurrence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate vcPath to retain only the substring preceding the semicolon, discarding any additional path entries that follow.
- Step 4 - Inspect the last character of the (possibly truncated) vcPath for a trailing backslash ('\').
- Step 5 - If a trailing backslash is present, remove it by taking the substring from position 1 to one character less than the current length of vcPath.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path string contains at least one semicolon character.

TRUE: vcPath is truncated to the substring before the first semicolon, retaining only the first path entry in a semicolon-delimited list.

FALSE: vcPath is left unchanged and processing continues to DP-002.

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of vcPath is a backslash directory separator.

TRUE: The trailing backslash is stripped by replacing vcPath with SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE: vcPath is left unchanged and the value is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - When a path string contains one or more semicolons, only the portion before the first semicolon is considered a valid path; all subsequent entries are discarded.
- BR-002 - A valid path must not end with a backslash directory separator; if one is present it must be removed before the path is returned.
- BR-003 - The function operates exclusively on the supplied input string and does not modify any persisted data; the original parameter value is never altered directly.
- BR-004 - The sanitised path is limited to a maximum working length of 500 characters, consistent with the local variable declaration.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-067 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a bridge between Oracle Forms and the D2KWUTIL Windows API debug-string facility. It accepts a text string and forwards it to the native D2KWUTIL_DEBUGSTRING function via a registered Windows API function handle, enabling low-level debug output from within the Forms runtime environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-057](#SP-057--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-058](#SP-058--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-064](#SP-064--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer (vcBuff1).
- Step 2 - Check whether the Windows API layer is available by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is available, register the target function call by invoking REGISTER_FUNCTION_CALL, associating the internal debug-string handle (iDebugString) with the external function name 'd2kwutil_DebugString' and its parameter signature ('*CHAR').
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared text buffer (vcBuff1) to emit the debug string through the Windows API.
- Step 5 - If the API is not available, raise the WIN_API.NOT_AVAILABLE exception to signal that the debug channel cannot be used.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR to log the failure context ('WinDebug', WIN_API.NoAPI) and re-raise the exception to the caller.
- Step 7 - On any other exception, call ADD_ERROR with the combined error detail from WIN_API.UError and ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the Windows API function call via REGISTER_FUNCTION_CALL and forward the debug string to D2KWUTIL.D2KWUTIL_DEBUGSTRING using the resolved function handle.

FALSE: Raise WIN_API.NOT_AVAILABLE to indicate that the Windows API layer is not accessible.

---

DP-002

Condition: Exception raised is WIN_API.NOT_AVAILABLE.

TRUE: Log the error using ADD_ERROR with the 'WinDebug' context and WIN_API.NoAPI error code, then re-raise the exception.

FALSE: Treat the exception as an unclassified error; log it using ADD_ERROR with WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be enabled (WIN_API.API_ENABLED = TRUE) before any attempt is made to emit a debug string; if the API is unavailable the procedure must raise WIN_API.NOT_AVAILABLE rather than silently swallowing the call.
- BR-002 - The input text is always extended with a newline character (CHR(10)) before being passed to the debug-string function, ensuring each debug entry is terminated on its own line.
- BR-003 - The Windows API function call must be formally registered via REGISTER_FUNCTION_CALL with the correct function name ('d2kwutil_DebugString') and parameter type signature ('*CHAR') before the function handle is resolved and used.
- BR-004 - All exceptions must be re-raised after logging so that the calling context (DEBUGLOG in D2kwutil.pld) is aware of the failure; errors must not be silently consumed.
- BR-005 - Unclassified runtime errors must incorporate both the internal error descriptor (WIN_API.UError) and any external error detail retrieved via ADD_EXTERNAL_ERRORS to provide a complete diagnostic record.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Business Scenarios - How the report data differs by Exchange Status
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Invoice Header - MULDMS.SH_INVOICE
    - Old Vehicle Evaluation - MULDMS.SH_TV_EVAL
    - Sales Order - MULDMS.SH_ORDBOOK
    - Dealer Location - MULDMS.AM_DEALER_LOC
    - Employee Master - MULDMS.GM_EMP
    - Vehicle Variant - MULDMS.GM_VAR
    - Vehicle Model - MULDMS.GM_MOD
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (Report User - before report submission)
    - Session and Control Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-006 - D2KWUTIL.TRANSLATETYPE
    - SP-007 - GENERAL.ASK_CONFIRM
    - SP-008 - GENERAL.DISP_TEXT
    - SP-009 - GENERAL.RAISE_ERROR
    - SP-010 - WEBUTIL.BLOCKING
    - SP-011 - WEBUTIL.CHECKLIBS
    - SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-013 - WEBUTIL.CLOSEBLOB
    - SP-014 - WEBUTIL.CLOSEFILE
    - SP-015 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-016 - WEBUTIL.ERROR
    - SP-017 - WEBUTIL.ERRORALERT
    - SP-018 - WEBUTIL.EXECUTE
    - SP-019 - WEBUTIL.FCLOSE
    - SP-020 - WEBUTIL.FOPEN
    - SP-021 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-022 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-023 - WEBUTIL.GETCLIENTSETTING
    - SP-024 - WEBUTIL.GETIMPLCLASS
    - SP-025 - WEBUTIL.GETLASTERROR
    - SP-026 - WEBUTIL.GETLASTERRORARGS
    - SP-027 - WEBUTIL.GETNUMBER
    - SP-028 - WEBUTIL.GETOSFAMILY
    - SP-029 - WEBUTIL.GETOUTPUT
    - SP-030 - WEBUTIL.GETPROPERTY
    - SP-031 - WEBUTIL.GETSTRING
    - SP-032 - WEBUTIL.GETVAR
    - SP-033 - WEBUTIL.GET_LINE
    - SP-034 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-035 - WEBUTIL.ID_NULL
    - SP-036 - WEBUTIL.INIT
    - SP-037 - WEBUTIL.INITWEBUTIL
    - SP-038 - WEBUTIL.ISERROR
    - SP-039 - WEBUTIL.IS_OPEN
    - SP-040 - WEBUTIL.LENGTH
    - SP-041 - WEBUTIL.LOG
    - SP-042 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-043 - WEBUTIL.PUT_LINE
    - SP-044 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-045 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-046 - WEBUTIL.REGISTERBEAN
    - SP-047 - WEBUTIL.REGISTER_FUNCTION
    - SP-048 - WEBUTIL.RELEASE_PROCESS
    - SP-049 - WEBUTIL.SETCLIENTSETTING
    - SP-050 - WEBUTIL.SETDATA
    - SP-051 - WEBUTIL.SETPROPERTY
    - SP-052 - WEBUTIL.SHOWBEANS
    - SP-053 - WEBUTIL.WRITEDATA
    - SP-054 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-055 - ADD_ERROR
    - SP-056 - ADD_EXTERNAL_ERRORS
    - SP-057 - BOOLTOCHAR
    - SP-058 - CLEAN_ERROR_STACK
    - SP-059 - DEBUGLOG
    - SP-060 - GET_ENVIRONMENT_STRING
    - SP-061 - READ_REGISTRY
    - SP-062 - REGISTER_FUNCTION_CALL
    - SP-063 - SETDEBUG
    - SP-064 - SF_COPYRIGHT_DECLARATION
    - SP-065 - STRIPDIRSEP
    - SP-066 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | SR_EXCH_TRADEIN - Business Requirements Document |
| Form Module Name | SR_EXCH_TRADEIN |
| Document Version | 1.0 |
| Date Created | August 04, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 04, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the sr_exch_tradein Exchange Trade-In Report form, its purpose, and roles referenced in the module.*

The **sr_exch_tradein** Oracle Forms module is the dealership **Exchange and Trade-In Report** screen. A dealer user opens the form, selects the dealer and outlet, chooses the exchange status category - Bought, Evaluation, Cancelled, or Bought and Evaluation combined - and applies optional filters for vehicle model, variant, registration number, third-party outlet, buying category, and invoice type. The user must enter a date range of no more than three months; the system enforces that the start date is mandatory, not in the future, and does not exceed the end date, and that the end date is within three months of the start date. Once the criteria are confirmed, the user submits the request and the form produces a detailed CSV report of exchange and trade-in transactions matching the selected criteria. The report covers old vehicle details (registration, model, mileage, evaluation date, buying price), new vehicle details (VIN, model, variant, engine number), customer and outlet information, exchange bonus breakdowns, loyalty claim status, and vehicle verification data. The form performs no data entry or data modification; its sole function is report generation and export.

### Key Stakeholders

*Who uses sr_exch_tradein*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer / Outlet User** | **Primary interactive user.** Selects filter criteria, specifies the date range, and submits the report to export exchange and trade-in transaction data for their dealer and outlet. |
| **Dealer Management** | Receives and reviews the exported CSV report to analyse exchange bonus claims, trade-in volumes, and transaction status across the dealership. |
| **Vehicle Customer** | Customer details (name, registration, vehicle information) are captured in the report data; the customer does not use the form directly. |

---

---

## 3. System Context

*Describes the sr_exch_tradein module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **sr_exch_tradein** module is the dealership **Exchange and Trade-In Report** screen within the Dealer Management System. It provides authorised dealer users with a reporting tool to extract exchange and trade-in transaction data, filtered by dealer, outlet, exchange status, vehicle attributes, and date range, and exported as a CSV file for analysis and compliance purposes.

**System purpose:** Enable dealer users to specify search criteria - including dealer, outlet, exchange status, model, variant, and a date range of up to three months - validate the inputs, and generate a detailed CSV export of exchange and trade-in transactions as implemented in the sr_exch_tradein Oracle Forms module.

**In scope:**

- Select the dealer and outlet location applicable to the report
- Choose the exchange status category: Bought, Evaluation, Cancelled, or Bought and Evaluation combined
- Apply optional filters for vehicle model, variant, old vehicle registration number, third-party outlet, buying category, and invoice type
- Enter and validate a mandatory date range (start date and end date, maximum three months)
- Submit the request to generate and export the transaction report as a CSV file
- Display the report title and a copyright declaration on the form
- Clear the form and reset all parameters for a new report request

**Process Name:** Exchange Trade-In Report Generation

**Process Owner:** Dealer Sales Manager

**Process Objective:** Open the report form, select the dealer and outlet, choose an exchange status and optional vehicle filters, validate the date range, submit the request, and export the resulting exchange and trade-in transaction data as a CSV file.

**Process Trigger:** Dealer user requires an exchange and trade-in transaction report for a specific period or set of criteria

**Process Flow:**

The complete exchange trade-in report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The dealer user opens the Exchange Trade-In Report screen.
         The application session is registered. The report title "Exchange TradeIn Report"
         and the copyright declaration are populated automatically.

STEP 2 ── DEALER SELECTION
         The user selects a dealer from the Dealer LOV, which lists all dealers
         accessible to the logged-in user for the current principal.
         The dealer code, dealer map code, and parent group are populated automatically
         on selection.

STEP 3 ── OUTLET SELECTION
         The user selects an outlet location from the Outlet LOV, which lists
         locations for the selected dealer and parent group.
         The outlet location code and description are populated.

STEP 4 ── DEALER AND OUTLET VALIDATION
         When the user leaves the dealer field, the system checks that the dealer
         code is not empty and raises an error if it is.
         When the user leaves the outlet field, the system checks that the outlet
         code is not empty and raises an error if it is.

STEP 5 ── EXCHANGE STATUS SELECTION
         The user selects the exchange status from a list:
         ├── B  (Bought): invoiced trade-in transactions where the old vehicle was purchased
         ├── E  (Evaluation): trade-in transactions under evaluation, not yet purchased
         ├── C  (Cancelled): cancelled exchange transactions
         └── BE (Bought + Evaluation): combined report covering both Bought and Evaluation
         The exchange status field is mandatory; an error is shown if it is left empty.

STEP 6 ── OPTIONAL FILTER - VEHICLE MODEL
         The user may select a vehicle model from the Model LOV, which lists all
         models for the current principal. Selecting a model filters the report
         to that model. Leaving it blank reports all models.

STEP 7 ── OPTIONAL FILTER - VEHICLE VARIANT
         The user may select a variant from the Variant LOV, which lists variants
         for the selected model. Leaving it blank reports all variants.

STEP 8 ── OPTIONAL FILTER - TV OUTLET
         The user may select a third-party (TV) outlet from the TV Outlet LOV,
         which lists outlets for the selected dealer and for-code.
         Leaving it blank reports all outlets.

STEP 9 ── OPTIONAL FILTER - REGISTRATION NUMBER
         The user may enter an old vehicle registration number to narrow the
         report to a single vehicle. Leaving it blank includes all registrations.

STEP 10 ── OPTIONAL FILTER - BUYING CATEGORY AND INVOICE TYPE
          The user may select a buying category (TV, NTV, or All) and an invoice
          type to further narrow the result set.

STEP 11 ── FROM DATE ENTRY AND VALIDATION
          The user enters the report start date. The system enforces:
          ├── The start date must not be null
          ├── The start date must not be greater than today's date
          └── The start date must not be greater than the end date
          If the start date passes validation, the system automatically sets the
          end date to one month after the start date (capped at today's date).

STEP 12 ── TO DATE ENTRY AND VALIDATION
          The user enters or confirms the report end date. The system enforces:
          ├── The end date must not be null
          ├── A start date must have been entered first
          ├── The end date must not be less than the start date
          ├── The end date must not be greater than today's date
          └── The date range must not exceed three months

STEP 13 ── SUBMIT - REPORT GENERATION
          The user clicks the Submit button. The system builds a dynamic SQL
          query based on the selected exchange status and all applied filters,
          joining invoice, evaluation, order book, dealer location, model,
          variant, and employee data.

STEP 14 ── EXCHANGE STATUS BRANCH - QUERY SELECTION
          ├── B  (Bought): queries invoiced trade-in records where old vehicle status is Bought or Live
          ├── E  (Evaluation): queries evaluation records not yet converted to a purchase
          ├── C  (Cancelled): queries cancelled exchange transactions by cancellation date
          └── BE (Bought + Evaluation): executes both Bought and Evaluation queries combined

STEP 15 ── CSV FILE EXPORT
          The system generates a uniquely named CSV file (user ID + timestamp)
          containing all report columns, including old vehicle details, new vehicle
          details, bonus amounts, claim status, and Vahan verification data.
          The CSV is written to the server and made available for download.

STEP 16 ── ERROR HANDLING
          If any form error occurs during parameter entry or submission, the
          system displays a user-friendly error message and prevents progression
          until the issue is resolved.

STEP 17 ── CLEAR AND RESET (optional)
          The user may clear the form at any time. All filter fields are reset
          and the report title and copyright declaration are repopulated.
```

**Major process interactions:**

- **Dealer and user access master data** - identifies accessible dealers and outlet locations for the logged-in user
- **Vehicle model and variant master data** - provides model and variant lists for report filtering
- **TV outlet master data** - provides third-party outlet list filtered by dealer and for-code
- **Exchange and trade-in transaction data** - the primary source of invoice, evaluation, order book, and old vehicle records for the report
- **Bonus and claim data** - loyalty exchange bonus amounts and claim submission status included in the exported report
- **Vahan vehicle verification data** - vehicle registration and verification details appended to the report output
- **Employee master data** - resolves salesman names and MSPIN codes for new vehicle DSE columns in the report

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Initialisation and Application Performance Logging

**Business Description:**
When the Exchange Trade-In reporting screen is opened, the application registers the current session in the database with the module identity, enabling system administrators to monitor active form usage and correlate performance timing data. If the application-level performance logging option is enabled for this environment, a stopwatch timer is started so that the time taken to open the form can be captured for performance analysis. Once that session registration is complete, the main window is maximised to fill the screen, the report name label is set to its default title, the invoice date fields are pre-filled with the current month's range, and screen field labels are adjusted to match whether the principal context is a car dealership or a general vehicle context. The copyright declaration is loaded from the system, and the global application identifier is set so that downstream components can identify this form.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has been authenticated and has access to launch the Exchange Trade-In reporting screen.

**Main Flow:**

**Step 1 - Application session tracking is registered**
Before the form opens, the application writes its module identity (`sr_exch_tradein`) to the current database session context using the application information service. This allows system administrators to identify which application module is running for this session and trace any database activity back to the Exchange Trade-In report form.

**Step 2 - Performance timer is started if logging is active**
If the environment has application performance logging switched on (global flag `GLOBAL.APP_LOG` is set to `'Y'`), a timing measurement is started at this point so that the duration of the form-open operation can be recorded and reviewed during performance monitoring exercises. If logging is not switched on, this step is skipped and no timer runs.

**Step 3 - Main window is maximised**
The main application window (`WN_MAIN`) and the MDI host window are both maximised so that the form occupies the full available screen area.

**Step 4 - Report name label is set to its default title**
The report name display field is set to the fixed value *'Exchange TradeIn Report'*, establishing the standard label visible to the user at the top of the screen.

**Step 5 - Invoice date range is pre-filled with the current month's boundaries**
The Invoice From Date field is set to the first day of the current calendar month and the Invoice To Date field is set to today's date, giving the user a convenient default date range covering the current month without manual input.

*Procedures called:*
- **FIRST_DAY** - calculates the first calendar day of the month containing the supplied date and returns it as the default From Date.

**Step 6 - Screen field labels are adjusted for the principal context**
If the current principal is identified as a car dealership context (principal code = 1), the screen field labels for the buying category, registration number, model, and variant filters are set to 'Old Car Buying Category', 'Old Car Reg Num', 'Old Car Model', and 'Old Car Variant' respectively. For all other principal contexts, those same fields are labelled 'Old Vehicle Buying Category', 'Old Vehicle Reg Num', 'Old Vehicle Model', and 'Old Vehicle Variant'.

**Step 7 - Copyright declaration is loaded**
The copyright declaration text is retrieved from the system and placed in the copyright display field on the screen, ensuring the current legal notice is always shown when the form opens.

**Step 8 - Global application identifier is set**
The global application identifier seed `GLOBAL.APP_ID` is set to `'sr_exch_tradein'` and propagated to the application-level parameter `PARAMETER.P_APP_ID`. This seed value is used by downstream components (such as the report file-generation routine) to identify the originating form module.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) If application performance logging is not enabled for this environment, no timer is started and the form opens without any timing instrumentation.
- **BR-001-AF-02** - (from Step 6) If the principal is not code 1, the vehicle-generic field labels ('Old Vehicle ...') are applied instead of the car-specific labels ('Old Car ...').

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | Y / (other) | User authenticated | System-managed session global; controls whether the performance timer starts | N/A |
| Report Description (`REPORT_DESC`) | Auto-populated | Display item | 200 | N/A | Fixed value: *'Exchange TradeIn Report'* | Form open | System-set on form open; not user-editable | N/A |
| Inv From Date (`P_FROMDT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | First day of current month | Form open | Pre-filled automatically; user may change before submitting | N/A |
| To Date (`P_TODT`) | Auto-populated | Date | 10 / DD/MM/RRRR | N/A | Today's date | Form open | Pre-filled automatically; user may change before submitting | N/A |
| Application ID (`GLOBAL.APP_ID`) | Auto-populated | Character | 50 | N/A | Fixed seed value: `'sr_exch_tradein'` | Form open | System-set global; identifies this form to downstream report components | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Drop-Down List Population from Master Configuration

**Business Description:**
The report filter screen presents several drop-down selection fields - such as buying category and exchange status - whose available options are not hardcoded but are loaded at runtime from the central master configuration. This ensures that any changes made to the master list by system administrators (adding, retiring, or renaming options) are reflected immediately in the report filter without a form change. The loading routine queries the master configuration for the named list and applies the retrieved options to the drop-down field on screen.

**Actors:** System (automatic; called whenever a list field needs to be populated)

**Preconditions:**
- The named list exists in the master configuration with at least one active entry for the current principal.

**Main Flow:**

**Step 1 - Drop-down options are loaded from the master configuration**
When a drop-down field on the screen needs to be populated, the system queries the master configuration for all entries belonging to the named list for the active principal, then fills the drop-down with those entries so the user can make a selection. Any previously loaded options are cleared first to prevent duplicates. The retrieved code-description pairs are applied to the field so the user can pick from the current list.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Old Vehicle Buying Category (`P_BUY_CATEG`) | Optional | List (drop-down) | N/A | Master configuration list (AM_LIST) | Code and description pairs for the configured buying category list | Form open | Options loaded from master configuration at runtime | N/A |
| Exchange Status (`P_EXCH_STS`) | Mandatory | List (drop-down) | N/A | Master configuration list (AM_LIST) | Code and description pairs for the configured exchange status list | Form open | Options loaded from master configuration at runtime; field must not be left blank before report submission | *"Exchange Status can not be empty"* shown on attempt to leave field blank |
| Invoice Type (`P_INV_TYPE`) | Optional | List (drop-down) | 1 | N/A | Configured invoice type values | Form open | N/A | N/A |
| Destination (`P_DESTYPE`) | Read-only display | List (drop-down) | N/A | N/A | Configured destination values | Form open | Field is disabled (not user-editable) | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Dealer Details Mandatory Field Validation

**Business Description:**
Before the system accepts the dealer selection on the report filter screen, it checks that a dealer has actually been chosen. This prevents the user from leaving the dealer field blank and attempting to proceed, which would produce a meaningless report with no data scope. If the dealer field is empty when the user moves off it, an error is shown and the cursor is returned to the field.

**Actors:** Report User

**Preconditions:**
- The report filter screen is open and the user has attempted to move focus away from the Dealer Details field.

**Main Flow:**

**Step 1 - Dealer Details field is validated as non-empty**
When the user leaves the Dealer Details field, the system checks whether a dealer has been selected. If the field is blank, the user sees the message *"Dealer Details can not be empty"* and the field remains in focus so the user can make a selection before continuing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Details must not be blank | Null check in WHEN-VALIDATE-ITEM on CB_BLK.P_DELR_CD | When the user attempts to move off the Dealer Details field | Ensures a dealer is selected before any other filter values are entered or the report is submitted | *"Dealer Details can not be empty"* is displayed; cursor remains on the Dealer Details field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Dealer Details field is empty when the user leaves it - *"Dealer Details can not be empty"*; the user must select a dealer before moving to the next field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Details (`P_DELR_CD`) | Mandatory | Text | 500 | Dealer list (LV_DEALER / RG_DEALER) | Dealer city, name, and code | Form open | Must not be blank when the user leaves the field | *"Dealer Details can not be empty"* |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Outlet Details Mandatory Field Validation

**Business Description:**
Once a dealer has been selected, the user must also choose a specific outlet (location) for the dealer before the report can be submitted. The system checks that the outlet field is not left blank when the user moves off it. Leaving it blank would mean the report could not be scoped to any particular outlet, making the resulting data ambiguous. If the outlet field is empty, the user is told to fill it in before proceeding.

**Actors:** Report User

**Preconditions:**
- The report filter screen is open and the user has attempted to move focus away from the Outlet Details field.

**Main Flow:**

**Step 1 - Outlet Details field is validated as non-empty**
When the user leaves the Outlet Details field, the system checks whether an outlet has been selected. If the field is blank, the user sees the message *"Outlet Details can not be empty"* and the field remains in focus until a valid outlet is chosen.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Outlet Details must not be blank | Null check in WHEN-VALIDATE-ITEM on CB_BLK.P_LOC_CD | When the user attempts to move off the Outlet Details field | Ensures an outlet is selected so the report is scoped to a specific location | *"Outlet Details can not be empty"* is displayed; cursor remains on the Outlet Details field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Outlet Details field is empty when the user leaves it - *"Outlet Details can not be empty"*; the user must select an outlet before moving to the next field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Outlet Details (`P_LOC_CD`) | Mandatory | Text | 500 | Outlet list (LV_LOC / RG_LOC) | Location code and description | Dealer Details selected | Must not be blank when the user leaves the field | *"Outlet Details can not be empty"* |
| Outlet Description (`P_LOC_DESC`) | Read-only display | Display item | 500 | N/A | N/A | Outlet selected | Auto-populated when outlet is chosen | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Exchange Status Mandatory Field Validation

**Business Description:**
The Exchange Status filter determines which category of exchange trade-in records the report will cover. Before the report can be generated, the system checks that the user has selected a value for this field. If the Exchange Status is left blank, the report engine would not know which exchange state to query, resulting in an undefined data set. The system blocks the user from leaving the field empty and asks them to make a selection.

**Actors:** Report User

**Preconditions:**
- The report filter screen is open and the user has attempted to move focus away from the Exchange Status field.

**Main Flow:**

**Step 1 - Exchange Status field is validated as non-empty**
When the user leaves the Exchange Status field, the system checks whether a status value has been chosen. If the field is blank, the user sees the message *"Exchange Status can not be empty"* and the field remains in focus until a valid status is selected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Exchange Status must not be blank | Null check in WHEN-VALIDATE-ITEM on CB_BLK.P_EXCH_STS | When the user attempts to move off the Exchange Status field | Ensures an exchange status is selected so the report is scoped to a defined set of records | *"Exchange Status can not be empty"* is displayed; cursor remains on the Exchange Status field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Exchange Status field is empty when the user leaves it - *"Exchange Status can not be empty"*; the user must select a status before moving to the next field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Exchange Status (`P_EXCH_STS`) | Mandatory | List (drop-down) | 500 | Master configuration list (AM_LIST) | Configured exchange status codes and descriptions | Form open | Must not be blank when the user leaves the field | *"Exchange Status can not be empty"* |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Invoice From Date Validation and Automatic To Date Calculation

**Business Description:**
The Invoice From Date is a mandatory report filter that anchors the start of the date range covered by the report. When the user enters a From Date and moves off the field, the system runs several business checks to ensure the date is valid and logical: it must be provided, it must not be a future date, and it must not be later than the To Date already entered. If all checks pass, the system automatically calculates and sets the To Date to one month after the From Date (or today's date if that one-month mark falls in the future), saving the user from having to work out the default range manually.

**Actors:** Report User

**Preconditions:**
- The report filter screen is open and the user has entered a value in the Invoice From Date field and is attempting to move off it.

**Main Flow:**

**Step 1 - From Date is checked for presence**
The system first confirms that the From Date field has been filled in. If it is empty, the user sees the message *"From Date can not be empty"* and the cursor is returned to the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice From Date must not be blank | Null check - first DECLARE block in WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT | When the user moves off the Inv From Date field | Ensures a start date is always provided for the report range | *"From Date can not be empty"* is displayed; cursor returns to the Inv From Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - From Date field is empty when the user leaves it - *"From Date can not be empty"*; the user must enter a date before moving on.

**Step 2 - From Date is checked against today's date**
If a From Date is provided, the system checks that it does not fall after today. A future From Date would mean the report is being requested for invoices that have not yet been issued, which is not a valid business scenario. If the From Date is after today, an alert box shows the message *"From Date cannot be greater than Current Date"* and the user must correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice From Date must not be in the future | Comparison with system date - first DECLARE block in WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT | When the user moves off the Inv From Date field with a date entered | Prevents requesting a report for future invoice dates that cannot yet exist | Alert: *"From Date cannot be greater than Current Date"*; user must correct the date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-02** - From Date is after today - *"From Date cannot be greater than Current Date"*; the user must enter a date that is today or earlier.

**Step 3 - From Date is checked against the To Date if already entered**
If a To Date has already been entered, the system also checks that the From Date does not exceed it. A From Date later than the To Date would produce an empty or inverted date range. If this condition is found, an alert shows the message *"From Date cannot be greater than To Date"* and the user must correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invoice From Date must not exceed the To Date | Comparison with P_TODT - first DECLARE block in WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT | When the user moves off the Inv From Date field with a date entered | Prevents an inverted or zero-length date range being submitted for the report | Alert: *"From Date cannot be greater than To Date"*; user must correct the From Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-03** - From Date is after the To Date - *"From Date cannot be greater than To Date"*; the user must correct the From Date.

**Step 4 - To Date is automatically calculated from the From Date**
Once all date checks pass, the system automatically calculates a default To Date as one calendar month after the From Date minus one day (i.e. the last day of the same calendar month). If that calculated date is still in the future, the To Date is set to today's date instead, keeping the range within the past. This saves the user from having to calculate and type the To Date manually.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 4) If the date one month after the From Date is in the future, the To Date is set to today's date rather than the calculated one-month-out date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Inv From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | Form open | Must not be blank; must not be a future date; must not exceed the To Date if already entered | *"From Date can not be empty"* / *"From Date cannot be greater than Current Date"* / *"From Date cannot be greater than To Date"* |
| To Date (`P_TODT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | From Date validated | Auto-set to one month after From Date (or today if that falls in the future); also validated separately on the To Date field | N/A (auto-populated here) |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Invoice To Date Validation

**Business Description:**
The Invoice To Date marks the end of the date range for the report. When the user enters or modifies the To Date field and moves off it, the system enforces several business rules to ensure the date range is valid: the To Date must be provided, it must not be entered without a From Date already in place, it must not be earlier than the From Date, it must not be a future date, and the overall range between From Date and To Date must not exceed three months. These rules prevent users from accidentally generating excessively large or logically inconsistent reports.

**Actors:** Report User

**Preconditions:**
- The report filter screen is open and the user has entered a value in the To Date field and is attempting to move off it.

**Main Flow:**

**Step 1 - To Date is checked for presence**
The system first confirms that the To Date has been filled in. If it is empty, the user sees the message *"To Date can not be empty"* and the cursor is returned to the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be blank | Null check in WHEN-VALIDATE-ITEM on CB_BLK.P_TODT | When the user moves off the To Date field | Ensures an end date is always provided for the report range | *"To Date can not be empty"* is displayed; cursor returns to the To Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - To Date field is empty when the user leaves it - *"To Date can not be empty"*; the user must enter a date before moving on.

**Step 2 - To Date cannot be entered without a From Date**
If a To Date is provided but the From Date is still blank, the system clears the To Date, shows the message *"To date cannot be entered without entering From date"*, and stops the user from leaving the field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be entered before the To Date | From Date null check in WHEN-VALIDATE-ITEM on CB_BLK.P_TODT | When the user moves off the To Date field with a date entered | Enforces the logical sequencing of date-range entry - the start must be set before the end | *"To date cannot be entered without entering From date"*; To Date field is cleared and cursor remains |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-02** - To Date entered while From Date is blank - *"To date cannot be entered without entering From date"*; To Date is cleared; user must enter the From Date first.

**Step 3 - To Date must not be earlier than the From Date**
The system checks that the To Date is not less than the From Date. If it is, an alert shows *"To Date cannot be lesser than From Date"* and the user must correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be earlier than the From Date | Comparison with P_FROMDT - WHEN-VALIDATE-ITEM on CB_BLK.P_TODT | When the user moves off the To Date field | Prevents an inverted date range | Alert: *"To Date cannot be lesser than From Date"*; user must correct the To Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-03** - To Date is earlier than the From Date - *"To Date cannot be lesser than From Date"*; the user must correct the To Date.

**Step 4 - To Date must not be in the future**
The system checks that the To Date does not fall after today. Requesting data for future invoice dates is not a valid business scenario. If the To Date is after today, an alert shows *"To Date cannot be greater than Current Date"* and the user must correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be in the future | Comparison with system date - WHEN-VALIDATE-ITEM on CB_BLK.P_TODT | When the user moves off the To Date field | Prevents requesting a report for future invoice dates | Alert: *"To Date cannot be greater than Current Date"*; user must correct the To Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-04** - To Date is after today - *"To Date cannot be greater than Current Date"*; the user must enter a date that is today or earlier.

**Step 5 - Date range must not exceed three months**
As a final check, the system ensures the gap between the From Date and the To Date is no more than three calendar months. Ranges wider than three months could generate very large data extracts that degrade system performance. If the To Date is more than three months after the From Date, an alert shows *"Please give the date range of maximum three month"* and the user must narrow the range.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range must not exceed three months | Comparison with ADD_MONTHS(P_FROMDT, 3) minus one day - WHEN-VALIDATE-ITEM on CB_BLK.P_TODT | When the user moves off the To Date field | Limits the volume of data extracted to protect system performance | Alert: *"Please give the date range of maximum three month"*; user must reduce the To Date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-05** - Date range exceeds three months - *"Please give the date range of maximum three month"*; the user must reduce the date range.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`P_TODT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | From Date entered | Must not be blank; must not be entered without From Date; must not be earlier than From Date; must not be a future date; date range must not exceed three months | *"To Date can not be empty"* / *"To date cannot be entered without entering From date"* / *"To Date cannot be lesser than From Date"* / *"To Date cannot be greater than Current Date"* / *"Please give the date range of maximum three month"* |
| Inv From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Used as the lower bound in the To Date range checks | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Exchange Trade-In Report Generation and Download

**Business Description:**
When the user has filled in the required filter criteria and clicks the Submit Report button, the system builds a report covering exchange trade-in activity for the selected dealer, outlet, date range, exchange status, and any optional filters applied. The report is assembled as a CSV data extract containing vehicle, invoice, bonus, Vahan, and claim details for each matching transaction. The user receives the file directly in their browser for download or viewing. Three distinct data sets are produced depending on which exchange status category was chosen: transactions where the old vehicle buying was completed and invoiced, transactions where the old vehicle evaluation is still in progress (and not yet converted to a live buy), and transactions where the exchange was cancelled. The query that produces each category is different and automatically scoped to the appropriate records.

**Actors:** Report User

**Preconditions:**
- The dealer, outlet, invoice from date, to date, and exchange status have all been selected and individually validated.
- The optional filters (old vehicle registration number, new vehicle model, variant, TV outlet, buying category, invoice type) may or may not be specified.

**Main Flow:**

**Step 1 - Output filename is generated for the current user and timestamp**
The system generates a unique filename for the extract file by combining the current user's identifier with the current date and time, appended with a `.csv` extension. If the resulting path contains a space in any folder name, the file is redirected to the root of the C drive and the user is informed with the message *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*

**Step 2 - Report data set is assembled based on the Exchange Status filter**
The system constructs the data query for the selected exchange status. Each status produces a different data set:

- **Bought (invoiced) exchange status:** the report covers all invoice records where the linked old vehicle buying has reached a completed (live) buy status. The data includes all invoice, vehicle, evaluator, bonus, Vahan verification, and claim details for the selected dealer, outlet, and date range.
- **Evaluation-in-progress exchange status:** the report covers invoice records where the old vehicle evaluation is still active (status E or R) and has not yet been converted to a confirmed buy. Records that already have a live or bought buy record are excluded.
- **Cancelled exchange status:** the report covers invoice records where the exchange transaction was subsequently cancelled.

For all three categories, the optional filters (old vehicle registration, model, variant, TV outlet, buying category, invoice type) are applied when the user has provided them, or treated as "all" when left blank. The query includes dealer location details, old vehicle details, evaluator identity, new vehicle identity, bonus amounts across multiple bonus type categories, Vahan verification flags, and loyalty exchange claim status.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP (form program unit) - executes the assembled data query, writes each result row to a CSV file on the application server, then opens the file in the user's browser for download.
    * **Step 1** - Generate a filename for the CSV output file from the current user session identity and the current timestamp.
    * **Step 2** - If the file path contains spaces in any folder name, redirect the file to the root of the C drive and inform the user that the storage location has been changed.
    * **Step 3** - Clear any previously cached data set from the working area to ensure a fresh extract.
    * **Step 4** - Execute the report data query to populate the working data set with the rows matching the selected filter criteria.
    * **Step 5** - Determine the total number of rows returned by the query.
    * **Step 6** - Read the configured server-side file path from the path configuration file.
    * **Step 7** - Open a new output file on the application server at the configured path.
    * **Step 8** - Write each row from the data set to the CSV output file, one line per row.
    * **Step 9** - Close the output file.
    * **Step 10** - Open the completed CSV file in the user's browser in a new tab for download or viewing.
    * **Step 11** - If any unexpected error occurs during the above steps, display a message combining the error code and error description (in the form *"Error  - "* followed by the system error code and text), then stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces in a folder name | Path space check - VIEW_EXCEL_REP [SP-001] | When the Submit Report button is pressed | Ensures the output file can be saved in the designated path; redirects to a safe default if the path is unsuitable | Message: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; file is saved to the C drive root instead |
| Report data query execution and file write must succeed | OTHERS exception handler - VIEW_EXCEL_REP [SP-001] | During report data assembly and file write | Catches any unexpected runtime error so the user is informed rather than left with a silent failure | Message: *"Error  - "* followed by the system error code and error text; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-WS-01** - Output path contains spaces in a folder name - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; processing continues with the file stored at the C drive root.
- **BR-008-ES-01** - Unexpected runtime error during report generation - *"Error  - "* followed by the system-provided error code and error text; processing stops and the user must investigate the reported error.

#### Business Scenarios - How the report data differs by Exchange Status

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Bought / Invoiced exchanges** | Covers invoice records where the linked old-vehicle buying is in a completed live status. Includes all bonus type categories (base, MSIL share, additional, stock liquidation) and Vahan verification details. |
| **Evaluation-in-progress exchanges** | Covers invoice records where the old vehicle evaluation is still active and not yet converted to a confirmed buy. Records that already have a completed buy are excluded from this set. Bonus calculations are included but stock-liquidation bonus columns are not present in the header for this status. |
| **Cancelled exchanges** | Covers invoice records where the exchange transaction has been cancelled. The same set of columns is returned as for the evaluation-in-progress status. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Exchange Status (`P_EXCH_STS`) | Mandatory | List (drop-down) | 500 | Master configuration list (AM_LIST) | B = Bought/Invoiced; E = Evaluation-in-progress; C = Cancelled | Validated on field exit | Must be selected; determines which report query is executed | *"Exchange Status can not be empty"* |
| Inv From Date (`P_FROMDT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | Validated on field exit | Used as the start boundary for the invoice date filter in the query | Validated separately in BR-006 |
| To Date (`P_TODT`) | Mandatory | Date | 10 / DD/MM/RRRR | N/A | N/A | Validated on field exit | Used as the end boundary (exclusive - one day after the To Date is added internally) for the invoice date filter | Validated separately in BR-007 |
| Dealer Details (`P_DELR_CD`) | Mandatory | Text | 500 | Dealer list (LV_DEALER / RG_DEALER) | Dealer code | Validated on field exit | Used as the dealer filter in the data query | Validated separately in BR-003 |
| Dealer Map Code (`P_DEALER_MAP_CD`) | Auto-populated | Text | 500 | N/A | Internal dealer mapping code | Dealer Details selected | Set when dealer is selected from the LOV; used in the data query | N/A |
| Outlet Details (`P_LOC_CD`) | Mandatory | Text | 500 | Outlet list (LV_LOC / RG_LOC) | Location code | Validated on field exit | Used as the outlet filter in the data query | Validated separately in BR-004 |
| Old Vehicle Reg Num (`P_REG_NUM`) | Optional | Text | 20 | N/A | N/A | N/A | When blank, all registration numbers are included; when provided, scopes the report to that registration | N/A |
| New Vehicle Model (`P_MODEL_DESC`) | Optional | Text | 500 | Model list (LV_MODEL / RG_MODEL) | Model description | N/A | When blank, all models are included | N/A |
| Model code (`P_MODEL`) | Auto-populated | Text | 500 | N/A | Internal model code | Model selected | Set when model is selected from the LOV; used as the model filter in the data query | N/A |
| New Vehicle Variant (`P_VARIANT_DESC`) | Optional | Text | 500 | Variant list (LV_VARIANT / RG_VARIANT) | Variant description | Model selected | When blank, all variants are included | N/A |
| Variant code (`P_VARIANT`) | Auto-populated | Text | 500 | N/A | Internal variant code | Variant selected | Set when variant is selected from the LOV; used as the variant filter in the data query | N/A |
| TV Outlet (`P_TV_OUTLET_DESC`) | Optional | Text | 500 | TV Outlet list (LV_TVOUTLET / RG_TVOUTLET) | TV outlet description | N/A | When blank, all TV outlets are included | N/A |
| TV Outlet code (`P_TV_OUTLET`) | Auto-populated | Text | 500 | N/A | Internal TV outlet code | TV Outlet selected | Set when TV outlet is selected from the LOV; used as the outlet filter in the data query | N/A |
| Old Vehicle Buying Category (`P_BUY_CATEG`) | Optional | List (drop-down) | N/A | Master configuration list (AM_LIST) | Buying category codes | N/A | When blank, all buying categories are included | N/A |
| Invoice Type (`P_INV_TYPE`) | Optional | List (drop-down) | 1 | N/A | Invoice type codes | N/A | When blank, all invoice types are included | N/A |
| Query Text (`TXT`) | Auto-populated | Long text | 65534 | N/A | N/A | Report query built | Stores the assembled SQL query string at the point it is executed; not displayed to the user but stored for diagnostic purposes | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Centralised Form Error Interception and User Notification

**Business Description:**
When any error arises anywhere in the form - whether caused by an invalid date entry, a non-numeric value in a numeric field, a database constraint violation, a stale record conflict, or any unexpected database exception - the form intercepts it at the form level before it reaches the user as a raw technical system error. The form translates the error into a plain message the user can act on, and then stops the current operation so the user can correct the input. For specific well-known date format errors, field-type mismatches, and record-locking conflicts, the message is fixed and descriptive. For all other database exceptions, the database's own error text is shown as-is. Records that are stale (updated by another user) are rolled back and the user is told to re-query the record before making changes.

**Actors:** System (automatic; fires whenever any error occurs on the form)

**Preconditions:**
- The form is open and an error condition has been raised anywhere in the form's processing.

**Main Flow:**

**Step 1 - Date entry errors are intercepted and explained**
If the error is caused by an invalid date value (error code 50004), the user sees the message *"Entered Date is not valid Date"* and the current operation stops. If the error is caused by an incorrectly formatted date (error codes 50025 or 50026), the user sees *"Enter the Date in the proper format (DD-MM-YYYY)"* and the operation stops.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message text in an error-severity dialog so the user is clearly informed of what went wrong and must acknowledge it before continuing.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date value detected | Error code 50004 check - ON-ERROR (Form) | When an error occurs during form processing | Ensures the user receives a clear, plain-language explanation instead of a technical code when a date value is unrecognisable | *"Entered Date is not valid Date"* is displayed; current operation is stopped |
| Incorrect date format detected | Error codes 50025/50026 check - ON-ERROR (Form) | When an error occurs during form processing | Guides the user to the correct date entry format (DD-MM-YYYY) when they have entered a date in the wrong format | *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed; current operation is stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - An invalid date value was entered - *"Entered Date is not valid Date"*; the current operation stops and the user must correct the date.
- **BR-009-ES-02** - A date was entered in the wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the current operation stops and the user must re-enter the date correctly.

**Step 2 - Non-numeric input in a numeric field is intercepted**
If the error is caused by text or special characters being entered where only a number is allowed (error codes 40209 or 50016), the user sees the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and the current operation stops.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message in an error-severity dialog.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric characters in a numeric field detected | Error codes 40209/50016 check - ON-ERROR (Form) | When an error occurs during form processing | Prevents non-numeric input being accepted in fields that only allow numbers | *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed; current operation is stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-03** - Non-numeric characters were entered in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the current operation stops and the user must correct the entry.

**Step 3 - Standard Forms field error text is displayed for field-level errors**
If the error is error code 40207 (a standard Oracle Forms field error), the error text returned by the form itself is shown to the user exactly as provided by the form, and the current operation stops.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the raw error text in an error-severity dialog.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

**Step 4 - Child record constraint violation is translated to a business message**
If the database reports that the operation cannot be completed because related child records exist (database error code -02292, i.e. a referential integrity violation), the form looks up and displays the registered business error message for that condition.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-003](#SP-003--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up the registered error message for error code 'E0088' and displays it to the user.
    * **Step 1** - Receive the error identifier to look up.
    * **Step 2** - Retrieve the corresponding registered error message.
    * **Step 3** - Display the message to the user.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Child record existence check | Database error code -02292 - ON-ERROR (Form) | When a database error occurs during form processing | Translates a referential integrity error into a user-friendly business message instead of exposing a raw database constraint code | Business error message for code 'E0088' is displayed to the user; current operation is stopped |

**Step 5 - Stale record conflict is detected and the user is asked to re-query**
If the error indicates the record being modified has already been changed by another user (error codes 40654, 40655, 40656, 40657, or 40659), the form rolls back all pending changes and tells the user to re-query the record before attempting any further changes.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the stale-record message in an error-severity dialog.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Stale record conflict detected | Error codes 40654/40655/40656/40657/40659 check - ON-ERROR (Form) | When a database error occurs during form processing | Protects data integrity by rolling back and notifying when another user has already modified the same record | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; all pending changes are rolled back; current operation stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** - The record was modified by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; all pending changes are rolled back; the user must re-query before retrying.

**Step 6 - Any other database exception is reported with the database's own error text**
If a database exception occurs that is not covered by any of the above specific cases (i.e. SQLCODE is not zero), the database's own error text is shown to the user, all pending changes are rolled back, and the current operation stops.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error text in an error-severity dialog.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Any unhandled database exception | SQLCODE not zero check - ON-ERROR (Form) | When a database error occurs during form processing | Ensures no database exception is silently swallowed; the user always receives the database error text and all uncommitted changes are reversed | The database's own error message (SQLERRM) is displayed; all pending changes are rolled back; current operation stops |

**Step 7 - No-data and duplicate record messages are suppressed**
If the error is one of the codes indicating that no records were found (40401) or a duplicate record attempt (40405), the form takes no action - these conditions are silently ignored and do not produce any message to the user.

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 7) If the error is code 40401 or 40405, no message is shown and no rollback occurs; the form simply continues without raising any visible error to the user.

---

---

#### Requirement ID: BR-010

**Requirement Title:** Form Exit with Session Cleanup

**Business Description:**
When the user closes the form using the exit key, the application clears the database session context it registered when the form was opened. This ensures that the session's module and action identity are removed so database administrators monitoring active sessions do not see a stale reference to the Exchange Trade-In form after the user has left. The form then closes immediately without prompting to save any unsaved changes, since this form does not maintain persistent data that needs saving.

**Actors:** Report User

**Preconditions:**
- The form is open and the user has pressed the exit key.

**Main Flow:**

**Step 1 - Session context is cleared before the form closes**
The application removes the module and action name it registered in the database session when the form was opened, resetting both to empty values. This ensures the session's tracking information accurately reflects that the user is no longer in the Exchange Trade-In form.

**Step 2 - Form closes without prompting to save**
The form closes immediately, discarding any uncommitted changes without asking the user to save, since the form is a reporting-only screen with no persistent data entry.

---

---

#### Requirement ID: BR-011

**Requirement Title:** Form Reset, Cancel Confirmation, and Copyright Declaration Refresh

**Business Description:**
The user can reset the form either by pressing the standard clear-form key or by clicking the Cancel toolbar button. When the Cancel toolbar button is clicked and the form has unsaved changes, the system asks the user to confirm that they are willing to discard those changes before proceeding. When the form is cleared - by either route - all filter fields are reset, the report name label is restored to its default title, and the copyright declaration is refreshed from the system. This ensures that after a reset the form always shows the correct report identity and an up-to-date copyright notice.

**Actors:** Report User

**Preconditions:**
- The form is open and the user has either pressed the clear-form key or clicked the Cancel toolbar button.

**Main Flow:**

**Step 1 - Cancel toolbar button checks for unsaved changes before clearing**
When the user clicks the Cancel toolbar button, the form checks whether the button is currently enabled. If it is, the form checks whether there are any unsaved changes in the current session. If the form has changed data, the user is asked to confirm with the prompt *"Entered data will not be Saved"*. If the user confirms (or if the form has no unsaved changes), the clear-form action proceeds. If the user declines the confirmation, no clear action is taken and the user remains on the screen with their data intact.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User must confirm loss of unsaved data before clearing | Form-status check in FT_CANCEL - fired via WHEN-BUTTON-PRESSED on PB_BLK.PB_CANCEL | When the Cancel toolbar button is clicked with unsaved changes | Prevents the user from accidentally discarding work in progress without an explicit confirmation | *"Entered data will not be Saved"* confirmation is shown; if declined, the form is not cleared |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-IC-01** - User clicks Cancel with unsaved changes but declines the prompt *"Entered data will not be Saved"*; the form is not cleared and the user's data remains in place.
- **BR-011-SM-01** - User confirms the Cancel prompt, or clicks Cancel when there are no unsaved changes; the clear-form action proceeds.

**Step 2 - All form data is cleared without saving**
The form clears all fields and resets them to their initial empty state without performing any save or commit of any previously entered values.

**Step 3 - Report name label is set to its default value**
The report name display field is assigned the fixed text 'Exchange TradeIn Report', restoring the standard label for this form after the clear operation.

**Step 4 - Copyright declaration text is refreshed**
The form retrieves the current copyright declaration text by calling the copyright declaration function and places the result in the copyright display field, ensuring the notice shown on screen is current.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-013](#SP-013--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - retrieves the current copyright declaration text for display on the form.
    * **Step 1** - Retrieve the current copyright declaration text.
    * **Step 2** - Return the text to the caller for display.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display item | 200 | N/A | Fixed value: 'Exchange TradeIn Report' | Form cleared | System-set; not user-editable | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Display item | 100 | N/A | Current copyright declaration text retrieved at runtime | Form cleared | System-set from copyright declaration function; not user-editable | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Form-Level Message Interception for Field-Type and Numeric Errors

**Business Description:**
The form also intercepts certain system informational or message-level notifications that would otherwise be shown in their raw technical form. When a field-type mismatch or similar Oracle Forms message is raised (message codes 40209 or 40207), the form suppresses the default system message and re-displays it using the same styled error dialog as the error handler, so the presentation is consistent regardless of whether the event arrives via the error channel or the message channel.

**Actors:** System (automatic; fires whenever the form's message channel is invoked)

**Preconditions:**
- The form is open and a message-level notification with code 40209 or 40207 has been raised.

**Main Flow:**

**Step 1 - Field-type or numeric message is intercepted and redisplayed**
If a message with code 40209 or 40207 is raised on the form's message channel, the form captures it and displays the message type, error code, and message text together in the standard error dialog. The current operation is then stopped so the user must acknowledge the error. Any message with a code other than 40209 or 40207 on the message channel is not intercepted by this trigger and passes through normally.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the formatted message (combining error type, error code, and error text) in a styled error dialog.
    * **Step 1** - Receive the message text and severity level to display.
    * **Step 2** - Present the message to the user in a dialog appropriate to the given severity.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Field-type / numeric message codes 40209 or 40207 are intercepted | Error codes 40209/40207 check - ON-MESSAGE (Form) | When a form message is raised during any user interaction | Ensures consistent error presentation by routing these message codes through the same styled dialog as form errors | The message type, code, and text are displayed in the error dialog; current operation stops |

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) If the message code is not 40209 or 40207, the ON-MESSAGE trigger takes no action and the message is handled by the default Forms message channel.

---

---

#### Requirement ID: BR-013

**Requirement Title:** Toolbar Button Controls - Save, Insert, Delete, and Commit-Key Behaviour

**Business Description:**
The form toolbar provides Save, Cancel, Insert, Delete, List, and Print buttons whose active behaviour is controlled by whether each button is currently enabled. The Save toolbar button commits any pending data to the database and immediately clears the form so the user starts with a clean screen. The Insert toolbar button is intentionally blocked on this form - clicking it shows an error because no insert operation is permitted here. The Delete toolbar button, when active, asks the user to confirm before permanently removing the current record. The keyboard commit key (save shortcut) is separately disabled - pressing it does nothing, since the form is a reporting screen that does not create or modify records directly.

**Actors:** Report User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Toolbar Save button commits and clears the form**
When the user clicks the Save toolbar button, the form commits all pending changes to the database and then immediately clears all fields, returning the screen to a fresh state ready for a new entry. This two-step sequence (commit then clear) ensures that data is saved before the screen is wiped.

**Step 2 - Toolbar Insert button is blocked and informs the user**
When the user clicks the Insert toolbar button, the form checks whether the button is currently enabled. If it is, the user sees the message *"This Operation Cannot be performed Here"* and no insert action is taken. This prevents any attempt to add new records through the insert button on this form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation not permitted | Enabled-state check in FT_INSERT - fired via WHEN-BUTTON-PRESSED on PB_BLK.PB_INSERT | When the Insert toolbar button is clicked | Prevents the insert operation from being used on this form | *"This Operation Cannot be performed Here"* is displayed; no record is inserted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - User clicks the Insert button while it is active - *"This Operation Cannot be performed Here"*; the operation is cancelled and no record is created.

**Step 3 - Toolbar Delete button requests confirmation before removing a record**
When the user clicks the Delete toolbar button and it is currently enabled, the form suspends validation, navigates to the data block, and displays a confirmation prompt asking *"Are you sure to Delete?"*. If the user confirms, the current record is permanently deleted. If the user declines, no deletion is performed. Validation is re-enabled in both cases once the prompt is resolved.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete must be confirmed by the user | Confirmation check in FT_DEL - fired via WHEN-BUTTON-PRESSED on PB_BLK.PB_DEL | When the Delete toolbar button is clicked and the cursor is in the data block | Prevents accidental deletion of records by requiring explicit user confirmation | If the user declines the prompt, *"Are you sure to Delete?"*, no record is deleted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-SM-01** - User confirms deletion when prompted - *"Are you sure to Delete?"*; the current record is permanently removed.
- **BR-013-IC-01** - User declines the delete confirmation prompt - no deletion is performed; the record remains unchanged.

**Step 4 - Keyboard commit key press is suppressed**
When the user presses the keyboard commit (save) shortcut key, the form runs a no-operation statement, effectively ignoring the key press without performing any save or commit action. This is intentional: the Exchange Trade-In report form is a query and report submission screen that does not create or modify any database records directly, so the save key shortcut is not meaningful here.

(COMMENTED OUT / INACTIVE - KEY-COMMIT does not execute)

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Dealer Details Required | Validation | BR-003 | The Dealer Details field is left blank when the user moves off it | Block navigation and display *"Dealer Details can not be empty"* | Prevents a report being submitted without a dealer scope, which would produce unusable results |
| BRC-002 | Outlet Details Required | Validation | BR-004 | The Outlet Details field is left blank when the user moves off it | Block navigation and display *"Outlet Details can not be empty"* | Prevents a report being submitted without an outlet scope, ensuring the data is correctly scoped to a specific location |
| BRC-003 | Exchange Status Required | Validation | BR-005 | The Exchange Status field is left blank when the user moves off it | Block navigation and display *"Exchange Status can not be empty"* | Ensures the report engine always knows which category of exchange records to retrieve |
| BRC-004 | Invoice From Date Required | Validation | BR-006 | The Invoice From Date field is left blank when the user moves off it | Block navigation and display *"From Date can not be empty"* | Ensures a valid start boundary is always present for the date-range filter |
| BRC-005 | Invoice From Date Must Not Be in the Future | Validation | BR-006 | The Invoice From Date entered is later than today's date | Display alert *"From Date cannot be greater than Current Date"* and block navigation | Prevents requesting data for future invoices that do not yet exist |
| BRC-006 | Invoice From Date Must Not Exceed To Date | Validation | BR-006 | The Invoice From Date is later than the To Date already entered | Display alert *"From Date cannot be greater than To Date"* and block navigation | Prevents an inverted or zero-length date range being submitted to the report query |
| BRC-007 | To Date Auto-Calculated from From Date | Derivation | BR-006 | The Invoice From Date passes all validations | Automatically set the To Date to the last day of the month following the From Date (or today if that date is in the future) | Saves the user from calculating the default To Date manually and enforces a sensible default range |
| BRC-008 | To Date Required | Validation | BR-007 | The To Date field is left blank when the user moves off it | Block navigation and display *"To Date can not be empty"* | Ensures a valid end boundary is always present for the date-range filter |
| BRC-009 | To Date Requires From Date First | Validation | BR-007 | A To Date is entered while the Invoice From Date is still blank | Clear the To Date field and display *"To date cannot be entered without entering From date"* | Enforces the logical sequencing of date-range entry - the start date must always be entered before the end date |
| BRC-010 | To Date Must Not Be Earlier Than From Date | Validation | BR-007 | The To Date entered is earlier than the Invoice From Date | Display alert *"To Date cannot be lesser than From Date"* and block navigation | Prevents an inverted date range that would produce an empty data set |
| BRC-011 | To Date Must Not Be in the Future | Validation | BR-007 | The To Date entered is later than today's date | Display alert *"To Date cannot be greater than Current Date"* and block navigation | Prevents requesting data for future invoices |
| BRC-012 | Date Range Must Not Exceed Three Months | Constraint | BR-007 | The gap between the Invoice From Date and the To Date is more than three calendar months | Display alert *"Please give the date range of maximum three month"* and block navigation | Limits the volume of data retrieved per request to protect system performance |
| BRC-013 | Invalid Date Value Error Translation | Validation | BR-009 | A date field receives a value that cannot be interpreted as a valid date (error code 50004) | Display *"Entered Date is not valid Date"* and stop the current operation | Ensures the user receives a plain-language message instead of a raw error code |
| BRC-014 | Date Format Error Translation | Validation | BR-009 | A date is entered in an unsupported format (error codes 50025 or 50026) | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop the current operation | Guides the user to the required date format (DD-MM-YYYY) |
| BRC-015 | Non-Numeric Input in Numeric Field | Validation | BR-009 | Characters or special characters are entered in a field that accepts only numeric values (error codes 40209 or 50016) | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop the current operation | Prevents invalid data types from being entered in numeric fields |
| BRC-016 | Referential Integrity Violation Translation | Constraint | BR-009 | A database operation fails because child records exist for the parent record being affected (database error code -02292) | Raise and display the registered business error for constraint code 'E0088' | Presents a business-meaningful message instead of exposing a raw database constraint error code |
| BRC-017 | Stale Record Conflict - Roll Back and Re-query | Validation | BR-009 | The record being processed has already been modified by another user (error codes 40654-40659) | Roll back all pending changes and display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* | Protects data integrity by preventing overwrite of changes made by another session |
| BRC-018 | Unhandled Database Exception - Roll Back and Inform | Validation | BR-009 | A database error occurs that is not covered by any specific error handler and SQLCODE is non-zero | Roll back all pending changes and display the database's own error text | Ensures no database exception is silently ignored; all uncommitted changes are reversed and the user is informed |
| BRC-019 | Report Output File Path Space Detection | Validation | BR-008 | The generated CSV output file path contains a space in one of the folder names | Redirect the file to the root of the C drive and inform the user with *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Prevents a file-save failure caused by spaces in a folder name; ensures the report is always delivered |
| BRC-020 | Report Generation Runtime Error Handling | Validation | BR-008 | An unexpected error occurs during data query execution or CSV file creation and writing | Display *"Error  - "* followed by the system error code and error text, then stop processing | Ensures any failure in the report generation pipeline is communicated to the user rather than producing a silent, incomplete output |
| BRC-021 | No-Data and Duplicate Record Messages Suppressed | Constraint | BR-009 | Error code 40401 (no records found) or 40405 (duplicate) is raised on the form | Take no action; do not display any message and do not roll back | Prevents unhelpful system-level messages from being shown to the user for these benign conditions |
| BRC-022 | Drop-Down Options Loaded from Master Configuration | Derivation | BR-002 | A list field on the screen is opened for the first time or refreshed | Query the master configuration for the named list under the current principal and populate the drop-down with the retrieved code-description pairs | Ensures the drop-down always reflects the current master list without requiring a form update |
| BRC-023 | Date Range Maximum One-Month Auto-Suggestion | Derivation | BR-006 | The Invoice From Date passes all validations | Calculate the last day of the one-month period starting from the From Date and set it as the default To Date, capping it at today if the calculated date is in the future | Provides a sensible default reporting window and reduces the chance of users requesting excessively large extracts |

**Total Business Rules Identified: 23**

---

## 6. Data Requirements

*This section documents the data entities referenced by the Exchange Trade-In report form, the filter criteria captured at submission time, the reference data look-ups used by the form's drop-down fields, and the data lifecycle behaviour evidenced in the form's code.*

### 6.1 Business Entities and Relationships

*The Exchange Trade-In report form does not have a database-backed data entry block. Its single block (CB_BLK) has no base table - all items are session-level parameters and filter fields. The form reads from several transactional and configuration tables through a dynamically assembled query that executes when the user submits the report. The core transactional entities read by the report query are described below.*

#### Invoice Header - MULDMS.SH_INVOICE

This entity holds the sales invoice records for dealer transactions. The report uses it as the primary driver table, joining each invoice to the old-vehicle evaluation, order, and employee records. The report query filters invoices by dealer, outlet, date range, invoice type, and exchange status, and retrieves invoice number, date, VIN, sales channel, sales type, and exchange cancellation details.

#### Old Vehicle Evaluation - MULDMS.SH_TV_EVAL

This entity holds the trade-in evaluation record for each old vehicle brought in under an exchange transaction. It is joined to the invoice header by the buying number and contains old vehicle details such as registration number, model, manufacturer, year of manufacture, buying price, reference price, emission, mileage, colour, chassis, engine, evaluation date, buying date, category, buying status, and Vahan verification flags. The exchange status selected by the user determines which old-vehicle statuses are included.

#### Sales Order - MULDMS.SH_ORDBOOK

This entity holds the order booking record linked to each invoice. It is joined to the invoice header and provides the customer's city code and enquiry reference used to retrieve the evaluator's identity.

#### Dealer Location - MULDMS.AM_DEALER_LOC

This entity holds the dealer location master for each outlet, including region code, city code, dealer name, address, parent group, dealer map code, and forward code. It is joined to the invoice header to supply location and region details for each report row.

#### Employee Master - MULDMS.GM_EMP

This entity holds employee records. It is joined to the invoice header by the salesperson code to retrieve the sales executive's MSPIN for the report.

#### Vehicle Variant - MULDMS.GM_VAR

This entity holds the vehicle variant master, including variant code, variant description, model code, and fuel type. It is joined to the invoice header by variant code to supply new vehicle variant and fuel type details for each report row.

#### Vehicle Model - MULDMS.GM_MOD

This entity holds the vehicle model master. It is joined to the vehicle variant by model category code, principal map code, and model code to supply the new vehicle model description.

#### Entity Relationships

The report query assembles data from multiple tables centred on the Invoice Header. Each invoice is linked to one old vehicle evaluation record, one order booking, one dealer location, one employee (salesperson), one vehicle variant, and one vehicle model. Additional detail tables (loyalty exchange claims, invoice charges, new insurance, Vahan verification) are read as correlated sub-queries.

```
MULDMS.SH_INVOICE (Invoice Header)
    ├── MULDMS.SH_TV_EVAL (Old Vehicle Evaluation - joined by buying_num = poc_buy_id)
    ├── MULDMS.SH_ORDBOOK (Sales Order - joined by dealer/parent/loc/comp/order_num)
    ├── MULDMS.AM_DEALER_LOC (Dealer Location - joined by dealer_map_cd + loc_cd)
    ├── MULDMS.GM_EMP (Employee - joined by dealer_map_cd + salesman_cd)
    ├── MULDMS.GM_VAR (Vehicle Variant - joined by variant_cd + principal_map_cd + model_cd)
    │       └── MULDMS.GM_MOD (Vehicle Model - joined by model_cat_cd + principal_map_cd + model_cd)
    ├── MULDMS.SD_LOYLTY_EXCH_CLAIM (Loyalty Exchange Claim - correlated sub-query by inv_num)
    ├── SD_INV_CHARGES (Invoice Charges - correlated sub-query by inv_num + charge_type EXB)
    ├── MULDMS.NI_NEW_MINS (New Insurance - correlated sub-query by vin)
    └── DMS_VAHAN_CHECK_DTL (Vahan Verification - correlated sub-query by poc_buy_id + vin)
```

### 6.2 Data Capture Requirements

*The form captures session-level filter parameters entered by the user before the report is submitted. All items reside in the CB_BLK control block, which has no database base table. No records are inserted or updated by this form.*

#### Report Filter Criteria (Report User - before report submission)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Details (`P_DELR_CD`) | Yes | The dealer for which the report is to be generated, selected from a list of dealers the user has access to | Must not be left blank; validated when the user moves off the field |
| Outlet Details (`P_LOC_CD`) | Yes | The specific outlet (location) within the selected dealer | Must not be left blank; validated when the user moves off the field |
| Outlet Description (`P_LOC_DESC`) | Auto-Populated | Display-only description of the selected outlet | Auto-populated when the outlet is chosen; not directly editable |
| Dealer Map Code (`P_DEALER_MAP_CD`) | Auto-Populated | Internal dealer mapping code used to scope the report query to the correct dealer record | Set when the dealer is chosen from the list; not visible to the user |
| Parent Group (`P_PARENT_GROUP`) | Auto-Populated | Internal parent group identifier for the selected dealer | Set when the dealer is chosen from the list; used in the report query |
| Old Vehicle Buying Category (`P_BUY_CATEG`) | No | Optional filter to restrict the report to a specific category of old vehicle buying (e.g. TV or NTV) | Optional; when left blank all buying categories are included |
| Old Vehicle Reg Num (`P_REG_NUM`) | No | Optional filter to restrict the report to a specific old vehicle registration number | Optional; when provided exactly matches the registration in the report query |
| New Vehicle Model (`P_MODEL_DESC`) | No | Optional filter to restrict the report to a specific new vehicle model, selected from a list | Optional; when left blank all models are included |
| Model Code (`P_MODEL`) | Auto-Populated | Internal model code for the selected model, used as the filter value in the report query | Set when a model is selected; not directly visible to the user |
| New Vehicle Variant (`P_VARIANT_DESC`) | No | Optional filter to restrict the report to a specific variant of the selected model | Optional; when left blank all variants for the selected model are included |
| Variant Code (`P_VARIANT`) | Auto-Populated | Internal variant code for the selected variant, used as the filter value in the report query | Set when a variant is selected; not directly visible to the user |
| Exchange Status (`P_EXCH_STS`) | Yes | The exchange status category to report on - determines which set of records is included (bought/invoiced, evaluation-in-progress, or cancelled) | Must not be left blank; validated when the user moves off the field |
| Invoice Type (`P_INV_TYPE`) | No | Optional filter to restrict the report to a specific invoice type | Optional; when left blank all invoice types are included; format mask DD/MM/RRRR applied |
| TV Outlet (`P_TV_OUTLET_DESC`) | No | Optional filter to restrict the report to a specific TV outlet, selected from a list | Optional; when left blank all TV outlets are included |
| TV Outlet Code (`P_TV_OUTLET`) | Auto-Populated | Internal TV outlet code for the selected outlet, used as the filter value in the report query | Set when a TV outlet is selected; not directly visible to the user |
| Inv From Date (`P_FROMDT`) | Yes | The start date of the invoice date range for the report (inclusive) | Must not be blank; must not be a future date; must not exceed the To Date; format mask DD/MM/RRRR |
| To Date (`P_TODT`) | Yes | The end date of the invoice date range for the report (inclusive; report query adds one day internally to make the boundary exclusive) | Must not be blank; must not be entered before the From Date is set; must not be earlier than the From Date; must not be a future date; date range must not exceed three months; format mask DD/MM/RRRR |
| Destination (`P_DESTYPE`) | Auto-Populated | Destination type for the report output; field is disabled and not editable by the user | System-managed; not user-editable |
| Report Description (`REPORT_DESC`) | Auto-Populated | Display label showing the name of the report ('Exchange TradeIn Report'); reset to this value whenever the form is cleared | System-set; not editable |

#### Session and Control Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Logging Flag (`GLOBAL.APP_LOG`) | Auto-Populated | Session global that indicates whether performance logging is active for this environment; controls whether a timing measurement is started when the form opens | System-managed; not user-editable |
| Principal Map Code (`GLOBAL.PRINCIPAL`) | Auto-Populated | Identifies the principal (e.g. OEM) for the current session; used to scope all lookup queries to the correct principal's data | System-managed; not user-editable |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The current user's identifier; used to generate a unique filename for the CSV report output | System-managed; not user-editable |
| Application ID (`PARAMETER.P_APP_ID`) | Auto-Populated | Application identifier parameter passed in when the form is launched | Set by the calling application at form open |
| Dealer Code (`PARAMETER.P_DLR_CD`) | Auto-Populated | Dealer code parameter passed in at form launch; used in TV outlet lookup queries | Set by the calling application at form open |
| For Code (`PARAMETER.P_FOR_CD`) | Auto-Populated | Forward code parameter passed in at form launch; used in TV outlet lookup queries | Set by the calling application at form open |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Displays the current system copyright declaration text, refreshed each time the form is cleared | Populated by the copyright declaration function; not user-editable |
| Query Text (`TXT`) | Auto-Populated | Stores the dynamically assembled SQL query string at the point the report is submitted; retained for diagnostic purposes | System-set; not displayed to the user |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form's lookup fields and report query.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer List (LV_DEALER / RG_DEALER - MULDMS.AM_USER_DEALER, MULDMS.AM_DEALER_LOC, MULDMS.GM_CITY) | Provides the list of dealers the user is permitted to select, formatted with city, dealer name, and dealer code | When the user opens the Dealer Details lookup field |
| Outlet List (LV_LOC / RG_LOC - MULDMS.AM_DEALER_LOC, MULDMS.AM_USER_DEALER_MASTER) | Provides the list of outlets (locations) available for the selected dealer, showing location code and description | When the user opens the Outlet Details lookup field after selecting a dealer |
| TV Outlet List (LV_TVOUTLET / RG_TVOUTLET - SM_DMSPOC_TV_OUTLET) | Provides the list of TV outlets for the selected dealer and forward code | When the user opens the TV Outlet lookup field |
| New Vehicle Model List (LV_MODEL / RG_MODEL - GM_MOD) | Provides the list of new vehicle models available for the current principal, including an 'All Models' option | When the user opens the New Vehicle Model lookup field |
| New Vehicle Variant List (LV_VARIANT / RG_VARIANT - GM_VAR) | Provides the list of variants for the selected model, including an 'All Variants' option | When the user opens the New Vehicle Variant lookup field after selecting a model |
| Master Configuration List (AM_LIST) | Provides code-description pairs for drop-down fields populated at runtime (e.g. buying category, exchange status, sales type, channel type, fuel type, relationship type) | When the form populates drop-down fields and when the report query decodes certain code values into descriptions |
| City Description (MULDMS.GM_CITY) | Used to resolve city codes to city descriptions in the report output | During report query execution |
| Relationship Type (MULDMS.AM_LIST - list POC_RELATION) | Provides descriptions for the customer-to-invoice relationship codes shown in the report | During report query execution |
| New Insurance Owner (MULDMS.NI_NEW_MINS) | Provides the insurance owner name for the new vehicle at the time of invoice | During report query execution (correlated sub-query on VIN) |
| Loyalty Exchange Claim (MULDMS.SD_LOYLTY_EXCH_CLAIM) | Indicates whether a loyalty exchange claim has been submitted for each invoice | During report query execution (correlated sub-query on invoice number) |
| Vahan Verification (DMS_VAHAN_CHECK_DTL) | Provides Vahan-registered owner details, creation date, and owner's father/husband name for Vahan-verified vehicles | During report query execution (correlated sub-query on VIN and buying number) |
| Invoice Exchange Charges (SD_INV_CHARGES - charge type EXB) | Provides the exchange benefit discount amount given by the dealer for each invoice | During report query execution (correlated sub-query on invoice number) |
| Report Output Path Configuration (/reports/DMS/excelpath.txt) | Contains the server-side directory path where the CSV report file is written before being served to the browser | When the Submit Report button is pressed and the report file is being written |

### 6.4 Data Lifecycle

*Describes the evidenced behaviour for how data flows through the Exchange Trade-In report form.*

**Creation**

- The form does not create or insert any records. It is a reporting-only screen; all filter values entered by the user exist only as session-level parameters in the CB_BLK control block and are not persisted to the database.
- When the user presses Submit Report, the form dynamically assembles a data query for the selected exchange status category, executes it via the VIEW_EXCEL_REP program unit, and writes the result to a server-side CSV file. This is a read-only operation - no records are inserted.

**Updates**

- The form does not update any records. The only "writes" are the session context registrations (module name and client info) made by DBMS_APPLICATION_INFO at form open and cleared at form exit, which are database session metadata - not application data.

**Save and Commit**

- The save/commit key (KEY-COMMIT) is explicitly disabled on this form with a NULL trigger body (inactive - does not execute). The form has no save workflow.
- The report file is written to the server file system by the VIEW_EXCEL_REP program unit when the user presses the Submit Report button; this is a file system write, not a database commit.

**Retention and Audit**

- The form does not set or manage any audit stamps (created-by, modified-by, created-date, modified-date). The form is a reporting-only screen with no persistent data entry.
- The generated CSV file is placed on the application server at the path configured in /reports/DMS/excelpath.txt. No retention or cleanup policy for these files is evidenced in the form's code.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | REGION |  | AM_DEALER_LOC | REGION_CD | Region code read from the dealer location record (aloc.region_cd) for the invoiced dealer outlet. |
| 2 | Exchange Status, DLR, FOR, BOUGHT | DEALER CITY |  | GM_CITY | CITY_DESC | Shows the DEALER CITY taken from the enquiry's related records. |
| 3 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | DEALER-FOR CODE |  | AM_DEALER_LOC | MUL_DEALER_CD | Dealer-FOR code formed by concatenating aloc.mul_dealer_cd and aloc.for_cd from the dealer location record. |
| 4 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | DEALER NAME |  | AM_DEALER_LOC | DEALER_NAME | Dealer name read from aloc.dealer_name in the dealer location master; embedded commas replaced with spaces. |
| 5 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | INV NUM |  | SH_INVOICE | INV_NUM | Invoice number read from sh.inv_num in the sales invoice record. |
| 6 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | INV DATE |  | SH_INVOICE | INV_DATE | Invoice date read from sh.inv_date in the sales invoice record; filtered by the user-entered From/To date range. |
| 7 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | ADDRESS |  | AM_DEALER_LOC | DEALER_ADDRESS1 | Dealer address formed by concatenating aloc.dealer_address1, dealer_address2, and dealer_address3 from the dealer location record. |
| 8 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; TV Outlet; date range | TV OUTLET |  | SH_TV_EVAL | OUTLET_CD | True Value outlet code read from si.outlet_cd in the TV evaluation record. |
| 9 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Old Vehicle Reg Num; date range | OLD REG NUM |  | SH_TV_EVAL | REG_NO | Registration number of the old vehicle read from si.reg_no in the TV evaluation record. |
| 10 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH CUST NAME |  | SH_TV_EVAL | CUST_NAME | Customer name on the old vehicle record read from si.cust_name in the TV evaluation table; embedded commas replaced with spaces. |
| 11 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | MANUFACTURER |  | SH_TV_EVAL | MAKE | Manufacturer derived by decoding si.make: value 'M' displays as 'MARUTI', all others as 'NON MARUTI'. |
| 12 | Exchange Status, DLR, FOR, BOUGHT | OLD VEH MODEL |  | GM_MOD | MODEL_DESC | Shows the OLD VEH MODEL taken from GM_MOD.MODEL_DESC, looked up via PKG_ENQ_POC_DETAIL.SF_OLD_MODEL_DESC. |
| 13 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH SUBMODEL |  | SH_TV_EVAL | SUBMODEL | Sub-model description of the old vehicle read from si.submodel in the TV evaluation record. |
| 14 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH MANUFACTURE YEAR |  | SH_TV_EVAL | YOM | Year of manufacture of the old vehicle read from si.yom in the TV evaluation record. |
| 15 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH REG DATE |  | SH_TV_EVAL | DATE_OF_REG | Registration date of the old vehicle read from si.date_of_reg in the TV evaluation record. |
| 16 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH COLOR |  | SH_TV_EVAL | COLOR | Colour of the old vehicle read from si.color in the TV evaluation record. |
| 17 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH CHASSIS NO |  | SH_TV_EVAL | CHASSIS | Chassis number of the old vehicle read from si.chassis in the TV evaluation record. |
| 18 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH ENGINE _NUM |  | SH_TV_EVAL | ENGINE | Engine number of the old vehicle read from si.engine in the TV evaluation record. |
| 19 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH MILEAGE |  | SH_TV_EVAL | MILEAGE | Odometer mileage of the old vehicle read from si.mileage in the TV evaluation record. |
| 20 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH EVALUATION DATE |  | SH_TV_EVAL | EVAL_DATE | Evaluation date of the old vehicle read from si.eval_date in the TV evaluation record. |
| 21 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD CAR BUYING ID |  | SH_TV_EVAL | BUYING_NUM | Buying transaction identifier of the old vehicle read from si.buying_num in the TV evaluation record. |
| 22 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH BUYING DATE |  | SH_TV_EVAL | BUY_DATE | Date on which the old vehicle was bought read from si.buy_date in the TV evaluation record. |
| 23 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Old Vehicle Buying Category (TV / NTV); date range | OLD VEH CATEGORY |  | SH_TV_EVAL | CATEGORY | Vehicle category derived by decoding si.category: 'T' displays as 'TV' (True Value), 'N' as 'NTV' (Non-True Value). |
| 24 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH BUYING STATUS |  | SH_TV_EVAL | STATUS | Buying status of the old vehicle derived by decoding si.status: 'Y' or 'B' both display as 'LIVE'. |
| 25 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH PHONE NUM |  | SH_TV_EVAL | MOBILE_NO | Mobile/phone number of the old vehicle owner read from si.mobile_no in the TV evaluation record. |
| 26 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH EMISSION |  | SH_TV_EVAL | EMISSION | Emission standard of the old vehicle read from si.emission in the TV evaluation record. |
| 27 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH BUYING PRICE |  | SH_TV_EVAL | BUY_PRICE | Buying price agreed for the old vehicle read from si.buy_price in the TV evaluation record. |
| 28 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | OLD VEH REF PRICE |  | SH_TV_EVAL | REF_PRICE | Reference (evaluated) price of the old vehicle read from si.ref_price in the TV evaluation record. |
| 29 | Exchange Status, DLR, FOR, BOUGHT | EVALUATOR MSPIN |  | GM_EMP | MSPIN | Shows the EVALUATOR MSPIN taken from GM_EMP.MSPIN, looked up via PKG_POC_DMS.FNC_EVAL_EVALUATOR_MSPIN. |
| 30 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | EVALUATOR NAME |  | GM_EMP |  | Evaluator's employee name looked up via PKG_POC_DMS.fnc_eval_evaluator_name, which selects GM.EMP_NAME from GM_EMP joined to RH_ENQ on ENQ_EVALUATOR = EMP_CD. |
| 31 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; Outlet Details; date range | NEW VEH VIN |  | SH_INVOICE | VIN | Vehicle Identification Number of the new vehicle read from sh.vin in the sales invoice record. |
| 32 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; New Vehicle Model; date range | NEW MODEL |  | GM_MOD | MODEL_DESC | Model description of the new vehicle read from mo.model_desc in the model master; embedded commas replaced with spaces. |
| 33 | Exchange Status (BOUGHT, EVALUATION, CANCEL, BOUGHT & EVALUATION); Dealer Details; New Vehicle Variant; date range | NEW VARIANT CD |  | GM_VAR | VARIANT_CD | Variant code of the new vehicle read from gv.variant_cd in the variant master; embedded commas replaced with spaces. |
| 34 | Exchange Status, DLR, FOR, BOUGHT | NEW VARIANT DESC |  | GM_VAR | VARIANT_DESC | New vehicle variant description read from gm_var (alias gv) joined via sh_ordbook; commas replaced with spaces in the output. |
| 35 | Exchange Status, DLR, FOR, BOUGHT | NEW ENGINE NUM |  | SH_INVOICE | ENGINE_NUM | Engine number of the new vehicle taken directly from sh_invoice (alias sh). |
| 36 | Exchange Status, DLR, FOR, BOUGHT | NEW CHASSIS NUM |  | SH_INVOICE | CHASSIS_NUM | Chassis number of the new vehicle taken directly from sh_invoice (alias sh). |
| 37 | Exchange Status, DLR, FOR, BOUGHT | NEW VEH CUST NAME |  | SH_INVOICE | INV_PARTY_CD | Invoice party code identifying the new-vehicle customer, read from sh_invoice (alias sh). |
| 38 | Exchange Status, DLR, FOR, BOUGHT | NEW VEH RELATION |  | AM_LIST | LIST_DESC | Shows the NEW VEH RELATION taken from the enquiry's related records. |
| 39 | Exchange Status, DLR, FOR, BOUGHT | NEW VEH DSE |  | GM_EMP | FIRST_NAME | Shows the NEW VEH DSE taken from GM_EMP.FIRST_NAME, looked up via SF_GET_EMP_NAME. |
| 40 | Exchange Status, DLR, FOR, BOUGHT | NEW VEH MSPIN |  | GM_EMP | MSPIN | MSPIN (employee identifier) of the salesperson linked to the new vehicle invoice, read from gm_emp (alias emp). |
| 41 | Exchange Status, DLR, FOR, BOUGHT | FUEL TYPE |  | GM_VAR | FUELTYPE_CD | Fuel type code of the new vehicle variant, read from gm_var (alias gv). |
| 42 | Exchange Status, DLR, FOR, BOUGHT | EXCH CANC DATE |  | SH_INVOICE | EXCH_CANC_DATE | Date on which the exchange transaction was cancelled, read from sh_invoice (alias sh). |
| 43 | Exchange Status, DLR, FOR, BOUGHT | EXCH CANC REASON |  | SH_INVOICE | EXCH_CANC_TYPE | Cancellation reason/type code for the exchange, read from sh_invoice (alias sh). |
| 44 | Exchange Status, DLR, FOR, BOUGHT | NEW VEH INSURANCE OWNER NAME |  | NI_NEW_MINS | MINS_CUST_NAME | Shows the NEW VEH INSURANCE OWNER NAME taken from the enquiry's related records. |
| 45 | Exchange Status, DLR, FOR, BOUGHT | CLAIM STATUS |  | AM_LIST | LIST_DESC | Shows the CLAIM STATUS status description (AM_LIST.LIST_DESC), looked up via sf_bonus_claim_status. |
| 46 | Exchange Status, DLR, FOR, BOUGHT | BONUS MASTER MAIN BONUS |  | SM_BONUS_MASTER | BT | Shows the BONUS MASTER MAIN BONUS taken from SM_BONUS_MASTER.BT, looked up via SF_GET_TOTAL_BONUS. |
| 47 | Exchange Status, DLR, FOR, BOUGHT | DISC GIVEN BY DEALER(UNDER EXBD) |  | SD_INV_CHARGES | CHARGE_AMT | Shows the DISC GIVEN BY DEALER(UNDER EXBD) taken from the enquiry's related records. |
| 48 | Exchange Status, DLR, FOR, BOUGHT | Age Of Old Car |  | SH_INVOICE | OLD_CAR_AGE | Age of the old car (in years) at the time of the exchange transaction, read from sh_invoice (alias sh). |
| 49 | Exchange Status, DLR, FOR, BOUGHT | SALES TYPE |  | SH_INVOICE | SALES_TYPE | Sales type code from sh_invoice (alias sh) decoded to a display label (e.g. BSF Customer, Individual, HUF/Corporate/Institution). |
| 50 | Exchange Status, DLR, FOR, BOUGHT | CHANNEL |  | AM_LIST | LIST_DESC | Shows the CHANNEL taken from the enquiry's related records. |
| 51 | Exchange Status, DLR, FOR, BOUGHT | Old Car Vahan Flag |  | SH_TV_EVAL | VAHAN_VALID_FLAG | Flag indicating whether Vahan validation was performed on the old car, read from sh_tv_eval (alias si). |
| 52 | Exchange Status, DLR, FOR, BOUGHT | OTP Declaration Flag |  | SH_INVOICE | DECLARE_OTP_YN | Y/N flag indicating whether the customer OTP declaration was captured, read from sh_invoice (alias sh). |
| 53 | Exchange Status, DLR, FOR, BOUGHT | OTP Declaration Flag Date |  | SH_INVOICE | CUST_DECL_PDATE | Date on which the customer OTP/price declaration was made, read from sh_invoice (alias sh). |
| 54 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Customer Father / Husband Name |  | SH_TV_EVAL | CUST_FATHER_HUS_NAME | Father or husband name of the old-car owner as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 55 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Customer State |  | SH_TV_EVAL | VAHAN_STATE_DESC | State of the old-car owner as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 56 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Customer City |  | SH_TV_EVAL | VAHAN_CITY_DESC | City of the old-car owner as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 57 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Model Variant |  | SH_TV_EVAL | VAHAN_MODEL_VARIANT | Model variant of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 58 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Color |  | SH_TV_EVAL | VAHAN_COLOUR | Colour of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 59 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Fuel |  | SH_TV_EVAL | VAHAN_FUEL | Fuel type of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 60 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Manufacturing Month/Year |  | SH_TV_EVAL | MANUFACTURING_MONTH_YR | Manufacturing month and year of the old car as returned by Vahan, read from sh_tv_eval (alias si). |
| 61 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old car VIN |  | SH_TV_EVAL | VAHAN_VIN | VIN of the old car as returned by the Vahan lookup, read from sh_tv_eval (alias si). |
| 62 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Emission |  | SH_TV_EVAL | VAHAN_EMISSION | Emission norm category of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 63 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Commercial Flag |  | SH_TV_EVAL | COMMERCIAL_VEH_FLAG | Flag indicating whether the old car is classified as a commercial vehicle by Vahan, read from sh_tv_eval (alias si). |
| 64 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car RC Status |  | SH_TV_EVAL | VAHAN_RC_STATUS | Registration Certificate status of the old car as returned by Vahan, read from sh_tv_eval (alias si). |
| 65 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old car Road Tax Status |  | SH_TV_EVAL | VAHAN_ROAD_TAX_STATUS | Road tax payment status of the old car as returned by Vahan, read from sh_tv_eval (alias si). |
| 66 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Body Type |  | SH_TV_EVAL | VAHAN_BODY_TYPE | Body type of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 67 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car PUCC Upto |  | SH_TV_EVAL | PUCC_UPTO | Pollution Under Control Certificate validity date of the old car as returned by Vahan, read from sh_tv_eval (alias si). |
| 68 | Exchange Status, DLR, FOR, BOUGHT | Vahan Old Car Financer Name |  | SH_TV_EVAL | FINANCER_NAME | Name of the financier (hypothecation holder) of the old car as returned by Vahan, read from sh_tv_eval (alias si); commas replaced with spaces. |
| 69 | Exchange Status, DLR, FOR, BOUGHT & EVALUATION | RVSF NAME |  | SH_INVOICE | RVSF_NAME | Name of the Registered Vehicle Scrappage Facility (RVSF) associated with the exchange transaction, read from sh_invoice (alias sh). |
| 70 | Exchange Status, DLR, FOR, BOUGHT & EVALUATION | RVSF ADDRESS |  | SH_INVOICE | RVSF_ADDRESS | Address of the RVSF associated with the exchange transaction, read from sh_invoice (alias sh); commas replaced with spaces in the output. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_LIST | Application list master - a configurable lookup table storing code and description pairs grouped by list name and principal, used to populate drop-down list items in the form | - | LOV, Principal |
| AM_USER_DEALER_MASTER | User-dealer access master table - records which dealers, parent groups, and outlet locations each system user is authorised to access | - | Dealer, Outlet, Principal |
| Bought (B) | Exchange status indicating the old vehicle has been invoiced and purchased by the dealer | - | Exchange Status, Trade-In |
| Buying Category | Classification of a trade-in vehicle; TV (True Value / third-party) or NTV (Non-True Value) | Buy Category | TV, NTV |
| Cancelled (C) | Exchange status indicating the exchange transaction was cancelled after invoice; filtered by exchange cancellation date | - | Exchange Status, Trade-In |
| CB_BLK | Control block in Oracle Forms - the single data block of sr_exch_tradein containing all report parameter and UI items; not bound to a database table | Control Block | Block, Oracle Forms |
| CSV | Comma-Separated Values - the file format used for the generated exchange trade-in report export | Spreadsheet Export | Report, VIEW_EXCEL_REP |
| Dealer | A franchised vehicle sales outlet identified by a dealer map code and for-code within the DMS | - | Outlet, For-Code, Principal |
| DMS | Dealer Management System - the integrated software platform for dealership sales, service, and reporting operations | - | Dealer, Oracle Forms |
| DPL | Shared PL/SQL program library (DPL.pld) attached to the form, providing common utility procedures such as DISP_TEXT and RAISE_ERROR | DPL.pld | PLD, GENERAL |
| Evaluation (E) | Exchange status indicating the old vehicle has been evaluated but not yet formally purchased | - | Exchange Status, Trade-In |
| Exchange Status | The current stage of a vehicle exchange transaction: Bought, Evaluation, Cancelled, or Bought+Evaluation combined | Exch Status, P_EXCH_STS | Trade-In, Bought, Evaluation, Cancelled |
| For-Code | Franchise code identifying the manufacturer franchise associated with a dealer | - | Dealer, Principal |
| GENERAL | The namespace qualifier used in this form's PL/SQL to invoke shared library routines such as GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR | - | DPL, DISP_TEXT, RAISE_ERROR |
| GM_MOD | Vehicle model master table - stores model codes and descriptions for the current principal | - | GM_VAR, Model |
| GM_VAR | Vehicle variant master table - stores variant codes and descriptions linked to model codes and principal | - | GM_MOD, Variant |
| LOV | List of Values - a pop-up selection list in Oracle Forms that allows the user to choose a valid value for a field | Dropdown, Picklist | Record Group, LV_ |
| MULDMS | Database schema housing multi-dealer master and transaction tables (e.g. AM_DEALER_LOC, AM_USER_DEALER_MASTER) | - | Dealer, DMS |
| NTV | Non-True Value - a buying category for trade-in vehicles that are not part of the manufacturer's certified pre-owned programme | Non-TV | Buying Category, TV |
| Outlet | A specific branch or location of a dealer, identified by a location code (LOC_CD) within the dealer group | Location | Dealer, LOC_CD |
| PLD | Program Library Definition - a shared Oracle Forms PL/SQL library (`.pld` file) containing reusable utility procedures and functions | Program Library | DPL, GENERAL |
| Principal | The manufacturer or brand company code (PRINCIPAL_MAP_CD) used to scope all data queries to the relevant brand in multi-principal deployments | Principal Map Code | Dealer, DMS |
| Record Group | An Oracle Forms in-memory data structure populated by a SQL query; used to back LOV pop-up lists | RG_ | LOV, Dynamic Bindings |
| SM_DMSPOC_TV_OUTLET | TV outlet master table - stores third-party outlet codes and descriptions for the point-of-contact exchange programme | - | TV, Outlet |
| TV | True Value - a buying category for certified pre-owned vehicles traded in through the manufacturer's programme | True Value | NTV, Buying Category |
| TV Outlet | A third-party (True Value) outlet associated with the dealer used in the exchange programme | TV Outlet Code | TV, Outlet |
| Vahan | Government vehicle registration database used to verify vehicle details such as owner name, chassis, emission, and road tax status; data is appended to the report | - | RC Status, VIN |
| VIN | Vehicle Identification Number - unique chassis identifier for a new vehicle used as a key in invoice and order records | Chassis Number | New Vehicle |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: sr_exch_tradein (SR_EXCH_TRADEIN)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Exchange TradeIn Report (inherited from DPL.olb object group OG_GROUP; no local window definition overrides the inherited value)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PKG_ENQ_POC_DETAIL, PKG_POC_DMS
- Source artifacts: `sr_exch_tradein_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); D2KWUTIL; DPL (DPL.pld program library); PCK `PKG_ENQ_POC_DETAIL.pck`; PCK `PKG_POC_DMS.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed from the calling context; used to identify the calling application at session level |
| APP_LOG | Char | Trigger | Application logging flag; when set to `Y`, activates the performance timer at form startup |
| COMP_FA | Char | Trigger | Company financial-authority code; set at session initialisation and used to scope company-level access |
| CUR_DATE | Char | ProgramUnit | Current system date used for date validation comparisons |
| DEALER | Char | ProgramUnit / Trigger | Current dealer map code used as a filter in list population queries |
| GROUP_CD | Char | Trigger | Dealer group code; set at session initialisation and used to scope group-level outlet queries |
| LOC_CD | Char | Trigger | Outlet location code; set at session initialisation and used to default the outlet filter |
| PARENT_GROUP | Char | Trigger | Parent group code; used to scope outlet location queries to the dealer's parent group |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal (manufacturer) map code used to scope all data queries to the current company |
| P_FIN_YR | Char | Trigger | Current financial year; set at session initialisation and used to scope financial-year-sensitive queries |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user identifier used to scope dealer access and name the generated CSV output file |
| USER_NAME | Char | Trigger | Display name of the logged-in user; set at session initialisation for labelling and audit purposes |

### 8.1.2 Form Parameters

*All 3 ModuleParameter entries from sr_exch_tradein_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup; used to identify the calling application context |
| P_DLR_CD | Char | - | Dealer code passed at form startup; used to filter TV outlet records in record group queries |
| P_FOR_CD | Char | - | For-code (franchise code) passed at form startup; used alongside dealer code to filter TV outlet data |

**Total Parameters:** 3

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control block - entry point for report parameter selection; no database table bound |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from sr_exch_tradein_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in sr_exch_tradein_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `sr_exch_tradein_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 23 | 0 | 23 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **45** | **0** | **45** |

**Item detail (all 45 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | P_DELR_CD | false | Dealer code filter - selected dealer for report scoping |
| CB_BLK | P_LOC_CD | false | Outlet location code filter - selected outlet for report scoping |
| CB_BLK | P_LOC_DESC | false | Outlet location description - display label for selected outlet |
| CB_BLK | P_DEALER_MAP_CD | false | Dealer map code - internal dealer identifier used in query filters |
| CB_BLK | P_PARENT_GROUP | false | Parent group code - dealer group identifier used in outlet location query |
| CB_BLK | P_BUY_CATEG | false | Buying category filter - list item to select TV or NTV category |
| CB_BLK | P_REG_NUM | false | Old vehicle registration number filter - optional search criterion |
| CB_BLK | P_MODEL_DESC | false | Model description - display field for selected vehicle model |
| CB_BLK | P_MODEL | false | Model code filter - vehicle model code for report scoping |
| CB_BLK | P_VARIANT_DESC | false | Variant description - display field for selected vehicle variant |
| CB_BLK | P_VARIANT | false | Variant code filter - vehicle variant code for report scoping |
| CB_BLK | P_EXCH_STS | false | Exchange status filter - list item selecting Bought, Evaluation, Cancelled, or Bought+Evaluation |
| CB_BLK | P_INV_TYPE | false | Invoice type filter - list item to filter by invoice status |
| CB_BLK | P_TV_OUTLET_DESC | false | TV outlet description - display field for selected third-party outlet |
| CB_BLK | P_TV_OUTLET | false | TV outlet code filter - third-party outlet code for report scoping |
| CB_BLK | REPORT_DESC | false | Report title display - shows fixed label "Exchange TradeIn Report" |
| CB_BLK | P_FROMDT | false | From date filter - start of date range; mandatory, validated against current date and to date |
| CB_BLK | P_TODT | false | To date filter - end of date range; mandatory, must be ≥ from date and ≤ current date |
| CB_BLK | P_DESTYPE | false | Destination type - list item selecting report output destination |
| CB_BLK | SUBMIT | false | Submit button - triggers report generation and exports data to CSV |
| CB_BLK | S_NUM | false | Serial number - internal sequence field used during report export processing |
| CB_BLK | TXT | false | Query text - stores the dynamically built SQL query string for the report |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration - displays legal copyright text populated at form startup |
| PB_BLK | PB_EXIT | false | Exit button (inherited from OG_GROUP/PB_BLK) - closes the form; triggers WHEN-BUTTON-PRESSED which calls GENERAL.ASK_CONFIRM before exiting |
| PB_BLK | PB_LIST | false | List-of-values button (inherited from OG_GROUP/PB_BLK) - invokes the LOV attached to the current item |
| PB_BLK | PB_INSERT | false | Insert button (inherited from OG_GROUP/PB_BLK) - initiates a new record insertion; inactive in this report-only form |
| PB_BLK | PM_CONT | false | Continue/context button (inherited from OG_GROUP/PB_BLK) - provides a context-sensitive navigation or continuation action |
| PB_BLK | PB_DEL | false | Delete button (inherited from OG_GROUP/PB_BLK) - initiates record deletion; inactive in this report-only form |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited from OG_GROUP/PB_BLK) - cancels pending changes and reverts the form state |
| PB_BLK | PB_SAVE | false | Save button (inherited from OG_GROUP/PB_BLK) - commits pending changes; inactive in this report-only form |
| PB_BLK | PB_PRINT | false | Print button (inherited from OG_GROUP/PB_BLK) - invokes the print action for the current report output |
| PB_BLK | PB_CUT | false | Cut button (inherited from OG_GROUP/PB_BLK) - cuts the selected text from the current field |
| PB_BLK | PB_COPY | false | Copy button (inherited from OG_GROUP/PB_BLK) - copies the selected text from the current field |
| PB_BLK | PB_PASTE | false | Paste button (inherited from OG_GROUP/PB_BLK) - pastes clipboard text into the current field |
| PB_BLK | PB_ERR_EXIT | false | Error-exit button (inherited from OG_GROUP/PB_BLK) - closes the error window and returns focus to the main canvas |
| CB_ERR | TXT_ERR | false | Error message text item (inherited from OG_GROUP/CB_ERR) - displays the error message text in the WIN_ERR error window |
| WEBUTIL | DUMMY | false | WEBUTIL infrastructure button - push button in the WEBUTIL block with an empty WHEN-BUTTON-PRESSED trigger body; no active business logic; included for completeness of the full item inventory |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes client-information JavaScript functions to the Forms session |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes client-side file-access functions (open, save, transfer) to the Forms session |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes host-command execution functions to the Forms session |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes session-management functions to the Forms session |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes file-transfer functions between client and server to the Forms session |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes OLE/COM automation functions to the Forms session |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes C-API (DLL/shared-library) call functions to the Forms session |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WEBUTIL infrastructure bean area - exposes browser-control functions (URL navigation, document display) to the Forms session |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_LOC | Outlet Details... | RG_LOC | CB_BLK.P_LOC_CD |
| LV_DEALER | Dealer Details... | RG_DEALER | CB_BLK.P_DELR_CD |
| LV_TVOUTLET | Outlet... | RG_TVOUTLET | CB_BLK.P_TV_OUTLET_DESC |
| LV_VARIANT | Variant... | RG_VARIANT | CB_BLK.P_VARIANT_DESC |
| LV_MODEL | Model... | RG_MODEL | CB_BLK.P_MODEL_DESC |

**Total LOVs:** 5

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Inherited from webutil.olb via WEBUTIL object group; called by the WebUtil internal error handler when a client-side WebUtil operation fails |
| ALERT_BUT | Note | Please select valid region code and for code | Displayed when dealer or outlet selection is invalid; called from WHEN-VALIDATE-ITEM on CB_BLK.P_DELR_CD and CB_BLK.P_LOC_CD |
| AL_PRINT | Print | (set at runtime) | Inherited from OG_GROUP (DPL_MTPL); invoked by print-related actions to confirm or report print status |
| AL_ERRINFO | Error | (set at runtime) | Inherited from OG_GROUP (DPL_MTPL); invoked by GENERAL.RAISE_ERROR and ON-ERROR to display error-level messages |
| AL_NOTE | Note | (set at runtime) | Inherited from OG_GROUP (DPL_MTPL); invoked by GENERAL.DISP_TEXT to display informational messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from OG_GROUP (DPL_MTPL); invoked by GENERAL.ASK_CONFIRM to prompt the user for yes/no confirmation (e.g. before exit) |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **6 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL, GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Entire body is block-commented; formerly validated test-drive form fields (plate number, model year, dates, odometer, location, salesman) using CHECK_NULL |
| CHECK_BEFORE_DELETE | Unknown | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Body is `NULL;` with a commented block; formerly checked for dependent enquiry records before allowing zone master deletion |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab (type reference) | Package specification declaring a PL/SQL table variable `v_tab` of type `pk_plsql_table.code_tab`; used for error code collection |
| L_POPULATE | Procedure | AM_LIST, id_null (webutil), Create_Group_From_Query, Populate_Group, Populate_List | Populates a list item from the AM_LIST lookup table; queries list codes and descriptions filtered by list name and current principal, then loads the result into the specified list item |
| PR_REMOVE_ASCII_CHR | Procedure | text_io.fopen, text_io.get_line, text_io.put_line, text_io.fclose, web.show_document, GENERAL.DISP_TEXT | Reads a server-side report file, removes lines beginning with ASCII 12 (form-feed characters), writes cleaned output to a new file, and opens the file in the browser |
| VIEW_EXCEL_REP | Procedure | id_null (webutil), Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Delete_Group | Executes a dynamic SQL query, creates an in-memory record group, and prepares data for CSV export; used by the SUBMIT button to export exchange trade-in report data |

**Total Program Units:** 6

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level; PB_BLK.PB_EXIT WHEN-BUTTON-PRESSED (inherited) | Displays AL_CONFIRM caution alert to request user confirmation before a destructive or exit action; returns the user's yes/no response to the caller |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Called only from the commented-out VALIDATE_CN_MAIN procedure; validates that required fields are not null |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_DELR_CD WHEN-VALIDATE-ITEM, CB_BLK.P_EXCH_STS WHEN-VALIDATE-ITEM, CB_BLK.P_FROMDT WHEN-VALIDATE-ITEM, CB_BLK.P_LOC_CD WHEN-VALIDATE-ITEM, CB_BLK.P_TODT WHEN-VALIDATE-ITEM, Form level ON-ERROR, Form level ON-MESSAGE, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays an alert dialog with the supplied message text and title; used for error and informational messages throughout the form |
| GENERAL.RAISE_ERROR | Library routine | Form level ON-ERROR | Looks up an error message by code and displays it as an error or caution alert; raises FORM_TRIGGER_FAILURE when message type is Error |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Formerly intercepted Oracle error codes 40209, 40207, 50026, and 50004 via GENERAL.DISP_TEXT and raised FORM_TRIGGER_FAILURE; also handled integrity constraint violations (ORA-02292) via GENERAL.RAISE_ERROR('E0088') and concurrent-update errors | Superseded by the active ON-ERROR trigger body below the commented block; legacy code preserved for reference |
| **Inactive stub** | Form | - | KEY-COMMIT | Body is `NULL;` - commit action is fully suppressed; no record saving occurs | Form is report-only (no DML); KEY-COMMIT intentionally disabled with null stub |
| **Commented out** | Form | - | FT_SAVE | Formerly triggered a save/commit action via the toolbar Save button; body is block-commented | Superseded by the inherited FT_SAVE trigger from OG_GROUP; local override is inactive |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Formerly initialised global variables, populated lists, set default parameter values, and set up the copyright declaration at form startup | Superseded by the active WHEN-NEW-FORM-INSTANCE inherited from OG_GROUP and the active PRE-FORM trigger; legacy initialisation code preserved in comments |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Formerly called GENERAL.ASK_CONFIRM and exited the form if the user confirmed | Superseded by the inherited WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT from OG_GROUP/PB_BLK; local override body is commented out |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (38 business triggers):**
*sr_exch_tradein_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; displays user-friendly messages for invalid date (50004), format errors (50025/50026), numeric field errors (40209), mandatory field errors (40207), integrity constraint violations (ORA-02292), and concurrent-update conflicts; rolls back on unhandled SQLCODE |
| ON-MESSAGE | Form | - | Form level | Intercepts Oracle Forms system messages and displays them via GENERAL.DISP_TEXT for error-type messages (40209, 40207), suppressing default message dialogs |
| KEY-EXIT | Form | - | Form level | Clears application session info via DBMS_APPLICATION_INFO and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Determines the LOV attached to the current item and displays it; navigates to next item on successful LOV selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Body is `NULL;`; commit is suppressed as the form performs no DML |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, resets the report description label to "Exchange TradeIn Report", and repopulates the copyright declaration field |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses unhandled key actions to prevent default Forms key behaviour from interfering with the form's navigation model |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Navigates to the next item in the tab order; inherited from OG_GROUP |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Navigates to the previous item in the tab order; inherited from OG_GROUP |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates to the next block; inherited from OG_GROUP |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates to the previous block; inherited from OG_GROUP |
| KEY-DOWN | Form | - | Form level (inherited) | Navigates down within a multi-record block or to the next item; inherited from OG_GROUP |
| KEY-UP | Form | - | Form level (inherited) | Navigates up within a multi-record block or to the previous item; inherited from OG_GROUP |
| FT_SAVE | Form | - | Form level (inherited) | Toolbar Save trigger inherited from OG_GROUP; local override is commented out - see Section 8.7.1 |
| FT_CANCEL | Form | - | Form level (inherited) | Toolbar Cancel trigger inherited from OG_GROUP; cancels pending changes and reverts the form to its last committed state |
| FT_INSERT | Form | - | Form level (inherited) | Toolbar Insert trigger inherited from OG_GROUP; initiates a new record insertion; inactive in this report-only form |
| FT_DEL | Form | - | Form level (inherited) | Toolbar Delete trigger inherited from OG_GROUP; initiates record deletion; inactive in this report-only form |
| FT_LIST | Form | - | Form level (inherited) | Toolbar List trigger inherited from OG_GROUP; invokes the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Toolbar Print trigger inherited from OG_GROUP; invokes the print action for the current report output |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises global variables, populates list items via L_POPULATE, sets default parameter values, and populates the copyright declaration field at form startup; inherited from OG_GROUP - local override is commented out (see Section 8.7.1) |
| PRE-FORM | Form | - | Form level | Starts the application performance timer if logging is enabled; registers the form module name with DBMS_APPLICATION_INFO for session tracking |
| WHEN-VALIDATE-ITEM | CB_BLK | P_DELR_CD | CB_BLK.P_DELR_CD | Validates that the dealer code is not empty; raises FORM_TRIGGER_FAILURE with an error message if the field is null |
| WHEN-VALIDATE-ITEM | CB_BLK | P_LOC_CD | CB_BLK.P_LOC_CD | Validates that the outlet location code is not empty; raises FORM_TRIGGER_FAILURE with an error message if the field is null |
| WHEN-VALIDATE-ITEM | CB_BLK | P_EXCH_STS | CB_BLK.P_EXCH_STS | Validates that the exchange status is not empty; raises FORM_TRIGGER_FAILURE with an error message if the field is null |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROMDT | CB_BLK.P_FROMDT | Validates from date: enforces non-null, ensures date is not in the future, ensures it does not exceed to date; also auto-calculates the to date as one month after the from date (capped at current date) |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TODT | CB_BLK.P_TODT | Validates to date: enforces non-null, ensures from date is entered first, ensures to date is not less than from date, ensures to date is not in the future, and restricts the date range to a maximum of three months |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Generates a dynamic SQL query based on the selected exchange status (Bought/Evaluation/Cancelled/Bought+Evaluation), applies all filter parameters, and exports the result set to a CSV file via VIEW_EXCEL_REP |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Calls GENERAL.ASK_CONFIRM to prompt the user before exiting; exits the form if the user confirms; inherited from OG_GROUP/PB_BLK - local commented-out override exists (see Section 8.7.1) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Invokes the LOV attached to the current item when the toolbar List button is pressed; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Initiates a new record insertion when the toolbar Insert button is pressed; inactive in this report-only form; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Provides a context-sensitive continuation action; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Initiates record deletion when the toolbar Delete button is pressed; inactive in this report-only form; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels pending changes when the toolbar Cancel button is pressed; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Commits pending changes when the toolbar Save button is pressed; inactive in this report-only form; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Invokes the print action for the current report output when the toolbar Print button is pressed; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts the selected text from the current field when the toolbar Cut button is pressed; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies the selected text from the current field when the toolbar Copy button is pressed; inherited from OG_GROUP/PB_BLK |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text into the current field when the toolbar Paste button is pressed; inherited from OG_GROUP/PB_BLK |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Exchange TradeIn Report (Rel 1.2.11) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

*Both WN_MAIN and WIN_ERR are inherited from OG_GROUP (DPL_MTPL). CN_MAIN hosts the main report parameter entry area displayed in WN_MAIN. CN_TOOL hosts the inherited toolbar button block (PB_BLK) also displayed in WN_MAIN. CN_ERR is displayed in WIN_ERR and hosts the CB_ERR error message block.*

---

### 8.9 Editors

*No editors found in sr_exch_tradein_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in sr_exch_tradein_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime. The form contains 2 object groups: OG_GROUP (inherited from DPL_MTPL, 41 children) and WEBUTIL (inherited from WEBUTIL library, 4 children).*

**Object Group: OG_GROUP** (parent module: DPL_MTPL)

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

**Object Group: WEBUTIL** (parent module: WEBUTIL)

| Object Group Child | Type |
| :--- | :--- |
| WEBUTIL_ERROR | Alert |
| WEBUTIL_HIDDEN_WINDOW | Window |
| WEBUTIL_CANVAS | Canvas |
| WEBUTIL | Block |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in sr_exch_tradein_fmb.xml.*

## 9. Object Library

*The form references the DPL object library, which supplies shared visual attributes and property classes used by forms across the application suite. The full catalogue of library objects is drawn from the supplied OLB file.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box style - gray background, Arial 8pt, black foreground, transparent fill | referenced | N/A |
| VA_RB | VisualAttribute | Radio button style - gray background, Arial 8pt, black foreground, transparent fill | referenced | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button style - white background, black foreground, transparent fill | referenced | N/A |
| VA_DESC | VisualAttribute | Description field style - gray background, Small Fonts 7pt medium, blue foreground, transparent fill | referenced | N/A |
| VA_NUM | VisualAttribute | Numeric field style - white background, Arial 8pt plain medium, black foreground, transparent fill | referenced | N/A |
| VA_MAND | VisualAttribute | Mandatory field style - cyan background, Arial 9pt plain medium, black foreground, transparent fill | referenced | N/A |
| VA_OPROMPT | VisualAttribute | Optional prompt style - white background, Arial prompt, black prompt foreground, transparent fill | referenced | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory prompt style - white background, Arial prompt, red prompt foreground, transparent fill | referenced | N/A |
| VA_TEXT | VisualAttribute | Standard text item style - white background, Arial 9pt plain medium, black foreground, transparent fill | referenced | N/A |
| VA_BUTN | VisualAttribute | Button style - gray background, Arial 10pt bold, black foreground, transparent fill | referenced | N/A |
| VA_ALERT | VisualAttribute | Alert dialog style - gray background, MT Extra 11pt demilight, black foreground, transparent fill | referenced | N/A |
| VA_TITLE | VisualAttribute | Title style - gray background, Arial 10pt bold, blue foreground, transparent fill | referenced | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date style - white background, Courier bold, black foreground, transparent fill | referenced | N/A |
| VA_LOV | VisualAttribute | LOV field style - gray background, Arial 9pt, dark blue foreground, transparent fill | referenced | N/A |
| VA_DISP | VisualAttribute | Display field style - r25g75b75 background, Arial 8pt bold, black foreground, transparent fill | referenced | N/A |
| PC_DESC | PropertyClass | Display item property class - left-justified, white background, Arial 9pt, blue foreground, no bevel, max length 110, no keyboard navigation | referenced | N/A |
| PC_SC_DATE | PropertyClass | Scrolling calendar date display property class - gray background, Arial 8pt bold, blue foreground, format mask blank, date hint text for DD-MM-YY / DD/MM/YY | referenced | N/A |
| PC_TITLE | PropertyClass | Title text item property class - centre-justified, gray background, Arial 10pt bold, blue foreground, uppercase, auto-hint | referenced | N/A |
| PC_FORMAT | PropertyClass | Format text item property class - centre-justified, white background, Arial 9pt, black foreground, uppercase, max length 12 | referenced | N/A |
| PC_MR_BLK | PropertyClass | Multi-record block property class - navigates to PB_BLK, vertical record orientation, scrollbar width 12 | referenced | N/A |
| PC_DISP | PropertyClass | Read-only display text item property class - left-justified, disabled, gray8 background, Arial 9pt, no auto-hint, no keyboard navigation, mixed case, lowered bevel | referenced | N/A |
| PC_LOV | PropertyClass | LOV field property class - gray background, Arial 8pt, dark blue foreground, LOV position 80/96, auto-select off | referenced | N/A |
| PC_FORM | PropertyClass | Form-level property class - item validation unit, no savepoint mode, console window WN_MAIN, menu menu.mmx; includes embedded ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, and KEY-CLRFRM triggers | referenced | N/A |
| PC_DISP_DATE | PropertyClass | Read-only date display property class - disabled, gray8 background, Arial 9pt, format mask DD-MM-RRRR, no keyboard navigation | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Read-only numeric display property class - right-justified, disabled, gray8 background, Arial 9pt, number data type, lowered bevel, no keyboard navigation | referenced | N/A |
| PC_DATE | PropertyClass | Editable date text item property class - white background, Arial 9pt, format mask DD-MM-RRRR, date hint, mouse-navigate, max length 10, popup menu POP_MAIN | referenced | N/A |
| PC_DTTIME | PropertyClass | Editable date-time property class - white background, Arial 8pt, format mask DD-MM-RRRR HH24:MI, datetime data type, initialize to current DB datetime | referenced | N/A |
| PC_CB | PropertyClass | Check box property class - white background, Arial 9pt, check box item type | referenced | N/A |
| PC_ALERT | PropertyClass | Alert property class - gray background, MT Extra 11pt demilight, black foreground | referenced | N/A |
| PC_MDATE | PropertyClass | Mandatory date property class - white background, format mask DD-MM-RRRR, date hint, mouse-navigate, max length 10, red prompt foreground, popup menu POP_MAIN; includes embedded WHEN-VALIDATE-ITEM trigger that checks for null value | referenced | N/A |
| PC_RB | PropertyClass | Radio button property class - gray background, Arial 9pt, black foreground | referenced | N/A |
| PC_WIND | PropertyClass | Window property class - gray background, Arial 10pt bold, blue foreground, resizable, maximisable, minimisable, hide on exit, position 0/0 | referenced | N/A |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial, black foreground, window WN_MAIN, raise on enter | referenced | N/A |
| PC_BUTN | PropertyClass | Push button property class - gray background, Arial 9pt bold, black foreground, no mouse-navigate, width 42, height 16 | referenced | N/A |
| PC_TEXT | PropertyClass | Standard editable text item property class - left-justified, white background, Arial 9pt plain medium, black foreground, auto-hint, popup menu POP_MAIN, mixed case | referenced | N/A |
| PC_MTEXT | PropertyClass | Mandatory editable text item property class - left-justified, white background, Arial 9pt, red prompt foreground, popup menu POP_MAIN; includes embedded WHEN-VALIDATE-ITEM trigger that checks for null value | referenced | N/A |
| PC_UTEXT | PropertyClass | Uppercase editable text item property class - left-justified, white background, Arial 9pt plain medium, black foreground, uppercase case restriction, popup menu POP_MAIN | referenced | N/A |
| PC_MUTEXT | PropertyClass | Mandatory uppercase editable text item property class - left-justified, white background, Arial 9pt, red prompt foreground, uppercase, popup menu POP_MAIN; includes embedded WHEN-VALIDATE-ITEM trigger that checks for null value | referenced | N/A |
| PC_NUM | PropertyClass | Numeric text item property class - right-justified, white background, Arial 9pt, number data type, lowest allowed value 0, uppercase | referenced | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric text item property class - right-justified, white background, Arial 9pt, number data type, red prompt foreground; includes embedded WHEN-VALIDATE-ITEM trigger that checks for zero or null value | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class - white background, iconic, no bevel, no mouse-navigate, width 20, height 16 | referenced | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class - scrollbar width 13 | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_VARIANT | Query | LV_VARIANT | VAR_CD | VAR_DESC | No | Lists vehicle variants available for the selected model; allows the user to filter the report by variant | LV_VARIANT -> CB_BLK.P_VARIANT_DESC |
| RG_MODEL | Query | LV_MODEL | MOD_CD | MOD_DESC | No | Lists vehicle models for the current principal; allows the user to filter the report by model | LV_MODEL -> CB_BLK.P_MODEL_DESC |
| RG_TVOUTLET | Query | LV_TVOUTLET | OUTLET_CD | TV_OUTLET_DESC | Yes - PARAMETER | Lists third-party TV outlets for the selected dealer and for-code; allows the user to scope the report to a specific outlet | LV_TVOUTLET -> CB_BLK.P_TV_OUTLET_DESC |
| RG_DEALER | Query | LV_DEALER | DLR_CD | PARENT_GROUP | No | Lists dealers accessible to the logged-in user; allows the user to select the dealer for report scoping | LV_DEALER -> CB_BLK.P_DELR_CD |
| RG_LOC | Query | LV_LOC | LOC_CD | LOC_DESC | Yes - CB_BLK | Lists outlet locations for the selected dealer and parent group; allows the user to select the specific outlet location for the report | LV_LOC -> CB_BLK.P_LOC_CD |

**Total Record Groups:** 5

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_LIST` | - | L_POPULATE | Application list master - lookup table storing configurable code/description pairs for list items by list name and principal |
| `AM_USER_DEALER_MASTER` | MULDMS | RG_DEALER | User-dealer access master - maps logged-in users to their authorised dealers, parent groups, and location codes |
| `DUAL` | - | RG_MODEL, RG_TVOUTLET, RG_VARIANT | Oracle system dual table - used to inject an "ALL" option row at the top of LOV queries |
| `GM_MOD` | - | RG_MODEL | Vehicle model master - stores model codes and descriptions scoped by principal |
| `GM_VAR` | - | RG_VARIANT | Vehicle variant master - stores variant codes and descriptions linked to model codes and principal |
| `MULDMS.AM_DEALER_LOC` | - | RG_LOC | Dealer location master - stores outlet location codes, descriptions, and dealer map codes for dealer branches |
| `MULDMS.AM_USER_DEALER_MASTER` | - | RG_DEALER | User-dealer access master (MULDMS schema reference) - used in dealer LOV query to resolve accessible dealers for the current user |
| `SM_DMSPOC_TV_OUTLET` | - | RG_TVOUTLET | TV outlet master - stores third-party outlet codes and descriptions for the point-of-contact exchange programme, filtered by dealer and for-code |

**Total Referenced Objects:** 8

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name in the database session context at form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module name and action in the database session context at form open |
| BR-001 | STOP_WATCH.START_TIMER | Starts the application performance timer when the environment has logging enabled |
| BR-008 | VIEW_EXCEL_REP | Executes the report data query, writes the CSV output file, and serves it to the user's browser |
| BR-008 | PKG_ENQ_POC_DETAIL.SF_OLD_MODEL_DESC | Retrieves the old vehicle model description for display in the report output |
| BR-008 | PKG_POC_DMS.FNC_EVAL_EVALUATOR_MSPIN | Retrieves the evaluator's MSPIN for the linked enquiry |
| BR-008 | PKG_POC_DMS.FNC_EVAL_EVALUATOR_NAME | Retrieves the evaluator's name for the linked enquiry |
| BR-008 | SF_BONUS_CLAIM_STATUS | Returns the claim submission status for the bonus associated with a given invoice |
| BR-008 | SF_GET_TOTAL_BONUS | Calculates the total bonus amount for a given bonus type, invoice, model, and other parameters |
| BR-008 | SF_GET_EXCH_SLAB | Returns the exchange slab identifier for the old vehicle's age |
| BR-008 | SF_GET_VIN_YOM | Returns the year of manufacture for a given VIN |
| BR-008 | SF_GET_EMP_NAME | Returns the employee name for a given dealer, outlet, and employee code |
| BR-008 | WEBUTIL_C_API.ID_NULL | Tests whether a record group handle is null before creating a fresh record group in VIEW_EXCEL_REP and L_POPULATE |
| BR-009 | GENERAL.DISP_TEXT | Displays formatted error and informational messages to the user |
| BR-009 | GENERAL.RAISE_ERROR | Looks up and raises a registered business error message by error code |
| BR-009 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog and returns the user's response before discarding changes or deleting a record |
| BR-010 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client info from the database session context at form exit |
| BR-010 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module and action names from the database session context at form exit |
| BR-011 | SF_COPYRIGHT_DECLARATION | Retrieves the current copyright declaration text for display on the form |
| BR-012 | GENERAL.DISP_TEXT | Displays formatted messages via the ON-MESSAGE channel |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central dispatch routine for all WebUtil bean events fired from WEBUTIL object group canvas items |
| - | WEBUTIL.FOPEN | Opens a server-side file for writing during CSV generation in VIEW_EXCEL_REP |
| - | WEBUTIL.PUT_LINE | Writes a single line of CSV content to the open output file |
| - | WEBUTIL.FCLOSE | Closes the server-side output file after all CSV lines have been written |
| - | WEBUTIL.GET_LINE | Reads a line from a server-side file during the ASCII-character filtering pass in PR_REMOVE_ASCII_CHR |
| - | WEBUTIL.IS_OPEN | Tests whether a file handle is currently open before attempting read or write operations |
| - | WEBUTIL.GETLASTERROR | Retrieves the last error code recorded by the WebUtil framework |
| - | WEBUTIL.GETLASTERRORARGS | Retrieves the arguments associated with the last WebUtil error |
| - | WEBUTIL.ISERROR | Tests whether the WebUtil framework recorded an error after the most recent operation |
| - | WEBUTIL.LOG | Writes a diagnostic message to the WebUtil client-side log |
| - | WEBUTIL.INIT | Initialises the WebUtil framework at form startup |
| - | WEBUTIL.INITWEBUTIL | Performs extended WebUtil initialisation and bean registration at form startup |
| - | WEBUTIL.REGISTERBEAN | Registers a WebUtil Java bean with the Forms runtime |
| - | WEBUTIL.REGISTER_FUNCTION | Registers a named WebUtil function for later dispatch |
| - | WEBUTIL.EXECUTE | Executes a registered WebUtil function call |
| - | WEBUTIL.GETCALLBACKTRIGGER | Returns the name of the callback trigger currently being processed by the WebUtil dispatcher |
| - | WEBUTIL.CLEARCALLBACKTRIGGER | Clears the stored callback trigger name after processing |
| - | WEBUTIL.GETSTRING | Retrieves a string result value from the most recent WebUtil function execution |
| - | WEBUTIL.GETNUMBER | Retrieves a numeric result value from the most recent WebUtil function execution |
| - | WEBUTIL.GETVAR | Retrieves a named variable value from the WebUtil session context |
| - | WEBUTIL.SETPROPERTY | Sets a named property on a WebUtil bean |
| - | WEBUTIL.GETPROPERTY | Gets a named property from a WebUtil bean |
| - | WEBUTIL.GETCLIENTOSFAMILY | Returns the operating system family string for the connected client |
| - | WEBUTIL.GETOSFAMILY | Returns the server-side operating system family string |
| - | WEBUTIL.GETCLIENTSETTING | Retrieves a named client-environment setting |
| - | WEBUTIL.SETCLIENTSETTING | Sets a named client-environment setting |
| - | WEBUTIL.GETIMPLCLASS | Returns the implementation class name for a registered WebUtil bean |
| - | WEBUTIL.BLOCKING | Sets or clears the blocking state of the WebUtil framework |
| - | WEBUTIL.CHECKLIBS | Verifies that required WebUtil native libraries are loaded on the client |
| - | WEBUTIL.SHOWBEANS | Displays diagnostic information about registered WebUtil beans |
| - | WEBUTIL.ERROR | Records an error condition within the WebUtil framework |
| - | WEBUTIL.ERRORALERT | Displays a WebUtil error as an alert dialog |
| - | WEBUTIL.SETDATA | Writes a data value into the WebUtil session context |
| - | WEBUTIL.WRITEDATA | Writes binary or character data through a WebUtil channel |
| - | WEBUTIL.DOWNLOADFROMURLINT | Downloads content from a URL to the client using the internal WebUtil transfer mechanism |
| - | WEBUTIL.CLOSEBLOB | Closes an open BLOB handle used during a WebUtil file transfer |
| - | WEBUTIL.CLOSEFILE | Closes a WebUtil-managed file handle |
| - | WEBUTIL.RELEASE_PROCESS | Releases a server-side process handle after a host command completes |
| - | WEBUTIL.GETOUTPUT | Retrieves buffered output from a completed host command process |
| - | WEBUTIL.GET_STANDARD_OUTPUT | Retrieves standard output from a completed host command process |
| - | WEBUTIL.LENGTH | Returns the byte length of a WebUtil data buffer |
| - | WEBUTIL.POPULATEPROPERTYBUNDLE | Populates a property bundle object with name-value pairs for a WebUtil call |
| - | WEBUTIL.READFROMPROPERTYBUNDLE | Reads a named value from a WebUtil property bundle |
| - | WEBUTIL.READTRANSFROMMSGBUNDLE | Reads a transfer descriptor from a WebUtil message bundle |
| - | D2KWUTIL.ATTEMPT_DLL_LOAD | Attempts to load a named native DLL into the Forms client process |
| - | D2KWUTIL.D2KWUTIL_DEBUGSTRING | Returns a debug string from the D2KWUTIL native library for diagnostic purposes |
| - | D2KWUTIL.D2KWUTIL_GETDOSENV | Retrieves a DOS/Windows environment variable value via the D2KWUTIL native library |
| - | D2KWUTIL.D2KWUTIL_GETREGKEY | Reads a Windows registry key value via the D2KWUTIL native library |
| - | D2KWUTIL.TRANSLATETYPE | Translates an internal D2KWUTIL type code to a human-readable string |
| - | ADD_ERROR | Adds an error entry to the WebUtil internal error stack |
| - | ADD_EXTERNAL_ERRORS | Adds externally supplied error entries to the WebUtil error stack |
| - | BOOLTOCHAR | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character equivalent |
| - | CLEAN_ERROR_STACK | Clears all entries from the WebUtil internal error stack |
| - | DEBUGLOG | Writes a debug message to the WebUtil diagnostic log |
| - | GET_ENVIRONMENT_STRING | Retrieves a named environment variable string from the current session |
| - | READ_REGISTRY | Reads a Windows registry value via the WebUtil registry access mechanism |
| - | REGISTER_FUNCTION_CALL | Registers a pending function call in the WebUtil dispatch queue |
| - | SETDEBUG | Enables or disables WebUtil debug logging |
| - | STRIPDIRSEP | Strips trailing directory separator characters from a file path string |
| - | WINDEBUG | Writes a debug message to the Windows debug output channel |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package routine (GENERAL) | ON-ERROR trigger; ON-MESSAGE trigger; FT_INSERT trigger; WHEN-VALIDATE-ITEM on CB_BLK.P_DELR_CD, CB_BLK.P_LOC_CD, CB_BLK.P_EXCH_STS, CB_BLK.P_FROMDT, CB_BLK.P_TODT; PR_REMOVE_ASCII_CHR program unit | Displays an alert dialog to the user. Sets AL_ERRINFO (when title is 'Error') or AL_NOTE (for informational messages) with the supplied text and title, then calls SHOW_ALERT. Used for field-level validation errors, system error messages, and exception reporting. |
| GENERAL.RAISE_ERROR | Package routine (GENERAL) | ON-ERROR trigger | Looks up a registered application error message by its code, formats it with the code prefix, and displays it via GENERAL.DISP_TEXT. Raises FORM_TRIGGER_FAILURE when the message type is Error ('E'); displays a note or caution dialog for non-critical types ('N', 'C'). |
| GENERAL.ASK_CONFIRM | Package routine (GENERAL) | FT_CANCEL trigger; FT_DEL trigger; WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Displays a confirmation dialog containing the supplied message and returns the user's response as a number. Used to prompt the user before discarding changes or deleting a record. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Package routine (DBMS_APPLICATION_INFO) | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the client info string in the current database session for monitoring and tracing purposes. |
| DBMS_APPLICATION_INFO.SET_MODULE | Package routine (DBMS_APPLICATION_INFO) | PRE-FORM trigger; KEY-EXIT trigger | Sets or clears the module name and action name in the current database session for monitoring and tracing purposes. |
| STOP_WATCH.START_TIMER | Package routine (STOP_WATCH) | PRE-FORM trigger (conditional on application logging flag) | Starts the application-level performance timer. |
| VIEW_EXCEL_REP | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Executes the report data query, writes the result to a CSV file on the application server, and serves it to the user's browser. Uses WEBUTIL_C_API.ID_NULL to test and manage the record group handle before creating a fresh record group. |
| L_POPULATE | Form program unit (PROCEDURE) | PRE-FORM trigger; internal calls for list initialisation | Queries AM_LIST for a named list and principal, then populates the target drop-down field with the retrieved code-description pairs. Calls WEBUTIL_C_API.ID_NULL to manage the record group handle and GENERAL.L_POPULATE as a helper. |
| PR_REMOVE_ASCII_CHR | Form program unit (PROCEDURE) | Internal - not called from any active trigger in this form's active code | Reads a CSV file line by line using WEBUTIL.GET_LINE and WEBUTIL.IS_OPEN, filters out characters with ASCII code 12, and writes the cleaned content to a new output file via WEBUTIL.PUT_LINE. Reports errors via GENERAL.DISP_TEXT. |
| PKG_ENQ_POC_DETAIL.SF_OLD_MODEL_DESC | Package function (PKG_ENQ_POC_DETAIL) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query for all three exchange status branches) | Returns the old vehicle model description for a given principal, make flag, and model code. |
| PKG_POC_DMS.FNC_EVAL_EVALUATOR_MSPIN | Package function (PKG_POC_DMS) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query for all three exchange status branches) | Returns the evaluator's MSPIN for a given enquiry. |
| PKG_POC_DMS.FNC_EVAL_EVALUATOR_NAME | Package function (PKG_POC_DMS) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query for all three exchange status branches) | Returns the evaluator's name for a given enquiry. |
| SF_BONUS_CLAIM_STATUS | Standalone function | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query) | Returns the bonus claim submission status for a given invoice. |
| SF_GET_TOTAL_BONUS | Standalone function | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query - called multiple times for bonus type codes: BT, BM, AM, AT, ST, SM) | Calculates the total bonus amount for a given bonus type, invoice date, region, variant, fuel type, principal, and other parameters. |
| SF_GET_EXCH_SLAB | Standalone function | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query - used as a parameter to SF_GET_TOTAL_BONUS) | Returns the exchange slab code based on the age of the old vehicle. |
| SF_GET_VIN_YOM | Standalone function | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query - used as a parameter to SF_GET_TOTAL_BONUS for stock liquidation bonus types) | Returns the year of manufacture for a given VIN. |
| SF_GET_EMP_NAME | Standalone function | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic query for all three exchange status branches) | Returns the employee (salesperson) name for a given dealer, outlet, and employee code. |
| SF_COPYRIGHT_DECLARATION | Standalone function | KEY-CLRFRM trigger | Returns the current copyright declaration text for display on the form. |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | PLD routine (WEBUTIL_CORE) | WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine for WebUtil bean events. Receives the event name and its serialised parameter string and routes the event to the appropriate WebUtil package procedure for processing client-side responses. |
| WEBUTIL_C_API.ID_NULL | PLD function (WEBUTIL_C_API) | L_POPULATE program unit; VIEW_EXCEL_REP program unit | Checks whether a Forms handle (RecordGroup or similar object reference) is null. Returns TRUE when the handle is uninitialised. Used to determine whether an existing record group must be deleted before creating a fresh one. |
| WEBUTIL.FOPEN | PLD routine (WEBUTIL) | VIEW_EXCEL_REP program unit; PR_REMOVE_ASCII_CHR program unit | Opens a server-side file for reading or writing. Returns a file handle used by subsequent PUT_LINE, GET_LINE, and FCLOSE calls. |
| WEBUTIL.PUT_LINE | PLD routine (WEBUTIL) | VIEW_EXCEL_REP program unit; PR_REMOVE_ASCII_CHR program unit | Writes a single line of text to an open server-side file handle during CSV generation or ASCII-character filtering. |
| WEBUTIL.FCLOSE | PLD routine (WEBUTIL) | VIEW_EXCEL_REP program unit; PR_REMOVE_ASCII_CHR program unit | Closes an open server-side file handle after all read or write operations are complete. |
| WEBUTIL.GET_LINE | PLD routine (WEBUTIL) | PR_REMOVE_ASCII_CHR program unit | Reads the next line of text from an open server-side file handle during the ASCII-character filtering pass. |
| WEBUTIL.IS_OPEN | PLD routine (WEBUTIL) | PR_REMOVE_ASCII_CHR program unit | Tests whether a file handle is currently open before attempting read operations. |
| WEBUTIL.GETLASTERROR | PLD routine (WEBUTIL) | VIEW_EXCEL_REP program unit; WebUtil internal error handling | Retrieves the last error code recorded by the WebUtil framework after a file or transfer operation. |
| WEBUTIL.GETLASTERRORARGS | PLD routine (WEBUTIL) | WebUtil internal error handling | Retrieves the arguments associated with the last WebUtil error for diagnostic display. |
| WEBUTIL.ISERROR | PLD routine (WEBUTIL) | VIEW_EXCEL_REP program unit; WebUtil internal error handling | Tests whether the WebUtil framework recorded an error after the most recent operation. |
| WEBUTIL.LOG | PLD routine (WEBUTIL) | WebUtil internal routines | Writes a diagnostic message to the WebUtil client-side log. |
| WEBUTIL.INIT | PLD routine (WEBUTIL) | WHEN-NEW-FORM-INSTANCE trigger (WebUtil initialisation sequence) | Initialises the WebUtil framework at form startup. |
| WEBUTIL.INITWEBUTIL | PLD routine (WEBUTIL) | WHEN-NEW-FORM-INSTANCE trigger (WebUtil initialisation sequence) | Performs extended WebUtil initialisation including bean registration and library verification at form startup. |
| WEBUTIL.REGISTERBEAN | PLD routine (WEBUTIL) | WEBUTIL.INITWEBUTIL | Registers a WebUtil Java bean with the Oracle Forms runtime so that it can receive and dispatch custom item events. |
| WEBUTIL.REGISTER_FUNCTION | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Registers a named WebUtil function for later execution via WEBUTIL.EXECUTE. |
| WEBUTIL.EXECUTE | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Executes a previously registered WebUtil function call and stores the result for retrieval via GETSTRING or GETNUMBER. |
| WEBUTIL.GETCALLBACKTRIGGER | PLD routine (WEBUTIL) | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Returns the name of the callback trigger currently being processed by the WebUtil event dispatcher. |
| WEBUTIL.CLEARCALLBACKTRIGGER | PLD routine (WEBUTIL) | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Clears the stored callback trigger name after the WebUtil event has been fully processed. |
| WEBUTIL.GETSTRING | PLD routine (WEBUTIL) | WEBUTIL internal dispatch; VIEW_EXCEL_REP program unit | Retrieves a string result value from the most recent WebUtil function execution. |
| WEBUTIL.GETNUMBER | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Retrieves a numeric result value from the most recent WebUtil function execution. |
| WEBUTIL.GETVAR | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Retrieves a named variable value from the WebUtil session context. |
| WEBUTIL.SETPROPERTY | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Sets a named property on a registered WebUtil bean. |
| WEBUTIL.GETPROPERTY | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Gets a named property value from a registered WebUtil bean. |
| WEBUTIL.GETCLIENTOSFAMILY | PLD routine (WEBUTIL) | WEBUTIL.INITWEBUTIL; WebUtil environment detection | Returns the operating system family string for the connected client machine. |
| WEBUTIL.GETOSFAMILY | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Returns the server-side operating system family string. |
| WEBUTIL.GETCLIENTSETTING | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Retrieves a named client-environment setting from the WebUtil session. |
| WEBUTIL.SETCLIENTSETTING | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Sets a named client-environment setting within the WebUtil session. |
| WEBUTIL.GETIMPLCLASS | PLD routine (WEBUTIL) | WEBUTIL.REGISTERBEAN | Returns the implementation class name for a registered WebUtil bean. |
| WEBUTIL.BLOCKING | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Sets or clears the blocking state of the WebUtil framework during asynchronous operations. |
| WEBUTIL.CHECKLIBS | PLD routine (WEBUTIL) | WEBUTIL.INITWEBUTIL | Verifies that required WebUtil native libraries are loaded and accessible on the client. |
| WEBUTIL.SHOWBEANS | PLD routine (WEBUTIL) | Diagnostic / developer use | Displays diagnostic information about all registered WebUtil beans in the current session. |
| WEBUTIL.ERROR | PLD routine (WEBUTIL) | WEBUTIL internal error handling | Records an error condition within the WebUtil framework error stack. |
| WEBUTIL.ERRORALERT | PLD routine (WEBUTIL) | WEBUTIL internal error handling | Displays a WebUtil error condition as a Forms alert dialog. |
| WEBUTIL.SETDATA | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Writes a data value into the WebUtil session context for use by subsequent operations. |
| WEBUTIL.WRITEDATA | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Writes binary or character data through a WebUtil transfer channel. |
| WEBUTIL.DOWNLOADFROMURLINT | PLD routine (WEBUTIL) | WEBUTIL internal file transfer | Downloads content from a URL to the client machine using the internal WebUtil transfer mechanism. |
| WEBUTIL.CLOSEBLOB | PLD routine (WEBUTIL) | WEBUTIL internal file transfer | Closes an open BLOB handle used during a WebUtil file transfer operation. |
| WEBUTIL.CLOSEFILE | PLD routine (WEBUTIL) | WEBUTIL internal file transfer | Closes a WebUtil-managed file handle after a transfer operation is complete. |
| WEBUTIL.RELEASE_PROCESS | PLD routine (WEBUTIL) | WEBUTIL internal host command handling | Releases a server-side process handle after a host command has completed execution. |
| WEBUTIL.GETOUTPUT | PLD routine (WEBUTIL) | WEBUTIL internal host command handling | Retrieves buffered output from a completed host command process. |
| WEBUTIL.GET_STANDARD_OUTPUT | PLD routine (WEBUTIL) | WEBUTIL internal host command handling | Retrieves standard output text from a completed host command process. |
| WEBUTIL.LENGTH | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Returns the byte length of a WebUtil data buffer. |
| WEBUTIL.POPULATEPROPERTYBUNDLE | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Populates a property bundle object with name-value pairs in preparation for a WebUtil function call. |
| WEBUTIL.READFROMPROPERTYBUNDLE | PLD routine (WEBUTIL) | WEBUTIL internal dispatch | Reads a named value from a WebUtil property bundle after a function call completes. |
| WEBUTIL.READTRANSFROMMSGBUNDLE | PLD routine (WEBUTIL) | WEBUTIL internal file transfer | Reads a transfer descriptor from a WebUtil message bundle to drive a file transfer operation. |
| D2KWUTIL.ATTEMPT_DLL_LOAD | PLD routine (D2KWUTIL) | WEBUTIL.CHECKLIBS | Attempts to load a named native DLL into the Oracle Forms client process; used to verify WebUtil library availability. |
| D2KWUTIL.D2KWUTIL_DEBUGSTRING | PLD routine (D2KWUTIL) | WEBUTIL diagnostic routines | Returns a debug string from the D2KWUTIL native library for diagnostic and tracing purposes. |
| D2KWUTIL.D2KWUTIL_GETDOSENV | PLD routine (D2KWUTIL) | GET_ENVIRONMENT_STRING | Retrieves a DOS/Windows environment variable value via the D2KWUTIL native library. |
| D2KWUTIL.D2KWUTIL_GETREGKEY | PLD routine (D2KWUTIL) | READ_REGISTRY | Reads a Windows registry key value via the D2KWUTIL native library. |
| D2KWUTIL.TRANSLATETYPE | PLD routine (D2KWUTIL) | WEBUTIL diagnostic routines | Translates an internal D2KWUTIL type code to a human-readable string for diagnostic output. |
| ADD_ERROR | PLD standalone routine | WEBUTIL internal error handling | Adds an error entry to the WebUtil internal error stack. |
| ADD_EXTERNAL_ERRORS | PLD standalone routine | WEBUTIL internal error handling | Adds externally supplied error entries to the WebUtil error stack for consolidated error reporting. |
| BOOLTOCHAR | PLD standalone routine | WEBUTIL internal dispatch | Converts a PL/SQL BOOLEAN value to its VARCHAR2 character equivalent ('TRUE' / 'FALSE'). |
| CLEAN_ERROR_STACK | PLD standalone routine | WEBUTIL internal error handling | Clears all entries from the WebUtil internal error stack. |
| DEBUGLOG | PLD standalone routine | WEBUTIL diagnostic routines | Writes a debug message to the WebUtil diagnostic log when debug mode is active. |
| GET_ENVIRONMENT_STRING | PLD standalone routine | WEBUTIL.GETCLIENTSETTING; WEBUTIL.INITWEBUTIL | Retrieves a named environment variable string from the current Forms session using D2KWUTIL.D2KWUTIL_GETDOSENV. |
| READ_REGISTRY | PLD standalone routine | WEBUTIL.INITWEBUTIL; WEBUTIL.GETCLIENTSETTING | Reads a Windows registry value via the WebUtil registry access mechanism using D2KWUTIL.D2KWUTIL_GETREGKEY. |
| REGISTER_FUNCTION_CALL | PLD standalone routine | WEBUTIL internal dispatch | Registers a pending function call in the WebUtil dispatch queue for deferred execution. |
| SETDEBUG | PLD standalone routine | WEBUTIL.INITWEBUTIL | Enables or disables WebUtil debug logging for the current session. |
| STRIPDIRSEP | PLD standalone routine | VIEW_EXCEL_REP program unit; WEBUTIL file path handling | Strips trailing directory separator characters from a file path string to produce a clean base path. |
| WINDEBUG | PLD standalone routine | WEBUTIL diagnostic routines | Writes a debug message to the Windows debug output channel when running on a Windows client. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No packages from the available PCK files are referenced in ``sr_exch_tradein_fmb.xml``. The form XML does not invoke any routine from the uploaded package sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No package routines from the available PCK files are referenced in `sr_exch_tradein_fmb.xml`.*

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog containing the supplied message and returns the user's response as a number. Called from FT_CANCEL and FT_DEL to prompt the user before discarding changes or deleting a record, and from the WEBUTIL.DUMMY button trigger to confirm a pending action. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DELR_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_EXCH_STS, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | Displays an alert dialog to the user. Sets either AL_ERRINFO (when title is 'Error') or AL_NOTE (for informational messages) with the supplied text and title, then calls SHOW_ALERT. Used throughout the form for field-level validation errors, system error messages, and exception reporting. |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a list item by name using the specified field mapping. Called recursively or as a helper from within the L_POPULATE program unit to load list-of-values data into a named list item on the form canvas. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by its code, formats it with the code prefix, and displays it via GENERAL.DISP_TEXT. Raises FORM_TRIGGER_FAILURE when the message type is Error ('E'), or displays a note/caution dialog for non-critical message types ('N', 'C'). Called from ON-ERROR when an ORA-02292 integrity constraint violation is detected. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``sr_exch_tradein_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Previously called from the commented-out VALIDATE_CN_MAIN procedure to validate that required test-drive fields (plate number, model year, dates, odometer readings, location, and salesman) were not null before proceeding. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine for WebUtil bean events. Each WEBUTIL object group canvas item fires WHEN-CUSTOM-ITEM-EVENT and delegates immediately to this handler, passing the event name and its serialised parameter string. The handler routes the event to the appropriate WebUtil package procedure for processing client-side responses (file transfer completions, host command results, OLE responses, session information, etc.). |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: L_POPULATE, ProgramUnit: VIEW_EXCEL_REP | Checks whether a Forms handle (RecordGroup or similar object reference) is null. Returns TRUE when the handle is uninitialized. Used in L_POPULATE and VIEW_EXCEL_REP to test whether an existing record group must be deleted before creating a fresh one. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``sr_exch_tradein_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Previously called from within the VIEW_EXCEL_REP program unit to present a client-side Save As dialog, allowing the user to choose a directory, filename, file filter, and dialog title for saving the generated Excel report. The return value would have supplied the resolved file path for the subsequent file-transfer operation. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Exchange Trade-In Report Service | VIEW_EXCEL_REP / MULDMS.SH_INVOICE, MULDMS.SH_TV_EVAL, MULDMS.SH_ORDBOOK, MULDMS.AM_DEALER_LOC, MULDMS.GM_VAR, MULDMS.GM_MOD, MULDMS.GM_EMP | dealerMapCode, locationCode, parentGroup, fromDate, toDate, exchangeStatus, buyingCategory (optional), regNum (optional), modelCode (optional), variantCode (optional), tvOutlet (optional), invoiceType (optional), principal | CSV file stream containing invoice, vehicle, evaluator, bonus, Vahan, and claim detail rows for matching transactions | Generates and delivers the Exchange Trade-In report CSV for the selected dealer, outlet, date range, exchange status, and optional filters | POST /api/reports/exchange-tradein/generate |
| MS-002 | Old Vehicle Model Description Service | PKG_ENQ_POC_DETAIL.SF_OLD_MODEL_DESC | principal, makeFlag, modelCode | Old vehicle model description string | Returns the description of an old vehicle's model for display in the Exchange Trade-In report output | GET /api/vehicles/old-model-description?principal={p}&makeFlag={m}&modelCode={c} |
| MS-003 | Evaluator Identity Service | PKG_POC_DMS.FNC_EVAL_EVALUATOR_MSPIN, PKG_POC_DMS.FNC_EVAL_EVALUATOR_NAME | parentGroup, dealerMapCode, locationCode, compFa, enquiryNumber | Evaluator MSPIN and evaluator name | Returns the identity (MSPIN and name) of the evaluator who assessed an old vehicle for a given enquiry | GET /api/evaluators/identity?parentGroup={pg}&dealerMapCode={d}&locationCode={l}&compFa={c}&enquiryNum={e} |
| MS-004 | Exchange Bonus Calculation Service | SF_GET_TOTAL_BONUS, SF_GET_EXCH_SLAB, SF_GET_VIN_YOM | bonusType, programType, invoiceDate, regionCode, stateCode, forCode, modelCode, variantCode, fuelTypeCode, make (conditional), oldModelCode (conditional), oldSubModel (conditional), principal, vin (conditional), channel, salesType | Total bonus amount for the specified bonus type | Calculates the applicable exchange bonus amount for a given invoice, model, and bonus type category (main bonus, MSIL share, additional bonus, stock liquidation bonus) | POST /api/bonuses/exchange/calculate |
| MS-005 | Exchange Slab Lookup Service | SF_GET_EXCH_SLAB | oldCarAge | Exchange slab code | Returns the exchange slab identifier for the age of the old vehicle | GET /api/exchange/slab?oldCarAge={age} |
| MS-006 | VIN Year-of-Manufacture Lookup Service | SF_GET_VIN_YOM | vin | Year of manufacture | Returns the year of manufacture for a given vehicle VIN, used as an input to the stock liquidation bonus calculation | GET /api/vehicles/yom?vin={vin} |
| MS-007 | Bonus Claim Status Service | SF_BONUS_CLAIM_STATUS | parentGroup, dealerMapCode, locationCode, compFa, invoiceNumber | Bonus claim submission status string | Returns the claim submission status for the exchange bonus associated with a given dealer invoice | GET /api/bonuses/claim-status?parentGroup={pg}&dealerMapCode={d}&locationCode={l}&compFa={c}&invoiceNum={n} |
| MS-008 | Employee Name Lookup Service | SF_GET_EMP_NAME | dealerMapCode, locationCode, employeeCode | Employee full name | Returns the name of a dealer employee (salesperson) for a given employee code and outlet | GET /api/employees/name?dealerMapCode={d}&locationCode={l}&employeeCode={e} |
| MS-009 | Drop-Down List Population Service | AM_LIST | listName, principalMapCode | Array of code-description pairs | Provides the valid options for a named drop-down list for the current principal; replaces the form's runtime master-configuration lookup | GET /api/lists/{listName}?principal={p} |
| MS-010 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION | (none) | Copyright declaration text string | Returns the current copyright declaration text for display on application screens | GET /api/system/copyright-declaration |

**Total Microservices Identified: 10**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Initialisation | PRE-FORM trigger fires when the form is opened | 1. Register form module identity in database session context. 2. If application performance logging is enabled, start the performance timer. | Is application performance logging active? If yes, start timer; if no, skip. | Form is open and ready for user input; session context is registered |
| WF-002 | Report Filter Entry and Validation | User enters filter criteria and moves between fields | 1. User selects Dealer Details from the lookup. 2. Dealer Details is validated as non-empty. 3. User selects Outlet Details from the lookup. 4. Outlet Details is validated as non-empty. 5. User enters Invoice From Date. 6. From Date is validated (not blank, not future, not after To Date) and default To Date is calculated. 7. User enters or confirms To Date. 8. To Date is validated (not blank, requires From Date first, not earlier than From Date, not future, range ≤ 3 months). 9. User selects Exchange Status. 10. Exchange Status is validated as non-empty. 11. User optionally fills in any of: buying category, old vehicle reg number, new vehicle model/variant, TV outlet, invoice type. | Is each mandatory field blank? Is From Date in the future? Is date range > 3 months? Is To Date before From Date? | All mandatory filter fields are filled and validated; optional filters are set as needed; form is ready for report submission |
| WF-003 | Exchange Trade-In Report Generation and Delivery | User presses the Submit Report button (WHEN-BUTTON-PRESSED on SUBMIT) | 1. Generate a unique CSV output filename from the current user identity and timestamp. 2. Check if the file path contains spaces; if so, redirect to C:\ root and inform the user. 3. Based on the Exchange Status selected, assemble the appropriate data query (Bought/Invoiced, Evaluation-in-progress, or Cancelled branch). 4. Execute the data query and populate the working data set. 5. Write each result row to the CSV file on the application server. 6. Close the output file. 7. Open the completed CSV in the user's browser. | Which Exchange Status is selected? (B = Bought/Invoiced query; E = Evaluation-in-progress query; C = Cancelled query.) Does the file path contain spaces? Did any unexpected error occur during file creation or writing? | CSV report file is served to the user's browser for download; or an error message is shown if file generation fails |
| WF-004 | Form Error Interception and User Notification | ON-ERROR trigger fires when any form error is raised | 1. Check error code: if 50004 (invalid date), display *"Entered Date is not valid Date"*. 2. If 50025/50026 (date format), display *"Enter the Date in the proper format (DD-MM-YYYY)"*. 3. If 40209/50016 (non-numeric input), display *"Characters/Special Characters are not allowed here, enter the numeric value"*. 4. If 40207 (Forms field error), display the form's own error text. 5. If database error code -02292 (referential integrity), raise registered business error E0088. 6. If error codes 40654-40659 (stale record), roll back and display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*. 7. If SQLCODE ≠ 0 (other database error), roll back and display the database error text. 8. If error code 40401 or 40405, take no action. | Which error code was raised? Is SQLCODE non-zero? | User is informed of the error with an appropriate plain-language message; current operation is stopped (except 40401/40405 which are silently suppressed) |
| WF-005 | Form Reset and Copyright Refresh | KEY-CLRFRM trigger fires when the user presses the clear-form key | 1. Clear all form fields without saving. 2. Set the report description field to 'Exchange TradeIn Report'. 3. Retrieve and display the current copyright declaration text. | None | Form is reset to its initial state with all fields empty; report name and copyright are refreshed |
| WF-006 | Form Exit with Session Cleanup | KEY-EXIT trigger fires when the user presses the exit key | 1. Clear the module name and action from the database session context. 2. Close the form without saving. | None | Form is closed; database session context is cleared |

**Total Workflows Identified: 6**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: L_POPULATE, ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is checked, then returns whether the group exists so that stale groups can be deleted before re-creation |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-002 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field value is null, then form trigger failure is raised and an error message is displayed |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DELR_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_EXCH_STS, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT | /api/v1/pld/disp_text | When a message and title are supplied, then an alert dialog is shown to the user using the appropriate alert style |
| PLD-004 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is supplied, then the corresponding message is retrieved and displayed; form trigger failure is raised for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``sr_exch_tradein_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*The following package routines are called from WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT via routines embedded in the dynamically constructed SQL query string. Source files: PKG_ENQ_POC_DETAIL.pck, PKG_POC_DMS.pck.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| -- | --------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_ENQ_POC_DETAIL.SF_OLD_MODEL_DESC | Data retrieval | Trigger WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic SQL query for all exchange-status branches) | GET /api/vehicles/old-model-description | When a principal map code, make indicator, and model code are provided, returns the old vehicle model description by querying GM_MOD (for Maruti/principal=2) or SM_DMSPOC_MAKE_MODEL_MAS (for non-Maruti makes); returns NULL on no-data or error |
| PCK-002 | PKG_POC_DMS.FNC_EVAL_EVALUATOR_MSPIN | Data retrieval | Trigger WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic SQL query for all exchange-status branches) | GET /api/evaluators/mspin | When parent group, dealer map code, location code, franchise code, and enquiry number are provided, returns the evaluator's MSPIN by joining RH_ENQ with GM_EMP on employee code and dealer map code; returns NULL on no-data or error |
| PCK-003 | PKG_POC_DMS.FNC_EVAL_EVALUATOR_NAME | Data retrieval | Trigger WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (embedded in dynamic SQL query for all exchange-status branches) | GET /api/evaluators/name | When parent group, dealer map code, location code, franchise code, and enquiry number are provided, returns the evaluator's full employee name by joining RH_ENQ with GM_EMP on employee code and dealer map code; returns NULL on no-data or error |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| MULDMS.SH_INVOICE - Invoice Header | Database table (SELECT) | Primary driver table for the Exchange Trade-In report; provides invoice number, date, VIN, bill nature, invoice status, sales type, channel, and exchange cancellation details | Form -> read at report submission (WHEN-BUTTON-PRESSED on SUBMIT) via dynamic SQL | Any query failure is caught by the OTHERS exception handler in VIEW_EXCEL_REP and reported to the user as "Error  - " followed by the system error code and text |
| MULDMS.SH_TV_EVAL - Old Vehicle Evaluation | Database table (SELECT) | Provides old vehicle details (registration, model, manufacturer, year of manufacture, buying price, reference price, evaluation date, buying status, emission, Vahan flags) for each invoice | Form -> read at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.SH_ORDBOOK - Sales Order | Database table (SELECT) | Provides customer city code and enquiry reference joined to each invoice for evaluator lookup | Form -> read at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.AM_DEALER_LOC - Dealer Location | Database table (SELECT) | Provides region, city, dealer name, address, and outlet details for each invoice row; also queried for the Dealer Details and Outlet Details LOVs | Form -> read at form open (LOV queries) and at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler; LOV errors handled by ON-ERROR trigger |
| MULDMS.GM_VAR - Vehicle Variant Master | Database table (SELECT) | Provides new vehicle variant code, description, fuel type, and model code for each invoice row; also queried for the Variant LOV | Form -> read at form open (LOV query) and at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.GM_MOD - Vehicle Model Master | Database table (SELECT) | Provides new vehicle model description for each invoice row; also queried for the Model LOV | Form -> read at form open (LOV query) and at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.GM_EMP - Employee Master | Database table (SELECT) | Provides salesperson MSPIN for each invoice row | Form -> read at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| AM_LIST - Master Configuration List | Database table (SELECT) | Provides code-description pairs for runtime-populated drop-down fields (buying category, exchange status, sales type, channel, fuel type, relationship type) | Form -> read at list population (L_POPULATE) and at report submission | Errors in list population handled by ON-ERROR trigger |
| MULDMS.SD_LOYLTY_EXCH_CLAIM - Loyalty Exchange Claim | Database table (SELECT) | Provides loyalty exchange claim submission status (YES/NO) and old car age per third-party assessment for each invoice row | Form -> read at report submission (correlated sub-query) | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| SD_INV_CHARGES - Invoice Charges | Database table (SELECT) | Provides the exchange benefit discount amount given by the dealer (charge type EXB) for each invoice row | Form -> read at report submission (correlated sub-query) | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.NI_NEW_MINS - New Insurance | Database table (SELECT) | Provides the insurance owner name for the new vehicle at the time of invoice | Form -> read at report submission (correlated sub-query on VIN) | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| DMS_VAHAN_CHECK_DTL - Vahan Verification Detail | Database table (SELECT) | Provides Vahan verification details for the new vehicle (owner name, owner father/husband name, creation date) | Form -> read at report submission (correlated sub-query on VIN and buying number) | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| MULDMS.GM_CITY - City Master | Database table (SELECT) | Provides city descriptions for dealer and customer city codes in the report output | Form -> read at report submission (correlated sub-query) | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| SM_DMSPOC_TV_OUTLET - TV Outlet | Database table (SELECT) | Provides TV outlet descriptions for the TV outlet filter in the report; also queried for the TV Outlet LOV | Form -> read at form open (LOV query) and at report submission | Covered by VIEW_EXCEL_REP OTHERS exception handler |
| DBMS_APPLICATION_INFO | Oracle system package | Registers and clears the form module name and action in the database session context for monitoring purposes | Form -> write at PRE-FORM (open) and KEY-EXIT (close) | No explicit error handling evidenced; failures would propagate to the ON-ERROR trigger |

### 20.2 External System Integrations

The form does not invoke any external application systems directly. Its only external dependency is the application server file system (see Section 20.1 Report Output Path Configuration) and the WEBUTIL and D2KWUTIL libraries, which provide browser file-serving capabilities (WEB.SHOW_DOCUMENT is called by VIEW_EXCEL_REP). No calls to external REST services, web services, or third-party systems are evidenced in the form's code.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Application Server File System | File I/O (via TEXT_IO / DPL library) | The VIEW_EXCEL_REP program unit writes the CSV report output file to the application server's configured reports directory | Server-side file write (TEXT_IO.FOPEN / TEXT_IO.PUT_LINE / TEXT_IO.FCLOSE) | /iashome/ias/reports/printer/{filename} (server path) and configured path from /reports/DMS/excelpath.txt | Form -> write: each CSV row is written one line at a time | OTHERS exception in VIEW_EXCEL_REP catches file write failures and displays "Error  - " with error code and text |
| Browser (via WEB.SHOW_DOCUMENT) | Browser document launch (DPL / WEBUTIL) | After the CSV file is written to the server, the completed file is opened in the user's browser for download via a URL constructed from the configured server path | Browser URL open (_blank target) | URL constructed from the path read from /reports/DMS/excelpath.txt | Form -> browser: URL delivered to user's browser for file download | OTHERS exception in VIEW_EXCEL_REP catches failures |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - application report server | INFERRED - dealer, outlet, date range, exchange status, and optional filters consistent with CB_BLK filter items | INFERRED - report output format | N/A - report object declared in form XML (execute mode: Runtime) but not actively invoked from any trigger or program unit in the form's active code |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the SR_EXCH_TRADEIN form.

### 21.1 Catalogue Index

66 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-007](#SP-007--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-008](#SP-008--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-009](#SP-009--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-010](#SP-010--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-011](#SP-011--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-013](#SP-013--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-014](#SP-014--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-016](#SP-016--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-017](#SP-017--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-018](#SP-018--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-019](#SP-019--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-020](#SP-020--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-021](#SP-021--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-022](#SP-022--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-024](#SP-024--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-025](#SP-025--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-026](#SP-026--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-027](#SP-027--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-028](#SP-028--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-029](#SP-029--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-030](#SP-030--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-031](#SP-031--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-032](#SP-032--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-033](#SP-033--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-034](#SP-034--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-035](#SP-035--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-036](#SP-036--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-037](#SP-037--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-038](#SP-038--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-039](#SP-039--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-040](#SP-040--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-041](#SP-041--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-042](#SP-042--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-043](#SP-043--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-045](#SP-045--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-046](#SP-046--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-047](#SP-047--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-048](#SP-048--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-050](#SP-050--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-051](#SP-051--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-052](#SP-052--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-053](#SP-053--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-054](#SP-054--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-055](#SP-055--ADD_ERROR) | ADD_ERROR |
| [SP-056](#SP-056--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-057](#SP-057--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-058](#SP-058--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-059](#SP-059--DEBUGLOG) | DEBUGLOG |
| [SP-060](#SP-060--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-061](#SP-061--READ_REGISTRY) | READ_REGISTRY |
| [SP-062](#SP-062--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-063](#SP-063--SETDEBUG) | SETDEBUG |
| [SP-064](#SP-064--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-065](#SP-065--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-066](#SP-066--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- sr_exch_tradein_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates a CSV export file from a dynamic SQL query and streams it to the end user's browser as a downloadable Excel-compatible report. The procedure builds an in-memory record group from the supplied query, writes the designated column's data row-by-row to a server-side CSV file, and then opens the file in a new browser window via a resolved URL path.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-019](#SP-019--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-020](#SP-020--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-033](#SP-033--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-043](#SP-043--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output file name by concatenating the current Oracle Forms global user ID (`:global.userid`) with the current date/time formatted as `YYYYMMDDHHMISS`, then appending the `.csv` extension.
- Step 2 - Validate the generated file name: if the file name contains spaces in any folder segment, override the path to the `C:\` root drive and display a warning message to the user informing them of the path change.
- Step 3 - Check whether a record group named `DataRecordSet` already exists in the current Forms session using `Find_Group`; if it does, delete it with `Delete_Group` to avoid stale data.
- Step 4 - Create a new record group named `DataRecordSet` from the dynamic SQL string supplied in `p_query` using `Create_Group_From_Query`, then populate it with `Populate_Group`.
- Step 5 - Retrieve the total row count of the populated record group using `Get_Group_Row_Count`.
- Step 6 - Construct the server-side file path by prepending the fixed directory `/iashome/ias/reports/printer/` to the base file name (extracted from `FILENAME` after the last backslash).
- Step 7 - Open the configuration file `/reports/DMS/excelpath.txt` for reading using `TEXT_IO.FOPEN`, read the URL base path with `TEXT_IO.GET_LINE`, and close the file with `TEXT_IO.FCLOSE`.
- Step 8 - Combine the URL base path with the base file name to form the full browser-accessible URL (`formserverpath`).
- Step 9 - Open the server-side CSV file for writing using `TEXT_IO.FOPEN` in write (`W`) mode.
- Step 10 - Locate the target column in the record group using `Find_Column` with the column reference `DataRecordSet.<p_column_name>`.
- Step 11 - Iterate over all rows (1 through `the_rowcount`): for each row, retrieve the cell value from the identified column using `GET_GROUP_CHAR_CELL` and write it as a line to the CSV file using `TEXT_IO.PUT_LINE`.
- Step 12 - Close the CSV file with `TEXT_IO.FCLOSE` after all rows have been written.
- Step 13 - Launch the generated CSV file in a new browser window by calling `WEB.SHOW_DOCUMENT` with the resolved `formserverpath` URL and target `_blank`.
- Step 14 - If any exception occurs during processing, display an error message combining `ERROR_CODE` and `ERROR_TEXT`, then raise `FORM_TRIGGER_FAILURE` to halt the trigger.

---
**Decision Points**

DP-001

Condition:
The generated file name (`vcFile`) is NULL.

TRUE:
No file name is assigned; the procedure takes no action on the file name (null branch - a commented-out file-save dialog is bypassed).

FALSE:
The generated file name is assigned to `FILENAME` for use in subsequent steps.

---

DP-002

Condition:
The `FILENAME` string contains a space character (`INSTR(FILENAME, ' ') > 0`).

TRUE:
The file path is overridden to `C:\` concatenated with the base file name only; a warning message is displayed to the user advising that the file will be saved to the C drive because the original path contained spaces.

FALSE:
The `FILENAME` value is used as-is without path modification.

---

DP-003

Condition:
A record group named `DataRecordSet` already exists in the Forms session (`NOT Id_Null(rg_id)` after `Find_Group`).

TRUE:
The existing record group is deleted with `Delete_Group` before a new one is created.

FALSE:
No deletion is performed; the procedure proceeds directly to create the record group.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output file name must be unique per user session; it is constructed by combining the logged-in user's ID (from `:global.userid`) with a timestamp (`YYYYMMDDHHMISS`) and a `.csv` extension to prevent file name collisions.
- BR-002 - File paths containing spaces are not permitted; if the resolved path contains spaces, the file must be redirected to the `C:\` root directory and the user must be notified.
- BR-003 - Any pre-existing record group named `DataRecordSet` must be destroyed before creating a new one to ensure the export reflects only the current query's data.
- BR-004 - The data query used to populate the export is supplied entirely at runtime via the `p_query` parameter; the procedure imposes no restriction on the query's content.
- BR-005 - Only the single column identified by `p_column_name` is written to the CSV output; multi-column formatting is the responsibility of the calling context, which must pre-compose the column value as a complete delimited string if multiple fields are required.
- BR-006 - The server-side output directory is fixed at `/iashome/ias/reports/printer/`; the browser-accessible URL base path is read at runtime from the configuration file `/reports/DMS/excelpath.txt` and must exist and be readable for the procedure to succeed.
- BR-007 - The generated CSV file is opened directly in a new browser window (`_blank`) using `WEB.SHOW_DOCUMENT`; no intermediate download dialog is presented to the user.
- BR-008 - Any unhandled exception must surface an error message to the user (combining `ERROR_CODE` and `ERROR_TEXT`) and terminate the calling trigger by raising `FORM_TRIGGER_FAILURE`.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	/*IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;*/
 	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into Oracle Forms via ORA_FFI, optionally verifying that the file exists at the supplied directory path before loading. If a path is provided, the procedure validates file presence using TEXT_IO; if the load succeeds and counting is enabled, it increments the package-level DLL load counter and marks the API as enabled. On any failure, it marks the API as disabled and returns a null library handle to the caller (REGISTER_FUNCTION_CALL).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-065](#SP-065--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip file-existence checking and proceed directly to the DLL load attempt.
- Step 2 - Normalise TargetPath by passing it through STRIPDIRSEP to remove any existing trailing directory separator, then appending a single backslash ('\'), ensuring a consistent path format regardless of how the caller supplied the value.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R') to confirm the file physically exists at the specified location.
- Step 4 - If the file is opened successfully, close it immediately with TEXT_IO.FCLOSE; the open/close sequence is used solely for existence verification and has no data-reading purpose.
- Step 5 - If the file cannot be opened (any exception), invoke DEBUGLOG at severity level 99, logging the procedure name 'Attempt_DLL_LOAD' and a message identifying the DLL and the path where it was not found, then raise the BadLocation exception to abort further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 7 - If the LoadCount parameter is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE, recording that a DLL has been successfully loaded.
- Step 8 - Return the populated library handle hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null library handle hDLL, signalling to the caller that the load did not succeed.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP, append a backslash, and perform file-existence verification using TEXT_IO before attempting the DLL load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the file at TargetPath||TargetDLL

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file condition via DEBUGLOG (severity 99) and raise the BadLocation exception, halting further execution of the procedure.

---

DP-003

Condition: LoadCount parameter is TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Skip counter increment and API_ENABLED update; return the library handle without modifying package-level state.

---

DP-004

Condition: An unhandled exception occurs during the ORA_FFI.LOAD_LIBRARY call or surrounding logic

TRUE: Set API_ENABLED to FALSE and return the null library handle hDLL to the caller.

FALSE: Normal execution completes; the populated library handle is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must be normalised to a single trailing backslash before use; STRIPDIRSEP is applied to remove any pre-existing trailing separator, and '\' is then appended, preventing double-separator or missing-separator path errors.
- BR-002 - When TargetPath is supplied, the physical existence of the DLL file must be confirmed via a TEXT_IO read-mode open before any load is attempted; a DLL that cannot be opened at the specified path is treated as an invalid location.
- BR-003 - A failed file-existence check must be logged through DEBUGLOG at severity level 99, capturing the procedure context and the full unresolvable path, before the BadLocation exception is raised.
- BR-004 - The package-level DLL load counter (DLL_LOAD_COUNT) must only be incremented, and API_ENABLED set to TRUE, when the load succeeds and the caller explicitly requests counting via LoadCount = TRUE.
- BR-005 - On any exception during the load phase, API_ENABLED must be set to FALSE and a null library handle returned, ensuring the caller can detect an unsuccessful load without an unhandled exception propagating.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C-language D2KWUTIL library routine. It is invoked by the WINDEBUG stored procedure within D2kwutil.pld to relay diagnostic or debug messages from the Oracle Forms PL/SQL layer to the native windowing utility.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function entry point within the D2KWUTIL external library.
- Step 2 - Receive the debug text string (Text) to be transmitted to the external library.
- Step 3 - Delegate execution to the external C routine d2kwutil_DebugString via the ORA_FFI PRAGMA INTERFACE binding (interface code 11265), passing both the function handle and the text string directly to the native layer.
- Step 4 - Return control to the calling procedure (WINDEBUG) upon completion of the external call; no return value is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a direct foreign-function call with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI.funcHandleType handle; the handle is established and managed by the calling context (WINDEBUG) before this procedure is invoked.
- BR-002 - The procedure operates exclusively as an FFI pass-through; no transformation, validation, or persistence of the Text parameter is performed within this layer.
- BR-003 - The external C interface is bound at compile time via PRAGMA INTERFACE with interface code 11265; the procedure signature must remain compatible with that binding.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

This function serves as a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle to the underlying native library routine, a source string identifying the environment variable to look up, an output buffer to receive the expanded value, and the maximum buffer length. It returns a PLS_INTEGER status code indicating the outcome of the native call. It is invoked indirectly by the parent routine GET_ENVIRONMENT_STRING in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered ORA_FFI function handle (hFunc) that references the native OS library entry point responsible for environment-variable expansion.
- Step 2 - Accept the source string (SourceStr) identifying the name or token of the DOS/OS environment variable to be resolved.
- Step 3 - Accept the output buffer (ExpandStr) that will receive the expanded environment variable value returned by the native call, and accept InBuffLen defining the maximum allowable length of that buffer.
- Step 4 - Delegate execution to the native function referenced by hFunc, passing SourceStr, ExpandStr, and InBuffLen as arguments through the ORA_FFI mechanism.
- Step 5 - Receive the updated ExpandStr (populated with the resolved environment variable value) and the updated SourceStr as IN OUT results from the native call.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) reflecting the success or failure of the native environment-variable retrieval.

---
**Decision Points**

No conditional decision points are determinable from the available specification. The function declaration contains no branching logic; all control flow decisions reside within the native library routine invoked via the ORA_FFI function handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid, pre-registered ORA_FFI function handle (hFunc); the handle must reference the correct native OS library entry point before invocation.
- BR-002 - The InBuffLen parameter must accurately reflect the allocated size of the ExpandStr buffer to prevent buffer overrun when the native routine writes the expanded environment variable value.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT; the caller must treat their values as potentially modified upon return and must not assume they are unchanged after the call.
- BR-004 - The returned PLS_INTEGER status code must be evaluated by the calling routine (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully retrieved before the expanded value in ExpandStr is used.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper function that retrieves a Windows Registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry value and returns an integer status code indicating the outcome of the retrieval operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld to support registry-based configuration lookups from Oracle Forms.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows Registry API routine to be called.
- Step 2 - Accept the registry root identifier (RegRoot) that specifies the top-level registry hive (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) to target.
- Step 3 - Accept the registry path (RegPath) and registry entry name (RegEntry) that together identify the specific registry key and value to retrieve.
- Step 4 - Accept the maximum allowable length for the returned value (RegValueLength) to govern the buffer size for RegValue.
- Step 5 - Accept the RegDontExpand flag that controls whether environment-variable references embedded in the registry value are expanded before being returned.
- Step 6 - Invoke the native Windows Registry read operation via the ORA_FFI function handle with the supplied parameters.
- Step 7 - Populate the RegValue IN OUT parameter with the registry value string retrieved from the Windows Registry.
- Step 8 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating success or failure of the registry key retrieval.

---
**Decision Points**

DP-001

Condition: Whether the RegDontExpand flag is set (non-zero) or not (zero).

TRUE: The registry value is returned as-is, without expanding any embedded environment-variable references (e.g., %SystemRoot% remains unexpanded).

FALSE: The underlying Windows Registry API is permitted to expand environment-variable references within the registry value before it is returned in RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_FFI function handle (hFunc); this handle must be initialised by the calling routine (READ_REGISTRY) prior to invocation, as no handle initialisation occurs within this function.
- BR-002 - RegValueLength must accurately reflect the maximum buffer size allocated for RegValue; the retrieved registry value must not exceed this length.
- BR-003 - RegRoot must correspond to a valid Windows Registry hive constant; supplying an unrecognised root value will result in a failed retrieval reflected in the returned status code.
- BR-004 - The function returns a PLS_INTEGER status code; the caller (READ_REGISTRY) is responsible for interpreting this code to determine whether the registry key was successfully retrieved.
- BR-005 - RegPath and RegEntry are declared IN OUT; the calling routine must supply non-null, correctly formatted values for both parameters to identify the target registry entry.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name supplied by the caller into the corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type codes required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter DataType (VARCHAR2) representing a C data type token as a string.
- Step 2 - Normalise the input to uppercase and store it in the local variable vcType to ensure case-insensitive comparison.
- Step 3 - Evaluate vcType against the full set of supported C type tokens in a sequential IF-ELSIF chain.
- Step 4 - For each matching token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, '*INT' maps to ORA_FFI.C_INT_PTR, 'INT' maps to ORA_FFI.C_INT, '*LONG' maps to ORA_FFI.C_LONG_PTR, 'LONG' maps to ORA_FFI.C_LONG, '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR, 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT, '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR, 'DOUBLE' maps to ORA_FFI.C_DOUBLE, '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 5 - Return iRC to the caller (REGISTER_FUNCTION_CALL) as a PLS_INTEGER representing the resolved ORA_FFI type constant.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer to character type).
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR (character type by value).
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer to integer type).
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT (integer type by value).
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer to long type).
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG (long type by value).
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer to short/byte type; both aliases resolve to the same constant).
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT (short/byte type by value; both aliases resolve to the same constant).
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer to double type).
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE (double type by value).
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR (pointer to void type).
FALSE: No branch is matched; iRC remains uninitialised (NULL) and that NULL value is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is converted to uppercase before comparison, making type token matching case-insensitive; callers may supply mixed-case tokens without causing a lookup failure.
- BR-002 - The tokens '*SHORT' and '*BYTE' are treated as equivalent aliases and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-003 - The function supports exactly eleven recognised C type tokens: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT' / '*BYTE', 'SHORT' / 'BYTE', '*DOUBLE', 'DOUBLE', and '*VOID'; any token outside this set results in a NULL return value.
- BR-004 - The function performs a pure in-memory lookup with no database interaction and no side effects; it is deterministic for any given valid input token.
- BR-005 - The resolved ORA_FFI constant returned by this function is intended for consumption by REGISTER_FUNCTION_CALL to correctly register external C function parameter and return types via the ORA_FFI interface.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-007 - GENERAL.ASK_CONFIRM

**Invoked From:**

- sr_exch_tradein_fmb.xml [Trigger: FT_CANCEL]
- sr_exch_tradein_fmb.xml [Trigger: FT_DEL]
- sr_exch_tradein_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator reflecting the button pressed. The function is used across cancel, delete, and button-pressed triggers in the SR Exchange Trade-In form to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - If the user pressed ALERT_BUTTON1 (confirmed), return 1 to the caller to signal affirmative confirmation.
- Step 6 - If the user pressed any other button (declined), return 0 to the caller to signal that the action was not confirmed.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert)

TRUE:
The function returns 1, indicating the user has confirmed the action.

FALSE:
The function returns 0, indicating the user has declined or dismissed the confirmation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert presented to the user must always be AL_CONFIRM; no other alert identifier is used by this function.
- BR-002 - The alert message text is dynamically set at runtime from the confirm_msg parameter, allowing callers to supply context-specific confirmation messages without requiring separate alert objects.
- BR-003 - Only a response matching ALERT_BUTTON1 is treated as an affirmative confirmation; all other button responses are treated as a denial, ensuring that ambiguous or dismissed alerts default to a safe non-confirmation result.
- BR-004 - The function returns a numeric value (1 for confirmed, 0 for not confirmed); callers are responsible for interpreting this return value and branching their processing logic accordingly.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-008 - GENERAL.DISP_TEXT

**Invoked From:**

- sr_exch_tradein_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- sr_exch_tradein_fmb.xml [Trigger: FT_INSERT]
- sr_exch_tradein_fmb.xml [Trigger: ON-ERROR]
- sr_exch_tradein_fmb.xml [Trigger: ON-MESSAGE]
- sr_exch_tradein_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a given message and title. The procedure selects the appropriate pre-defined Oracle Forms alert component based on whether the message is classified as an error or a general notification, then presents it to the user. It is used across multiple triggers and program units in sr_exch_tradein_fmb.xml and by GENERAL.RAISE_ERROR in DPL.pld as the standard mechanism for surfacing text-based feedback.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and the dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value (case-insensitive) to determine which alert component to use: if it equals 'ERROR', assign alert name 'AL_ERRINFO'; otherwise assign alert name 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert to title_string using set_alert_property.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert to text_string using set_alert_property.
- Step 5 - Display the configured alert to the user by calling show_alert, capturing the user's button response in p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert component 'AL_ERRINFO' is selected, indicating an error-style dialog is required.

FALSE:
The alert component 'AL_NOTE' is selected, indicating a general informational or notification dialog is required.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure supports exactly two alert types: 'AL_ERRINFO' for error messages and 'AL_NOTE' for all other message categories; no other alert components are used.
- BR-002 - The classification of the alert type is determined solely by a case-insensitive comparison of title_string to the literal value 'ERROR'; any other title value, including variations such as 'Warning' or 'Info', routes to the AL_NOTE alert.
- BR-003 - Both the title and the message body of the alert are always overwritten at runtime via set_alert_property before display, ensuring the alert reflects the current call's content rather than any previously set values.
- BR-004 - The user's button selection returned by show_alert is captured but not acted upon; the procedure does not branch or raise exceptions based on the user's response.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-009 - GENERAL.RAISE_ERROR

**Invoked From:**

- sr_exch_tradein_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms by accepting a message code, determining the message severity type, composing a display string, and presenting it to the user via GENERAL.DISP_TEXT. For error-level messages the procedure additionally halts form processing by raising FORM_TRIGGER_FAILURE. It is invoked by the ON-ERROR trigger in sr_exch_tradein_fmb.xml to intercept and present form errors in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-008](#SP-008--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Declare local variables for message type (mesg_type), message text (mesg_text), and message title (mesg_title); note that the former GENERAL.get_message call is commented out, so mesg_type and mesg_text retain their default NULL values unless set elsewhere prior to invocation.
- Step 3 - Compose the display text by concatenating mesg_code, a colon separator, and mesg_text to form the full message string.
- Step 4 - Evaluate mesg_type to determine severity and route to the appropriate handling branch (Error, Note, or Caution).
- Step 5 - For an Error message (mesg_type = 'E'), set the title to 'Error', call GENERAL.DISP_TEXT to display the message, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 6 - For a Note message (mesg_type = 'N'), set the title to 'Note' and call GENERAL.DISP_TEXT to display the message; processing continues normally.
- Step 7 - For a Caution message (mesg_type = 'C'), set the title to 'Caution' and call GENERAL.DISP_TEXT to display the message; processing continues normally.
- Step 8 - If mesg_type does not match any recognised severity code, no display action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E' (Error severity)

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to present the error dialog, then raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Proceed to evaluate whether mesg_type = 'N'.

---

DP-002

Condition:
mesg_type = 'N' (Note severity)

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to present the informational dialog; form processing continues.

FALSE:
Proceed to evaluate whether mesg_type = 'C'.

---

DP-003

Condition:
mesg_type = 'C' (Caution severity)

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to present the caution dialog; form processing continues.

FALSE:
No matching severity code; the procedure takes no display action and exits silently.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The full message presented to the user must always include the original message code as a prefix, separated from the message text by ' : ', ensuring traceability back to the originating code.
- BR-002 - A message classified as Error (mesg_type = 'E') must unconditionally raise FORM_TRIGGER_FAILURE after display, preventing any further form trigger processing.
- BR-003 - A message classified as Note (mesg_type = 'N') or Caution (mesg_type = 'C') must be displayed to the user but must not interrupt form processing.
- BR-004 - All user-facing message dialogs must be rendered exclusively through GENERAL.DISP_TEXT (SP-008); no direct Oracle Forms alert or message calls are permitted within this procedure.
- BR-005 - If mesg_type does not correspond to a recognised severity code ('E', 'N', or 'C'), the procedure must exit without displaying any message, avoiding spurious dialogs for unclassified codes.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-010 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before continuing. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-018](#SP-018--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing cmd and the constant BLOCKING_MODE to run the command synchronously.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, allowing the invoking routine (WEBUTIL.GETVAR) to reference the completed process.

---
**Decision Points**

No conditional decision points exist within this function. The function unconditionally delegates to WEBUTIL.EXECUTE with BLOCKING_MODE; all branching logic is handled within WEBUTIL.EXECUTE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; non-blocking execution is not permitted through this function.
- BR-002 - The function must return a PROCESS_ID to the caller, enabling downstream procedures such as WEBUTIL.GETVAR to identify and interact with the completed process.
- BR-003 - All execution handling, including process management and error conditions, is delegated entirely to WEBUTIL.EXECUTE; WEBUTIL.BLOCKING introduces no additional processing logic of its own.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-011 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the correct version. For each library defined in the property bundle for the package, the procedure compares the installed version recorded in the client settings against the expected version. Where a library is absent, outdated, or flagged for forced re-download, the procedure downloads the library from the configured URL and updates the client setting to reflect the newly installed version. The procedure is invoked by WEBUTIL.REGISTERBEAN as part of the package registration lifecycle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-045](#SP-045--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter that identifies the WebUtil package whose system libraries must be checked.
- Step 2 - Enter a loop and, for each iteration, attempt to read a library specification entry from the property bundle using the fully qualified key 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>'. The loop index starts at 1 and increments by 1 on each successful read.
- Step 3 - If no specification is found for the OS-family/architecture-specific key, fall back to the less specific key 'install.syslib.<OSFamily>.<packageID>.<index>' via a second call to WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 4 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 5 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (field 1), expected file size in bytes (field 2), expected version string (field 3), and a progress-display flag (field 4).
- Step 6 - Query the current installed version of the library by calling WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>'.
- Step 7 - Evaluate whether a download is required: the library must be downloaded if the installed version is NULL, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 8 - When a download is required, resolve the download base URL by calling WEBUTIL.READFROMPROPERTYBUNDLE in order of decreasing specificity: OS-family/architecture key first, then OS-family-only key, then the generic 'install.syslib.location' key.
- Step 9 - Call WEBUTIL.DOWNLOADFROMURLINT with the fully composed URL (base URL + '/' + library file name), the library name, a syslib-install indicator (value 1), the expected file size, the progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 10 - If the download succeeds, call WEBUTIL.SETCLIENTSETTING to record the newly installed version under the key 'syslib.<libName>'.
- Step 11 - If the download fails, call WEBUTIL.LOG to record a failure message ('Download of system library <libName> failed') and flag it as an error.
- Step 12 - Continue the loop to process the next library entry for the package.

---
**Decision Points**

DP-001

Condition: The OS-family/architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL library specification.

TRUE: Use the returned specification; skip the fallback lookup.

FALSE: Attempt the less specific fallback key ('install.syslib.<OSFamily>.<packageID>.<index>') via a second call to WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-002

Condition: Both the OS-family/architecture-specific and the OS-family-only property bundle lookups return NULL for the current loop index.

TRUE: Exit the loop; no further library entries exist for this package.

FALSE: Continue processing the retrieved library specification.

---

DP-003

Condition: The installed version retrieved via WEBUTIL.GETCLIENTSETTING is NULL, does not match the expected version from the property bundle, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip download and advance to the next loop iteration.

---

DP-004

Condition: The OS-family/architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the OS-family-only location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key ('install.syslib.location.<OSFamily>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the generic location key ('install.syslib.location').

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Call WEBUTIL.SETCLIENTSETTING to record the installed version for the library.

FALSE: Call WEBUTIL.LOG to record a download failure error for the library.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications must be defined in the property bundle using the key pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>' or the fallback pattern 'install.syslib.<OSFamily>.<packageID>.<index>'; any package with no matching entries requires no library installation.
- BR-002 - Each library specification entry must be a pipe-delimited string containing, in order: library file name, expected file size, expected version string, and a Boolean progress-display indicator ('TRUE'/'FALSE').
- BR-003 - A library is considered up to date only when the client setting key 'syslib.<libName>' exists and its value exactly matches the expected version string from the property bundle; a NULL or mismatched value mandates re-download.
- BR-004 - The REDOWNLOAD_SYSLIB flag, when TRUE, forces re-download of all system libraries regardless of the currently recorded installed version.
- BR-005 - The download base URL is resolved with OS specificity applied in descending order (OS-family + architecture -> OS-family only -> generic); the first non-NULL value found is used.
- BR-006 - The installed version client setting ('syslib.<libName>') must be updated via WEBUTIL.SETCLIENTSETTING only upon confirmed successful download; a failed download must not update the setting.
- BR-007 - A failed library download must be logged as an error via WEBUTIL.LOG with a message identifying the library name, ensuring the failure is visible for diagnostic purposes.
- BR-008 - Progress dialog labels presented during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localised display.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the provided integer key. This procedure ensures that stale or consumed callback registrations are cleaned up, preventing unintended re-execution of callback triggers within the WebUtil processing context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the target callback entry within the internal m_callbacks collection.
- Step 2 - Check whether an entry corresponding to callbackKey currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection, effectively deregistering the callback trigger.
- Step 4 - If no entry exists for the given key, take no action and exit silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - an entry for the supplied callbackKey is present in the m_callbacks collection.

TRUE: The entry is deleted from m_callbacks, removing the callback registration.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A callback entry is removed only if it currently exists in the m_callbacks collection; the procedure must not raise an error when the specified key is absent.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to a valid index within the m_callbacks collection; the procedure does not perform any transformation or validation of the key beyond the existence check.
- BR-003 - Each call to this procedure removes at most one entry from the m_callbacks collection, identified exclusively by the supplied callbackKey.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-013 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by a checksum value by delegating the close operation to the WebUtil_DB package. This procedure finalises access to a BLOB resource that was previously opened within a WebUtil database session, ensuring the handle is properly released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the identifying key.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB handle was successfully closed.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a previously opened BLOB handle; the validity and resolution of that handle is enforced by WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is determined entirely by WebUtil_DB.CloseBlob; this function returns that outcome unchanged to the caller.
- BR-003 - No direct database table interactions are performed by this function; all BLOB lifecycle management is encapsulated within WebUtil_DB.CloseBlob.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-014 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file reader object by invoking the corresponding Java method on the AppServerFileReader class. This procedure is called by WEBUTIL.SETDATA to release the file handle once all data transfer operations on the server file have been completed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing the active AppServerFileReader instance that holds the open file handle.
- Step 2 - Reset the argument list (args) to NULL, as the closeFile Java method requires no arguments.
- Step 3 - Invoke the closeFile() method on the AppServerFileReader Java class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and the method signature '()Z'.
- Step 4 - Return the Boolean result produced by the Java method call, indicating whether the file was successfully closed.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally delegates the close operation to the Java layer and returns the result directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file close operation is performed exclusively through the JNI bridge targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class; no direct PL/SQL or database file-handling mechanism is used.
- BR-002 - The argument list must be set to NULL before invoking the Java closeFile method, as the method accepts no parameters ('()Z' signature).
- BR-003 - The Boolean return value from the Java method must be propagated back to the caller unchanged, allowing the invoking routine (WEBUTIL.SETDATA) to determine whether the file handle was successfully released.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-015 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initiates a file download from a specified URL to a client-side destination by constructing a delimited parameter string and delegating the download request to the WebUtil Core bean via property set/get calls. The function returns TRUE if the download completes successfully, or FALSE (and raises an error) if mandatory inputs are missing or the underlying bean is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception and return FALSE after logging error code 25 via WebUtil_Core.Error.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception and return FALSE after logging error code 130 via WebUtil_Core.Error.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, default the value to '0'; otherwise convert the supplied integer to a character string. Append this value followed by the pipe separator ('|') to begin building submitString.
- Step 4 - Evaluate fileSize: if null, append '0|' to submitString; otherwise append the character representation of fileSize followed by '|'.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N|' to submitString; if TRUE, append 'Y|'.
- Step 6 - Concatenate the remaining parameters - sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) - each separated by the pipe delimiter, to complete submitString.
- Step 7 - Submit the assembled submitString to the WebUtil Core bean by calling WebUtil_Core.setProperty with property key WUC_URL_DOWNLOAD on the WUC_PACKAGE component.
- Step 8 - Retrieve the result of the download operation by calling WebUtil_Core.getProperty with the same property key.
- Step 9 - Return TRUE if the retrieved result equals the string 'TRUE'; otherwise return FALSE.
- Step 10 - If a BEAN_NOT_REGISTERED exception is raised during bean communication, display an alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE.
- Step 11 - If a PROPERTY_ERROR exception is raised during bean communication, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception; log error code 25 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Proceed to validate clientDestination.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception; log error code 130 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Proceed to evaluate specialDestination.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append '0|' to submitString (default to zero).

FALSE: Append the character representation of specialDestination followed by '|' to submitString.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append '0|' to submitString.

FALSE: Append the character representation of fileSize followed by '|' to submitString.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N|' to submitString (progress display suppressed).

FALSE: Append 'Y|' to submitString (progress display enabled).

---

DP-006

Condition: result (returned from WebUtil_Core.getProperty) = 'TRUE'

TRUE: Function returns TRUE, indicating the download succeeded.

FALSE: Function returns FALSE, indicating the download did not succeed.

---

DP-007

Condition: BEAN_NOT_REGISTERED exception raised during WebUtil_Core interaction

TRUE: Display an alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt processing.

FALSE: Not applicable (exception path only).

---

DP-008

Condition: PROPERTY_ERROR exception raised during WebUtil_Core interaction

TRUE: Raise FORM_TRIGGER_FAILURE to halt processing.

FALSE: Not applicable (exception path only).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be supplied; a null sourceURL is invalid and will cause the function to abort with error code 25, returning FALSE.
- BR-002 - A client destination path must be supplied; a null clientDestination is invalid and will cause the function to abort with error code 130, returning FALSE.
- BR-003 - The specialDestination value must be an integer in the range 0-2 inclusive; any null, negative, or out-of-range value is silently defaulted to 0.
- BR-004 - A null fileSize is treated as 0 (unknown or unspecified file size) when constructing the download request.
- BR-005 - Progress display is opt-in; a null or FALSE withProgress flag suppresses the progress indicator ('N'), while an explicit TRUE enables it ('Y').
- BR-006 - Optional progress text parameters (progressTitle, progressSubTitle, progressMessage) must never be passed as null to the bean; each defaults to a single space character to preserve the integrity of the pipe-delimited submitString.
- BR-007 - The pipe character ('|') is the mandatory field delimiter within the submitString submitted to the WebUtil Core bean; all parameter values are concatenated in a fixed order using this separator.
- BR-008 - If the WebUtil Core bean is not registered, processing must be halted via FORM_TRIGGER_FAILURE; the function cannot perform a download without the bean.
- BR-009 - A PROPERTY_ERROR returned by the WebUtil Core bean is a fatal condition that must halt form processing via FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-016 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a package/unit name, and up to three optional argument values, then publishes the composed message to the WebUtil core property 'WUC_ERROR_MSG' for the specified package instance. This provides a standardised mechanism for reporting errors back to the WebUtil framework during custom event handling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package instance identifier (packageID), a numeric error code (code), the name of the originating package or unit (pu_name), and up to three optional supplementary arguments (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR', the error code left-padded with leading zeros to three digits, a pipe delimiter '|', and the pu_name value (e.g. 'ERROR005|MY_PACKAGE').
- Step 3 - Evaluate whether arg1 is not null; if so, append a pipe delimiter and the value of arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is not null; if so, append a pipe delimiter and the value of arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is not null; if so, append a pipe delimiter and the value of arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty, passing the packageID, the property key 'WUC_ERROR_MSG', and the fully composed error text string to register the error message against the correct package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter '|' followed by the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter '|' followed by the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter '|' followed by the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; the error text string is finalised as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the fixed prefix 'ERROR' followed by the numeric code formatted as exactly three digits, left-padded with zeros (e.g. code 5 becomes '005'), ensuring a consistent and parseable error identifier format.
- BR-002 - The pipe character '|' is the mandatory delimiter between all segments of the error text string (prefix+code, pu_name, and each non-null argument), enforcing a uniform tokenised structure for downstream parsing.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error text only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - The composed error message must be published to the WebUtil core property 'WUC_ERROR_MSG' against the correct package instance identified by packageID, ensuring error context is scoped to the originating package.
- BR-005 - The maximum length of the composed error text string is 1024 characters, as defined by the local variable declaration; error messages exceeding this length will result in a runtime error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-017 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user via a pre-registered alert dialog. The procedure is a centralised error-notification utility called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE whenever a bean-not-registered or bean-not-found condition must be communicated. If the alert object is available it is used; otherwise the message is surfaced through the standard Forms MESSAGE built-in.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error description text (errText) as input.
- Step 2 - Invoke WEBUTIL.ID_NULL (SP-035) to test whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If the alert handle is valid, set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded, as no downstream branching depends on the user's button choice.
- Step 5 - If the alert handle is not valid (alert not registered), fall back to the Forms MESSAGE built-in, prefixing the error text with the literal 'WebUtil Error: ' to ensure consistent presentation.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - i.e., the alert object handle m_errorAlert is not null and refers to a registered alert.

TRUE:
Set the alert message text to errText via SET_ALERT_PROPERTY and display the alert to the user via SHOW_ALERT. The user's button response is ignored.

FALSE:
The alert object is unavailable; display the error using the Forms MESSAGE built-in in the format 'WebUtil Error: <errText>'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - WEBUTIL.ERRORALERT must be used exclusively for surfacing bean-not-registered or bean-not-found errors within the WebUtil framework; it is not a general-purpose alert utility.
- BR-002 - The alert title is not modified at runtime; it is assumed to be pre-configured on the alert object m_errorAlert at design time.
- BR-003 - The user's response to the alert dialog is intentionally discarded; the procedure does not branch or take corrective action based on which button the user selects.
- BR-004 - When the alert handle m_errorAlert is unavailable, the error message presented via MESSAGE must be prefixed with 'WebUtil Error: ' to maintain a consistent error identification format across both display paths.
- BR-005 - Availability of the alert object is determined solely by WEBUTIL.ID_NULL (SP-035); no other validation of m_errorAlert is performed.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-018 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a host operating-system command for execution on the client machine by delegating to the WebUtil host-execution bean. The procedure sets the desired execution mode, passes the command string to the WebUtil Core layer, and returns a process handle that the caller can use to reference the spawned process. If the required WebUtil bean is not registered, the procedure raises an informational error alert and aborts gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as input parameters.
- Step 2 - Evaluate whether cmd is non-null; if it is null, skip all processing and return an empty PROCESS_ID handle to the caller.
- Step 3 - Set the execution mode on the WebUtil host-utility package by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Submit the command for execution by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the WebUtil bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, convert the returned string value to a number, and store it in the local PROCESS_ID variable (procId.handle).
- Step 6 - Return the populated PROCESS_ID record to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and indicating that WEBUTIL_HOST.Execute will not function, then exit without returning a valid handle.

---
**Decision Points**

DP-001

Condition: The input parameter cmd IS NOT NULL.

TRUE: Set the execution mode property, submit the command to the WebUtil host-utility bean, retrieve and store the resulting process handle, and return the populated PROCESS_ID to the caller.

FALSE: Bypass all WebUtil property calls and return an empty (default) PROCESS_ID record to the caller.

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property set or get operations.

TRUE: Display an error alert that identifies the unregistered implementation class and states that WEBUTIL_HOST.Execute will not work; procedure exits without returning a valid process handle.

FALSE: No exception occurs; normal processing completes and the PROCESS_ID is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string is treated as a no-operation; no execution request is submitted to the WebUtil bean and an empty PROCESS_ID is returned, preventing unintended host-process invocations.
- BR-002 - The execution mode (exemode) must be explicitly communicated to the WebUtil bean before the command is submitted; the mode property (WUH_EXECUTION_MODE) must be set prior to setting the execute property (WUH_EXECUTE) to ensure the bean applies the correct execution behaviour.
- BR-003 - The process identifier returned by the WebUtil bean is delivered as a string via WebUtil_Core.getProperty and must be converted to a numeric value before being stored in the PROCESS_ID handle; no raw string handle is exposed to the caller.
- BR-004 - If the WebUtil host-utility bean is not registered in the runtime environment, the procedure must not silently fail; it must surface an error alert identifying the missing bean class so that the integration issue can be diagnosed and resolved.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-019 - WEBUTIL.FCLOSE

**Invoked From:**

- sr_exch_tradein_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by releasing the underlying WebUtil file handle. The procedure nullifies the handle on the file_type record to signal that the file is no longer open, and raises a fatal tool error if the required WebUtil bean is unavailable or if a property-level error occurs during the close operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-024](#SP-024--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file_type parameter (IN OUT) representing the currently open client-side file.
- Step 2 - Check whether the file handle is not NULL, indicating an open file that requires closing.
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE action, passing the file handle to instruct the WebUtil bean to close the file on the client.
- Step 4 - Set the file handle to NULL on the file_type record, marking the file as closed within the calling session.
- Step 5 - If the BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive error message that includes the implementation class name retrieved by WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass), then raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If the PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR immediately without an alert, halting further processing.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
The file is considered open; WebUtil_Core.setProperty is called to close the file on the client and the handle is set to NULL.

FALSE:
No action is taken; the procedure exits without attempting to close anything.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE:
WEBUTIL.ERRORALERT is called with a message composed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then TOOL_ERR.TOOL_ERROR is raised to abort processing.

FALSE:
Exception is not raised; normal processing continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the close operation.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to abort processing; no alert is displayed.

FALSE:
Exception is not raised; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is not NULL; a NULL handle is treated as already closed and no WebUtil call is made.
- BR-002 - Upon successful closure, the file handle must be set to NULL on the file_type record to prevent duplicate or stale close attempts by the caller.
- BR-003 - If the WebUtil bean required to perform the client-side close is not registered, WEBUTIL.ERRORALERT must be invoked with a message that includes the implementation class name (obtained via WEBUTIL.GETIMPLCLASS) before raising a fatal error, ensuring the user receives an actionable diagnostic message.
- BR-004 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions are treated as fatal; processing must be halted by raising TOOL_ERR.TOOL_ERROR in either case.
- BR-005 - No database interactions occur during file close; all operations are confined to client-side file handling via the WebUtil bean layer.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-020 - WEBUTIL.FOPEN

**Invoked From:**

- sr_exch_tradein_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text I/O by delegating to the WebUtil Java bean layer. The function validates the requested file path and access mode, transmits the open request to the client-side bean via WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty), and returns a typed file handle that subsequent client text I/O operations can use. It is invoked as part of the VIEW_EXCEL_REP stored procedure in sr_exch_tradein_fmb.xml to support Excel report file access on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-030](#SP-030--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values: `r` (read), `w` (write), or `a` (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is outside this set.
- Step 2 - Validate the file specification: confirm that `spec` is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR if no file path has been provided.
- Step 3 - Transmit the file path to the WebUtil bean: call WebUtil_Core.setProperty to push the value of `spec` into the WUF_FILENAME property of the WUF_PACKAGE bean.
- Step 4 - Transmit the file mode to the WebUtil bean: call WebUtil_Core.setProperty to push `filemode` into the WUF_TEXTIO_FILEMODE property.
- Step 5 - Transmit the character set to the WebUtil bean: if `charSet` is NULL, push the literal string `(null)` into WUF_TEXTIO_CHARSET; otherwise push the supplied charset value. This ensures the bean always receives an explicit charset signal.
- Step 6 - Request the bean to open the file: invoke WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) against the WUF_TEXTIO_OPEN property of WUF_PACKAGE. The bean attempts to open the file and returns a Java handle string.
- Step 7 - Validate the returned handle: if the handle is NULL, empty, or equals `-1`, the file was not opened successfully; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Construct and return the file handle: convert the valid Java handle string to a number, assign it to `clientFile.handle`, and return the populated `file_type` record to the caller.
- Step 9 - Handle exceptions: if the WebUtil bean is not registered, display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR. Propagate PROPERTY_ERROR, VALUE_ERROR (re-raised as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition:
Is `lower(filemode)` NOT IN ('r', 'w', 'a')?

TRUE:
The file mode is invalid; raise TOOL_ERR.TOOL_ERROR and abort processing.

FALSE:
The file mode is acceptable; continue to the next validation.

---

DP-002

Condition:
Is `spec` NULL or equal to an empty string?

TRUE:
No file path has been provided; raise TOOL_ERR.TOOL_ERROR and abort processing.

FALSE:
A file path exists; continue to transmit properties to the WebUtil bean.

---

DP-003

Condition:
Is `charSet` NULL?

TRUE:
Push the literal string `(null)` into the WUF_TEXTIO_CHARSET property so the bean receives an explicit no-charset signal.

FALSE:
Push the supplied `charSet` value into the WUF_TEXTIO_CHARSET property.

---

DP-004

Condition:
Is the Java handle returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) NULL, empty, or equal to '-1'?

TRUE:
The client-side file open attempt failed; raise TOOL_ERR.TOOL_ERROR.

FALSE:
The file was opened successfully; convert the handle to a number, populate `clientFile.handle`, and return the file handle to the caller.

---

DP-005

Condition:
Does the EXCEPTION block catch BEAN_NOT_REGISTERED?

TRUE:
Display an error alert identifying the missing WebUtil bean class, then raise TOOL_ERR.TOOL_ERROR and return NULL.

FALSE:
Evaluate subsequent exception handlers (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) and propagate accordingly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file access mode must be exactly one of `r`, `w`, or `a` (evaluated case-insensitively); any other value is rejected before any client interaction occurs.
- BR-002 - A non-null, non-empty file specification (path) is mandatory; the function will not attempt to open an unidentified file.
- BR-003 - When no character set is explicitly provided by the caller, the function must still transmit a defined sentinel value (`(null)`) to the WebUtil bean so that the bean's charset handling is deterministic.
- BR-004 - A Java handle of NULL, empty string, or `-1` is treated as a failed open; the function must not return a file handle to the caller in this state.
- BR-005 - The function depends on WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) to retrieve the file handle from the client-side bean; if the bean is not registered, the operation cannot proceed and a descriptive error alert must be raised before propagating TOOL_ERR.TOOL_ERROR.
- BR-006 - All error conditions (invalid mode, missing spec, failed open, bean absence, property error, value conversion error) must surface as TOOL_ERR.TOOL_ERROR to the caller, ensuring a uniform error contract for consuming routines such as VIEW_EXCEL_REP.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-021 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key by looking up the value in the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger should be invoked for a specific WebUtil callback operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer callback key (callbackKey) as input.
- Step 2 - Use callbackKey as an index to look up the corresponding trigger name in the package-level collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name retrieved from m_callbacks to the caller.

---
**Decision Points**

No decision points are present in the implementation logic. The function performs a direct collection lookup and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds checking or default handling is performed within this function, so the caller is responsible for supplying a key that was previously registered in the collection.
- BR-002 - The return value is the VARCHAR2 trigger name stored at the specified index in m_callbacks; no transformation or formatting is applied to the stored value before it is returned.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-022 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally held client OS family classification (stored in the package-level variable m_clientOSFamily) to calling routines, enabling the application to make platform-aware decisions based on the client environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR (via webutil.pld) to retrieve the client operating system family.
- Step 2 - The function reads the value of the package-level variable m_clientOSFamily, which holds the pre-populated OS family identifier for the current client session.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller with no transformation or additional processing.

---
**Decision Points**

No decision points are present. The function unconditionally returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the value of m_clientOSFamily exactly as stored; no defaulting, validation, or transformation is applied to the returned value.
- BR-002 - The client OS family identifier must have been populated into m_clientOSFamily prior to invocation; this function only reads the variable and does not set or initialise it.
- BR-003 - The return type is PLS_INTEGER, constraining the OS family identifier to an integer representation; callers must interpret the numeric value according to the WebUtil OS family enumeration convention.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-023 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil core bean. Given a property name, the function delegates to WebUtil_Core to query the local client environment and returns the corresponding value as a VARCHAR2 string. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client settings before proceeding with library checks and bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2) identifying the client-side setting to be retrieved.
- Step 2 - Evaluate whether propertyName is non-null; if null, skip all processing and return a null result.
- Step 3 - If propertyName is non-null, invoke WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName value, instructing the WebUtil core bean to prepare the requested property.
- Step 4 - Invoke WebUtil_Core.getProperty targeting the same WUC_PACKAGE component and key WUC_GET_LOCAL_PROPERTY to read back the resolved property value into the local result variable.
- Step 5 - Return the result variable to the caller.
- Step 6 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during Steps 3-4, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a WebUtil_Core.PROPERTY_ERROR exception is raised during Steps 3-4, raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to set the property on the WebUtil core bean via WebUtil_Core.setProperty, then retrieve the resolved value via WebUtil_Core.getProperty and store it in the result variable.

FALSE: Skip all bean interaction; result remains NULL and is returned immediately to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property set/get

TRUE: Display an error alert identifying the unregistered bean class (obtained via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Exception is not raised; normal processing continues.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during bean property set/get

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Exception is not raised; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any interaction with the WebUtil core bean; the function must return NULL silently in this case.
- BR-002 - The property retrieval must be performed exclusively through the WebUtil_Core.setProperty / WebUtil_Core.getProperty mechanism targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY; no direct client access is permitted.
- BR-003 - If the WebUtil core bean is not registered at the time of invocation, the function must surface a descriptive error alert that includes the bean implementation class name before terminating form processing via FORM_TRIGGER_FAILURE.
- BR-004 - If a property error occurs during the bean interaction, the function must raise FORM_TRIGGER_FAILURE immediately, ensuring the calling form trigger does not continue with an unreliable or partial result.
- BR-005 - The returned client setting value must not exceed 255 characters; the result variable is defined as VARCHAR2(255 CHAR) and any value exceeding this length will cause a runtime error.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-024 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class suffix for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package identifier (packageID) as an integer input representing a specific WebUtil package.
- Step 2 - Look up the implementation class suffix for the supplied packageID from the internal collection m_implClasses.
- Step 3 - Concatenate the constant WEBUTIL_JAVA_ROOT prefix with the retrieved class suffix to form the fully qualified Java class name.
- Step 4 - Return the resulting fully qualified class name string to the caller (WEBUTIL.FCLOSE).

---
**Decision Points**

No conditional decision points exist in this function. The function performs a direct collection lookup and string concatenation without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid index within the m_implClasses collection; no bounds-checking or default handling is performed, so an invalid packageID will result in a runtime error.
- BR-002 - The fully qualified Java class name is always constructed by prepending the WEBUTIL_JAVA_ROOT constant to the implementation class suffix, ensuring all resolved class names share the same root package path.
- BR-003 - This function has no external or internal dependencies; it relies solely on the package-level constant WEBUTIL_JAVA_ROOT and the package-level collection m_implClasses, both of which must be initialised prior to invocation.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-025 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function interrogates the underlying Java instance via JNI to return an integer error code, allowing the calling routine (WEBUTIL.SETDATA) to determine whether a preceding file-transfer operation completed successfully or encountered an error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object reference (obj) as the sole input parameter.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the Java instance method getLastError() on the AppServerFileReader class via JNI.CALL_INT_METHOD, targeting the method signature '()I' (no arguments, integer return).
- Step 4 - Return the integer error code produced by the Java method call to the caller.

---
**Decision Points**

No conditional decision points exist within this function. The function unconditionally clears the argument list and delegates execution to the Java getLastError() method, returning its result directly to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always reset the JNI argument list (args := NULL) before invoking the Java method to prevent argument contamination from prior JNI calls.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader and the target method signature is '()I'; no deviation from these identifiers is permitted.
- BR-003 - The function operates in instance-method mode (FALSE flag on CALL_INT_METHOD), meaning the supplied obj reference must be a valid, non-null AppServerFileReader instance at the time of invocation.
- BR-004 - The function returns a NUMBER representing the last error code; a return value of zero conventionally indicates no error, while any non-zero value indicates a file-transfer error condition to be handled by the caller.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-026 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates to the JNI layer to invoke the native Java method and returns the error argument details as a VARCHAR2 string, enabling the caller (WEBUTIL.SETDATA) to obtain contextual information about the last file-transfer error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an instance of the AppServerFileReader class.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java method getLastErrorArgs on the supplied object via JNI.CALL_STRING_METHOD, targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader class with the method signature ()Ljava/lang/String;.
- Step 4 - Return the VARCHAR2 string result received from the JNI call to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be explicitly set to NULL before the JNI call to prevent stale argument data from being passed to the Java method.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader; no other class may be substituted for this invocation.
- BR-003 - The Java method signature must be ()Ljava/lang/String;, indicating the method accepts no arguments and returns a String; the function enforces this contract via the JNI call.
- BR-004 - The function returns whatever string value the JNI layer provides, including NULL if no error argument information is available on the Java object.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-027 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified positional index. The function delegates string extraction to WEBUTIL.GETSTRING and converts the returned substring to a NUMBER, providing callers with a type-safe numeric value without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-031](#SP-031--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position, the optional UnTerminated flag (defaulting to FALSE), and the optional delimiter character (defaulting to a comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-031), which locates and returns the raw substring at the requested field position within the delimited source string.
- Step 3 - Apply the Oracle built-in TO_NUMBER function to the string value returned by WEBUTIL.GETSTRING, converting it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No explicit conditional decision points exist within this function. All branching logic related to field extraction (delimiter scanning, boundary detection, and UnTerminated handling) is fully encapsulated within WEBUTIL.GETSTRING (SP-031). This function unconditionally passes its inputs to WEBUTIL.GETSTRING and converts the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The delimiter parameter defaults to a comma (',') if not supplied by the caller; callers requiring a different delimiter must pass it explicitly.
- BR-002 - The UnTerminated parameter defaults to FALSE if not supplied; callers must set it to TRUE only when the source string is not terminated by a trailing delimiter after the final field.
- BR-003 - The field at the specified position must contain a value that is convertible to a NUMBER; if WEBUTIL.GETSTRING returns a non-numeric substring, the Oracle TO_NUMBER conversion will raise a runtime exception.
- BR-004 - All rules governing valid field positions, delimiter parsing, and boundary conditions are governed by WEBUTIL.GETSTRING (SP-031); this function imposes no additional validation on the extracted string before conversion.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-028 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., CLIENT_PLATFORM_WIN32, CLIENT_PLATFORM_MAC, CLIENT_PLATFORM_LINUX, CLIENT_PLATFORM_SOLARIS, CLIENT_PLATFORM_HP, CLIENT_PLATFORM_AIX, or CLIENT_PLATFORM_UNKNOWN). The resolved platform value is stored in the package-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the osName input parameter and convert it to lowercase, storing the result in the local variable l_osName to ensure case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the package-level cache variable m_clientOSFamily is null; if it is not null, skip all evaluation and proceed directly to Step 10.
- Step 4 - If m_clientOSFamily is null, inspect l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not found, inspect l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not found, inspect l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not found, inspect l_osName for the substrings 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator was found, inspect l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not found, inspect l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the package-level variable m_clientOSFamily, caching it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed to evaluate the osName string against all known platform identifiers and populate m_clientOSFamily with the resolved platform constant.

FALSE: Skip all platform evaluation and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to evaluate the next platform identifier (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to evaluate the next platform identifier (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to evaluate the next platform identifier (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to evaluate the next platform identifier (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to evaluate the next platform identifier (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no further platform checks are performed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The osName input is converted to lowercase before any substring comparison, ensuring that platform detection is case-insensitive regardless of how the operating system reports its name.
- BR-002 - Platform evaluation follows a strict precedence order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and no further checks are performed.
- BR-003 - If the osName string does not match any known platform identifier, the function returns CLIENT_PLATFORM_UNKNOWN, signalling that the client platform could not be determined.
- BR-004 - The resolved platform constant is cached in the package-level variable m_clientOSFamily after the first successful evaluation. All subsequent invocations return the cached value directly, preventing redundant re-evaluation of the OS name.
- BR-005 - Solaris is identified by either the substring 'solaris' or 'sunos' in the OS name, accommodating both the commercial Solaris branding and the legacy SunOS designation.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-029 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a previously spawned host process by repeatedly polling the WebUtil client-side bean for buffered output lines. The function accumulates the lines into an OUTPUT_ARRAY and returns the complete collection to the caller (WEBUTIL.GET_STANDARD_OUTPUT). If the required bean is not registered on the client, an error alert is raised and the function terminates gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-036](#SP-036--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE context, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a polling loop. On each iteration, call WebUtil_Core.getProperty with the WUH_PACKAGE context and the caller-supplied 'prop' parameter to retrieve the next buffered output line into a 257-character buffer.
- Step 3 - Extract the first character of the buffer as a status indicator ('Y' = more lines follow, 'N' = this is the last line, 'X' = buffer was empty).
- Step 4 - If the status is not 'X' (i.e., a real line is present), store the remainder of the buffer (characters 2 onward) as the next element in the OUTPUT_ARRAY and increment the array index.
- Step 5 - Exit the loop when the status is not 'Y' (i.e., the last line has been read or the buffer was empty).
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - On package initialisation, call Webutil_Core.Init to ensure the WebUtil core is instantiated before any function in the package is used.
- Step 8 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and abort processing.

---
**Decision Points**

DP-001

Condition: The status character extracted from the buffer is 'X'.

TRUE: The buffer was empty; the current iteration does not add an entry to the OUTPUT_ARRAY, and the loop exit condition is evaluated.

FALSE: A valid output line is present; the substring from position 2 onward is stored in the OUTPUT_ARRAY at the current index and the index is incremented.

---

DP-002

Condition: The status character extracted from the buffer is 'Y'.

TRUE: More output lines are expected; the loop continues and polls for the next line.

FALSE: No further lines are expected (status is 'N' or 'X'); the loop exits and the accumulated OUTPUT_ARRAY is returned.

---

DP-003

Condition: A BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: The required WebUtil bean is not present on the client; an error alert is displayed identifying the missing bean class, and the function does not return an OUTPUT_ARRAY.

FALSE: The bean is registered; normal processing continues and the OUTPUT_ARRAY is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil core (via WebUtil_Core.setProperty) before any output lines are polled; this associates the polling session with the correct host process.
- BR-002 - Each value returned by WebUtil_Core.getProperty is treated as a two-part token: the first character is a control status ('Y', 'N', or 'X') and the remaining characters are the actual output line content; these two parts must never be conflated.
- BR-003 - A status of 'X' indicates an empty buffer; no entry is written to the OUTPUT_ARRAY for that iteration, preventing blank lines from being included in the result.
- BR-004 - A status of 'N' signals the final line of output; after storing that line the loop must exit, ensuring the function does not poll indefinitely.
- BR-005 - The output buffer is limited to 257 characters per line; any single line of host process output that exceeds this length will be truncated to fit the buffer.
- BR-006 - The WebUtil core must be initialised (Webutil_Core.Init) at package load time; no output-retrieval operation may proceed against an uninitialised core.
- BR-007 - If the WebUtil bean required by this function is not registered on the client, processing must halt and an informative error alert must be presented to the user; silent failure is not permitted.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-030 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Callers such as WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN use this function to obtain environment-level property values (e.g., file separators, OS name, Java version) that govern subsequent file-handling and bean-registration behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) identifying the Java system property to be queried.
- Step 2 - Initialise a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the property key string to the argument list via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java static method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the prepared argument list.
- Step 5 - Return the string value of the requested system property to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function follows a single unconditional execution path: build the JNI argument list, invoke the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly one input argument (the property key) must be supplied; the JNI argument list is always created with a capacity of 1.
- BR-002 - The property lookup is performed against the live Java runtime environment (java.lang.System.getProperty), meaning the returned value reflects the JVM state at the moment of invocation.
- BR-003 - The function returns a VARCHAR2 value; if the requested property does not exist in the Java runtime, the JNI layer returns NULL and the function propagates that NULL to the caller.
- BR-004 - No database interaction occurs; all processing is handled entirely through the JNI bridge to the Java Virtual Machine.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-031 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited field from a source string by position. Given a delimiter-separated string, a target field position, a delimiter character, and an optional flag indicating whether the string lacks a trailing delimiter, the function returns the substring occupying that positional field. It is used internally by WEBUTIL.GETNUMBER to isolate a specific token from a delimited value list.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position to extract, the UnTerminated flag (defaulting to FALSE), and the delimiter character (defaulting to comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If the UnTerminated flag is TRUE, append the delimiter to the end of the working copy so that the last field is bounded on both sides and can be located consistently.
- Step 4 - Determine the start pointer (iPtrStart): if Field_Position is greater than 1, locate the delimiter occurrence at position Field_Position-1 within the working string and advance the pointer past the delimiter to the first character of the target field; otherwise set iPtrStart to 1 (the string start).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the delimiter occurrence at exactly Field_Position within the working string.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which is the content of the requested field excluding its surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated IN parameter is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any positional search is performed, ensuring the final field in an unterminated string is bounded and can be extracted correctly.

FALSE: The source string is used as-is; no delimiter is appended.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: iPtrStart is calculated by finding the (Field_Position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, placing the pointer at the first character of the target field.

FALSE: iPtrStart is set to 1, meaning extraction begins at the very start of the string (first field).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The source string must use a consistent, known delimiter; the delimiter parameter defaults to a comma if not supplied by the caller.
- BR-002 - Field positions are 1-based; a Field_Position of 1 always refers to the content before the first delimiter occurrence.
- BR-003 - If the source string does not end with the delimiter (i.e., the last field is unterminated), the caller must pass UnTerminated = TRUE so that the function appends the delimiter and correctly bounds the final field during extraction.
- BR-004 - The function returns only the field content, excluding the surrounding delimiter characters.
- BR-005 - The working string is limited to 32,000 characters (varchar2(32000)); source strings exceeding this length are not supported.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-032 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR resolves the value of a named configuration variable on the client machine by querying the appropriate platform-specific source. On Windows clients it first attempts to read the variable from the Oracle registry key (HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE) and falls back to the Windows environment string if the registry yields no result. On Unix/Linux clients it executes the 'env' command via a blocking host process, captures standard output, and parses the key=value pairs to locate the requested variable. Mac OS and unknown client platforms are explicitly excluded from resolution, returning no value. The procedure is invoked during bean registration (WEBUTIL.REGISTERBEAN) to supply runtime environment configuration values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-060](#SP-060--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-061](#SP-061--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-010](#SP-010--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-022](#SP-022--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-034](#SP-034--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-048](#SP-048--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and an IN OUT placeholder (VARVALUE) as input.
- Step 2 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 3 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY, passing VARNAME and a case-insensitive lookup flag.
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value from the Windows environment using GET_ENVIRONMENT_STRING with VARNAME.
- Step 5 - If the client is Mac OS (CLIENT_PLATFORM_MAC) or an unrecognised platform (CLIENT_PLATFORM_UNKNOWN), take no action; VARVALUE remains unchanged.
- Step 6 - If the client is any other platform (Unix/Linux), execute the shell command 'env' synchronously via WEBUTIL.BLOCKING, capturing a process handle.
- Step 7 - Retrieve the complete standard output of the 'env' command as an array of lines using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 8 - Release the host process handle using WEBUTIL.RELEASE_PROCESS.
- Step 9 - Iterate over each output line; for each line locate the first '=' character using INSTR. If found, extract the key (substring before '=') and compare it to VARNAME.
- Step 10 - On a matching key, extract the value (substring after '='), assign it to VARVALUE, and exit the loop immediately.
- Step 11 - If a NO_DATA_FOUND exception is raised at any point during processing, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001
Condition: Client OS family equals CLIENT_PLATFORM_WIN32.
TRUE: Attempt registry lookup under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE for VARNAME; if result is NULL or empty, fall back to environment string lookup via GET_ENVIRONMENT_STRING.
FALSE: Proceed to DP-002.

DP-002
Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.
TRUE: No action is taken; VARVALUE is not populated.
FALSE: Treat the client as a Unix/Linux platform and proceed with the host 'env' command approach (DP-003 onwards).

DP-003
Condition: Registry value returned by READ_REGISTRY is NULL or empty string (Windows path only).
TRUE: Call GET_ENVIRONMENT_STRING to attempt resolution via the Windows environment variables.
FALSE: Use the registry value already retrieved as VARVALUE.

DP-004
Condition: A '=' character is found (INSTR > 0) in the current Unix 'env' output line.
TRUE: Extract the key portion and compare it to VARNAME (DP-005).
FALSE: Skip the current line and continue iterating.

DP-005
Condition: The extracted key from the Unix 'env' output line equals VARNAME.
TRUE: Assign the value portion (substring after '=') to VARVALUE and exit the loop.
FALSE: Continue iterating to the next output line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE is always the primary source for variable resolution; the Windows environment is only consulted as a fallback when the registry returns no value.
- BR-002 - On Mac OS and unrecognised client platforms, variable resolution is not attempted; VARVALUE is returned without modification.
- BR-003 - On Unix/Linux clients, variable resolution is performed exclusively by executing the 'env' shell command and parsing its output; no registry or direct environment API is used.
- BR-004 - The Unix output parsing uses the first '=' character as the delimiter; only lines containing '=' are evaluated, and the loop exits immediately upon the first matching key to prevent duplicate processing.
- BR-005 - If a NO_DATA_FOUND exception occurs during any resolution path, VARVALUE is set to NULL, ensuring the caller always receives a defined output value rather than an unhandled exception.
- BR-006 - The host process opened for Unix variable resolution must be released via WEBUTIL.RELEASE_PROCESS before the output is parsed, ensuring no process handle leak regardless of whether a match is found.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-033 - WEBUTIL.GET_LINE

**Invoked From:**

- sr_exch_tradein_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side file handle and returns it to the caller. The procedure delegates the physical read operation to the WebUtil Java bean layer via WebUtil_Core property calls, then surfaces the retrieved text through an OUT parameter. It is invoked as part of the VIEW_EXCEL_REP stored procedure in sr_exch_tradein_fmb.xml to process file content line by line.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle (file.handle) supplied by the caller through the file_type IN parameter.
- Step 2 - Pass the file handle to the WebUtil Java bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the next line of text from the client file by reading the WUF_TEXTIO_GETLINE property from the WUF_PACKAGE component via WebUtil_Core.getProperty; the result is stored in a local VARCHAR2 buffer.
- Step 4 - Evaluate the buffer content: if the buffer equals CHR(10) (a lone newline), this signals that the end of the file has been reached (a convention used by the PJC exception handler because a normal line read never returns a bare newline).
- Step 5 - If end-of-file is detected, raise NO_DATA_FOUND to signal the caller that no further lines are available.
- Step 6 - If the buffer contains normal line content, assign it to the OUT parameter item and return.
- Step 7 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), surface a descriptive error message identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 8 - If a property read/write error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The value returned in the buffer from WebUtil_Core.getProperty equals CHR(10) (a lone newline character).

TRUE:
The end of the file has been reached; NO_DATA_FOUND is raised to signal the caller that no more lines exist.

FALSE:
The buffer contains a valid line of text; it is assigned to the OUT parameter item and the procedure returns normally.

---

DP-002

Condition:
The BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty calls, indicating the required WebUtil Java bean is not available on the client.

TRUE:
An error alert is issued identifying the missing bean class (obtained via WebUtil_Core.getImplClass), and TOOL_ERR.TOOL_ERROR is raised to abort processing.

FALSE:
Processing continues normally; the bean is available and the line read proceeds.

---

DP-003

Condition:
The PROPERTY_ERROR exception is raised during the setProperty or getProperty calls.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to abort processing.

FALSE:
Processing continues normally; no property error occurred.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A lone newline character (CHR(10)) in the read buffer is reserved as the end-of-file sentinel; the procedure must never treat it as valid line content and must instead raise NO_DATA_FOUND.
- BR-002 - The file handle embedded in the file_type parameter must be set on the WUF_PACKAGE component before any line read is attempted; the handle must be passed via WebUtil_Core.setProperty using the WUF_TEXTIO_HANDLE property key.
- BR-003 - Line retrieval is performed exclusively through the WebUtil Java bean layer (WebUtil_Core.getProperty with WUF_TEXTIO_GETLINE); direct client file I/O outside this mechanism is not permitted.
- BR-004 - If the required WebUtil bean is not registered on the client, the procedure must surface a descriptive diagnostic message identifying the missing bean class before raising a fatal error, ensuring the failure is traceable.
- BR-005 - Any PROPERTY_ERROR encountered during the bean interaction must result in an immediate fatal error (TOOL_ERR.TOOL_ERROR); partial or silent failure is not permitted.
- BR-006 - The maximum line length that can be returned is 4000 characters, as constrained by the internal VARCHAR2(4000 char) buffer; lines exceeding this length will be truncated by the underlying platform.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-034 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output stream captured from a previously executed host process. Given a process identifier, the function delegates to WEBUTIL.GETOUTPUT to extract all output lines associated with the 'WUH_STDOUT' channel and returns them as an array for further processing by the calling routine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-029](#SP-029--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (PROCESS_ID) that references a previously executed host process.
- Step 2 - Invoke WEBUTIL.GETOUTPUT, passing the supplied process identifier and the fixed output-channel key 'WUH_STDOUT', to retrieve all standard output lines captured for that process.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No conditional decision points are present in this function. The function unconditionally delegates to WEBUTIL.GETOUTPUT with the fixed channel key 'WUH_STDOUT' and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output channel key used to retrieve standard output is always 'WUH_STDOUT'; this value is hard-coded and cannot be overridden by the caller.
- BR-002 - The function does not perform any independent data retrieval or transformation; the completeness and accuracy of the returned OUTPUT_ARRAY are entirely determined by WEBUTIL.GETOUTPUT (SP-029).
- BR-003 - A valid PROCESS_ID must be supplied by the caller; the function passes it unmodified to WEBUTIL.GETOUTPUT without performing any prior validation.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-035 - WEBUTIL.ID_NULL

**Invoked From:**

- sr_exch_tradein_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle reference is uninitialised (null). Callers use this utility function to guard against operating on an invalid or unallocated pointer before invoking further WebUtil operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming handle parameter (of type Pointer) passed by the calling routine.
- Step 2 - Inspect the internal field `hnd` of the Pointer record to determine whether it holds a null value.
- Step 3 - Return TRUE to the caller if `hnd` is null, indicating the handle is uninitialised.
- Step 4 - Return FALSE to the caller if `hnd` is not null, indicating the handle references a valid, allocated object.

---
**Decision Points**

DP-001

Condition:
The `hnd` field of the supplied `handle` Pointer record IS NULL.

TRUE:
The function returns TRUE, signalling to the caller that the handle is null and no valid object is referenced.

FALSE:
The function returns FALSE, signalling to the caller that the handle is populated and safe to use in subsequent operations.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal `hnd` field being null; no other attribute of the Pointer record is evaluated.
- BR-002 - The function is read-only and stateless: it performs no database interactions, raises no exceptions, and does not modify any state, ensuring it is safe to call at any point in processing.
- BR-003 - All callers (WEBUTIL.ERRORALERT, WEBUTIL.INITWEBUTIL, WEBUTIL.REGISTER_FUNCTION, WEBUTIL.SHOWBEANS, and VIEW_EXCEL_REP) must treat a TRUE return value as an indicator that the handle must be initialised before further WebUtil operations are attempted.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-036 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core library. When the WEBUTIL package is loaded into memory, its package initialisation block automatically calls INITWEBUTIL (SP-037) to set up the WebUtil environment. The INIT procedure itself performs no additional processing; entering the package is sufficient to trigger the required initialisation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-037](#SP-037--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.INIT is invoked by WEBUTIL.GETOUTPUT as part of the WebUtil package lifecycle.
- Step 2 - The procedure body executes a NULL statement, confirming that no explicit procedural logic is required within INIT itself.
- Step 3 - The package initialisation block (BEGIN...END WEBUTIL_CORE) executes automatically upon first reference to the package, calling INITWEBUTIL (SP-037) to perform the actual WebUtil environment setup.

---
**Decision Points**

No decision points exist within this procedure. The procedure body contains only a NULL statement, and the package initialisation block unconditionally calls INITWEBUTIL with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The INIT procedure must contain no active logic; entering the package is the sole mechanism required to trigger WebUtil initialisation.
- BR-002 - WebUtil environment setup is delegated entirely to INITWEBUTIL (SP-037), which is called unconditionally from the package initialisation block, ensuring the utility is always initialised before any package member is used.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-037 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the mandatory WebUtil object group (including its error alert and dummy item) is present in the form, optionally navigating to the WebUtil bean area to force bean instantiation, and detecting the server operating system to set the correct file-path separator for subsequent file operations.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-052](#SP-052--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) at procedure entry so that navigation can be safely restored later.
- Step 2 - Populate the package-to-implementation-class registry (m_implClasses) with the fully qualified Java bean class names for all known WebUtil packages: WUC (VBeanCommon), WUT (FileTransfer), WUF (FileFunctions), WUI (GetClientInfo), WUH (Host), WUS (SessionFunctions), WUB (BrowserFunctions), WUO (OleFunctions), WUU (empty/no class), and WUL (CApiFunctions).
- Step 3 - Check whether the WebUtil error alert object (m_errorAlert) is null using WEBUTIL.ID_NULL. If it is null, display an error message stating that the WEBUTIL object group is not available and pause execution; WebUtil cannot proceed.
- Step 4 - If the error alert is present, evaluate whether explicit instantiation is enabled (FLAG_EXPICIT_INSTANCIATE) and the form is in NORMAL mode (SYSTEM.MODE = 'NORMAL') before attempting bean navigation.
- Step 5 - Within the explicit-instantiation branch, check whether the WebUtil dummy item (hDummy) exists using WEBUTIL.ID_NULL. If it does not exist, take no action, assuming the developer is managing bean setup independently.
- Step 6 - If the dummy item exists, navigate to it via GO_ITEM to trigger bean area rendering.
- Step 7 - Compare the block of the original cursor position with the block of the dummy item. If they are the same block, move to the next block (NEXT_BLOCK) to leave the bean block; otherwise navigate back to the original cursor item (GO_ITEM(startPoint)).
- Step 8 - Call WEBUTIL.SHOWBEANS(false) to complete bean area initialisation after navigation.
- Step 9 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) is TRUE (the WebUtil error alert object is not present in the form).

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', pause execution, and exit without performing any further initialisation.

FALSE: Proceed with bean instantiation and server OS detection steps.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE = 'NORMAL'.

TRUE: Attempt navigation to the WebUtil dummy item to force bean instantiation.

FALSE: Skip the bean navigation block entirely; m_implClasses registration and server OS detection still occur.

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) is FALSE (the WebUtil dummy item exists in the form).

TRUE: Navigate to the dummy item, perform block comparison, restore cursor position, and call WEBUTIL.SHOWBEANS(false).

FALSE: Take no action; the developer is assumed to be managing bean area setup independently.

---

DP-004

Condition: The block containing the original cursor item is the same block as the block containing the dummy item (GET_ITEM_PROPERTY(startPoint, BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy, BLOCK_NAME)).

TRUE: Execute NEXT_BLOCK to move focus out of the bean block.

FALSE: Execute GO_ITEM(startPoint) to return focus to the original cursor position.

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server OS name contains 'WIN').

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward-slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil object group, including its error alert (m_errorAlert), must be present in the host form before WebUtil can initialise. If the error alert is absent, initialisation is halted immediately with a user-facing message.
- BR-002 - Implementation class mappings for all ten WebUtil packages must be registered in the m_implClasses registry during every initialisation call; no package may be omitted from this registration step.
- BR-003 - Bean area navigation to force explicit instantiation is only permitted when the form is in NORMAL mode. Enter-Query mode must not trigger bean navigation, as this causes known defects (reference: Bug 2955789).
- BR-004 - Explicit bean instantiation via navigation is conditional on the FLAG_EXPICIT_INSTANCIATE flag, providing a mechanism to enable or disable this behaviour without code changes.
- BR-005 - After navigating to the dummy item block, the procedure must restore the user's original cursor position: if the cursor was already in the dummy item's block, focus moves to the next block; otherwise focus returns to the exact originating item.
- BR-006 - WEBUTIL.SHOWBEANS must be called with the parameter false immediately after dummy-item navigation to complete bean area rendering.
- BR-007 - The server file-path separator (m_serverFileSep) must be determined at initialisation time based on the server OS and stored for use by subsequent file-handling operations; Windows environments use '\' and all other environments use '/'.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-038 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal module-level variable m_lastError and returns TRUE if a non-zero error code is present, allowing callers such as WEBUTIL.LOG to determine whether an error condition exists before proceeding.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the value of the module-level variable m_lastError, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare m_lastError against zero to determine whether an error was recorded.
- Step 3 - Return TRUE if m_lastError is not equal to zero (an error exists), or FALSE if m_lastError equals zero (no error).

---
**Decision Points**

DP-001

Condition: m_lastError <> 0

TRUE: The function returns TRUE, indicating that the last WebUtil operation produced an error code.

FALSE: The function returns FALSE, indicating that no error was recorded by the last WebUtil operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-zero value in m_lastError is the sole criterion for classifying the last WebUtil operation as an error; any non-zero code, regardless of its specific value, is treated as an error condition.
- BR-002 - The function is read-only with respect to m_lastError; it reports the error state but does not reset or modify it.
- BR-003 - The function accepts no input parameters; the error state is derived entirely from the internal module-level variable m_lastError.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-039 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to verify file state before attempting file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as the input parameter.
- Step 2 - Evaluate the handle attribute of the FILE_TYPE record to determine whether it holds a value.
- Step 3 - If the handle attribute is NULL, return FALSE to indicate that the file is not open.
- Step 4 - If the handle attribute is not NULL, return TRUE to indicate that the file is open.

---
**Decision Points**

DP-001

Condition: The handle attribute of the FILE_TYPE input record is NULL.

TRUE: The function returns FALSE, signalling to the caller that no open file handle exists for the given file.

FALSE: The function returns TRUE, signalling to the caller that a valid open file handle exists for the given file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its handle attribute is non-NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs a state check only and does not modify the FILE_TYPE record or any other resource; it is a pure read-only inspection.
- BR-003 - The function accepts exactly one input parameter of type FILE_TYPE and returns a BOOLEAN result; no output parameters or database interactions are involved.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-040 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL routines with a means to determine file size without direct database or filesystem PL/SQL calls.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) passed in by the calling routine (e.g., DEBUGLOG, REGISTER_FUNCTION_CALL, STRIPDIRSEP, or WEBUTIL.GETSTRING).
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale parameters are forwarded to the Java method.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the target object, the class path 'java/io/File', the method name 'length', and the method signature '()J' (no arguments, returns a long).
- Step 4 - Return the numeric result (file size in bytes) to the calling routine as a PL/SQL NUMBER.

---
**Decision Points**

No conditional decision points exist in the implementation logic. The function executes a single deterministic JNI call and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_JAVA.JOBJECT reference representing a java.io.File instance; the JNI call targets the class path 'java/io/File' and will fail if the object is of an incompatible Java type.
- BR-002 - The JNI argument list (args) must be explicitly reset to NULL before the method call to prevent parameter contamination from prior JNI invocations within the same session context.
- BR-003 - The return value represents the file size in bytes as reported by the underlying Java runtime; a return value of 0 may indicate either an empty file or a file that does not exist, consistent with the behaviour of java.io.File.length().
- BR-004 - The function is non-static (FALSE flag passed to JNI.CALL_LONG_METHOD), meaning a valid object instance must be supplied; a NULL object reference will result in a JNI-level error.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-041 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side text file on behalf of the WebUtil framework. On first invocation it reads logging configuration from a property bundle (enabled flag, errors-only flag, and target file path), caches those settings for the session, and propagates the resolved logging mode to any registered WebUtil bean. On subsequent calls it appends the supplied message-optionally prefixed with the client IP address and username-to the configured log file, subject to the active logging mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-038](#SP-038--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-039](#SP-039--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip directly to Step 8.
- Step 2 - Read the three logging configuration keys from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE: 'logging.enabled' (sets m_loggingAllowed), 'logging.errorsonly' (sets m_loggingErrorsOnly), and 'logging.file' (sets m_loggingFile).
- Step 3 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE) and raise a configuration error. If no WebUtil bean is registered yet, surface the error as an alert via WEBUTIL.ERRORALERT (message WUC-008); otherwise disable server-side logging on the bean (WUC_SRV_LOGGING = '0') and raise the error through the WebUtil_Core framework.
- Step 4 - If at least one bean is registered, synchronise the resolved logging mode to the bean property WUC_SRV_LOGGING: set '1' for errors-only mode, '2' for full logging, or '0' if logging is disabled.
- Step 5 - Evaluate whether the current message should be written: logging must be allowed (m_loggingAllowed = TRUE) and either errors-only mode is off, or errors-only mode is on and the isError parameter is TRUE.
- Step 6 - Open the log file in append mode (TEXT_IO.FOPEN with mode 'A'). If the file cannot be opened, raise NO_DATA_FOUND.
- Step 7 - Write the message to the log file. If m_clientIP is populated, prefix the message with the client IP address and username (format: '<IP>:<username>: <msg>'); otherwise write the message as supplied.
- Step 8 - Close the log file (TEXT_IO.FCLOSE).
- Step 9 - On exception: if SQLCODE is -302000 (file write failure), disable logging (m_loggingAllowed := FALSE) and report error WUC-007 either via WEBUTIL.ERRORALERT (no bean registered) or via the WebUtil_Core error mechanism with WUC_SRV_LOGGING reset to '0'. Any other exception is re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging configuration cache not yet initialised).
TRUE: Read configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the session-level cache variables before evaluating whether to write.
FALSE: Skip initialisation; proceed directly to the write-eligibility check using the already-cached values.

DP-002
Condition: Logging is enabled (m_loggingAllowed = TRUE) AND m_loggingFile IS NULL.
TRUE: Set m_loggingAllowed to FALSE. If no bean is registered, call WEBUTIL.ERRORALERT with WUC-008; otherwise reset WUC_SRV_LOGGING to '0' on the bean and raise the error via WebUtil_Core.
FALSE: Retain the current m_loggingAllowed value and continue.

DP-003
Condition: At least one WebUtil bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the end of the initialisation block.
TRUE: Synchronise the resolved logging mode to the bean property WUC_SRV_LOGGING ('0', '1', or '2').
FALSE: Skip bean property synchronisation.

DP-004
Condition: m_loggingAllowed = TRUE AND (m_loggingErrorsOnly = FALSE OR (m_loggingErrorsOnly = TRUE AND isError = TRUE)).
TRUE: Open the log file and write the message.
FALSE: Take no action; the message is silently suppressed.

DP-005
Condition: TEXT_IO.IS_OPEN(logFile) returns FALSE after the FOPEN call.
TRUE: Raise NO_DATA_FOUND, triggering the exception handler.
FALSE: Proceed to write the message.

DP-006
Condition: m_clientIP IS NULL at write time.
TRUE: Write the raw message text to the log file without any prefix.
FALSE: Prefix the message with the client IP address and username before writing.

DP-007
Condition: Exception handler - SQLCODE = -302000 (file write error).
TRUE: Set m_loggingAllowed to FALSE. If no bean is registered, call WEBUTIL.ERRORALERT with WUC-007; otherwise reset WUC_SRV_LOGGING to '0' and raise the error via WebUtil_Core.
FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in session-level variables; subsequent calls reuse the cached values without re-reading the bundle.
- BR-002 - If logging is enabled but no log file path is configured, logging is unconditionally disabled for the remainder of the session; this condition is treated as a reportable error (WUC-008).
- BR-003 - When errors-only mode is active, only messages passed with isError = TRUE are written to the log file; informational messages are silently discarded.
- BR-004 - The log file is always opened in append mode, preserving existing log content across multiple invocations.
- BR-005 - If a client IP address is available (m_clientIP IS NOT NULL), every log entry is prefixed with the client IP and username to support audit traceability.
- BR-006 - Error reporting follows a two-path rule: if no WebUtil bean is registered at the time of the error, the error is surfaced to the user via WEBUTIL.ERRORALERT in plain English; if a bean is registered, the error is communicated through the WebUtil_Core framework and the bean property WUC_SRV_LOGGING is reset to '0'.
- BR-007 - A file-write failure (SQLCODE -302000) permanently disables logging for the session (m_loggingAllowed := FALSE) to prevent repeated failed write attempts; all other exceptions are re-raised without suppression.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-042 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter. It is invoked by WEBUTIL.READFROMPROPERTYBUNDLE to supply configuration values at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-017](#SP-017--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global variable is unset, attempt to retrieve the configuration file path from the operating environment using TOOL_ENV.GETVAR with the key WEBUTIL_CONFIG_ENV.
- Step 3 - If the environment variable also yields no value, fall back to reading the path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM.
- Step 4 - If all three sources fail to supply a path, raise NO_DATA_FOUND to trigger error handling.
- Step 5 - Persist the resolved configuration file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL so that subsequent calls do not need to re-resolve it.
- Step 6 - Open the configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' character.
- Step 10 - For valid key-value lines, increment the property index, store the trimmed, lower-cased key and the trimmed, carriage-return-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key against the lower-cased input propertyKey; if they match, capture the corresponding value into the result variable.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE.
- Step 13 - Return the result value (NULL if the key was not found in the file).
- Step 14 - On NO_DATA_FOUND exception (no configuration file path resolved): if no bean package is registered yet, call WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error; set m_config_error to TRUE and return NULL.
- Step 15 - On SQLCODE -302000 (file unreadable): if no bean package is registered yet, call WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error; set m_config_error to TRUE and return NULL.
- Step 16 - For all other exceptions, re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.

TRUE: Clear the local configFile variable and proceed to resolve the path from the environment variable (WEBUTIL_CONFIG_ENV).

FALSE: Use the value held in WEBUTIL_CONFIG_GLOBAL as the configuration file path; skip environment and parameter lookups.

---

DP-002

Condition: TOOL_ENV.GETVAR returns a non-null value for WEBUTIL_CONFIG_ENV.

TRUE: Use the returned value as the configuration file path; skip the Forms parameter lookup.

FALSE: Attempt to resolve the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition: The Forms parameter WEBUTIL_CONFIG_PARAM yields a non-null value.

TRUE: Use the parameter value as the configuration file path.

FALSE: Raise NO_DATA_FOUND; no configuration file path is available.

---

DP-004

Condition: The first character of the current line read from the file is '#'.

TRUE: Skip the line entirely; it is a comment.

FALSE: Proceed to check the line for a key-value pair delimiter.

---

DP-005

Condition: The '=' delimiter is found at a position greater than zero within the current line.

TRUE: Parse the line into a key and value, store them in m_propertyBundle, and check whether the key matches propertyKey.

FALSE: Skip the line; it does not represent a valid key-value pair.

---

DP-006

Condition: The lower-cased stored key equals the lower-cased input propertyKey.

TRUE: Assign the corresponding property value to the result variable.

FALSE: Continue iterating without updating the result variable.

---

DP-007

Condition: A NO_DATA_FOUND or SQLCODE -302000 exception is raised, and m_registeredPackages.FIRST is NULL (no bean package registered).

TRUE: Call WEBUTIL.ERRORALERT to display the appropriate WUC error message in English.

FALSE: Delegate error reporting to Webutil_Core.Error.

---

DP-008

Condition: An exception other than NO_DATA_FOUND and SQLCODE -302000 is raised.

TRUE: Re-raise the exception to the caller.

FALSE: Not applicable (condition is only evaluated in the OTHERS handler).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none supplies a value, processing cannot continue.
- BR-002 - Once the configuration file path is successfully resolved from any source, it must be written back to WEBUTIL_CONFIG_GLOBAL to cache it for subsequent invocations within the same session.
- BR-003 - Lines beginning with the '#' character are treated as comments and must be excluded from property parsing.
- BR-004 - Only lines containing an '=' character are treated as valid key-value pairs; lines without '=' are silently ignored.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed, ensuring case-insensitive and whitespace-tolerant key matching.
- BR-006 - Property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped, ensuring clean values regardless of file line-ending format.
- BR-007 - All valid key-value pairs encountered in the file are loaded into m_propertyBundle regardless of whether they match the requested key, populating the full bundle in a single file read.
- BR-008 - When the configuration file cannot be located (WUC-005) or cannot be read (WUC-006), the m_config_error flag must be set to TRUE and the function must return NULL rather than propagating the error.
- BR-009 - Error messages for WUC-005 and WUC-006 must be presented via WEBUTIL.ERRORALERT only when no bean package has been registered; if a bean is registered, error reporting is delegated to Webutil_Core.Error.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-043 - WEBUTIL.PUT_LINE

**Invoked From:**

- sr_exch_tradein_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the text content and a newline instruction to the WebUtil client bean. The procedure is used within the trade-in exchange report generation flow (VIEW_EXCEL_REP) to append a line of data to a file handle that was previously opened on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WebUtil client bean (WUF_PACKAGE) to identify the file that will receive the output.
- Step 3 - Set the WUF_TEXTIO_PUT property to the supplied text item, instructing the bean to buffer the text for writing.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property to 1, instructing the bean to append a newline character after the text, completing the line write operation.
- Step 5 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If any property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The WebUtil client bean for WUF_PACKAGE is not registered on the client at the time any setProperty call is made (WebUtil_Core.BEAN_NOT_REGISTERED exception raised).

TRUE:
An error alert is displayed identifying the missing bean class and noting that CLIENT_TEXT_IO.put_line will not work; TOOL_ERR.TOOL_ERROR is then raised to abort the calling process.

FALSE:
Processing continues normally through the remaining setProperty calls.

---

DP-002

Condition:
A property-set operation against the WebUtil client bean fails (WebUtil_Core.PROPERTY_ERROR exception raised).

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to abort the calling process; no further property-set calls are attempted.

FALSE:
All three property assignments complete successfully and the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil client bean (WUF_PACKAGE) must be registered and available on the client before this procedure is called; absence of the bean is treated as a fatal error.
- BR-002 - A newline character must always be appended after the written text item (WUF_TEXTIO_NEWLINE is unconditionally set to 1); partial-line writes are not supported by this procedure.
- BR-003 - Any bean registration or property-set failure must propagate as TOOL_ERR.TOOL_ERROR, ensuring the parent process (VIEW_EXCEL_REP) is notified of the failure rather than silently continuing with incomplete file output.
- BR-004 - The file handle passed in the file parameter must correspond to a file that has already been opened by the caller; this procedure does not open or validate the file itself.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-044 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle. If the bundle has not yet been loaded, it delegates initialisation to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. The function is used by WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN to resolve configuration properties at runtime without repeated file reads.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-042](#SP-042--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries held in the package-level collection m_propertyBundle.
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, return NULL immediately and take no further action.
- Step 3 - If no configuration error exists but the property bundle collection is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested propertyKey, and assign its return value directly as the result.
- Step 4 - If the collection is already populated, iterate through all entries in m_propertyBundle, comparing each entry's propertyKey (stored in lower-case) against the lower-case equivalent of the supplied input key.
- Step 5 - On the first matching entry, capture the corresponding propertyValue as the result and exit the loop immediately.
- Step 6 - Return the resolved property value to the caller; if no matching key was found during iteration, the result remains NULL and is returned as such.

---
**Decision Points**

DP-001

Condition: m_config_error is TRUE.

TRUE: The function returns NULL immediately, bypassing all lookup logic, because a prior configuration file error renders the bundle unreliable.

FALSE: Processing continues to evaluate the state of the property bundle collection.

---

DP-002

Condition: The property bundle collection (m_propertyBundle) contains zero entries (propCount = 0).

TRUE: WEBUTIL.POPULATEPROPERTYBUNDLE is called to load the bundle and return the value for the requested key in a single operation.

FALSE: The collection is already populated; the function iterates through existing entries to locate the matching key.

---

DP-003

Condition: During iteration, the current entry's propertyKey matches the lower-case form of the supplied input key.

TRUE: The entry's propertyValue is captured as the result and the loop exits immediately.

FALSE: The loop continues to the next entry; if the loop exhausts all entries without a match, the result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been recorded (m_config_error = TRUE), the function must return NULL without attempting any property lookup, preventing consumption of potentially corrupt or incomplete configuration data.
- BR-002 - Property key comparisons are performed in lower-case; the supplied input key is normalised to lower-case before being matched against stored keys, ensuring case-insensitive resolution.
- BR-003 - When the property bundle collection is empty, the function must delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to initialise the bundle; the function must not attempt direct iteration over an empty collection.
- BR-004 - Once a matching property key is found during iteration, the loop must exit immediately; only the first matching entry's value is returned, preventing duplicate-key ambiguity.
- BR-005 - The returned property value must not exceed 1000 characters, as enforced by the VARCHAR2(1000 char) result variable declaration.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-045 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by delegating to the WebUtil Core client-server property mechanism. The function accepts a message property key and an optional arguments string, passes them to the client-side bundle via a combined property value, and returns the resolved translation. It is currently used exclusively by WEBUTIL.CHECKLIBS to obtain the localised progress bar title.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional arguments string (args) as input.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a single composite value string.
- Step 3 - Write the composite value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read back the resolved (translated) message by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the translated message string to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic executes unconditionally: the composite key is always written to the property store and the resolved value is always read back and returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and optional arguments must be combined using a pipe character ('|') as the delimiter before being submitted to the WebUtil Core property store; this delimiter convention is required for the message bundle to correctly parse the key and its arguments.
- BR-002 - The args parameter is optional (defaults to NULL); when NULL is passed, the composite value submitted to the property store will be in the form 'propertyKey|', with no argument text following the delimiter.
- BR-003 - Translation resolution is performed entirely through the Webutil_Core.setProperty / Webutil_Core.getProperty round-trip using the WUC_PACKAGE and WUC_TRANS_MSG identifiers; no direct database lookup or additional internal routine is involved.
- BR-004 - The function is currently authorised for use only by WEBUTIL.CHECKLIBS (specifically for retrieving the progress bar title); any future callers must be reviewed for compatibility with the pipe-delimited key-argument convention.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-046 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms server session during form initialisation. For each bean that connects for the first time, the procedure maps the bean's short name to an internal package identifier, captures client environment details (IP address, OS, architecture, username, locale, path and file separators), resolves the system-library download directory, configures heartbeat blocking, communicates server-side logging options back to the bean, and triggers library availability checks. The procedure ensures each distinct bean package is registered only once per session, even if the underlying item appears in a multi-row block.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-011](#SP-011--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-023](#SP-023--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-028](#SP-028--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-030](#SP-030--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-032](#SP-032--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-049](#SP-049--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the first pipe-delimited token of the clientInfo string.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant.
- Step 3 - Check whether the client IP address has already been captured (m_clientIP IS NULL). If this is the first bean to register in the session, set the checkUserLibs flag to TRUE and parse the remaining clientInfo tokens to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), m_clientOSArch (set to 1 when the architecture token contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 4 - Check whether this package ID already exists in the m_registeredPackages array. If it does not, record the triggering item (SYSTEM.TRIGGER_ITEM) against the package ID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - If checkUserLibs is TRUE, resolve the system-library client directory: (a) reset REDOWNLOAD_SYSLIB to FALSE; (b) retrieve the server host name via WEBUTIL.GETVAR using the 'COMPUTERNAME' variable, falling back to 'HOST' if null; (c) read the client library path from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE, first attempting an OS-family-plus-architecture key, then an OS-family-only key.
- Step 6 - Apply the resolved library directory: if no directory was found in the property bundle, send a WUC_SYSLIB_DIR property containing only the server host and application config to the WUC bean via WebUtil_Core.setProperty; if a directory was found, substitute the '$(SERVERHOST)' placeholder with the actual server host name, send the full WUC_SYSLIB_DIR property, compare the new directory against the previously stored value retrieved via WEBUTIL.GETCLIENTSETTING, and if they differ, persist the new value via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 7 - Retrieve and store the WebUtil bean version from the WUC_BEAN_VERSION property via WEBUTIL.GETPROPERTY.
- Step 8 - If the 'logging.connections' property bundle entry evaluates to 'true', write a connection log entry via WEBUTIL.LOG recording the current form name, client OS, and locale.
- Step 9 - If newPackage is TRUE, invoke WEBUTIL.CHECKLIBS with the string representation of the package ID to verify that all required libraries for the newly registered bean are available on the client.
- Step 10 - If checkUserLibs is TRUE, invoke WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 11 - Read the 'BlockAllowHeartBeat' property bundle entry and send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the bean if the value is 'true', 'yes', or '1'; otherwise send '0'.
- Step 12 - Evaluate the logging flags and send the WUC_SRV_LOGGING property to the bean: '1' when logging is allowed but errors-only, '2' when full logging is allowed, or '0' when logging is disabled.
- Step 13 - If checkUserLibs is TRUE, invoke WEBUTIL.CHECKLIBS with the literal string 'user' to check for and initiate download of any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the recognised values (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: No packageID is assigned; subsequent logic that references packageID will operate with an uninitialised value.

DP-002
Condition: m_clientIP IS NULL (i.e. this is the first bean to register in the current session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; checkUserLibs remains FALSE and parsing is skipped.

DP-003
Condition: The architecture token extracted from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1, indicating a 64-bit client.
FALSE: m_clientOSArch remains at its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The package is recorded in m_registeredPackages and newPackage is set to TRUE.
FALSE: The package was already registered; newPackage remains FALSE and no duplicate entry is created.

DP-005
Condition: The COMPUTERNAME environment variable (retrieved via WEBUTIL.GETVAR) is null.
TRUE: A second attempt is made using the HOST environment variable to obtain the server host name.
FALSE: The COMPUTERNAME value is used as the server host name.

DP-006
Condition: The OS-family-plus-architecture key ('install.syslib.location.client.{osfamily}.{osarch}') returns a non-null value from WEBUTIL.READFROMPROPERTYBUNDLE.
TRUE: clientLibDir is set to that value.
FALSE: A fallback lookup is attempted using the OS-family-only key ('install.syslib.location.client.{osfamily}').

DP-007
Condition: clientLibDir is null after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the WUC bean containing only the server host and application config; the client JRE handles the directory.
FALSE: The specific client directory is used; the '$(SERVERHOST)' placeholder is replaced and WUC_SYSLIB_DIR is sent with the full path.

DP-008
Condition: The previously stored client library directory (retrieved via WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: The new directory is persisted via WEBUTIL.SETCLIENTSETTING and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The directory is unchanged; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: The 'logging.connections' property bundle entry (lowercased) equals 'true'.
TRUE: A connection log entry is written via WEBUTIL.LOG with form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the package ID string to validate client-side library availability for the newly registered bean.
FALSE: Library check for this package is skipped.

DP-011
Condition: blockAllowHeartBeat (lowercased) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is sent to the bean as '1', instructing the client to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '0'.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is sent as '1' (errors-only logging).
FALSE: Proceed to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is sent as '2' (full logging).
FALSE: WUC_SRV_LOGGING is sent as '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (evaluated for the second time, after library checks).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check and download any user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Client environment information (IP address, OS, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per session; subsequent bean registrations within the same session do not overwrite these values.
- BR-002 - Each distinct bean package type may be registered only once per form session. If the same bean type appears in a multi-row block or is otherwise instantiated multiple times, only the first instance is recorded.
- BR-003 - Bean short names must be one of the ten recognised values (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL); each maps to a fixed WEBUTIL_CORE package-ID constant.
- BR-004 - A client OS architecture containing the string '64' is classified as 64-bit (m_clientOSArch = 1); all other values are treated as non-64-bit.
- BR-005 - The system-library client directory is resolved by first attempting the most specific property bundle key (OS family + architecture), then falling back to the OS-family-only key, and finally defaulting to the client JRE when neither key yields a value.
- BR-006 - When a specific client library directory is configured, the placeholder '$(SERVERHOST)' within that directory value must be replaced with the actual server host name before the value is transmitted to the client bean.
- BR-007 - If the resolved client library directory differs from the value previously stored on the client (via WEBUTIL.GETCLIENTSETTING), the new directory is persisted via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag is set to TRUE, triggering a re-download of system libraries.
- BR-008 - Connection logging is governed by the 'logging.connections' property bundle entry; the log entry is written only when this entry evaluates to 'true' (case-insensitive) and only during the first bean registration of the session.
- BR-009 - The BlockAllowHeartBeat configuration variable accepts 'true', 'yes', or '1' (case-insensitive) as affirmative values; any other value is treated as disabled.
- BR-010 - Server-side logging state (full, errors-only, or disabled) is communicated to each registered client bean via the WUC_SRV_LOGGING property so that the bean can suppress unnecessary round-trip log messages.
- BR-011 - User library availability checks (WEBUTIL.CHECKLIBS with 'user') are performed only once per session and only after at least one bean package has been registered, ensuring a handler bean exists to process any required downloads.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-047 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent use. The procedure communicates the library and function specification to the WebUtil core component, retrieves the resulting handle token, and tracks the total count of successfully registered function handles within the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName into a pipe-delimited specification string and pass it to the WebUtil core layer by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 3 - Retrieve the string-form handle token from the WebUtil core layer by reading the WUL_REGISTER_FUNCTION property on the WUL_PACKAGE component.
- Step 4 - Convert the retrieved string token to a numeric value and assign it to the hnd field of the local FunctionHandle variable (funcHnd).
- Step 5 - Evaluate whether the returned FunctionHandle is valid by calling WEBUTIL.ID_NULL; if the handle is not null (i.e., valid), increment the session-level function handle counter (m_funcHandleCount) by 1.
- Step 6 - Return the populated FunctionHandle to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised, display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a PROPERTY_ERROR exception is raised, raise FORM_TRIGGER_FAILURE to halt processing.
- Step 9 - If a VALUE_ERROR exception is raised (e.g., the string token cannot be converted to a number), raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: The FunctionHandle returned from the WebUtil core layer is evaluated using WEBUTIL.ID_NULL to determine whether it represents a valid (non-null) handle.

TRUE (handle is NOT null - i.e., ID_NULL returns FALSE): The session-level function handle counter (m_funcHandleCount) is incremented by 1, confirming a successful registration.

FALSE (handle IS null - i.e., ID_NULL returns TRUE): The counter is not incremented; the handle is returned as-is without recording a successful registration.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during WebUtil core property interaction, indicating the required WebUtil bean is not available.

TRUE: An error alert is displayed to the user identifying the missing bean class, and FORM_TRIGGER_FAILURE is raised to stop further form processing.

FALSE: Normal execution continues.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during WebUtil core property interaction.

TRUE: FORM_TRIGGER_FAILURE is raised immediately to stop further form processing; no alert is displayed.

FALSE: Normal execution continues.

---

DP-004

Condition: A VALUE_ERROR exception is raised when attempting to convert the retrieved string handle token to a number via TO_NUMBER.

TRUE: TOOL_ERR.TOOL_ERROR is raised to signal a data conversion failure to the calling environment.

FALSE: Normal execution continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil core layer must be formatted as a pipe-delimited string combining the library name and function name (libName || '|' || funcName); neither component may be supplied in any other format.
- BR-002 - A FunctionHandle is only counted as a successfully registered handle if WEBUTIL.ID_NULL confirms it is not null; null handles are returned but do not increment the session registration counter.
- BR-003 - The WebUtil bean corresponding to WUL_PACKAGE must be registered and available at the time of invocation; if it is not, the operation is aborted and the user is notified via an error alert before FORM_TRIGGER_FAILURE is raised.
- BR-004 - If the WebUtil core layer returns a handle token that cannot be converted to a numeric value, the procedure raises TOOL_ERR.TOOL_ERROR, preventing an invalid handle from being returned to the caller.
- BR-005 - Any PROPERTY_ERROR raised during core layer communication results in immediate termination via FORM_TRIGGER_FAILURE, with no partial result returned.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-048 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated WebUtil property and callback trigger, then nullifying the handle reference. This ensures that process resources managed by the WebUtil Host (WUH) package are properly deallocated after use, preventing stale handle references from persisting in the calling context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the WUH_CLEAR_PROC property on the WUH_PACKAGE bean, passing the current process handle value, signalling the WebUtil layer to release the associated server-side process resource.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the process handle to deregister any callback trigger that was registered against this process, ensuring no orphaned callbacks remain.
- Step 4 - Set process.handle to NULL, marking the PROCESS_ID as released and preventing the caller from reusing a stale reference.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during Steps 2 or 3, invoke WebUtil_Core.ErrorAlert to display a descriptive error message identifying the missing bean class and stating that WEBUTIL_HOST.Release_Process will not function, then allow the procedure to exit without further processing.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to set the WUH_CLEAR_PROC property or clear the callback trigger (i.e., the WUH_PACKAGE bean is not registered in the WebUtil runtime).

TRUE: WebUtil_Core.ErrorAlert is called with a message combining the implementation class name (retrieved via WebUtil_Core.getImplClass for WUH_PACKAGE) and a fixed notification that WEBUTIL_HOST.Release_Process will not work; the procedure exits via the exception handler without nullifying the handle.

FALSE: The property is cleared, the callback trigger is deregistered, and process.handle is set to NULL; the procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be passed as IN OUT; the procedure is responsible for nullifying it upon successful release, and the caller must not reuse the handle after this procedure returns.
- BR-002 - Release of a process requires both the WUH property clear (WUH_CLEAR_PROC) and the callback trigger deregistration to be performed together; neither action alone constitutes a complete release.
- BR-003 - If the WUH_PACKAGE bean is not registered in the WebUtil runtime, the release operation cannot proceed and an error alert must be raised to notify the user; no silent failure is permitted.
- BR-004 - The error message presented on BEAN_NOT_REGISTERED must include the resolved implementation class name of the WUH_PACKAGE bean to aid in diagnosing the missing component.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-049 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. This allows the Oracle Forms runtime to push local client settings (identified by a property name/value pair) to the WebUtil core package on the client tier, enabling client-environment configuration at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; only proceed if a valid property name has been supplied.
- Step 3 - Concatenate propertyName and propertyValue into the format 'propertyName=propertyValue' and pass the result to WebUtil_Core.setProperty, targeting the WUC_PACKAGE bean with the WUC_SET_LOCAL_PROPERTY action, to apply the setting on the client side.
- Step 4 - If WebUtil_Core raises BEAN_NOT_REGISTERED (the WebUtil core bean has not been registered), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 5 - If WebUtil_Core raises PROPERTY_ERROR (the property could not be set), raise FORM_TRIGGER_FAILURE to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Calls WebUtil_Core.setProperty with WUC_PACKAGE, WUC_SET_LOCAL_PROPERTY, and the concatenated 'propertyName=propertyValue' string to apply the client setting.

FALSE: The procedure exits silently without invoking WebUtil_Core.setProperty; no property is transmitted and no error is raised.

DP-002

Condition: WebUtil_Core raises the BEAN_NOT_REGISTERED exception during the setProperty call.

TRUE: Displays an error alert identifying the missing WebUtil core bean implementation class, then raises FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Exception is not raised; processing continues normally.

DP-003

Condition: WebUtil_Core raises the PROPERTY_ERROR exception during the setProperty call.

TRUE: Raises FORM_TRIGGER_FAILURE immediately to abort the current form trigger; no additional alert is displayed.

FALSE: Exception is not raised; processing completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted to the WebUtil bean if propertyName is not null; a null property name causes the procedure to exit silently with no action taken.
- BR-002 - The property name and value are combined into a single string using the format 'propertyName=propertyValue' before being passed to WebUtil_Core.setProperty; the caller must ensure the value does not itself contain an equals sign that would corrupt this format.
- BR-003 - If the WebUtil core bean is not registered at the time of invocation, the procedure must surface a descriptive error alert (including the implementation class name) and terminate the form trigger via FORM_TRIGGER_FAILURE; silent failure is not permitted in this scenario.
- BR-004 - A PROPERTY_ERROR returned by WebUtil_Core.setProperty must cause immediate termination of the form trigger via FORM_TRIGGER_FAILURE; no further processing or alerting is performed beyond the raise.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-050 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (VARCHAR2) and writes it to either a database BLOB or a server-side file, depending on the active transfer destination flag. It decrements the outstanding-chunk counter after each successful write and, when the final chunk is processed, closes the target resource, marks the upload as succeeded, fires any registered callback trigger, and clears that trigger registration. It is invoked by WEBUTIL_CORE.CUSTOMEVENTHANDLER as part of the chunked file-upload protocol managed by the WebUtil file-transfer subsystem.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-013](#SP-013--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-014](#SP-014--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-021](#SP-021--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-025](#SP-025--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-026](#SP-026--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-053](#SP-053--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 parameter representing one chunk of the file being uploaded.
- Step 2 - Validate that uploadData is not NULL and not an empty string; if it is, set the internal flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the transfer destination by evaluating the internal flag m_toDB.
- Step 4a (DB path) - If m_toDB is TRUE, delegate the write operation to WebUtil_DB_LOCAL.WriteData, passing the chunk data.
- Step 4b (File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file via the persistent Java object m_persistObj. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception.
- Step 5 - Decrement the chunk counter m_chunks by 1 to track progress toward transfer completion.
- Step 6 - Evaluate whether m_chunks has reached zero, indicating that all expected chunks have been received.
- Step 7a (Final chunk, DB path) - If m_toDB is TRUE and this is the final chunk, call WebUtil_DB_Local.CloseBlob passing m_fileSize. If CloseBlob succeeds, set m_uploadSucceeded to TRUE; otherwise retrieve the last error via WebUtil_DB_Local.getLastError and log it through WebUtil_core.Error.
- Step 7b (Final chunk, File path) - If m_toDB is FALSE and this is the final chunk, call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If CloseFile succeeds, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error, delete the global Java reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 8 - After successfully closing the resource, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER with argument -1. If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 9 - Call WEBUTIL.CLEARCALLBACKTRIGGER with argument -1 to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL OR uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no write or close operations are performed.

FALSE: Proceed to write the chunk data to the appropriate destination.

---

DP-002

Condition: m_toDB IS TRUE

TRUE: Write the chunk to the database BLOB using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (file-path write only)

TRUE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource (BLOB or file) and finalise the upload.

FALSE: No closing action required; procedure exits after the decrement.

---

DP-005

Condition: m_toDB IS TRUE at final-chunk close (evaluated only when m_chunks = 0)

TRUE: Call WebUtil_DB_Local.CloseBlob to finalise the BLOB.

FALSE: Call JAVA_APPSERV_WRITER.CloseFile to finalise the server-side file.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob succeeds (DB path, final chunk only)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the last error via WebUtil_DB_Local.getLastError and log it; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile succeeds (file path, final chunk only)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error code and arguments, log the error, delete the global Java reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name (evaluated after successful resource close)

TRUE: Execute the named trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is marked as failed (m_uploadSucceeded = FALSE) and no data is written to either the database or the file system.
- BR-002 - Each call to SETDATA processes exactly one chunk; the chunk counter m_chunks must be decremented by exactly 1 per successful write, ensuring the procedure can detect transfer completion.
- BR-003 - The transfer destination (database BLOB vs. server-side file) is determined exclusively by the pre-set internal flag m_toDB; SETDATA does not alter this routing decision.
- BR-004 - A write failure on the file-system path must be reported with both an error code (via JAVA_APPSERV_WRITER.getLastError) and error arguments (via JAVA_APPSERV_WRITER.getLastErrorArgs) before raising READWRITE_ERROR, ensuring full diagnostic information is captured.
- BR-005 - Resource closure (CloseBlob or CloseFile) is performed only after all expected chunks have been received (m_chunks = 0); partial uploads must not trigger a close operation.
- BR-006 - The upload is marked as succeeded (m_uploadSucceeded = TRUE) only upon confirmed successful closure of the target resource; any close failure leaves the flag as FALSE.
- BR-007 - On a CloseFile failure in the file-system path, the global Java persistent object reference (m_persistObj) must be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before the READWRITE_ERROR exception is raised, preventing resource leaks.
- BR-008 - After the final chunk is successfully closed, any registered callback trigger must be fired before its registration is cleared; the trigger is always cleared (via WEBUTIL.CLEARCALLBACKTRIGGER) regardless of whether a trigger was present, ensuring a clean state for subsequent transfers.
- BR-009 - The callback trigger slot used by SETDATA is identified by the fixed index -1, consistently passed to both WEBUTIL.GETCALLBACKTRIGGER and WEBUTIL.CLEARCALLBACKTRIGGER.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-051 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value by delegating to the Java Virtual Machine via the JNI bridge. The function accepts a property key and its new value, invokes java.lang.System.setProperty through JNI, and returns the previous value of the property as a VARCHAR2 string. It is called by WEBUTIL_CORE.CUSTOMEVENTHANDLER to allow Oracle Forms to read or modify JVM-level system properties at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Create a JNI argument list sized for two arguments by calling JNI.CREATE_ARG_LIST(2) and assign the result to the shared args variable.
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the new property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully qualified class name, method name, and JNI method signature, along with the prepared argument list.
- Step 6 - Return the VARCHAR2 result from JNI.CALL_STRING_METHOD to the caller; this value represents the previous value of the named system property as returned by the JVM (NULL if the property was not previously set).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally for all valid inputs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property key (a0) and the property value (a1) must be supplied as VARCHAR2 values; the JNI argument list is constructed expecting exactly two String arguments, and omitting either will result in an incorrect JNI call.
- BR-002 - The function targets the static Java method java.lang.System.setProperty with the fixed JNI signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'; the property key and value must therefore be compatible with Java String semantics.
- BR-003 - The return value represents the previous value of the system property as held by the JVM; callers that need to preserve the original value must capture the function's return value before overwriting the property.
- BR-004 - This function has no database interactions; all state changes are confined to JVM system properties and are not persisted to any database table.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-052 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil bean components. When called with show = TRUE, the procedure surfaces the window and redirects form focus to the WebUtil dummy item; when called with show = FALSE, it hides the window and restores focus to the previously active item. Execution is suppressed entirely while the form is in Enter Query Mode to prevent interference with query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-035](#SP-035--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Boolean parameter 'show', which signals whether the WebUtil hidden window should be displayed or concealed.
- Step 2 - Check the current form mode via SYSTEM.MODE; if the form is not in 'NORMAL' mode (e.g., it is in Enter Query Mode), skip all remaining steps and exit without action.
- Step 3 - Locate the WebUtil hidden window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the handle in the local variable hWin.
- Step 4 - Verify that a valid window handle was returned by calling WEBUTIL.ID_NULL(hWin); if the window does not exist, skip all remaining steps and exit without action.
- Step 5 - If 'show' is TRUE: capture the currently focused form item by reading SYSTEM.CURSOR_ITEM via FIND_ITEM and storing it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the window using SHOW_WINDOW; then navigate form focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether m_infoFrom holds a valid item handle using WEBUTIL.ID_NULL; if valid, navigate form focus back to m_infoFrom; then hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE = 'NORMAL'

TRUE: Proceed with window visibility logic (steps 3-6).

FALSE: Exit the procedure immediately without performing any window or focus operations, preventing interference with Enter Query Mode.

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) is FALSE (i.e., a valid window handle was found for WEBUTIL_HIDDEN_WINDOW)

TRUE: Proceed to evaluate the 'show' parameter and act on window visibility.

FALSE: Exit the procedure without performing any window or focus operations.

---

DP-003

Condition: 'show' parameter is TRUE

TRUE: Record the current cursor item in m_infoFrom, set the window title, display the hidden window, and move focus to WEBUTIL_DUMMY_ITEM.

FALSE: Evaluate whether m_infoFrom is valid and, if so, restore focus to m_infoFrom, then hide the window.

---

DP-004

Condition: 'show' is FALSE AND WEBUTIL.ID_NULL(m_infoFrom) is FALSE (i.e., a previously saved cursor item exists)

TRUE: Navigate form focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus operations while the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this safeguard prevents disruption of user query entry.
- BR-002 - The WebUtil hidden window must exist (WEBUTIL.ID_NULL returns FALSE for hWin) before any show or hide action is attempted; if the window is not found, the procedure exits silently.
- BR-003 - When showing the WebUtil window, the currently focused item (SYSTEM.CURSOR_ITEM) must be captured and persisted in m_infoFrom prior to redirecting focus, so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The WebUtil hidden window title must be set to 'WebUtil ' concatenated with WEBUTIL_VERSION each time the window is displayed, ensuring the version is always visible in the window title bar.
- BR-005 - Focus restoration to m_infoFrom is conditional: it is performed only when m_infoFrom holds a valid item handle (WEBUTIL.ID_NULL returns FALSE), preventing a navigation error if no prior item was recorded.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-053 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data chunk to the Java-layer AppServerFileWriter object on the application server by invoking its WriteData method via JNI. The function acts as a PL/SQL-to-Java bridge, forwarding the supplied data argument to the underlying Java file-writer and returning a Boolean indicating whether the write operation succeeded. It is called exclusively by WEBUTIL.SETDATA to perform the actual data transfer step.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target Java object reference (obj) representing an active AppServerFileWriter instance and the data string (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the data string a0 to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class through JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result produced by the Java method to the caller (WEBUTIL.SETDATA), indicating success or failure of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function constructs the JNI call unconditionally and returns the Boolean result directly from the Java method invocation without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid Java object reference (obj) pointing to an initialised AppServerFileWriter instance; no null-check or fallback is performed within this function, so the caller (WEBUTIL.SETDATA) is responsible for supplying a live object.
- BR-002 - Exactly one String argument (a0) must be packaged into the JNI argument list before the Java method is called; the argument list size is fixed at 1.
- BR-003 - The return value is a Boolean sourced directly from the Java WriteData method; a FALSE return indicates the write operation was unsuccessful and must be interpreted by the calling routine.
- BR-004 - The target Java class and method are fixed at compile time ('oracle/forms/webutil/fileTransfer/AppServerFileWriter', method 'WriteData', signature '(Ljava/lang/String;)Z') and cannot be overridden by the caller.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-054 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- sr_exch_tradein_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side Java bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires in sr_exch_tradein_fmb.xml, this procedure receives the event name and its serialised parameter string, extracts the data payload and multi-part chunking metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-callback execution, or file-transfer data receipt). Events that are not on the recognised whitelist are silently discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-016](#SP-016--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-027](#SP-027--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-041](#SP-041--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-046](#SP-046--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-050](#SP-050--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-051](#SP-051--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the event name (EventName) and the serialised parameter string (EventParameters) passed by the WHEN-CUSTOM-ITEM-EVENT trigger.
- Step 2 - Validate that EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'). If it is not, raise the local 'unhandled' exception, which is caught silently, and exit without further processing.
- Step 3 - Extract the data payload string from EventParameters by reading the 'WUC_DATA' attribute into the local variable dataPayload.
- Step 4 - Extract the multi-part descriptor string from EventParameters by reading the 'WUC_DATA_MULTIPART' attribute into dataMultiPart.
- Step 5 - Parse dataMultiPart using the '/' delimiter to derive chunkNumber (the current chunk sequence) and PayloadChunks (the total number of chunks expected), enabling reassembly of large payloads split across multiple client messages.
- Step 6 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG with dataPayload to write an informational log entry.
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG with dataPayload flagged as an error entry.
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a number and store it in m_lastCallback; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is populated, execute the corresponding callback trigger via EXECUTE_TRIGGER; if m_lastCallback is null, call WEBUTIL.LOG to record that no callback trigger was specified.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA with dataPayload to store the transferred file data, then call WEBUTIL.SETPROPERTY to mark the transfer event status as 'RECEIVED'.
- Step 7 - Allow any unexpected exception other than 'unhandled' to propagate to the caller via the WHEN OTHERS re-raise handler.

---
**Decision Points**

DP-001

Condition: EventName is one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', or 'WUT_TRANSFER_EVENT'.

TRUE: Continue processing - extract payload and multi-part metadata, then route to the appropriate handler.

FALSE: Raise the local 'unhandled' exception, which is caught silently; procedure exits without any action.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload as an informational log entry (error flag = false).

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload flagged as an error entry (error flag = true).

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number and store in m_lastCallback; evaluate DP-006 and DP-007.

FALSE: Evaluate the 'WUT_TRANSFER_EVENT' condition.

---

DP-006

Condition: Conversion of dataPayload to a number raises INVALID_NUMBER during the 'WUH_CALLBACK_EVENT' branch.

TRUE: Call WEBUTIL.ERROR to report error code 408 for 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains null.

FALSE: m_lastCallback is set to the numeric value of dataPayload; proceed to DP-007.

---

DP-007

Condition: m_lastCallback IS NOT NULL after the numeric conversion attempt in the 'WUH_CALLBACK_EVENT' branch.

TRUE: Execute the trigger stored in m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record that the callback trigger for the host command was not specified.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to set the 'WUT_TRANSFER_EVENT' property to 'RECEIVED'.

FALSE: No further routing is performed (end of event-dispatch chain).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five explicitly whitelisted event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; any other event name is silently ignored and causes no state change.
- BR-002 - The data payload and multi-part chunking descriptor must always be extracted from EventParameters before any event-specific routing is attempted, regardless of the event type.
- BR-003 - Large payloads transmitted from the client may be split into multiple chunks; chunkNumber and PayloadChunks derived from the 'WUC_DATA_MULTIPART' attribute govern reassembly sequencing.
- BR-004 - For 'WUH_CALLBACK_EVENT', the payload must be a valid integer referencing an entry in the m_callbacks collection; an INVALID_NUMBER conversion failure must be reported via WEBUTIL.ERROR (error code 408) rather than allowed to propagate silently.
- BR-005 - A host callback is only executed when m_lastCallback is not null; a null value (resulting from a conversion failure) must be logged as a warning via WEBUTIL.LOG rather than causing a runtime error.
- BR-006 - For 'WUT_TRANSFER_EVENT', the transfer is only considered complete when both WEBUTIL.SETDATA has stored the payload and WEBUTIL.SETPROPERTY has set the status to 'RECEIVED'; both calls are mandatory.
- BR-007 - Unexpected exceptions (WHEN OTHERS) are re-raised to the calling trigger to ensure that unhandled runtime errors are not masked; only the locally defined 'unhandled' exception is suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-055 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a global error flag, composing a formatted error stack entry from the calling function name and error text, and forwarding the composed message to the debug logging facility. This procedure provides a centralised error-capture mechanism used by utility routines throughout the D2kwutil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been recorded.
- Step 3 - Compose the ERROR_STACK entry by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess to prevent value errors.
- Step 4 - Invoke DEBUGLOG (SP-059) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK string, so that the error is written to the debug log.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to TRUE on every call, ensuring that any downstream logic inspecting this flag can detect that at least one error has occurred.
- BR-002 - The error text stored in ERROR_STACK is capped at 1,968 characters (via SUBSTR) to guard against VALUE_ERROR exceptions caused by oversized string assignments.
- BR-003 - The ERROR_STACK entry must be prefixed with the CallingFunction name followed by a colon-space separator, ensuring traceability of the error back to its originating routine.
- BR-004 - All recorded errors must be forwarded to DEBUGLOG (SP-059) at severity level 99, guaranteeing that every captured error is persisted in the debug log regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-056 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates error messages from the Oracle Forms tool_err error stack into a single newline-delimited string buffer. If the tool_err stack contains one or more errors, each message is extracted and appended in sequence; if the stack is empty but a SQL error is present, the current SQLERRM value is captured instead. The resulting buffer is returned to the caller for upstream error reporting or display.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local counter (iCounter) and an empty varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error text.
- Step 2 - Check whether the tool_err error stack contains one or more errors (tool_err.nerrors > 0).
- Step 3 - If errors exist, iterate through each entry on the stack from 1 to tool_err.nerrors.
- Step 4 - For each iteration, append a newline character (CHR(10)) followed by the current tool_err.message to vcErrBuff.
- Step 5 - If appending the next message would cause vcErrBuff to exceed its 1968-character limit, a VALUE_ERROR exception is raised; the loop exits immediately to prevent overflow.
- Step 6 - After each message is successfully appended, call tool_err.pop to remove that entry from the error stack.
- Step 7 - If the tool_err stack is empty but SQLERRM is not null, append a newline character followed by SQLERRM to vcErrBuff as a fallback error source.
- Step 8 - Return vcErrBuff (populated or empty) to the calling routine.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Enter the loop to iterate over all entries on the tool_err stack, appending each message to vcErrBuff and popping each entry after capture.

FALSE: Skip the loop and evaluate the SQLERRM fallback condition (DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE: Append CHR(10) || SQLERRM to vcErrBuff as the sole error message.

FALSE: vcErrBuff remains empty; an empty string is returned to the caller.

---

DP-003

Condition: Appending the next tool_err.message causes a VALUE_ERROR exception (vcErrBuff would exceed 1968 characters)

TRUE: Exit the iteration loop immediately; remaining stack entries are not processed, and vcErrBuff is returned as-is.

FALSE: Append the message successfully, pop the entry, and continue to the next iteration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer must not exceed 1968 characters; any message that would cause the buffer to overflow is silently discarded and iteration halts, preventing a runtime error from propagating to the caller.
- BR-002 - Each error message retrieved from the tool_err stack must be prefixed with a newline character (CHR(10)) to ensure messages are separated when the buffer is displayed or logged.
- BR-003 - The tool_err stack is consumed during processing; tool_err.pop is called after each message is appended, meaning entries are removed from the stack as they are collected.
- BR-004 - The SQLERRM fallback is only evaluated when the tool_err stack is empty, ensuring tool_err messages take precedence over SQL engine errors.
- BR-005 - The function always returns a value (vcErrBuff), which may be an empty string if neither tool_err entries nor a SQLERRM value are present at the time of invocation.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-057 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It exists because Oracle Forms and PL/SQL contexts frequently require a character representation of a Boolean result for display, concatenation, or further string-based processing. It is invoked by GET_ENVIRONMENT_STRING and READ_REGISTRY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input Boolean value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate whether ThisBoolean resolves to TRUE.
- Step 3 - If the condition is TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the condition is FALSE (or NULL evaluates to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; the only permitted return values are the string literals 'TRUE' and 'FALSE'.
- BR-002 - A BOOLEAN input that is not explicitly TRUE (including a FALSE or NULL BOOLEAN) is mapped to the return value 'FALSE', ensuring the output is never null or undefined.
- BR-003 - The function accepts no parameters other than the single IN BOOLEAN argument and has no side effects; it performs no database reads or writes.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-058 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state used across the utility library by clearing the error-encountered flag and discarding any accumulated error messages. This procedure is called before operations that require a clean error context, ensuring that stale error information from a previous execution does not affect subsequent processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error has been encountered in the current execution context.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, removing any previously accumulated error messages from the error stack.

---
**Decision Points**

No decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be reset to FALSE on every invocation, regardless of its prior state, to ensure callers begin with a clean error context.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error messages from a previous operation are carried forward.
- BR-003 - The procedure accepts no input and produces no formal output; its sole effect is the unconditional reset of the shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-059 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel (Windows debug monitor or flat file) when the current debug state permits logging. It enforces debug-level filtering, optional timestamping, and automatic fallback from Windows API-based debug output to file-based logging when the debug API is unavailable, restoring the preferred channel once the API becomes available again.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-063](#SP-063--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-066](#SP-066--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Check whether debugging is active (iDebugState ≠ 0), not paused (bDebugPaused = FALSE), and the requested DebugLevel does not exceed the configured threshold (iDebugLevel). If any guard condition fails, exit immediately without logging.
- Step 2 - If the timestamp flag (bDebugTimeStamp) is enabled, retrieve the current system time formatted as HH24:MI:SS and append a '> ' separator to form vcDateStamp.
- Step 3 - Construct the full debug string: prefix the numeric DebugLevel (left-padded to two digits in angle brackets), append the optional timestamp, then right-pad the LoggingCall value (with a colon suffix) to 30 characters.
- Step 4 - Append the LogString to the constructed prefix, truncating it so that the total string length does not exceed 2,000 characters.
- Step 5 - If iDebugState = 2 (Windows debug monitor mode) and DEBUG_API_ENABLED is TRUE, pass the formatted string to WINDEBUG for output via the Windows debug API.
- Step 6 - If iDebugState = 2 but DEBUG_API_ENABLED is FALSE, call SETDEBUG to switch the session to file-based logging (mode 1, targeting the configured debug file or the default 'd2kwutil.log'), log a fallback notice, re-invoke DEBUGLOG recursively to write the original message to the file, and set bDebugType2Required to TRUE to record that Windows debug mode was the intended channel.
- Step 7 - If iDebugState ≠ 2 and bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE, call SETDEBUG to restore Windows debug monitor mode (mode 2), log a restoration notice, reset bDebugType2Required to FALSE, and re-invoke DEBUGLOG recursively to write the original message to the restored channel.
- Step 8 - If iDebugState ≠ 2 and no pending channel restoration is required, open the configured debug file in append mode using TEXT_IO, write the formatted string as a new line, and close the file.
- Step 9 - If any unhandled exception occurs during the above steps, suppress it silently by setting iDebugState to 0, disabling further debug output for the session.

---
**Decision Points**

DP-001
Condition: iDebugState = 0
TRUE: Procedure exits immediately; no logging is performed because debugging is disabled.
FALSE: Proceed to DP-002.

DP-002
Condition: bDebugPaused = TRUE
TRUE: Procedure exits immediately; logging is suspended.
FALSE: Proceed to DP-003.

DP-003
Condition: DebugLevel > iDebugLevel
TRUE: Procedure exits immediately; the message's severity level exceeds the configured verbosity threshold.
FALSE: Proceed to construct the debug string and determine the output channel.

DP-004
Condition: bDebugTimeStamp = TRUE
TRUE: A HH24:MI:SS timestamp is generated and included in the formatted debug string.
FALSE: No timestamp is included; vcDateStamp remains empty.

DP-005
Condition: iDebugState = 2 (Windows debug monitor mode requested)
TRUE: Proceed to DP-006 to evaluate API availability.
FALSE: Proceed to DP-007 to evaluate file-based logging path.

DP-006
Condition: DEBUG_API_ENABLED = TRUE (within iDebugState = 2 branch)
TRUE: The formatted string is passed to WINDEBUG for output via the Windows debug API.
FALSE: SETDEBUG is called to switch to file logging; a fallback notice and the original message are written recursively; bDebugType2Required is set to TRUE.

DP-007
Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (within file-logging branch)
TRUE: SETDEBUG is called to restore Windows debug monitor mode; a restoration notice and the original message are written recursively; bDebugType2Required is reset to FALSE.
FALSE: The formatted string is appended directly to the debug file via TEXT_IO.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState equals 0; no output is produced regardless of the DebugLevel or LogString supplied.
- BR-002 - Logging is suppressed when the session debug state is paused (bDebugPaused = TRUE), allowing temporary suspension without disabling the debug configuration.
- BR-003 - A message is only logged if its DebugLevel is less than or equal to the configured iDebugLevel threshold; messages with a higher level are silently discarded.
- BR-004 - The total length of the formatted debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit.
- BR-005 - When Windows debug monitor mode (iDebugState = 2) is active but the debug API is unavailable, the procedure automatically downgrades to file-based logging targeting the configured debug file, defaulting to 'd2kwutil.log' if no file is specified.
- BR-006 - Once file-based fallback is active (bDebugType2Required = TRUE) and the debug API becomes available again, the procedure automatically restores Windows debug monitor mode via SETDEBUG before continuing normal logging.
- BR-007 - Any runtime exception raised during logging is silently caught and handled by setting iDebugState to 0, ensuring that diagnostic instrumentation never causes failures in the calling business process.
- BR-008 - The DebugLevel value is always formatted as a two-digit, zero-padded integer enclosed in angle brackets at the start of every log entry, providing consistent log readability.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-060 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUtil native library function D2KWUTIL_GETDOSENV. The function registers the external call, passes the variable name in DOS-expansion format, and returns the resolved string value. If the Win API layer is unavailable, the variable cannot be resolved, or the returned buffer is empty/unchanged, the function records an error via ADD_ERROR and either raises NO_DATA_FOUND or returns NULL depending on the caller's exception preference.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-057](#SP-057--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-058](#SP-058--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the string representation of RaiseExceptions (obtained via BOOLTOCHAR).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack) and initialise the return-code variable iRC to 0.
- Step 3 - Check whether the Win API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle for D2KWUTIL_GETDOSENV by calling REGISTER_FUNCTION_CALL, supplying the function identifier iGetDOSEnv, the function name 'd2kwutil_GetDOSEnv', and its calling-convention signature ('LONG','*CHAR,*CHAR,LONG').
- Step 5 - Prepare the call buffers: wrap VariableName in percent signs to form the DOS environment variable token (vcBuff1), initialise a 512-character null-padded output buffer (vcBuff2), and set the buffer length indicator iBuff1 to 512.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing the formatted variable name, the output buffer, and the buffer length. Capture the integer return code in iRC.
- Step 7 - Log the result diagnostics by calling DEBUGLOG again, recording the returned value length (iRC) and the populated output buffer (vcBuff2).
- Step 8 - Evaluate the resolution outcome: if iRC equals 0 or the output buffer is unchanged from the input token (vcBuff2 = vcBuff1), the variable was not found. Call ADD_ERROR to record the failure message, then either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL (if RaiseExceptions is FALSE).
- Step 9 - If resolution succeeded, return vcBuff2 as the environment variable value.
- Step 10 - Handle exceptions: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with WIN_API.NoAPI and re-raise; for all other exceptions, call ADD_ERROR with WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Proceed to register the external function call and invoke D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all resolution logic.

---

DP-002

Condition: iRC = 0 OR vcBuff2 = vcBuff1 (the external call returned a zero-length result or the output buffer was not populated beyond the input token).

TRUE: The environment variable could not be resolved. Call ADD_ERROR to record the failure, then branch on RaiseExceptions (see DP-003).

FALSE: The environment variable was resolved successfully; return vcBuff2 to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND so the calling context can handle the unresolved variable as an exception.

FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment variable lookup when the Win API layer is active (WIN_API.API_ENABLED = TRUE); if the layer is unavailable, processing is halted immediately and WIN_API.NOT_AVAILABLE is raised.
- BR-002 - The environment variable name must be submitted to D2KWUTIL_GETDOSENV wrapped in percent signs (e.g. %VariableName%) to conform to the DOS environment variable expansion convention.
- BR-003 - The output buffer is fixed at 512 characters; values exceeding this length will be truncated to fit the buffer.
- BR-004 - A return code of zero from D2KWUTIL_GETDOSENV, or an output buffer identical to the formatted input token, is treated as a failed resolution and is not considered a valid variable value.
- BR-005 - When a variable cannot be resolved, an error message identifying the procedure and the unresolved variable name must be recorded via ADD_ERROR before any return or exception propagation.
- BR-006 - The caller controls exception behaviour through the RaiseExceptions parameter: TRUE causes NO_DATA_FOUND to be raised on resolution failure; FALSE causes NULL to be returned, making the failure non-fatal to the calling context.
- BR-007 - All unexpected runtime errors must be enriched with ADD_EXTERNAL_ERRORS output before being recorded via ADD_ERROR and re-raised, ensuring the full external error context is preserved in the error stack.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-061 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a given registry path and entry key. It translates the root hive portion of the supplied path to the numeric constant expected by the underlying D2KWUTIL native call, delegates the actual registry read to D2KWUTIL.D2KWUTIL_GETREGKEY, and returns the value as a VARCHAR2 string. The procedure supports an optional exception-raising mode so callers can choose between receiving a NULL return value or a propagated PL/SQL exception when the read fails. It is invoked indirectly through WEBUTIL.GETVAR.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-057](#SP-057--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-058](#SP-058--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (severity 99) with the supplied RegPath, RegEntry, and the Boolean-to-character representation of RaiseExceptions produced by BOOLTOCHAR.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable (iRC) to 0 and check whether the WIN_API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL with the function identifier, name, and parameter type signature.
- Step 5 - Parse the root hive from RegPath by extracting the substring before the first backslash and converting it to upper case. Map the root hive name to its corresponding integer constant: HKEY_LOCAL_MACHINE -> 0, HKEY_CLASSES_ROOT -> 1, HKEY_CURRENT_USER -> 2, HKEY_USERS -> 3, HKEY_CURRENT_CONFIG -> 4.
- Step 6 - If the root hive name does not match any recognised constant, call ADD_ERROR to record an 'Invalid Registry Key' message. If RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise continue.
- Step 7 - Prepare the call buffers: set the sub-path (everything after the first backslash) into vcBuff1, the entry name into vcBuff2, and initialise the 2000-byte result buffer vcBuff3 with padded null characters.
- Step 8 - Evaluate the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag. If it is FALSE, set the suppress-expansion flag (iBuff3) to 1 and log a compatibility suppression message via DEBUGLOG; otherwise set iBuff3 to 0 to allow environment-variable expansion.
- Step 9 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the registered function handle, root constant, sub-path, entry name, result buffer, buffer length (2000), and the expansion flag. Capture the integer return code in iRC.
- Step 10 - Log the result by calling DEBUGLOG with the return code and the content of the result buffer.
- Step 11 - Evaluate iRC for error conditions and respond according to the RaiseExceptions flag (see Decision Points). On success (iRC not negative), return the populated result buffer vcBuff3.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the NoAPI message then re-raise; for all other exceptions, call ADD_ERROR with the generic unexpected-error message concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root-hive parsing, and the registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately, bypassing all registry access logic.

DP-002
Condition: The upper-cased root hive extracted from RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding integer constant to iBuff1 and continue buffer preparation.
FALSE: Call ADD_ERROR with 'Invalid Registry Key'; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue execution (the subsequent D2KWUTIL call will proceed with an uninitialised iBuff1).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: Set iBuff3 to 1 (suppress environment-variable expansion in the registry value) and log a compatibility message via DEBUGLOG.
FALSE: Set iBuff3 to 0 (allow environment-variable expansion).

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (entry not found).
TRUE and RaiseExceptions FALSE: Call ADD_ERROR with a 'Cannot read entry' message and return NULL.
TRUE and RaiseExceptions TRUE: Call ADD_ERROR with a 'Cannot read entry' message and raise NO_DATA_FOUND.
FALSE: Proceed to evaluate further return codes.

DP-005
Condition: iRC equals -2 (unsupported data type).
TRUE and RaiseExceptions FALSE: Call ADD_ERROR with an 'unsupported datatype' message and return NULL.
TRUE and RaiseExceptions TRUE: Call ADD_ERROR with an 'unsupported datatype' message and raise NO_DATA_FOUND.
FALSE: Proceed to evaluate further return codes.

DP-006
Condition: iRC equals -3 (value exceeds buffer length of 2000 bytes).
TRUE and RaiseExceptions FALSE: Call ADD_ERROR with a 'longer than N Bytes' message and return NULL.
TRUE and RaiseExceptions TRUE: Call ADD_ERROR with a 'longer than N Bytes' message and raise VALUE_ERROR.
FALSE: Proceed to evaluate further return codes.

DP-007
Condition: iRC equals -4 (environment-string expansion failure).
TRUE and RaiseExceptions FALSE: Call ADD_ERROR with a 'Failed to expand environment string' message and return NULL.
TRUE and RaiseExceptions TRUE: Call ADD_ERROR with a 'Failed to expand environment string' message and raise NO_DATA_FOUND.
FALSE: No error condition; return the populated result buffer vcBuff3.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure may only execute when the WIN_API layer is available (WIN_API.API_ENABLED = TRUE); if the layer is unavailable the WIN_API.NOT_AVAILABLE exception is raised and an error is recorded via ADD_ERROR.
- BR-002 - The root hive component of RegPath must be one of exactly five recognised Windows registry hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other value is treated as an invalid registry key error.
- BR-003 - The registry value result buffer is fixed at 2000 bytes; a registry entry whose value exceeds this limit produces a specific error (iRC = -3) and is reported as a VALUE_ERROR when RaiseExceptions is TRUE.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when this flag is FALSE, expansion is suppressed and the raw registry string is returned.
- BR-005 - The RaiseExceptions parameter governs error propagation behaviour: when FALSE all error conditions (invalid hive, entry not found, unsupported type, buffer overflow, expansion failure) cause the function to return NULL after logging the error; when TRUE the corresponding PL/SQL exception is raised.
- BR-006 - All errors, including unexpected exceptions, must be recorded via ADD_ERROR before any exception is propagated to the caller; unexpected exceptions additionally incorporate external error detail obtained through ADD_EXTERNAL_ERRORS.
- BR-007 - Entry and diagnostic logging via DEBUGLOG must occur at the start of execution (input arguments) and immediately after the D2KWUTIL_GETREGKEY call (return code and retrieved value), ensuring a complete audit trail of every registry read attempt.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-062 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native DLL function and its call signature (parameters and return type) with the Oracle FFI layer so that the function can be invoked from Oracle Forms at runtime. The procedure first ensures the target DLL is loaded, then registers the function handle, iterates over the argument list to register each parameter type, and registers the return type when applicable. It caches the DLL load-count against the function ID to avoid redundant re-registration and to detect DLL reloads that require re-registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-047](#SP-047--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the already-loaded DLL by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant; if the library is found the procedure continues to Step 3.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises ORA_FFI.FFI_ERROR, call D2KWUTIL.ATTEMPT_DLL_LOAD to reload the DLL from DLL_PATH. If the reload also fails, set API_ENABLED to FALSE, raise an error via ADD_ERROR identifying the missing DLL by name, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Compare the cached load-count for FunctionID (FunctionLoad array) against the current DLL_LOAD_COUNT. If no entry exists for FunctionID, or the stored count differs from DLL_LOAD_COUNT, proceed to Step 4; otherwise skip to Step 9 (registration is current).
- Step 4 - Register the function with the DLL handle by calling ORA_FFI.REGISTER_FUNCTION, passing the DLL handle, FunctionName, and calling convention ORA_FFI.C_STD; store the resulting handle in FunctionHandle(FunctionID).
- Step 5 - If FunctionName is not 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (Win_API_Debug.DebugLog) recording the function name, current DLL load count, and whether this is an initial registration or a re-registration (distinguished by whether FunctionLoad already contains an entry for FunctionID).
- Step 6 - Prepare the argument list by appending a trailing comma to FunctionArgs, then enter a loop that processes each comma-delimited type token while the remaining string is non-null, non-empty, and not equal to 'VOID,'.
- Step 7 - Within each loop iteration, extract the next type token using INSTR and SUBSTR, call D2KWUTIL.TRANSLATETYPE to convert the token to its FFI type constant, and register the parameter against the function handle via ORA_FFI.REGISTER_PARAMETER. Advance the working string past the processed token; exit the loop when no tokens remain.
- Step 8 - After parameter registration, if FunctionReturn is not 'VOID' (case-insensitive) and is not NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store DLL_LOAD_COUNT in FunctionLoad(FunctionID) to mark the function as registered for the current DLL load cycle.
- Step 10 - If ORA_FFI.FFI_ERROR is raised at any point during Steps 4-9, call ADD_ERROR with the FunctionName and the concatenated error text from ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to abort the calling routine.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL by DLL_NAME.

TRUE: The DLL handle is obtained and processing continues to the registration check (DP-002).

FALSE: ORA_FFI.FFI_ERROR is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is called to reload the DLL (see DP-002-inner).

---

DP-002-inner

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD successfully reloads the DLL after the initial FIND_LIBRARY failure.

TRUE: DLL handle is obtained and processing continues to the registration check.

FALSE: ORA_FFI.FFI_ERROR is raised again; API_ENABLED is set to FALSE, ADD_ERROR is called with the DLL name, and NO_DATA_FOUND is raised to abort.

---

DP-003

Condition: FunctionLoad does not contain an entry for FunctionID, OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.

TRUE: The function has not been registered for the current DLL load cycle; full registration (Steps 4-9) is performed.

FALSE: The function is already registered for the current DLL load cycle; registration is skipped.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: Diagnostic logging via DEBUGLOG is suppressed to avoid infinite recursion.

FALSE: DEBUGLOG is called to record whether this is an initial registration or a re-registration.

---

DP-005

Condition: FunctionLoad already contains an entry for FunctionID at the time of logging (evaluated inside the DP-004 FALSE branch).

TRUE: Log message indicates re-registration and includes the previous load count.

FALSE: Log message indicates initial registration.

---

DP-006

Condition: The working argument string (vcArgs) is non-null, non-empty, and not equal to 'VOID,' at the start of each loop iteration.

TRUE: Extract the next type token, call D2KWUTIL.TRANSLATETYPE, and register the parameter; advance the string.

FALSE: Exit the parameter registration loop.

---

DP-007

Condition: FunctionReturn is not 'VOID' (case-insensitive) and is not NULL.

TRUE: Call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type via ORA_FFI.REGISTER_RETURN.

FALSE: No return type is registered (procedure is treated as void-returning).

---

DP-008

Condition: ORA_FFI.FFI_ERROR is raised during the registration block (Steps 4-9).

TRUE: ADD_ERROR is called with FunctionName and the output of ADD_EXTERNAL_ERRORS; NO_DATA_FOUND is raised.

FALSE: Normal execution completes without error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The target DLL must be locatable via ORA_FFI.FIND_LIBRARY or recoverable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and the operation is aborted.
- BR-002 - A function is re-registered whenever the cached DLL load-count for its FunctionID does not match the current DLL_LOAD_COUNT, ensuring that stale handles from a previous DLL load are never used.
- BR-003 - Diagnostic logging is explicitly suppressed for the internal function 'd2kwutil_DebugString' to prevent recursive logging loops.
- BR-004 - The argument list passed in FunctionArgs must be comma-delimited; each token is translated to its FFI type constant via D2KWUTIL.TRANSLATETYPE before being registered. A value of 'VOID' in the argument list terminates parameter registration.
- BR-005 - A return type is registered only when FunctionReturn is non-null and not equal to 'VOID' (case-insensitive); void-returning functions receive no return-type registration.
- BR-006 - Any ORA_FFI.FFI_ERROR raised during function or parameter registration must be surfaced to the caller through ADD_ERROR (incorporating ADD_EXTERNAL_ERRORS detail) and results in NO_DATA_FOUND being raised to halt the calling routine.
- BR-007 - After successful registration, FunctionLoad(FunctionID) is updated to DLL_LOAD_COUNT to prevent unnecessary re-registration on subsequent calls within the same DLL load cycle.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-063 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by recording the desired logging mode, target file, severity level, and timestamp preference into module-level state variables. Depending on the DebugType supplied, the procedure activates file-based logging, activates non-file (in-application) logging, or deactivates logging entirely, and emits an initial diagnostic entry via DEBUGLOG to confirm the new state.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-059](#SP-059--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the module-level variable bDebugTimeStamp to control whether subsequent log entries include a timestamp.
- Step 2 - Store the incoming DebugFile value in the module-level variable vcDebugFile to record the target log file path for file-based logging.
- Step 3 - Store the incoming DebugLevel value in the module-level variable iDebugLevel to set the active severity threshold for log filtering.
- Step 4 - Evaluate DebugType to determine which logging mode to activate (see Decision Points).
- Step 5 - Set the module-level state variable iDebugState to the resolved mode value (1 for file logging, 2 for non-file logging, or 0 for logging disabled).
- Step 6 - Call DEBUGLOG with severity 0 and the procedure name 'SetDebug' to emit a confirmation message that reflects the newly established logging state.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging) and call DEBUGLOG to record the message 'Logging to File ' concatenated with the supplied DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (non-file / in-application logging) and call DEBUGLOG to record the message 'Logging Started'.

FALSE: Call DEBUGLOG to record the message 'Logging Stopped', then set iDebugState to 0 (logging disabled).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging mode; the DebugFile parameter must carry a meaningful file path under this mode, as it is stored and referenced in the confirmation log entry.
- BR-002 - DebugType = 2 designates non-file (in-application) logging mode; DebugFile is accepted but is not referenced in the confirmation log entry for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to disable logging; iDebugState is set to 0 and a 'Logging Stopped' entry is written before the state is cleared.
- BR-004 - DebugLevel defaults to 98 when not supplied, establishing the severity threshold used by the logging framework for subsequent calls.
- BR-005 - TimeStamp defaults to FALSE when not supplied; setting it to TRUE instructs downstream logging calls to include timestamp information in each log entry.
- BR-006 - A confirmation log entry via DEBUGLOG is always emitted at severity level 0 regardless of the logging mode selected, ensuring the state transition is itself recorded.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-064 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- sr_exch_tradein_fmb.xml [Trigger: KEY-CLRFRM]
- sr_exch_tradein_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Generates and returns a formatted copyright string displaying the current financial year and the company name 'Maruti Suzuki India Limited'. Because the Indian financial year runs from April to March, the function adjusts the displayed year accordingly so that months January through March show the preceding calendar year as the copyright year. The returned string is used at form initialisation and form-clear events in the Exchange/Trade-In screen.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date using SYSDATE into a local date variable.
- Step 2 - Evaluate the month component of the current date to determine the applicable financial year.
- Step 3 - If the current month is January, February, or March (i.e., the tail end of the Indian financial year), subtract 1 from the current calendar year to derive the correct copyright year.
- Step 4 - If the current month is any other month (April through December), use the current calendar year as the copyright year.
- Step 5 - Concatenate the derived year with the fixed company name to form the copyright string in the format '- YYYY Maruti Suzuki India Limited '.
- Step 6 - Return the formatted copyright string to the calling trigger (KEY-CLRFRM or WHEN-NEW-FORM-INSTANCE in sr_exch_tradein_fmb.xml).

---
**Decision Points**

DP-001

Condition:
The month portion of the current system date (SYSDATE) is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The copyright year is set to the current calendar year minus 1, reflecting that these months belong to the previous Indian financial year (e.g., February 2012 belongs to financial year 2011-12, so the year displayed is 2011).

FALSE:
The copyright year is set to the current calendar year as-is, because the month falls within April-December, which is the opening half of the Indian financial year (e.g., July 2011 belongs to financial year 2011-12, so the year displayed is 2011).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Indian financial year convention (April-March) must be applied when determining the copyright year; months January, February, and March are treated as belonging to the financial year that started in the previous calendar year.
- BR-002 - The copyright notice must always identify 'Maruti Suzuki India Limited' as the rights holder; this company name is fixed and must not be derived dynamically.
- BR-003 - The function takes no input parameters and performs no database reads or writes; the sole data source is the database server's current date via SYSDATE, ensuring the copyright year is always current without manual maintenance.
- BR-004 - The returned string must follow the format '- YYYY Maruti Suzuki India Limited ' (leading dash, space-padded) so that consuming form triggers can display it consistently without additional formatting.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-065 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any semicolon-delimited suffix and any trailing backslash directory separator, returning a clean, single-path value ready for use in DLL load operations invoked from D2KWUTIL.ATTEMPT_DLL_LOAD.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-040](#SP-040--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working copy of the input path (InPath) into a VARCHAR2(500) variable.
- Step 2 - Search the working path for the first occurrence of a semicolon character.
- Step 3 - If a semicolon is found, truncate the working path to retain only the characters that precede the semicolon, discarding everything from the semicolon onward.
- Step 4 - Inspect the last character of the (possibly truncated) working path for a trailing backslash ('\').
- Step 5 - If a trailing backslash is present, remove it by retaining only the substring up to but not including that final character.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition:
The working path contains at least one semicolon character (INSTR(vcPath, ';') > 0).

TRUE:
Truncate the working path to the substring preceding the first semicolon, effectively discarding any additional paths or parameters appended after the semicolon.

FALSE:
Leave the working path unchanged and proceed to the next check.

---

DP-002

Condition:
The last character of the working path is a backslash (SUBSTR(vcPath, -1, 1) = '\').

TRUE:
Remove the trailing backslash by returning the substring from position 1 to LENGTH(vcPath) - 1.

FALSE:
Leave the working path unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path that precedes the first semicolon is considered valid; any text from the semicolon onward is discarded to prevent multi-path or parameter injection into DLL load operations.
- BR-002 - A path must not end with a backslash directory separator; if one is present it must be stripped before the path is returned, ensuring consistent path formatting for downstream consumers.
- BR-003 - The input path is accepted as-is up to a maximum internal working length of 500 characters; the function does not validate or reject paths that exceed this limit at the signature level, so callers must ensure the supplied value does not exceed this boundary.
- BR-004 - The function is read-only with respect to all external state; it performs no database interactions and produces its result solely through string manipulation of the supplied input.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-066 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a controlled interface for writing a debug string to an external Windows API debug output channel. It accepts a text message, appends a newline character, and delegates the output call to the D2KWUTIL debug string function via the WIN_API framework. If the Windows API is unavailable or an unexpected error occurs, the procedure captures and registers a structured error before re-raising the exception to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-055](#SP-055--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-056](#SP-056--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input text parameter and construct a working buffer by appending a newline character (CHR(10)) to form the debug message string.
- Step 2 - Evaluate whether the Windows API integration layer is active by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the intended external function call by invoking REGISTER_FUNCTION_CALL, supplying the internal debug handle (iDebugString), the target function name 'd2kwutil_DebugString', and the argument type descriptor '*CHAR'.
- Step 4 - Execute the external debug output by calling D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle and the prepared buffer string.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the debug channel is unavailable.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, record a structured error via ADD_ERROR, identifying the procedure as 'WinDebug' and the reason as WIN_API.NoAPI, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, record a structured error via ADD_ERROR combining WIN_API.UError with any additional external error details retrieved through ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: The procedure registers the function call via REGISTER_FUNCTION_CALL and then invokes D2KWUTIL.D2KWUTIL_DEBUGSTRING to write the debug string to the external Windows API output channel.

FALSE: The WIN_API.NOT_AVAILABLE exception is raised, triggering the corresponding exception handler which logs the error via ADD_ERROR and re-raises.

---

DP-002

Condition: The WIN_API.NOT_AVAILABLE exception is caught in the exception block.

TRUE: ADD_ERROR is called with procedure name 'WinDebug' and error code WIN_API.NoAPI; the exception is then re-raised to propagate the failure to the caller.

FALSE: Not applicable - this handler is only entered when the specific exception is raised.

---

DP-003

Condition: An unhandled (OTHERS) exception is caught in the exception block.

TRUE: ADD_ERROR is called with procedure name 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS; the exception is then re-raised.

FALSE: Not applicable - this handler is only entered when an unexpected exception occurs.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must be augmented with a newline character (CHR(10)) before being passed to the external debug output function; the raw input value is never sent directly.
- BR-002 - Debug output may only be written when WIN_API.API_ENABLED is TRUE; any attempt to invoke the debug channel while the Windows API integration is inactive must result in a WIN_API.NOT_AVAILABLE exception.
- BR-003 - Every invocation of the external D2KWUTIL debug string function must be preceded by a call to REGISTER_FUNCTION_CALL to register the function handle and argument type metadata before execution.
- BR-004 - All exceptions must be re-raised after error registration; WINDEBUG does not silently suppress failures, ensuring that callers are always notified of debug channel errors.
- BR-005 - Unexpected runtime errors must be recorded with a composite error message that combines WIN_API.UError with any supplementary external error details obtained from ADD_EXTERNAL_ERRORS before re-raising.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

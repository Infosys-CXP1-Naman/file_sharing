# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Repair Order - VH_RO
    - Bodyshop Tracking - VT_VTS
    - Bay Master - VM_BAY_MAST
    - Holiday and Leave Calendar - WD_BTN
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Criteria (Service Advisor/Bodyshop Supervisor - before running the report)
    - Session and Global Variables (System - maintained for pagination support)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - PKG_VTS_BODYSHOP
    - VIEW_EXCEL_REP
    - GENERAL (DPL.pld)
    - WEBUTIL_CORE (webutil.pld)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-006 - D2KWUTIL.TRANSLATETYPE
    - SP-007 - GENERAL.ASK_CONFIRM
    - SP-008 - GENERAL.CHECK_FORM_FAILURE
    - SP-009 - GENERAL.DISP_TEXT
    - SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL
    - SP-011 - PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY
    - SP-012 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT
    - SP-013 - WEBUTIL.BLOCKING
    - SP-014 - WEBUTIL.CHECKLIBS
    - SP-015 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-016 - WEBUTIL.CLOSEBLOB
    - SP-017 - WEBUTIL.CLOSEFILE
    - SP-018 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-019 - WEBUTIL.ERROR
    - SP-020 - WEBUTIL.ERRORALERT
    - SP-021 - WEBUTIL.EXECUTE
    - SP-022 - WEBUTIL.FCLOSE
    - SP-023 - WEBUTIL.FOPEN
    - SP-024 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-025 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-026 - WEBUTIL.GETCLIENTSETTING
    - SP-027 - WEBUTIL.GETIMPLCLASS
    - SP-028 - WEBUTIL.GETLASTERROR
    - SP-029 - WEBUTIL.GETLASTERRORARGS
    - SP-030 - WEBUTIL.GETNUMBER
    - SP-031 - WEBUTIL.GETOSFAMILY
    - SP-032 - WEBUTIL.GETOUTPUT
    - SP-033 - WEBUTIL.GETPROPERTY
    - SP-034 - WEBUTIL.GETSTRING
    - SP-035 - WEBUTIL.GETVAR
    - SP-036 - WEBUTIL.GET_LINE
    - SP-037 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-038 - WEBUTIL.ID_NULL
    - SP-039 - WEBUTIL.INIT
    - SP-040 - WEBUTIL.INITWEBUTIL
    - SP-041 - WEBUTIL.ISERROR
    - SP-042 - WEBUTIL.IS_OPEN
    - SP-043 - WEBUTIL.LENGTH
    - SP-044 - WEBUTIL.LOG
    - SP-045 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-046 - WEBUTIL.PUT_LINE
    - SP-047 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-048 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-049 - WEBUTIL.REGISTERBEAN
    - SP-050 - WEBUTIL.REGISTER_FUNCTION
    - SP-051 - WEBUTIL.RELEASE_PROCESS
    - SP-052 - WEBUTIL.SETCLIENTSETTING
    - SP-053 - WEBUTIL.SETDATA
    - SP-054 - WEBUTIL.SETPROPERTY
    - SP-055 - WEBUTIL.SHOWBEANS
    - SP-056 - WEBUTIL.WRITEDATA
    - SP-057 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-058 - ADD_ERROR
    - SP-059 - ADD_EXTERNAL_ERRORS
    - SP-060 - BOOLTOCHAR
    - SP-061 - CLEAN_ERROR_STACK
    - SP-062 - DEBUGLOG
    - SP-063 - GET_ENVIRONMENT_STRING
    - SP-064 - READ_REGISTRY
    - SP-065 - REGISTER_FUNCTION_CALL
    - SP-066 - SETDEBUG
    - SP-067 - STRIPDIRSEP
    - SP-068 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_BODYSHOP_PROD - Business Requirements Document |
| Form Module Name | VR_BODYSHOP_PROD |
| Document Version | 1.0 |
| Date Created | August 17, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 17, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_bodyshop_prod Bodyshop Productivity Report form, its purpose, and roles referenced in the module.*

The **vr_bodyshop_prod** Oracle Forms module is the dealership **Bodyshop Productivity Report** screen. A service manager or reporting user opens the form, enters a billing date range of up to one month, and clicks Search. The form validates that both dates are provided, that neither exceeds the current date, and that the range does not span more than 31 days. On successful validation, the screen calculates and displays the number of active service bays, the number of working days in the period (excluding recorded holidays), the count of bodyshop job cards closed within the range, the total panel count, the total labour amount generated, and four derived productivity ratios - bay productivity, per-day productivity, panel productivity, and labour productivity. The user may also export the same productivity data as a CSV file by clicking the Excel export button, which opens the generated report in the browser. All calculations are scoped to the session's dealership, parent group, and location context.

### Key Stakeholders

*Who uses vr_bodyshop_prod*

| Stakeholder | Role |
| :--- | :--- |
| **Service Manager / Reporting User** | **Primary interactive user** of vr_bodyshop_prod. Selects the billing period, initiates the productivity calculation, reviews the results, and exports the data to CSV when required. |
| **Bodyshop Team** | Operational staff whose job-card and bay activity is measured; they do not interact with the form directly but their work is the subject of the report. |

---

---

## 3. System Context

*Describes the vr_bodyshop_prod module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_bodyshop_prod** module is the dealership **Bodyshop Productivity Report** screen. It gives service managers a consolidated view of bodyshop efficiency for any selected billing period and connects daily repair-order activity to management reporting and data exports.

**System purpose:** Allow a reporting user to select a billing date range, validate the range, and generate bodyshop productivity metrics - bay count, working days, job-card volume, panel count, labour amount, and four derived productivity ratios - scoped to the session dealership and location, with an option to export the results as a CSV file.

**In scope:**

- Select and validate a billing date range (From Date and To Date) with rules for null values, future dates, and a 31-day maximum span
- Calculate the number of active service bays for the session's dealer and location
- Calculate the count of working days in the selected range, excluding holidays
- Aggregate bodyshop job-card counts, panel counts, and labour amounts from repair-order records for the period
- Derive and display four productivity ratios: bay productivity, per-day productivity, panel productivity, and labour productivity
- Export the productivity data as a CSV file viewable in the browser
- Register session activity with the database application monitor at form open and close

**Process Name:** Bodyshop Productivity Reporting

**Process Owner:** Service Manager

**Process Objective:** Open the report screen, enter and validate the billing date range, retrieve productivity metrics from the dealership repair-order data, display the results, and optionally export them to CSV.

**Process Trigger:** Service manager needs to review bodyshop productivity for a past billing period

**Process Flow:**

The complete bodyshop productivity reporting process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         Service manager opens the Bodyshop Productivity Report screen.
         Session is registered with the database application monitor using the form module name.

STEP 2 ── DATE RANGE ENTRY - FROM DATE
         Manager enters the start date of the billing period.
         System validates that the From Date is not null.
         System validates that the From Date does not exceed the current date.

STEP 3 ── DATE RANGE ENTRY - TO DATE
         Manager enters the end date of the billing period.
         System validates that the To Date does not exceed the current date.
         System validates that the To Date is not earlier than the From Date.
         System validates that the date range does not exceed 31 days.

STEP 4 ── SEARCH INITIATED
         Manager clicks the Search button.
         System performs date-range validation checks before querying.

STEP 5 ── DATE VALIDATION - TO DATE NOT FUTURE
         System confirms the To Date is not greater than the current date.
         If the To Date is invalid, an error is displayed and the To Date field is focused.

STEP 6 ── DATE VALIDATION - FROM DATE NOT AFTER TO DATE
         System confirms the From Date does not exceed the To Date.
         If the From Date is after the To Date, an error is displayed.

STEP 7 ── BAY COUNT RETRIEVED
         System retrieves the number of active service bays from the bay master for the
         session's dealer and location.

STEP 8 ── WORKING DAY COUNT CALCULATED
         System counts the calendar days between From Date and To Date, excluding any dates
         recorded as holidays for the dealer and location.

STEP 9 ── REPAIR ORDER DATA QUERIED
         System queries bodyshop repair orders (category BANDP) for the session's dealer,
         parent group, and location where the bill date falls within the selected range.
         Job-card count, panel count, and labour amount are aggregated.

STEP 10 ── PRODUCTIVITY RATIOS CALCULATED
          System calculates four productivity ratios:
          Bay productivity (job cards ÷ active bays),
          Per-day productivity (job cards ÷ working days),
          Panel productivity (panels ÷ working days),
          Labour productivity (labour amount ÷ working days).

STEP 11 ── RESULTS DISPLAYED
          The results block is populated with: number of bays, working days, vehicle count,
          panel count, labour amount, bay productivity, per-day productivity, panel
          productivity, and labour productivity.
          Focus moves to the Excel export button.

STEP 12 ── OPTIONAL - EXPORT TO CSV
          ├── Manager clicks the Excel export button.
          │   System validates the date range (same checks as Search).
          │   System builds a dynamic SQL query embedding the date range.
          └── System executes the query, writes each result row as a CSV line to a server file,
              and opens the file in the browser for download.

STEP 13 ── SESSION CLOSED
          Manager exits the form.
          Session application info is cleared from the database monitor and global variables
          are erased.
```

**Major process interactions:**

- **Repair order data** - bodyshop job-card records (category BANDP) provide the job count, panel count, and labour amount for the selected period
- **Bay master** - active service bay records for the dealer and location supply the bay count used in productivity ratio calculations
- **Holiday/working-day calendar** - recorded non-working dates are excluded when counting working days in the selected range
- **VTS panel data** - VTS repair records provide the windshield panel counts aggregated per repair order
- **Browser / file server** - the CSV export is written to a server-side file path and opened in the user's browser

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration on Startup

**Business Description:**
When the Bodyshop Productivity Report form is opened, the system registers the module as active in the current database session, sets the form's report description and application identifier, maximises the main application window, and pre-populates the billing date range with sensible defaults. This allows database administrators and performance monitoring tools to identify the active business module, ensures the form title is correctly identified, and means the user can run a report immediately without manually entering dates.

**Actors:** Service Advisor / Bodyshop Supervisor (any user who opens the form)

**Preconditions:**
- The user has successfully logged into the dealership management system.
- A valid database session has been established for the user.

**Main Flow:**

**Step 1 - Application module registered in the database session**
Before the form is displayed (PRE-FORM), the system records the form identifier (`vr_bodyshop_prod`) as both the client information and the module name in the current database session using `DBMS_APPLICATION_INFO`. This registration enables database-level tracking of which business module is active, supporting operational monitoring and audit trail management.

**Step 2 - Report description and application identifier seeded**
When the form opens (WHEN-NEW-FORM-INSTANCE), the system sets the global report description to *"BodyShop Productivity Report(For Job Cards Billed and Punched in VTS Bodyshop)"* (`global.report_desc`) and the report description display field to the same value. The global application identifier is set to `vr_bodyshop_prod` (`global.app_id`), and the corresponding session parameter (`parameter.p_app_id`) is set to match. These values identify the form to downstream reporting and audit processes.

**Step 3 - Main window maximised**
The system maximises both the MDI host window and the form's main window (`WN_MAIN`) so that the full screen area is available to the user immediately on opening.

**Step 4 - Default billing date range pre-populated**
The system pre-fills the From Bill Date with the first day of the previous calendar month and the To Bill Date with today's date. This gives the user a sensible default reporting period that covers the most recent completed month without requiring manual date entry.

**Step 5 - Copyright declaration loaded**
The system retrieves the application copyright declaration from the database (`SF_COPYRIGHT_DECLARATION`) and stores it in the copyright display field on the query block.

---

---

#### Requirement ID: BR-002

**Requirement Title:** From Bill Date Entry and Validation

**Business Description:**
When the user enters the start date of the billing period for the Bodyshop Productivity Report, the system validates that the date is not blank and does not fall in the future. This prevents the report from being generated for periods that have not yet occurred. Once the date is validated, the cursor advances to the "To Bill Date" field so the user can complete the date range.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The Bodyshop Productivity Report form is open and the user has placed their cursor in the "From Bill Date" field.

**Main Flow:**

**Step 1 - From Bill Date entered and validated**
The user types a start date for the billing period. When the user moves off the field, the system checks that a date has been entered and that it is not later than today's date. If either check fails, the user is shown an alert message and the cursor remains on the field so the value can be corrected.

**Step 2 - Cursor advances to the To Bill Date field**
After the From Bill Date passes validation, the cursor moves directly to the "To Bill Date" field, ready for the user to enter the end of the billing period.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - From Bill Date is blank - *"From Date can not be null"*; the trigger is aborted and the cursor remains on the From Bill Date field.
- **BR-002-ES-02** - From Bill Date is later than today - *"From Date cannot be greater than Current Date"*; the trigger is aborted and the cursor remains on the From Bill Date field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Bill Date must be provided | Mandatory field check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT; condition: `FROM_JC_BILL_DT IS NULL` | When the user moves off the From Bill Date field | Ensures a start date is always supplied before the form proceeds, preventing an incomplete date range from being submitted | Alert displayed: *"From Date can not be null"*; trigger aborted; cursor stays on field |
| From Bill Date must not be in the future | Future-date check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT; condition: `FROM_JC_BILL_DT > SYSDATE` | When the user moves off the From Bill Date field after a non-null value is present | Prevents the report from being requested for a billing period that has not yet started | Alert displayed: *"From Date cannot be greater than Current Date"*; trigger aborted; cursor stays on field |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Must not be blank; must not be later than today's date | Alert: *"From Date can not be null"* if blank; *"From Date cannot be greater than Current Date"* if future |

---

---

#### Requirement ID: BR-003

**Requirement Title:** To Bill Date Entry and Validation

**Business Description:**
When the user enters the end date of the billing period for the Bodyshop Productivity Report, the system applies a set of date range validations: the end date must not be in the future, must not be earlier than the start date, and the total period must not exceed one month (31 days). If the "To Bill Date" field is left blank, the system automatically defaults it to today's date. These rules ensure the report is always requested for a valid, complete, and manageable billing period.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The "From Bill Date" has already been entered and validated.
- The user has placed their cursor in the "To Bill Date" field.

**Main Flow:**

**Step 1 - To Bill Date validated against date-range rules**
The user enters an end date for the billing period. When the user moves off the field, the system performs three sequential checks: (a) the end date must not be later than today; (b) the end date must not be earlier than the start date already entered; (c) the gap between start and end dates must not exceed 31 days. If any check fails, the user sees an alert message and the cursor stays on or returns to the "To Bill Date" field for correction.

**Step 2 - Blank To Bill Date automatically set to today**
If the "To Bill Date" field is still empty after the date-range checks (because none of them fired on a null value), the system silently sets it to today's date. No message is displayed; the field is populated automatically.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - End date is later than today - *"To Date cannot be greater than Current Date"*; the trigger is aborted and the cursor remains on the To Bill Date field.
- **BR-003-ES-02** - End date is earlier than the start date - *"To Date cannot be less than From Date"*; the trigger is aborted and the cursor remains on the To Bill Date field.
- **BR-003-ES-03** - Billing period exceeds 31 days - *"Report can be generated for maximum 1 Month"*; the cursor is moved back to the To Bill Date field and the trigger is aborted.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date must not be in the future | Future-date check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT; condition: `TO_BILL_DT > SYSDATE` | When the user moves off the To Bill Date field | Prevents reporting on billing periods that have not yet ended | Alert displayed: *"To Date cannot be greater than Current Date"*; trigger aborted |
| To Bill Date must not be before the From Bill Date | Date-sequence check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT; condition: `FROM_JC_BILL_DT > TO_BILL_DT` | When the user moves off the To Bill Date field | Ensures the billing period is a valid, forward-moving date range | Alert displayed: *"To Date cannot be less than From Date"*; trigger aborted |
| Billing period must not exceed 31 days | Period-length check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT; condition: `TO_BILL_DT - FROM_JC_BILL_DT > 31` | When the user moves off the To Bill Date field | Limits the report range to a maximum of one month to prevent excessively large data sets | Alert displayed: *"Report can be generated for maximum 1 Month"*; cursor moved to To Bill Date field; trigger aborted |

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 2) If the "To Bill Date" field is blank when the second anonymous PL/SQL block executes, the system automatically sets it to today's date without prompting the user; no alert is shown.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Bill Date (`TO_BILL_DT`) | Conditional - defaults to today if left blank | Date | DD-MM-RRRR | N/A | N/A | From Bill Date entered and validated | Must not be later than today; must not be before From Bill Date; must be within 31 days of From Bill Date | Alert: *"To Date cannot be greater than Current Date"*; *"To Date cannot be less than From Date"*; *"Report can be generated for maximum 1 Month"* |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Read for date-sequence and range-length comparison | Alerts as per Step 1 validations |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Generate Bodyshop Productivity Report on Screen

**Business Description:**
When the user clicks the Search button after entering a valid billing date range, the system retrieves bodyshop productivity data for the dealership, group, and location associated with the current user's session. It calculates key performance indicators - including the number of active bays, working days in the period, vehicles repaired, panels repaired, labour revenue generated, and four derived productivity ratios - and displays the results on screen. This gives bodyshop management an immediate, quantified view of workshop efficiency for the selected period.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- A valid billing date range has been entered with the "From Bill Date" earlier than the "To Bill Date" and the period not exceeding 31 days.
- The current user's session carries the dealership, group, and location context needed to scope the data.

**Main Flow:**

**Step 1 - Date range re-validated before the query runs**
Before any data is retrieved, the system re-checks that the end date of the billing range is not in the future and is not earlier than the start date. If either check fails, the user sees an alert and the cursor moves to the "To Bill Date" field. These checks match the field-level validations and serve as a final gate before the database query executes.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date must not be in the future | Re-validation check - WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH; condition: `TO_BILL_DT > SYSDATE` | When the user clicks the Search button | Prevents the productivity query from running against an incomplete or future billing period | Alert displayed: *"To Date cannot be greater than Current Date"*; cursor moved to To Bill Date field; trigger aborted |
| To Bill Date must not be before the From Bill Date | Date-sequence re-check - WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH; condition: `FROM_JC_BILL_DT > TO_BILL_DT` | When the user clicks the Search button | Ensures the query date range is valid before any data is fetched | Alert displayed: *"To Date cannot be less than From Date"*; cursor moved to To Bill Date field; trigger aborted |

**Step 2 - Productivity metrics calculated and displayed**
The system queries the bodyshop repair orders for the current dealership and location, filtered to the Body and Paint repair category and the selected billing period. For each dealership/location combination found, it calculates the number of active service bays, the number of working days in the period, the number of vehicles repaired (job count), the total panels repaired, and the total labour revenue. It then calculates four productivity ratios: vehicles repaired per active bay, vehicles repaired per working day, panels repaired per working day, and labour revenue per working day. The results are loaded into the on-screen results area. After loading, the cursor moves to the Export to Excel button.

*Procedures called:*
- **PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY** ([SP-003](#SP-003--PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY)) - PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY - retrieves the total number of active service bays configured for the specified dealer group, dealership, and location. Returns zero if no active bays are found or an error occurs.
    * **Step 1** - Using the dealer group, dealership, and location identifiers supplied, the function looks up the bodyshop bay configuration to count bays currently marked as active.
    * **Step 2** - Returns the total count of active bays. If no bays are found or an unexpected error occurs, the function returns zero to allow calculations to continue.

- **PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT** ([SP-004](#SP-004--PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT)) - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT - counts the number of actual working days within the selected billing period for the specified dealer group, dealership, and location, taking the holiday and leave calendar into account.
    * **Step 1** - Starting from the first day of the selected billing period, the function iterates through each calendar day up to and including the last day.
    * **Step 2** - For each day, it checks the holiday and leave calendar to determine whether that day has been designated as a non-working day for the dealership.
    * **Step 3** - Days that do not appear on the non-working-day calendar are counted as working days.
    * **Step 4** - Returns the total number of working days found in the period.

- **PKG_VTS_BODYSHOP.SF_GET_PANEL** ([SP-002](#SP-002--PKG_VTS_BODYSHOP.SF_GET_PANEL)) - PKG_VTS_BODYSHOP.SF_GET_PANEL - retrieves the total number of body panels repaired for a given repair order at the specified dealer group, dealership, and location.
    * **Step 1** - Using the repair order number and the dealer group, dealership, and location identifiers, the function looks up the bodyshop tracking records for that repair order.
    * **Step 2** - It sums the total number of panels recorded across all matching tracking records for the repair order.
    * **Step 3** - Returns the summed panel count, treating any absence of records as zero.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Active bay count retrieved per dealership/location | Bay count - PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY [SP-003] | When the Search button is clicked and the date range passes validation | Provides the denominator for the bay productivity ratio; returns zero if no active bays are configured | Bay productivity ratio evaluates to zero (no alert displayed) |
| Working day count calculated for the billing period | Working day count - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT [SP-004] | When the Search button is clicked and the date range passes validation | Provides the denominator for the per-day productivity ratios; excludes holidays and leave days from the count | Per-day ratios evaluate to zero if the working day count is zero (no alert displayed) |
| Panel count summed per repair order | Panel total - PKG_VTS_BODYSHOP.SF_GET_PANEL [SP-002] | When the Search button is clicked and the date range passes validation | Provides the total panel repairs for the period used in the panels-per-day productivity ratio | Panel count evaluates to zero if no panel tracking records exist for the repair orders in the period |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - End date is in the future (re-check at button click) - *"To Date cannot be greater than Current Date"*; cursor moved to To Bill Date field; trigger aborted.
- **BR-004-ES-02** - End date is before start date (re-check at button click) - *"To Date cannot be less than From Date"*; cursor moved to To Bill Date field; trigger aborted.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Used as the lower bound of the billing period query | Alerts per Step 1 re-validation |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | From Bill Date entered | Used as the upper bound of the billing period query; must not be future or before From Bill Date | Alerts per Step 1 re-validation |
| Number of Bays (`NO_OF_BAYS`) | Auto-populated | Numeric | N/A | N/A | Calculated by SF_GET_VTS_NO_BAY | Date range validated | Read-only; system-calculated from active bay configuration | N/A |
| Number of Working Days (`NO_OF_WORK_DAYS`) | Auto-populated | Numeric | N/A | N/A | Calculated by SF_GET_WORKING_DAY_CNT | Date range validated | Read-only; system-calculated from holiday/leave calendar | N/A |
| Number of Vehicles Repaired (`NO_OF_VEH_REP`) | Auto-populated | Numeric | N/A | N/A | Count of repair orders in period | Date range validated | Read-only; system-calculated from repair order data | N/A |
| Number of Panels Repaired (`NO_OF_PANELS`) | Auto-populated | Numeric | N/A | N/A | Sum from SF_GET_PANEL per repair order | Date range validated | Read-only; system-calculated per repair order | N/A |
| Labour Revenue Generated (`LAB_GEN`) | Auto-populated | Numeric | N/A | N/A | Sum of labour amounts from repair orders | Date range validated | Read-only; system-calculated from repair order labour charges | N/A |
| Bay Productivity (`BAY_PROD`) | Auto-populated | Numeric | Decimal (2 places) | N/A | Vehicles repaired ÷ active bays | Bay count and repair order data available | Read-only; calculated as vehicles repaired divided by number of active bays, rounded to 2 decimal places | N/A |
| Per-Day Productivity (`PER_DAY_PROD`) | Auto-populated | Numeric | Decimal (2 places) | N/A | Vehicles repaired ÷ working days | Working day count and repair order data available | Read-only; calculated as vehicles repaired divided by working days, rounded to 2 decimal places | N/A |
| Panel Productivity (`PANEL_PROD`) | Auto-populated | Numeric | Decimal (2 places) | N/A | Panels repaired ÷ working days | Working day count and panel count available | Read-only; calculated as panels repaired divided by working days, rounded to 2 decimal places | N/A |
| Labour Productivity (`LABOUR_PROD`) | Auto-populated | Numeric | Decimal (2 places) | N/A | Labour revenue ÷ working days | Working day count and labour revenue available | Read-only; calculated as labour revenue divided by working days, rounded to 2 decimal places | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Export Bodyshop Productivity Data to Excel (CSV)

**Business Description:**
When the user clicks the "Export to Excel" button, the system assembles the same productivity data shown on screen and generates a downloadable CSV file for the current user. The file is named using the user's login identifier and the current date and time to ensure it is unique. The exported file contains all nine productivity metrics as comma-separated columns and is opened directly in the user's browser for download. This allows management to save, distribute, and further analyse the bodyshop productivity figures outside the system.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The billing date range has been entered and a valid productivity query period has been established.
- The user has navigated to or clicked the "Export to Excel" button.

**Main Flow:**

**Step 1 - Export filename generated**
The system builds a unique filename for the output CSV file by combining the current user's login identifier with a timestamp (formatted as YYYYMMDDHH24MISS), followed by a `.CSV` extension.

**Step 2 - Productivity query assembled and stored**
The system constructs the SQL query that retrieves the same productivity metrics as the on-screen report, embedding the current billing date range and the session's dealership, group, and location identifiers directly into the query string. The assembled query string is stored in the internal query field for use in the next step. The embedded query calls the same database functions used by the on-screen report.

**Step 3 - CSV file generated and opened for download**
The system passes the assembled query and filename to the file-generation routine, which executes the query, writes each result row to a CSV file on the application server, and opens the file in the user's browser for download.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#SP-001--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the assembled productivity query, writes each result row to a CSV file on the application server, and opens the file in the user's browser for download. Raises a trigger failure and shows an error message if an unexpected exception occurs during file generation.
    * **Step 1** - A unique CSV filename is constructed from the current user's login identity and the current timestamp.
    * **Step 2** - If the file path contains spaces in any folder name, the path is redirected to the C:\ drive root and the user is informed via a status message.
    * **Step 3** - The system checks whether a temporary in-memory data group named 'DataRecordSet' already exists; if so, it is removed before a new one is created.
    * **Step 4** - A new in-memory data group is created from the provided query and populated with the query results.
    * **Step 5** - The total number of rows returned is checked; if it exceeds 65,535, the count is capped at 65,535 and the user is informed that the Excel row limit has been reached.
    * **Step 6** - The server-side export path is read from the configuration file at `/reports/DMS/excelpath.txt`.
    * **Step 7** - A CSV file is created at the resolved server path, and each row from the data group is written to the file as a line of text.
    * **Step 8** - The file is closed and the URL to the generated CSV is opened in the user's browser in a new window for download.
    * **Step 9** - If any unexpected error occurs during file generation, an error message is displayed combining the system error code and description, and the trigger is aborted.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path spaces redirected to C:\ drive | Path-spaces check - VIEW_EXCEL_REP [SP-001]; condition: `INSTR(FILENAME, ' ') > 0` | When the Export to Excel button is clicked and the file generation routine begins | Prevents file-system errors caused by spaces in folder names on the application server | File path adjusted to C:\ root; user informed: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* |
| Export row count limited to 65,535 | Excel row limit check - VIEW_EXCEL_REP [SP-001]; condition: `the_rowcount > 65536` | When the in-memory data group is populated from the query | Prevents the generated CSV from exceeding the maximum number of rows that Excel can open | Row count capped at 65,535; user informed: *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* |
| Unexpected error during file generation | General exception handler - VIEW_EXCEL_REP [SP-001]; WHEN OTHERS handler | At any point during file creation or data writing | Ensures any unhandled system error is surfaced to the user rather than silently lost | Error message displayed as *"Error  - "* followed by the system error code and error text (dynamic); trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-01** - Path contains a space in a folder name - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; path adjusted to C:\ root automatically; export continues.
- **BR-005-IC-02** - Result set exceeds Excel row limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues with the first 65,535 rows.
- **BR-005-ES-01** - Unexpected error during file generation - *"Error  - "* followed by the system-generated error code and error text (dynamic); trigger aborted.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Embedded into the export query as the lower date bound | N/A |
| To Bill Date (`TO_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | N/A | Embedded into the export query as the upper date bound | N/A |
| Query Text (`TXT`) | Auto-populated | Text | Up to 5000 characters | N/A | System-generated SQL | Date range entered | Read-only internal field; stores the assembled export query string | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Form Exit and Session Cleanup

**Business Description:**
When the user presses the Exit key to close the Bodyshop Productivity Report form, the system clears the module tracking information from the current database session and erases any pagination-related global variables before closing the form without saving any pending changes. This ensures that session metadata does not persist after the user leaves the module, keeping the database session context clean for the next operation.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The Bodyshop Productivity Report form is open.

**Main Flow:**

**Step 1 - Database session context cleared**
When the user presses the Exit key, the system immediately clears the module tracking identifier and the module name from the current database session. This removes the record that the Bodyshop Productivity Report was active in this session.

**Step 2 - Pagination global variables erased**
The system erases the three pagination-related global variables that control record navigation (the "from" record number, the "to" record number, and the page increment size). This prevents stale navigation state from persisting into any subsequent form opened in the same session.

**Step 3 - Form closed without saving**
The form is closed immediately, discarding any unsaved changes, and the user is returned to the calling application or menu.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Global "From" Record Number (`global.from_no`) | Auto-populated | Numeric | N/A | N/A | N/A | Form open | Erased on exit; session-scope only | N/A |
| Global "To" Record Number (`global.to_no`) | Auto-populated | Numeric | N/A | N/A | N/A | Form open | Erased on exit; session-scope only | N/A |
| Global Page Increment (`global.increment_no`) | Auto-populated | Numeric | N/A | N/A | N/A | Form open | Erased on exit; session-scope only | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form Clear Action (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
(COMMENTED OUT / INACTIVE - does not execute) This capability was intended to clear the report criteria and results from the screen, resetting the form to its initial state with default values, re-enabling editable fields, and re-initialising global navigation variables. The implementation is fully commented out and does not run in the current version of the form.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- Not applicable - this capability does not execute.

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)**
The KEY-CLRFRM trigger body begins with `null;` followed by a fully commented-out block. The only active statement is the `null;` no-op. No business logic executes when the clear-form key is pressed.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Custom Error Handling Override (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
(COMMENTED OUT / INACTIVE - does not execute) This capability was intended to provide a customised response to Oracle Forms system errors by suppressing specific error numbers and reformatting others into a friendlier display. The entire implementation is commented out; the active trigger body contains only a no-op statement. Standard Oracle Forms error handling is in effect.

**Actors:** N/A - does not execute.

**Preconditions:**
- Not applicable - this capability does not execute.

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)**
The ON-ERROR trigger at form level begins with `null;` followed by the fully commented-out custom error-handling logic. No custom error handling runs in the current version.

---

---

#### Requirement ID: BR-009

**Requirement Title:** System Message Override for Field-Type Errors

**Business Description:**
When Oracle Forms raises an internal message during a user action, the system intercepts specific message codes and replaces the default Forms message with a formatted error display before halting the trigger. This ensures that field-type validation errors (such as entering an alphabetic character in a numeric field) are presented in a consistent, user-friendly style rather than the raw Oracle Forms message text.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The Bodyshop Productivity Report form is open.
- Oracle Forms has raised an internal message during a user action.

**Main Flow:**

**Step 1 - Message code inspected**
When a Forms message fires, the system captures the message code (`ERROR_CODE`), the message text (`ERROR_TEXT`), and the message type (`ERROR_TYPE`).

**Step 2 - Field-type error codes intercepted and redisplayed**
If the message code is `40209` (maximum field length exceeded / invalid character for field type) or `40207` (invalid value entered), the system suppresses the standard Forms message and instead displays a formatted error combining the error type, the code number, and the original error text. The trigger is then aborted to keep the user on the failing field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message code is a field-type error | Error-code check - ON-MESSAGE; condition: `errnum IN (40209, 40207)` | When Oracle Forms raises an internal message | Replaces raw Forms error messages with a formatted display for the two most common field-type input errors | Custom error displayed as `<type>-<code>: <text>`; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Message code is `40209` or `40207` - formatted error message displayed (`<error type>-<error code>: <error text>`); trigger aborted; user remains on the failing field.
- **BR-009-SM-01** - Message code is any other value - no interception; standard Forms message handling continues.

---

---

#### Requirement ID: BR-010

**Requirement Title:** List-of-Values Key Override (INACTIVE - does not execute)

**Business Description:**
(INACTIVE - does not execute) This trigger was intended to override the default list-of-values invocation behaviour when the user presses the LOV key. The trigger is marked inactive and does not execute.

**Actors:** N/A - does not execute.

**Preconditions:**
- Not applicable - this capability does not execute.

**Main Flow:**

**Step 1 - (INACTIVE - does not execute)**
The KEY-LISTVAL trigger at form level is marked inactive. No business logic executes.

---

---

#### Requirement ID: BR-011

**Requirement Title:** Save/Commit Action

**Business Description:**
When the user presses the Commit key or clicks the Save toolbar button (when it is enabled), the system validates all pending field values, commits any outstanding changes to the database, and then clears the form ready for the next use. This provides a consistent save-and-clear cycle for the form without requiring a separate clear action.

**Actors:** Service Advisor / Bodyshop Supervisor

**Preconditions:**
- The Bodyshop Productivity Report form is open.
- For the Save toolbar button: the Save button (PB_BLK.PB_SAVE) must be in an enabled state.

**Main Flow:**

**Step 1 - Toolbar Save button checked for availability**
When the user clicks the Save button on the toolbar, the system first checks whether the Save button is currently enabled. If the button is disabled, no action is taken. If it is enabled, the system proceeds to commit by firing the standard Commit Form key action.

**Step 2 - Form input validated before commit**
When the Commit key is pressed (directly or via the toolbar Save button), the system runs form-level validation (`ENTER`) to ensure all required fields and business rules have been satisfied. If validation fails, the commit is halted and the user is kept on the form to correct any errors.

**Step 3 - Changes committed to the database**
Once validation passes, the system executes `COMMIT_FORM` to write any pending changes to the database. After the commit, the system performs a second failure check to confirm the commit completed successfully. If a failure is detected at this stage, the user remains on the form.

**Step 4 - Form cleared after successful commit**
Following a successful commit, the form is automatically cleared (`CLEAR_FORM`) so that the screen is reset and ready for the next operation.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-01** - Save button is disabled when clicked - no action is taken; the commit sequence does not start.
- **BR-011-ES-01** - Validation fails at Step 2 - commit is aborted; user remains on the form to correct the failing field or rule.
- **BR-011-ES-02** - Commit fails at Step 3 - form is not cleared; user remains on the form.
- **BR-011-SM-01** - Commit succeeds - form is cleared and ready for next use.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Record Navigation Key Overrides on Query Block (INACTIVE - does not execute)

**Business Description:**
(INACTIVE - does not execute) Two triggers were defined on the query criteria block to override the cursor-up and cursor-down keyboard navigation keys. Both trigger bodies contain only a `NULL;` no-op statement and are marked inactive; neither executes.

**Actors:** N/A - does not execute.

**Preconditions:**
- Not applicable - these capabilities do not execute.

**Main Flow:**

**Step 1 - (INACTIVE - does not execute)**
Both KEY-UP and KEY-DOWN triggers on the query criteria block contain `NULL;` and are marked inactive. No navigation override runs.

---

---

#### Requirement ID: BR-013

**Requirement Title:** WebUtil Component Infrastructure (INACTIVE - does not execute)

**Business Description:**
(INACTIVE - does not execute) The form contains a WebUtil infrastructure block that hosts multiple component event handlers. All triggers attached to this block - including the push-button handler and all custom-item-event handlers for the file, host, session, file-transfer, OLE, C-API, and browser function components - are marked inactive and do not execute any business logic.

**Actors:** N/A - does not execute.

**Preconditions:**
- Not applicable - these capabilities do not execute.

**Main Flow:**

**Step 1 - (INACTIVE - does not execute)**
The WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY and all eight WHEN-CUSTOM-ITEM-EVENT triggers on the WebUtil component items are marked inactive. No business logic executes from these triggers.

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Bill Date Is Required | Validation | BR-002 | The "From Bill Date" field is left blank when the user moves off it | Block further processing and show the alert *"From Date can not be null"*; cursor stays on the From Bill Date field | Prevents the report from being submitted without a start date, ensuring a complete billing period is always defined |
| BRC-002 | From Bill Date Must Not Be in the Future | Validation | BR-002 | The "From Bill Date" entered is later than today's date | Block further processing and show the alert *"From Date cannot be greater than Current Date"*; cursor stays on the From Bill Date field | Prevents requests for reports covering periods that have not yet occurred |
| BRC-003 | To Bill Date Must Not Be in the Future | Validation | BR-003, BR-004 | The "To Bill Date" entered or already on screen is later than today's date | Block further processing and show the alert *"To Date cannot be greater than Current Date"*; cursor moves to or stays on the To Bill Date field | Ensures reports are only generated for completed billing periods |
| BRC-004 | To Bill Date Must Not Be Earlier Than From Bill Date | Validation | BR-003, BR-004 | The "To Bill Date" is earlier than the "From Bill Date" already entered | Block further processing and show the alert *"To Date cannot be less than From Date"*; cursor moves to or stays on the To Bill Date field | Ensures the billing period represents a valid forward-moving date range |
| BRC-005 | Billing Period Must Not Exceed 31 Days | Constraint | BR-003 | The number of days between "From Bill Date" and "To Bill Date" is greater than 31 | Block further processing and show the alert *"Report can be generated for maximum 1 Month"*; cursor moved back to the To Bill Date field | Limits the data set to a manageable monthly range and prevents excessively long-running queries |
| BRC-006 | To Bill Date Defaults to Today When Left Blank | Derivation | BR-003 | The "To Bill Date" field is still empty after the date-range validation checks have run without error | Automatically set the To Bill Date to today's date; no message is shown to the user | Provides a sensible default for the end of the billing period when the user does not specify one |
| BRC-007 | CSV Export Row Count Limited to 65,535 | Constraint | BR-005 | The productivity query returns more than 65,535 rows | Truncate the export to the first 65,535 rows and show the message *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues | Prevents the generated CSV from exceeding the maximum row limit of older Excel versions |
| BRC-008 | CSV File Path Spaces Redirected to C:\ Drive | Derivation | BR-005 | The generated CSV file path contains a space in one or more folder names | Redirect the file path to the C:\ drive root and inform the user: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Prevents file-system errors on the application server caused by spaces in folder paths |

**Total Business Rules Identified: 8**

---

## 6. Data Requirements

*This section describes the business entities queried by the Bodyshop Productivity Report form, the data captured from the user as report criteria, the reference data used to perform calculations, and the lifecycle of that data within the form's operation.*

### 6.1 Business Entities and Relationships

*The form reads data from the Repair Order register and references supporting configuration tables to calculate and display bodyshop productivity metrics. No records are created or updated by this form; all data access is read-only.*

#### Repair Order - VH_RO

The Repair Order table holds the complete register of vehicle repair jobs processed by the dealership. This form queries repair orders belonging to the Body and Paint repair category within the selected billing date range, using them to count the number of vehicles repaired and to sum the labour revenue generated during the period. Each record represents one completed repair job for a specific vehicle at a specific dealership and location.

#### Bodyshop Tracking - VT_VTS

The Bodyshop Tracking table records the detailed body and paint work carried out for each repair order, including panel counts. This form uses it - via the panel-count calculation function - to sum the total number of body panels repaired across all repair orders in the selected period.

#### Bay Master - VM_BAY_MAST

The Bay Master table holds the configuration of service bays at each dealership location. This form uses it - via the bay-count calculation function - to determine how many bays are currently active and available for body and paint work, providing the denominator for the bay productivity ratio.

#### Holiday and Leave Calendar - WD_BTN

The Holiday and Leave Calendar records days designated as non-working days (public holidays, closures, etc.) for each dealership location. This form uses it - via the working-day-count calculation function - to exclude non-working days from the date range when calculating per-day productivity ratios.

#### Entity Relationships

The Repair Order is the central data entity for this form's productivity calculations. The Bodyshop Tracking table records detailed work - including panel counts - at the repair order level. The Bay Master and Holiday and Leave Calendar are independent configuration tables linked at the dealership/location level; they provide the active bay count and working day count used as denominators in the productivity ratios.

```
VM_BAY_MAST (Bay Master)
  - linked by dealer group + dealership + location

WD_BTN (Holiday/Leave Calendar)
  - linked by dealer group + dealership + location

VH_RO (Repair Order)
  └── VT_VTS (Bodyshop Tracking)    <- linked by dealer group + dealership + location + repair order number
```

### 6.2 Data Capture Requirements

*The form captures a billing date range from the user as query criteria. All result fields are system-calculated and read-only. No records are written to the database.*

#### Report Criteria (Service Advisor/Bodyshop Supervisor - before running the report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| From Bill Date (`FROM_JC_BILL_DT`) | Yes | The start date of the billing period for which bodyshop productivity is to be reported | Must not be blank; must not be later than today's date |
| To Bill Date (`TO_BILL_DT`) | Conditional | The end date of the billing period; defaults to today if left blank | Must not be later than today; must not be earlier than the From Bill Date; the period must not exceed 31 days |

#### Session and Global Variables (System - maintained for pagination support)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Pagination "From" Record (`global.from_no`) | Auto-Populated | Session-level variable holding the starting record number for pagination; set to 1 on initialisation and erased on form exit | System-managed; not user-editable |
| Pagination "To" Record (`global.to_no`) | Auto-Populated | Session-level variable holding the ending record number for pagination; set to 10 on initialisation and erased on form exit | System-managed; not user-editable |
| Page Increment (`global.increment_no`) | Auto-Populated | Session-level variable holding the number of records per page; set to 10 on initialisation and erased on form exit | System-managed; not user-editable |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form to support the bodyshop productivity calculations.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Repair Orders - Body and Paint Category (VH_RO, filtered by `rcateg_cd = 'BANDP'`) | Provides the count of vehicles repaired and the total labour revenue for the selected period and dealership/location | When the user clicks the Search button or the Export to Excel button; data is filtered to the billing date range and the current session's dealership context |
| Active Service Bays (VM_BAY_MAST, via PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY) | Provides the total count of active service bays for the current dealership and location, used as the denominator for the bay productivity ratio | When the productivity query runs on Search or Export to Excel; filtered to the current dealership/location context (EXTERNAL / NOT IN BUNDLE - VM_BAY_MAST not supplied in source bundle) |
| Holiday and Leave Calendar (WD_BTN, via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT) | Provides the list of non-working days for the dealership location within the billing period, used to calculate the working day count | When the productivity query runs on Search or Export to Excel; filtered to the current dealership/location and the selected date range (EXTERNAL / NOT IN BUNDLE - WD_BTN not supplied in source bundle) |
| Bodyshop Panel Records (VT_VTS, via PKG_VTS_BODYSHOP.SF_GET_PANEL) | Provides the panel count per repair order for the selected period, summed to produce the total panels repaired metric | When the productivity query runs on Search or Export to Excel; filtered per repair order to the current dealership/location context (EXTERNAL / NOT IN BUNDLE - VT_VTS not supplied in source bundle) |
| Export Path Configuration (`/reports/DMS/excelpath.txt`) | Provides the server-side directory path where generated CSV export files are stored | When the user clicks the Export to Excel button and the VIEW_EXCEL_REP procedure begins file creation (EXTERNAL / NOT IN BUNDLE - server-side file, not in source bundle) |

### 6.4 Data Lifecycle

*Describes how data flows through this form. This form is read-only - it queries existing records from the database and displays calculated results. It does not create, update, or delete any database records.*

**Creation**

- No records are created by this form. The bodyshop productivity data displayed on screen and exported to CSV is derived entirely from existing repair order, bay, panel, and calendar records held in the database.

**Updates**

- No database records are updated by this form. The results block is a non-database display area populated from an in-memory cursor; its values exist only for the duration of the current session.

**Save and Commit**

- There is no save or commit operation in this form. The KEY-COMMIT trigger is inactive. No data entered or calculated within the form is written back to the database.

**Retention and Audit**

- This form does not create, modify, or delete audit trail records. Session context is registered in the database via DBMS_APPLICATION_INFO at startup (PRE-FORM trigger) and cleared on exit (KEY-EXIT trigger); this is operational session metadata only, not a business audit record.
- The generated CSV file is written to a server path derived from the configuration file `/reports/DMS/excelpath.txt`. File retention on that server path is not governed by this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| BANDP | Body and Paint - the service category code used to identify bodyshop repair orders in the DMS | Body & Paint | Bodyshop, Repair Order, Job Card |
| Bay | A physical workspace in the bodyshop where a vehicle is serviced or repaired | Service Bay | Bay Productivity, VM_BAY_MAST |
| Bay Productivity | A derived metric calculated as total job cards divided by the number of active bays in the selected period | - | Productivity, Job Card, Bay |
| Billing Date | The date a job card or repair order is billed; used as the filter criterion for the report date range | Bill Date | From Date, To Date, Job Card |
| Bodyshop | The vehicle repair and paint department within a dealership | - | BANDP, Bay, Repair Order |
| BR-T-PKG-VTS-BODYSHOP | Business-requirement traceability identifier for the PKG_VTS_BODYSHOP database package in this BRD | - | PKG_VTS_BODYSHOP |
| CB_DOC | Control block displaying calculated bodyshop productivity results | - | CB_DOC_QUERY, Block |
| CB_DOC_QUERY | Control block holding the search criteria (date range) and action buttons for the report | - | CB_DOC, Block |
| CSV | Comma-Separated Values - a plain-text file format used for the productivity data export | Excel Export | Export |
| Dealer | The dealership identifier (dealer map code) that scopes all data queries on this form | Dealer Map Code | Parent Group, Location |
| DMS | Dealer Management System - the integrated software platform for dealership operations | - | Bodyshop, Repair Order |
| DPL | Shared PL/SQL program library providing common Oracle Forms utility procedures (DPL.pld) | - | PLD, Utility Library |
| From Date | The start date of the billing period entered by the user on the search criteria screen | FROM_JC_BILL_DT | To Date, Billing Date |
| Holiday | A non-working date recorded in the working-day calendar for a dealer and location; excluded from the working-day count | Leave Date | Working Day, WD_BTN |
| Job Card | A repair order record in the bodyshop capturing the work done on a vehicle, referenced by RO number | RO, Repair Order | BANDP, VH_RO |
| Labour Amount | The total labour billing value generated from bodyshop repair orders in the selected period | LAB_AMT | Labour Productivity |
| Labour Productivity | A derived metric calculated as total labour amount divided by the number of working days | - | Productivity, Working Day |
| Location | The service centre or branch code (loc_cd) that scopes data queries alongside dealer and parent group | Loc_Cd | Dealer, Parent Group |
| Panel Count | The total count of windshield panels processed in the bodyshop in the selected period, sourced from VTS records | PANEL_CNT | Panel Productivity, VT_VTS |
| Panel Productivity | A derived metric calculated as total panel count divided by the number of working days | - | Productivity, Working Day, Panel Count |
| Parent Group | The parent dealer group code that scopes all queries to the correct business entity | PARENT_GROUP | Dealer, Location |
| PCK | Oracle PL/SQL Package source file (.pck) containing the bodyshop calculation functions | Package | PKG_VTS_BODYSHOP, PLD |
| Per-Day Productivity | A derived metric calculated as total job cards divided by the number of working days | - | Productivity, Working Day, Job Card |
| PKG_VTS_BODYSHOP | Oracle database package providing the bodyshop productivity calculation functions (bay count, working days, panel count) | - | sf_get_vts_no_bay, sf_get_working_day_cnt, sf_get_panel |
| PLD | Oracle Forms PL/SQL Library file (.pld) providing shared utility routines attached to the form | Program Library | DPL, Webutil |
| Productivity | A general term for the output-per-unit-resource ratios calculated by the report (bay, per-day, panel, and labour) | - | Bay Productivity, Per-Day Productivity, Panel Productivity, Labour Productivity |
| Repair Order | The primary vehicle service document in the DMS; referred to as RO or job card in the bodyshop context | RO, Job Card | BANDP, VH_RO |
| RO | Repair Order - abbreviated form used throughout the DMS and in database table names | Repair Order, Job Card | BANDP, VH_RO |
| sf_get_panel | Database function that returns the total windshield panel count for a given repair order from VTS records | - | PKG_VTS_BODYSHOP, Panel Count |
| sf_get_vts_no_bay | Database function that returns the count of active service bays for a dealer and location | - | PKG_VTS_BODYSHOP, Bay |
| sf_get_working_day_cnt | Database function that counts working days in a date range by excluding holidays for a dealer and location | - | PKG_VTS_BODYSHOP, Working Day, Holiday |
| To Date | The end date of the billing period entered by the user on the search criteria screen | TO_BILL_DT | From Date, Billing Date |
| VTS | Vehicle Tracking System - the system that records bodyshop stage and panel data used to calculate panel counts | - | Panel Count, VT_VTS |
| Webutil | Oracle Forms client-extension library providing file-transfer and browser-integration utilities | - | PLD, VIEW_EXCEL_REP |
| Working Day | A calendar day within the report date range that is not recorded as a holiday for the dealer and location | - | Holiday, sf_get_working_day_cnt |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_bodyshop_prod (VR_BODYSHOP_PROD)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Bodyshop Productivity Report (inherited from DPL.olb object group; no locally defined window in form XML)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_VTS_BODYSHOP
- Source artifacts: `vr_bodyshop_prod_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); PCK `PKG_VTS_BODYSHOP.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier for the current session; read at form startup to scope application-level behaviour |
| APP_LOG | Char | Trigger | Application logging flag or reference used for session audit trail |
| COMP_FA | Char | ProgramUnit / Trigger | Company/FA code for filtering bodyshop repair orders |
| CURRENCY | Char | Trigger | Currency code applicable to the current dealer session; used for monetary display formatting |
| DEALER | Number | ProgramUnit / Trigger | Dealer map code identifying the dealership for data scope |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session; used to constrain period-based queries |
| FIN_END | Char | Trigger | Financial year end date for the current session; used to constrain period-based queries |
| FROM_NO | Number | ProgramUnit / Trigger | Starting record number for pagination of displayed results |
| FROM_REC | Number | ProgramUnit / Trigger | Starting record index used for result-set navigation |
| INCREMENT_NO | Number | ProgramUnit / Trigger | Page size increment for record navigation (default 10) |
| LOC_CD | Char | ProgramUnit / Trigger | Location code identifying the service centre or branch |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent dealer group code used to scope all queries |
| PRINCIPAL | Char | Trigger | Principal/brand code associated with the dealership session |
| P_FIN_YR | Char | Trigger | Financial year parameter passed into the session context; used to align report period with the dealer's fiscal calendar |
| REPORT_DESC | Char | Trigger | Description label displayed on the report screen header |
| REP_SERVER | Char | Trigger | Report server name or URL used when submitting server-side report jobs |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the current dealer session |
| TO_NO | Number | ProgramUnit / Trigger | Ending record number for pagination of displayed results |
| TO_REC | Number | ProgramUnit / Trigger | Ending record index used for result-set navigation |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID used for session tracking and file naming |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used for header labels and audit references |

### 8.1.2 Form Parameters

*All 2 ModuleParameter entries from vr_bodyshop_prod_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_RO_NUM | Char | - | Repair order number passed into the form when launched from a parent screen; used to scope legacy job-card detail queries (referenced in inactive EXCEL_GENERATION program unit) |
| P_APP_ID | Char | - | Application identifier passed at form launch; referenced in inactive code for alternative Excel report generation - not used in current active form logic |

**Total Parameters:** 2

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | 1 | N/N/N/N | Default | Control - entry point for date range and search criteria |
| CB_DOC | - | 2 | N/N/N/N | Default | Control - displays calculated productivity results; no direct master-detail relationship |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_bodyshop_prod_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_bodyshop_prod_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_bodyshop_prod_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DOC_QUERY | 7 | 0 | 7 |
| CB_DOC | 9 | 0 | 9 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **39** | **0** | **39** |

**Item detail (all 39 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | FROM_JC_BILL_DT | false | Start date of the billing period for the bodyshop productivity report |
| CB_DOC_QUERY | TO_BILL_DT | false | End date of the billing period; must not exceed current date or differ from start by more than 31 days |
| CB_DOC_QUERY | SEARCH | false | Search button - triggers productivity calculation and populates the results block |
| CB_DOC_QUERY | PB_EXCEL | false | Export button - generates a CSV export of the productivity data |
| CB_DOC_QUERY | TXT | false | Hidden text item storing the dynamically built SQL query string for Excel export |
| CB_DOC_QUERY | COPYRIGHT_DECLARATION | false | Display item showing copyright or disclaimer text |
| CB_DOC_QUERY | REPORT_DESC | false | Display item showing the report description label from the session global |
| CB_DOC | NO_OF_BAYS | false | Number of active service bays for the dealer and location |
| CB_DOC | NO_OF_WORK_DAYS | false | Count of working days within the selected date range |
| CB_DOC | NO_OF_VEH_REP | false | Number of job cards (vehicles repaired) in the period |
| CB_DOC | NO_OF_PANELS | false | Total panel count from bodyshop VTS records in the period |
| CB_DOC | LAB_GEN | false | Total labour amount generated in the selected period |
| CB_DOC | BAY_PROD | false | Bay productivity - vehicles repaired per bay (calculated) |
| CB_DOC | PER_DAY_PROD | false | Per-day productivity - vehicles repaired per working day (calculated) |
| CB_DOC | PANEL_PROD | false | Panel productivity - panels completed per working day (calculated) |
| CB_DOC | LABOUR_PROD | false | Labour productivity - labour amount per working day (calculated) |
| CB_ERR | TXT_ERR | false | Inherited error display text item (CB_ERR block); shows runtime error messages in the error window (inherited from DPL.olb) |
| PB_BLK | PB_EXIT | false | Inherited toolbar button - exits the current form (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_LIST | false | Inherited toolbar button - opens the list of values for the current item (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button - inserts a new record (inherited from DPL.olb PB_BLK block; no-op in this read-only form) |
| PB_BLK | PM_CONT | false | Inherited toolbar container or spacer item (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_DEL | false | Inherited toolbar button - deletes the current record (inherited from DPL.olb PB_BLK block; no-op in this read-only form) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button - cancels pending changes (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button - saves/commits changes (inherited from DPL.olb PB_BLK block; no DML in this form) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button - invokes the print action for the current screen (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_CUT | false | Inherited toolbar button - cuts selected text to clipboard (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_COPY | false | Inherited toolbar button - copies selected text to clipboard (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button - pastes clipboard content into the current item (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_ERR_EXIT | false | Inherited error-window button - closes the error dialog without action (inherited from DPL.olb PB_BLK block) |
| PB_BLK | PB_ERR_OK | false | Inherited error-window button - acknowledges and dismisses the error dialog (inherited from DPL.olb PB_BLK block) |
| WEBUTIL | DUMMY | false | Placeholder item required by the WEBUTIL block to satisfy Oracle Forms block-must-have-item constraint (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WEBUTIL bean area item exposing client machine information functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WEBUTIL bean area item exposing client-side file system functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WEBUTIL bean area item exposing host/shell execution functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WEBUTIL bean area item exposing session-level utility functions (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WEBUTIL bean area item exposing file transfer (upload/download) functions between client and server (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WEBUTIL bean area item exposing OLE automation functions on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WEBUTIL bean area item exposing C API / DLL call functions on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WEBUTIL bean area item exposing browser control functions such as opening URLs (inherited from webutil.olb) |

### 8.4 List of Values

*No LOVs found in vr_bodyshop_prod_fmb.xml.*

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Inherited from WEBUTIL object group; fired by the WEBUTIL subsystem when a client-side operation fails; no active SHOW_ALERT call for this alert found in form triggers or program units |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb object group; presented by DPL library routines when a print destination choice is required |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb object group; displayed by GENERAL.DISP_TEXT / GENERAL.RAISE_ERROR to surface error detail to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb object group; used by DPL library routines to display informational messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb object group; used by GENERAL.ASK_CONFIRM to present a yes/no confirmation dialog |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| SET_GLOBAL | Procedure | :global.from_no, :global.to_no, :global.increment_no | Initialises pagination global variables (from_no = 1, to_no = 10, increment_no = 10) at form start |
| POPULATE | Unknown | **COMMENTED OUT / INACTIVE** - formerly called CB_DOC block navigation globals and DOC_DET package | **COMMENTED OUT / INACTIVE** - formerly populated the CB_DOC results block from an in-memory PL/SQL table; entire body is commented out |
| DOC_DET | Unknown | **COMMENTED OUT / INACTIVE** - formerly referenced pk_plsql_table.code_tab6 | **COMMENTED OUT / INACTIVE** - formerly a package spec declaring an in-memory document collection; entire body is commented out |
| EXCEL_GENERATION | Unknown | **COMMENTED OUT / INACTIVE** - formerly called vh_ro, ph_issue, vm_rcateg, GM_CIN, GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - formerly generated an Excel/CSV export of job card billing details using server-side file I/O; entire body is commented out |
| VIEW_EXCEL_REP | Procedure | ID_NULL (webutil), Create_Group_From_Query, Populate_Group, Get_Group_Row_Count, Get_Group_Char_Cell, Delete_Group, TEXT_IO.FOPEN, TEXT_IO.PUT_LINE, web.show_document | Executes a SQL query into a record group, writes each row as a CSV line to a server file, then opens the file in the browser; called from WHEN-BUTTON-PRESSED on PB_EXCEL |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Presents a yes/no confirmation dialog to the user using the AL_CONFIRM alert; return value controls subsequent form action |
| GENERAL.DISP_TEXT | Library routine | Form level; ProgramUnit: EXCEL_GENERATION (commented out) | Displays an alert dialog with a title and message body; the active call site is at form level; the EXCEL_GENERATION call site is in inactive/commented code |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code and displays it via AL_ERRINFO; active call site is at form level |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | ON-ERROR | Formerly handled Oracle Forms and database errors using GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR with specific error codes (40209, 40207, 50004, 50025, 50026, -02292) | Body is `null;` with full error-handling logic block-commented; replaced by inherited error handling |
| **Inactive stub** | Form | - | KEY-CLRFRM | Formerly cleared the form, reset DOC_TYPE to JC, called SET_GLOBAL to reinitialise pagination globals, and toggled item properties for navigation controls | Body starts with `null;`; previous clear-form and UI-reset logic is block-commented |
| **Inactive stub** | Form | - | FT_CANCEL | Formerly invoked the DPL cancel/rollback action for the current block | Body is `null;`; inherited FT_CANCEL trigger from DPL.olb supersedes this stub |
| **Inactive stub** | Form | - | FT_DEL | Formerly invoked the DPL delete-record action for the current block | Body is `null;`; inherited FT_DEL trigger from DPL.olb supersedes this stub |
| **Inactive stub** | Form | - | FT_LIST | Formerly invoked the DPL list-of-values action for the current item | Body is `null;`; inherited FT_LIST trigger from DPL.olb supersedes this stub |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Formerly initialised session globals (USERID, DEALER, LOC_CD, PARENT_GROUP, COMP_FA, PRINCIPAL, REPORT_DESC and others) by calling DPL session-setup routines and SET_GLOBAL | Entire body is block-commented; session initialisation is now handled by the inherited WHEN-NEW-FORM-INSTANCE from DPL.olb object group |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-UP | No previously documented behaviour recoverable from comments | Body is `NULL;` |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-DOWN | No previously documented behaviour recoverable from comments | Body is `NULL;` |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (39 business triggers):**
*vr_bodyshop_prod_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body is `null;`; formerly intercepted Forms and database errors and displayed messages via GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR |
| ON-MESSAGE | Form | - | Form level | Inherited from DPL.olb object group; handles informational message suppression (inherited) |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info, erases pagination globals (from_no, to_no, increment_no), and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Inherited from DPL.olb object group; activates the list of values for the current item (inherited) |
| KEY-COMMIT | Form | - | Form level | Inherited from DPL.olb object group; commit action (no DML blocks so effectively a no-op save) (inherited) |
| KEY-CLRFRM | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body is `null;`; formerly cleared form and reset navigation state |
| KEY-UP | Form | - | Form level | Inherited from DPL.olb object group; suppresses upward navigation at form level (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited from DPL.olb object group; suppresses downward navigation at form level (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL.olb object group; navigates to the previous block (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL.olb object group; navigates to the next block (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL.olb object group; navigates focus to the previous item (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL.olb object group; navigates focus to the next item (inherited) |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL.olb object group; suppresses unhandled key actions at form level (inherited) |
| FT_SAVE | Form | - | Form level | Inherited from DPL.olb object group; toolbar Save action - commits pending changes (inherited) |
| FT_CANCEL | Form | - | Form level | **INACTIVE STUB** - body is `null;`; inherited FT_CANCEL from DPL.olb object group supersedes this local stub |
| FT_INSERT | Form | - | Form level | Inherited from DPL.olb object group; toolbar Insert action - creates a new record (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE STUB** - body is `null;`; inherited FT_DEL from DPL.olb object group supersedes this local stub |
| FT_LIST | Form | - | Form level | **INACTIVE STUB** - body is `null;`; inherited FT_LIST from DPL.olb object group supersedes this local stub |
| FT_PRINT | Form | - | Form level | Inherited from DPL.olb object group; toolbar Print action - invokes the DPL print dialog (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **COMMENTED OUT** - entire body is block-commented; formerly initialised session globals and called SET_GLOBAL; session initialisation now handled by inherited WHEN-NEW-FORM-INSTANCE from DPL.olb object group |
| PRE-FORM | Form | - | Form level | Sets DBMS application info (client info and module name) to `vr_bodyshop_prod` for session monitoring |
| KEY-UP | CB_DOC_QUERY | - | CB_DOC_QUERY | **COMMENTED OUT / INACTIVE** - body is `NULL;`; no active navigation behaviour |
| KEY-DOWN | CB_DOC_QUERY | - | CB_DOC_QUERY | **COMMENTED OUT / INACTIVE** - body is `NULL;`; no active navigation behaviour |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Validates that the From Date is not null and does not exceed the current date |
| KEY-NEXT-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Navigates focus to the To Date field; legacy multi-path code is commented out |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | TO_BILL_DT | CB_DOC_QUERY.TO_BILL_DT | Validates that To Date does not exceed current date, is not less than From Date, and the range does not exceed 31 days |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | SEARCH | CB_DOC_QUERY.SEARCH | Validates date range, executes the bodyshop productivity query, and populates CB_DOC with bays, working days, job counts, panel counts, labour amounts, and productivity ratios |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | PB_EXCEL | CB_DOC_QUERY.PB_EXCEL | Validates date range, builds a dynamic SQL query string, stores it in TXT, and calls VIEW_EXCEL_REP to generate and display a CSV productivity export |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button action - exits the form cleanly (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button action - opens the LOV for the current item (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button action - inserts a new record (inherited from DPL.olb PB_BLK block; no-op in this read-only form) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar container action (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button action - deletes the current record (inherited from DPL.olb PB_BLK block; no-op in this read-only form) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button action - cancels/rolls back pending changes (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button action - saves/commits changes (inherited from DPL.olb PB_BLK block; no DML in this form) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button action - invokes the DPL print dialog (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button action - cuts selected text to clipboard (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button action - copies selected text to clipboard (inherited from DPL.olb PB_BLK block) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button action - pastes clipboard content into the current item (inherited from DPL.olb PB_BLK block) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Bodyshop Productivity Report (1.1.2) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN (inherited) |
| CN_MAIN | Content | WN_MAIN (inherited) |
| CN_ERR | Content | WIN_ERR (inherited) |

---

### 8.9 Editors

*No editors found in vr_bodyshop_prod_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_bodyshop_prod_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_bodyshop_prod_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_bodyshop_prod_fmb.xml.*

## 9. Object Library

*The form references two Object Library files (OLB). The DPL library provides shared Visual Attributes and Property Classes used for consistent styling across the dealership management system. The WEBUTIL library provides the infrastructure object group for Oracle WebUtil browser integration. No items in this form inherit directly from DPL Property Classes or Visual Attributes in the current build.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check box items | not used by this form | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio button items | not used by this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons | not used by this form | N/A |
| VA_DESC | VisualAttribute | Visual attribute for description text items | not used by this form | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric display items | not used by this form | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory fields | not used by this form | N/A |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts | not used by this form | N/A |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts | not used by this form | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for standard text items | not used by this form | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for standard push buttons | not used by this form | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert-related items | not used by this form | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for title/heading items | not used by this form | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date items | not used by this form | N/A |
| VA_LOV | VisualAttribute | Visual attribute for list-of-values items | not used by this form | N/A |
| VA_DISP | VisualAttribute | Visual attribute for display-only items | not used by this form | N/A |
| PC_DESC | PropertyClass | Property class for description text items | not used by this form | N/A |
| PC_SC_DATE | PropertyClass | Property class for date items | not used by this form | N/A |
| PC_TITLE | PropertyClass | Property class for title/heading text items | not used by this form | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items | not used by this form | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-record block layout | not used by this form | N/A |
| PC_DISP | PropertyClass | Property class for display-only text items | not used by this form | N/A |
| PC_LOV | PropertyClass | Property class for list-of-values items | not used by this form | N/A |
| PC_FORM | PropertyClass | Property class for form-level styling | not used by this form | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items | not used by this form | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items | not used by this form | N/A |
| PC_DATE | PropertyClass | Property class for date entry items | not used by this form | N/A |
| PC_DTTIME | PropertyClass | Property class for date-and-time items | not used by this form | N/A |
| PC_CB | PropertyClass | Property class for check box items | not used by this form | N/A |
| PC_ALERT | PropertyClass | Property class for alert items | not used by this form | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date items | not used by this form | N/A |
| PC_RB | PropertyClass | Property class for radio button items | not used by this form | N/A |
| PC_WIND | PropertyClass | Property class for window layout | not used by this form | N/A |
| PC_CANV | PropertyClass | Property class for canvas layout | not used by this form | N/A |
| PC_BUTN | PropertyClass | Property class for push button items | not used by this form | N/A |
| PC_TEXT | PropertyClass | Property class for standard text entry items | not used by this form | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | not used by this form | N/A |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | not used by this form | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | not used by this form | N/A |
| PC_NUM | PropertyClass | Property class for numeric items | not used by this form | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | not used by this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons | not used by this form | N/A |
| PC_SCROLL | PropertyClass | Property class for scroll bar items | not used by this form | N/A |
| WEBUTIL | ObjectGroup | WebUtil browser integration object group - provides the complete set of WebUtil client-side function components required for browser-based file operations and client/server communication | referenced (form's WEBUTIL block inherits from this group) | WEBUTIL.DUMMY, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil browser integration object group - variant without OLE function components, for deployments where OLE is not required | not used by this form | N/A |
| OG_GROUP | ObjectGroup | Form-level object group defined in the form XML (not from OLB); groups form-level objects for reuse or packaging | referenced | N/A |

---

## 10. Record Groups

*No record groups found in `vr_bodyshop_prod_fmb.xml`.*

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | - | No |
| CB_DOC | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system pseudo-table - used as a header row source in the Excel export SQL union query (WHEN-BUTTON-PRESSED) and as a lightweight query target for form initialisation logic (WHEN-NEW-FORM-INSTANCE) |

**Total Referenced Objects:** 1

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name against the current database session for operational monitoring |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module name and action context in the current database session |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY | Returns the count of active service bays for the specified dealer group, dealership, and location |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Counts working days in the selected billing period by excluding holidays and leave days |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_PANEL | Sums the total body panels repaired per repair order for the specified dealership context |
| BR-005 | VIEW_EXCEL_REP (form program unit) | Executes the productivity query, writes results to a CSV file on the server, and opens it in the browser |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY | Returns active bay count embedded in the export query |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Returns working day count embedded in the export query |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_PANEL | Returns panel count embedded in the export query |
| BR-005 | WEB.SHOW_DOCUMENT | Opens the generated CSV file URL in the user's browser for download |
| BR-005 | WEBUTIL.ID_NULL | Checks whether an existing record group handle is null before re-creating the group in VIEW_EXCEL_REP |
| BR-006 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session module identifier on form exit |
| BR-006 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module name and action from the session on form exit |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before executing significant toolbar actions (delete, save, exit, etc.) |
| - | GENERAL.CHECK_FORM_FAILURE | Checks the outcome of the most recent Forms operation after KEY-COMMIT and raises FORM_TRIGGER_FAILURE on failure |
| - | GENERAL.DISP_TEXT | Intercepts Forms runtime messages via ON-MESSAGE and displays them in a consistent alert dialog |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central event-dispatch procedure routing WHEN-CUSTOM-ITEM-EVENT calls from all eight WebUtil bean items to the appropriate WebUtil subsystem handler |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | PRE-FORM trigger (startup); KEY-EXIT trigger (exit) | Registers or clears the client identifier in the database session for monitoring and auditing |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | PRE-FORM trigger (startup); KEY-EXIT trigger (exit) | Registers or clears the module name and action name in the database session |
| PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY | Application package function | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH (in cursor query); WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL (in assembled query string) | Returns the number of active service bays for a given dealer group, dealership, and location from the bay master configuration (VM_BAY_MAST where ACTIVE_YN = 'Y'); returns 0 on exception |
| PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Application package function | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH (in cursor query) | Counts the number of working days in a date range by iterating day by day and excluding dates recorded as holidays in WD_BTN for the dealer and location; returns 0 or a positive integer |
| PKG_VTS_BODYSHOP.SF_GET_PANEL | Application package function | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH (in cursor query) | Sums the total windshield panel count (PANEL_WNSHLD) for a specific repair order from VT_VTS for the given parent group, dealer, location, company/FA code, and RO number; returns 0 when no VTS record exists |
| VIEW_EXCEL_REP | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL | Executes a provided SQL query, writes the result rows to a CSV file on the application server, and launches the file URL in the browser; uses TEXT_IO for server-side file operations; reads the export path from `/reports/DMS/excelpath.txt`; raises FORM_TRIGGER_FAILURE on unhandled exceptions |
| WEB.SHOW_DOCUMENT | Oracle Forms built-in WEB package procedure | VIEW_EXCEL_REP form program unit | Opens a URL in the user's web browser in a new window; used to present the generated CSV file for download |
| WEBUTIL.ID_NULL | WebUtil PLD library function (WEBUTIL_C_API) | VIEW_EXCEL_REP form program unit | Checks whether a given Oracle Forms RecordGroup handle is null; returns TRUE if the handle's internal pointer is null, FALSE otherwise; called before attempting to delete an existing record group so that a fresh group can be created for the export query |
| GENERAL.ASK_CONFIRM | PLD library function (DPL.pld - GENERAL) | WHEN-BUTTON-PRESSED on PB_BLK.PB_COPY, PB_BLK.PB_CUT, PB_BLK.PB_DEL, PB_BLK.PB_EXIT, PB_BLK.PB_INSERT, PB_BLK.PB_LIST, PB_BLK.PB_PASTE, PB_BLK.PB_PRINT, PB_BLK.PB_SAVE, WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message and returns a NUMBER indicating the user's choice; called from every toolbar push-button trigger (inherited via OG_GROUP object group) to obtain user confirmation before executing potentially destructive or significant actions |
| GENERAL.CHECK_FORM_FAILURE | PLD library procedure (DPL.pld - GENERAL) | KEY-COMMIT trigger (form level) | Checks the outcome of the most recent Forms operation and raises FORM_TRIGGER_FAILURE if a failure or fatal error condition is detected; called immediately after the commit action to ensure database or Forms errors are surfaced consistently |
| GENERAL.DISP_TEXT | PLD library procedure (DPL.pld - GENERAL) | ON-MESSAGE trigger (form level) | Displays an alert dialog - AL_ERRINFO for error-type messages or AL_NOTE for informational messages - populated with the supplied title and message text; called from the ON-MESSAGE trigger to present Forms runtime messages in a consistent, user-friendly format |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil PLD library procedure (webutil.pld - WEBUTIL_CORE) | WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central event-dispatch procedure for the WebUtil integration layer; each WebUtil bean item fires a WHEN-CUSTOM-ITEM-EVENT trigger passing the event name and a serialised parameter string; the trigger delegates to CustomEventHandler, which routes the event to the appropriate WebUtil subsystem handler based on EventName |

---

#### PKG_VTS_BODYSHOP

The PKG_VTS_BODYSHOP package is the primary application package called by this form. It provides three scalar functions used within the bodyshop productivity query:

- **SF_GET_VTS_NO_BAY** - accepts `p_pgroup VARCHAR2`, `p_dealermap NUMBER`, `p_loc VARCHAR2`; returns the count of active bays from VM_BAY_MAST (ACTIVE_YN = 'Y') for a given dealer group, dealership, and location. Returns 0 on exception. Called from both the SEARCH and PB_EXCEL button triggers.
- **SF_GET_WORKING_DAY_CNT** - accepts `p_pgroup VARCHAR2`, `p_dealermap NUMBER`, `p_loc VARCHAR2`, `p_frm_dt DATE`, `p_to_dt DATE`; iterates over the date range day by day, checking each date against WD_BTN (holiday/leave calendar), and returns the count of working days. Called from the SEARCH button trigger to populate NO_OF_WORK_DAYS and to compute per-day, panel, and labour productivity ratios.
- **SF_GET_PANEL** - accepts `p_pgroup VARCHAR2`, `p_dealermap NUMBER`, `p_loc VARCHAR2`, `p_comp VARCHAR2`, `p_ronum VARCHAR2`; queries VT_VTS for the sum of PANEL_WNSHLD associated with the given repair order number and returns the total (defaulting to 0 via NVL). Called once per VH_RO row in the SEARCH cursor to accumulate the total panel count across all matching repair orders.

All three functions return a numeric value and must not raise exceptions on missing data.

---

#### VIEW_EXCEL_REP

A form-level PL/SQL procedure that accepts a query string and column name, executes the query using a Forms record group, iterates the result rows, and writes each row as a line to a server-side CSV file via TEXT_IO. It reads the server export path from `/reports/DMS/excelpath.txt` and opens the resulting file URL in the browser via WEB.SHOW_DOCUMENT. Before creating the record group it calls WEBUTIL.ID_NULL to test whether an existing group handle is non-null and deletes it if so, ensuring a clean group is used for each export. Raises FORM_TRIGGER_FAILURE on unhandled exceptions.

---

#### GENERAL (DPL.pld)

The GENERAL library (delivered via DPL.pld) provides three active utility routines used by this form:

- **ASK_CONFIRM** - function accepting a `confirm_msg VARCHAR2`; presents a user confirmation dialog and returns a NUMBER representing the user's choice. Wired to every OG_GROUP toolbar button's WHEN-BUTTON-PRESSED trigger.
- **CHECK_FORM_FAILURE** - procedure with no parameters; inspects the Forms failure/fatal-error state after a commit and raises FORM_TRIGGER_FAILURE if an error is detected. Called from the form-level KEY-COMMIT trigger.
- **DISP_TEXT** - procedure accepting `text_string VARCHAR2` and `title_string VARCHAR2`; routes the message to AL_ERRINFO (when title = 'ERROR') or AL_NOTE (all other titles). Called from the form-level ON-MESSAGE trigger.

Note: GENERAL.RAISE_ERROR appears only in commented-out code within the ON-ERROR trigger and is not active in this form.

---

#### WEBUTIL_CORE (webutil.pld)

The WebUtil integration layer is surfaced through two routines active in this form:

- **WEBUTIL_CORE.CUSTOMEVENTHANDLER** - the single dispatcher for all eight WebUtil bean items' WHEN-CUSTOM-ITEM-EVENT triggers; routes events to the appropriate WebUtil subsystem (browser, client-info, C-API, file-transfer, file, host, OLE, session) based on the EventName parameter.
- **WEBUTIL.ID_NULL** (WEBUTIL_C_API) - checks whether a RecordGroup handle pointer is null; used in VIEW_EXCEL_REP to guard against operating on a stale group reference before creating a new one for the export query.

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-VTS-BODYSHOP | PKG_VTS_BODYSHOP | Bodyshop productivity calculation engine - exposes functions to retrieve the number of active service bays, count working days in a date range excluding holidays, and sum panel counts from VTS records for a given dealer, location, and repair order | The form requires centralized database functions to calculate bay count, working days, and panel data so that productivity metrics (bay productivity, per-day productivity, panel productivity, and labour productivity) can be computed and displayed correctly for the selected period | sf_get_vts_no_bay returns the count of active bays for the dealer/location; sf_get_working_day_cnt counts calendar days in the range excluding holidays recorded in WD_BTN; sf_get_panel returns the total panel windshield count for a given repair order from VT_VTS; all three functions return a numeric value and must not raise exceptions on missing data |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_VTS_BODYSHOP.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_panel | Function | function sf_get_panel(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_comp varchar2, p_ronum varchar2) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Returns the total windshield panel count for a specific repair order by summing PANEL_WNSHLD from VT_VTS for the given parent group, dealer, location, and RO number. Accepts the group, dealer map code, location code, company/FA code, and repair order number. Called once per VH_RO row in the SEARCH cursor to accumulate the total panel count across all matching repair orders. Returns 0 when no VTS record exists. |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_vts_no_bay | Function | function sf_get_vts_no_bay(p_pgroup varchar2, p_dealermap number, p_loc varchar2) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Returns the count of active service bays for the given parent group, dealer, and location by querying VM_BAY_MAST where ACTIVE_YN = 'Y'. Accepts the group, dealer map code, and location code. Called during the SEARCH and Excel export triggers to populate the NO_OF_BAYS field and to compute bay productivity ratios. Returns 0 on exception. |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_working_day_cnt | Function | function sf_get_working_day_cnt(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_frm_dt date, p_to_dt date) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Returns the count of working days in the given date range by iterating day by day between p_frm_dt and p_to_dt and excluding dates recorded as holidays in WD_BTN for the dealer and location. Accepts group, dealer map code, location code, from date, and to date. Called during SEARCH to populate NO_OF_WORK_DAYS and to compute per-day, panel, and labour productivity ratios. |

**Total Matched Package Routines (called from form XML):** 3

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| sf_get_panel | Number | 0 or positive integer (panel count) | Total count of windshield panels for the repair order; 0 when no VTS record exists |
| sf_get_vts_no_bay | Number | 0 or positive integer (bay count) | Number of active service bays at the dealer/location; 0 when none configured or on exception |
| sf_get_working_day_cnt | Number | 0 or positive integer (day count) | Count of non-holiday calendar days between the from and to dates inclusive |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message and returns a NUMBER indicating the user's choice. Called from every toolbar push-button's WHEN-BUTTON-PRESSED trigger (inherited via the OG_GROUP object group) to obtain user confirmation before executing potentially destructive or significant actions such as delete, cut, copy, paste, insert, save, print, list, and exit. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks the outcome of the most recent Forms operation and raises FORM_TRIGGER_FAILURE if a failure or fatal error condition is detected. Called from the form-level KEY-COMMIT trigger immediately after the commit action to ensure that any database or Forms error encountered during the commit cycle is surfaced and handled consistently. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-MESSAGE in Form | Displays an alert dialog - AL_ERRINFO for error-type messages or AL_NOTE for informational messages - populated with the supplied title and message text. The title parameter drives alert selection: a title of 'ERROR' routes to the error alert; all other titles route to the note alert. Called from the form-level ON-MESSAGE trigger to intercept and present Forms runtime messages in a consistent, user-friendly format. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_bodyshop_prod_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | **COMMENTED OUT / INACTIVE** - looks up an error message text and type by message code, then calls DISP_TEXT with the resolved message and title, raising FORM_TRIGGER_FAILURE for error-type messages. The call site in ON-ERROR is inside block-commented code and will not execute. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central event-dispatch procedure for the WebUtil integration layer. Each WEBUTIL bean item fires a WHEN-CUSTOM-ITEM-EVENT trigger passing the event name and a serialised parameter string; the trigger delegates immediately to CustomEventHandler, which routes the event to the appropriate WebUtil subsystem handler based on EventName. All eight WebUtil functional bean items share this single dispatcher, ensuring uniform event processing across browser, client-info, C-API, file-transfer, file, host, OLE, and session subsystems. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a given Oracle Forms handle (RecordGroup) is null. Returns TRUE if the handle's internal pointer is null, FALSE otherwise. Called in VIEW_EXCEL_REP before attempting to delete an existing record group - if the group already exists and is not null, it is deleted before creating a fresh one from the export query. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Bodyshop Productivity Report Service | VH_RO + PKG_VTS_BODYSHOP (SF_GET_VTS_NO_BAY, SF_GET_WORKING_DAY_CNT, SF_GET_PANEL) | dealer_map_cd, parent_group, loc_cd, from_bill_date, to_bill_date | JSON object with: no_of_bays, no_of_work_days, no_of_jc, panel_cnt, lab_amt, bay_productivity, per_day_productivity, panel_productivity, labour_productivity | Retrieves and calculates bodyshop productivity metrics (vehicle count, panel count, labour revenue, and four productivity ratios) for a dealership/location and billing period | POST /api/bodyshop/productivity-report |
| MS-002 | Active Bay Count Service | PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY -> VM_BAY_MAST | parent_group, dealer_map_cd, loc_cd | Integer - count of active service bays | Returns the number of currently active service bays for the specified dealership and location | GET /api/bodyshop/bays/active-count?dealer={dealer}&group={group}&location={loc} |
| MS-003 | Working Day Count Service | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT -> WD_BTN | parent_group, dealer_map_cd, loc_cd, from_date, to_date | Integer - number of working days in the period | Counts the working days in a date range for a dealership/location, excluding public holidays and leave days | GET /api/bodyshop/calendar/working-days?dealer={dealer}&group={group}&location={loc}&from={from}&to={to} |
| MS-004 | Repair Order Panel Count Service | PKG_VTS_BODYSHOP.SF_GET_PANEL -> VT_VTS | parent_group, dealer_map_cd, loc_cd, comp_fa, ro_num | Numeric - total panel count for the repair order | Returns the total number of body panels recorded for a specific repair order | GET /api/bodyshop/repair-orders/{ro_num}/panel-count?dealer={dealer}&group={group}&location={loc}&comp={comp} |
| MS-005 | Bodyshop Productivity CSV Export Service | VH_RO + PKG_VTS_BODYSHOP functions | dealer_map_cd, parent_group, loc_cd, from_bill_date, to_bill_date, userid | CSV file download - same columns as on-screen report | Generates and returns a downloadable CSV file containing the bodyshop productivity report data for the specified period and dealership context | POST /api/bodyshop/productivity-report/export/csv |
| MS-006 | Session Module Registration Service | DBMS_APPLICATION_INFO | module_name, action_name, client_info | HTTP 204 No Content | Registers or clears the active module context in the database session for operational monitoring | PUT /api/session/module-context |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Startup and Session Registration | User opens the Bodyshop Productivity Report form (PRE-FORM trigger fires) | 1. Register module name in database session via DBMS_APPLICATION_INFO | None | Form is open; session context is registered; user is ready to enter report criteria |
| WF-002 | From Bill Date Entry and Validation | User moves off the "From Bill Date" field (WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT fires) | 1. Check if From Bill Date is blank; 2. Check if From Bill Date is later than today; 3. If both pass, advance cursor to "To Bill Date" field | If blank -> show error alert, abort; If future date -> show error alert, abort; Otherwise -> proceed | Cursor is on the "To Bill Date" field ready for input |
| WF-003 | To Bill Date Entry and Validation | User moves off the "To Bill Date" field (WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT fires) | 1. Check if To Bill Date is later than today; 2. Check if To Bill Date is before From Bill Date; 3. Check if period exceeds 31 days; 4. If all pass and To Bill Date is blank, default it to today | If future date -> show error, abort; If before From -> show error, abort; If >31 days -> show error, move cursor back, abort; If blank -> silently set to today | To Bill Date is validated and populated; user can proceed to Search |
| WF-004 | Generate Bodyshop Productivity Report | User clicks the Search button (WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH fires) | 1. Re-validate To Bill Date not in future; 2. Re-validate To Bill Date not before From Bill Date; 3. Execute productivity cursor query (calling SF_GET_VTS_NO_BAY, SF_GET_WORKING_DAY_CNT, SF_GET_PANEL); 4. Populate on-screen results block with metrics; 5. Move cursor to Export to Excel button | If re-validation fails -> show error alert, move cursor to To Bill Date field, abort; No data found for period -> results block remains empty | On-screen results area displays productivity metrics; cursor is on the Export to Excel button |
| WF-005 | Export Bodyshop Productivity Data to CSV | User clicks the Export to Excel button (WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL fires) | 1. Generate unique CSV filename from user ID and timestamp; 2. Assemble productivity SQL query with embedded date range and session context; 3. Store assembled query in internal text field; 4. Call VIEW_EXCEL_REP to execute query, write CSV, and open file in browser | If file path contains spaces -> redirect to C:\ and inform user; If row count exceeds 65,535 -> truncate and inform user; If unexpected error -> show error message, abort | CSV file written to server; file URL opened in user's browser for download |
| WF-006 | Form Exit and Session Cleanup | User presses the Exit key (KEY-EXIT trigger at form level fires) | 1. Clear client info from database session; 2. Clear module name from database session; 3. Erase pagination global variables (from_no, to_no, increment_no); 4. Exit form without saving | None | Form is closed; database session context is cleared; pagination globals are erased |

**Total Workflows Identified: 6**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is evaluated, then the function returns true if the handle is null, enabling safe group cleanup before Excel export |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | DISP_TEXT | Business Logic | ProgramUnit: EXCEL_GENERATION, Trigger: ON-ERROR in Form | /api/v1/pld/disp_text | **COMMENTED OUT / INACTIVE** - when an error or note alert is required, then a dialog is displayed with the supplied message and title; all call sites are inactive |
| PLD-002 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | **COMMENTED OUT / INACTIVE** - when an error message code is supplied, then the corresponding message is looked up and displayed, raising form failure for error-type messages; call site is inactive |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_bodyshop_prod_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_VTS_BODYSHOP.sf_get_panel | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_panel | When a repair order is included in the productivity query, then the total windshield panel count is retrieved from VT_VTS and summed across all matching job cards |
| PCK-002 | PKG_VTS_BODYSHOP.sf_get_vts_no_bay | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_vts_no_bay | When productivity metrics are calculated, then the number of active service bays is retrieved from VM_BAY_MAST for the dealer and location to serve as the bay-productivity divisor |
| PCK-003 | PKG_VTS_BODYSHOP.sf_get_working_day_cnt | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_working_day_cnt | When the selected date range is submitted, then the count of working days is calculated by iterating each day and excluding dates listed as holidays in WD_BTN for the dealer and location |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Repair Order Register (VH_RO) | SELECT query via embedded SQL in WHEN-BUTTON-PRESSED triggers | Retrieves the count of repair orders, total panel counts, and total labour revenue for the Body and Paint repair category within the selected billing period for the current dealership/location | Inbound - data flows from VH_RO to the on-screen results block (CB_DOC) and into the export query | No explicit error handler in the cursor loop; if no rows are found the results block remains empty |
| Bodyshop Productivity Package (PKG_VTS_BODYSHOP) | PL/SQL package function calls embedded in SQL queries | Provides scalar functions (SF_GET_VTS_NO_BAY, SF_GET_WORKING_DAY_CNT, SF_GET_PANEL) called within the productivity SELECT query to calculate bay count, working day count, and panel totals | Inbound - each function returns a numeric value used in the query result set | SF_GET_VTS_NO_BAY and SF_GET_PANEL return 0 on WHEN OTHERS; SF_GET_WORKING_DAY_CNT returns 0 on WHEN OTHERS for the holiday-check sub-query |
| Database Session Context (DBMS_APPLICATION_INFO) | Oracle built-in package calls | Registers the module name and client identifier in the database session at startup; clears them on exit for operational monitoring | Outbound - module/action/client information written to the database session | No explicit error handling; Oracle built-in; failure would prevent form startup (PRE-FORM) or silent on exit (KEY-EXIT) |
| Bay Master Configuration (VM_BAY_MAST) | SELECT via PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY | Provides the count of active service bays for the dealership/location, used as the denominator for the bay productivity ratio | Inbound - scalar count returned to the productivity query | Returns 0 on WHEN OTHERS within SF_GET_VTS_NO_BAY |
| Holiday and Leave Calendar (WD_BTN) | SELECT via PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT | Provides non-working day records to allow accurate working day counting within the billing period | Inbound - each day checked against WD_BTN; non-matching days counted as working days | Returns 0 for the holiday count on WHEN OTHERS within the sub-query; counting continues |

### 20.2 External System Integrations

The form has no external system integrations (no CALL_FORM or OPEN_FORM calls to external modules, no external system API calls, no interface tables). The only external dependency is the server-side configuration file and the file system access described in Section 20.3 and the report integrations section; there are no message-based or service-based external system integrations.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Application Server File System | Server-side file write via TEXT_IO (Oracle Forms) | Writes the generated productivity CSV file to the application server file system for browser download | Oracle Forms TEXT_IO (server-side) | `/iashome/ias/reports/printer/` (server path prefix derived from hardcoded base; filename appended) | Outbound - CSV rows written from in-memory record group to a file on the server | WHEN OTHERS in VIEW_EXCEL_REP catches file I/O errors; shows *"Error  - "* + system error code + text and raises FORM_TRIGGER_FAILURE |
| Export Path Configuration File | Server-side file read via TEXT_IO (Oracle Forms) | Reads the server-side base URL/path for the generated CSV files from a fixed configuration file | Oracle Forms TEXT_IO (server-side) | `/reports/DMS/excelpath.txt` (hardcoded path) | Inbound - one line of text read from the file containing the base URL for the export file | WHEN OTHERS in VIEW_EXCEL_REP catches read errors; shows *"Error  - "* + system error code + text and raises FORM_TRIGGER_FAILURE |
| Web Browser (via WEB.SHOW_DOCUMENT) | Oracle Forms WEB package call | Opens the generated CSV file URL in the user's browser in a new window for download | Oracle Forms built-in WEB package | URL constructed from export path + generated filename | Outbound - URL passed to browser; no response captured | No explicit error handling for browser open; failure would be silent from the form's perspective |

### 20.3 Report Integrations

No Oracle Reports are called by this form. The `reference_data.reports` slice entry is empty. The form generates CSV exports directly via the VIEW_EXCEL_REP program unit and TEXT_IO, not via Oracle Reports.

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_BODYSHOP_PROD form.

### 21.1 Catalogue Index

68 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-007](#SP-007--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-008](#SP-008--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-009](#SP-009--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-010](#SP-010--PKG_VTS_BODYSHOP.SF_GET_PANEL) | PKG_VTS_BODYSHOP.SF_GET_PANEL |
| [SP-011](#SP-011--PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY) | PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY |
| [SP-012](#SP-012--PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT) | PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT |
| [SP-013](#SP-013--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-014](#SP-014--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-015](#SP-015--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-016](#SP-016--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-017](#SP-017--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-018](#SP-018--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-019](#SP-019--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-020](#SP-020--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-021](#SP-021--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-022](#SP-022--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-023](#SP-023--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-024](#SP-024--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-025](#SP-025--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-026](#SP-026--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-027](#SP-027--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-028](#SP-028--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-029](#SP-029--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-030](#SP-030--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-031](#SP-031--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-032](#SP-032--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-033](#SP-033--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-034](#SP-034--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-035](#SP-035--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-036](#SP-036--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-037](#SP-037--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-038](#SP-038--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-039](#SP-039--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-040](#SP-040--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-041](#SP-041--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-042](#SP-042--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-043](#SP-043--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-044](#SP-044--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-045](#SP-045--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-046](#SP-046--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-048](#SP-048--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-049](#SP-049--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-050](#SP-050--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-051](#SP-051--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-052](#SP-052--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-053](#SP-053--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-054](#SP-054--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-055](#SP-055--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-056](#SP-056--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-057](#SP-057--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-058](#SP-058--ADD_ERROR) | ADD_ERROR |
| [SP-059](#SP-059--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-060](#SP-060--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-061](#SP-061--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-062](#SP-062--DEBUGLOG) | DEBUGLOG |
| [SP-063](#SP-063--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-064](#SP-064--READ_REGISTRY) | READ_REGISTRY |
| [SP-065](#SP-065--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-066](#SP-066--SETDEBUG) | SETDEBUG |
| [SP-067](#SP-067--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-068](#SP-068--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Generates a CSV-formatted Excel report by executing a caller-supplied query, writing the resulting data rows to a server-side file, and then opening that file in a new browser window. The procedure derives the output file name from the current user ID and system timestamp, resolves the public URL path from a configuration text file, and enforces the 65,535-row Excel limit before streaming content.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-022](#SP-022--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-023](#SP-023--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-036](#SP-036--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-038](#SP-038--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-046](#SP-046--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output file name by concatenating the current Oracle Forms global user ID (`:global.userid`) with the current system date/time formatted as `YYYYMMDDHHMISS`, then append the `.csv` extension.
- Step 2 - Assign the derived file name to the `FILENAME` variable; if the derived name is NULL the assignment is skipped (no-op).
- Step 3 - Validate the file path for spaces: if `FILENAME` contains a space character, override the path to `C:\` and display a warning message informing the user that the file will be stored on the C drive as a default.
- Step 4 - Check whether a record group named `DataRecordSet` already exists; if it does, delete it to ensure a clean state before re-creation.
- Step 5 - Create a new record group named `DataRecordSet` from the caller-supplied query (`p_query`) using `Create_Group_From_Query`, then populate it with `Populate_Group`.
- Step 6 - Retrieve the total row count of the populated record group via `Get_Group_Row_Count`.
- Step 7 - If the row count exceeds 65,536, display a truncation warning message, clear the message, and cap the working row count at 65,535 to stay within Excel's row limit.
- Step 8 - Construct the server-side file path by prefixing `/iashome/ias/reports/printer/` with the bare file name (extracted from `FILENAME` using `INSTR`/`SUBSTR`).
- Step 9 - Open the URL configuration file `/reports/DMS/excelpath.txt` for reading using `TEXT_IO.FOPEN`, read the URL base path with `TEXT_IO.GET_LINE`, and close the file with `TEXT_IO.FCLOSE`.
- Step 10 - Construct the public URL (`formserverpath`) by concatenating the URL base path read in Step 9 with the bare file name.
- Step 11 - Open the server-side output file for writing using `TEXT_IO.FOPEN`.
- Step 12 - Locate the target column in the record group using `Find_Column` with the composite name `DataRecordSet.<p_column_name>`.
- Step 13 - Iterate through all rows (1 to `the_rowcount`): for each row, retrieve the character cell value via `GET_GROUP_CHAR_CELL` and write it as a line to the output file using `TEXT_IO.PUT_LINE`.
- Step 14 - Close the output file with `TEXT_IO.FCLOSE`.
- Step 15 - Launch the generated report in a new browser tab/window by calling `WEB.SHOW_DOCUMENT` with `formserverpath` and target `_blank`.
- Step 16 - On any exception, display an error message combining `ERROR_CODE` and `ERROR_TEXT`, then raise `FORM_TRIGGER_FAILURE` to halt processing.

---
**Decision Points**

DP-001

Condition:
The derived `vcFile` value is NULL.

TRUE:
No assignment is made; the `FILENAME` variable remains unset (NULL).

FALSE:
The `FILENAME` variable is assigned the value of `vcFile`.

---

DP-002

Condition:
`FILENAME` contains one or more space characters (`INSTR(FILENAME,' ') > 0`).

TRUE:
The file path is overridden to `C:\<bare file name>` and a warning message is displayed to the user indicating the default C drive location.

FALSE:
The original `FILENAME` path is retained unchanged.

---

DP-003

Condition:
A record group named `DataRecordSet` already exists (`NOT Id_Null(rg_id)`).

TRUE:
The existing record group is deleted with `Delete_Group` before a new one is created.

FALSE:
No deletion occurs; processing continues directly to record group creation.

---

DP-004

Condition:
The populated record group row count exceeds 65,536 rows.

TRUE:
A truncation warning message is displayed to the user and the effective row count is capped at 65,535.

FALSE:
The full row count is used without modification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output file name must be unique per user session; it is constructed by combining the Oracle Forms global user ID with the system timestamp (`YYYYMMDDHHMISS`) and the `.csv` extension.
- BR-002 - File paths containing spaces are not permitted; if a space is detected in the resolved file path, the output location is automatically redirected to the root of the C drive (`C:\`) and the user is notified.
- BR-003 - The record group `DataRecordSet` must be recreated fresh for each invocation; any pre-existing group with that name is deleted before the new query-based group is created.
- BR-004 - Excel output is limited to a maximum of 65,535 data rows; any result set exceeding 65,536 rows is silently truncated to 65,535 rows and the user is warned.
- BR-005 - The public URL base path for the generated report file must be read at runtime from the server configuration file `/reports/DMS/excelpath.txt`; it is not hard-coded in the procedure.
- BR-006 - The generated report must be presented to the user in a new browser window or tab (`_blank` target) via `WEB.SHOW_DOCUMENT`.
- BR-007 - Any unhandled exception must surface a descriptive error message (combining `ERROR_CODE` and `ERROR_TEXT`) and terminate the calling trigger by raising `FORM_TRIGGER_FAILURE`.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, 
 												 p_query VARCHAR2,
 												 p_column_name VARCHAR2) 
IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);

	vcfile varchar2(150);
	lv_user  varchar2(150);
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);

begin
	lv_user := name_in(':global.userid'); 
	vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS'); 
	vcFile := vcFile||'.csv';

	if vcFile is null then
		null;
	else
		filename:=vcFile;
	end if;
	
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;
--message('1 '||filename);	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
--message('2 '||server_file);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
--message('3');	
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
--message('4');	
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
--message('5');	
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
--message('6');
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	end loop;
    text_io.fclose(myfile);   
	 	web.show_document(formserverpath,'_blank');
--message('7');
exception when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
 
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The procedure normalises the target path using STRIPDIRSEP, confirms the file is accessible via TEXT_IO, loads the library, and optionally increments a module-level load counter and enables the API flag. It is invoked by REGISTER_FUNCTION_CALL to establish a valid library handle prior to function registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-067](#SP-067--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if null, skip path validation and proceed directly to the library load attempt.
- Step 2 - Normalise TargetPath by calling STRIPDIRSEP to remove any extraneous directory separators, then append a single trailing backslash ('\') to ensure a well-formed directory path. This also discards any additional paths that may have been concatenated into the value.
- Step 3 - Attempt to open the file at the concatenated path (TargetPath || TargetDLL) in read mode using TEXT_IO.FOPEN to confirm the DLL physically exists at the specified location.
- Step 4 - If the file is successfully opened, close it immediately with TEXT_IO.FCLOSE; the open was for existence verification only.
- Step 5 - If the file cannot be opened (any exception), call DEBUGLOG (severity 99) to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 7 - If the LoadCount flag is TRUE, increment the module-level DLL_LOAD_COUNT counter by 1 and set the module-level API_ENABLED flag to TRUE.
- Step 8 - Return the populated library handle (hDLL) to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return a null library handle to the caller.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP, append a trailing backslash, and perform file-existence verification before attempting the library load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the constructed file path (TargetPath || TargetDLL)

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log a debug message via DEBUGLOG recording the DLL name and the path where it was not found, then raise the BadLocation exception to halt processing.

---

DP-003

Condition: LoadCount parameter is TRUE

TRUE: Increment the module-level DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged after the successful library load.

---

DP-004

Condition: An unhandled exception occurs during or after the ORA_FFI.LOAD_LIBRARY call

TRUE: Set API_ENABLED to FALSE and return a null library handle to the caller.

FALSE: Return the valid library handle obtained from ORA_FFI.LOAD_LIBRARY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the first directory path value present in TargetPath is used; any additional concatenated paths are discarded by STRIPDIRSEP before the trailing separator is appended.
- BR-002 - TargetPath must be normalised to include exactly one trailing backslash ('\') before it is used for file verification or library loading.
- BR-003 - When TargetPath is provided, the DLL file must be physically accessible at the constructed path (TargetPath || TargetDLL); if it is not, the load is aborted and BadLocation is raised.
- BR-004 - A failed file-existence check must be recorded via DEBUGLOG at severity level 99, capturing the DLL name and the full path that was checked.
- BR-005 - The module-level DLL_LOAD_COUNT counter and API_ENABLED flag are updated only when the LoadCount parameter is passed as TRUE, allowing callers to suppress tracking for conditional or speculative load attempts.
- BR-006 - If the library load fails for any reason, API_ENABLED must be set to FALSE and a null library handle must be returned, ensuring the caller can detect an unsuccessful load without an unhandled exception propagating.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to the native C-level debug string routine exposed by the D2KWUTIL library. When invoked by WINDEBUG, it passes a function handle and a text string to the underlying C implementation (pragma interface code 11265), enabling debug output to be written through the Oracle Forms foreign-function interface (ORA_FFI) mechanism.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that identifies the registered C function entry point within the D2KWUTIL library.
- Step 2 - Receive the debug text string (Text) to be output.
- Step 3 - Delegate execution directly to the C-level d2kwutil_DebugString routine via the PRAGMA INTERFACE(C) binding using interface code 11265, passing both parameters as supplied.

---
**Decision Points**

No decision points are present. The procedure contains no conditional logic; it acts solely as a pass-through wrapper to the underlying C routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc); the handle is established externally by the invoking WINDEBUG routine before this procedure is called.
- BR-002 - The Text parameter carries the debug message content and is passed unmodified to the C layer; no transformation or validation of the string is performed within this procedure.
- BR-003 - Execution is bound to the C runtime via PRAGMA INTERFACE(C) with interface code 11265, meaning the procedure has no PL/SQL body and its behaviour is entirely determined by the D2KWUTIL native library.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-004 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle and a source environment variable name, then populates an expansion buffer with the resolved value, returning an integer status code to the caller. It is invoked exclusively by the GET_ENVIRONMENT_STRING stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying OS-level routine responsible for environment variable resolution.
- Step 2 - Accept the source environment variable name via SourceStr (IN OUT), which identifies the variable to be expanded.
- Step 3 - Accept the expansion output buffer via ExpandStr (IN OUT), pre-allocated to the length specified by InBuffLen, into which the resolved environment variable value will be written.
- Step 4 - Delegate execution to the native OS function referenced by hFunc, passing SourceStr and the buffer of size InBuffLen.
- Step 5 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) indicating the outcome of the environment variable lookup.

---
**Decision Points**

No explicit decision points are determinable from the available specification. The function signature exposes no conditional branching; control flow and success/failure discrimination are governed entirely by the return value interpreted by the calling routine GET_ENVIRONMENT_STRING.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must be initialised by the caller (GET_ENVIRONMENT_STRING) before this function is called.
- BR-002 - InBuffLen must accurately reflect the allocated size of the ExpandStr buffer to prevent buffer overrun when the OS writes the resolved environment variable value.
- BR-003 - SourceStr and ExpandStr are both IN OUT parameters; the caller must supply them as writable variables and must not pass literals.
- BR-004 - The function returns a PLS_INTEGER status code; the caller is responsible for evaluating this code to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper function that retrieves a Windows registry key value. It accepts a registry root identifier, a registry path, and an entry name, then populates the corresponding registry value string up to the specified maximum length, with an option to suppress environment-variable expansion. The function returns a PLS_INTEGER status code indicating the outcome of the registry read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows registry API entry point registered via ORA_FFI.
- Step 2 - Accept the registry root constant (RegRoot) that identifies the hive to query (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER).
- Step 3 - Accept the registry subkey path (RegPath) and the specific entry name (RegEntry) that together locate the target registry value.
- Step 4 - Accept the maximum buffer length (RegValueLength) that constrains how many characters may be written into RegValue, and the expansion flag (RegDontExpand) that controls whether REG_EXPAND_SZ environment variables are resolved.
- Step 5 - Invoke the native registry read operation through the ORA_FFI function handle, passing all supplied parameters.
- Step 6 - Populate the IN OUT parameter RegValue with the retrieved registry data, within the bounds of RegValueLength.
- Step 7 - Return a PLS_INTEGER result code to the caller (READ_REGISTRY in D2kwutil.pld) indicating success or failure of the registry read.

---
**Decision Points**

DP-001

Condition: RegDontExpand flag value passed by the caller.

TRUE (non-zero): The native registry call returns the raw REG_EXPAND_SZ string without resolving embedded environment-variable references before writing it to RegValue.

FALSE (zero): The native registry call expands any environment-variable references within the registry value before writing the result to RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function signature is defined as an ORA_FFI foreign-function declaration; no PL/SQL body exists in the source. Execution is delegated entirely to the native Windows registry API through the provided FFI function handle (hFunc).
- BR-002 - RegPath, RegEntry, and RegValue are declared IN OUT; the caller must supply adequately sized VARCHAR2 buffers, and the function may modify these values during the registry read operation.
- BR-003 - The number of characters written to RegValue must not exceed the value supplied in RegValueLength, enforcing a maximum buffer constraint on the returned registry data.
- BR-004 - The function returns a PLS_INTEGER status code; the invoking routine READ_REGISTRY is responsible for interpreting this code to determine whether the registry read succeeded or failed.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name supplied by the caller into the corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type codes required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and normalise it to upper case, storing the result in the local variable vcType.
- Step 2 - Evaluate vcType against each recognised C data type token in sequence using an IF-ELSIF chain.
- Step 3 - When a match is found, assign the corresponding ORA_FFI constant to the local return variable iRC (e.g., '*CHAR' -> ORA_FFI.C_CHAR_PTR, 'CHAR' -> ORA_FFI.C_CHAR, '*INT' -> ORA_FFI.C_INT_PTR, 'INT' -> ORA_FFI.C_INT, '*LONG' -> ORA_FFI.C_LONG_PTR, 'LONG' -> ORA_FFI.C_LONG, '*SHORT' or '*BYTE' -> ORA_FFI.C_SHORT_PTR, 'SHORT' or 'BYTE' -> ORA_FFI.C_SHORT, '*DOUBLE' -> ORA_FFI.C_DOUBLE_PTR, 'DOUBLE' -> ORA_FFI.C_DOUBLE, '*VOID' -> ORA_FFI.C_VOID_PTR).
- Step 4 - Return iRC to the caller; if no token matched, iRC remains uninitialised (NULL) and is returned as-is.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer-to-char type code).
FALSE: Evaluation continues to the next condition.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR (char type code).
FALSE: Evaluation continues to the next condition.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer-to-int type code).
FALSE: Evaluation continues to the next condition.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT (int type code).
FALSE: Evaluation continues to the next condition.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer-to-long type code).
FALSE: Evaluation continues to the next condition.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG (long type code).
FALSE: Evaluation continues to the next condition.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer-to-short type code; *BYTE is treated as an alias for *SHORT).
FALSE: Evaluation continues to the next condition.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT (short type code; BYTE is treated as an alias for SHORT).
FALSE: Evaluation continues to the next condition.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer-to-double type code).
FALSE: Evaluation continues to the next condition.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE (double type code).
FALSE: Evaluation continues to the next condition.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR (pointer-to-void type code).
FALSE: No branch is matched; iRC remains NULL and is returned to the caller without assignment.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is always normalised to upper case before comparison, making the lookup case-insensitive.
- BR-002 - The token '*BYTE' is treated as a synonym for '*SHORT'; both resolve to ORA_FFI.C_SHORT_PTR.
- BR-003 - The token 'BYTE' is treated as a synonym for 'SHORT'; both resolve to ORA_FFI.C_SHORT.
- BR-004 - Only pointer variants of CHAR, INT, LONG, SHORT/BYTE, DOUBLE, and VOID are supported as pointer types (prefix '*'); no pointer variant exists for VOID value-type, as '*VOID' maps to C_VOID_PTR and plain 'VOID' has no corresponding branch.
- BR-005 - If the supplied DataType token does not match any recognised value, the function returns NULL; no exception is raised and no default type code is substituted.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-007 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric indicator reflecting the button pressed. The function allows calling screens to present a yes/no confirmation prompt with a dynamic message and to branch their processing based on the user's response.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text supplied by the caller via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert dialog to the user using show_alert and capture the button pressed in p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed: if it equals ALERT_BUTTON1, return 1 to indicate the user confirmed; otherwise return 0 to indicate the user declined or dismissed the dialog.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the primary confirmation button of alert AL_CONFIRM).

TRUE:
The function returns 1, signalling to the caller that the user accepted or confirmed the prompted action.

FALSE:
The function returns 0, signalling to the caller that the user declined or did not select the primary confirmation button.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert must use the predefined alert component AL_CONFIRM; no other alert name is permitted within this function.
- BR-002 - The alert message text must be set dynamically at runtime from the confirm_msg parameter before the alert is displayed, ensuring the prompt is contextually relevant to the calling operation.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button selection must result in a return value of 0, treating all non-primary responses as a rejection.
- BR-004 - The function produces no side effects on database state; its sole output is the numeric confirmation indicator returned to the caller.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-008 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Centralises post-operation failure detection for the KEY-COMMIT trigger. After a form operation, the procedure inspects the Oracle Forms built-in success indicator and, if a failure is detected, determines whether the error originated from the database (ORA) or the Forms runtime (FRM), displays the appropriate error message to the user via GENERAL.DISP_TEXT, and then halts further trigger processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-009](#SP-009--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the Oracle Forms built-in FORM_SUCCESS indicator to determine whether the preceding form operation completed without error.
- Step 2 - If the operation did not succeed, inspect the ERROR_TYPE built-in to classify the source of the failure.
- Step 3 - If ERROR_TYPE is 'ORA' (database-layer error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the Oracle database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (Forms runtime error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms engine error to the user.
- Step 5 - Raise FORM_TRIGGER_FAILURE to abort the KEY-COMMIT trigger and prevent any further commit processing.
- Step 6 - If FORM_SUCCESS returned TRUE in Step 1, no action is taken and the procedure exits normally.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (the preceding form operation failed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No error has occurred; the procedure exits without taking any action.

---

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated at the database layer).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM and severity label 'Error' to present the Oracle database error message to the user.

FALSE: Evaluate the next condition (DP-003).

---

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated in the Oracle Forms runtime).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT and severity label 'Error' to present the Forms runtime error message to the user.

FALSE: No matching error-type branch is executed; processing continues to raise FORM_TRIGGER_FAILURE regardless.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation must not be allowed to complete silently when a form-level failure has occurred; any failure detected by FORM_SUCCESS must result in user notification and trigger abortion.
- BR-002 - Database errors (ERROR_TYPE = 'ORA') must be reported using the Oracle-supplied error message returned by SQLERRM, ensuring the user receives the exact database-layer error detail.
- BR-003 - Forms runtime errors (ERROR_TYPE = 'FRM') must be reported using the Forms-supplied ERROR_TEXT, ensuring the user receives the exact runtime error detail.
- BR-004 - All error messages displayed by this procedure must be classified with severity label 'Error' when passed to GENERAL.DISP_TEXT.
- BR-005 - Upon detecting any form failure, FORM_TRIGGER_FAILURE must always be raised to unconditionally halt the KEY-COMMIT trigger, regardless of which error-type branch was executed.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-009 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- vr_bodyshop_prod_fmb.xml [Trigger: ON-MESSAGE]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate Oracle Forms alert component based on whether the title indicates an error condition, then presents the alert with the supplied text.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value (case-insensitive) to determine which alert component to use: if the title equals 'ERROR', assign the alert name 'AL_ERRINFO'; otherwise assign 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert to the supplied title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert to the supplied text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT and capture the user's response in a local variable.

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert component 'AL_ERRINFO' is selected, indicating an error-severity dialog will be presented to the user.

FALSE:
The alert component 'AL_NOTE' is selected, indicating an informational or non-error dialog will be presented to the user.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title_string value is evaluated case-insensitively; any capitalisation variant of 'ERROR' triggers the error alert ('AL_ERRINFO'), ensuring consistent error presentation regardless of caller casing.
- BR-002 - All non-error titles (i.e., any title_string that is not 'ERROR') result in the informational alert ('AL_NOTE') being used, providing a distinct visual treatment for non-critical messages.
- BR-003 - Both the alert title and the alert message text are dynamically overwritten at runtime via SET_ALERT_PROPERTY before display, ensuring the alert always reflects the exact text and title passed by the caller rather than any design-time defaults.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-010 - PKG_VTS_BODYSHOP.SF_GET_PANEL

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the total number of windshield panels associated with a specific repair order by summing the PANEL_WNSHLD column from VT_VTS. The result is used by the Bodyshop production screen to determine the panel count for a given parent group, dealer map code, location, and repair order number combination.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept five input parameters identifying the repair order context: parent group (p_pgroup), dealer map code (p_dealermap), location code (p_loc), company code (p_comp), and repair order number (p_ronum).
- Step 2 - Initialise the local variable LV_PANEL to 0 as the default panel count.
- Step 3 - Query VT_VTS, summing the PANEL_WNSHLD column for all rows that match the supplied parent_group, dealer_map_cd, loc_cd, and ro_NUM values.
- Step 4 - Store the aggregated result in LV_PANEL.
- Step 5 - Return LV_PANEL, substituting 0 via NVL if the query produces a NULL result (e.g. no matching rows found).

---
**Decision Points**

DP-001

Condition:
The SUM of PANEL_WNSHLD returned from VT_VTS for the given filter criteria is NULL (i.e. no matching rows exist).

TRUE:
NVL converts the NULL value to 0, and 0 is returned to the caller.

FALSE:
The actual aggregated panel count is returned to the caller.

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
**Business Rules**

- BR-001 - The panel count is derived exclusively from the PANEL_WNSHLD column in VT_VTS; no other panel-type columns contribute to the returned value.
- BR-002 - Records in VT_VTS must match all four filter criteria simultaneously (parent_group, dealer_map_cd, loc_cd, and ro_NUM) to be included in the aggregation; the p_comp parameter is accepted as input but is not applied as a filter in the query.
- BR-003 - A NULL aggregate result (no matching repair order records) is treated as a zero panel count, ensuring the caller always receives a valid numeric value.
- BR-004 - The function is read-only; it performs no inserts, updates, or deletes against any database table.

---
**Implementation Logic**

```plsql

  function sf_get_panel(p_pgroup    varchar2,
                        p_dealermap number,
                        p_loc       varchar2,
                        p_comp      varchar2,
                        p_ronum     varchar2) RETURN NUMBER IS

    LV_PANEL NUMBER := 0;

  BEGIN
    SELECT sum(panel_wnshld)
      into LV_PANEL
      FROM VT_VTS
     WHERE parent_group = p_pgroup
       and dealer_map_cd = p_dealermap
       and loc_cd = p_loc
       and ro_NUM = p_ronum;

    RETURN NVL(LV_PANEL, 0);
  END sf_get_panel;
```

#### SP-011 - PKG_VTS_BODYSHOP.SF_GET_VTS_NO_BAY

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Returns the total count of active bodyshop bays configured for a given parent group, dealer map code, and location. The result is used by the bodyshop production screen to determine how many bays are available before proceeding with bay-related operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the local bay count variable (LV_BAY_CNT) to zero.
- Step 2 - Query VM_BAY_MAST to count all records that match the supplied parent group (p_pgroup), dealer map code (p_dealermap), and location code (p_loc) where the bay is marked as active (active_YN = 'Y').
- Step 3 - If any exception occurs during the query (e.g., unexpected database error), suppress the exception and retain LV_BAY_CNT as zero.
- Step 4 - Return LV_BAY_CNT to the caller as the active bay count.

---
**Decision Points**

DP-001

Condition:
An exception is raised during the COUNT query against VM_BAY_MAST.

TRUE:
The exception is caught by the WHEN OTHERS handler; LV_BAY_CNT is set to 0 and execution continues to the RETURN statement.

FALSE:
The COUNT result is stored in LV_BAY_CNT and returned normally.

---
**Database Interactions**

- DB-001 - Read VM_BAY_MAST - Reads data from VM_BAY_MAST for lookup or validation.
**Business Rules**

- BR-001 - Only bays flagged as active (active_YN = 'Y') in VM_BAY_MAST are included in the count; inactive bays are excluded regardless of other matching criteria.
- BR-002 - The bay count is scoped to the intersection of parent group, dealer map code, and location code; all three input parameters must match for a bay record to be counted.
- BR-003 - If no matching active bays exist, or if a database error occurs, the function returns zero rather than raising an error to the caller, ensuring the invoking screen receives a safe numeric default.

---
**Implementation Logic**

```plsql

  function sf_get_vts_no_bay(p_pgroup    varchar2,
                             p_dealermap number,
                             p_loc       varchar2) RETURN NUMBER IS
    LV_BAY_CNT NUMBER := 0;

  begin
    begin
      select count(*)
        into LV_BAY_CNT
        from VM_BAY_MAST
       where parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and active_YN = 'Y';
    exception
      when others then
        LV_BAY_CNT := 0;
    end;
    RETURN LV_BAY_CNT;
  end sf_get_vts_no_bay;
```

#### SP-012 - PKG_VTS_BODYSHOP.SF_GET_WORKING_DAY_CNT

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PARAMETERS (N/A / CN_MAIN)

---

**Purpose**

Calculates the number of working days between two dates (inclusive) for a given dealer, location, and parent group by iterating through each calendar day in the range and excluding any dates recorded as holidays or leave days in the WD_BTN table. The resulting count is returned to the caller for use in bodyshop production scheduling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_frm_dt | date | IN |
| p_to_dt | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Truncate the input from-date and to-date to remove any time component, establishing clean start and end boundaries for the day-count loop.
- Step 2 - Initialise the working day counter (lv_day_cnt) and the holiday counter (LV_HOLIDAY_CNT) to zero.
- Step 3 - Enter a loop that iterates one calendar day at a time from lv_start_dt through lv_end_dt (inclusive); the loop exits when lv_start_dt advances past lv_end_dt.
- Step 4 - For each day in the loop, query the WD_BTN table to count rows where the parent_group, dealer_map_cd, loc_cd, and LEAVE_DATE all match the current iteration date. If the query raises any exception, default LV_HOLIDAY_CNT to 0.
- Step 5 - If no matching holiday/leave record is found (LV_HOLIDAY_CNT = 0), increment the working day counter by 1; otherwise leave the counter unchanged, effectively skipping that day.
- Step 6 - Advance lv_start_dt by one day and repeat from Step 4.
- Step 7 - After the loop completes, return the accumulated working day count (lv_day_cnt) to the caller.

---
**Decision Points**

DP-001

Condition:
lv_start_dt = lv_end_dt + 1 (current iteration date has moved one day beyond the end date)

TRUE:
Exit the loop; all days in the range have been evaluated.

FALSE:
Continue processing the current date - query WD_BTN for a holiday record and apply the working-day increment logic.

---

DP-002

Condition:
LV_HOLIDAY_CNT = 0 (no holiday or leave record exists in WD_BTN for the current date, parent group, dealer, and location)

TRUE:
The current date is a working day; increment lv_day_cnt by 1.

FALSE:
The current date is a non-working day (holiday/leave); lv_day_cnt is not incremented and the day is excluded from the count.

---
**Database Interactions**

- DB-001 - Read WD_BTN - Reads data from WD_BTN for lookup or validation.
**Business Rules**

- BR-001 - Both the from-date and to-date are truncated to midnight before processing, ensuring that any time-of-day component in the input parameters does not affect the day boundary calculations.
- BR-002 - The date range is treated as fully inclusive; the from-date and the to-date are both eligible to be counted as working days.
- BR-003 - A day is classified as a non-working day only when a matching record exists in WD_BTN for the combination of parent_group, dealer_map_cd, loc_cd, and LEAVE_DATE; all other days are treated as working days.
- BR-004 - The holiday lookup is scoped to the specific parent group, dealer map code, and location supplied by the caller, ensuring that holiday calendars are applied at the correct organisational and geographic level.
- BR-005 - Any database exception raised during the WD_BTN lookup for a given date is silently suppressed and treated as no holiday found (LV_HOLIDAY_CNT defaults to 0), preventing a single query failure from aborting the entire calculation.
- BR-006 - The function returns a pure numeric count of working days with no side-effects; it does not modify any database records.

---
**Implementation Logic**

```plsql

  function sf_get_working_day_cnt(p_pgroup    varchar2,
                                  p_dealermap number,
                                  p_loc       varchar2,
                                  p_frm_dt    date,
                                  p_to_dt     date) RETURN NUMBER IS
    lv_start_dt    date;
    lv_end_dt      date;
    lv_day_cnt     number := 0;
    LV_HOLIDAY_CNT number := 0;
  begin
    begin
      lv_start_dt := trunc(p_frm_dt);
      lv_end_dt   := trunc(p_to_dt);
      LOOP
        exit when lv_start_dt = lv_end_dt + 1;
        begin
          SELECT COUNT(*)
            INTO LV_HOLIDAY_CNT
            FROM WD_BTN
           where parent_group = p_pgroup
             and dealer_map_cd = p_dealermap
             and loc_cd = p_loc
             and LEAVE_DATE = lv_start_dt;
        exception
          when others then
            LV_HOLIDAY_CNT := 0;
        end;
        if LV_HOLIDAY_CNT = 0 then
          lv_day_cnt := lv_day_cnt + 1;
        end if;
        lv_start_dt := lv_start_dt + 1;
      END LOOP;
    end;
    return lv_day_cnt;
  end sf_get_working_day_cnt;
```

#### SP-013 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before continuing. The function delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-021](#SP-021--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing cmd as the command argument and BLOCKING_MODE as the execution mode flag.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller.

---
**Decision Points**

No conditional decision points exist within this function. Execution flow is unconditional: the function always calls WEBUTIL.EXECUTE with BLOCKING_MODE and returns the resulting PROCESS_ID.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The function returns a PROCESS_ID, allowing the caller to reference or track the completed process after execution.
- BR-003 - All actual command execution responsibility is delegated to WEBUTIL.EXECUTE (SP-021); WEBUTIL.BLOCKING introduces no additional processing or validation logic of its own.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-014 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the correct version. For each library defined in the property bundle for the client's OS family and architecture, the procedure compares the installed version against the expected version and, where a mismatch or absence is detected, downloads the library from the configured URL and records the newly installed version on the client. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-018](#SP-018--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-026](#SP-026--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-044](#SP-044--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-048](#SP-048--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-052](#SP-052--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Begin iterating through sequentially numbered library entries in the property bundle using the key pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>', incrementing the index counter (lib) on each iteration.
- Step 2 - If no entry is found for the OS-family/architecture-specific key, fall back to the OS-family-only key pattern 'install.syslib.<OSFamily>.<packageID>.<index>' via WEBUTIL.READFROMPROPERTYBUNDLE.
- Step 3 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 4 - Parse the retrieved library specification string (pipe-delimited) into its four components: library file name (position 1), expected file size in bytes (position 2), expected version string (position 3), and a progress-display flag (position 4).
- Step 5 - Query the client's current installed version for the library by calling WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>'.
- Step 6 - Evaluate whether a download is required: the installed version is absent, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 7 - If a download is required, resolve the download base URL by attempting three successive lookups via WEBUTIL.READFROMPROPERTYBUNDLE: OS-family/architecture-specific location, then OS-family-only location, then the generic 'install.syslib.location' key, using the first non-NULL value found.
- Step 8 - Invoke WEBUTIL.DOWNLOADFROMURLINT to download the library file from the resolved URL, passing the file name, size, progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 9 - If the download succeeds, record the newly installed version on the client by calling WEBUTIL.SETCLIENTSETTING with the key 'syslib.<libName>' and the expected version string.
- Step 10 - If the download fails, log an error message via WEBUTIL.LOG indicating which library could not be downloaded, then continue to the next library entry.

---
**Decision Points**

DP-001

Condition: The OS-family/architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL value.

TRUE: Use the returned library specification string for this iteration.

FALSE: Attempt the OS-family-only fallback key ('install.syslib.<OSFamily>.<packageID>.<index>') via WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-002

Condition: The OS-family-only fallback key also returns NULL.

TRUE: No further library entries exist for this package; exit the loop.

FALSE: Use the returned library specification string for this iteration and continue processing.

---

DP-003

Condition: The installed version retrieved from WEBUTIL.GETCLIENTSETTING is NULL, does not match the expected version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip to the next loop iteration without downloading.

---

DP-004

Condition: The OS-family/architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base URL.

FALSE: Attempt the OS-family-only location key ('install.syslib.location.<OSFamily>') via WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-005

Condition: The OS-family-only download location key returns a non-NULL URL.

TRUE: Use this URL as the download base URL.

FALSE: Attempt the generic location key ('install.syslib.location') via WEBUTIL.READFROMPROPERTYBUNDLE.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the expected version against the library key on the client via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message for the library via WEBUTIL.LOG and continue to the next library entry.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library entries for a package are resolved in ascending numeric order; processing stops as soon as a sequentially numbered entry is absent from the property bundle for both the architecture-specific and OS-family-only key patterns.
- BR-002 - Architecture-specific library definitions take precedence over OS-family-only definitions; the OS-family-only key is consulted only when the architecture-specific key yields no result.
- BR-003 - A library must be downloaded if and only if its client-side installed version is absent, does not exactly match the version declared in the property bundle, or the REDOWNLOAD_SYSLIB override flag is active.
- BR-004 - The download base URL is resolved with a three-level fallback hierarchy (OS-family + architecture -> OS-family only -> generic); the first non-NULL value found is used.
- BR-005 - The full download URL is constructed by appending a forward slash and the library file name to the resolved base URL.
- BR-006 - The client's recorded version for a library is updated via WEBUTIL.SETCLIENTSETTING only upon confirmed successful download; a failed download must not update the version record.
- BR-007 - A failed library download must be logged as an error via WEBUTIL.LOG with sufficient detail to identify the affected library, but must not halt processing of remaining library entries for the package.
- BR-008 - Progress dialog labels presented during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localisation compliance.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-015 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up callback registrations that are no longer required, ensuring the collection does not retain stale or orphaned entries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the target callback entry within the package-level collection m_callbacks.
- Step 2 - Check whether an entry with the supplied key currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection using the provided key.
- Step 4 - If no entry exists for the supplied key, take no action and return silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.EXISTS(callbackKey) - an entry with the supplied key is present in the m_callbacks collection.

TRUE: The entry is deleted from m_callbacks via m_callbacks.DELETE(callbackKey), removing the callback registration.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to delete a callback entry if that entry already exists in the m_callbacks collection; deletion of a non-existent key is not permitted and is silently bypassed.
- BR-002 - The callbackKey parameter uniquely identifies a single entry in the m_callbacks collection; only the entry matching that exact key is removed, leaving all other entries intact.
- BR-003 - No output or exception is raised when the specified callbackKey is not found in the collection; the operation is treated as a no-op in that scenario.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-016 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, releasing any server-side resources associated with the BLOB session for the given checksum.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the identifying key.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in this procedure. All conditional logic is encapsulated within WebUtil_DB.CloseBlob; this function unconditionally delegates to that routine and returns its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a previously opened BLOB handle; the validity of the checksum is enforced by the delegated call to WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is determined solely by the return value of WebUtil_DB.CloseBlob; WEBUTIL.CLOSEBLOB must propagate that result unchanged to its caller.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-017 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file handle represented by the supplied Java object. The procedure delegates the close operation to the native Java class oracle/forms/webutil/fileTransfer/AppServerFileReader by invoking its closeFile method via the JNI bridge, ensuring that file resources held on the application server are properly released after a file transfer or read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents the open AppServerFileReader file handle on the application server.
- Step 2 - Reset the shared argument list (args) to NULL to ensure no stale parameters are passed to the JNI call.
- Step 3 - Invoke the closeFile method on the AppServerFileReader Java class through JNI.CALL_BOOLEAN_METHOD, passing the object reference and a no-argument method signature ('()Z').
- Step 4 - Return the BOOLEAN result produced by the JNI call to the caller (WEBUTIL.SETDATA), indicating whether the file was successfully closed.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI method call and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args parameter must be set to NULL before the JNI call to guarantee that no residual arguments from a prior operation are inadvertently passed to the closeFile method.
- BR-002 - The file close operation must target the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class using the exact no-argument method signature '()Z'; any deviation would result in an incorrect or failed JNI dispatch.
- BR-003 - The function must return the BOOLEAN outcome of the JNI call to the invoking routine (WEBUTIL.SETDATA), allowing the caller to determine whether the server-side file handle was successfully released.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-018 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initiates a client-side file download by transferring a file from a specified URL to a designated local destination. The function assembles a delimited command string from the supplied parameters-destination type, expected file size, progress-display preferences, and path information-and dispatches it to the WebUtil Core bean via a property set/get round-trip, returning TRUE if the download completes successfully and FALSE otherwise.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its character representation. Append the pipe separator after each token.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its character representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate the remaining fields to the submit string in order: sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null), each separated by the pipe delimiter.
- Step 7 - Invoke WebUtil_Core.setProperty to dispatch the assembled submit string to the WebUtil Core bean under the property key WUC_URL_DOWNLOAD.
- Step 8 - Invoke WebUtil_Core.getProperty to retrieve the outcome from the bean for the same property key.
- Step 9 - Return TRUE if the retrieved result equals the literal string 'TRUE'; return FALSE otherwise.
- Step 10 - Handle exceptions: CLIENT_FILE_NULL logs error code 130 and returns FALSE; URL_NULL logs error code 25 and returns FALSE; BEAN_NOT_REGISTERED raises an alert identifying the missing bean class and raises FORM_TRIGGER_FAILURE; PROPERTY_ERROR raises FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception, which is caught in the exception block, logs error code 25 referencing WEBUTIL_CORE.DownloadFromURLInt, and returns FALSE.

FALSE: Proceed to validate clientDestination.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception, which is caught in the exception block, logs error code 130 referencing WEBUTIL_CORE.DownloadFromURLInt, and returns FALSE.

FALSE: Proceed to build the submit string.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append the literal '0' (default destination type) followed by the pipe separator to the submit string.

FALSE: Append the character representation of specialDestination followed by the pipe separator to the submit string.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append the literal '0' (zero file size) followed by the pipe separator to the submit string.

FALSE: Append the character representation of fileSize followed by the pipe separator to the submit string.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' (no progress display) followed by the pipe separator to the submit string.

FALSE: Append 'Y' (show progress display) followed by the pipe separator to the submit string.

---

DP-006

Condition: WebUtil_Core.getProperty returns the string 'TRUE'

TRUE: The function returns the boolean value TRUE, indicating the download succeeded.

FALSE: The function returns the boolean value FALSE, indicating the download did not succeed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is an invalid invocation and causes the function to abort with error code 25 without attempting the download.
- BR-002 - A client destination path must be provided; a null clientDestination is an invalid invocation and causes the function to abort with error code 130 without attempting the download.
- BR-003 - The specialDestination value must be 0, 1, or 2; any null, negative, or out-of-range value is silently normalised to 0 before the command string is assembled.
- BR-004 - A null fileSize is treated as 0 (unknown or unspecified size) in the command string sent to the bean.
- BR-005 - A null withProgress flag is treated as FALSE ('N'), meaning no progress indicator is displayed unless explicitly requested.
- BR-006 - Null values for progressTitle, progressSubTitle, and progressMessage are substituted with a single space character to preserve the fixed pipe-delimited field structure expected by the WebUtil Core bean.
- BR-007 - The WebUtil Core bean must be registered in the form; if it is not (BEAN_NOT_REGISTERED), an error alert is raised identifying the missing implementation class and processing is halted via FORM_TRIGGER_FAILURE.
- BR-008 - A PROPERTY_ERROR returned by the WebUtil Core bean is treated as a fatal condition and halts processing via FORM_TRIGGER_FAILURE.
- BR-009 - The function return value is determined solely by whether the bean's response string equals the literal 'TRUE'; any other response, including an empty string, evaluates to FALSE.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-019 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then writes the assembled message to the WebUtil core property 'WUC_ERROR_MSG' for the given package instance. This provides a standardised mechanism for reporting errors back to the WebUtil client-side layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text by concatenating the literal prefix 'ERROR' with the error code left-padded to three digits and the program unit name, separated by pipe ('|') delimiters.
- Step 2 - Evaluate whether the optional argument arg1 has been supplied; if it is not null, append a pipe delimiter followed by arg1 to the error text string.
- Step 3 - Evaluate whether the optional argument arg2 has been supplied; if it is not null, append a pipe delimiter followed by arg2 to the error text string.
- Step 4 - Evaluate whether the optional argument arg3 has been supplied; if it is not null, append a pipe delimiter followed by arg3 to the error text string.
- Step 5 - Invoke Webutil_Core.setProperty, passing the packageID, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to persist the error message for the calling package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append '|' || arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append '|' || arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append '|' || arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; processing continues to the final step.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error code must be formatted as a zero-padded three-digit number (e.g., code 5 becomes '005') to ensure consistent message structure across all error types.
- BR-002 - The error message string must always begin with the prefix 'ERROR' followed by the padded code and the program unit name, separated by pipe delimiters, establishing a mandatory minimum structure for every error message.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error message only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - The assembled error message must be stored against the property key 'WUC_ERROR_MSG' for the specified packageID via Webutil_Core.setProperty, ensuring the error is accessible to the WebUtil client-side event handler that invoked this procedure.
- BR-005 - The error text string is constrained to a maximum of 1 024 characters; error messages exceeding this length will be truncated at the variable boundary.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-020 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the procedure renders the supplied error text inside that alert dialog; otherwise it falls back to the standard Forms MESSAGE built-in. It is called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE to surface bean-registration or bean-not-found errors in a consistent, user-visible manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-038](#SP-038--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error text string (errText) passed by the calling procedure (FCLOSE, LOG, or POPULATEPROPERTYBUNDLE).
- Step 2 - Call WEBUTIL.ID_NULL (SP-038) to test whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If m_errorAlert is valid, set the ALERT_MESSAGE_TEXT property of the alert to the supplied errText using SET_ALERT_PROPERTY.
- Step 4 - Display the configured alert dialog to the user by invoking SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid (ID_NULL returns TRUE), fall back to the Forms MESSAGE built-in, concatenating the literal prefix 'WebUtil Error: ' with errText to form the displayed message.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - i.e., the alert handle m_errorAlert is not null and refers to a registered alert object.

TRUE:
Set the ALERT_MESSAGE_TEXT property of m_errorAlert to the supplied errText and display the alert dialog via SHOW_ALERT; the user sees a modal alert titled with the pre-configured alert title.

FALSE:
The alert object is unavailable; display the error using the Forms MESSAGE built-in with the prefix 'WebUtil Error: ' prepended to errText.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error messages must always be surfaced to the user; the procedure must never silently swallow the error text regardless of alert availability.
- BR-002 - When a valid alert handle exists, the alert's ALERT_MESSAGE_TEXT property is overwritten with the current errText on every invocation; the alert title is not modified at runtime (it is set at design time in the alert's property sheet).
- BR-003 - The return value of SHOW_ALERT is intentionally discarded; no branching logic is applied based on the user's button selection.
- BR-004 - The fallback MESSAGE output must prefix the error text with 'WebUtil Error: ' to maintain a consistent error identification convention across both display paths.
- BR-005 - Determination of alert handle validity is delegated exclusively to WEBUTIL.ID_NULL (SP-038); no inline null check is performed directly within this procedure.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-021 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell or operating-system command for execution on the client machine by delegating to the WebUtil host bean. The procedure sets the desired execution mode, passes the command string to the WebUtil Core layer, and returns a process handle that the caller can use to reference the spawned process. If the required WebUtil bean is not registered on the client, an error alert is raised and no process is started.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode flag (exemode) as inputs.
- Step 2 - Evaluate whether cmd is non-null; if it is null, skip all processing and return an uninitialised PROCESS_ID to the caller.
- Step 3 - Set the execution mode on the WebUtil host bean by calling WebUtil_Core.setProperty with the WUH_PACKAGE target, property key WUH_EXECUTION_MODE, and the supplied exemode value.
- Step 4 - Pass the command string to the WebUtil host bean by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, convert the returned string to a number, and store it in the handle field of the local PROCESS_ID variable.
- Step 6 - Return the populated PROCESS_ID (containing the numeric process handle) to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point, display an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class and indicating that WEBUTIL_HOST.Execute will not function.

---
**Decision Points**

DP-001

Condition: cmd IS NOT NULL

TRUE: Set the execution mode property on the WebUtil host bean, submit the command string to the bean, retrieve and store the returned process handle, and return the populated PROCESS_ID to the caller.

FALSE: Bypass all bean interaction and return an uninitialised PROCESS_ID to the caller.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property operations

TRUE: Display an error alert via WebUtil_Core.ErrorAlert that identifies the unregistered bean class and states that WEBUTIL_HOST.Execute will not work; no process handle is returned.

FALSE: No exception occurs; normal execution continues and the process handle is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string (cmd) must be treated as a no-operation; the function must return an uninitialised PROCESS_ID without attempting any bean interaction.
- BR-002 - The execution mode (exemode) must be applied to the WebUtil host bean before the command string is submitted, ensuring the bean uses the correct mode for the process it spawns.
- BR-003 - The numeric process handle returned by the bean after command submission must be captured and surfaced to the caller as the handle field of the PROCESS_ID return value, enabling the caller to track or reference the spawned process.
- BR-004 - If the WebUtil host bean is not registered on the client, the function must not propagate an unhandled exception; instead it must display a descriptive error alert identifying the missing bean class and the affected functionality, then terminate gracefully.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-022 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by releasing its handle through the WebUtil core layer. The procedure nullifies the file handle upon successful closure and raises a terminal error if the underlying WebUtil bean is unavailable or if the close operation itself fails, ensuring that dangling file handles are not left in an inconsistent state.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-020](#SP-020--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-027](#SP-027--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file object (file_type) passed IN OUT, which carries the current file handle.
- Step 2 - Check whether the file handle is not NULL; only an open, active file requires a close operation.
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE identifier and the WUF_TEXTIO_CLOSE command to instruct the client-side WebUtil bean to physically close the file.
- Step 4 - After the close command is issued successfully, set file.handle to NULL to mark the file object as closed and prevent reuse of a stale handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised (the WebUtil bean is not available on the client), call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that identifies the missing bean class (resolved through WEBUTIL.GETIMPLCLASS) and states that CLIENT_TEXT_IO.fclose will not work; then raise TOOL_ERR.TOOL_ERROR to abort the calling process.
- Step 6 - If a PROPERTY_ERROR exception is raised (the close property command failed), raise TOOL_ERR.TOOL_ERROR immediately to abort the calling process without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to issue the WebUtil_Core.setProperty close command and subsequently null the handle.

FALSE:
Skip the close operation entirely; no action is taken and no error is raised for an already-closed or uninitialised file.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close operation

TRUE:
Call WEBUTIL.ERRORALERT (WebUtil_Core.ErrorAlert) with a message constructed using WEBUTIL.GETIMPLCLASS to identify the missing bean, then raise TOOL_ERR.TOOL_ERROR to terminate processing.

FALSE:
Exception is not raised; normal close flow continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the close operation

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to terminate processing; no alert is displayed.

FALSE:
Exception is not raised; normal close flow continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is not NULL; calling FCLOSE on an already-closed or uninitialised file object is silently ignored.
- BR-002 - Once the WebUtil bean successfully closes the file, the handle must be set to NULL immediately to prevent any subsequent operation from referencing a stale or invalid handle.
- BR-003 - If the WebUtil bean required for client-side text I/O is not registered, the procedure must surface a user-facing error alert (via WEBUTIL.ERRORALERT) that includes the resolved implementation class name (via WEBUTIL.GETIMPLCLASS) before terminating, ensuring the operator has actionable diagnostic information.
- BR-004 - Both bean-not-found and property-error failure conditions must result in TOOL_ERR.TOOL_ERROR being raised, ensuring the calling routine (VIEW_EXCEL_REP) is notified of the failure and cannot continue in an undefined state.
- BR-005 - No database interactions are performed; all file operations are delegated entirely to the client-side WebUtil bean layer.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-023 - WEBUTIL.FOPEN

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file for reading, writing, or appending on behalf of the Oracle Forms runtime environment. The function validates the supplied file path and access mode, communicates the open request to the WebUtil Java bean layer via WEBUTIL.GETPROPERTY, and returns a typed file handle that calling routines (such as VIEW_EXCEL_REP) can use for subsequent file I/O operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-033](#SP-033--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is not recognised.
- Step 2 - Validate the file specification: confirm that the `spec` parameter is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR if no file path has been provided.
- Step 3 - Transmit the file name to the WebUtil bean layer by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and the property key 'WUF_FILENAME', passing the `spec` value.
- Step 4 - Transmit the file mode to the WebUtil bean layer by calling WebUtil_Core.setProperty with the property key 'WUF_TEXTIO_FILEMODE', passing the `filemode` value.
- Step 5 - Transmit the character set to the WebUtil bean layer by calling WebUtil_Core.setProperty with the property key 'WUF_TEXTIO_CHARSET'. If `charSet` is NULL the literal string '(null)' is passed; otherwise the supplied `charSet` value is passed.
- Step 6 - Request the file open operation and retrieve the resulting Java file handle by invoking WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) with the property key 'WUF_TEXTIO_OPEN'. The return value is stored in the local variable `javaHandle`.
- Step 7 - Validate the returned handle: if `javaHandle` is NULL, empty, or equals '-1', the file could not be opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid string handle to a numeric value and assign it to the `handle` field of the `clientFile` record of type FILE_TYPE.
- Step 9 - Return the populated FILE_TYPE record to the caller.

---
**Decision Points**

DP-001

Condition:
The `filemode` parameter (converted to lower case) is NOT one of 'r', 'w', or 'a'.

TRUE:
Raise TOOL_ERR.TOOL_ERROR; processing halts and no file open attempt is made.

FALSE:
Continue to the file specification validation step.

---

DP-002

Condition:
The `spec` parameter is NULL or an empty string.

TRUE:
Raise TOOL_ERR.TOOL_ERROR; processing halts and no file open attempt is made.

FALSE:
Continue to transmit file open properties to the WebUtil bean layer.

---

DP-003

Condition:
The `charSet` parameter is NULL.

TRUE:
Pass the literal string '(null)' as the WUF_TEXTIO_CHARSET property value to the WebUtil bean layer.

FALSE:
Pass the actual `charSet` value as the WUF_TEXTIO_CHARSET property value.

---

DP-004

Condition:
The `javaHandle` returned by WEBUTIL.GETPROPERTY is NULL, empty, or equals '-1'.

TRUE:
Raise TOOL_ERR.TOOL_ERROR; the file was not successfully opened on the client.

FALSE:
Convert `javaHandle` to a number, populate the FILE_TYPE record, and return it to the caller.

---

DP-005

Condition:
The exception handler catches BEAN_NOT_REGISTERED from WebUtil_Core.

TRUE:
Display an error alert identifying the missing bean class, then raise TOOL_ERR.TOOL_ERROR and return NULL; CLIENT_TEXT_IO file operations will not function.

FALSE:
Not applicable; this branch is only entered when the specific exception is raised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file access mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append); any other value is rejected before any file system interaction occurs.
- BR-002 - A non-null, non-empty file path specification must be provided; the function will not attempt to open an unnamed file.
- BR-003 - When no character set is explicitly supplied by the caller, the WebUtil bean layer is instructed to use its default character set by receiving the sentinel value '(null)' for the WUF_TEXTIO_CHARSET property.
- BR-004 - A Java handle value of NULL, empty string, or '-1' is treated as a failed open attempt and is not returned to the caller; TOOL_ERR.TOOL_ERROR is raised instead.
- BR-005 - The Java file handle retrieved via WEBUTIL.GETPROPERTY must be convertible to a NUMBER; a VALUE_ERROR during conversion causes TOOL_ERR.TOOL_ERROR to be raised, preventing the return of a corrupt handle.
- BR-006 - If the WebUtil bean is not registered in the Forms runtime (BEAN_NOT_REGISTERED), the function surfaces a descriptive error alert and raises TOOL_ERR.TOOL_ERROR, ensuring the caller is notified rather than receiving a silent NULL result.
- BR-007 - PROPERTY_ERROR exceptions propagated by the WebUtil bean layer are re-raised unchanged, preserving the original error context for upstream handlers.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-024 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key by looking up the value in the internal callbacks collection (m_callbacks). This function supports WEBUTIL.SETDATA in resolving which trigger to invoke for a specific callback operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the numeric callback key (callbackKey) supplied by the calling routine.
- Step 2 - Use callbackKey as an index to look up the corresponding trigger name in the m_callbacks internal collection.
- Step 3 - Return the VARCHAR2 trigger name retrieved from m_callbacks to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic is a direct index-based lookup with no branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; supplying an invalid or unregistered key will result in a runtime error as no bounds-checking or default handling is implemented within this function.
- BR-002 - The function returns exactly one VARCHAR2 value per invocation, representing the trigger name mapped to the provided key; no null substitution or default value is applied.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-025 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally stored client OS family variable (m_clientOSFamily) to callers, enabling the application to determine the client platform category for conditional processing or display logic.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires the client OS family value.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client operating system family identifier.
- Step 3 - The function returns the value of m_clientOSFamily as a PLS_INTEGER to the caller.

---
**Decision Points**

No decision points are present. The function unconditionally returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns the client OS family solely from the module-level variable m_clientOSFamily; no input parameters are accepted and no derivation or calculation is performed at call time.
- BR-002 - The return type is PLS_INTEGER, meaning the OS family is represented as a numeric identifier; the caller (WEBUTIL.GETVAR) is responsible for interpreting the numeric value in a business context.
- BR-003 - The function has no dependencies on database objects or external routines; the integrity of the returned value depends entirely on m_clientOSFamily having been correctly populated prior to invocation.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-026 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set and then read back the requested local property, returning its current value to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings required for WebUtil initialisation and bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input property name (propertyName) from the calling routine.
- Step 2 - Evaluate whether propertyName is not null; if null, skip property retrieval and return a null result.
- Step 3 - Call WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName, instructing the WebUtil Core bean to prepare the requested local property value.
- Step 4 - Call WebUtil_Core.getProperty targeting the same WUC_PACKAGE component and key WUC_GET_LOCAL_PROPERTY to read back the resolved property value into the local result variable.
- Step 5 - Return the retrieved property value (VARCHAR2, up to 255 characters) to the caller.
- Step 6 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during steps 3-4, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a WebUtil_Core.PROPERTY_ERROR exception is raised during steps 3-4, raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to invoke WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client-side setting value.

FALSE: Skip all property retrieval logic and return a null result to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property retrieval

TRUE: Display an error alert identifying the unregistered WebUtil Core implementation class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No exception of this type; continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during property retrieval

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: No exception of this type; return the successfully retrieved property value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any interaction with the WebUtil Core bean; the function must return null immediately without attempting property retrieval.
- BR-002 - The property value returned must not exceed 255 characters, as enforced by the result variable declaration (VARCHAR2(255 char)).
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, the function must display a descriptive error alert that includes the bean implementation class name and must raise FORM_TRIGGER_FAILURE to prevent further form processing.
- BR-004 - If a property error occurs during retrieval, the function must raise FORM_TRIGGER_FAILURE to halt form processing; no partial or default value may be returned in this scenario.
- BR-005 - Property retrieval is performed as a two-step operation: the property name must first be set on the WUC_PACKAGE component via WebUtil_Core.setProperty before the value is read back via WebUtil_Core.getProperty; both calls must use the WUC_GET_LOCAL_PROPERTY key.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-027 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class entry for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Look up the implementation class string associated with packageID in the m_implClasses indexed collection.
- Step 3 - Prepend the WEBUTIL_JAVA_ROOT constant to the retrieved implementation class string to form the fully qualified Java class name.
- Step 4 - Return the concatenated fully qualified class name to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic executes as a single unconditional return statement; there are no branching conditions to document.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The packageID supplied must correspond to a valid, pre-populated entry in the m_implClasses collection; no bounds or existence check is performed, so an invalid packageID will raise a runtime error.
- BR-002 - The fully qualified Java class name is always constructed by prepending WEBUTIL_JAVA_ROOT to the stored implementation class string; neither component may be substituted or overridden at call time.
- BR-003 - This function has no database interactions and no external dependencies; it operates entirely on in-memory package-level structures.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-028 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object on the application server. The function delegates the call via the JNI bridge to the native Java method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class, returning an integer error code that the calling routine (WEBUTIL.SETDATA) can inspect to determine whether a preceding file-transfer operation completed successfully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) passed in by the caller (WEBUTIL.SETDATA).
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale parameters are forwarded to the Java method.
- Step 3 - Invoke the Java instance method getLastError() on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing the object reference and the method signature '()I' (no arguments, integer return).
- Step 4 - Return the integer error code received from the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method call and returns its result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to guarantee that no residual argument values from a prior invocation are passed to the AppServerFileReader.getLastError() Java method.
- BR-002 - The function must be invoked with a valid AppServerFileReader Java object reference (obj); the object context is established by the calling routine WEBUTIL.SETDATA and is not validated within this function.
- BR-003 - The return value is an integer error code sourced exclusively from the AppServerFileReader Java class on the application server; no database lookup or PL/SQL-level error mapping is performed within this function.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-029 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates to the JNI layer to invoke the native Java method and returns the error argument details as a VARCHAR2 string, enabling the calling routine (WEBUTIL.SETDATA) to obtain diagnostic context for the last file-transfer error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the shared args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java instance method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the object reference, the fully-qualified class path, the method name, and the method signature '()Ljava/lang/String;' with the cleared args value.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the caller, representing the error argument details from the last file-transfer error.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence: clear args, invoke the JNI method, and return the result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to prevent stale argument data from a previous invocation from being passed to the Java method.
- BR-002 - The target Java method must be resolved against the fully-qualified class oracle/forms/webutil/fileTransfer/AppServerFileReader using the exact method signature '()Ljava/lang/String;'; any deviation would cause the JNI call to fail to locate the method.
- BR-003 - The function returns the raw string value provided by the Java runtime; no transformation or validation is applied to the returned error argument data before it is passed back to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-030 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified positional index and returns its value as a NUMBER. The procedure delegates string extraction to WEBUTIL.GETSTRING and applies a TO_NUMBER conversion, providing callers with a type-safe numeric result without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-034](#SP-034--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional Boolean flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-034), which locates and extracts the raw VARCHAR2 value at the specified positional field within the delimited source string.
- Step 3 - Apply Oracle's TO_NUMBER function to the VARCHAR2 value returned by WEBUTIL.GETSTRING to convert it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

- DP-001

  Condition: The UnTerminated parameter is passed as TRUE or FALSE (defaulting to FALSE).

  TRUE: WEBUTIL.GETSTRING treats the final field in the source string as unterminated (i.e., not followed by a closing delimiter) when extracting the target field.

  FALSE: WEBUTIL.GETSTRING treats all fields, including the final one, as delimiter-terminated during extraction.

- DP-002

  Condition: A custom Delimiter character is supplied by the caller (default is comma ',').

  TRUE: WEBUTIL.GETSTRING uses the caller-supplied delimiter character to parse and locate the field at the specified position.

  FALSE: WEBUTIL.GETSTRING uses the default comma delimiter to parse the source string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The field extraction logic is fully delegated to WEBUTIL.GETSTRING (SP-034); WEBUTIL.GETNUMBER performs no independent parsing of the source string.
- BR-002 - The value extracted from the source string at the specified field position must be implicitly convertible to a NUMBER via TO_NUMBER; non-numeric content will cause a runtime conversion error.
- BR-003 - The Delimiter parameter defaults to a comma (',') if not explicitly provided by the caller, establishing comma-separated format as the standard input convention.
- BR-004 - The UnTerminated parameter defaults to FALSE if not explicitly provided, meaning the source string is assumed to have a closing delimiter after the final field unless the caller overrides this behaviour.
- BR-005 - Field positions are determined by WEBUTIL.GETSTRING based on the supplied Field_position and Delimiter values; the caller is responsible for providing a valid, in-range positional index.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-031 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string. The function maps the raw OS name to a predefined platform constant (Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluating the string. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform classification.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all classification logic and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily is null, evaluate l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If the Windows check did not match, evaluate l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If no match yet, evaluate l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If no match yet, evaluate l_osName for either the substring 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If no match yet, evaluate l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If no match yet, evaluate l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to m_clientOSFamily, caching it for the remainder of the session.
- Step 11 - Return m_clientOSFamily as the function output.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (i.e., the OS family has not yet been determined and cached for this session).

TRUE: Proceed through the OS name classification logic (Steps 4-9) to determine the platform constant, then cache and return the result.

FALSE: Skip all classification logic and return the previously cached value of m_clientOSFamily immediately.

---

DP-002

Condition: The lowercase OS name contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next OS family check (DP-003).

---

DP-003

Condition: The lowercase OS name contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next OS family check (DP-004).

---

DP-004

Condition: The lowercase OS name contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next OS family check (DP-005).

---

DP-005

Condition: The lowercase OS name contains the substring 'solaris' OR the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next OS family check (DP-006).

---

DP-006

Condition: The lowercase OS name contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next OS family check (DP-007).

---

DP-007

Condition: The lowercase OS name contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: No recognised OS family matched; result remains CLIENT_PLATFORM_UNKNOWN.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison must be performed case-insensitively; the input string is converted to lowercase before any substring matching is applied.
- BR-002 - Platform classification is mutually exclusive and evaluated in priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition determines the platform; subsequent checks are not evaluated.
- BR-003 - If the OS name does not match any recognised platform substring, the function must return CLIENT_PLATFORM_UNKNOWN as the default classification.
- BR-004 - The resolved OS family must be cached in the module-level variable m_clientOSFamily upon first determination; once cached, the classification logic must not be re-executed within the same session, ensuring consistent and performant platform identification across repeated calls.
- BR-005 - The function accepts the OS name solely as an input parameter and produces no formal output parameters; the platform classification is communicated exclusively through the function return value.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-032 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a given client-side process by repeatedly polling the WebUtil host bean via WebUtil_Core property calls. The function accumulates each output line into an array and returns the complete OUTPUT_ARRAY to the caller (WEBUTIL.GET_STANDARD_OUTPUT). Package initialisation ensures WebUtil_Core is instantiated before any retrieval occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-039](#SP-039--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise local variables: an empty OUTPUT_ARRAY (lines), a line counter (i = 1), a 257-character buffer, and a status flag defaulting to 'X' (empty).
- Step 2 - Set the process context on the WebUtil host bean by writing the process handle to the WUH_PROC_ID property of WUH_PACKAGE via WebUtil_Core.setProperty.
- Step 3 - Enter a loop: call WebUtil_Core.getProperty for WUH_PACKAGE using the supplied prop parameter and store the result in buffer.
- Step 4 - Extract the first character of buffer as the status indicator ('Y' = more lines follow, 'N' = last line, 'X' = buffer empty).
- Step 5 - If status is not 'X', store the remainder of buffer (characters 2 onward) as the next element in the lines array and increment the counter.
- Step 6 - Exit the loop when status is not 'Y' (i.e., the last line 'N' has been processed or the buffer was empty 'X').
- Step 7 - Return the populated OUTPUT_ARRAY to the caller.
- Step 8 - On exception BEAN_NOT_REGISTERED, raise an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function.

---
**Decision Points**

DP-001

Condition: status <> 'X' (the buffer returned by WebUtil_Core.getProperty is not empty)

TRUE: Extract the payload (substr(buffer, 2)) and store it as the next element in the output array; increment the line counter.

FALSE: Discard the buffer contents; do not add an entry to the output array.

---

DP-002

Condition: status <> 'Y' (no further lines are pending from the bean)

TRUE: Exit the retrieval loop and proceed to return the accumulated output array.

FALSE: Continue looping; poll WebUtil_Core.getProperty again for the next output line.

---

DP-003

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property access

TRUE: Display an error alert identifying the unregistered bean class and halt processing; no output array is returned.

FALSE: Normal execution continues; no exception handling is triggered.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil host bean before output retrieval begins; the function sets WUH_PROC_ID to the supplied process handle as the first action in every invocation.
- BR-002 - Output lines are identified solely by the single-character status prefix returned by the bean: 'Y' signals a line with more to follow, 'N' signals the final line, and 'X' signals an empty buffer; only 'Y' and 'N' statuses result in a line being added to the output array.
- BR-003 - The buffer length is capped at 257 characters; the first character is reserved for the status flag, leaving a maximum of 256 characters of usable payload per line.
- BR-004 - WebUtil_Core must be initialised (via Webutil_Core.Init in the package initialisation block) before any call to GetOutput; this ensures the core bean infrastructure is available at package load time.
- BR-005 - If the required WebUtil host bean is not registered on the client, the function must not return partial data; instead it raises an error alert and terminates, preventing silent data loss.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-033 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Given a property key string, the function calls the standard Java method java.lang.System.getProperty and returns the corresponding property value to the caller. This allows Oracle Forms WebUtil routines (such as FOPEN and REGISTERBEAN) to interrogate the underlying Java runtime environment for configuration or platform details.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property key string (a0) supplied by the calling routine (WEBUTIL.FOPEN or WEBUTIL.REGISTERBEAN).
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1) and storing the handle in the local variable args.
- Step 3 - Add the property key string a0 to the argument list as a STRING argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the static Java method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the class path 'java/lang/System', the method name 'getProperty', the JNI method signature '(Ljava/lang/String;)Ljava/lang/String;', and the prepared argument list.
- Step 5 - Return the VARCHAR2 value received from the JNI call directly to the caller as the function result.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function follows a single, unconditional execution path: build the argument list, invoke the JNI method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly one input argument (the property key) must be supplied; the JNI argument list is always created with a fixed capacity of 1.
- BR-002 - The property lookup is delegated entirely to the Java runtime via JNI; no Oracle database query or Forms-layer caching is performed.
- BR-003 - The function targets the static Java method java.lang.System.getProperty with the strict JNI signature '(Ljava/lang/String;)Ljava/lang/String;'; any deviation in the key type or return type would cause a JNI resolution failure.
- BR-004 - If the requested property does not exist in the Java runtime, the JNI call returns NULL, and the function propagates that NULL value to the caller without raising an exception.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-034 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited field from a source string by position. Given a delimiter-separated string, a target field position, a delimiter character, and an optional flag indicating whether the string lacks a terminal delimiter, the function returns the substring occupying that positional slot. It is used internally by WEBUTIL.GETNUMBER to isolate individual tokens from composite string values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-043](#SP-043--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the 1-based field position to extract, an optional boolean flag (UnTerminated) indicating whether the source string is missing a trailing delimiter, and an optional delimiter character (defaulting to comma).
- Step 2 - Create a working copy of the source string.
- Step 3 - If UnTerminated is TRUE, append the delimiter character to the end of the working copy so that the last field is bounded and can be located using standard delimiter-search logic.
- Step 4 - Determine the start position of the target field: if Field_Position is greater than 1, locate the (Field_Position - 1)th occurrence of the delimiter within the working copy using INSTR and advance the pointer past the delimiter by adding the length of the delimiter string; otherwise set the start pointer to 1 (beginning of the string).
- Step 5 - Determine the end position of the target field by locating the Field_Positionth occurrence of the delimiter within the working copy using INSTR.
- Step 6 - Extract and return the substring from the start pointer for a length equal to (end pointer - start pointer), yielding the field value without its surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any positional search is performed, ensuring the final field is bounded and extractable.

FALSE: The source string is used as-is; no modification is made before positional searching begins.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_Position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the requested field.

FALSE: The start pointer is set to 1, meaning extraction begins at the very start of the working string (i.e., the first field is being requested).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_Position value of 1 always refers to the content before the first delimiter occurrence in the source string.
- BR-002 - If the source string does not end with the delimiter (i.e., the last field is unterminated), the caller must pass UnTerminated = TRUE so that the function appends the delimiter internally and correctly bounds the final field for extraction.
- BR-003 - The delimiter defaults to a comma if not explicitly supplied; any single or multi-character delimiter string is supported.
- BR-004 - The function returns only the field content, excluding the surrounding delimiter characters; the extracted length is computed as (position of closing delimiter - position of opening delimiter start), which naturally omits both delimiters.
- BR-005 - The working copy of the source string is limited to 32,000 characters (VARCHAR2(32000)); source strings exceeding this length are not supported.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-035 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named configuration variable from the client environment by applying a platform-specific resolution strategy. On Windows clients, the procedure first queries the Oracle registry key and falls back to the Windows environment string if the registry lookup returns no value. On Unix clients, it executes the 'env' command, parses its output, and extracts the matching variable. On Mac and unknown platforms, no resolution is attempted and the output value remains unchanged. The procedure is invoked during WebUtil bean registration to supply runtime environment context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-063](#SP-063--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-064](#SP-064--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-013](#SP-013--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-025](#SP-025--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-037](#SP-037--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-051](#SP-051--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 2 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the requested variable from the Windows registry under the 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' key using READ_REGISTRY, passing VARNAME and returning the result into VARVALUE.
- Step 3 - If the registry lookup returns NULL or an empty string, fall back to reading the variable from the Windows environment using GET_ENVIRONMENT_STRING, passing VARNAME and storing the result in VARVALUE.
- Step 4 - If the client is Mac (CLIENT_PLATFORM_MAC) or an unknown platform, take no action; VARVALUE retains whatever value was passed in.
- Step 5 - If the client is any other platform (Unix), execute the shell command 'env' as a blocking host process via WEBUTIL.BLOCKING, capturing the process handle.
- Step 6 - Retrieve the full standard output of the 'env' command as an array of strings using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 7 - Release the host process handle using WEBUTIL.RELEASE_PROCESS.
- Step 8 - Iterate through each line of the 'env' output; for each line, locate the '=' delimiter using INSTR. If a delimiter is found, extract the key portion (left of '=') and compare it to VARNAME. On a match, extract the value portion (right of '=') into VARVALUE and exit the loop.
- Step 9 - If a NO_DATA_FOUND exception is raised at any point during execution, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: Client OS family equals CLIENT_PLATFORM_WIN32.

TRUE: Attempt registry lookup under 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' for VARNAME; proceed to DP-002.

FALSE: Proceed to DP-003 to evaluate Mac/unknown platform.

---

DP-002

Condition: Registry lookup result (VARVALUE) is NULL or empty string.

TRUE: Fall back to GET_ENVIRONMENT_STRING to retrieve VARNAME from the Windows environment and assign the result to VARVALUE.

FALSE: Use the registry value already stored in VARVALUE; no further lookup is performed.

---

DP-003

Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE: Take no action; VARVALUE is left unchanged.

FALSE: Treat the client as a Unix platform and proceed to execute the 'env' command.

---

DP-004

Condition: A '=' delimiter is found (INSTR result > 0) in the current line of the 'env' output array.

TRUE: Extract the key and value segments; proceed to DP-005.

FALSE: Skip the current line and continue iterating.

---

DP-005

Condition: The extracted key from the current 'env' output line equals VARNAME.

TRUE: Assign the value segment to VARVALUE and exit the loop immediately.

FALSE: Continue iterating through remaining 'env' output lines.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is the primary source for variable resolution; the Windows environment is only consulted as a secondary fallback when the registry returns no value.
- BR-002 - On Mac and unknown client platforms, variable resolution is explicitly suppressed; the procedure returns without modifying VARVALUE.
- BR-003 - On Unix clients, variable resolution is performed exclusively by parsing the output of the 'env' command; direct environment API calls are not used.
- BR-004 - For Unix resolution, only the first matching variable name found in the 'env' output is used; iteration stops immediately upon the first match.
- BR-005 - Lines in the Unix 'env' output that do not contain an '=' character are ignored and do not contribute to variable resolution.
- BR-006 - A NO_DATA_FOUND exception at any stage of execution results in VARVALUE being set to NULL, ensuring the caller always receives a defined (though empty) output rather than an unhandled error.
- BR-007 - The host process spawned for Unix 'env' execution must be explicitly released via WEBUTIL.RELEASE_PROCESS before the parsed output is used, ensuring no process handle leak occurs.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-036 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual file-read operation to the WebUtil Java bean layer via WebUtil_Core property calls, and raises a standard NO_DATA_FOUND exception when the end of the file is reached, allowing the calling routine (VIEW_EXCEL_REP) to detect end-of-file in a controlled manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle encapsulated in the FILE_TYPE input parameter.
- Step 2 - Pass the file handle to the WebUtil Java bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the next line of text from the open file by reading the WUF_TEXTIO_GETLINE property from the WUF_PACKAGE component via WebUtil_Core.getProperty; the result is stored in a local VARCHAR2(4000) buffer.
- Step 4 - Evaluate the buffer content: if the buffer equals CHR(10) (a lone newline), interpret this as the end-of-file sentinel placed by the PJC exception handler and raise NO_DATA_FOUND; otherwise, assign the buffer value to the OUT parameter ITEM.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If a property read/write error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The value returned in the buffer from WebUtil_Core.getProperty equals CHR(10) (a lone newline character).

TRUE:
The end-of-file sentinel has been detected; NO_DATA_FOUND is raised so the caller can terminate its read loop cleanly.

FALSE:
The buffer contains a valid line of text; the buffer value is assigned to the OUT parameter ITEM and control returns to the caller.

---

DP-002

Condition:
The BEAN_NOT_REGISTERED exception is raised during the property set or get calls.

TRUE:
An error alert is displayed identifying the unregistered bean class, and TOOL_ERR.TOOL_ERROR is raised to abort the operation.

FALSE:
Processing continues normally to the buffer evaluation step.

---

DP-003

Condition:
The PROPERTY_ERROR exception is raised during the property set or get calls.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to abort the operation without displaying an additional alert.

FALSE:
Processing continues normally to the buffer evaluation step.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle supplied in the FILE_TYPE parameter must already be open; this procedure does not open or validate the file itself.
- BR-002 - A lone CHR(10) newline in the read buffer is reserved exclusively as the end-of-file sentinel injected by the PJC exception handler; it is never treated as a valid line of data.
- BR-003 - The maximum length of a single line that can be read and returned is 4 000 characters, as defined by the internal buffer declaration.
- BR-004 - If the WebUtil Java bean is not registered on the client, the procedure must surface a descriptive error alert and terminate with TOOL_ERR.TOOL_ERROR rather than silently returning an empty or null value.
- BR-005 - Any property-level error during the file-read interaction must cause immediate termination via TOOL_ERR.TOOL_ERROR, preventing partial or corrupt data from being returned to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-037 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream collected from a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT (SP-032), passing the fixed stream identifier 'WUH_STDOUT' so that callers do not need to know the internal stream-name constant.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-032](#SP-032--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (PROCESS_ID) that references a previously executed host process whose output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-032) with the supplied process identifier and the hard-coded stream label 'WUH_STDOUT' to fetch the standard output lines captured for that process.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller without further transformation.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: delegate to WEBUTIL.GETOUTPUT with the fixed stream identifier and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; callers cannot override the stream name through this function, ensuring that only the standard output channel is returned.
- BR-002 - The function returns an OUTPUT_ARRAY type; the caller is responsible for handling an empty or null array if no standard output was produced by the referenced process.
- BR-003 - A valid PROCESS_ID must be supplied; the function performs no independent validation of the process identifier and relies on WEBUTIL.GETOUTPUT (SP-032) to handle any process-not-found or invalid-ID conditions.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-038 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a utility check that determines whether a given handle object is uninitialised (null). Callers across the WebUtil library and the bodyshop report form use this function to guard against operating on an invalid or unallocated pointer before invoking further WebUtil operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming `handle` parameter of type Pointer.
- Step 2 - Inspect the `hnd` attribute of the supplied Pointer to determine whether it holds a null value.
- Step 3 - Return TRUE if `handle.hnd` is null, indicating the handle has not been initialised.
- Step 4 - Return FALSE if `handle.hnd` is not null, indicating the handle references a valid, allocated object.

---
**Decision Points**

DP-001

Condition:
`handle.hnd IS NULL`

TRUE:
The function returns TRUE, signalling to the caller that the handle is uninitialised and should not be used for further operations.

FALSE:
The function returns FALSE, signalling to the caller that the handle is valid and operations against it may proceed safely.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal `hnd` attribute; no additional state or context is evaluated.
- BR-002 - The function must always return a Boolean result (TRUE or FALSE); no exception path or default null return is permitted, ensuring callers always receive a definitive validity signal.
- BR-003 - This function carries no side effects and performs no database interactions; it is a pure predicate intended for use as a pre-condition guard by any routine that manages WebUtil handles.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-039 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT is a package initialisation procedure that serves as the formal entry point for the WEBUTIL_CORE package. Its sole responsibility is to trigger package-level initialisation by delegating immediately to WEBUTIL.INITWEBUTIL via the package body's BEGIN block. The procedure itself performs no discrete processing; entering the package is sufficient to invoke the initialisation sequence.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-040](#SP-040--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.INIT is called by WEBUTIL.GETOUTPUT as part of the WebUtil utility setup sequence.
- Step 2 - The procedure body executes a NULL statement, confirming that no explicit procedural logic is required; the act of entering the package is sufficient for setup.
- Step 3 - Control passes to the WEBUTIL_CORE package body's BEGIN block, which calls WEBUTIL.INITWEBUTIL (SP-040) to perform the actual WebUtil initialisation.

---
**Decision Points**

No decision points are present. The procedure contains only a NULL statement and unconditionally delegates initialisation to WEBUTIL.INITWEBUTIL via the package-level BEGIN block.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Entering the WEBUTIL_CORE package is sufficient to trigger initialisation; no explicit procedural steps are required within WEBUTIL.INIT itself.
- BR-002 - Package-level initialisation must always invoke WEBUTIL.INITWEBUTIL (SP-040); this call is mandatory and is placed in the package body's BEGIN block to ensure it executes on first package reference.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-040 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the required WebUtil object group (including its error alert and dummy item) is present in the form, optionally navigating to and rendering the bean areas, and determining the server-side file-path separator based on the host operating system. This procedure must complete successfully before any WebUtil functionality can be used in the form session.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-038](#SP-038--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-055](#SP-055--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to be used as reference points throughout initialisation.
- Step 2 - Populate the package-to-implementation-class mapping array (m_implClasses) with the Java bean class names for each known WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
- Step 3 - Call WEBUTIL.ID_NULL against the module-level error-alert handle (m_errorAlert) to determine whether the WebUtil object group has been included in the form.
- Step 4 - If the error alert handle is null (object group absent), display a message informing the developer that the WEBUTIL object group is not available and the framework cannot operate, then pause execution. No further initialisation is performed.
- Step 5 - If the error alert handle is valid, check whether the FLAG_EXPICIT_INSTANCIATE flag is enabled and the current form mode (SYSTEM.MODE) is 'NORMAL' before attempting bean-area navigation.
- Step 6 - When both conditions in Step 5 are met, call WEBUTIL.ID_NULL against the dummy item handle (hDummy) to confirm the standard WebUtil object group layout is in use.
- Step 7 - If the dummy item exists, navigate to it using GO_ITEM, then determine whether the starting cursor field and the dummy item reside in the same block; if they do, move to the next block (NEXT_BLOCK), otherwise return focus to the original starting item (GO_ITEM(startPoint)).
- Step 8 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without forcing focus, completing the visual initialisation of the bean components.
- Step 9 - If the dummy item does not exist (Step 6 check fails), take no navigation action, assuming the developer is managing bean-area setup independently.
- Step 10 - Inspect the server operating system via GET_APPLICATION_PROPERTY(OPERATING_SYSTEM); if the value contains 'WIN' (case-insensitive), set the module-level server file separator (m_serverFileSep) to backslash ('\'), otherwise set it to forward slash ('/').

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns TRUE (the WebUtil error alert object is not found in the form).

TRUE: Display an error message stating the WEBUTIL object group is unavailable and WebUtil cannot operate, then pause. Initialisation is aborted; no further steps execute.

FALSE: The WebUtil object group is present; proceed with conditional bean-area navigation and server OS detection.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to check for the dummy item and attempt bean-area navigation (Steps 6-9).

FALSE: Skip bean-area navigation entirely; proceed directly to server OS detection (Step 10).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) returns FALSE (the WebUtil dummy item exists in the form).

TRUE: Navigate to the dummy item, resolve block positioning, and call WEBUTIL.SHOWBEANS(false) to render bean areas.

FALSE: Take no navigation action; the developer is assumed to be managing bean-area instantiation independently.

---

DP-004

Condition: The block containing the original cursor field (startPoint) is the same block as the one containing the dummy item (hDummy), evaluated via GET_ITEM_PROPERTY ... BLOCK_NAME comparison.

TRUE: Move focus to the next block using NEXT_BLOCK to exit the dummy item's block.

FALSE: Return focus to the original starting item using GO_ITEM(startPoint).

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server operating system name contains 'WIN').

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert component, must be present in the form before WebUtil initialisation can proceed; absence of the error alert is treated as a fatal configuration error and all further initialisation is halted.
- BR-002 - Bean-area navigation is only attempted when the explicit-instantiation flag (FLAG_EXPICIT_INSTANCIATE) is enabled and the form is in NORMAL mode; Enter-Query mode must not trigger bean navigation to avoid known form navigation conflicts.
- BR-003 - If the standard WebUtil dummy item is not found in the form during bean-area setup, the procedure takes no navigation action, deferring full responsibility for bean-area management to the developer.
- BR-004 - After navigating to the dummy item, the procedure must restore focus to a valid item outside the dummy item's block; if the original cursor field was in the same block as the dummy item, focus advances to the next block, otherwise focus returns to the original cursor field.
- BR-005 - WEBUTIL.SHOWBEANS must be called with the parameter false during initialisation, indicating that bean rendering should occur without forcing user focus to the bean areas.
- BR-006 - The server file-path separator stored in m_serverFileSep must reflect the actual server operating system: backslash for Windows environments and forward slash for all other environments; this value governs all subsequent server-side file-path construction within the WebUtil framework.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-041 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator that signals whether the most recent WebUtil operation resulted in an error. It exposes the internal error-state variable `m_lastError` to callers (such as WEBUTIL.LOG) so they can branch their processing based on whether a prior operation succeeded or failed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the internal package-level variable `m_lastError` against zero.
- Step 2 - Return TRUE if `m_lastError` is not equal to zero, indicating that an error condition is currently recorded.
- Step 3 - Return FALSE if `m_lastError` equals zero, indicating no error is currently recorded.

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, signalling that the last WebUtil operation raised an error.

FALSE: The function returns FALSE, signalling that no error is recorded from the last WebUtil operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The sole criterion for determining an error state is whether `m_lastError` holds a non-zero value; a value of zero is unconditionally treated as a success state.
- BR-002 - The function is read-only; it inspects `m_lastError` but does not modify it, ensuring that checking the error state does not alter or clear the recorded error.
- BR-003 - The function accepts no input parameters; the error state is derived entirely from the package-level variable `m_lastError`, making the result context-dependent on the prior execution state of the WebUtil package.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-042 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to verify file state before attempting file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as the input parameter.
- Step 2 - Evaluate the handle attribute of the FILE_TYPE record to determine whether it holds a non-NULL value.
- Step 3 - If the handle is NULL, return FALSE to indicate that the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate that the file is currently open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The file handle has not been assigned; the function returns FALSE, signalling that the file is not open.

FALSE: The file handle contains a value; the function returns TRUE, signalling that the file is open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its handle attribute is non-NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs a read-only inspection of the FILE_TYPE record and does not modify any file state or system resource.
- BR-003 - No database interaction or external dependency is required to determine file open status; the determination is made solely from the in-memory FILE_TYPE record.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-043 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of the file represented by the supplied Java File object. It delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL callers (such as DEBUGLOG, REGISTER_FUNCTION_CALL, STRIPDIRSEP, and WEBUTIL.GETSTRING) with a numeric file-size value without requiring direct Java or OS-level coding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) passed in by the calling routine.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no residual arguments from a prior call are carried over.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the target object, the class path 'java/io/File', the method name 'length', the method signature '()J' (no parameters, returns a long), and the now-null argument list.
- Step 4 - Return the numeric result (file size in bytes) to the caller.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: clear arguments, call the JNI method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates exclusively on a valid ORA_JAVA.JOBJECT representing a java.io.File instance; the caller is responsible for supplying a properly initialised File object.
- BR-002 - The argument list must be explicitly reset to NULL before the JNI call to prevent argument pollution from any previously executed JNI operation.
- BR-003 - The file length is retrieved via the Java native method java.io.File.length() (JNI signature '()J'), and the returned long value is surfaced as an Oracle NUMBER to PL/SQL callers.
- BR-004 - This function performs no database interactions and maintains no state; it is a pure pass-through to the JNI layer.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-044 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to the server-side WebUtil log file. On first invocation it initialises a module-level logging configuration cache by reading three property-bundle keys (logging enabled flag, errors-only flag, and log file path), propagates the resolved logging mode to the registered WebUtil bean via a WUC_SRV_LOGGING property, and then conditionally appends the supplied message-prefixed with the client IP and username when available-to the configured log file. The procedure is called by WEBUTIL.CHECKLIBS, WEBUTIL.REGISTERBEAN, and WEBUTIL_CORE.CUSTOMEVENTHANDLER to provide a unified, configurable logging channel across the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-020](#SP-020--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-041](#SP-041--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-042](#SP-042--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level logging configuration cache (m_loggingAllowed) has already been initialised; if it is NULL, proceed with initialisation (Steps 2-8), otherwise skip directly to Step 9.
- Step 2 - Call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve 'logging.enabled'; set m_loggingAllowed to TRUE if the returned value (lowercased) equals 'true'.
- Step 3 - Call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve 'logging.errorsonly'; set m_loggingErrorsOnly to TRUE if the returned value (lowercased) equals 'true'.
- Step 4 - Call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve 'logging.file'; store the result in m_loggingFile.
- Step 5 - If logging is allowed but m_loggingFile is NULL, set m_loggingAllowed to FALSE (no file means no logging). If no bean is registered yet, call WEBUTIL.ERRORALERT to display English-language error 'WUC-008: Server side logging was requested but no log file was specified - logging is disabled'; otherwise notify the bean by setting WUC_SRV_LOGGING to '0' and raising error 8 via WebUtil_Core.
- Step 6 - If at least one bean is registered, propagate the resolved logging mode to the bean: set WUC_SRV_LOGGING to '1' when logging is allowed and errors-only mode is active, '2' when logging is allowed for all messages, or '0' when logging is disabled.
- Step 7 - End of cache initialisation block.
- Step 8 - Evaluate whether a log entry should be written: proceed only if m_loggingAllowed is TRUE and either errors-only mode is inactive or the isError flag passed by the caller is TRUE.
- Step 9 - Open the log file identified by m_loggingFile in append mode using TEXT_IO.FOPEN.
- Step 10 - Verify the file was opened successfully via TEXT_IO.IS_OPEN; if not, raise NO_DATA_FOUND.
- Step 11 - Write the log entry using TEXT_IO.PUT_LINE: if m_clientIP is NULL, write the raw message; otherwise prefix the message with m_clientIP, a colon, m_clientUserName, and a colon-space separator.
- Step 12 - Close the log file using TEXT_IO.FCLOSE.
- Step 13 - On exception: if SQLCODE is -302000 (file write failure), call WEBUTIL.ERRORALERT with 'WUC-007: Unable to write to WebUtil Logging File <filename>' when no bean is registered, or set WUC_SRV_LOGGING to '0' and raise error 7 via WebUtil_Core when a bean is available; in both cases set m_loggingAllowed to FALSE to suppress further attempts. Any other exception is re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging configuration cache not yet initialised).
TRUE: Execute the full initialisation sequence (read property bundle keys, validate log file path, set m_loggingAllowed / m_loggingErrorsOnly / m_loggingFile, propagate logging mode to the bean).
FALSE: Skip initialisation and proceed directly to the write-eligibility check.

DP-002
Condition: m_loggingAllowed is TRUE and m_loggingFile IS NULL.
TRUE: Set m_loggingAllowed to FALSE. If no bean is registered, call WEBUTIL.ERRORALERT with WUC-008 message; otherwise set WUC_SRV_LOGGING to '0' and raise error 8 via WebUtil_Core.
FALSE: Retain the current value of m_loggingAllowed and continue.

DP-003
Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) after the log-file validation step.
TRUE: Propagate the resolved logging mode to the bean (WUC_SRV_LOGGING = '1', '2', or '0' depending on m_loggingAllowed and m_loggingErrorsOnly).
FALSE: Skip bean property propagation.

DP-004
Condition: m_loggingAllowed is TRUE AND (m_loggingErrorsOnly is FALSE OR isError is TRUE).
TRUE: Proceed to open the log file and write the message.
FALSE: Do not write any log entry; exit the procedure silently.

DP-005
Condition: TEXT_IO.IS_OPEN returns FALSE after the FOPEN call.
TRUE: Raise NO_DATA_FOUND, which is handled by the EXCEPTION block.
FALSE: Continue to write the log entry.

DP-006
Condition: m_clientIP IS NULL at the time of writing the log entry.
TRUE: Write the raw message text only.
FALSE: Prefix the message with m_clientIP, a colon, m_clientUserName, and a colon-space separator before writing.

DP-007
Condition: An exception occurs and SQLCODE equals -302000 (file write failure).
TRUE: If no bean is registered, call WEBUTIL.ERRORALERT with WUC-007 message; otherwise set WUC_SRV_LOGGING to '0' and raise error 7 via WebUtil_Core. Set m_loggingAllowed to FALSE.
FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, log file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in module-level variables; subsequent calls reuse the cached values without re-reading the bundle.
- BR-002 - If logging is enabled but no log file path is configured, logging is unconditionally disabled (m_loggingAllowed set to FALSE) and error WUC-008 is reported; a missing file path is treated as a configuration error, not a silent no-op.
- BR-003 - When errors-only mode is active (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently discarded.
- BR-004 - The log file is opened in append mode for each individual log call and closed immediately after writing, ensuring that partial writes do not corrupt the file and that the file handle is not held open between calls.
- BR-005 - Every log entry is prefixed with the client IP address and username (m_clientIP and m_clientUserName) when m_clientIP is not NULL, providing an audit trail of which client session generated each message.
- BR-006 - Error reporting on configuration or write failures is context-sensitive: if no WebUtil bean has been registered yet, WEBUTIL.ERRORALERT is used to display an English-language alert directly; once a bean is registered, errors are communicated through the bean's property mechanism via WebUtil_Core.
- BR-007 - A file write failure identified by SQLCODE -302000 permanently disables logging for the session (m_loggingAllowed set to FALSE) and reports error WUC-007; this prevents repeated failed write attempts on a broken log file.
- BR-008 - Any exception other than SQLCODE -302000 is re-raised to the caller, ensuring that unexpected errors are not silently swallowed by the logging subsystem.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-045 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter. It is invoked by WEBUTIL.READFROMPROPERTYBUNDLE to supply configuration values at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-020](#SP-020--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the WebUtil configuration file path from the Forms global variable (WEBUTIL_CONFIG_GLOBAL); if the global is not set ('[NOTSET]'), proceed to Step 2.
- Step 2 - Attempt to retrieve the configuration file path from the operating-system environment variable (WEBUTIL_CONFIG_ENV) via TOOL_ENV.GETVAR; if still null, proceed to Step 3.
- Step 3 - Attempt to retrieve the configuration file path from the Forms parameter (WEBUTIL_CONFIG_PARAM); if still null, raise NO_DATA_FOUND to trigger the error handler.
- Step 4 - Persist the resolved configuration file path back into WEBUTIL_CONFIG_GLOBAL so that subsequent calls do not need to re-resolve it.
- Step 5 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 6 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 7 - For each line, skip it if the first character is '#' (comment line).
- Step 8 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' (not a valid key-value pair).
- Step 9 - For valid key-value lines, increment the property index, store the trimmed, lowercased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 10 - Compare the stored key against the lowercased input propertyKey; if they match, capture the corresponding value as the result.
- Step 11 - Close the configuration file using TEXT_IO.FCLOSE and return the result value (NULL if the key was not found).
- Step 12 - On NO_DATA_FOUND exception (configuration file path unresolved): if no bean is registered (m_registeredPackages is empty), call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 13 - On SQLCODE -302000 (file unreadable): if no bean is registered, call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 14 - On any other exception, re-raise to the caller.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains a value other than '[NOTSET]'.
TRUE: Use the global variable value as the configuration file path; skip environment and parameter lookups.
FALSE: Clear the path variable and attempt resolution via the environment variable (DP-002).

DP-002
Condition: TOOL_ENV.GETVAR returns a non-null value for WEBUTIL_CONFIG_ENV.
TRUE: Use the environment variable value as the configuration file path; skip the Forms parameter lookup.
FALSE: Attempt resolution via the Forms parameter WEBUTIL_CONFIG_PARAM (DP-003).

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null value.
TRUE: Use the Forms parameter value as the configuration file path.
FALSE: Raise NO_DATA_FOUND, triggering the missing-configuration error handler.

DP-004
Condition: The first character of the current line read from the file is '#'.
TRUE: Skip the line entirely (comment); continue to the next line.
FALSE: Proceed to evaluate the line as a potential key-value pair (DP-005).

DP-005
Condition: The current line contains an '=' character (INSTR result > 0).
TRUE: Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches propertyKey (DP-006).
FALSE: Skip the line; it is not a valid property entry.

DP-006
Condition: The lowercased, trimmed key of the current entry equals the lowercased input propertyKey.
TRUE: Capture the corresponding property value as the function result.
FALSE: Continue processing remaining lines without updating the result.

DP-007
Condition: A NO_DATA_FOUND or SQLCODE -302000 exception is raised, and m_registeredPackages.FIRST is null (no bean registered).
TRUE: Call WEBUTIL.ERRORALERT to display the appropriate English-language error message directly.
FALSE: Delegate error reporting to Webutil_Core.Error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: Forms global variable WEBUTIL_CONFIG_GLOBAL, then environment variable WEBUTIL_CONFIG_ENV, then Forms parameter WEBUTIL_CONFIG_PARAM. If none yields a value, the procedure treats this as a fatal configuration error.
- BR-002 - Once the configuration file path is successfully resolved, it must be written back to WEBUTIL_CONFIG_GLOBAL to cache it for subsequent invocations.
- BR-003 - Lines in the configuration file that begin with '#' are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are treated as valid property entries; lines without '=' are silently skipped.
- BR-005 - Property keys are stored and compared in lowercase with leading and trailing whitespace removed; property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped.
- BR-006 - When the configuration file path cannot be resolved (NO_DATA_FOUND), the module sets the m_config_error flag to TRUE and returns NULL, ensuring the caller receives a safe null result rather than an unhandled exception.
- BR-007 - When the configuration file cannot be read (SQLCODE -302000), the module sets the m_config_error flag to TRUE and returns NULL.
- BR-008 - Error messaging is context-sensitive: if no WebUtil bean has been registered (m_registeredPackages is empty), WEBUTIL.ERRORALERT is used to present the error in plain English; otherwise, error reporting is handled by the Webutil_Core framework.
- BR-009 - Any exception other than NO_DATA_FOUND and SQLCODE -302000 is re-raised unhandled, allowing the calling context to manage unexpected failures.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-046 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by delegating to the WebUtil_Core bean layer. The procedure sets the target file handle, supplies the text content, and appends a newline character, effectively replicating the behaviour of CLIENT_TEXT_IO.put_line over the WebUtil bridge. It is invoked during Excel report generation in the bodyshop production screen to stream report output line by line to the client file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, directing subsequent write operations to the correct open file.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, passing the text content (item) to be written to the file.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean to 1 via WebUtil_Core.setProperty, instructing the bean to append a newline character after the text, completing the line-write operation.
- Step 5 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If any property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
The WebUtil_Core bean corresponding to WUF_PACKAGE is registered and available on the client at the time of the three setProperty calls.

TRUE:
All three properties (WUF_TEXTIO_HANDLE, WUF_TEXTIO_PUT, WUF_TEXTIO_NEWLINE) are set successfully and the line is written to the client file; the procedure exits normally.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed identifying the missing bean class, and TOOL_ERR.TOOL_ERROR is raised to abort the calling process.

---

DP-002

Condition:
A property-set operation against the WUF_PACKAGE bean raises a PROPERTY_ERROR exception.

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately, aborting the calling process; no additional alert is displayed.

FALSE:
The property-set operations complete without error and processing continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil_Core bean for WUF_PACKAGE must be registered on the client before this procedure is called; if it is not, the procedure will not write any data and will raise a fatal error.
- BR-002 - A newline is always appended after the supplied text (WUF_TEXTIO_NEWLINE is unconditionally set to 1); callers cannot suppress the newline through this interface.
- BR-003 - Any failure in setting file-handle, text-content, or newline properties is treated as a fatal condition; TOOL_ERR.TOOL_ERROR is raised and execution of the calling routine is terminated.
- BR-004 - The procedure produces no return value; success is implied by the absence of an exception, and the caller is responsible for handling the raised TOOL_ERR.TOOL_ERROR if an exception occurs.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-047 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been loaded, it delegates population of the cache to WEBUTIL.POPULATEPROPERTYBUNDLE before returning the requested value. This function supports internal configuration look-ups performed by WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-045](#SP-045--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, return NULL immediately without further processing.
- Step 3 - If no configuration error exists and the property bundle is empty (count = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE passing the requested property key, and assign its return value as the result.
- Step 4 - If the property bundle is already populated (count > 0), iterate through each entry in m_propertyBundle and compare the stored property key (case-insensitively, using lower()) against the supplied propertyKey.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the resolved result value (or NULL if no match was found or a config error was present).

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no property look-up is attempted.

FALSE: Proceed to evaluate the state of the property bundle cache.

---

DP-002

Condition: The property bundle cache (m_propertyBundle) is empty (COUNT = 0).

TRUE: Delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to load the bundle and retrieve the value for the requested key in a single call.

FALSE: The bundle is already populated; iterate through existing entries to locate the matching key.

---

DP-003

Condition: During iteration of m_propertyBundle, the current entry's propertyKey (stored in lower-case) matches lower(propertyKey).

TRUE: Assign the entry's propertyValue to the result and exit the loop.

FALSE: Continue iterating to the next entry; if the loop exhausts all entries without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been detected (m_config_error = TRUE), the function must return NULL and must not attempt any property look-up or bundle population.
- BR-002 - Property key matching is case-insensitive; all stored keys are held in lower-case and the supplied key is converted to lower-case before comparison.
- BR-003 - When the property bundle cache is empty, WEBUTIL.POPULATEPROPERTYBUNDLE must be called to initialise the cache; direct key iteration is not performed on an unpopulated bundle.
- BR-004 - The function exits the iteration loop as soon as the first matching property key is found, ensuring that only the first occurrence of a duplicate key (if any) is returned.
- BR-005 - The return value is limited to VARCHAR2(1000 char); property values exceeding this length cannot be returned by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-048 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key from the supplied property key and optional arguments, then delegating the get/set cycle to the WebUtil Core layer. The function is currently used exclusively by WEBUTIL.CHECKLIBS to obtain the localised title text for the progress bar displayed during library checking.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional arguments string (args) as inputs.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup token.
- Step 3 - Write the composite token to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Immediately retrieve the resolved translated message from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed set/get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The composite lookup token passed to the WebUtil Core property store must be formed by joining propertyKey and args with a pipe character ('|') as the delimiter, even when args is NULL, resulting in a trailing pipe in the token.
- BR-002 - Translation resolution is fully delegated to the WebUtil Core layer via Webutil_Core.setProperty and Webutil_Core.getProperty; no translation logic is performed within this function itself.
- BR-003 - The function targets the fixed property identifiers WUC_PACKAGE (package scope) and WUC_TRANS_MSG (property name) for both the write and the read operations, ensuring the translated value is read back from exactly the same slot that was just written.
- BR-004 - The args parameter is optional and defaults to NULL; callers are not required to supply substitution arguments when the message requires none.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-049 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms session on its first contact. The procedure parses the bean's identification and environment data from the client, maps the bean short-name to an internal package constant, captures one-time client environment details (IP address, OS, architecture, locale, path/file separators), resolves and communicates the system-library download directory to the client, applies heartbeat-blocking and server-logging configuration, and triggers library availability checks for both the newly registered bean package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-014](#SP-014--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-026](#SP-026--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-031](#SP-031--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-033](#SP-033--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-035](#SP-035--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-044](#SP-044--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-052](#SP-052--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short-name from the first pipe-delimited token of the clientInfo parameter.
- Step 2 - Map the bean short-name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant; if no match is found, packageID remains unset.
- Step 3 - If the module-level client IP address (m_clientIP) is null, this is the first bean to register in the session; set the checkUserLibs flag to TRUE and parse tokens 2-8 of clientInfo to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), clientOSArch, m_clientOSArch (set to 1 when the architecture string contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 4 - If the packageID does not yet exist in the m_registeredPackages array, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE; only the first instance of each bean type is registered.
- Step 5 - When checkUserLibs is TRUE, resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 6 - Read the OS-architecture-specific system-library client directory from the property bundle (key 'install.syslib.location.client.<OSFamily>.<OSArch>') via WEBUTIL.READFROMPROPERTYBUNDLE; if null, fall back to the OS-family-only key ('install.syslib.location.client.<OSFamily>').
- Step 7 - If clientLibDir is still null, send a syslib-directory property to the WUC bean containing only the server host and application config, leaving client-side JRE handling to the bean; otherwise replace the '$(SERVERHOST)' placeholder in clientLibDir with the resolved server host name and send the full directory path plus server host and config to the WUC bean.
- Step 8 - When a specific clientLibDir was resolved, retrieve the previously stored client setting for 'install.syslib.dir' via WEBUTIL.GETCLIENTSETTING; if it differs from the newly resolved directory, update it via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 9 - Retrieve the WebUtil bean version from the WUC bean property 'WUC_BEAN_VERSION' via WEBUTIL.GETPROPERTY and store it in WEBUTIL_CORE.WEBUTIL_VERSION.
- Step 10 - If the property bundle key 'logging.connections' evaluates to 'true' (case-insensitive), log a connection record containing the current form name, client OS, and locale via WEBUTIL.LOG.
- Step 11 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS with the string representation of packageID to verify and download required libraries for the newly registered bean.
- Step 12 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 13 - Read the 'BlockAllowHeartBeat' property bundle value; if it equals 'true', 'yes', or '1' (case-insensitive), set the WUC_BLOCK_ALLOW_HEART_BEAT property to '1' on the bean; otherwise set it to '0'.
- Step 14 - Evaluate the server-logging flags: if both m_loggingAllowed and m_loggingErrorsOnly are TRUE, set WUC_SRV_LOGGING to '1'; if only m_loggingAllowed is TRUE, set it to '2'; otherwise set it to '0'.
- Step 15 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains unassigned; no package mapping is performed.

DP-002
Condition: m_clientIP IS NULL (no bean has been registered in this session yet).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; checkUserLibs remains FALSE and parsing is skipped.

DP-003
Condition: clientOSArch string contains '64'.
TRUE: m_clientOSArch is set to 1, indicating a 64-bit client architecture.
FALSE: m_clientOSArch remains at its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current trigger item is stored against packageID in m_registeredPackages and newPackage is set to TRUE.
FALSE: The package was already registered (e.g. bean placed in a multi-row block); no action is taken and newPackage remains FALSE.

DP-005
Condition: clientLibDir resolved from the property bundle (architecture-specific key) IS NULL.
TRUE: Fall back to the OS-family-only property bundle key to retrieve clientLibDir.
FALSE: Use the architecture-specific clientLibDir value.

DP-006
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: Send a syslib-directory property to the WUC bean containing only ':serverHost:CONFIG', delegating directory handling to the client JRE.
FALSE: Replace the '$(SERVERHOST)' placeholder in clientLibDir, send the full path to the WUC bean, and proceed to compare with the previously stored client setting.

DP-007
Condition: Previously stored client syslib directory (clientLibDirOld) differs from the newly resolved clientLibDir.
TRUE: Update the stored setting via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
FALSE: Directory is unchanged; no update is performed and REDOWNLOAD_SYSLIB is not set.

DP-008
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections') evaluates to 'true' (case-insensitive).
TRUE: A connection log entry is written via WEBUTIL.LOG containing form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-009
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to verify required bean libraries on the client.
FALSE: Library check for this package is skipped.

DP-010
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('BlockAllowHeartBeat') equals 'true', 'yes', or '1' (case-insensitive).
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT property is set to '1' on the bean, instructing the client to block heartbeat allow behaviour.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT property is set to '0'.

DP-011
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging mode communicated to client bean).
FALSE: Proceed to DP-012.

DP-012
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging mode communicated to client bean).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled on client bean).

DP-013
Condition: checkUserLibs is TRUE (evaluated after heartbeat and logging configuration).
TRUE: WEBUTIL.CHECKLIBS is called with the literal 'user' to verify and download user-defined libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only the ten known bean short-names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are valid identifiers; each maps to a fixed WEBUTIL_CORE package constant used for all subsequent array and property operations.
- BR-002 - Client environment data (IP address, OS name, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per Forms session, on the first bean registration; subsequent bean registrations do not overwrite these values.
- BR-003 - A client architecture containing the string '64' is classified as 64-bit (m_clientOSArch = 1); all other architectures default to the non-64-bit classification.
- BR-004 - Each bean type is registered at most once per form session; if the same bean appears in a multi-row block or is otherwise duplicated, only the first instance is recorded in m_registeredPackages.
- BR-005 - The system-library client directory is resolved with precedence: architecture-specific property bundle key first, OS-family-only key second, and JRE-delegated behaviour (no explicit directory) as the final fallback.
- BR-006 - The '$(SERVERHOST)' placeholder in the configured client library directory must be replaced with the runtime server host name before the value is transmitted to the client bean.
- BR-007 - If the resolved system-library directory differs from the value previously stored on the client, the stored setting must be updated and the REDOWNLOAD_SYSLIB flag must be set to TRUE to trigger a re-download.
- BR-008 - Connection logging is controlled by the 'logging.connections' property bundle key; the log entry must include the current form name, client operating system, and locale.
- BR-009 - Library availability checks (WEBUTIL.CHECKLIBS) for a bean package are performed only when that package is newly registered in the current session; re-registration of an existing package does not trigger a redundant library check.
- BR-010 - User library checks (WEBUTIL.CHECKLIBS with 'user') are performed only once per session, during the same first-registration pass that captures client environment data.
- BR-011 - The heartbeat-blocking instruction sent to the client bean is governed by the 'BlockAllowHeartBeat' property bundle key; accepted truthy values are 'true', 'yes', and '1' (case-insensitive); all other values result in heartbeat blocking being disabled.
- BR-012 - Server logging mode communicated to the client bean has three states: errors-only (WUC_SRV_LOGGING = '1'), full logging (WUC_SRV_LOGGING = '2'), and disabled (WUC_SRV_LOGGING = '0'), determined by the combination of m_loggingAllowed and m_loggingErrorsOnly flags.
- BR-013 - The WEBUTIL.LOG initialisation call (null message) must occur after at least one bean package has been registered, so that a handler bean exists to process any resulting client communication.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-050 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil client-side bean, obtaining a numeric handle that uniquely identifies the function for subsequent calls. The handle is returned to the caller and an internal registration counter is incremented for every successfully resolved function, enabling the Oracle Forms session to invoke native client-side library functions through the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-038](#SP-038--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Compose a pipe-delimited function specification string (libName || '|' || funcName) and transmit it to the WebUtil client-side bean by calling WebUtil_Core.setProperty with the WUL_PACKAGE target and the WUL_FUNCTION_SPEC property key.
- Step 3 - Retrieve the registration result from the WebUtil bean by calling WebUtil_Core.getProperty with the WUL_PACKAGE target and the WUL_REGISTER_FUNCTION property key; the bean returns a VARCHAR2 string representing the allocated function handle.
- Step 4 - Convert the returned string handle to a numeric value using TO_NUMBER and store it in the hnd field of a FunctionHandle record (funcHnd).
- Step 5 - Evaluate the resolved handle using ID_NULL (SP-038) to determine whether the registration produced a valid, non-null handle.
- Step 6 - If the handle is valid (not null), increment the module-level function handle counter (m_funcHandleCount) by 1 to track the total number of successfully registered functions.
- Step 7 - Return the populated FunctionHandle record to the caller.
- Step 8 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 9 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to abort processing.
- Step 10 - If the string-to-number conversion fails (VALUE_ERROR exception), raise TOOL_ERR.TOOL_ERROR to signal a data conversion failure.

---
**Decision Points**

DP-001

Condition: The handle string returned by WebUtil_Core.getProperty, when converted to a number and wrapped in a FunctionHandle record, is evaluated by ID_NULL(funcHnd) as NOT NULL (i.e., the bean successfully allocated a valid handle).

TRUE: The module-level counter m_funcHandleCount is incremented by 1, recording that a new function handle has been successfully registered.

FALSE: The counter is not incremented; the FunctionHandle record is still returned to the caller but reflects a null/invalid handle, indicating the registration did not produce a usable reference.

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty calls, indicating the WebUtil client-side bean implementation class is not available in the current session.

TRUE: An error alert is displayed to the user citing the missing bean class name, and FORM_TRIGGER_FAILURE is raised to halt the current trigger execution.

FALSE: Processing continues normally without raising an alert.

DP-003

Condition: A PROPERTY_ERROR exception is raised during the setProperty or getProperty interaction with the WebUtil bean.

TRUE: FORM_TRIGGER_FAILURE is raised immediately to halt the current trigger execution; no alert is displayed.

FALSE: Processing continues normally.

DP-004

Condition: A VALUE_ERROR exception is raised when TO_NUMBER attempts to convert the string handle returned by the bean.

TRUE: TOOL_ERR.TOOL_ERROR is raised, signalling a data conversion failure to the calling context.

FALSE: The numeric conversion succeeds and the FunctionHandle record is populated normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil bean must be formatted as a pipe-delimited string combining the library name and function name (libName || '|' || funcName); no other delimiter or format is permissible.
- BR-002 - A FunctionHandle is only considered successfully registered if ID_NULL (SP-038) returns FALSE for the resolved handle; only in that case is the global registration counter incremented.
- BR-003 - The module-level counter m_funcHandleCount must be incremented by exactly 1 for each successfully registered function handle, maintaining an accurate tally of active registrations within the session.
- BR-004 - If the WebUtil bean implementation class is absent at registration time, the procedure must surface a descriptive error alert identifying the missing class before aborting, ensuring the failure is visible to the end user.
- BR-005 - Any failure in the bean property exchange (PROPERTY_ERROR) or numeric conversion (VALUE_ERROR) must terminate processing immediately via the appropriate Oracle Forms or tool error mechanism; partial or silent failures are not permitted.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-051 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated properties and callback trigger, then nullifying the handle reference. This ensures that process resources managed by the WebUtil host utility are properly cleaned up after use, preventing stale handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process handle property on the WUH_PACKAGE bean, using the WUH_CLEAR_PROC property key and the current handle value.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger to remove any registered callback trigger associated with the process handle.
- Step 4 - Set the process.handle attribute to NULL, marking the PROCESS_ID as released and no longer referencing an active process.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised at any point, invoke WebUtil_Core.ErrorAlert to display an error message identifying the missing bean class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised during the attempt to clear the process properties via WebUtil_Core.

TRUE: WebUtil_Core.ErrorAlert is called with a message composed of the implementation class name for WUH_PACKAGE and a notification that WEBUTIL_HOST.Release_Process will not work; normal cleanup steps are aborted.

FALSE: The property clear, callback trigger removal, and handle nullification complete successfully with no error raised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be passed as IN OUT; the procedure explicitly nullifies process.handle upon successful completion, ensuring the caller cannot reuse a released handle.
- BR-002 - Both the WUH_PACKAGE bean property (WUH_CLEAR_PROC) and the associated callback trigger must be cleared together as an atomic cleanup sequence; neither step is performed in isolation.
- BR-003 - If the WebUtil bean is not registered in the runtime environment, the procedure must raise an error alert and must not silently fail, ensuring the absence of the required bean is visible to the user.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-052 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. This allows the Oracle Forms application to push runtime client settings (identified by propertyName) to the WebUtil Core package on the client tier, enabling dynamic configuration of client-side behaviour without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is non-null; if null, no action is taken and the procedure exits silently.
- Step 3 - If propertyName is non-null, invoke WebUtil_Core.setProperty passing the constant WebUtil_Core.WUC_PACKAGE as the target package identifier, the constant 'WUC_SET_LOCAL_PROPERTY' as the action key, and the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil Core bean has not been registered (WebUtil_Core.BEAN_NOT_REGISTERED exception), raise an error alert displaying the implementation class name followed by a descriptive message, then raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If a property error occurs during the setProperty call (WebUtil_Core.PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to call WebUtil_Core.setProperty with the WUC_PACKAGE identifier, the 'WUC_SET_LOCAL_PROPERTY' action key, and the concatenated propertyName||'='||propertyValue payload.

FALSE: Skip the setProperty call entirely; the procedure completes without performing any operation.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Display an error alert identifying the unregistered implementation class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No BEAN_NOT_REGISTERED error; continue normal execution or handle other exceptions.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raise FORM_TRIGGER_FAILURE silently to abort the current form trigger without displaying an additional alert.

FALSE: No PROPERTY_ERROR; procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName is treated as a no-operation; the procedure must not attempt to transmit a setting to the client bean when the property name is absent.
- BR-002 - The property payload delivered to the client bean must follow the format propertyName||'='||propertyValue; no other delimiter or encoding is applied.
- BR-003 - The target package for the client-side property call is always WebUtil_Core.WUC_PACKAGE and the action key is always 'WUC_SET_LOCAL_PROPERTY'; these values are not configurable by callers.
- BR-004 - If the WebUtil Core bean is not registered at the time of the call, the procedure must surface a descriptive error alert identifying the missing implementation class before terminating the form trigger.
- BR-005 - Both the BEAN_NOT_REGISTERED and PROPERTY_ERROR exception conditions must result in FORM_TRIGGER_FAILURE being raised, ensuring that any failure to apply a client setting immediately halts further form processing.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-053 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via WebUtil_DB_Local or a server-side file via JAVA_APPSERV_WRITER. It tracks the remaining chunk count and, once all chunks have been received, finalises the transfer by closing the target resource, recording overall upload success or failure, firing any registered callback trigger, and then clearing that trigger registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-015](#SP-015--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-016](#SP-016--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-017](#SP-017--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-024](#SP-024--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-028](#SP-028--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-029](#SP-029--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-056](#SP-056--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming uploadData parameter; if it is NULL or empty, mark the upload as failed (m_uploadSucceeded := false) and take no further action.
- Step 2 - Determine the write destination by evaluating the module-level flag m_toDB.
- Step 3 (DB path) - If m_toDB is TRUE, delegate the chunk write to WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 4 (File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.WriteData with the persistent object reference (m_persistObj) and uploadData. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception.
- Step 5 - Decrement the remaining-chunk counter (m_chunks := m_chunks - 1).
- Step 6 - If m_chunks reaches zero, all expected chunks have been received; proceed to finalise the transfer.
- Step 7 (Finalise - DB path) - Call WebUtil_DB_Local.CloseBlob(m_fileSize). If successful, set m_uploadSucceeded := true; otherwise retrieve the last error from WebUtil_DB_Local.getLastError, log it via WebUtil_core.Error, and leave m_uploadSucceeded as false.
- Step 8 (Finalise - File path) - Call JAVA_APPSERV_WRITER.CloseFile(m_persistObj, m_fileSize). If successful, set m_uploadSucceeded := true; otherwise retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, release the global Java object reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 9 - After finalisation, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1). If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 10 - Unconditionally call WEBUTIL.CLEARCALLBACKTRIGGER(-1) to deregister the callback trigger, regardless of whether it was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Mark m_uploadSucceeded := false and exit the procedure without writing data or decrementing the chunk counter.

FALSE: Proceed to write the data chunk to the designated destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the data chunk to the database BLOB using WebUtil_DB_LOCAL.WriteData.

FALSE: Write the data chunk to a server-side file using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failure)

TRUE: Retrieve error code and args, log the error via WebUtil_core.Error, and raise READWRITE_ERROR.

FALSE: Continue processing (decrement chunk counter).

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource and finalise the upload.

FALSE: No further action for this invocation; await subsequent chunks.

---

DP-005

Condition: m_toDB is TRUE (during finalisation)

TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob(m_fileSize).

FALSE: Close the file via JAVA_APPSERV_WRITER.CloseFile(m_persistObj, m_fileSize).

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob returns TRUE

TRUE: Set m_uploadSucceeded := true.

FALSE: Retrieve last error from WebUtil_DB_Local.getLastError, log it via WebUtil_core.Error, and leave m_uploadSucceeded as false.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE

TRUE: Set m_uploadSucceeded := true.

FALSE: Retrieve error code and args, log the error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData value is treated as an error condition; the upload is immediately marked as failed and no data is written.
- BR-002 - The write destination (database BLOB or server-side file) is determined exclusively by the module-level flag m_toDB; this flag must be set before SETDATA is called.
- BR-003 - Each call to SETDATA represents exactly one chunk; the chunk counter (m_chunks) must be initialised to the total expected chunk count before the first call and is decremented by one on every successful write.
- BR-004 - Finalisation (closing the target resource) occurs only when m_chunks reaches zero, ensuring the resource is not closed prematurely while chunks remain outstanding.
- BR-005 - On a file-path write failure, error details must be captured and logged before raising READWRITE_ERROR; partial uploads are not silently discarded.
- BR-006 - On a file-path close failure, the Java persistent object reference must be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR to prevent resource leaks.
- BR-007 - A registered callback trigger (identified by index -1) is fired after successful finalisation of the last chunk and is unconditionally cleared via WEBUTIL.CLEARCALLBACKTRIGGER(-1) regardless of whether it was executed.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-054 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a Java system property at runtime by delegating to the Java Native Interface (JNI) layer. The procedure accepts a property key and a property value, passes both to the underlying Java Virtual Machine via a JNI call to java.lang.System.setProperty, and returns the previous value of the named property (or NULL if it was not previously set). This allows Oracle Forms WebUtil to configure or override JVM-level system properties during a client session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input arguments.
- Step 2 - Initialise a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2).
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the assembled argument list and the fully-qualified method signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'.
- Step 6 - Return the VARCHAR2 result from the JNI call, which represents the previous value of the property before it was overwritten (NULL if the property did not exist).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally and returns the result of the Java system property assignment without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property key (a0) and the property value (a1) must be supplied as VARCHAR2 values; the JNI argument list is constructed with a fixed size of 2, so both positions must be populated before the Java method is invoked.
- BR-002 - The target Java method is the standard static method java.lang.System.setProperty; the property key and value are passed as Java String objects using the exact method signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', ensuring type safety at the JNI boundary.
- BR-003 - The function returns the previous value of the named system property as reported by the JVM; callers should expect a NULL return when the property was not previously defined.
- BR-004 - The call is made as a static method invocation (the first argument to JNI.CALL_STRING_METHOD is TRUE and the object reference is NULL), meaning no Java object instance is required and the property change applies at the JVM-global scope for the current client session.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-055 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the current cursor item so focus can be restored when the window is subsequently hidden. This routine is only active when the form is in NORMAL mode, preventing unintended window manipulation during Enter Query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-038](#SP-038--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which indicates whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Resolve the WebUtil hidden window handle by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW.
- Step 3 - Check whether the form system mode is 'NORMAL'; if it is not (e.g., Enter Query mode is active), skip all subsequent processing entirely.
- Step 4 - Validate that the resolved window handle is not null using WEBUTIL.ID_NULL (SP-038); if the handle is null, skip all subsequent processing.
- Step 5 - If 'show' is TRUE: capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the hidden window using SHOW_WINDOW; navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether the previously stored cursor item handle m_infoFrom is not null using WEBUTIL.ID_NULL (SP-038); if valid, navigate focus back to that item using GO_ITEM; hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'

TRUE: Proceed to evaluate the window handle and perform show/hide logic.

FALSE: Exit the procedure immediately without performing any window operations, preventing interference with Enter Query mode.

---

DP-002

Condition: The window handle resolved by FIND_WINDOW for WEBUTIL_HIDDEN_WINDOW is not null (evaluated via WEBUTIL.ID_NULL)

TRUE: Proceed to evaluate the 'show' flag and perform the appropriate window operation.

FALSE: Exit the procedure without performing any window operations.

---

DP-003

Condition: The 'show' parameter is TRUE

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Proceed to DP-004 to evaluate whether focus can be restored before hiding the window.

---

DP-004

Condition: The stored cursor item handle m_infoFrom is not null (evaluated via WEBUTIL.ID_NULL), applicable only when 'show' is FALSE

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not perform any window visibility changes when the form is operating in Enter Query mode; only NORMAL system mode permits execution.
- BR-002 - The WebUtil hidden window must resolve to a valid, non-null handle before any show or hide action is attempted; an unresolved window handle causes the procedure to abort silently.
- BR-003 - When displaying the WebUtil hidden window, the originating cursor item must be captured and retained in m_infoFrom so that focus can be accurately restored when the window is later hidden.
- BR-004 - The WebUtil hidden window title must be set to the string 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown, ensuring the displayed title reflects the current WebUtil version.
- BR-005 - Focus restoration to the original cursor item upon hiding the window is conditional; if m_infoFrom does not hold a valid item handle, focus restoration is skipped and the window is hidden without navigation.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-056 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a string data payload to a server-side file by invoking the Java method WriteData on the AppServerFileWriter class via the JNI bridge. This procedure acts as a PL/SQL wrapper that passes the supplied string argument to the underlying Java file-writer object and returns a Boolean indicating whether the write operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string payload (a0) to the argument list by calling JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class through JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result received from the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

DP-001

Condition: The return value of JNI.CALL_BOOLEAN_METHOD evaluates to TRUE or FALSE based on whether the Java WriteData method successfully wrote the data to the server-side file.

TRUE: The write operation completed successfully; TRUE is returned to the caller (WEBUTIL.SETDATA).

FALSE: The write operation failed; FALSE is returned to the caller (WEBUTIL.SETDATA), signalling that the data was not written.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must receive a valid Java object reference (obj) pointing to an initialised AppServerFileWriter instance; the JNI call targets the fixed class path 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' and method 'WriteData'.
- BR-002 - The data payload (a0) must be supplied as a VARCHAR2 string and is passed directly to the Java layer without transformation or validation at the PL/SQL level.
- BR-003 - The outcome of the write operation is communicated solely through the Boolean return value; no output parameters or exceptions are raised by this procedure itself.
- BR-004 - The JNI argument list must be constructed with a capacity of exactly one argument, matching the single-parameter signature '(Ljava/lang/String;)Z' of the target Java method.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-057 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_bodyshop_prod_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires in the bodyshop production form, this procedure receives the event name and its encoded parameter string, extracts the data payload and multi-part chunk metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer processing).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-019](#SP-019--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-030](#SP-030--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-044](#SP-044--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-049](#SP-049--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-053](#SP-053--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-054](#SP-054--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the incoming EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); if not, raise the internal 'unhandled' exception and exit silently.
- Step 2 - Extract the data payload string from EventParameters by reading the 'WUC_DATA' attribute via the internal get_parameter_attr call, storing the result in dataPayload.
- Step 3 - Extract the multi-part chunk descriptor from EventParameters by reading the 'WUC_DATA_MULTIPART' attribute, storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using WEBUTIL.GETNUMBER (DelimStr.getNumber) to determine the current chunk sequence number (chunkNumber, position 1) and the total number of chunks required to complete the payload (PayloadChunks, position 2), using '/' as the delimiter.
- Step 5 - If EventName is 'WUC_LOG_EVENT', forward dataPayload to WEBUTIL.LOG as a standard informational log entry.
- Step 6 - If EventName is 'WUC_ERROR_EVENT', forward dataPayload to WEBUTIL.LOG flagged as an error entry.
- Step 7 - If EventName is 'WUC_REGISTER', pass dataPayload to WEBUTIL.REGISTERBEAN to register the bean described by the payload.
- Step 8 - If EventName is 'WUH_CALLBACK_EVENT', convert dataPayload to a numeric callback index (m_lastCallback); if conversion fails, invoke WEBUTIL.ERROR with package code WUC_PACKAGE and error code 408. If the index is valid, execute the corresponding callback trigger stored in m_callbacks; if the index is null, log a warning via WEBUTIL.LOG.
- Step 9 - If EventName is 'WUT_TRANSFER_EVENT', pass dataPayload to WEBUTIL.SETDATA to store the transferred file data, then invoke WEBUTIL.SETPROPERTY to mark the WUT_TRANSFER_EVENT property as 'RECEIVED' on the WUT_PACKAGE component.
- Step 10 - On the 'unhandled' exception (unrecognised event name), suppress the error and return without action. All other exceptions are re-raised to the caller.

---
**Decision Points**

DP-001

Condition: EventName is not one of the five valid WebUtil event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: The internal 'unhandled' exception is raised; the exception handler catches it silently (null) and the procedure exits without further processing.

FALSE: Processing continues to payload extraction and event routing.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: dataPayload is forwarded to WEBUTIL.LOG as a standard (non-error) log message.

FALSE: Evaluation continues to the next event type check.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: dataPayload is forwarded to WEBUTIL.LOG flagged as an error message.

FALSE: Evaluation continues to the next event type check.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: dataPayload is passed to WEBUTIL.REGISTERBEAN to register the described bean.

FALSE: Evaluation continues to the next event type check.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a numeric callback index; proceed to DP-006 and DP-007.

FALSE: Evaluation continues to the next event type check.

---

DP-006

Condition: Conversion of dataPayload to a number succeeds (no INVALID_NUMBER exception) during WUH_CALLBACK_EVENT processing.

TRUE: m_lastCallback is set to the numeric value and processing continues to DP-007.

FALSE: WEBUTIL.ERROR is called with package code WUC_PACKAGE and error code 408, identifying 'WEBUTIL_CORE.CustomEventHandler' as the source; the callback is not executed.

---

DP-007

Condition: m_lastCallback is not null after successful numeric conversion during WUH_CALLBACK_EVENT processing.

TRUE: EXECUTE_TRIGGER is called with the trigger name stored at m_callbacks(m_lastCallback).

FALSE: A warning is written via WEBUTIL.LOG stating that the callback trigger for the host command was not specified.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: dataPayload is passed to WEBUTIL.SETDATA and the WUT_TRANSFER_EVENT property on WUT_PACKAGE is set to 'RECEIVED' via WEBUTIL.SETPROPERTY.

FALSE: No further routing action is taken (end of event dispatch chain).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the following five event names are considered valid for processing: 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', and 'WUT_TRANSFER_EVENT'. Any other event name is silently discarded without error propagation.
- BR-002 - Every event, regardless of type, requires extraction of both the 'WUC_DATA' payload and the 'WUC_DATA_MULTIPART' chunk descriptor from EventParameters before event-specific handling is performed.
- BR-003 - The multi-part chunk descriptor must be parseable as two '/' delimited integers representing the current chunk number and total chunk count; parsing is performed via WEBUTIL.GETNUMBER.
- BR-004 - For 'WUH_CALLBACK_EVENT', the data payload must be convertible to a valid numeric index into the m_callbacks collection; a non-numeric payload is treated as a hard error and reported through WEBUTIL.ERROR (error code 408) rather than silently ignored.
- BR-005 - A null callback index (m_lastCallback is null) after a successful numeric conversion during 'WUH_CALLBACK_EVENT' processing is treated as a configuration warning, logged via WEBUTIL.LOG, and does not trigger callback execution.
- BR-006 - Upon successful receipt of a 'WUT_TRANSFER_EVENT', the WUT_TRANSFER_EVENT property on the WUT_PACKAGE component must be explicitly set to 'RECEIVED' via WEBUTIL.SETPROPERTY to signal completion of the file-transfer handshake.
- BR-007 - Unrecognised exceptions other than the internal 'unhandled' event exception are re-raised to the caller and must not be suppressed within this procedure.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-058 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error condition by setting a global error flag, composing a formatted error message that identifies the calling function and error description, and forwarding the composed message to the debug logging facility. This procedure provides a centralised error-capture mechanism used by utility routines throughout the D2kwutil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the error description text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised.
- Step 3 - Compose the global variable ERROR_STACK by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, ensuring the stored message does not exceed the allowable length.
- Step 4 - Invoke DEBUGLOG (SP-062) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK value, so that the error is written to the debug log.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error description text stored in ERROR_STACK is truncated to a maximum of 1,968 characters to prevent overflow of the global variable.
- BR-002 - The ERROR_STACK message must be prefixed with the CallingFunction name followed by a colon-space separator, ensuring each logged error is traceable to its originating routine.
- BR-003 - The global flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, indicating to all subsequent logic that an error state is active.
- BR-004 - All errors captured by this procedure must be forwarded to DEBUGLOG (SP-062) at severity level 99, classifying them as high-severity debug events.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-059 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates error messages from the Oracle Forms tool error stack (tool_err) into a single string buffer, which is returned to the caller for upstream error reporting. If no tool errors are present but a SQL error exists, the current SQLERRM message is captured instead. The function serves as a utility to aggregate external error context into a returnable varchar2 value.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a loop counter (iCounter) and an output buffer (vcErrBuff, max 1968 characters) to hold the concatenated error messages.
- Step 2 - Check whether the tool error stack (tool_err) contains one or more errors by evaluating tool_err.nerrors > 0.
- Step 3 - If tool errors exist, iterate through each error on the stack from 1 to tool_err.nerrors.
- Step 4 - Within each iteration, append a newline character followed by the current tool_err.message to the buffer (vcErrBuff).
- Step 5 - If appending the next message would exceed the varchar2 buffer capacity, a VALUE_ERROR exception is raised; the exception handler exits the loop immediately to prevent overflow.
- Step 6 - After appending the message, remove the top error from the tool error stack by calling tool_err.pop.
- Step 7 - If no tool errors exist but SQLERRM is not null, append a newline character followed by the SQLERRM message to the buffer.
- Step 8 - Return the fully assembled error buffer string (vcErrBuff) to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0

TRUE: Enter the loop to iterate over and concatenate all messages from the tool error stack into the buffer, popping each entry after it is appended.

FALSE: Skip the tool error loop and evaluate whether a SQL error is available (proceed to DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when tool_err.nerrors is not > 0)

TRUE: Append a newline and the SQLERRM message to the buffer.

FALSE: No error message is appended; the buffer remains empty and an empty/null string is returned.

---

DP-003

Condition: VALUE_ERROR exception raised during string concatenation inside the loop

TRUE: The buffer has reached its 1968-character capacity limit; exit the loop immediately, discarding any remaining tool error messages.

FALSE: Concatenation succeeded within buffer limits; continue iterating and popping tool error messages.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Tool error stack messages take precedence over SQL error messages; SQLERRM is only captured when the tool error stack is empty.
- BR-002 - Each tool error message is prefixed with a newline character (chr(10)) before concatenation to ensure messages are separated in the output buffer.
- BR-003 - The error message buffer is capped at 1968 characters (varchar2(1968)); if concatenation of the next message would exceed this limit, collection stops immediately and no further tool error messages are appended.
- BR-004 - Each tool error entry is popped from the stack (tool_err.pop) after its message is appended, ensuring the stack is consumed during processing.
- BR-005 - The function always returns a varchar2 value to the caller; if neither tool errors nor a SQL error are present, the return value will be null or an empty string.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-060 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by other stored procedures within D2kwutil.pld - specifically GET_ENVIRONMENT_STRING and READ_REGISTRY - where a boolean result must be represented as a character string for further processing or output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean.
- Step 2 - Evaluate the value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL/falsy), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition: ThisBoolean IS TRUE

TRUE: The function returns the VARCHAR2 value 'TRUE'.

FALSE: The function returns the VARCHAR2 value 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 string; the only permitted return values are 'TRUE' and 'FALSE'.
- BR-002 - Any BOOLEAN value that does not evaluate to TRUE (including FALSE and NULL) is represented as 'FALSE' in the returned string.
- BR-003 - The function has no database interactions and no external dependencies; its behaviour is entirely determined by the value of the single input parameter ThisBoolean.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-061 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-tracking state by clearing the error-encountered flag and emptying the error message stack. This procedure is called by GET_ENVIRONMENT_STRING and READ_REGISTRY to ensure that any error conditions recorded during a previous operation do not carry over into the next invocation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level Boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, discarding any previously accumulated error messages.
- Step 3 - Return control to the calling routine with a clean error state.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every call, regardless of its prior value, ensuring no stale error flag persists between operations.
- BR-002 - ERROR_STACK must be set to NULL on every call, ensuring no residual error message text is inherited by a subsequent operation.
- BR-003 - The procedure accepts no input and produces no formal output; its sole effect is the unconditional reset of the shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-062 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel (Windows debug monitor or flat file) on behalf of any calling routine in D2kwutil. It enforces debug-state and level filtering so that only messages relevant to the current session configuration are recorded, and it handles automatic fallback from the Windows debug API to file-based logging when the API is unavailable, restoring the preferred channel once the API becomes available again.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-066](#SP-066--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-043](#SP-043--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-068](#SP-068--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState). If debug is inactive (iDebugState = 0) or paused (bDebugPaused = TRUE), exit immediately without logging.
- Step 2 - Compare the incoming DebugLevel against the current threshold (iDebugLevel). If DebugLevel exceeds the threshold, exit immediately without logging.
- Step 3 - If the timestamp flag (bDebugTimeStamp) is enabled, format the current system time as HH24:MI:SS and append a '>' separator to form vcDateStamp.
- Step 4 - Construct the full debug string (vcDebugString) by combining the zero-padded DebugLevel, the optional timestamp, the right-padded LoggingCall label (30 characters), and a truncated portion of LogString so that the total length does not exceed 2,000 characters.
- Step 5 - If iDebugState = 2 (Windows debug monitor mode), check whether DEBUG_API_ENABLED is TRUE.
  - Step 5a - If TRUE, call WINDEBUG (via win_api_debug.WinDebug) to write vcDebugString to the Windows debug monitor.
  - Step 5b - If FALSE, the API is unavailable; call SETDEBUG to switch the session to file-based logging (mode 1) targeting the configured debug file (defaulting to 'd2kwutil.log'), log a transition message at level 0, re-invoke DEBUGLOG recursively to write the original message to the file, and set bDebugType2Required = TRUE to remember that the Windows monitor was the intended channel.
- Step 6 - If iDebugState is not 2 (file-based logging mode), check whether a prior API failure was recorded (bDebugType2Required = TRUE) and whether DEBUG_API_ENABLED is now TRUE.
  - Step 6a - If both conditions hold, the Windows debug API has recovered; call SETDEBUG to restore mode 2, log a restoration message at level 0, reset bDebugType2Required = FALSE, and re-invoke DEBUGLOG recursively to write the original message to the Windows monitor.
  - Step 6b - Otherwise, open the debug file in append mode using TEXT_IO, write vcDebugString as a new line, and close the file.
- Step 7 - If any unhandled exception occurs during the above steps, suppress it and set iDebugState = 0 to disable further debug logging, preventing diagnostic activity from disrupting normal application processing.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: Procedure exits immediately; no message is logged.

FALSE: Processing continues to DP-002.

---

DP-002

Condition: bDebugPaused = TRUE

TRUE: Procedure exits immediately; no message is logged.

FALSE: Processing continues to DP-003.

---

DP-003

Condition: DebugLevel > iDebugLevel

TRUE: The message's verbosity exceeds the configured threshold; procedure exits immediately without logging.

FALSE: The message qualifies for logging; processing continues to DP-004.

---

DP-004

Condition: bDebugTimeStamp = TRUE

TRUE: Current system time (HH24:MI:SS) is formatted and included in the debug string prefix.

FALSE: No timestamp is prepended; vcDateStamp remains empty.

---

DP-005

Condition: iDebugState = 2 (Windows debug monitor mode)

TRUE: Attempt to write to the Windows debug monitor; proceed to DP-006.

FALSE: Session is in file-based logging mode; proceed to DP-007.

---

DP-006

Condition: DEBUG_API_ENABLED = TRUE

TRUE: Write vcDebugString to the Windows debug monitor via WINDEBUG.

FALSE: Windows debug API is unavailable; invoke SETDEBUG to switch to file-based logging (mode 1), log a transition notice, recursively log the original message to the file, and set bDebugType2Required = TRUE.

---

DP-007

Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE

TRUE: The Windows debug API has recovered; invoke SETDEBUG to restore mode 2, log a restoration notice, reset bDebugType2Required = FALSE, and recursively log the original message to the Windows monitor.

FALSE: No API recovery; open the debug file in append mode, write vcDebugString, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug logging is suppressed entirely when iDebugState equals 0; no message may be written regardless of the supplied parameters.
- BR-002 - Debug logging is suppressed when the session is paused (bDebugPaused = TRUE), allowing temporary suspension without altering the debug state or level configuration.
- BR-003 - A message is only logged if its DebugLevel does not exceed the configured threshold (iDebugLevel); messages above the threshold are silently discarded.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit after the fixed prefix (level, timestamp, and caller label) is accounted for.
- BR-005 - The caller label (LoggingCall) is always right-padded to 30 characters in the output string to ensure consistent column alignment across log entries.
- BR-006 - When Windows debug monitor logging (iDebugState = 2) is requested but DEBUG_API_ENABLED is FALSE, the session must automatically fall back to file-based logging via SETDEBUG, and the fallback must be recorded with a level-0 transition message before the original message is written.
- BR-007 - Once a fallback to file logging has occurred (bDebugType2Required = TRUE), the session must automatically restore Windows debug monitor logging via SETDEBUG as soon as DEBUG_API_ENABLED becomes TRUE again, and the restoration must be recorded with a level-0 restoration message before the original message is written.
- BR-008 - Any exception raised within DEBUGLOG must be silently caught and resolved by disabling debug logging (iDebugState := 0) to ensure that diagnostic instrumentation never causes failures in the host application.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-063 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function returns the resolved variable value as a VARCHAR2 string, or NULL (optionally raising an exception) when the variable cannot be resolved or the WIN_API layer is unavailable. It is invoked by WEBUTIL.GETVAR to surface environment-variable values to Oracle Forms at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-058](#SP-058--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-059](#SP-059--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-060](#SP-060--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-061](#SP-061--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-065](#SP-065--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (via Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the Boolean flag RaiseExceptions (converted to a character representation via BOOLTOCHAR).
- Step 2 - Reset the error state: call CLEAN_ERROR_STACK to clear any previously accumulated errors from the WIN_API error stack before processing begins.
- Step 3 - Initialise the return code iRC to 0.
- Step 4 - Check API availability: evaluate the WIN_API.API_ENABLED flag to determine whether the native WIN_API layer is accessible.
- Step 5 - Register the native function: if the API is available, call REGISTER_FUNCTION_CALL to bind the iGetDOSEnv handle to the D2KWUTIL_GETDOSENV entry point, declaring its calling signature ('LONG', '*CHAR,*CHAR,LONG').
- Step 6 - Prepare call buffers: wrap VariableName in percent signs to form the OS-style variable reference (e.g. %VAR_NAME%), initialise a 512-character null-padded output buffer vcBuff2, and set the buffer-length integer iBuff1 to 512.
- Step 7 - Invoke the native call: execute D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing the formatted variable name, the output buffer, and the buffer length; capture the integer return code iRC (the resolved value length).
- Step 8 - Log the native call result: call DEBUGLOG again at trace level 99 to record the returned value length and the populated buffer content.
- Step 9 - Evaluate the resolution outcome: if iRC equals 0 or the output buffer is unchanged (equals the formatted input string), the variable was not resolved; call ADD_ERROR to record a descriptive error message and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - Return the resolved value: if the native call succeeded and the buffer was populated, return vcBuff2 as the environment variable value.
- Step 11 - Handle NO_DATA_FOUND: re-raise the exception so the caller can manage it.
- Step 12 - Handle WIN_API.NOT_AVAILABLE: call ADD_ERROR with the standard NoAPI message, then re-raise the exception.
- Step 13 - Handle all other exceptions: call ADD_ERROR with the generic unexpected-error message concatenated with ADD_EXTERNAL_ERRORS output to capture any supplementary error detail, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the native D2KWUTIL_GETDOSENV function and invoke it to retrieve the environment variable value.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception handler, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition: The native call return code iRC equals 0, OR the output buffer vcBuff2 is identical to the formatted input string vcBuff1 (indicating the variable was not expanded).

TRUE: The environment variable could not be resolved; call ADD_ERROR to record the failure, then branch on RaiseExceptions (see DP-003).

FALSE: The variable was successfully resolved; return the populated buffer vcBuff2 to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to signal the resolution failure as an exception to the caller.

FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the native environment-variable lookup when WIN_API.API_ENABLED is TRUE; if the WIN_API layer is unavailable the function must raise WIN_API.NOT_AVAILABLE and must not attempt the lookup.
- BR-002 - The environment variable name must be submitted to the native call wrapped in percent signs (e.g. %VariableName%) to conform to the OS variable-reference convention expected by D2KWUTIL_GETDOSENV.
- BR-003 - The output buffer supplied to D2KWUTIL_GETDOSENV must be exactly 512 characters, null-padded, and the corresponding length argument must be set to 512.
- BR-004 - A return code of 0 from D2KWUTIL_GETDOSENV, or an output buffer that remains equal to the formatted input string, must be treated as a failed resolution; an error must be recorded via ADD_ERROR in both cases.
- BR-005 - When resolution fails, the caller's preference for error-handling governs the response: RaiseExceptions = TRUE causes NO_DATA_FOUND to be raised; RaiseExceptions = FALSE (the default) causes NULL to be returned without raising an exception.
- BR-006 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be logged via ADD_ERROR before being re-raised, ensuring the WIN_API error stack is populated for upstream diagnostics.
- BR-007 - Unhandled exceptions must include supplementary error detail obtained from ADD_EXTERNAL_ERRORS, concatenated to the standard unexpected-error prefix, to capture any additional context from external error sources.
- BR-008 - Entry and exit diagnostic information (input arguments, resolved value length, and resolved value) must be written to the debug log via DEBUGLOG at trace level 99 to support runtime troubleshooting without affecting normal execution flow.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-064 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows registry for a given registry path and entry key. It translates a human-readable root hive name (e.g., HKEY_LOCAL_MACHINE) into its numeric identifier, delegates the low-level read to the D2KWUTIL native library call D2KWUTIL_GETREGKEY, interprets the return code to detect error conditions, and returns the registry value as a VARCHAR2 string. The procedure supports an optional exception-raising mode, allowing callers to choose between silent NULL returns and propagated exceptions on failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-058](#SP-058--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-059](#SP-059--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-060](#SP-060--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-061](#SP-061--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-065](#SP-065--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG with severity 99, recording the RegPath, RegEntry, and RaiseExceptions argument values for traceability.
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the WIN_API integration layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL, supplying the function name and its parameter type signature.
- Step 5 - Determine the registry root hive by extracting the prefix of RegPath (the segment before the first backslash) and mapping it to its numeric constant: HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4. If the prefix does not match any known hive, call ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare the call buffers: set the subpath (RegPath after the first backslash) into vcBuff1, the entry name into vcBuff2, initialise the 2000-byte output buffer vcBuff3 with spaces padded to NUL, and set the buffer length (iBuff2 = 2000).
- Step 7 - Evaluate WIN_API.COMPAT_EXPAND_REG_VALUES. If FALSE (compatibility mode), set iBuff3 = 1 to suppress environment-variable expansion and log a compatibility debug message; otherwise set iBuff3 = 0 to allow expansion.
- Step 8 - Invoke D2KWUTIL_GETREGKEY via the registered function handle, passing the numeric root identifier, subpath, entry name, output buffer, buffer length, and the expansion flag. Capture the integer return code in iRC.
- Step 9 - Log the result by calling DEBUGLOG with the return code and the retrieved buffer value.
- Step 10 - Evaluate iRC for error conditions: RC=-1 indicates the entry could not be read; RC=-2 indicates an unsupported data type; RC=-3 indicates the value exceeds the 2000-byte buffer; RC=-4 indicates failure to expand an environment string. For each error code, call ADD_ERROR with a descriptive message and either return NULL or raise the appropriate exception depending on RaiseExceptions.
- Step 11 - If iRC indicates success (no negative code matched), return vcBuff3 as the registry value string.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the no-API message then re-raise; for all other exceptions, call ADD_ERROR appending ADD_EXTERNAL_ERRORS output and re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, hive mapping, buffer preparation, and the registry read call.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately, bypassing all registry operations.

DP-002
Condition: The extracted root hive prefix matches one of the five known hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric identifier (0-4) to iBuff1 and continue processing.
FALSE: Call ADD_ERROR reporting an invalid registry key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (iBuff1 is unset and the subsequent D2KWUTIL call will likely return an error code).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: Set iBuff3 = 1 to suppress environment-variable expansion in the registry value and log a compatibility debug message.
FALSE: Set iBuff3 = 0 to allow environment-variable expansion.

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (entry not found / cannot be read).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Evaluate the next return-code condition (DP-005).

DP-005
Condition: iRC equals -2 (unsupported registry data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Evaluate the next return-code condition (DP-006).

DP-006
Condition: iRC equals -3 (value length exceeds the 2000-byte buffer).
TRUE: Call ADD_ERROR citing the buffer size limit; if RaiseExceptions is FALSE return NULL, otherwise raise VALUE_ERROR.
FALSE: Evaluate the next return-code condition (DP-007).

DP-007
Condition: iRC equals -4 (environment string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: No error condition matched; return vcBuff3 as the successful result.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch DP-002 through DP-007).
TRUE: Raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) after logging the error.
FALSE: Return NULL to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - READ_REGISTRY may only execute when the WIN_API integration layer is enabled; if WIN_API.API_ENABLED is FALSE the function raises WIN_API.NOT_AVAILABLE and no registry access is attempted.
- BR-002 - The registry root hive must be one of the five recognised Windows hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other value is treated as an invalid registry key and triggers an error.
- BR-003 - The native registry read is performed exclusively through the registered D2KWUTIL_GETREGKEY function handle; the function handle must be registered via REGISTER_FUNCTION_CALL before the read is attempted.
- BR-004 - The output buffer for the registry value is fixed at 2000 bytes; values longer than this limit result in an RC=-3 error condition and the value is not returned.
- BR-005 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when this flag is FALSE, expansion is suppressed (iBuff3=1) to maintain backward compatibility.
- BR-006 - The caller controls error-handling behaviour through the RaiseExceptions parameter: when FALSE the function returns NULL on any error condition; when TRUE the function raises NO_DATA_FOUND (for entry-not-found, unsupported type, and expansion-failure errors) or VALUE_ERROR (for buffer-overflow errors).
- BR-007 - All error conditions, including invalid hive, read failures, unsupported data types, buffer overflow, and expansion failures, must be recorded via ADD_ERROR before the function returns NULL or raises an exception.
- BR-008 - Unhandled exceptions are enriched with external error details retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring the full error context is preserved for the caller.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-065 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

REGISTER_FUNCTION_CALL ensures that a named DLL function is correctly registered with the Oracle FFI (Foreign Function Interface) layer before it is called at runtime. It verifies that the target DLL is loaded, registers the function handle, its parameter types, and its return type if applicable, and caches the registration against the current DLL load count to avoid redundant re-registration. If the DLL is unavailable or FFI registration fails, it disables the API and raises a controlled exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-058](#SP-058--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-059](#SP-059--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-006](#SP-006--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-043](#SP-043--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-050](#SP-050--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the current session by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant and storing the result in DLL_HANDLE.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not yet loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD passing DLL_Path and DLL_NAME to attempt a fresh load of the DLL.
- Step 3 - If ATTEMPT_DLL_LOAD also raises an FFI error, set the package-level flag API_ENABLED to FALSE, record the failure via ADD_ERROR with source 'D2KWUTIL' and a message indicating the DLL was not found, then raise NO_DATA_FOUND to abort processing.
- Step 4 - Check whether the function has already been registered by testing whether FunctionLoad(FunctionId) exists in the cache array and, if so, whether its stored load count equals the current DLL_LOAD_COUNT.
- Step 5 - If the function is not cached or the load count has changed (indicating the DLL was reloaded), register the function handle by calling ORA_FFI.REGISTER_FUNCTION with DLL_HANDLE, FunctionName, and the ORA_FFI.C_STD calling convention, storing the result in FunctionHandle(FunctionId).
- Step 6 - If the function being registered is not the internal debug function 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (level 99) indicating either an initial registration or a re-registration, including the DLL load count and, for re-registrations, the previously cached load count.
- Step 7 - Append a comma delimiter to FunctionArgs and iterate through the comma-separated argument type tokens; for each token, call D2KWUTIL.TRANSLATETYPE to convert the type string to the corresponding ORA_FFI type constant and register it against the function handle via ORA_FFI.REGISTER_PARAMETER. Iteration stops when the remaining string is NULL, a bare comma, or 'VOID,'.
- Step 8 - After processing all parameters, if FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE on the return type string and register it against the function handle via ORA_FFI.REGISTER_RETURN.
- Step 9 - Store the current DLL_LOAD_COUNT in FunctionLoad(FunctionId) to mark the function as registered for this DLL load cycle, preventing unnecessary re-registration on subsequent calls.
- Step 10 - If an FFI error is raised at any point outside the inner DLL-load block, capture it in the outer exception handler, record the error via ADD_ERROR using FunctionName as the source and appending any external errors collected by ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL by DLL_NAME.

TRUE: DLL_HANDLE is populated and processing continues to the registration check (Step 4).

FALSE: An ORA_FFI.FFI_ERROR is raised; control passes to the inner exception block which attempts D2KWUTIL.ATTEMPT_DLL_LOAD.

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in loading the DLL.

TRUE: DLL_HANDLE is populated from the load attempt and processing continues to the registration check (Step 4).

FALSE: An ORA_FFI.FFI_ERROR is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised.

---

DP-003

Condition: FunctionLoad array contains an entry for FunctionId AND FunctionLoad(FunctionId) equals the current DLL_LOAD_COUNT.

TRUE: The function is already registered for the current DLL load cycle; Steps 5-9 are skipped entirely.

FALSE: The function has never been registered or the DLL has been reloaded since last registration; the full registration sequence (Steps 5-9) is executed.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: The DEBUGLOG diagnostic call is suppressed to avoid recursive logging.

FALSE: DEBUGLOG is called at level 99 to record either an initial registration or a re-registration event.

---

DP-005

Condition: FunctionLoad.exists(FunctionId) is TRUE at the time the DEBUGLOG call is made (within the re-registration branch).

TRUE: DEBUGLOG records a re-registration message that includes the previously cached load count.

FALSE: DEBUGLOG records an initial registration message without a prior load count.

---

DP-006

Condition: The remaining FunctionArgs string is NULL, equals ',', or equals 'VOID,' during parameter-loop iteration.

TRUE: The parameter registration loop exits; no further parameters are registered.

FALSE: The next comma-delimited type token is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered via ORA_FFI.REGISTER_PARAMETER.

---

DP-007

Condition: FunctionReturn is not 'VOID' (case-insensitive) AND FunctionReturn is not NULL.

TRUE: The return type is translated via D2KWUTIL.TRANSLATETYPE and registered via ORA_FFI.REGISTER_RETURN.

FALSE: No return type is registered (procedure-style call or explicitly void function).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable or loadable before any function registration is attempted; if neither ORA_FFI.FIND_LIBRARY nor D2KWUTIL.ATTEMPT_DLL_LOAD succeeds, the API is permanently disabled for the session (API_ENABLED = FALSE) and no registration proceeds.
- BR-002 - A function is only re-registered with the FFI layer when it has not been previously registered or when the DLL has been reloaded since the last registration, as determined by comparing FunctionLoad(FunctionId) against DLL_LOAD_COUNT; unnecessary re-registration is explicitly prevented.
- BR-003 - All parameter type strings supplied in FunctionArgs must be translatable by D2KWUTIL.TRANSLATETYPE into valid ORA_FFI type constants before they can be registered; the comma-separated list is processed left-to-right, one token per iteration.
- BR-004 - A return type is registered only when FunctionReturn is explicitly provided and is not 'VOID'; procedures or void functions must pass 'VOID' or NULL to suppress return-type registration.
- BR-005 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG instrumentation during registration to prevent recursive logging.
- BR-006 - Any FFI error that escapes the inner DLL-load block must be surfaced to the caller as NO_DATA_FOUND, with full error context recorded through ADD_ERROR and ADD_EXTERNAL_ERRORS before the raise, ensuring callers receive a deterministic failure signal rather than a raw FFI exception.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-066 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging session by setting the debug output type (file, screen, or off), the target log file name, the verbosity level, and whether log entries should be timestamped. Once configured, the procedure activates or deactivates the logging state accordingly and records an initialisation entry via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-062](#SP-062--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the package-level variable bDebugTimeStamp to control whether subsequent log entries include a timestamp.
- Step 2 - Store the incoming DebugFile value in the package-level variable vcDebugFile to identify the target log file for file-based logging.
- Step 3 - Store the incoming DebugLevel value in the package-level variable iDebugLevel to set the verbosity threshold for subsequent log calls.
- Step 4 - Evaluate the DebugType parameter to determine the logging mode to activate.
- Step 5 - If DebugType = 1, set iDebugState to 1 (file logging) and call DEBUGLOG to record the message 'Logging to File' appended with the DebugFile name.
- Step 6 - If DebugType = 2, set iDebugState to 2 (screen/alternative logging) and call DEBUGLOG to record the message 'Logging Started'.
- Step 7 - For any other DebugType value, call DEBUGLOG to record the message 'Logging Stopped' and then set iDebugState to 0, disabling all further debug logging.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG to log 'Logging to File <DebugFile>'.

FALSE: Proceed to evaluate DP-002.

---

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging mode) and invoke DEBUGLOG to log 'Logging Started'.

FALSE: Invoke DEBUGLOG to log 'Logging Stopped' and set iDebugState to 0, turning debug logging off.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the DebugFile parameter must supply the target file name, which is stored and referenced in subsequent log output.
- BR-002 - DebugType = 2 designates screen (or alternative non-file) logging; no file name is required for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and no further debug output is produced until SETDEBUG is called again with a valid active type.
- BR-004 - The default value of DebugLevel is 98, meaning a high verbosity threshold is assumed when no explicit level is provided by the caller.
- BR-005 - Timestamping of log entries is disabled by default (TimeStamp defaults to FALSE); the caller must explicitly pass TRUE to enable it.
- BR-006 - An initialisation entry is always written via DEBUGLOG at severity level 0 under the source label 'SetDebug' regardless of which logging mode is selected or deselected, providing an audit trail of every configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-067 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied to D2KWUTIL.ATTEMPT_DLL_LOAD by removing any semicolon-delimited suffix (retaining only the portion before the first semicolon) and stripping a trailing backslash directory separator, ensuring the returned path is clean and unambiguous for downstream DLL-load processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-043](#SP-043--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working copy of the input path (InPath) into a VARCHAR2(500) variable.
- Step 2 - Inspect the working path for the presence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate the working path to the substring that precedes the first semicolon, discarding everything from the semicolon onwards.
- Step 4 - Inspect the last character of the (possibly truncated) working path to determine whether it is a backslash ('\').
- Step 5 - If a trailing backslash is present, remove it by taking the substring from position 1 to one character less than the current path length.
- Step 6 - Return the sanitised path string to the caller (D2KWUTIL.ATTEMPT_DLL_LOAD).

---
**Decision Points**

DP-001

Condition:
INSTR(vcPath, ';') > 0 - the path contains at least one semicolon.

TRUE:
Truncate vcPath to the substring before the first semicolon (positions 1 to INSTR(vcPath,';') - 1), discarding any additional path entries that follow.

FALSE:
Leave vcPath unchanged and proceed to the trailing-separator check.

---

DP-002

Condition:
SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash directory separator.

TRUE:
Remove the trailing backslash by reassigning vcPath to SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE:
Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the path segment preceding the first semicolon is considered valid; any additional entries in a semicolon-delimited list are silently discarded.
- BR-002 - A trailing backslash directory separator must not be present in the returned path; if detected it is unconditionally removed.
- BR-003 - The function is non-destructive with respect to the original input: all modifications are applied to a local copy, and the original IN parameter value is never altered.
- BR-004 - The working path buffer is limited to 500 characters; input paths exceeding this length will be implicitly truncated on assignment.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-068 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a controlled interface for sending a debug string to the D2KWUTIL external debug output facility. It accepts a text message, appends a newline character, registers the required external function call handle, and delegates output to D2KWUTIL.D2KWUTIL_DEBUGSTRING. The procedure enforces that the underlying Win API layer is available before attempting the call, and surfaces structured error messages if the API is absent or any other failure occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-058](#SP-058--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-059](#SP-059--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-065](#SP-065--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and initialise a local buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text.
- Step 2 - Evaluate whether the Win API layer is active by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call by invoking REGISTER_FUNCTION_CALL with the debug-string function identifier (iDebugString), the function name 'd2kwutil_DebugString', and the parameter type '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the function handle obtained from WIN_API.FunctionHandle(iDebugString) and the prepared buffer, to write the debug string to the external debug output.
- Step 5 - If WIN_API.API_ENABLED is FALSE, raise the WIN_API.NOT_AVAILABLE exception, bypassing steps 3 and 4.
- Step 6 - In the NOT_AVAILABLE exception handler, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error constant to register the unavailability error, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message formed by concatenating WIN_API.UError with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: The procedure registers the external function call via REGISTER_FUNCTION_CALL and forwards the debug string to D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: The WIN_API.NOT_AVAILABLE exception is raised, triggering the NOT_AVAILABLE exception handler.

---

DP-002

Condition: The WIN_API.NOT_AVAILABLE exception is caught in the exception block.

TRUE: ADD_ERROR is called with 'WinDebug' and WIN_API.NoAPI to record the API-unavailability error; the exception is then re-raised to the caller.

FALSE: Control passes to the OTHERS handler if a different exception has been raised.

---

DP-003

Condition: An unclassified (OTHERS) exception is caught in the exception block.

TRUE: ADD_ERROR is called with 'WinDebug' and the concatenation of WIN_API.UError and ADD_EXTERNAL_ERRORS to record the unexpected error; the exception is then re-raised to the caller.

FALSE: No action is taken under this handler (condition not met means execution completed without an unclassified exception).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win API layer must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to write a debug string; the procedure does not silently swallow unavailability but raises and propagates the error to the caller.
- BR-002 - The input text is always extended with a newline character (CHR(10)) before being passed to the external debug facility, ensuring each debug entry is terminated on its own line.
- BR-003 - The external function call must be explicitly registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING is invoked; the function name 'd2kwutil_DebugString' and parameter type '*CHAR' are fixed registration values.
- BR-004 - All errors, whether arising from API unavailability or unexpected runtime failures, are recorded through ADD_ERROR before the exception is re-raised, ensuring the calling context receives both the structured error record and the propagated exception.
- BR-005 - Unexpected errors are enriched with external error detail by concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, providing a composite diagnostic message rather than a generic error code alone.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

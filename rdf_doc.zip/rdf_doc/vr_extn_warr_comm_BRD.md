# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Report Configuration - ED_REPORTS
    - Report Server Configuration - EH_REPORTS
    - Dealer Location Master - AM_DEALER_LOC
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (User - at submission)
    - Session and Control Parameters (System - at initialisation)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - L_POP_LIST_ITEM
    - PR_PASS_PARAM
    - GENERAL.ASK_CONFIRM
    - GENERAL.DISP_TEXT
    - GENERAL.RAISE_ERROR
    - GENERAL.l_pop_list_item
    - DBMS_APPLICATION_INFO.SET_CLIENT_INFO
    - DBMS_APPLICATION_INFO.SET_MODULE
    - STOP_WATCH.START_TIMER
    - WEB.SHOW_DOCUMENT
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - D2kwutil.pld (`Win_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - L_POP_LIST_ITEM
    - SP-002 - PR_PASS_PARAM
    - SP-003 - GENERAL.ASK_CONFIRM
    - SP-004 - GENERAL.DISP_TEXT
    - SP-005 - GENERAL.RAISE_ERROR

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_EXTN_WARR_COMM - Business Requirements Document |
| Form Module Name | VR_EXTN_WARR_COMM |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_extn_warr_comm Extension Warranty Commission Report form, its purpose, and roles referenced in the module.*

The **vr_extn_warr_comm** Oracle Forms module is the **Extension Warranty Commission Report** screen. A dealer user opens the form, selects the reporting parameters - including dealer location, contract month, reason code, and output format - and submits the request. The form validates that the reason field is not left empty, builds a parameter string from the current dealer, location, contract month, and principal, and runs the configured report against the report server, delivering the output directly to the user's browser as a PDF or in the selected format. When the user clears the screen, the form restores the report header details and re-confirms the target report server from configuration. The form does not create, modify, or delete transactional data; its sole business purpose is to generate and deliver the extension warranty commission report for the selected scope.

### Key Stakeholders

*Who uses vr_extn_warr_comm*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary interactive user of vr_extn_warr_comm. Selects dealer location, contract month, reason code, and output format, then submits the report request. |
| **Dealer Management / Business Manager** | Consumes the extension warranty commission report output for performance review and commission reconciliation (INFERRED). |

---

---

## 3. System Context

*Describes the vr_extn_warr_comm module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_extn_warr_comm** module is the **Extension Warranty Commission Report** screen within the dealer management system. It provides a self-service reporting interface for dealer users to generate commission reports for the extension warranty programme, scoped by dealer location, contract month, and reason code. The module connects dealer user context, authorised location data, and report configuration to the Oracle Reports server for report delivery.

**System purpose:** Allow a dealer user to select report parameters - dealer location, contract month, reason code, and output format - and generate the extension warranty commission report through the configured report server, from screen open through parameter validation and report delivery.

**In scope:**

- Open the report parameter screen with the dealer's pre-configured report title and server details
- Select an authorised dealer location from the dealer location lookup
- Select the contract month and reason code for the commission report scope
- Select the output format (PDF, HTML, or Character)
- Optionally specify an output file name when Excel format is selected
- Validate that the reason code is provided before submission
- Build the report parameter string from dealer, location, contract month, and principal values
- Submit the report for execution against the Oracle Reports server
- Deliver the generated report output to the user's browser
- Clear the screen and restore report header and server configuration from session globals

**Process Name:** Extension Warranty Commission Report Generation

**Process Owner:** Dealer Operations Manager (INFERRED)

**Process Objective:** Open the report parameter screen, select the dealer location, contract month, reason code, and output format, validate required parameters, build the report parameter string, and submit the report for delivery.

**Process Trigger:** Dealer user opens the Extension Warranty Commission Report screen to generate a commission report for the selected period and scope.

**Process Flow:**

The complete extension warranty commission report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Dealer user opens the vr_extn_warr_comm form.
         Application logging timer is started if logging is enabled.
         Session tracking is registered with the database module context.

STEP 2 ── REPORT HEADER DISPLAYED
         The report title and configured report server name are loaded from
         session globals and displayed on screen.

STEP 3 ── DEALER LOCATION SELECTION
         User activates the Dealer Description field and opens the dealer lookup.
         The system displays authorised dealer locations for the current user and
         principal from the dealer location master, filtered to active locations only.
         User selects a dealer location; location code and description are populated.

STEP 4 ── CONTRACT MONTH SELECTION
         User selects the contract month from the dropdown list.
         The selected month determines the reporting period for commission calculation.

STEP 5 ── REASON CODE SELECTION
         User selects a reason code from the Reason dropdown list.
         This field is mandatory - the screen will not allow submission if left empty.

STEP 6 ── REASON VALIDATION
         When the user leaves the Reason field, the system checks it is not null.
         ├── REASON PROVIDED: Navigation continues normally.
         └── REASON EMPTY: An error message is displayed and the user must select a value.

STEP 7 ── OUTPUT FORMAT SELECTION
         User selects the output format (HTMLCSS, PDF, or CHARACTER).
         The system defaults to PDF.

STEP 8 ── FILE NAME ENTRY - EXCEL FORMAT ONLY
         ├── FORMAT IS EXCEL: The File Name field is enabled and the user may enter
                              an output file name.
         └── FORMAT IS NOT EXCEL: The File Name field is cleared and disabled.

STEP 9 ── SUBMIT REPORT
         User clicks the Submit Report button.
         The system sets the application ID to the form name and builds the report
         parameter string by reading report parameter definitions from the report
         configuration table for the current application and principal.
         Parameters include dealer code, location, contract month, and principal.

STEP 10 ── REPORT OBJECT CONFIGURED
          The system locates the report object, sets the output format to PDF,
          appends bitmap and blank-pages options to the parameter string,
          sets the report file name and output destination path,
          and directs execution to the configured report server.

STEP 11 ── REPORT EXECUTED
          The report is submitted to the Oracle Reports server for execution.
          The generated output file is written to the server print directory.

STEP 12 ── REPORT DELIVERED
          The system opens the generated report in a new browser window for the user.

STEP 13 ── ERROR HANDLING
          If any Forms or Oracle error occurs during the process, the on-error handler
          intercepts it, displays a user-friendly message, and rolls back where required.
          Foreign-key constraint violations and concurrent update conflicts are
          specifically handled with descriptive alerts.

STEP 14 ── CLEAR SCREEN (OPTIONAL)
          User presses the Clear Form key to reset the screen.
          The form is cleared without validation; the report title, report name, and
          application ID are restored from session globals.
          The report server is re-queried from the report header configuration table
          for the current application and principal.

STEP 15 ── EXIT
          User presses the Exit key.
          Session tracking is cleared from the database module context.
          The form exits without validation.
```

**Major process interactions:**

- **Dealer location master (AM_DEALER_LOC)** - provides the list of authorised dealer locations for the current user and principal, filtered to active non-terminated locations
- **Application user master (AM_USERS)** - determines the user type and dealer assignments used to scope the dealer location lookup
- **Report parameter configuration (ED_REPORTS)** - supplies the parameter definitions (type, name, default, data type) used to build the report parameter string for the current application and principal
- **Report header configuration (EH_REPORTS)** - stores the report server name per application and principal, retrieved on form clear to restore the target server
- **Oracle Reports server** - executes the report object with the built parameter string and writes the output file to the server print directory for browser delivery

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Session Tracking Setup

**Business Description:**
When the Warranty Commission report form opens, the system registers the current user session with the application's monitoring infrastructure and sets the report description to *"Extended Warrenty Dealer Commission"*, establishing the application identity (`vr_extn_warr_comm`) in the session context. The form windows are maximised, the copyright declaration is retrieved, and the report server address is resolved from configuration. The Save and Delete toolbar buttons are disabled at startup. The Contract Month dropdown is populated with the last six available months using the `Category` record group and pre-selected to the most recent completed month. If application-level logging has been activated by the environment, the system also starts a performance timer so that execution times can be captured for audit and support purposes.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The user has been authenticated and their session is active in the system.
- The application monitoring infrastructure is available to accept session registration.
- The report configuration table (`EH_REPORTS`) is accessible for server address lookup.

**Main Flow:**

**Step 1 - Application logging timer started if activated**
If the environment has enabled application-level performance logging, the system starts an internal timer at the moment the form is opened. This allows the system to track how long each reporting session runs for performance and audit purposes.

**Step 2 - Session identification registered with the monitoring system**
The system registers the module identity of this form with the database session monitoring framework, recording the name of the current report module (`vt_extn_warr_comm`) so that all database activity during this session can be traced back to this form for support and audit purposes.

**Step 3 - Report description and application identity initialised**
The system sets the session report description to *"Extended Warrenty Dealer Commission"* and stores it in the global session variable `global.report_desc`. The application identity (`GLOBAL.app_id`) is set to `vr_extn_warr_comm`. Both values are copied to the corresponding display fields (`CB_BLK.report_name`, `CB_BLK.app_id`) so the header area reflects the correct report title and application context for the duration of the session.

**Step 4 - Form windows maximised and copyright declaration retrieved**
The system maximises the main form window (`WN_MAIN`) and the MDI host window to fill the available screen area. It then retrieves the current copyright declaration text from the database and stores it in the display field for presentation to the user.

**Step 5 - Report server address resolved for the session**
The system queries the report configuration table (`EH_REPORTS`) for a server address specific to the current application identity and principal. If a configured address is found, it is applied for this session. If no specific address is found, or any database error occurs, the system falls back to the default report server address already held in the session context.

**Step 6 - Save and Delete toolbar buttons disabled at startup**
The system disables the Save toolbar button (`PB_SAVE`) and the Delete toolbar button (`PB_DEL`) when the form first opens, so that neither action is available until the user has entered and confirmed the required report parameters.

**Step 7 - Contract month dropdown populated with the last six months**
The system builds a list of the six most recent completed months (the current month minus one through minus six) using the `Category` record group and loads it into the Contract Month dropdown field (`CB_BLK.P_CONTRACT_MONTH`). The list is filtered to include only months from July 2012 onward. Only months within the allowed historical range are offered to the user.

**Step 8 - Contract month defaulted to the previous month**
The system pre-selects the Contract Month field to the most recently completed month (one month before the current date) so the user does not need to make a selection unless they wish to report on a different period.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) If application-level logging is not activated, the performance timer is not started and the form opens directly to Step 2 without any timing instrumentation.
- **BR-001-AF-02** - (from Step 5) If no report server address is configured for this application and principal, or any database error occurs during the lookup, the default report server address from the session context is used without notifying the user.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form-Level Error Handling and User Notification

**Business Description:**
When any system error occurs while the user is working in the form, the system intercepts the error and presents a clear, context-appropriate message rather than displaying a raw system code. Different categories of error are handled distinctly: date format errors, character entry errors, record-locking conflicts, database integrity violations, and all other database errors each produce a specific user-facing message. After displaying the message, the system cancels the current operation and leaves the user on the form so they can correct the situation and retry.

**Actors:** Service Advisor / Report User

**Preconditions:**
- A system error has been raised during any operation within the form.

**Main Flow:**

**Step 1 - Error type identified and appropriate message displayed**
The system captures the Oracle Forms error code and any accompanying database error code. It then evaluates the error against a set of known conditions in sequence and routes to the appropriate message:

- If the error indicates an invalid date entry (error code 50004), the system displays *"Entered Date is not valid Date"* as an error alert and cancels the current operation, returning the user to the form.
- If the error indicates an incorrect date format (error codes 50025 or 50026), the system displays *"Enter the Date in the proper format (DD-MM-YYYY)"* as an error alert and cancels the current operation.
- If the error indicates that characters or special characters were entered where only numeric values are accepted (error codes 40209 or 50016), the system displays *"Characters/Special Characters are not allowed here, enter the numeric value"* as an error alert and cancels the current operation.
- If the error is a general field validation error (error code 40207), the system displays the Oracle Forms error text itself as an error alert and cancels the current operation.
- If the database error indicates a child record still exists and cannot be deleted (Oracle database error -02292), the system raises a structured error notification for error code E0088.
- If the error is a record-locking conflict (error codes 40654, 40655, 40656, 40657, or 40659), the system displays *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* as an error alert, rolls back any unsaved changes, and cancels the current operation.
- If any other database error is present, the system displays the database engine's own error description as an error alert, rolls back any unsaved changes, and cancels the current operation.
- If the error is a "no records found" or "end of records" navigation condition (error codes 40401 or 40405), the system takes no action and suppresses the notification silently.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an alert dialog to the user with the given message text and severity title, allowing the user to acknowledge the error before returning to the form.
    * **Step 1** - Determine the correct type of alert dialog to use based on whether the message is an error or an informational notification.
    * **Step 2** - Set the title of the alert dialog to the provided severity title.
    * **Step 3** - Set the body of the alert dialog to the provided message text.
    * **Step 4** - Display the alert dialog to the user and wait for acknowledgement.

- **GENERAL.RAISE_ERROR** ([SP-003](#SP-003--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up a structured error message by code, assembles the display text, and displays it as an alert of the appropriate severity; if the severity is an error, it also cancels further processing.
    * **Step 1** - Combine the error code with any available message text to assemble the text that will be shown (note: the message lookup is not active in the current version, so the displayed text is the error code followed by a separator).
    * **Step 2** - Evaluate the message type to determine the alert severity.
    * **Step 3** - If the message is classified as an error, display it as an error alert and stop further processing.
    * **Step 4** - If the message is classified as a note, display it as an informational alert without stopping processing.
    * **Step 5** - If the message is classified as a caution, display it as a caution alert without stopping processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date entry check | Error code 50004 - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Ensures the user is notified clearly when they have entered an invalid date value, rather than seeing a raw system error code | Operation cancelled; user sees *"Entered Date is not valid Date"* and remains on the form to correct the entry |
| Incorrect date format check | Error codes 50025, 50026 - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Guides the user to enter dates in the required DD-MM-YYYY format | Operation cancelled; user sees *"Enter the Date in the proper format (DD-MM-YYYY)"* |
| Non-numeric character entry check | Error codes 40209, 50016 - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Prevents letters or special characters from being entered in numeric-only fields | Operation cancelled; user sees *"Characters/Special Characters are not allowed here, enter the numeric value"* |
| General field validation error | Error code 40207 - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Surfaces the system's own validation message for the affected field | Operation cancelled; user sees the Forms-generated error text |
| Child record integrity violation | Database error -02292 - ON-ERROR (Form trigger) via GENERAL.RAISE_ERROR [SP-003] | When a system error is raised during any user action in the form | Prevents deletion of a record that is still referenced by child records, notifying the user via a structured error code | Operation cancelled; structured error notification for code E0088 displayed |
| Concurrent update conflict | Error codes 40654-40659 - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Protects data integrity when two users attempt to modify the same record simultaneously; prompts the user to refresh and retry | Unsaved changes rolled back; user sees *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; operation cancelled |
| General database error | Non-zero SQL code (any other error) - ON-ERROR (Form trigger) | When a system error is raised during any user action in the form | Ensures no database error goes silently unnoticed; all unexpected errors surface the database engine's own description | Unsaved changes rolled back; user sees the database engine's error description; operation cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Invalid date entered - *"Entered Date is not valid Date"*; operation cancelled, user remains on form.
- **BR-002-ES-02** - Incorrect date format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; operation cancelled, user remains on form.
- **BR-002-ES-03** - Non-numeric characters in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; operation cancelled, user remains on form.
- **BR-002-ES-04** - General field validation error - the Oracle Forms error text for the field is displayed; operation cancelled, user remains on form.
- **BR-002-ES-05** - Child record integrity violation (database error -02292) - structured error notification for code E0088 displayed; operation cancelled.
- **BR-002-ES-06** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; unsaved changes rolled back; operation cancelled.
- **BR-002-ES-07** - Any other database error - the database engine's own error description displayed; unsaved changes rolled back; operation cancelled.
- **BR-002-IC-01** - Navigation boundary conditions (error codes 40401, 40405) - silently suppressed; no message shown to the user.

---

---

#### Requirement ID: BR-003

**Requirement Title:** Form-Level Message Handling for Input Validation Notifications

**Business Description:**
When the system raises a standard information or validation message for specific field-entry conditions, the form intercepts the message and presents it as a formatted error alert rather than allowing the default system notification style. This ensures that numeric-field input errors and general validation messages are consistently displayed in the same visual style as other errors in the form, and that the current operation is cancelled so the user can correct the entry before proceeding.

**Actors:** Service Advisor / Report User

**Preconditions:**
- A system message has been raised during a field entry or navigation action in the form.

**Main Flow:**

**Step 1 - Message code evaluated and reformatted if applicable**
The system captures the message code and its associated text. If the message code falls into the category of non-numeric character entry or general field validation messages (codes 40209 or 40207), the system formats it as an error alert combining the message type identifier, code number, and description text, displays it to the user, and cancels the current operation. For all other message codes, the system takes no action and allows standard processing to continue.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an alert dialog to the user with the composed message text and an error severity title.
    * **Step 1** - Determine the correct type of alert dialog based on whether the message is an error or informational notification.
    * **Step 2** - Set the title of the alert dialog to the provided severity title.
    * **Step 3** - Set the body of the alert dialog to the provided message text.
    * **Step 4** - Display the alert dialog to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Non-numeric character and general validation message intercept | Message codes 40209, 40207 - ON-MESSAGE (Form trigger) | When the system raises a message during any field entry or navigation action | Ensures these specific validation messages are displayed in the same styled alert format as all other errors, providing a consistent user experience | Operation cancelled; user sees the formatted message combining the error type, code, and description text |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Non-numeric character or validation message (codes 40209, 40207) intercepted - message type, code, and description text displayed as a formatted error alert; operation cancelled; user remains on the form to correct the entry.

---

---

#### Requirement ID: BR-004

**Requirement Title:** Output Format Selection and File Name Field Activation

**Business Description:**
When the user selects or changes the output format for the report, the form automatically controls whether the file name field is available for entry. If the user selects the spreadsheet format, the file name field becomes enabled and editable so the user can specify an output file name. For any other output format, the file name field is cleared and made read-only, preventing the user from entering a value that would not apply to the chosen format.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The report parameters screen is open and the output format list is visible to the user.

**Main Flow:**

**Step 1 - Output format changed by user**
The user selects or changes the output format from the available list of formats. The system immediately evaluates the chosen format.

**Step 2 - File Name field state adjusted based on selected format**
If the selected format is anything other than the spreadsheet (EXCEL) format, the system clears any previously entered file name and disables the file name field so the user cannot enter a value. If the spreadsheet format is selected, the system enables the file name field and makes it navigable so the user can type a file name.

**Step 3 - File Name field state applied when cursor arrives at the field**
When the user navigates to the file name field (if it is accessible), the system re-applies the format-based rule: if the spreadsheet format is currently selected, the field allows both new entry and edits; otherwise, entry and editing are both disabled.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 2) If the current format selection is the spreadsheet format, the file name field is enabled for input without clearing any previously entered value; the user can proceed to enter or edit the file name.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Format (`P_DESFORMAT`) | Mandatory | List (selection) | N/A | N/A | Selected from the available output format list | Report parameters screen open | Must have a value selected before the report can be submitted | N/A |
| File Name (`FILENAME`) | Conditional - when spreadsheet format selected | Text | 4000 characters | N/A | N/A | Format selection completed | Required only when spreadsheet format is selected; disabled and cleared for all other formats | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Report Reason Validation

**Business Description:**
When the user completes entry of the reason selection field and moves to the next field, the system checks that a reason has been selected. If the reason is left blank, the system displays an error message and prevents the user from continuing until a valid reason has been chosen. This ensures that every report submission is accompanied by a documented reason, which is required for audit and reporting purposes.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The report parameters screen is active and the user has navigated past the reason selection field.

**Main Flow:**

**Step 1 - Reason field validated on exit**
When the user moves away from the reason field, the system checks whether a reason has been selected. If the reason field is empty, the system displays an error and prevents the user from proceeding to other fields.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-002](#SP-002--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays an error alert with the message *"Main Reason can not be empty"* and the title "Error", prompting the user to select a reason before continuing.
    * **Step 1** - Determine the correct alert type based on the error severity (this message uses the error alert type).
    * **Step 2** - Set the title of the alert dialog to "Error".
    * **Step 3** - Set the body of the alert dialog to *"Main Reason can not be empty"*.
    * **Step 4** - Display the alert dialog to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Reason field must not be empty | WHEN-VALIDATE-ITEM on Reason (`CB_BLK.P_REASON`) - own condition: P_REASON IS NULL | When the user moves away from the Reason field | Ensures every report submission is linked to a documented reason for audit and tracking purposes | User sees *"Main Reason can not be empty"*; navigation away from the field is blocked until a reason is selected |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Reason field left empty - *"Main Reason can not be empty"*; user must select a reason before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Reason (`P_REASON`) | Mandatory | List (selection) | N/A | N/A | Selected from the available reason list | Report parameters screen open | Must not be empty; a reason must be selected before submission | *"Main Reason can not be empty"* - user is blocked from navigating away until a selection is made |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Report Parameter Assembly and Report Submission

**Business Description:**
When the user clicks the Submit Report button, the system assembles the required report parameters using the filter values the user has entered, configures the reporting engine with the appropriate output format settings and file destination, and submits the report for generation. The generated report is produced as a PDF file and immediately displayed to the user in a new browser tab. The report is identified by the current user and the date and time of submission to ensure unique file naming. If any unexpected error occurs during this process, the system silently absorbs it without displaying an error to the user.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The report parameters screen is open and the user has selected or confirmed all required filter values.
- The report server address has been established for the current session.

**Main Flow:**

**Step 1 - Application identity set for the session**
The system records the application identity as the warranty commission report application, establishing the context for parameter assembly and report name resolution.

**Step 2 - Report parameters assembled**
The system assembles the complete set of report parameters - including the dealer code, location code, contract month, and principal - by iterating through the parameter configuration defined for this application and principal in the report configuration data.

*Procedures called:*
- **PR_PASS_PARAM** ([SP-001](#SP-001--PR_PASS_PARAM)) - PR_PASS_PARAM - builds the report parameter string by reading the configured parameters for this application and principal from the report configuration table, then appending the current values for dealer, location, contract month, and principal to the parameter string.
    * **Step 1** - Retrieve the list of configured report parameters for this application and the current principal from the report configuration data.
    * **Step 2** - For each configured parameter, append the dealer code value to the parameter string.
    * **Step 3** - For each configured parameter, append the location code value to the parameter string.
    * **Step 4** - For each configured parameter, append the contract month value to the parameter string.
    * **Step 5** - For each configured parameter, append the current principal value to the parameter string.
    * **Step 6** - Return the fully assembled parameter string to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report parameter configuration lookup | PR_PASS_PARAM [SP-001] - reads report parameter configuration from the report configuration table filtered by application identity and principal | When the user clicks the Submit Report button | Ensures the report is submitted with the correct set of parameters defined for this application and the user's principal, preventing misconfigured or missing parameters | If no configuration rows are found the parameter string remains empty and the report is submitted with no filter parameters |

**Step 3 - Report object located and output properties configured**
The system locates the report template in the form's report object registry, then configures the output settings: the format is set to PDF, the output destination is set to a file, and the output mode is set to bitmap with blank pages suppressed.

**Step 4 - Output file named using user identity and submission timestamp**
The system derives a unique output file name by combining the current user's login name with the exact date and time of submission, formatted to the second, and appending a .pdf extension. This file name is stored in the file name field for reference. The report server address carried from the session is applied to the report configuration.

**Step 5 - Report submitted and displayed in browser**
The system runs the report against the report server with the assembled parameters and configuration. Once the report has been generated and placed in the designated printer output folder, the system opens a new browser tab pointing to the generated PDF file so the user can view or download it immediately.

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-IC-01** - Report submitted silently on unexpected error - if any error occurs during report submission, the exception is absorbed silently and no error message is shown to the user; the button press has no visible effect.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Description (`P_DLR`) | Optional | Text (lookup-assisted) | N/A | Dealer Detail (`DEALER_DETAIL` LOV) | Dealer location code, description, parent group, dealer map code | Report parameters screen open | Must correspond to a valid dealer for the current principal when populated | N/A |
| Location (`P_LOC`) | Optional | Text | N/A | N/A | Populated via Dealer Detail LOV selection | Dealer selected | Carries the location code selected via the dealer lookup | N/A |
| Contract Month (`P_CONTRACT_MONTH`) | Optional | List (selection) | N/A | N/A | Selected from contract month list | Report parameters screen open | N/A | N/A |
| Application Identity (`APP_ID`) | Auto-populated | Text | 200 characters | N/A | Fixed value set at submission | Submit button clicked | System-set; not user-editable | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Text | 2000 characters | N/A | Set from application identity at submission | Application identity set | System-set; not user-editable | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Text | N/A | N/A | Loaded from session context | Session initialized | System-set; not user-editable | N/A |
| File Name (`FILENAME`) | Auto-populated | Text | 4000 characters | N/A | Generated from user identity and submission timestamp + .pdf extension | Format set to PDF | System-generated; read-only for PDF format | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form Toolbar Actions: Save, Cancel, Delete, and Form Reset

**Business Description:**
The form toolbar provides four active data-management actions: Save, Cancel, Delete, and Reset. When the user clicks Save, the system commits any pending changes to the database and then clears the form to its default state. When the user clicks Cancel and there are unsaved changes, the system asks the user to confirm abandonment before clearing the form; if no changes exist the form is cleared immediately. When the user clicks Insert, the system blocks the action and informs the user that inserting records is not permitted on this form. When the user clicks Delete while positioned on the master data block, the system asks the user to confirm before deleting the current record. When the user resets the form (Clear Form), the system clears all entered values and restores the report description, report name, and application identity from the session context. The system then looks up the report server address configured for the current application and principal; if a specific address has been defined in the report configuration, it is applied for the session. If no specific address is found - whether because no configuration row exists, multiple rows exist, or any other database error occurs - the system falls back to the default report server address from the session context. This ensures the form is always in a consistent, ready state with the correct server address regardless of configuration gaps.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The report parameters screen is open.
- A session context has been established for the current user, including a default report server address.

**Main Flow:**

**Step 1 - User clicks the Save toolbar button**
When the Save button is enabled and the user clicks it, the system commits all pending data changes to the database. Once the commit completes, the system clears all form fields and resets the form to its default state, ready for a new entry.

**Step 2 - User clicks the Cancel toolbar button**
When the Cancel button is enabled and the user clicks it, the system checks whether any unsaved changes exist on the form.

- If unsaved changes are present, the system displays the confirmation alert *"Entered data will not be Saved"* and waits for the user to respond. If the user confirms, the system clears all form fields without saving the changes.
- If no unsaved changes are present, the system clears all form fields immediately without displaying a confirmation prompt.

The system then resets the Contract Month field to the previous calendar month as the default.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes check before cancel | FT_CANCEL - checks :system.form_status = 'CHANGED' | When the user clicks the Cancel toolbar button | Prevents accidental loss of entered data by prompting the user before discarding changes | User sees *"Entered data will not be Saved"* and must confirm before the form is cleared |

**Step 3 - User clicks the Insert toolbar button**
When the Insert button is enabled and the user clicks it, the system does not create a new record. Instead it immediately displays the message *"This Operation Cannot be performed Here"* as an error notification, informing the user that the Insert action is not available in this form context.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert action blocked | FT_INSERT - checks PB_BLK.PB_INSERT ENABLED property | When the user clicks the Insert toolbar button while it is enabled | Prevents accidental record creation in a context where insert is not supported | User sees *"This Operation Cannot be performed Here"* as an error alert; no record is created |

**Step 4 - User clicks the Delete toolbar button**
When the Delete button is enabled and the cursor is positioned in the master data block, the system suspends form-level validation and navigates to the master data block. It then displays the confirmation alert *"Are you sure to Delete?"* and waits for the user to respond. If the user confirms, the system deletes the current master record. After the operation completes (whether or not the user confirmed), form-level validation is re-enabled.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete confirmation required | FT_DEL - checks PB_BLK.PB_DEL ENABLED and :SYSTEM.CURSOR_BLOCK = 'B_GM_PROGRAM_MASTER' | When the user clicks the Delete toolbar button while positioned on the master data block | Prevents accidental deletion of master records by requiring explicit user confirmation | If the user does not confirm, the record is not deleted; form validation is re-enabled regardless |

**Step 5 - Form contents cleared and session values restored (Reset)**
The system clears all fields in the form without prompting for save confirmation. It then restores the report description, report name, and application identity from the values stored in the current session context, so the form reflects the correct reporting context for the user's session.

**Step 6 - Report server address resolved for the current application and principal**
The system queries the report configuration to find the server address defined for the current application identity and principal. The query returns the configured server address if one exists, or falls back to the default server address from the session if no specific address is defined or if any database error occurs.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report server address lookup | KEY-CLRFRM (Form trigger) - SELECT NVL(rep_server, :global.rep_server) FROM EH_REPORTS WHERE app_id matches and principal matches | When the user resets the form | Ensures the correct report server is always used for this application and principal combination after a form reset | If no matching configuration row is found, or any database error occurs, the default server address from the session is used |

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 2) If the user does not confirm the cancellation prompt, no action is taken and the form remains in its current changed state.
- **BR-007-AF-02** - (from Step 4) If the Delete button is enabled but the cursor is not in the master data block, no action is taken.
- **BR-007-AF-03** - (from Step 6) If the report configuration table contains no row for the current application and principal (no data found), the system uses the default report server address from the session context without notifying the user.
- **BR-007-AF-04** - (from Step 6) If the report configuration table contains more than one row for the current application and principal, the system uses the default report server address from the session context without notifying the user.
- **BR-007-AF-05** - (from Step 6) If any other database error occurs during the server address lookup, the system uses the default report server address from the session context without notifying the user.

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-SM-01** - Save completed - all pending changes committed to the database; form cleared to default state.
- **BR-007-ES-01** - Cancel with unsaved changes - *"Entered data will not be Saved"* displayed; user confirms and form is cleared without saving.
- **BR-007-IC-01** - Cancel without unsaved changes - form cleared immediately with no prompt.
- **BR-007-ES-02** - Insert attempted - *"This Operation Cannot be performed Here"* displayed; no record created.
- **BR-007-SM-02** - Delete confirmed - master record deleted; form validation re-enabled.
- **BR-007-IC-02** - Delete not confirmed - no deletion; form validation re-enabled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display | 200 characters | N/A | Restored from session context | Session initialized | System-restored on form reset; not user-editable | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Text | 2000 characters | N/A | Restored from session context | Session initialized | System-restored on form reset; not user-editable | N/A |
| Application Identity (`APP_ID`) | Auto-populated | Text | 200 characters | N/A | Restored from session context | Session initialized | System-restored on form reset; not user-editable | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Text | N/A | Report configuration (`EH_REPORTS`) | Configured report server address for this application and principal | Session initialized | System resolves the server address from configuration or falls back to the session default | Falls back to session default on any database error |
| Contract Month (`P_CONTRACT_MONTH`) | Auto-populated | List (selection) | N/A | N/A | Reset to previous month on Cancel | Cancel action | Defaulted to previous calendar month after Cancel | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Form Exit with Session Cleanup

**Business Description:**
When the user exits the form, the system clears the session tracking information that was registered when the form was opened, removes the module identity from the database session monitoring record, and then closes the form without prompting the user to save any unsaved changes. This ensures that the database's session monitoring tables are kept clean and do not carry stale entries from closed report sessions.

**Actors:** Service Advisor / Report User

**Preconditions:**
- The report form is open and the user initiates an exit action.

**Main Flow:**

**Step 1 - Session tracking information cleared**
The system removes the client information and module name that were registered with the database session monitoring framework when the form was opened, resetting those tracking fields to empty values so the session no longer shows this report module as active.

**Step 2 - Form closed without save prompt**
The system closes the form immediately, without asking the user to confirm or save any changes that may have been made to the report parameter fields.

---

> **Note - Inactive Requirements:**
> The following trigger is present in the form but does not execute. It is documented here for completeness only.
>
> **KEY-COMMIT (Form trigger) - COMMENTED OUT / INACTIVE - does not execute.**
> A form-level KEY-COMMIT trigger exists in the form but contains only a null statement (`NULL;`) and is flagged as inactive. No commit or save action is implemented via this trigger. Standard Oracle Forms commit/save behaviour does not apply to this form's data block (the block has no base table).
>
> **WHEN-LIST-CHANGED on Reason field (CB_BLK.P_REASON) - COMMENTED OUT / INACTIVE - does not execute.**
> An item-level WHEN-LIST-CHANGED trigger exists on the Reason field but its entire body is commented out (`null;`). It was intended to clear several dependent fields when the reason changes but this behaviour is not active.
>
> **VALIDATE_CN_MAIN (Form Program Unit) - COMMENTED OUT / INACTIVE - does not execute.**
> A form-level program unit named VALIDATE_CN_MAIN exists in the form but its entire body is commented out. It was intended to perform null-checks and date/time/odometer validations on a test-drive record but this behaviour is not active.
>
> **CHECK_BEFORE_DELETE (Form Program Unit) - COMMENTED OUT / INACTIVE - does not execute.**
> A form-level program unit named CHECK_BEFORE_DELETE exists in the form but its entire body is commented out. It was intended to prevent deletion of a record that still has child enquiry records but this behaviour is not active.

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the VR_EXTN_WARR_COMM form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Application Logging Timer Start | Derivation | BR-001 | Application-level performance logging is activated for the environment | Start the performance timer at the moment the form opens | Enables tracking of report session execution times for performance monitoring and support |
| BRC-002 | Invalid Date Entry Error | Validation | BR-002 | A system error with code 50004 is raised during any user action | Display *"Entered Date is not valid Date"* as an error alert and cancel the current operation | Prevents the user from proceeding with an invalid date value and provides a clear, readable message instead of a raw system code |
| BRC-003 | Incorrect Date Format Error | Validation | BR-002 | A system error with code 50025 or 50026 is raised during any user action | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* as an error alert and cancel the current operation | Guides the user to enter dates in the required format, reducing repeated data entry errors |
| BRC-004 | Non-Numeric Character Entry Error | Validation | BR-002 | A system error with code 40209 or 50016 is raised during any user action | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* as an error alert and cancel the current operation | Enforces numeric-only entry on fields that require it, preventing data quality issues |
| BRC-005 | General Field Validation Error Display | Validation | BR-002 | A system error with code 40207 is raised during any user action | Display the Oracle Forms-generated error text for the field as an error alert and cancel the current operation | Surfaces the system's own validation message to the user in a consistent alert format |
| BRC-006 | Child Record Integrity Violation | Constraint | BR-002 | The database reports a child record integrity violation (Oracle database error -02292) | Raise the structured error notification for code E0088 | Prevents deletion of a parent record that is still referenced by child records, preserving referential integrity |
| BRC-007 | Concurrent Update Conflict | Validation | BR-002 | A record-locking conflict error is raised (error codes 40654, 40655, 40656, 40657, or 40659) | Roll back unsaved changes, display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* as an error alert, and cancel the current operation | Protects data integrity when two users attempt to modify the same record simultaneously |
| BRC-008 | General Database Error Handling | Validation | BR-002 | Any database error is present (SQL code is non-zero) and none of the specific error codes above apply | Roll back unsaved changes, display the database engine's own error description as an error alert, and cancel the current operation | Ensures no unexpected database error goes silently unnoticed; all unhandled errors surface their description to the user |
| BRC-009 | Navigation Boundary Message Suppression | Constraint | BR-002 | A navigation boundary condition message (code 40401 or 40405) is raised | Suppress the message silently; take no action | Prevents unnecessary "no records found" or "end of records" popups from interrupting the user during normal navigation |
| BRC-010 | Message Intercept for Input Validation Codes | Validation | BR-003 | A system message with code 40209 or 40207 is raised | Compose a formatted message combining the message type, code, and description text, display it as an error alert, and cancel the current operation | Ensures input-validation messages are presented in the same styled format as other errors, providing a consistent user experience |
| BRC-011 | File Name Field Disabled for Non-Spreadsheet Formats | Constraint | BR-004 | The user selects an output format other than the spreadsheet format | Clear the file name field and disable it so no value can be entered | Prevents the user from entering a file name that would have no effect for non-spreadsheet output formats |
| BRC-012 | File Name Field Enabled for Spreadsheet Format | Derivation | BR-004 | The user selects the spreadsheet (EXCEL) output format | Enable the file name field and make it navigable so the user can enter an output file name | Allows the user to specify the file name only when the chosen format actually uses it |
| BRC-013 | File Name Field Editability on Field Entry | Validation | BR-004 | The user navigates to the file name field | If the spreadsheet format is selected, allow both new entry and editing; otherwise disable both insert and update on the field | Enforces consistent file name editability rules regardless of how the user arrives at the field |
| BRC-014 | Reason Field Mandatory | Validation | BR-005 | The user moves away from the Reason field and it is empty | Display *"Main Reason can not be empty"* as an error alert and block navigation away from the field | Ensures every report submission is linked to a documented reason, which is required for audit and reporting purposes |
| BRC-015 | Report Parameter Assembly by Application and Principal | Derivation | BR-006 | The user clicks the Submit Report button | Retrieve the configured report parameters for this application and principal, then assemble a parameter string including dealer code, location code, contract month, and principal values | Ensures the report is submitted with the correct parameter set defined for the specific application and principal combination |
| BRC-016 | Report Output Format Fixed as PDF | Constraint | BR-006 | The user clicks the Submit Report button | Set the report output format to PDF, the destination type to file, and output mode to bitmap with blank pages suppressed | Standardises the report output format for all warranty commission report submissions |
| BRC-017 | Unique Report File Name from User and Timestamp | Derivation | BR-006 | The user clicks the Submit Report button | Derive the output file name by combining the current user's login name with the date and time formatted to the second, appending a .pdf extension | Ensures each submitted report produces a uniquely named output file, preventing collisions between concurrent or repeated submissions |
| BRC-018 | Silent Error Suppression on Report Submission | Constraint | BR-006 | Any unexpected error occurs during the report submission process | Absorb the error silently without displaying any message to the user | Prevents the user from seeing unhandled runtime errors during report submission |
| BRC-019 | Form Reset Restores Session Context Values | Derivation | BR-007 | The user resets the form | Clear all fields without a save prompt, then restore the report description, report name, and application identity from the current session context | Ensures the form returns to a consistent, session-correct state after a reset without losing the reporting context |
| BRC-020 | Report Server Address Resolution After Reset | Derivation | BR-007 | The form has been cleared and the session context has been restored | Query the report configuration for the server address specific to the current application and principal; if no unique address is found or any error occurs, use the default server address from the session | Ensures the correct report server is always applied after a form reset, with a reliable fallback when no specific server is configured |
| BRC-021 | Session Tracking Cleared on Form Exit | Constraint | BR-008 | The user exits the form | Clear the client information and module name registered with the database session monitoring framework, then close the form without a save prompt | Keeps the database session monitoring tables clean by removing stale entries when the report form is closed |

**Total Business Rules Identified: 21**

---

## 6. Data Requirements

*This section covers the data entities referenced or used by the VR_EXTN_WARR_COMM form, the report parameter fields captured from the user, the reference and configuration data the form queries, and the lifecycle of data within the form's scope.*

### 6.1 Business Entities and Relationships

*The form does not own a master database entity - its single block has no base table and captures no persisted records. It reads from two configuration tables and a dealer location master, and submits a report rather than saving form data.*

#### Report Configuration - ED_REPORTS

The report configuration entity stores the set of parameters that are expected for each application's report, keyed by application identity and principal mapping code. The form reads this entity at report submission time to determine which parameter names to assemble into the report parameter string. Each row represents one parameter definition for a specific application and principal combination.

#### Report Server Configuration - EH_REPORTS

The report server configuration entity stores the server address to be used when running reports for a given application and principal. The form reads this entity on form reset (and implicitly on initialisation) to determine which report server should receive the submitted report job. If no specific address is configured, the session default is used.

#### Dealer Location Master - AM_DEALER_LOC

The dealer location master stores the physical dealer locations and their associated parent group and dealer mapping codes. The form uses this entity as the source for the dealer selection lookup, allowing users to choose a dealer and location from the set of locations accessible to the current user.

#### Entity Relationships

The form's data model is configuration-driven. The report parameter configuration and report server configuration are both keyed by application identity and principal mapping code, linking them to the current session context. The dealer location master is filtered by the current user's authorised locations, drawing on the user-to-dealer access data.

```
EH_REPORTS (report server config, by app + principal)
ED_REPORTS (report parameter config, by app + principal)
AM_DEALER_LOC (dealer location master, filtered by user access)
```

### 6.2 Data Capture Requirements

*The form captures filter parameters that control which data appears in the generated report. No records are inserted or updated in the database; all captured values are passed to the reporting engine at submission time.*

#### Report Filter Parameters (User - at submission)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Description (`P_DLR`) | No | The dealer the user wishes to include in the report, selected from the authorised dealer list via a lookup | Must correspond to a valid dealer location accessible to the current user if populated; selection sourced from the Dealer Detail lookup |
| Location (`P_LOC`) | No | The dealer location code associated with the selected dealer; populated automatically when the dealer is chosen via the lookup | Carried from the dealer lookup result; no independent user validation |
| Contract Month (`P_CONTRACT_MONTH`) | No | The contract month for which the warranty commission report should be generated, selected from the available list | Selected from the available contract month list; no further validation enforced in form code |
| Reason (`P_REASON`) | Yes | The reason category for generating this report, selected from the available reason list | Must not be empty; validated when the user moves away from the field; displays *"Main Reason can not be empty"* if left blank |
| Format (`P_DESFORMAT`) | Yes | The output format for the generated report (e.g. PDF, EXCEL), selected from the available format list | Required; controls whether the file name field is enabled; PDF format suppresses file name entry |
| File Name (`FILENAME`) | Conditional | The output file name for the report; only applicable and editable when the spreadsheet format is selected | Required only when the spreadsheet format is selected; disabled and cleared for all other formats |

#### Session and Control Parameters (System - at initialisation)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Identity (`APP_ID` / global) | Auto-Populated | The application identity used to scope configuration and parameter lookups; set to the warranty commission report application at submission | System-set at submission; not user-editable |
| Report Name (`REPORT_NAME`) | Auto-Populated | The report file name to be passed to the reporting engine; set from the application identity at submission | System-set; not user-editable |
| Report Server (`REP_SERVER`) | Auto-Populated | The address of the report server to which the report job is submitted; resolved from the report server configuration or the session default | Resolved from configuration on form reset; system-set; not user-editable |
| Report Description (`REPORT_DESC`) | Auto-Populated | A display label describing the report; restored from the session context on form reset or initialisation | Restored from session; display only |
| Principal (`P_PRINCIPAL` / global) | Auto-Populated | The principal mapping code for the current user's organisation; used to scope configuration, dealer, and parameter lookups | Provided by the session; not user-editable |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Detail (`DEALER_DETAIL` LOV / `DEALER_DETAIL` record group - from `AM_DEALER_LOC`, `AM_USERS`, `AM_USER_DEALER_MASTER`) | Provides the list of dealer locations authorised for the current user and principal, used for dealer selection on the report parameters screen | When the user invokes the dealer lookup to select a dealer and location |
| Report Parameter Configuration (`ED_REPORTS`) | Defines which report parameters should be assembled and passed to the reporting engine for the current application identity and principal | At report submission, to build the parameter string for the report run |
| Report Server Configuration (`EH_REPORTS`) | Stores the report server address for a given application identity and principal | On form reset, to resolve the correct report server address |
| Application Logging Timer (`STOP_WATCH` - attached library) | Provides the performance timing function used to start a session timer when application logging is enabled | At form initialisation, if application-level logging is active |

### 6.4 Data Lifecycle

*Describes how data flows through this form; the form does not persist records - it captures filter parameters and passes them to the reporting engine.*

**Creation**

- No database records are created by this form. All block items are non-database items; the single block has no base table and no DML operations are performed.

**Updates**

- No database records are updated by this form. The form operates in a read-and-submit pattern: it reads configuration data and passes the assembled parameters to the report server.

**Save and Commit**

- The form's KEY-COMMIT trigger is inactive (contains only a null statement and does not execute). There is no save or commit action for the form's data block.
- Report submission is triggered by the Submit Report button and passes the assembled parameters to the Oracle Reports engine via the form's report object. No SQL commit is issued by the form.
- On form reset (clear form), unsaved parameter field values are discarded without a save prompt; configuration values are reloaded from the session context.
- On form exit (KEY-EXIT), the form closes without a save prompt.

**Retention and Audit**

- The form registers the module identity with the database session monitoring framework at open (PRE-FORM) and clears it at exit (KEY-EXIT), providing a session-level audit trail of which report module the user ran.
- If application-level logging is active, a performance timer is started at form open; the form does not itself record the timer result - that is handled by the logging infrastructure.
- No create or modify timestamps are written by this form. No archival or purge policy is implemented within the form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer Location master table - stores location codes, descriptions, parent group, dealer map codes, and principal mappings for each dealer outlet | Dealer Location Master | AM_USERS, Principal |
| AM_USERS | Application User master table - stores user IDs, user types, and dealer assignments used for access control and LOV filtering | User Master | AM_DEALER_LOC |
| APP_ID | Application identifier - form name assigned to the session globals to identify the current Oracle Forms module in report and logging contexts | Application ID | GLOBAL, Module |
| APP_LOG | Application logging flag - global variable; when set to `Y`, the performance timer is started at form open for session tracking | Logging Flag | GLOBAL, PRE-FORM |
| CB_BLK | Control Block - the single data block in the form, used for report parameter entry; has no direct database table binding | Control Block | Block |
| Contract Month | The calendar month used to scope the extension warranty commission report; selected by the user from the contract month dropdown | - | P_CONTRACT_MONTH, Report Parameter |
| Dealer Location | An authorised outlet of a dealer group, identified by a location code and description; used to scope the commission report to a specific site | Location | AM_DEALER_LOC, LOV |
| DMS | Dealer Management System - integrated software platform for dealership operations, within which vr_extn_warr_comm operates | - | Oracle Forms, Report |
| DPL | DPL program library (DPL.pld) - shared Oracle Forms PL/SQL library providing common utility procedures such as DISP_TEXT and RAISE_ERROR | - | PLD, GENERAL |
| ED_REPORTS | Report parameter configuration table - stores parameter type, name, default value, and data type for each application and principal combination | Report Config | EH_REPORTS, PR_PASS_PARAM |
| EH_REPORTS | Report header configuration table - stores the report server name per application and principal; queried on form clear to restore the target server | Report Header | ED_REPORTS, REP_SERVER |
| Extension Warranty | A vehicle warranty product that extends coverage beyond the standard manufacturer warranty; the subject of the commission report | - | Commission, Principal |
| GENERAL | Package alias used within DPL.pld for shared utility routines (DISP_TEXT, RAISE_ERROR, CHECK_NULL); refers to the general package of the DPL library | - | DPL, DISP_TEXT, RAISE_ERROR |
| GLOBAL | Oracle Forms global variable namespace (`:GLOBAL.*`) - stores session-level values such as APP_ID, PRINCIPAL, USERID, CUR_DATE, and REP_SERVER across triggers and program units | Global Variable | APP_ID, PRINCIPAL, USERID |
| LOV | List of Values - dropdown lookup popup in Oracle Forms; used in vr_extn_warr_comm for the DEALER_DETAIL dealer location selection | List of Values, Dropdown | DEALER_DETAIL, Record Group |
| OLB | Oracle Object Library (`.olb`) - a shared library of reusable Oracle Forms objects such as windows, canvases, and visual attributes; DPL.olb is the parent object library for this form | Object Library | DPL, Property Class |
| Oracle Forms | Oracle Forms 12c - the runtime platform for vr_extn_warr_comm; an event-driven, block-based UI framework for database applications | Forms, Oracle Forms 12c | DMS, OLB, PLD |
| PDF | Portable Document Format - the default output format for the commission report; selected via the Format dropdown | - | Output Format, P_DESFORMAT |
| PLD | PL/SQL Library (`.pld`) - a shared Oracle Forms program library compiled separately and attached to the form at runtime; DPL.pld provides shared utility routines | Program Library | DPL, GENERAL |
| Principal | Manufacturer or brand code - stored in `:GLOBAL.PRINCIPAL`; used to filter the dealer location LOV and report parameter data to a specific brand | Brand Code, Principal Map Code | GLOBAL, AM_DEALER_LOC |
| P_CHECK | Form parameter - numeric flag passed at startup; reserved for caller-side pre-check control; not used in active form logic | - | Parameter |
| P_CONTRACT_MONTH | Block item and report parameter - the contract month selected by the user; passed to the report as a parameter | Contract Month | P_DEALER, P_LOC |
| P_DESFORMAT | Block item - output format selector (HTMLCSS, PDF, CHARACTER); controls whether the filename field is enabled | Output Format | FILENAME, PDF |
| P_REGION | Form parameter - region code passed at startup to scope the report output to a specific geographic region | Region Code | Parameter |
| PRINCIPAL | See *Principal* above | - | GLOBAL, Principal |
| PR_PASS_PARAM | Form-local procedure - builds the report parameter string from ED_REPORTS configuration, appending dealer, location, contract month, and principal values | Pass Parameters | ED_REPORTS, SUBMIT |
| Record Group | An Oracle Forms data structure used to hold LOV query results; DEALER_DETAIL record group powers the dealer location LOV | - | LOV, DEALER_DETAIL |
| REP_SERVER | Report server name - stored in `:GLOBAL.REP_SERVER` and in CB_BLK; routes the report execution request to the correct Oracle Reports server instance | Report Server | EH_REPORTS, Oracle Reports |
| SUBMIT | The Submit Report push button on CB_BLK - triggers the report parameter build, report object configuration, and report execution sequence | Submit Report Button | WHEN-BUTTON-PRESSED, PR_PASS_PARAM |
| USERID | Logged-in user identifier - stored in `:GLOBAL.USERID`; used to filter the DEALER_DETAIL LOV to locations authorised for the current user | User ID | AM_USERS, GLOBAL |
| vr_extn_warr_comm | The Oracle Forms module identifier for the Extension Warranty Commission Report screen (lowercase: vr_extn_warr_comm; uppercase: VR_EXTN_WARR_COMM) | VR_EXTN_WARR_COMM | Extension Warranty, Commission |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_extn_warr_comm (VR_EXTN_WARR_COMM)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Extended Warrenty Dealer Commission Report (inherited from DPL.olb object group)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu_mul.mmx
- Source artifacts: `vr_extn_warr_comm_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier set to form name on report submission |
| APP_LOG | Char | Trigger | Application logging flag; when `Y` starts the performance timer at form open |
| CUR_DATE | Date | ProgramUnit | Current business date used for date validation comparisons |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal/manufacturer code used to filter dealer and report data by brand |
| REPORT_DESC | Char | Trigger | Report description label displayed on screen and restored on form clear |
| REPORT_NAME | Char | Trigger | Report name identifier used when locating and running the report object |
| REP_SERVER | Char | Trigger | Report server name used to route report execution requests |
| USERID | Char | RecordGroup / Trigger | Logged-in user ID used to filter dealer LOV to authorised locations |

### 8.1.2 Form Parameters

*All 2 ModuleParameter entries from vr_extn_warr_comm_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_CHECK | Number | 0 | Numeric flag passed at startup; reserved for caller-side pre-check control (not used in active form logic) |
| P_REGION | Char | - | Region code passed at startup to scope report output to a specific region |

**Total Parameters:** 2

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - report parameter entry block; no direct database table |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_extn_warr_comm_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_extn_warr_comm_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_extn_warr_comm_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 18 | 0 | 18 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **31** | **0** | **31** |

**Item detail (all 31 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | REPORT_DESC111 | false | Legacy report description field - unused display item, no canvas assigned |
| CB_BLK | REPORT_DESC | false | Report title displayed at top of screen |
| CB_BLK | P_MONTHYEAR | false | Month/year parameter (date format DD-MM-RRRR) for report period selection |
| CB_BLK | P_PARENT | false | Parent group code for dealer hierarchy filtering |
| CB_BLK | P_DEALER | false | Dealer code (hidden) returned from dealer LOV selection |
| CB_BLK | P_LOC | false | Location code (hidden) for the selected dealer location |
| CB_BLK | LOC_DESC | false | Location description display for selected dealer |
| CB_BLK | P_DLR | false | Dealer description - user-facing field with LOV for dealer selection |
| CB_BLK | P_CONTRACT_MONTH | false | Contract month list (values J and blank) for report filtering |
| CB_BLK | APP_ID | false | Application identifier stored in block; set to form name on submission |
| CB_BLK | REPORT_NAME | false | Report name identifier used to locate and invoke the report object |
| CB_BLK | REP_SERVER | false | Report server name used to route report execution |
| CB_BLK | SUBMIT | false | Submit Report button - triggers report parameter build and report execution |
| CB_BLK | FILENAME | false | Output file name field; enabled only when output format is EXCEL |
| CB_BLK | P_REASON | false | Reason code list; required field - cannot be left empty before report submission |
| CB_BLK | P_DESFORMAT | false | Output format selector (HTMLCSS, PDF, CHARACTER); controls file-name field enablement |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration display field shown at foot of form |
| CB_BLK | P_PRINCIPAL | false | Principal code stored in block for parameter passing to the report |
| PB_BLK | PB_EXIT | false | Exit button (inherited from DPL.olb PB_BLK); closes the form session |
| PB_BLK | PB_LIST | false | List-of-values button (inherited); triggers LOV display for the current field |
| PB_BLK | PB_INSERT | false | Insert button (inherited); initiates a new record in the active block |
| PB_BLK | PM_CONT | false | Continue/navigate button (inherited); advances form navigation |
| PB_BLK | PB_DEL | false | Delete button (inherited); removes the current record |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited); abandons pending changes |
| PB_BLK | PB_SAVE | false | Save button (inherited); commits pending changes to the database |
| PB_BLK | PB_PRINT | false | Print button (inherited); invokes the print action for the current form |
| PB_BLK | PB_CUT | false | Cut button (inherited); cuts selected text to clipboard |
| PB_BLK | PB_COPY | false | Copy button (inherited); copies selected text to clipboard |
| PB_BLK | PB_PASTE | false | Paste button (inherited); pastes clipboard content into the current field |
| PB_BLK | PB_ERR_EXIT | false | Error-window exit button (inherited); closes the error detail window |
| CB_ERR | TXT_ERR | false | Error message text display item (inherited via CB_ERR block); shows error detail in the WIN_ERR error window |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| DEALER_DETAIL | Dealer Details | DEALER_DETAIL | - |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | Trigger: PRE-FORM in Form - raised when region/dealer validation fails at startup |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.ASK_CONFIRM / DPL print-destination logic when the user initiates a print action |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.RAISE_ERROR / ON-ERROR handler to present error detail to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.DISP_TEXT for informational messages |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.ASK_CONFIRM for user confirmation prompts |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| PR_PASS_PARAM | Procedure | ED_REPORTS | Builds the report parameter string by querying ED_REPORTS for the current application and principal, appending dealer, location, contract month, and principal values; called from WHEN-BUTTON-PRESSED on SUBMIT |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL, GENERAL.DISP_TEXT (all commented out) | **COMMENTED OUT / INACTIVE** - All validation logic is block-commented; body executes NULL; was a validation procedure for test-drive records in another form |
| CHECK_BEFORE_DELETE | Unknown | SH_ENQUIRY, GENERAL.DISP_TEXT (all commented out) | **COMMENTED OUT / INACTIVE** - Entire body is block-commented; was a pre-delete check querying SH_ENQUIRY for dependent records |
| POPULATE_ERRORS | Package spec | PK_PLSQL_TABLE.CODE_TAB (type reference only) | Form-local package specification holding a PL/SQL table variable (`v_tab`) for error collection; no body implementation present |
| L_POP_LIST_ITEM | Procedure | FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP | Dynamically creates or refreshes a record group from a supplied SQL query and populates it; utility for dynamic list item population (commented header notes prototype period) |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level; PB_BLK.PB_EXIT (inherited) | Displays a confirmation or print-destination alert and returns the user's choice; used by the inherited exit and print button handlers |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | Raises an error and stops navigation if the supplied field value is null |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_REASON; Form level; ProgramUnit: CHECK_BEFORE_DELETE; ProgramUnit: VALIDATE_CN_MAIN | Displays a user-facing message alert with a supplied text string and title (Error or Note style) |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up a message code and displays the corresponding error, note, or caution alert; raises form trigger failure for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Form-level commit handler; body is `NULL;` - no save operation is performed | Replaced by report-submission workflow; commit not applicable to a report-parameter form |
| **Commented out** | Form | - | FT_SAVE | Inherited toolbar Save trigger; body is block-commented, executing `null;` - no save action is taken | Save action is not applicable to this report-parameter form; suppressed to prevent accidental commits |
| **Commented out** | CB_BLK | P_REASON | WHEN-LIST-CHANGED | Cleared dependent fields (P_FOR_DESC, P_FOR_CD, P_DEALER_DESC, LOC_DESC, P_PROGRAM, P_SESSION, P_AGENCY_CD, P_DEALER, P_LOC, P_PARENT) when reason selection changed | Block-commented; body executes `null;`; field cascade clearing removed from current implementation |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Called GENERAL.ASK_CONFIRM to prompt the user before exiting; on confirmation cleared DBMS application info and exited the form | Block-commented; exit confirmation logic removed; current exit behaviour is handled by the form-level KEY-EXIT trigger |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (38 business triggers):**
*vr_extn_warr_comm_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts all form errors; displays user-friendly messages for invalid dates, numeric entry errors, record-lock conflicts, and concurrent update conflicts; rolls back on unexpected Oracle errors |
| ON-MESSAGE | Form | - | Form level | Suppresses standard Forms messages for error codes 40209 and 40207; displays a formatted error dialog instead |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info and module context, then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name attached to the current item and displays it; advances to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Body is `NULL;`; no commit operation is executed |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation; restores report description, report name, application ID from globals, and re-queries the report server from EH_REPORTS |
| KEY-OTHERS | Form | - | Form level (inherited) | Inherited from DPL.olb object group; suppresses or handles all unassigned key events at form level |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Inherited from DPL.olb object group; navigates to the next item in tab order |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Inherited from DPL.olb object group; navigates to the previous item in tab order |
| KEY-NXTBLK | Form | - | Form level (inherited) | Inherited from DPL.olb object group; navigates to the next block |
| KEY-PRVBLK | Form | - | Form level (inherited) | Inherited from DPL.olb object group; navigates to the previous block |
| KEY-DOWN | Form | - | Form level (inherited) | Inherited from DPL.olb object group; moves focus down one record |
| KEY-UP | Form | - | Form level (inherited) | Inherited from DPL.olb object group; moves focus up one record |
| FT_SAVE | Form | - | Form level (inherited) | **COMMENTED OUT / INACTIVE** - Inherited toolbar Save trigger; body block-commented; save not applicable to this report-parameter form |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited from DPL.olb object group; cancels pending changes and reverts the current record |
| FT_INSERT | Form | - | Form level (inherited) | Inherited from DPL.olb object group; initiates insert mode for the active block |
| FT_DEL | Form | - | Form level (inherited) | Inherited from DPL.olb object group; deletes the current record after confirmation |
| FT_LIST | Form | - | Form level (inherited) | Inherited from DPL.olb object group; displays the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited from DPL.olb object group; invokes the print action for the current form |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Inherited from DPL.olb object group; performs standard form initialisation - sets global variables, populates defaults, and configures the initial UI state |
| PRE-FORM | Form | - | Form level | Starts the application performance timer if logging is enabled; sets DBMS application info module to `vt_extn_warr_comm` for session tracking |
| KEY-LISTVAL | CB_BLK | P_DLR | CB_BLK.P_DLR | Displays the DEALER_DETAIL LOV for the dealer description field; active LOV call; older dynamic LOV code is commented out |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Sets global and block application ID; calls PR_PASS_PARAM to build the report parameter string; configures and runs the report object as a PDF file; opens the output in a new browser window |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | FILENAME | CB_BLK.FILENAME | Enables the filename field for insert and update only when the selected output format is EXCEL; otherwise disables it |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REASON | CB_BLK.P_REASON | Validates that the reason field is not null; displays an error and raises failure if empty |
| WHEN-LIST-CHANGED | CB_BLK | P_REASON | CB_BLK.P_REASON | **COMMENTED OUT / INACTIVE** - Body executes `null;`; previously cleared dependent fields on reason change |
| WHEN-LIST-CHANGED | CB_BLK | P_DESFORMAT | CB_BLK.P_DESFORMAT | Enables or disables the filename field based on whether the selected output format is EXCEL |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | **COMMENTED OUT / INACTIVE** - Previously called GENERAL.ASK_CONFIRM before exiting; body block-commented; exit is now handled by the form-level KEY-EXIT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button; displays the LOV for the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button; initiates insert mode in the active block |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button; advances form navigation to the next step or block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button; deletes the current record after user confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button; abandons pending changes and reverts the current record |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button; commits pending changes to the database |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button; invokes the print action via GENERAL.ASK_CONFIRM print-destination prompt |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button; cuts selected text from the current field to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button; copies selected text from the current field to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button; pastes clipboard content into the current field |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Extended Warrenty Dealer Commission Report(1.1.0) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vr_extn_warr_comm_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_extn_warr_comm_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_extn_warr_comm_fmb.xml.*

## 9. Object Library

*The form references the DPL object library, which provides the standard Visual Attributes and Property Classes used across this application suite. Three Visual Attributes are declared in the form module itself (VA_MANDATORY, VA_DEFAULT, VA_DISPLAY) and one Object Group (OG_GROUP) is inherited from the DPL library. The full catalogue of library objects available from DPL is listed below.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual style - gray background, Arial 8pt, black foreground | Not directly referenced in this form | N/A |
| VA_RB | VisualAttribute | Radio button visual style - gray background, Arial 8pt, black foreground | Not directly referenced in this form | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual style - white background, black foreground | Not directly referenced in this form | N/A |
| VA_DESC | VisualAttribute | Description field visual style - gray background, Small Fonts 7pt, blue foreground | Not directly referenced in this form | N/A |
| VA_NUM | VisualAttribute | Numeric field visual style - white background, Arial 8pt, black foreground | Not directly referenced in this form | N/A |
| VA_MAND | VisualAttribute | Mandatory field visual style - cyan background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| VA_OPROMPT | VisualAttribute (Prompt) | Optional field prompt style - white background, Arial 9pt, black prompt foreground | Not directly referenced in this form | N/A |
| VA_MPROMPT | VisualAttribute (Prompt) | Mandatory field prompt style - white background, Arial 9pt, red prompt foreground | Not directly referenced in this form | N/A |
| VA_TEXT | VisualAttribute | Standard text field visual style - white background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| VA_BUTN | VisualAttribute | Push button visual style - gray background, Arial 10pt bold, black foreground | Not directly referenced in this form | N/A |
| VA_ALERT | VisualAttribute | Alert dialog visual style - gray background, MT Extra 11pt demilight, black foreground | Not directly referenced in this form | N/A |
| VA_TITLE | VisualAttribute | Title label visual style - gray background, Arial 10pt bold, blue foreground | Not directly referenced in this form | N/A |
| VA_TRNI_DT | VisualAttribute | Transaction date visual style - white background, Courier bold, black foreground | Not directly referenced in this form | N/A |
| VA_LOV | VisualAttribute | LOV field visual style - gray background, Arial 9pt, dark-blue foreground | Not directly referenced in this form | N/A |
| VA_DISP | VisualAttribute | Display field visual style - r25g75b75 background, Arial 8pt bold, black foreground | Not directly referenced in this form | N/A |
| PC_DESC | PropertyClass | Display item property class - left-justified, white background, blue foreground, Arial 9pt, no bevel, max 110 chars, width 250 | Not directly referenced in this form | N/A |
| PC_SC_DATE | PropertyClass | Display date item property class - gray background, Arial 8pt bold, blue foreground, format mask DD-MM-RRRR, max 11 chars, hint for date entry format | Not directly referenced in this form | N/A |
| PC_TITLE | PropertyClass | Title text item property class - gray background, Arial 10pt bold, blue foreground, centred, upper case | Not directly referenced in this form | N/A |
| PC_FORMAT | PropertyClass | Format code text item property class - white background, Arial 9pt, centred, upper case, max 12 chars, width 60 | Not directly referenced in this form | N/A |
| PC_MR_BLK | PropertyClass | Multi-row block navigation property class - vertical orientation, next navigation block set to PB_BLK, scrollbar width 12 | Not directly referenced in this form | N/A |
| PC_DISP | PropertyClass | Display-only item property class - disabled, non-navigable, lowered bevel, gray background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| PC_LOV | PropertyClass | LOV field property class - gray background, Arial 8pt, dark-blue foreground, auto-select off, LOV position 80/96, height 200, width 250 | Not directly referenced in this form | N/A |
| PC_FORM | PropertyClass | Standard form-level property class - includes ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM triggers; console window WN_MAIN, menu module menu.mmx | referenced (form inherits error/message handling pattern) | ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM |
| PC_DISP_DATE | PropertyClass | Display date item property class - disabled, non-navigable, format mask DD-MM-RRRR, gray background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| PC_DISP_NUM | PropertyClass | Display numeric item property class - disabled, non-navigable, right-justified, lowered bevel, gray background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| PC_DATE | PropertyClass | Editable date text item property class - white background, Arial 9pt, format mask DD-MM-RRRR, max 10 chars, width 60, date entry hint | Not directly referenced in this form | N/A |
| PC_DTTIME | PropertyClass | Date-and-time text item property class - format mask DD-MM-RRRR HH24:MI, max 15 chars, width 80, VA_TEXT visual attribute, initialised to current date-time | Not directly referenced in this form | N/A |
| PC_CB | PropertyClass | Check box property class - white background, Arial 9pt, height 14 | Not directly referenced in this form | N/A |
| PC_ALERT | PropertyClass | Alert property class - gray background, MT Extra 11pt demilight, black foreground | Not directly referenced in this form | N/A |
| PC_MDATE | PropertyClass | Mandatory date text item property class - white background, format mask DD-MM-RRRR, red prompt foreground; includes WHEN-VALIDATE-ITEM trigger that enforces non-null entry using the field's hint text as the error message | Not directly referenced in this form | N/A |
| PC_RB | PropertyClass | Radio button property class - gray background, Arial 9pt, black foreground | Not directly referenced in this form | N/A |
| PC_WIND | PropertyClass | Window property class - resizable, minimizable, maximizable, moveable, hide on exit, gray background, Arial 10pt bold, blue foreground, size 464×286 | Not directly referenced in this form | N/A |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial font, window WN_MAIN, raise on enter, size 750×440, viewport 479×301 | Not directly referenced in this form | N/A |
| PC_BUTN | PropertyClass | Push button property class - gray background, Arial 9pt bold, non-navigable, width 42, height 16 | Not directly referenced in this form | N/A |
| PC_TEXT | PropertyClass | Standard text item property class - white background, Arial 9pt, left-justified, mixed case, popup menu POP_MAIN, auto-hint | Not directly referenced in this form | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item property class - white background, Arial 9pt, red prompt foreground, mixed case; includes WHEN-VALIDATE-ITEM trigger that enforces non-null entry | Not directly referenced in this form | N/A |
| PC_UTEXT | PropertyClass | Upper-case text item property class - white background, Arial 9pt, upper case restriction, black prompt foreground | Not directly referenced in this form | N/A |
| PC_MUTEXT | PropertyClass | Mandatory upper-case text item property class - white background, Arial 9pt, red prompt foreground, upper case; includes WHEN-VALIDATE-ITEM trigger that enforces non-null entry | Not directly referenced in this form | N/A |
| PC_NUM | PropertyClass | Numeric text item property class - right-justified, white background, Arial 9pt, number data type, minimum value 0 | Not directly referenced in this form | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric text item property class - right-justified, white background, Arial 9pt, red prompt foreground, number data type; includes WHEN-VALIDATE-ITEM trigger that enforces non-zero numeric entry | Not directly referenced in this form | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class - iconic style, white background, no bevel, non-navigable, width 20, height 16 | Not directly referenced in this form | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class - scrollbar width 13 | Not directly referenced in this form | N/A |
| OG_GROUP | ObjectGroup | Standard object group - referenced from the DPL library (DPL_MTPL.fmb parent); carries the standard set of shared form objects for this application suite | 1 (form-level reference) | OG_GROUP |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| DEALER_DETAIL | Query | DEALER_DETAIL | LOC_CD | LOC_DESC | No | Lists active dealer locations authorised for the current user and principal for report scope selection | DEALER_DETAIL |

**Total Record Groups:** 1

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER_DETAIL | Dealer location master - stores location codes, descriptions, and principal mappings for each dealer outlet |
| `AM_USERS` | - | RG_DEALER_DETAIL | Application user master - stores user IDs, user types, and dealer assignments for access control |
| `DUAL` | - | Trigger WHEN-NEW-FORM-INSTANCE | Oracle pseudo-table used to perform a single-row SELECT at form startup, typically to retrieve session-level values or initialise form variables without referencing a real base table |
| `ED_REPORTS` | - | PR_PASS_PARAM | Report parameter configuration - defines report parameters (type, name, default, data type) for each application and principal |
| `EH_REPORTS` | - | Trigger KEY-CLRFRM, Trigger WHEN-NEW-FORM-INSTANCE | Report header configuration - stores the report server name per application and principal for routing report requests |

**Total Referenced Objects:** 5

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | STOP_WATCH.START_TIMER | Starts a performance timer when application logging is enabled at form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module identity against the database session at form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module name and action against the database session at form open |
| BR-002 | GENERAL.DISP_TEXT | Displays a user-facing error or informational alert during error handling |
| BR-002 | GENERAL.RAISE_ERROR | Looks up and displays a structured error message by code during error handling |
| BR-003 | GENERAL.DISP_TEXT | Displays a formatted validation message during message handling |
| BR-005 | GENERAL.DISP_TEXT | Displays the "Main Reason can not be empty" error when reason validation fails |
| BR-006 | PR_PASS_PARAM | Assembles the report parameter string from dealer, location, contract month, and principal values |
| BR-006 | WEB.SHOW_DOCUMENT | Opens the generated report PDF in a new browser tab after submission |
| BR-007 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Used within the KEY-EXIT trigger to clear session client info on form exit (also called at PRE-FORM) |
| BR-007 | DBMS_APPLICATION_INFO.SET_MODULE | Used within the KEY-EXIT trigger to clear session module info on form exit (also called at PRE-FORM) |
| BR-008 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session client information identifier on form exit |
| BR-008 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the session module name on form exit |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation dialog before discarding unsaved changes (FT_CANCEL) or committing a delete operation (FT_DEL) |
| - | GENERAL.DISP_TEXT | Notifies the user of insert-time validation or status conditions from the FT_INSERT trigger |
| - | L_POP_LIST_ITEM | Populates list items from named record groups during form initialisation and within the local L_POP_LIST_ITEM program unit |

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| L_POP_LIST_ITEM | Form Program Unit (PROCEDURE) | WHEN-NEW-FORM-INSTANCE trigger (Form); local program unit L_POP_LIST_ITEM | Wraps GENERAL.l_pop_list_item to populate list items from named record groups at form startup; applies a specified initial selection value to each list control |
| PR_PASS_PARAM | Form Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED trigger on CB_BLK.SUBMIT | Builds the report parameter string by reading the report parameter configuration from ED_REPORTS for the current application and principal, and appending dealer code, location code, contract month, and principal values |
| GENERAL.ASK_CONFIRM | External Package Routine (DPL library - GENERAL package) | Trigger: FT_CANCEL (Form); Trigger: FT_DEL (Form) | Displays a confirmation dialog presenting the supplied message and returns a numeric value indicating the user's choice; used to confirm discard of unsaved changes and to confirm delete operations before they are committed |
| GENERAL.DISP_TEXT | External Package Routine (DPL library - GENERAL package) | Trigger: ON-ERROR (Form); Trigger: ON-MESSAGE (Form); Trigger: WHEN-VALIDATE-ITEM on CB_BLK.P_REASON; Trigger: FT_INSERT (Form); GENERAL.RAISE_ERROR | Displays an alert dialog to the user; uses an error-type alert for severity "Error" and a note-type alert for other severities; used throughout the form for all user-facing error, validation, and informational messages |
| GENERAL.RAISE_ERROR | External Package Routine (DPL library - GENERAL package) | Trigger: ON-ERROR (Form) | Assembles a display message from an error code, determines the severity, and delegates to GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-severity messages; invoked specifically when DBMS error code -02292 (foreign-key constraint violation) is detected |
| GENERAL.l_pop_list_item | External Package Routine (DPL library - GENERAL package) | Form Program Unit: L_POP_LIST_ITEM; Trigger: WHEN-NEW-FORM-INSTANCE (Form) | Populates a list item from a named record group, applying the value supplied in p_select as the initially selected entry; called during WHEN-NEW-FORM-INSTANCE to initialise list items on form startup |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package Routine | Trigger: PRE-FORM (Form); Trigger: KEY-EXIT (Form) | Registers or clears the client identifier in the Oracle session monitoring tables; set to the module name at form open, cleared to null at form exit |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package Routine | Trigger: PRE-FORM (Form); Trigger: KEY-EXIT (Form) | Registers or clears the module name and action in the Oracle session monitoring tables; set to the module name at form open, cleared to empty strings at form exit |
| STOP_WATCH.START_TIMER | External Package Routine (STOP_WATCH package) | Trigger: PRE-FORM (Form) - conditional on application logging flag | Starts a performance measurement timer for the current session; invoked only when the application-level logging global flag is set to active |
| WEB.SHOW_DOCUMENT | Oracle Forms Web Built-in | Trigger: WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Opens a URL in a new browser window or tab using the target identifier '_blank'; used to display the generated PDF report from the printer output folder path after the report has been submitted to the server |

---

#### L_POP_LIST_ITEM

Form-level program unit. Wraps the DPL library routine GENERAL.l_pop_list_item to provide a reusable mechanism for populating list items from named record groups. Accepts a record group name and an initial selection value, then delegates to GENERAL.l_pop_list_item to apply the population and selection. Called directly from the WHEN-NEW-FORM-INSTANCE trigger to initialise all list controls on the form at startup, and referenced internally wherever multiple list controls require the same initialisation pattern.

---

#### PR_PASS_PARAM

Called from the WHEN-BUTTON-PRESSED trigger on the Submit button. Queries the ED_REPORTS table for all parameter definitions associated with the current application identity and the current user's principal mapping code, ordered by serial number. For each row returned, it appends the dealer code, location code, contract month, and principal values to the parameter string. The assembled parameter string is returned to the calling trigger for use in configuring the report object.

---

#### GENERAL.ASK_CONFIRM

Provided by the DPL attached library (GENERAL package). Accepts a confirmation message string and returns a numeric value representing the user's response. Displays a modal confirmation dialog to the user before a potentially destructive or irreversible action is taken. Called from the FT_CANCEL trigger to prompt the user before unsaved changes are discarded, and from the FT_DEL trigger to request explicit confirmation before a delete operation is committed to the database.

---

#### GENERAL.DISP_TEXT

Provided by the DPL attached library (GENERAL package). Accepts a message text and a severity title. Selects the appropriate alert template (error alert for "Error" severity, note alert for other severities), sets the alert title and message body, and displays the alert dialog. Used throughout the form for all user-facing error and informational messages, including ON-ERROR handling, ON-MESSAGE handling, reason-field validation in WHEN-VALIDATE-ITEM, and insert-time status notification from FT_INSERT.

---

#### GENERAL.RAISE_ERROR

Provided by the DPL attached library (GENERAL package). Accepts an error code string. Assembles the display text by concatenating the error code with a separator and any available message text (note: the message lookup function call is commented out in the current version, so the message text portion is empty). Evaluates the message type and routes to GENERAL.DISP_TEXT with the appropriate severity title; raises FORM_TRIGGER_FAILURE if the severity is an error type. Invoked specifically in the ON-ERROR trigger when DBMS error code -02292 (foreign-key constraint violation) is detected.

---

#### GENERAL.l_pop_list_item

Provided by the DPL attached library (GENERAL package). Accepts a record group name (p_rg_name) and an initial selection value (p_select). Populates the target list item from the named record group and applies the supplied value as the initially selected entry. Called during WHEN-NEW-FORM-INSTANCE to initialise list items on form startup, and invoked indirectly through the local L_POP_LIST_ITEM program unit wrapper.

---

#### DBMS_APPLICATION_INFO.SET_CLIENT_INFO

Oracle built-in package routine. Registers a client information string against the current database session, making it visible in Oracle session monitoring views. Called at form open (PRE-FORM) with the module name to identify the session, and at form exit (KEY-EXIT) with a null value to clear the identifier.

---

#### DBMS_APPLICATION_INFO.SET_MODULE

Oracle built-in package routine. Registers a module name and action name against the current database session. Called at form open (PRE-FORM) with the module name set to the form's application identifier and action set to empty, and at form exit (KEY-EXIT) with both module name and action set to empty strings to clear the session record.

---

#### STOP_WATCH.START_TIMER

Provided by the STOP_WATCH attached package. Starts a performance measurement timer for the current session. Invoked conditionally in the PRE-FORM trigger when the application logging global flag is set to active.

---

#### WEB.SHOW_DOCUMENT

Oracle Forms built-in web package routine. Opens the specified URL in a new browser window or tab using the target identifier '_blank'. Used in the WHEN-BUTTON-PRESSED trigger to display the generated PDF report from the printer output folder path after the report has been submitted to the server.

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/8ae3a5aa-c1a6-4e07-a7ab-e2dd4e12815c/inputs/form_sources`. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the input form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays a confirmation dialog presenting the supplied message and returns a numeric value indicating the user's choice. Called in FT_CANCEL to prompt the user before discarding unsaved changes, and in FT_DEL to request explicit confirmation before a delete operation is committed. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REASON | Displays a user-facing alert dialog with the supplied message text and title. When `title_string` is 'ERROR', uses the AL_ERRINFO alert style; otherwise uses AL_NOTE. Called in ON-ERROR to surface validation, date-format, and concurrent-update messages; called in ON-MESSAGE to display Forms error details; called in WHEN-VALIDATE-ITEM to report that the Reason field is empty; called in FT_INSERT to notify the user of insert-time validation or status conditions. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a list item from a named record group, applying the value supplied in `p_select` as the initially selected entry. Called during WHEN-NEW-FORM-INSTANCE to initialise list items on form startup, and referenced within the local program unit L_POP_LIST_ITEM which wraps this call for reuse across multiple list controls. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Accepts a message code, prepends it to the resolved message text, and displays it via DISP_TEXT with a severity-appropriate title (Error / Note / Caution). Raises FORM_TRIGGER_FAILURE for error-type messages. Called in ON-ERROR when DBMS error code -02292 is detected (foreign-key constraint violation). |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in `vr_extn_warr_comm_fmb.xml`.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Called only within the fully block-commented body of VALIDATE_CN_MAIN. Previously validated that mandatory fields (plate number, model year, test drive date/time, location, sales consultant, odometer readings) were not null; raised an error with the field label if empty. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### D2kwutil.pld (`Win_API`)

*No routines from `D2kwutil.pld` are referenced in `vr_extn_warr_comm_fmb.xml`.*

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Report Parameter Configuration Service | ED_REPORTS | Application identity, principal mapping code | List of report parameter definitions (param_type, parameter_name, default_value, parameter_datatype) ordered by serial number | Retrieves the configured parameter definitions for a given application and principal, enabling the caller to assemble the correct parameter string for report submission | GET /api/v1/report-parameters?appId={appId}&principalMapCd={principalMapCd} |
| MS-002 | Report Server Configuration Service | EH_REPORTS | Application identity, principal mapping code | Report server address (falls back to session default if not configured) | Resolves the report server address configured for a given application and principal; used to route report submissions to the correct server | GET /api/v1/report-server-config?appId={appId}&principalMapCd={principalMapCd} |
| MS-003 | Dealer Location Lookup Service | AM_DEALER_LOC, AM_USERS, AM_USER_DEALER_MASTER | User ID, principal mapping code | List of authorised dealer locations (location code, description, parent group, dealer map code, dealer name) | Returns the set of dealer locations accessible to the current user for the given principal, filtered to active locations only; used to populate the dealer selection lookup on the report parameters screen | GET /api/v1/dealer-locations?userId={userId}&principalMapCd={principalMapCd} |
| MS-004 | Report Submission Service | REPORT_CALL (rep.rdf) | Application identity, dealer code, location code, contract month, principal mapping code, output format | Report file URL / job status | Assembles the report parameter string, configures the reporting engine (output format PDF, destination file, bitmap mode, no blank pages), runs the report against the configured report server, and returns a link to the generated output file | POST /api/v1/reports/warranty-commission/submit |
| MS-005 | Application Error Message Service | GENERAL package (DPL library) | Error code | Message text, message type (Error / Note / Caution) | Looks up the business error message and severity for a given error code; used by error-handling logic to display structured messages to the user (note: message lookup is currently inactive in the form version - the code is present but the lookup call is commented out) | GET /api/v1/error-messages/{errorCode} |

**Total Microservices Identified: 5**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialization | User opens the form (PRE-FORM trigger fires) | 1. Check if application logging is enabled; 2. Start performance timer if logging is active; 3. Register module identity and client information in the database session monitoring framework | Is application-level logging active? Yes -> start timer; No -> skip timer | Form is open and session is registered for monitoring |
| WF-002 | Report Parameter Submission | User clicks the Submit Report button (WHEN-BUTTON-PRESSED trigger fires on Submit button) | 1. Set application identity and report name; 2. Assemble report parameter string (PR_PASS_PARAM - reads ED_REPORTS for dealer, location, contract month, and principal values); 3. Locate the report object; 4. Set output format to PDF and destination to file; 5. Generate unique file name from user login and submission timestamp; 6. Store parameter string in file name field; 7. Set report file name, parameters, and server address; 8. Set output file path; 9. Run report on server; 10. Open generated PDF in a new browser tab | Any error during report run? Yes -> silently absorb exception, no message shown | Report PDF displayed in a new browser tab, or silent failure if an error occurs |
| WF-003 | Output Format Change | User selects or changes the output format list value (WHEN-LIST-CHANGED on Format field fires) | 1. Evaluate the selected format; 2. If not spreadsheet format: clear file name field, disable file name field; 3. If spreadsheet format: enable file name field, make it navigable | Is the selected format the spreadsheet format? Yes -> enable file name field; No -> clear and disable file name field | File name field is either enabled (spreadsheet) or cleared and disabled (all other formats) |
| WF-004 | File Name Field Activation on Focus | User navigates to the file name field (WHEN-NEW-ITEM-INSTANCE fires on File Name field) | 1. Check the currently selected output format; 2. If spreadsheet format: set field to allow insert and update; 3. If not spreadsheet format: disable both insert and update on the field | Is the current format the spreadsheet format? Yes -> allow edit; No -> disable edit | File name field is editable (spreadsheet) or read-only (all other formats) |
| WF-005 | Reason Validation | User moves away from the Reason field (WHEN-VALIDATE-ITEM fires on Reason field) | 1. Check whether the Reason field has a value; 2. If empty: display *"Main Reason can not be empty"* error alert via GENERAL.DISP_TEXT, raise trigger failure to block navigation | Is the Reason field empty? Yes -> show error and block; No -> allow navigation | User remains on the Reason field (validation failed) or moves to the next field (validation passed) |
| WF-006 | Form Error Handling | Any system error is raised within the form (ON-ERROR trigger fires) | 1. Capture error code, error text, DB error code; 2. Check for invalid date (50004) -> show message, abort; 3. Check for date format error (50025/50026) -> show message, abort; 4. Check for non-numeric entry (40209/50016) -> show message, abort; 5. Check for general field validation (40207) -> show field error text, abort; 6. Check for child record integrity violation (-02292) -> raise structured error E0088; 7. Check for concurrent update conflict (40654-40659) -> rollback, show message, abort; 8. Check for general DB error (sqlcode ≠ 0) -> rollback, show DB error, abort; 9. Check for navigation boundary (40401/40405) -> suppress silently | Which error code is present? Branches to the matching condition; unmatched codes that have sqlcode ≠ 0 fall through to the general DB error handler; 40401/40405 are suppressed | Current operation cancelled and user remains on form (most branches); or error suppressed silently (navigation boundary codes) |
| WF-007 | Form Message Handling | A system message is raised within the form (ON-MESSAGE trigger fires) | 1. Capture message code and text; 2. If code is 40209 or 40207: compose formatted message, display as error alert via GENERAL.DISP_TEXT, raise trigger failure; 3. For all other codes: no action | Is the message code 40209 or 40207? Yes -> display formatted error; No -> no action | Current operation cancelled and user remains on form (intercepted codes), or standard message processing continues (other codes) |
| WF-008 | Form Reset | User triggers the clear-form action (KEY-CLRFRM trigger fires) | 1. Clear all form fields without save prompt; 2. Restore report description, report name, and application identity from session context; 3. Query EH_REPORTS for the report server address for the current application and principal; 4. Apply the configured server address, or fall back to the session default on any database error | Does EH_REPORTS contain a unique row for this application and principal? Yes -> use configured server address; No data / too many rows / any other error -> fall back to session default | Form is reset to a clean state with session values restored and the correct report server address resolved |
| WF-009 | Form Exit | User triggers the exit action (KEY-EXIT trigger fires) | 1. Clear the client information from the database session monitoring record (set to null); 2. Clear the module name from the database session monitoring record (set to empty); 3. Close the form immediately without save prompt | None | Form is closed and session monitoring records are cleared |

**Total Workflows Identified: 9**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a mandatory field value is null, then navigation is blocked and an error message is displayed |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REASON | /api/v1/pld/disp_text | When an error or informational message must be shown, then an alert dialog is displayed with the supplied text and title |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a message code is received, then the corresponding error or caution message is displayed and form execution is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_extn_warr_comm_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_extn_warr_comm_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Report Parameter Configuration (ED_REPORTS) | Direct SQL - SELECT | Reads the report parameter definitions (param_type, parameter_name, default_value, parameter_datatype) for the current application identity and principal mapping code; used to assemble the report parameter string at submission time | Form -> ED_REPORTS (read only) | No explicit error handling in the PR_PASS_PARAM procedure; if no rows are returned the parameter string remains empty and the report is submitted without filter parameters |
| Report Server Configuration (EH_REPORTS) | Direct SQL - SELECT | Reads the report server address configured for the current application identity and principal mapping code; used to resolve the correct server address after a form reset | Form -> EH_REPORTS (read only) | NO_DATA_FOUND, TOO_MANY_ROWS, and WHEN OTHERS all handled explicitly: in all three cases the form falls back to the default report server address from the session context without notifying the user |
| Dealer Location Master (AM_DEALER_LOC, AM_USERS, AM_USER_DEALER_MASTER) | Record Group Query - SELECT | Provides the list of dealer locations authorised for the current user and principal, used to populate the dealer selection lookup | Form -> AM_DEALER_LOC / AM_USERS / AM_USER_DEALER_MASTER (read only, via DEALER_DETAIL record group) | Standard Oracle Forms record group error handling; if the query returns no rows the LOV is empty |

### 20.2 External System Integrations

The form has no external system integrations beyond the Oracle Reports server and the Oracle database. No CALL_FORM, OPEN_FORM (other than the dealer LOV show), HOST commands, or external file references are present in the form. No external messaging or API calls are made.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Database Session Monitoring (DBMS_APPLICATION_INFO) | Oracle Built-in Package Call | Registers and clears the module identity and client information in the Oracle session monitoring views (V$SESSION) for audit and support traceability | In-process Oracle Forms built-in | N/A - in-database call | Module name and client info string written at form open; cleared to empty/null at form exit | No error handling; failures are silent |
| Oracle Application Performance Logger (STOP_WATCH) | Attached Library Call | Starts a performance timer for the current session when application-level logging is enabled | In-process attached PLL library call | N/A - in-process | Timer start signal sent to the STOP_WATCH package | Conditional on global logging flag; no explicit error handling |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Configured report server address resolved from EH_REPORTS (or session default); set via REPORT_SERVER property at runtime | P_DEALER, P_LOC, P_CONTRACT_MONTH, P_PRINCIPAL (assembled by PR_PASS_PARAM from ED_REPORTS configuration); MODE=BITMAP, BLANKPAGES=NO, parform=yes prepended at submission | PDF (fixed; output destination set to FILE; destination file path set to /iashome/ias/reports/printer/[userid][YYYYMMDDHHMISS].pdf) | WHEN-BUTTON-PRESSED on Submit button (CB_BLK.SUBMIT) - user-initiated |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_EXTN_WARR_COMM form.

### 21.1 Catalogue Index

5 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--L_POP_LIST_ITEM) | L_POP_LIST_ITEM |
| [SP-002](#SP-002--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-003](#SP-003--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-004](#SP-004--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-005](#SP-005--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |

---

### 21.2 Detailed Specifications

#### SP-001 - L_POP_LIST_ITEM

**Invoked From:**

- vr_extn_warr_comm_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

L_POP_LIST_ITEM is a reusable procedure that dynamically populates a named Oracle Forms record group from a caller-supplied SQL query. It is invoked during form initialisation (WHEN-NEW-FORM-INSTANCE) to load the data required to populate list items before the user interacts with the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters, and assign the name to a local variable rg_name.
- Step 2 - Attempt to locate an existing record group with the given name using Find_Group, storing the result in rg_id.
- Step 3 - Evaluate whether a record group with that name already exists (i.e., rg_id is not null).
- Step 4 - If the record group already exists, delete it using delete_group so that a fresh group can be created from the current query.
- Step 5 - If the record group does not exist, create a new record group from the supplied SQL query using Create_Group_From_Query, assigning the resulting group ID to rg_id.
- Step 6 - Populate the record group (whether newly created or recreated) by executing the SQL query via Populate_Group, storing the return code in errcode.

---
**Decision Points**

DP-001

Condition: The record group identified by p_rg_name already exists in the current form session (Id_Null(rg_id) evaluates to FALSE).

TRUE: The existing record group is deleted via delete_group, and execution continues to Step 6 where Populate_Group is called against the now-deleted group reference. (Note: in practice the group must be recreated before population; the logic deletes the stale group to avoid duplication.)

FALSE: A new record group is created from the supplied SQL query using Create_Group_From_Query, and the resulting rg_id is used in the subsequent Populate_Group call.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The record group name passed in p_rg_name must be unique within the form session; if a group with that name already exists it is deleted before repopulation to prevent duplicate group errors.
- BR-002 - The SQL query supplied via p_select must be a valid SELECT statement compatible with Create_Group_From_Query; the procedure does not validate or transform the query string before use.
- BR-003 - The procedure is generic and reusable; it does not reference any specific list item or block, making it applicable to any list item population requirement within the invoking form.
- BR-004 - The procedure does not raise or handle exceptions arising from Populate_Group; the numeric return code is captured in errcode but no error-handling branch is implemented, placing responsibility for error checking on the calling context.

---
**Implementation Logic**

```plsql
-- Commented by sanjeev on 14/4/04 for the prototype.

/* 
A common procedure to dynamically retrieve the values from the respective table b4 displaying them in the list items
*/

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	ELSE
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	END IF; 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-002 - PR_PASS_PARAM

**Invoked From:**

- vr_extn_warr_comm_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Builds a concatenated parameter string for report execution by appending key filter values - dealer, location, contract month, and principal - to the IN OUT parameter `Lv_param`. The parameter set is driven by report configuration rows retrieved from `ED_REPORTS` for the current application and principal context, and the resulting string is passed back to the calling trigger (`WHEN-BUTTON-PRESSED` in `vr_extn_warr_comm_fmb.xml`) for use in report invocation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open cursor `c1` to query `ED_REPORTS`, filtering rows by the current application identifier (`:CB_BLK.APP_ID`) and the current principal (`:GLOBAL.PRINCIPAL`), ordered by `serial_no` ascending.
- Step 2 - For each row returned by cursor `c1`, append the dealer parameter token (`P_DEALER='{:P_DEALER}'`) to `Lv_param`.
- Step 3 - For each row, append the location parameter token (`P_LOC='{:P_LOC}'`) to `Lv_param`.
- Step 4 - For each row, append the contract month parameter token (`P_CONTRACT_MONTH='{:P_CONTRACT_MONTH}'`) to `Lv_param`.
- Step 5 - For each row, append the principal parameter token (`P_PRINCIPAL='{:GLOBAL.PRINCIPAL}'`) to `Lv_param`.
- Step 6 - After the loop completes, assign `Lv_param` to itself (no further transformation) and return the fully constructed parameter string to the caller via the IN OUT parameter.

---
**Decision Points**

DP-001

Condition:
Cursor `c1` returns one or more rows from `ED_REPORTS` for the combination of `:CB_BLK.APP_ID` and `:GLOBAL.PRINCIPAL`.

TRUE:
The loop body executes for each matching row, appending the four parameter tokens (P_DEALER, P_LOC, P_CONTRACT_MONTH, P_PRINCIPAL) to `Lv_param` on every iteration.

FALSE:
The loop body is never entered; `Lv_param` retains whatever value was passed in by the caller and is returned unchanged.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - Report parameters must be scoped to the active application; only `ED_REPORTS` rows matching `:CB_BLK.APP_ID` are eligible for parameter generation.
- BR-002 - Report parameters must be further scoped to the active principal; only `ED_REPORTS` rows matching `:GLOBAL.PRINCIPAL` are eligible, ensuring cross-principal data isolation.
- BR-003 - Parameter tokens are appended in `serial_no` ascending order, preserving the report-defined sequence of parameters.
- BR-004 - All four business filter values - dealer (`P_DEALER`), location (`P_LOC`), contract month (`P_CONTRACT_MONTH`), and principal (`P_PRINCIPAL`) - must be included in the parameter string for every qualifying `ED_REPORTS` row; none may be omitted.
- BR-005 - Each parameter value is enclosed in single quotes within the concatenated string, conforming to the expected format of the downstream report execution engine.

---
**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM (Lv_param IN OUT VARCHAR2)
IS
cursor c1 is select param_type,parameter_name,default_value,parameter_datatype
	           from   ed_reports
						 where  app_id =:CB_BLK.APP_ID 
						 and principal_map_cd=:global.principal /*added by bhawana*/
						 order by to_number(serial_no);
Lv_frm_date DATE;
Lv_to_date DATE;	
L_AlertID						ALERT;
L_Alert							NUMBER;	
BEGIN
For cur_val in c1 Loop
	--lv_param:=lv_param||' '||'''P_DEALER='''||:P_DEALER||''' P_LOC='''||:P_LOC||'''P_CONTRACT_MONTH='''||:CONTRACT_MONTH||'''';
	lv_param := lv_param||' '||'P_DEALER='''||:P_DEALER||'''';
	lv_param := lv_param||' '||'P_LOC='''||:P_LOC||'''';
	lv_param := lv_param||' '||'P_CONTRACT_MONTH='''||:P_CONTRACT_MONTH||'''';
	lv_param := lv_param||' '||'P_PRINCIPAL='''||:GLOBAL.PRINCIPAL||''''	;/*ADDED BY BHAWANA*/
End Loop;	
lv_param:=lv_param;
--MESSAGE(lv_param) ;MESSAGE(' ');
END;
```

#### SP-003 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_extn_warr_comm_fmb.xml [Trigger: FT_CANCEL]
- vr_extn_warr_comm_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function is used by cancel and delete triggers to obtain explicit user confirmation before proceeding with a destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value supplied in confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed against the constant ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (affirmative confirmation), or return 0 for any other button press (non-confirmation).

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the user selected the affirmative/confirm button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the calling trigger (FT_CANCEL or FT_DEL) that the user has confirmed the action.

FALSE:
The function returns 0, signalling to the calling trigger that the user declined or dismissed the confirmation prompt.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert displayed must always be AL_CONFIRM; no other alert name is used by this function.
- BR-002 - The alert message text is dynamic and must be supplied by the caller via confirm_msg; the function does not define a default or fallback message.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button press yields a return value of 0, treating all non-affirmative responses as rejection.
- BR-004 - The function must be invoked prior to executing any cancel or delete operation (as enforced by triggers FT_CANCEL and FT_DEL) to ensure user intent is captured before a potentially destructive action is performed.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-004 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_extn_warr_comm_fmb.xml [Trigger: FT_INSERT]
- vr_extn_warr_comm_fmb.xml [Trigger: ON-ERROR]
- vr_extn_warr_comm_fmb.xml [Trigger: ON-MESSAGE]
- vr_extn_warr_comm_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate pre-defined Oracle Forms alert component ('AL_ERRINFO' for error conditions, 'AL_NOTE' for all other notifications), sets its title and message text dynamically, and presents it to the user. It is used across form triggers and the GENERAL.RAISE_ERROR stored procedure as the standard mechanism for surfacing both error and informational messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value: if it equals 'ERROR' (case-insensitive), assign the alert name 'AL_ERRINFO'; otherwise assign 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert component to title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert component to text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT, capturing the user's response in p_alert_id (return value is not further evaluated).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert component 'AL_ERRINFO' is selected, indicating an error-severity dialog should be presented to the user.

FALSE:
The alert component 'AL_NOTE' is selected, indicating a standard informational or warning dialog should be presented to the user.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title_string value 'ERROR' (matched case-insensitively) is the sole criterion that distinguishes an error alert ('AL_ERRINFO') from a general notification alert ('AL_NOTE'); all non-error titles route to 'AL_NOTE'.
- BR-002 - Both the alert title and the alert message text must be set dynamically at runtime from the supplied parameters before the alert is shown; hard-coded alert design-time properties are overridden on every invocation.
- BR-003 - The procedure does not evaluate or act upon the user's alert response (p_alert_id is captured but unused), meaning the dialog is purely informational and no branching logic depends on the button the user clicks.
- BR-004 - GENERAL.DISP_TEXT is the standard, centralised display routine for all user-facing messages within the application; callers must supply both a message body and a title to ensure correct alert selection and presentation.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-005 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_extn_warr_comm_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms triggers. Given a message code, the procedure constructs a display-ready message string and presents it to the user via GENERAL.DISP_TEXT with an appropriate title ('Error', 'Note', or 'Caution'). When the message type indicates a hard error, the procedure additionally raises FORM_TRIGGER_FAILURE to halt further form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Concatenate mesg_code with the resolved message text to form the full display string in the format '<code> : <text>' and store it in mesg_text.
- Step 3 - Evaluate mesg_type to determine the severity category of the message (Error / Note / Caution).
- Step 4 - If mesg_type is 'E', set mesg_title to 'Error', call GENERAL.DISP_TEXT to display the message, then raise FORM_TRIGGER_FAILURE to abort the triggering form action.
- Step 5 - If mesg_type is 'N', set mesg_title to 'Note' and call GENERAL.DISP_TEXT to display the message; processing continues normally after display.
- Step 6 - If mesg_type is 'C', set mesg_title to 'Caution' and call GENERAL.DISP_TEXT to display the message; processing continues normally after display.
- Step 7 - If mesg_type does not match any handled value ('E', 'N', or 'C'), no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E' (message severity is Error)

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with mesg_text and mesg_title to present the error dialog, then raise FORM_TRIGGER_FAILURE to halt the current form trigger execution.

FALSE:
Proceed to evaluate whether mesg_type is 'N' (DP-002).

---

DP-002

Condition:
mesg_type = 'N' (message severity is Note)

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with mesg_text and mesg_title to present the informational dialog; form processing continues.

FALSE:
Proceed to evaluate whether mesg_type is 'C' (DP-003).

---

DP-003

Condition:
mesg_type = 'C' (message severity is Caution)

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with mesg_text and mesg_title to present the caution dialog; form processing continues.

FALSE:
No matching severity type; the procedure exits without displaying any message or raising an exception.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The full message presented to the user must be composed by concatenating the message code and the resolved message text in the format '<mesg_code> : <mesg_text>', ensuring the originating code is always visible alongside the descriptive text.
- BR-002 - A message classified as type 'E' (Error) is treated as a blocking condition; the procedure must raise FORM_TRIGGER_FAILURE after displaying the error dialog to prevent the form trigger from completing successfully.
- BR-003 - A message classified as type 'N' (Note) or 'C' (Caution) is treated as non-blocking; the procedure displays the message via GENERAL.DISP_TEXT but must not raise FORM_TRIGGER_FAILURE, allowing form processing to continue.
- BR-004 - All user-facing message dialogs must be rendered exclusively through GENERAL.DISP_TEXT (SP-004); direct use of Oracle Forms built-in alert mechanisms is not permitted within this procedure.
- BR-005 - If mesg_type does not match any recognised severity value ('E', 'N', or 'C'), the procedure takes no action, ensuring unrecognised or uninitialised message types do not cause unintended interruptions to form processing.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

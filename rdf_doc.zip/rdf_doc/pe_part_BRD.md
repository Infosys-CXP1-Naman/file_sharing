# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Part Stock - PM_STOCK (via B_PM_STOCK)
    - Parts Master - PM_PART
    - Dealer Location - AM_DEALER_LOC
    - Store Master - GM_STORE
    - Part MRP Pricing - PI_PM_PART_MRP
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Filters (User - before stock search)
    - Session / Globals (System - form context)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - PM_PART (29 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL (Package - DPL attached library)
    - PK_PART_SEARCH_NEW (Database package - PK_PART_SEARCH_NEW.pck)
    - POPULATE_DETAILS (Form-level program unit)
    - L_POP_LIST_ITEM (Form-level program unit - wrapper)
    - VIEW_EXCEL_REPORT_NEW (Form-level or standalone program unit)
    - Standalone Database Functions and Procedures
    - WEBUTIL_CORE (Package - webutil.pld attached library)
    - WEBUTIL_C_API (Package - webutil.pld attached library)
    - WEBUTIL - Inactive / Commented-Only Routines (webutil.pld)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - POPULATE_DETAILS
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.CHOOSEFILE
    - SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-009 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-011 - D2KWUTIL.SAVE_FILE
    - SP-012 - D2KWUTIL.TRANSLATETYPE
    - SP-013 - GENERAL.CHECK_NULL
    - SP-014 - GENERAL.DISP_TEXT
    - SP-015 - GENERAL.L_POP_LIST_ITEM
    - SP-016 - GENERAL.RAISE_ERROR
    - SP-017 - PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW
    - SP-018 - PK_PART_SEARCH_NEW.PART_DETAILS
    - SP-019 - PK_PART_SEARCH_NEW.ROWCOUNT_NEW
    - SP-020 - WEBUTIL.BLOCKING
    - SP-021 - WEBUTIL.CHECKLIBS
    - SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-023 - WEBUTIL.CLOSEBLOB
    - SP-024 - WEBUTIL.CLOSEFILE
    - SP-025 - WEBUTIL.DOWNLOADFROMURL
    - SP-026 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-027 - WEBUTIL.ERROR
    - SP-028 - WEBUTIL.ERRORALERT
    - SP-029 - WEBUTIL.EXECUTE
    - SP-030 - WEBUTIL.FCLOSE
    - SP-031 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-032 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-033 - WEBUTIL.FOPEN
    - SP-034 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-035 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-036 - WEBUTIL.GETCLIENTSETTING
    - SP-037 - WEBUTIL.GETIMPLCLASS
    - SP-038 - WEBUTIL.GETLASTERROR
    - SP-039 - WEBUTIL.GETLASTERRORARGS
    - SP-040 - WEBUTIL.GETNUMBER
    - SP-041 - WEBUTIL.GETOSFAMILY
    - SP-042 - WEBUTIL.GETOUTPUT
    - SP-043 - WEBUTIL.GETPROPERTY
    - SP-044 - WEBUTIL.GETSTRING
    - SP-045 - WEBUTIL.GETVAR
    - SP-046 - WEBUTIL.GET_LINE
    - SP-047 - WEBUTIL.GET_RETURN_CODE
    - SP-048 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-049 - WEBUTIL.HOST
    - SP-050 - WEBUTIL.ID_NULL
    - SP-051 - WEBUTIL.INIT
    - SP-052 - WEBUTIL.INITWEBUTIL
    - SP-053 - WEBUTIL.ISERROR
    - SP-054 - WEBUTIL.IS_OPEN
    - SP-055 - WEBUTIL.LENGTH
    - SP-056 - WEBUTIL.LOG
    - SP-057 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-058 - WEBUTIL.PUTF
    - SP-059 - WEBUTIL.PUT_LINE
    - SP-060 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-061 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-062 - WEBUTIL.REGISTERBEAN
    - SP-063 - WEBUTIL.REGISTER_FUNCTION
    - SP-064 - WEBUTIL.RELEASE_PROCESS
    - SP-065 - WEBUTIL.SETCLIENTSETTING
    - SP-066 - WEBUTIL.SETDATA
    - SP-067 - WEBUTIL.SETPROPERTY
    - SP-068 - WEBUTIL.SHOWBEANS
    - SP-069 - WEBUTIL.URL_TO_CLIENT
    - SP-070 - WEBUTIL.WRITEDATA
    - SP-071 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-072 - ADD_ERROR
    - SP-073 - ADD_EXTERNAL_ERRORS
    - SP-074 - BOOLTOCHAR
    - SP-075 - CLEAN_ERROR_STACK
    - SP-076 - DEBUGLOG
    - SP-077 - GET_ENVIRONMENT_STRING
    - SP-078 - GET_TEMP_DIRECTORY
    - SP-079 - GET_WINDOWS_DIRECTORY
    - SP-080 - READ_REGISTRY
    - SP-081 - REGISTER_FUNCTION_CALL
    - SP-082 - SETDEBUG
    - SP-083 - SF_GET_PRICE
    - SP-084 - SF_GET_STORE_BIN_LOC
    - SP-085 - SF_GET_STORE_NAME
    - SP-086 - SP_GET_PART_SELL_PRICE_ONE
    - SP-087 - SP_GET_STORES_STOCK
    - SP-088 - STRIPDIRSEP
    - SP-089 - VIEW_EXCEL_REPORT_NEW
    - SP-090 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PE_LOC_STOCK - Business Requirements Document |
| Form Module Name | PE_LOC_STOCK |
| Document Version | 1.0 |
| Date Created | August 20, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 20, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pe_loc_stock Location Stock Enquiry form, its purpose, and roles referenced in the module.*

The **pe_loc_stock** Oracle Forms module is the **Location Stock Enquiry** screen. A Parts User opens the screen, enters a root part number (and optionally a specific part number, dealer, or branch location), and requests the current stock position. The form presents a multi-row results grid showing - for each dealer, branch location, and store combination - the available stock, float stock, allocated quantity, and the manufacturer's retail price for every part number that belongs to the entered root part. The user can toggle a checkbox to restrict results to stores that carry stock greater than zero. The screen is read-only; no new stock records are created or modified through this form. The form serves as a rapid stock-availability reference used to identify which outlets carry a given part before raising a replenishment request or directing a customer enquiry.

### Key Stakeholders

*Who uses pe_loc_stock*

| Stakeholder | Role |
| :--- | :--- |
| **Parts User** | **Primary interactive user** of pe_loc_stock. Enters part and dealer search criteria, reviews the stock position grid, and applies the stock-greater-than-zero filter to narrow results. |
| **Parts Manager** | Oversees parts availability across dealer locations; uses enquiry results to support replenishment decisions and customer service responses. |

---

---

## 3. System Context

*Describes the pe_loc_stock module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pe_loc_stock** module is the **Location Stock Enquiry** screen within the Dealer Management System (DMS). It provides a real-time, read-only view of parts stock positions across all dealer locations and stores belonging to the current parent group. The screen connects directly with the parts master and stock tables to deliver a consolidated inventory snapshot that supports replenishment decisions, customer enquiries, and inter-dealer stock transfers.

**System purpose:** Enable a Parts User to search for a root part number across all applicable dealer locations and stores and view the resulting stock breakdown - current quantity, float stock, allocated quantity, and MRP - within a single read-only enquiry screen, as implemented in the pe_loc_stock Oracle Forms module.

**In scope:**

- Search for stock by root part number, optionally filtered by part number, dealer, and branch location
- Select a dealer and location from a system-populated list of values scoped to the current parent group
- Filter the results grid to show only stores with stock greater than zero using the Stock > 0 checkbox
- Display multi-row stock results per dealer, location, and store showing current stock, float stock, allocated quantity, and MRP
- Display part description and root part number for each result row
- Show totals for current stock, float stock, and allocated quantity across all displayed rows
- Clear the search criteria and results, ready for a new enquiry
- Display an application copyright notice

**Process Name:** Location Stock Enquiry

**Process Owner:** Parts Manager

**Process Objective:** Open the location stock screen, enter a root part number and optional filters, retrieve the stock position across all applicable dealer locations and stores, review the results, and optionally re-filter to narrow the display to in-stock locations only.

**Process Trigger:** Parts User needs to determine which dealer locations and stores carry a specific part in order to fulfil a customer requirement or raise a replenishment request

**Process Flow:**

The complete location stock enquiry process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Parts User opens the Location Stock Enquiry screen.
         The form clears and the copyright notice is loaded.
         The search fields are empty and the stock results grid is blank.

STEP 2 ── DEALER SELECTION (OPTIONAL)
         User selects a dealer from the Dealer Name list of values.
         The list shows all dealers for the current parent group and principal.
         The selected dealer name, dealer code, and primary location code are populated.

STEP 3 ── LOCATION FILTER (OPTIONAL)
         User selects or enters a branch location code.
         The Location dropdown is dynamically refreshed to show only locations
         belonging to the selected dealer (or all locations if no dealer is selected).

STEP 4 ── PART NUMBER ENTRY (OPTIONAL)
         User enters a specific part number in the Part Number field.
         When the user advances, the system looks up the root part number
         from the parts master and auto-populates the Root Part Number field.

STEP 5 ── ROOT PART NUMBER ENTRY (MANDATORY)
         User enters or confirms the root part number.
         The root part number is required before the stock search can proceed.
         If the field is blank when the search is triggered, an error is shown and
         the cursor returns to the Root Part Number field.

STEP 6 ── STOCK FILTER SELECTION (OPTIONAL)
         User ticks the "Stock > 0" checkbox to restrict results to stores
         with available stock; leaving it unticked returns all stores regardless of
         stock level.

STEP 7 ── STOCK SEARCH INITIATED
         User navigates to the stock results block (or triggers the block instance).
         The form validates that part number or root part number is entered;
         if neither is present, an error message is displayed and the cursor
         returns to the Part Number field.

STEP 8 ── DEALER-LOCATION ITERATION
         The form iterates over dealer-location combinations from the dealer
         location master matching the current parent group and principal.
         ├── ALL DEALERS: When no dealer filter is set, all dealer-location
         │                combinations in the group are included.
         ├── DEALER FILTER: When a dealer is selected, only that dealer's
         │                  locations are included.
         ├── LOCATION FILTER: When a location code is set, only that location
         │                    is included regardless of dealer selection.
         └── BOTH FILTERS: Only the specific dealer-location combination is used.

STEP 9 ── STOCK DETAILS POPULATED PER DEALER-LOCATION
         For each dealer-location combination, stock records are retrieved from the
         parts stock table for all child parts under the root part number.
         Each row in the results grid is populated with:
           dealer map code, dealer name, location code, location description,
           store code, store description, part number, part description,
           current stock, float stock, allocated quantity, and MRP.

STEP 10 ── STOCK FILTER APPLIED
          ├── STOCK > 0: When the checkbox is ticked, only rows where net available
          │              stock is greater than zero are shown.
          └── ALL STOCK: When the checkbox is unticked, all rows are shown including
                         zero-stock stores.

STEP 11 ── RESULTS DISPLAYED
          The stock results grid shows up to 15 rows at a time with a scrollbar.
          Column totals for current stock, float stock, and allocated quantity are
          displayed at the bottom of the grid.

STEP 12 ── REVIEW AND REFINE
          User reviews the stock breakdown across dealers, locations, and stores.
          ├── CHANGE FILTER: User may toggle the Stock > 0 checkbox; the grid
          │                  is automatically refreshed with the new filter.
          └── NEW SEARCH: User presses the Clear Form key to reset all fields
                          and start a fresh enquiry.

STEP 13 ── CLEAR FORM
          User clears the form; search criteria and results are reset.
          The copyright notice is reloaded. No data is committed or changed.
```

**Major process interactions:**

- **Dealer and location master (AM_DEALER_LOC)** - supplies the list of dealers and branch locations available for selection and iteration within the current parent group and principal
- **Parts master (PM_PART)** - resolves part numbers to root part numbers and provides part descriptions for each result row
- **Parts stock table (PM_STOCK)** - primary data source for current stock, float stock, allocated quantity, and store details across dealer-location-store combinations
- **Parts MRP pricing (pi_pm_part_mrp)** - provides the latest manufacturer retail price batch for each part displayed in the results grid
- **DPL shared library** - supplies alert dialogs, null-value validation, dynamic list population, form-failure checking, and error handling utilities used throughout the screen

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form-Level Error Display and Message Interception

**Business Description:**
Whenever the application encounters an internal error or an informational message during user interaction, the system intercepts that event and presents a meaningful, human-readable description to the user instead of the raw system code. Specific categories of error - such as invalid date entry, numeric-only fields receiving text, record conflicts from concurrent users, and database constraint violations - are detected and handled with targeted guidance. Messages that the system would normally suppress or display in a generic way are redirected through a consistent error presentation channel so that users always see plain, actionable error text.

**Actors:** Parts Enquiry User (any user interacting with the form)

**Preconditions:**
- The form is open and the user is actively interacting with it.

**Main Flow:**

**Step 1 - All form errors are intercepted and a formatted error description is displayed**
Each time an error condition arises, the system first displays a combined label showing the error type, error number, and the error text so the user sees a complete description of what went wrong.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents a formatted text message to the user in a standard error dialog. It receives the message text and severity level and displays the message so the user sees it clearly.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error type, number, and text are composed and displayed | Display of error type, number, and text - GENERAL.DISP_TEXT [SP-004] | On every error event raised during form interaction | Ensures the user always receives a clearly formatted description of any error rather than a raw system code | The error description is presented; processing continues to further specific-error checks below |

**Step 2 - Invalid date entry is identified and the user is guided to correct the value**
If the error was caused by a date value that the system cannot recognise as a valid date, the form displays a specific message telling the user the date entered is not valid, then stops further processing so the user can correct it.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the invalid-date error message to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 50004 identifies an unrecognisable date value | Error code 50004 check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When the user enters a value in a date field and the system cannot parse it as a valid date | Prevents the user from leaving a date field with an entry the system cannot interpret, providing clear corrective guidance | *"Entered Date is not valid Date"* is shown; the current operation is halted and the user must re-enter the date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - Error code 50004: the entered date value cannot be recognised - *"Entered Date is not valid Date"*; the current operation is halted; the user must correct the date entry.

**Step 3 - Incorrect date format is detected and the expected format is shown**
If the error indicates the date was entered in the wrong format, the form tells the user the correct format to use (day-month-year with hyphens) and halts processing until the value is corrected.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the date-format guidance message to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 50025 and 50026 identify a date format violation | Error codes 50025/50026 check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When the user enters a date in an unrecognised format | Guides the user to enter dates in the required DD-MM-YYYY format, preventing downstream processing of a malformed date | *"Enter the Date in the proper format (DD-MM-YYYY)"* is shown; the current operation is halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-02** - Error codes 50025 or 50026: date format not recognised - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the current operation is halted; the user must re-enter the date in the correct format.

**Step 4 - Non-numeric entry in a numeric-only field is blocked**
If the error arose because the user typed alphabetic or special characters into a field that accepts numbers only, the form informs the user that only numeric values are allowed and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the numeric-only restriction message to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40209 and 50016 identify non-numeric entry in a numeric field | Error codes 40209/50016 check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When the user enters characters or special characters in a numeric-only field | Prevents invalid data types from being accepted in fields that require only numeric values | *"Characters/Special Characters are not allowed here, enter the numeric value"* is shown; the current operation is halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-03** - Error codes 40209 or 50016: non-numeric entry in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the current operation is halted; the user must correct the entry.

**Step 5 - A generic system message error is displayed using the error text only**
If error code 40207 is raised, the system displays only the associated error text (without the type-and-number prefix) and halts processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the error text to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 40207 triggers display of the error text only | Error code 40207 check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When error code 40207 is raised during form processing | Presents the error message text directly to the user without an unnecessary prefix | The error text is shown; the current operation is halted |

**Step 6 - A database referential constraint violation is raised as a named business error**
If the underlying database rejects an action because it would break a referential constraint (such as attempting to remove a record that is still referenced elsewhere), the system raises a standard named error to communicate the violation to the user.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-006](#sp-006)) - GENERAL.RAISE_ERROR - raises a named application error (error code 'E0088') corresponding to the referential integrity violation, presenting the associated business error message to the user.
    * **Step 1** - Receive the named error code to be raised.
    * **Step 2** - Look up the message associated with the named error code.
    * **Step 3** - Display the corresponding business error message to the user and stop the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database error -02292 (referential integrity constraint violated) | DBMS error code -02292 check in ON-ERROR trigger - GENERAL.RAISE_ERROR [SP-006] (error code 'E0088') | When the user attempts an action that would violate a referential integrity rule in the database | Provides a meaningful business error rather than exposing a raw database error code when a dependency constraint is violated | The named error 'E0088' is raised; the action is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-04** - Database error -02292: referential integrity constraint violated - the named business error 'E0088' is raised via GENERAL.RAISE_ERROR; the offending action is blocked.

**Step 7 - A concurrent-user record conflict is detected, the change is rolled back, and the user is told to re-query**
If the record the user is trying to change has already been updated by another user, the system rolls back the attempted change and instructs the user to re-query the record before making further edits.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the concurrent-update conflict message to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40654-40659 identify a concurrent-user record conflict | Error codes 40654/40655/40656/40657/40659 check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When an attempted save or change is rejected because another user has already modified the same record | Protects data integrity by preventing one user's changes from silently overwriting another user's update; instructs the user to refresh before re-editing | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is shown; the change is rolled back; the current operation is halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-05** - Error codes 40654-40659: concurrent record conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; the pending change is rolled back; the user must re-query the record before editing.

**Step 8 - Any remaining database error is displayed and the transaction is rolled back**
If an error that is not covered by the specific checks above causes a non-zero database error code, the system displays the database-generated error message and rolls back the transaction to keep data consistent.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the database error message text to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Any non-zero SQL error code not matched by earlier checks | sqlcode <> 0 fallback check in ON-ERROR trigger - GENERAL.DISP_TEXT [SP-004] | When any unclassified database error occurs during form processing | Ensures no database error is silently swallowed; the user always sees the database-generated error description and the transaction is safely rolled back | The database error message text is displayed dynamically (the system's own database error text); the transaction is rolled back; the current operation is halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-06** - Any unclassified database error (sqlcode ≠ 0): the database-generated error message text is shown dynamically; the transaction is rolled back; the current operation is halted.

**Step 9 - Certain informational system messages are silently suppressed**
Error codes 40401 and 40405 (standard informational conditions for "no records matched" and "last record reached") are intentionally handled with no action - no message is shown to the user and processing continues normally.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes 40401 and 40405 are handled silently (no-operation) | Error codes 40401/40405 null-handler in ON-ERROR trigger | When the form raises a standard informational code for "no records matched" or "last record reached" | Prevents unnecessary noise for expected informational states; the user is not shown a spurious error for normal navigation conditions | No message is shown; processing continues normally |

**Step 10 - Routed messages carrying specific error codes are also intercepted and formatted**
The form's message interception layer additionally catches cases where the system message event itself carries error codes 40209 or 40207, displaying a formatted label with the error type, number, and text, and stopping further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#sp-004)) - GENERAL.DISP_TEXT - presents the formatted message to the user.
    * **Step 1** - Receive the message text and severity indicator to be shown to the user.
    * **Step 2** - Display the message in the standard error notification area so the user can read it.
    * **Step 3** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message event codes 40209 and 40207 are intercepted and formatted | Error codes 40209/40207 check in ON-MESSAGE trigger - GENERAL.DISP_TEXT [SP-004] | When the system raises a message during form processing and that message carries code 40209 or 40207 | Ensures that specific message codes which carry meaningful error descriptions are surfaced to the user in a consistent formatted display rather than being passed through as generic messages | The formatted error type, number, and text are displayed; the current operation is halted |

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) The first DECLARE block in ON-ERROR (which handled only error codes 40209 and 40207 with an early single-check path) is entirely within a `/* ... */` comment block and does NOT execute. (COMMENTED OUT / INACTIVE - does not execute.)

---

---

#### Requirement ID: BR-002

**Requirement Title:** Exit the Form Without Saving Pending Changes

**Business Description:**
When the user closes the parts location stock enquiry screen, the system performs a short sequence of housekeeping tasks before shutting down: it clears the database session's application tracking information, removes in-memory query-state variables, and deletes any temporary part-search records created during the session. The form then closes immediately, discarding any unsaved changes, without prompting the user to confirm or save. This gives users a fast exit that also leaves no orphaned working data behind.

**Actors:** Parts Enquiry User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Application tracking information is cleared before closing**
Before the form closes, the system clears the application identifier and module name that were registered with the database session at start-up, so the database no longer attributes any activity to this form after the user leaves.

**Step 2 - Temporary session state is erased**
The system removes the in-memory global variables used to hold intermediate query filter state during the session (the organisation-level and final where-clause accumulators), freeing those values and preventing them from persisting into any subsequent session.

**Step 3 - Any outstanding part-search temporary data is deleted**
The system calls the part-search cleanup routine to remove any temporary search records created for the current principal organisation during this session, keeping the underlying working tables free of orphaned data.

*Procedures called:*
- **PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW** - deletes any temporary part-search working data associated with the current principal organisation from the part-search temporary tables, ensuring no orphaned records remain after the form closes.
    * **Step 1** - Receive the current principal organisation identifier.
    * **Step 2** - Delete all temporary part-search records belonging to that principal organisation from the working tables.

**Step 4 - The form closes immediately without saving pending changes**
Once the cleanup steps above have completed, the system closes the form immediately, discarding any unsaved changes. No confirmation or save prompt is shown to the user.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) The inactive KEY-LISTVAL trigger at form level is entirely empty (no code body) and does NOT execute when the list-of-values key is pressed. (COMMENTED OUT / INACTIVE - does not execute.)

---

---

#### Requirement ID: BR-003

**Requirement Title:** Save and Commit Stock Enquiry Data

**Business Description:**
When the user initiates a save action, the system checks whether saving is currently permitted. If it is, the system validates the current form state, commits the data to the database, confirms the commit succeeded, and then clears the form so it is ready for the next enquiry. If any step fails, the user is informed and the form remains open for correction.

**Actors:** Parts Enquiry User

**Preconditions:**
- The save action is available (the Save button is currently enabled on the form).
- The user triggers the save action either by pressing the save key or by clicking the Save toolbar button (the toolbar button delegates to the same save sequence via the FT_SAVE button trigger).

**Main Flow:**

**Step 1 - The save action is checked for availability and proceeds only if enabled**
When the user presses the save key, the system first checks whether the Save button on the form is currently active. If the Save button is not active, no save action takes place and the key press is silently ignored.

**Step 2 - The current form state is entered and checked for errors before committing**
The system moves into the current record (executing any pending item-level validations) and then checks whether that entry step raised any error. If an error was detected during entry, a descriptive message is displayed to the user and the save is aborted.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-002](#sp-002)) - GENERAL.CHECK_FORM_FAILURE - checks whether the most recent form operation succeeded. If it did not, it displays either the database-generated error message (when the error came from the database) or the form error text (when it was a form-level error), and then halts further processing so the user can see and correct the issue.
    * **Step 1** - Determine whether the most recently completed form operation ended in success or failure.
    * **Step 2** - If the operation failed and the error originated from the database, display the database-generated error message to the user.
    * **Step 3** - If the operation failed and the error was a form-level error, display the form error text to the user.
    * **Step 4** - If a failure was detected (either type), halt further processing so the user can review and correct the error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Form operation success is checked after the enter step | GENERAL.CHECK_FORM_FAILURE [SP-002] - checks form_success after enter | When the user initiates a save and the system moves into the current record | Ensures that any validation errors triggered during data entry are caught before the commit is attempted | A descriptive error message is shown (either the database error text or the form error text); the save is aborted; the form remains open |

**Step 3 - The data is committed to the database and the result is confirmed**
If the entry step succeeded, the system commits all pending changes to the database and immediately checks whether the commit completed successfully. If the commit fails, a descriptive error message is displayed and the form remains open.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-002](#sp-002)) - GENERAL.CHECK_FORM_FAILURE - checks whether the commit operation succeeded; displays the appropriate error message and halts processing if it did not.
    * **Step 1** - Determine whether the most recently completed form operation ended in success or failure.
    * **Step 2** - If the operation failed and the error originated from the database, display the database-generated error message to the user.
    * **Step 3** - If the operation failed and the error was a form-level error, display the form error text to the user.
    * **Step 4** - If a failure was detected (either type), halt further processing so the user can review and correct the error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Commit success is confirmed immediately after the database commit | GENERAL.CHECK_FORM_FAILURE [SP-002] - checks form_success after commit_form | After the database commit executes | Ensures the user is notified immediately if the database commit did not succeed, so data is not assumed saved when it was not | A descriptive error message is shown; the form remains open; the user must correct the issue before saving again |

**Step 4 - The form is cleared after a successful commit**
Once the commit is confirmed successful, the system clears the form, removing all entered data and returning the form to a blank ready state for the next enquiry.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) If the Save button is not enabled at the time the save key is pressed, the entire save sequence is skipped silently; no action is taken and the key press has no effect.
- **BR-003-AF-02** - (from Step 1) The form-level KEY-COMMIT trigger body is entirely within a `/* ... */` comment block ending in `null;` and does NOT execute. The save sequence is therefore only reachable via the save key action on the Save button or via the toolbar Save button (FT_SAVE). (COMMENTED OUT / INACTIVE - does not execute.)

---

---

#### Requirement ID: BR-004

**Requirement Title:** Clear the Form and Refresh the Copyright Notice

**Business Description:**
When the user triggers the clear-form action (either via the clear key or via the Cancel toolbar button), the system discards all current data on the screen without saving, refreshes the copyright notice displayed at the bottom of the screen with the current year's copyright text, and then deletes any temporary part-search working data created during the session. The copyright year is calculated automatically based on the current calendar date, using the previous financial year's label during the first quarter (January through March) and the current year's label for the rest of the year.

**Actors:** Parts Enquiry User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - All data on the form is cleared without saving**
The system removes all values currently displayed on the screen, resetting the form to a blank state, without prompting the user to save and without writing any changes to the database.

**Step 2 - The copyright notice is refreshed with the current-year value**
Immediately after clearing, the system retrieves the appropriate copyright text for the current period and writes it to the copyright display field on the screen. The year shown reflects either the current calendar year or the previous year, depending on whether the current date falls in the first quarter of the calendar year.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-007](#sp-007)) - SF_COPYRIGHT_DECLARATION - determines the correct copyright year based on today's date and returns a formatted copyright string for display. If the current month is January, February, or March, the previous calendar year is used (to align with the financial year); otherwise the current calendar year is used. The returned text is of the form "© [YYYY] Maruti Suzuki India Limited".
    * **Step 1** - Read today's date from the system.
    * **Step 2** - Check whether the current month falls in January, February, or March.
    * **Step 3** - If the month is January, February, or March, set the copyright year to the previous calendar year; otherwise set it to the current calendar year.
    * **Step 4** - Return the formatted copyright string "© [YYYY] Maruti Suzuki India Limited" for display.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Copyright year is determined by the current month (Q1 uses the previous year) | Month-based year-selection logic in SF_COPYRIGHT_DECLARATION [SP-007] | When the form is cleared and the copyright field is refreshed | Ensures that the copyright notice always shows the correct financial-year label, using the prior year during January-March and the current year for the remainder of the year | N/A - the function always returns a valid string; there is no failure path |

**Step 3 - Temporary part-search working data for the session is deleted**
After the form has been cleared and the copyright notice refreshed, the system calls the part-search cleanup routine to remove any temporary search records created for the current principal organisation, ensuring no stale working data accumulates between searches.

*Procedures called:*
- **PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW** - deletes all temporary part-search records associated with the current principal organisation, keeping the working tables clean between enquiry sessions.
    * **Step 1** - Receive the current principal organisation identifier.
    * **Step 2** - Delete all temporary part-search records belonging to that principal organisation from the working tables.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) The commented-out `ENTER_QUERY` call that previously would have started a query after clearing the form does NOT execute. (COMMENTED OUT / INACTIVE - does not execute.)
- **BR-004-AF-02** - (from Step 1) When the Cancel toolbar button (FT_CANCEL) triggers this process, the system first checks whether the Cancel button is enabled before proceeding. If the button is not enabled, no action is taken. The optional confirmation prompt (asking whether entered data should not be saved) is entirely commented out and does NOT execute; the form is always cleared unconditionally when the Cancel button is pressed and enabled. (COMMENTED OUT / INACTIVE - confirmation prompt does not execute.)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Text (display only) | 100 | N/A | N/A | Form cleared | System-set automatically by SF_COPYRIGHT_DECLARATION [SP-007]; not user-editable | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Populate the Location Filter List After Dealer Name Entry

**Business Description:**
When the user completes entry of a dealer name in the search filter, the system automatically refreshes the available choices in the Location drop-down list. The list is filtered to show only the locations that belong to the current user's group and principal organisation. If a specific dealer has also been entered in the Dealer filter, the location list is further narrowed to show only locations belonging to that dealer, giving the user an accurate and relevant set of locations to choose from.

**Actors:** Parts Enquiry User

**Preconditions:**
- The user has entered or changed the Dealer Name search filter.

**Main Flow:**

**Step 1 - A location query is built using the current search filters**
When the user finishes entering a dealer name, the system constructs a query that retrieves all available location descriptions and codes matching the current user's principal organisation and parent group. If the Dealer filter also contains a value, the query is additionally restricted to locations for that specific dealer only.

**Step 2 - The Location list data source is refreshed and the list is repopulated**
The system uses the constructed query to rebuild the underlying data source for the Location drop-down list, then applies the refreshed data source to the list item so the user sees only the matching location options.

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-005](#sp-005)) - GENERAL.L_POP_LIST_ITEM - rebuilds the underlying data source (record group) for the Location list using the supplied query. It first removes any previous version of the data source if one already exists, then creates a fresh one from the query and populates it with the matching rows.
    * **Step 1** - Check whether the Location data source already exists from a previous call.
    * **Step 2** - If the data source already exists, remove it so it can be replaced with fresh data.
    * **Step 3** - Create a new data source using the query built in Step 1 of the main flow.
    * **Step 4** - Populate the new data source by executing the query against the database.
- After GENERAL.L_POP_LIST_ITEM completes, the trigger calls the built-in **populate_list** function with the record group name 'Location' and the list item path 'cb_dummy.location' to apply the refreshed record group values to the Location list item, making the new options visible in the dropdown.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Existing Location data source is detected and replaced before repopulating | Existence check in GENERAL.L_POP_LIST_ITEM [SP-005] - Find_Group check before delete and recreate | When the user completes entry of the Dealer Name field | Prevents the Location list from accumulating stale or duplicate entries by ensuring any previous data source is removed before a fresh one is built | If the data source already existed it is removed; the fresh data source is then created from the current query - no visible error is shown |

**Business Scenarios - How the Location list differs by Dealer filter state**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **No dealer specified** | The Location list shows all locations across all dealers belonging to the user's group and principal organisation, ordered alphabetically by description. |
| **A specific dealer entered** | The Location list is restricted to locations belonging to that dealer only, filtered from the same group and principal organisation. |

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) The commented-out alternative query variant (which previously filtered locations by `dealer_map_cd` using a `LIKE` pattern with `nvl`) is entirely within a `/* ... */` comment block and does NOT execute. (COMMENTED OUT / INACTIVE - does not execute.)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Name (`DEALER_NAME`) | Optional | Text | 100 | Dealer lookup (LV_DEALER via RG_DEALER) | Dealer name | N/A | Used as trigger input; the dealer's code (if present) narrows the location query | N/A |
| Dealer (`DEALER`) | Optional | Numeric | 5 | N/A | N/A | N/A | When populated, restricts the Location list to the specified dealer's locations only | N/A |
| Location (`LOCATION`) | Auto-populated (refreshed) | List item | 3 | Dealer location master (AM_DEALER_LOC) | Location description and code | Dealer Name entry completed | Refreshed automatically; user selects from the updated list | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Resolve Root Part Number from the Entered Part Number

**Business Description:**
When the user enters a part number in the search filter, the system automatically looks up the root part number that the entered part belongs to and fills in the Root Part Number field. This saves the user from needing to know or manually enter the root part number. If the part number entered does not match any known part, the Root Part Number field is simply left unchanged and the user can proceed or manually enter it. When the user moves forward from the Part Number field, the same look-up runs and the cursor advances to the Root Part Number field.

**Actors:** Parts Enquiry User

**Preconditions:**
- The user has entered a value in the Part Number search filter.

**Main Flow:**

**Step 1 - The entered part number is looked up to find its root part number**
When the user leaves the Part Number field, the system queries the parts master to find the root part number that corresponds to the value entered. The search is scoped to the current user's principal organisation and considers both the organisation-level and dealer-level part records.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part number is looked up against the parts master; any failure is silently ignored | SELECT from PM_PART in WHEN-VALIDATE-ITEM trigger on CB_DUMMY.PART_NUM; WHEN OTHERS -> NULL | When the user leaves the Part Number field after entering a value | Automatically populates the Root Part Number so the user does not need to know or enter it manually | If no matching part is found or any other error occurs, the Root Part Number field is left unchanged (silent no-op); no error message is shown |

**Step 2 - The resolved root part number is stored for use in the stock search**
If a matching part is found in Step 1, the system stores the resolved root part number so it is available as a search filter for the subsequent stock enquiry.

**Step 3 - When the user advances from the Part Number field, the same lookup runs and the cursor moves to the Root Part Number field**
When the user presses the forward-navigation key from the Part Number field, the system repeats the root part number look-up (same query as Step 1) and then moves the cursor directly to the Root Part Number field, allowing the user to review or override the resolved value before triggering the stock search.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Same part-number look-up runs on forward navigation; any failure is silently ignored | SELECT from PM_PART in KEY-NEXT-ITEM trigger on CB_DUMMY.PART_NUM; WHEN OTHERS -> NULL | When the user presses the forward-navigation key from the Part Number field | Ensures the Root Part Number is up to date before the cursor advances, so the user can verify or amend it without losing the automatically resolved value | If no matching part is found or any other error occurs, the Root Part Number is unchanged and the cursor still advances to the Root Part Number field |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) The WHEN-VALIDATE-ITEM trigger on the Root Part Number field, which previously contained a call to validate that the Part Number field was not null, is entirely replaced by a `null;` no-op statement and does NOT execute any business logic. (COMMENTED OUT / INACTIVE - does not execute.)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Optional | Text | 15 | N/A | N/A | N/A | Entered value is used to query the parts master for the corresponding root part number | N/A - errors are silently ignored |
| Root Part Number (`ROOT_PART_NUM`) | Auto-populated | Text | 15 | N/A | N/A | Part Number entered | Automatically set from the parts master look-up; may be overridden manually | If the look-up finds no match, the field is unchanged; no error message |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Retrieve Part Stock Details by Search Criteria

**Business Description:**
When the user activates the stock search (by toggling the stock filter checkbox), the system clears any previously displayed stock results and then retrieves current stock information for the specified part across all applicable dealer locations. The search can be narrowed by optionally filtering on a specific dealer and/or a specific location. The user can also choose to see only stores that currently hold positive stock, or all stores regardless of stock level. If neither a part number nor a root part number has been entered, the system prompts the user to provide at least one before the search can proceed.

**Actors:** Parts Enquiry User

**Preconditions:**
- At least one of the Part Number or Root Part Number search filters contains a value.

**Main Flow:**

**Step 1 - The stock results area is cleared and navigation moves to the results section**
When the user toggles the stock filter checkbox, the system navigates to the stock results area and clears any data previously displayed there, making it ready for the new search results.

**Step 2 - The system verifies that at least one part identifier has been entered**
Before running the stock query, the system checks whether either the Part Number or the Root Part Number filter has been filled in. If neither has been entered, the search is blocked and the user is directed back to the Part Number field with an error message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one of Part Number or Root Part Number must be provided | Part-identifier presence check in WHEN-CHECKBOX-CHANGED trigger on CB_DUMMY.STOCK_CHK | When the user toggles the stock filter checkbox | Prevents the form from running a stock query with no part identifier, which would return no useful results | *"Please enter Part Number or Root Part Number to get details"* is shown; the cursor returns to the Part Number field; the search is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Neither Part Number nor Root Part Number is entered - *"Please enter Part Number or Root Part Number to get details"*; the cursor returns to the Part Number field; the stock search is aborted.

**Step 3 - Applicable dealer locations are identified based on the active filters**
The system determines which dealer locations to search based on the combination of Dealer and Location filters currently entered. Four combinations are handled: no dealer and no location (all locations in the group); dealer only (all locations for that dealer); location only (all dealers at that location); or both dealer and location specified (the specific combination only).

**Step 4 - Stock details are retrieved and displayed for each matching location**
For each dealer location identified in Step 3, the system retrieves the stock quantities, floating stock, allocated stock, part description, and the manufacturer's recommended price for each part variant at that location, and populates a row in the results grid.

*Procedures called:*
- **POP_STOCK_DETAILS** ([SP-001](#sp-001)) - POP_STOCK_DETAILS - retrieves and populates stock detail rows for one dealer/location combination. For the given dealer and location, it first finds all part variants sharing the same root part number. For each part variant it then fetches the current stock quantities (net stock, floating stock, allocated quantity) along with the part description and the most recent manufacturer recommended price. It applies the stock-filter setting to decide whether to include rows with zero stock or only rows with positive stock, and writes each qualifying row into the results grid.
    * **Step 1** - Check whether the Root Part Number has been resolved; if it has not been set, raise an error and move the cursor to the Root Part Number field, stopping processing.
    * **Step 2** - Retrieve all part variants (part numbers and descriptions) that share the same root part number, scoped to the current user's principal organisation.
    * **Step 3** - For each part variant, retrieve the stock quantities (net stock, floating stock, allocated stock), store description, store code, and the most recent manufacturer recommended price from the stock and pricing tables, joining them for the specified dealer and location.
    * **Step 4** - Apply the stock-filter option: if only positive-stock rows are requested, include only rows where the calculated net stock is greater than zero; otherwise include all rows regardless of stock level.
    * **Step 5** - Write each qualifying row into the stock results grid, populating the location code, dealer code, store code, store description, current stock, part description, allocated quantity, floating stock, location description, dealer name, part number, and recommended price fields.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Root Part Number must be resolved before stock details can be loaded | Root Part Number null-check in POP_STOCK_DETAILS [SP-001] - GENERAL.CHECK_NULL call followed by go_item and RAISE FORM_TRIGGER_FAILURE | When the stock search is triggered for a dealer/location combination | Ensures the stock search always runs against a valid root part number, since the query is keyed on the root part number | An error is raised by GENERAL.CHECK_NULL; the cursor moves to the Root Part Number field; stock loading for this dealer/location combination is halted |
| Stock filter option controls whether zero-stock rows are included or excluded | STOCK_CHK = 'Y' / 'N' filter in cur_stk cursor within POP_STOCK_DETAILS [SP-001] | When the user has set the "Stock > 0" checkbox before running the search | Allows users to focus on stores that actually have available stock, or to see all stores including those with zero stock | N/A - this is a filter choice that narrows results, not a failure condition |

**Step 5 - The first result row is displayed**
After all matching rows have been loaded, the system positions the display on the first result row so the user immediately sees the beginning of the results list.

**Step 6 - Navigating down through the results is bounded at the last row**
When the user presses the down-arrow key to move to the next result row, the system first checks whether the current row is a new, unsaved record. If it is, the user has reached the end of the loaded results and the system informs them accordingly, then stops further downward navigation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current record status is checked before advancing to the next row | system.record_status = 'NEW' check in KEY-DOWN trigger on the results block | When the user presses the down-arrow key in the stock results area | Prevents the user from navigating past the last loaded result row, giving clear feedback that no further rows exist | *"This is the Last Row"* is shown; downward navigation is halted; the user remains on the current row |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-WS-01** - User presses down-arrow on the last result row - *"This is the Last Row"* is shown; navigation is halted; the user stays on the current row.

**Step 7 - Navigating up through the results is bounded at the first row**
When the user presses the up-arrow key to move to the previous result row, the system checks whether the current row is the first record in the results. If it is, the system informs the user that no earlier rows exist and stops further upward navigation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current record position is checked before moving to the previous row | system.trigger_record = '1' check in KEY-UP trigger on the results block | When the user presses the up-arrow key in the stock results area | Prevents the user from navigating above the first loaded result row, giving clear feedback that no earlier rows exist | *"This is the first Row"* is shown; upward navigation is halted; the user remains on the current row |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-WS-02** - User presses up-arrow on the first result row - *"This is the first Row"* is shown; navigation is halted; the user stays on the current row.

**Business Scenarios - How search results differ by filter combination**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **No dealer, no location** | All dealer locations in the user's group and principal organisation are searched; results show stock across the entire network. |
| **Dealer specified, no location** | Only locations belonging to the specified dealer are searched; results are restricted to that dealer's stores. |
| **Location specified, no dealer** | All dealers at the specified location code are searched; results show stock for all dealers at that site. |
| **Both dealer and location specified** | Only the single combination of the specified dealer and location is searched; results are the most narrowly scoped. |
| **Stock > 0 checkbox selected** | Only stores where the calculated net stock is greater than zero are included in the results. |
| **Stock > 0 checkbox not selected** | All stores are included in the results regardless of their current stock level. |

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 4) Several earlier stock-retrieval cursor variants (c_stock1, c_stock2, c_stock3) that previously handled the lookup separately based on whether part number only, root part number only, or both were entered are entirely within a `/* ... */` comment block in POP_STOCK_DETAILS and do NOT execute. The active code always uses the root part number. (COMMENTED OUT / INACTIVE - does not execute.)
- **BR-007-AF-02** - (from Step 4) The code path inside POP_STOCK_DETAILS that previously set the net stock using the GET_PART_NET_STOCK function and also retrieved part description and root part number from PM_PART in a separate inline query is entirely within a `/* ... */` comment block and does NOT execute. (COMMENTED OUT / INACTIVE - does not execute.)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Conditional - when Root Part Number is blank | Text | 15 | N/A | N/A | N/A | At least one of Part Number or Root Part Number must be entered | *"Please enter Part Number or Root Part Number to get details"* |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - when Part Number is blank | Text | 15 | N/A | N/A | N/A | At least one of Part Number or Root Part Number must be entered; Root Part Number must be resolved before stock query runs | Error raised by GENERAL.CHECK_NULL; cursor moves to Root Part Number field |
| Dealer (`DEALER`) | Optional | Numeric | 5 | Dealer lookup (LV_DEALER via RG_DEALER) | Dealer code | N/A | Narrows the location search to the specified dealer when provided | N/A |
| Location (`LOCATION`) | Optional | List item | 3 | Dealer location master (AM_DEALER_LOC) | Location code | N/A | Narrows the location search to the specified location when provided | N/A |
| Stock > 0 (`STOCK_CHK`) | Optional | Checkbox | N/A | N/A | 'Y' / 'N' | N/A | When checked ('Y'), only stores with positive net stock are included in results; when unchecked ('N'), all stores are included | N/A |
| Stores (`NB_STORES_DESC`) | Auto-populated | Text (read-only) | 50 | N/A | N/A | Stock search executed | Populated from store description in stock data | N/A |
| Location (`NB_LOC_DESC`) | Auto-populated | Text (read-only) | 50 | N/A | N/A | Stock search executed | Populated from location description in dealer location data | N/A |
| Dealer Name (`DEALER_NAME`) | Auto-populated | Text (read-only) | 75 | N/A | N/A | Stock search executed | Populated from dealer name passed to POP_STOCK_DETAILS | N/A |
| Part Number - result (`PART_NUM` in results) | Auto-populated | Text (read-only) | 15 | N/A | N/A | Stock search executed | Populated from parts master for the root part number | N/A |
| Part Desc (`NB_PART_DESC`) | Auto-populated | Text (read-only display) | 50 | N/A | N/A | Stock search executed | Populated from part description in the parts master | N/A |
| Current Stock (`NB_CURR_STOCK`) | Auto-populated | Numeric (read-only) | 16 (format: 9,99,99,99,990.000) | N/A | N/A | Stock search executed | Net stock = local stock + other stock - allocated - float - reserved quantities | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Auto-populated | Numeric (read-only) | 16 (format: 9,99,99,99,990.000) | N/A | N/A | Stock search executed | Sum of local and other floating stock quantities | N/A |
| Allocated Stock (`ALLOC_QTY`) | Auto-populated | Numeric (read-only) | 17 (format: 9,99,99,99,990.000) | N/A | N/A | Stock search executed | Allocated quantity from stock data | N/A |
| Part MRP (`PART_MRP`) | Auto-populated | Numeric (read-only display) | 50 | N/A | N/A | Stock search executed | Manufacturer's recommended price from the most recent pricing batch for the part | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Auto-Load Stock Details When Navigating to the Results Area

**Business Description:**
When the user navigates into the stock results section of the screen (for example, by clicking into it or by tabbing into the results grid), the system automatically clears any previous results and re-runs the stock search using the current search filter values. This ensures the results area always shows up-to-date stock information that matches the filters currently set, even when the user moves between sections of the screen without explicitly triggering the checkbox. The same part-identifier requirement and dealer/location filter rules apply as for the checkbox-triggered search.

**Actors:** Parts Enquiry User

**Preconditions:**
- At least one of the Part Number or Root Part Number search filters contains a value.

**Main Flow:**

**Step 1 - The stock results area is cleared**
When the user navigates into the stock results section, the system immediately clears any data currently shown there, making room for fresh results based on the current filter values.

**Step 2 - The system verifies that at least one part identifier has been entered**
Before running the stock query, the system checks whether either the Part Number or the Root Part Number filter has a value. If neither has been entered, the search is blocked and the user is directed back to the Part Number field with an error message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one of Part Number or Root Part Number must be provided | Part-identifier presence check in WHEN-NEW-BLOCK-INSTANCE trigger on B_PM_STOCK | When the user navigates into the stock results area | Prevents the form from loading an empty results grid when no part has been entered | *"Please enter Part Number or Root Part Number to get details"* is shown; the cursor returns to the Part Number field; the auto-load is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - Neither Part Number nor Root Part Number is entered - *"Please enter Part Number or Root Part Number to get details"*; the cursor returns to the Part Number field; the auto-load is aborted.

**Step 3 - Applicable dealer locations are determined and stock details are retrieved**
Using the same dealer and location filter logic as the checkbox-triggered search (no filters, dealer only, location only, or both), the system identifies the applicable locations and calls the stock detail loader for each one, populating the results grid.

*Procedures called:*
- **POP_STOCK_DETAILS** ([SP-001](#sp-001)) - POP_STOCK_DETAILS - retrieves and populates stock detail rows for one dealer/location combination, applying the same root-part-number validation, part-variant iteration, stock-filter option, and pricing look-up as described in BR-007.
    * **Step 1** - Check whether the Root Part Number has been resolved; if it has not been set, raise an error and move the cursor to the Root Part Number field, stopping processing.
    * **Step 2** - Retrieve all part variants (part numbers and descriptions) that share the same root part number, scoped to the current user's principal organisation.
    * **Step 3** - For each part variant, retrieve the stock quantities (net stock, floating stock, allocated stock), store description, store code, and the most recent manufacturer recommended price from the stock and pricing tables, joining them for the specified dealer and location.
    * **Step 4** - Apply the stock-filter option: if only positive-stock rows are requested, include only rows where the calculated net stock is greater than zero; otherwise include all rows regardless of stock level.
    * **Step 5** - Write each qualifying row into the stock results grid, populating the location code, dealer code, store code, store description, current stock, part description, allocated quantity, floating stock, location description, dealer name, part number, and recommended price fields.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Root Part Number must be resolved before stock details can be loaded | Root Part Number null-check in POP_STOCK_DETAILS [SP-001] - GENERAL.CHECK_NULL call followed by go_item and RAISE FORM_TRIGGER_FAILURE | When the auto-load runs for a dealer/location combination | Ensures the stock search always runs against a valid root part number | An error is raised by GENERAL.CHECK_NULL; the cursor moves to the Root Part Number field; stock loading for this combination is halted |
| Stock filter option controls whether zero-stock rows are included or excluded | STOCK_CHK = 'Y' / 'N' filter in cur_stk cursor within POP_STOCK_DETAILS [SP-001] | When the auto-load populates results | Applies the same positive-stock filter that the user set via the checkbox, ensuring consistent results whether triggered by navigation or by the checkbox | N/A - this is a filter choice that narrows results, not a failure condition |

**Step 4 - The first result row is displayed**
After all rows have been loaded, the system positions the display on the first result row.

**Step 5 - Navigating down through the results is bounded at the last row**
When the user presses the down-arrow key to move to the next result row, the system checks whether the current row is a new, unsaved record. If it is, the user has reached the end of the loaded results and the system informs them accordingly, then stops further downward navigation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current record status is checked before advancing to the next row | system.record_status = 'NEW' check in KEY-DOWN trigger on the results block | When the user presses the down-arrow key in the stock results area | Prevents the user from navigating past the last loaded result row, giving clear feedback that no further rows exist | *"This is the Last Row"* is shown; downward navigation is halted; the user remains on the current row |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-WS-01** - User presses down-arrow on the last result row - *"This is the Last Row"* is shown; navigation is halted; the user stays on the current row.

**Step 6 - Navigating up through the results is bounded at the first row**
When the user presses the up-arrow key to move to the previous result row, the system checks whether the current row is the first record in the results. If it is, the system informs the user that no earlier rows exist and stops further upward navigation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current record position is checked before moving to the previous row | system.trigger_record = '1' check in KEY-UP trigger on the results block | When the user presses the up-arrow key in the stock results area | Prevents the user from navigating above the first loaded result row, giving clear feedback that no earlier rows exist | *"This is the first Row"* is shown; upward navigation is halted; the user remains on the current row |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-WS-02** - User presses up-arrow on the first result row - *"This is the first Row"* is shown; navigation is halted; the user stays on the current row.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Conditional - when Root Part Number is blank | Text | 15 | N/A | N/A | N/A | At least one of Part Number or Root Part Number must be entered | *"Please enter Part Number or Root Part Number to get details"* |
| Root Part Number (`ROOT_PART_NUM`) | Conditional - when Part Number is blank | Text | 15 | N/A | N/A | N/A | Must be resolved before stock query runs | Error raised by GENERAL.CHECK_NULL; cursor moves to Root Part Number field |
| Dealer (`DEALER`) | Optional | Numeric | 5 | Dealer lookup (LV_DEALER via RG_DEALER) | Dealer code | N/A | Narrows the location search to the specified dealer when provided | N/A |
| Location (`LOCATION`) | Optional | List item | 3 | Dealer location master (AM_DEALER_LOC) | Location code | N/A | Narrows the location search to the specified location when provided | N/A |
| Stock > 0 (`STOCK_CHK`) | Optional | Checkbox | N/A | N/A | 'Y' / 'N' | N/A | Applies the same positive-stock filter as the checkbox-triggered search | N/A |
| Stores (`NB_STORES_DESC`) | Auto-populated | Text (read-only) | 50 | N/A | N/A | Auto-load executed | Populated from store description | N/A |
| Location (`NB_LOC_DESC`) | Auto-populated | Text (read-only) | 50 | N/A | N/A | Auto-load executed | Populated from location description | N/A |
| Dealer Name (`DEALER_NAME`) | Auto-populated | Text (read-only) | 75 | N/A | N/A | Auto-load executed | Populated from dealer name passed to POP_STOCK_DETAILS | N/A |
| Part Number - result (`PART_NUM` in results) | Auto-populated | Text (read-only) | 15 | N/A | N/A | Auto-load executed | Populated from parts master for the root part number | N/A |
| Part Desc (`NB_PART_DESC`) | Auto-populated | Text (read-only display) | 50 | N/A | N/A | Auto-load executed | Populated from part description in the parts master | N/A |
| Current Stock (`NB_CURR_STOCK`) | Auto-populated | Numeric (read-only) | 16 (format: 9,99,99,99,990.000) | N/A | N/A | Auto-load executed | Net stock calculation | N/A |
| Float Stock (`NB_FLOAT_STOCK`) | Auto-populated | Numeric (read-only) | 16 (format: 9,99,99,99,990.000) | N/A | N/A | Auto-load executed | Sum of floating stock quantities | N/A |
| Allocated Stock (`ALLOC_QTY`) | Auto-populated | Numeric (read-only) | 17 (format: 9,99,99,99,990.000) | N/A | N/A | Auto-load executed | Allocated quantity from stock data | N/A |
| Part MRP (`PART_MRP`) | Auto-populated | Numeric (read-only display) | 50 | N/A | N/A | Auto-load executed | Most recent manufacturer's recommended price | N/A |

---

---

---

#### Requirement ID: BR-009

**Requirement Title:** Initialise the Form on Open

**Business Description:**
When the user opens the parts location stock enquiry screen, the system automatically prepares the form for use before control is handed to the user. This preparation includes registering the form identity with the database session for monitoring purposes, maximising the main application window, initialising internal session variables that govern query filtering and navigation, populating the Stores, Part Category, and Applicable Model dropdown lists from the relevant master data, defaulting the user's current store selection based on the dealer location configuration, and loading consignment and tax-factor parameters needed for price calculations. The user arrives at a fully ready screen with pre-populated filter lists and no residual state from any earlier session.

**Actors:** Parts Enquiry User (system-driven on form open; no direct user action required)

**Preconditions:**
- The user has launched the parts location stock enquiry form.
- The global session context variables (principal organisation, parent group, dealer, location code) have been set by the calling environment before the form opens.

**Main Flow:**

**Step 1 - The form is registered with the database session for monitoring**
Before the main window appears, the system registers the form identifier (`pe_part`) with the database application information service so that database administrators can identify active sessions running this form.

**Step 2 - The main application window is maximised**
The system sets the main window (`wn_main`) to the maximised state so the form occupies the full available screen area.

**Step 3 - The application identifier is set for use by downstream processes**
The system assigns the value `pe_part` to `global.app_id` to record the current application identifier in the session-level global variable. The same value is also copied into the session parameter `p_app_id` so that any process called from this form can identify which application is running.

**Step 4 - Internal query-state and navigation variables are initialised**
The system clears all query-filter accumulator variables (the organisation-level where-clause, the final where-clause, and the part-filter where-clause) and the exit-flag variable used by calling forms to detect whether the user selected a part. The message suppression level is set so that routine informational messages do not interrupt the user. Navigation range variables controlling the pagination window are set to their initial values (first record 1, last record 20).

**Step 5 - The Stores dropdown is populated from the dealer's store master**
The system builds the available choices for the Stores filter list by querying the store master for all stores belonging to the current dealer and location. The list is loaded using record group `Stores` and applied to the Stores filter field (`cb_dummy.stores_cd`).

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-005](#sp-005)) - GENERAL.L_POP_LIST_ITEM - creates or replaces the data source (`Stores`) for the Stores list by executing the supplied query against the store master, then discards any previous version of the data source before creating the fresh one.
    * **Step 1** - Check whether the Stores data source already exists from a previous call.
    * **Step 2** - If it already exists, remove it so it can be replaced.
    * **Step 3** - Create a new data source from the store master query scoped to the current dealer and location.
    * **Step 4** - Populate the data source by executing the query against the database.
- After GENERAL.L_POP_LIST_ITEM completes, the trigger calls **populate_list** with record group `Stores` and list item path `cb_dummy.stores_cd` to apply the refreshed choices to the Stores filter field.

**Step 6 - The user's default store is selected automatically**
After the Stores list has been populated, the system looks up the default store code configured for the current dealer, parent group, and location in the dealer location parameter table, and sets the Stores filter to that default value so the user does not need to select a store manually on each visit.

**Step 7 - The Part Category dropdown is populated from the category master**
The system builds the available choices for the Part Category filter list by querying the parts category master for all categories belonging to the current principal organisation. The list is loaded using record group `Category` and applied to the Part Category filter field (`cb_dummy.catg_cd`).

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-005](#sp-005)) - GENERAL.L_POP_LIST_ITEM - creates or replaces the data source (`Category`) for the Part Category list from the category master query scoped to the current principal organisation.
    * **Step 1** - Check whether the Category data source already exists from a previous call.
    * **Step 2** - If it already exists, remove it so it can be replaced.
    * **Step 3** - Create a new data source from the category master query.
    * **Step 4** - Populate the data source by executing the query against the database.
- After GENERAL.L_POP_LIST_ITEM completes, the trigger calls **populate_list** with record group `Category` and list item path `cb_dummy.catg_cd` to apply the refreshed choices to the Part Category filter field.

**Step 8 - The Applicable Model dropdown is populated from the model master**
The system builds the available choices for the Applicable Model filter list by querying the applicable-model master for all models belonging to the current principal organisation. The list is loaded using record group `Apply_Model` and applied to the Applicable Model filter field (`cb_dummy.apply_model_cd`).

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-005](#sp-005)) - GENERAL.L_POP_LIST_ITEM - creates or replaces the data source (`Apply_Model`) for the Applicable Model list from the model master query scoped to the current principal organisation.
    * **Step 1** - Check whether the Apply_Model data source already exists from a previous call.
    * **Step 2** - If it already exists, remove it so it can be replaced.
    * **Step 3** - Create a new data source from the applicable-model master query.
    * **Step 4** - Populate the data source by executing the query against the database.
- After GENERAL.L_POP_LIST_ITEM completes, the trigger calls **populate_list** with record group `Apply_Model` and list item path `cb_dummy.apply_model_cd` to apply the refreshed choices to the Applicable Model filter field.

**Step 9 - Pagination navigation buttons are disabled at start-up**
The Previous Page and Next Page navigation buttons are both disabled when the form first opens, because no search has yet been run and there are no results to paginate. The pagination range is set to the first window of twenty records.

**Step 10 - The Excel export button is disabled at start-up**
The Excel export function is disabled when the form first opens because no results are available to export. It becomes available only after a successful stock search.

**Step 11 - Consignment and tax-factor parameters are loaded for the current location**
The system retrieves the consignment code, local stock factor, and other-stock factor for the current dealer, parent group, and location by joining the dealer location, dealer location parameter, and part tax header tables. These values are stored as session parameters for use in price-related calculations during the session. If no matching tax configuration is found, the consignment code parameter is set to null and processing continues normally.

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 2) The earlier commented-out call to maximise the forms MDI window (`forms_mdi_window`) does NOT execute; the active call maximises `wn_main` instead. (COMMENTED OUT / INACTIVE - does not execute.)
- **BR-009-AF-02** - (from Step 4) The global variable assignment block that previously set dealer, principal, and location code to test values is entirely within a `/* ... */` comment block and does NOT execute. (COMMENTED OUT / INACTIVE - does not execute.)
- **BR-009-AF-03** - (from Step 11) If the query to retrieve consignment and tax-factor parameters raises any exception (for example, no configuration row exists for the current location), the consignment code parameter is set to null and execution continues without error; the form opens normally.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Stores (`cb_dummy.stores_cd`) | Auto-populated | List item | - | Store master (gm_store) | Store description and code | Dealer and location context set | Populated from store master for the current dealer and location; default store applied from dealer location parameters | N/A |
| Part Category (`cb_dummy.catg_cd`) | Auto-populated | List item | - | Parts category master (pm_category) | Category description and code | Principal organisation set | Populated from category master for the current principal organisation | N/A |
| Applicable Model (`cb_dummy.apply_model_cd`) | Auto-populated | List item | - | Applicable model master (pm_apply_model) | Model description and code | Principal organisation set | Populated from applicable-model master for the current principal organisation | N/A |

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Invalid Date Entry | Validation | BR-001 | A value entered in a date field cannot be recognised as a valid date | Display *"Entered Date is not valid Date"* and stop the current operation | Prevents an unrecognisable date from being accepted, forcing the user to enter a valid value |
| BRC-002 | Incorrect Date Format | Validation | BR-001 | A date value is entered in a format other than DD-MM-YYYY | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop the current operation | Ensures dates are always entered in the required format, avoiding downstream processing failures |
| BRC-003 | Non-Numeric Entry in Numeric Field | Validation | BR-001 | Alphabetic characters or special characters are entered in a field that accepts numbers only | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop the current operation | Prevents invalid data types from being accepted in numeric-only fields |
| BRC-004 | Referential Integrity Constraint Violation | Constraint | BR-001 | The database rejects an action because it would violate a referential integrity rule | Raise named error 'E0088' via the standard error procedure and block the action | Protects data integrity by preventing the deletion or modification of records that are still referenced by other records |
| BRC-005 | Concurrent Record Update Conflict | Validation | BR-001 | A record the user is trying to change has already been updated by another user | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back the pending change, and stop the operation | Prevents one user's changes from silently overwriting another user's update; requires the user to re-query before re-editing |
| BRC-006 | Save Button Must Be Enabled to Save | Authorization | BR-003 | The user presses the save key but the Save button on the form is not currently active | Silently ignore the key press; take no save action | Prevents an inadvertent save when the form's save capability has been disabled by business logic |
| BRC-007 | Form State Must Be Valid Before Commit | Validation | BR-003 | An error is detected in the current form state after the system enters the current record | Display the relevant error message (database error text or form error text) and abort the save | Ensures that data is validated before it is committed to the database, preventing invalid records from being saved |
| BRC-008 | Commit Must Succeed Before Clearing the Form | Validation | BR-003 | The database commit operation does not complete successfully | Display the relevant error message and leave the form open for correction | Prevents the form from being cleared and reset when the data has not actually been saved, ensuring the user is aware of the failure |
| BRC-009 | Copyright Year Follows Financial Year Boundary | Derivation | BR-004 | The current date falls in January, February, or March | Set the copyright year in the notice to the previous calendar year | Ensures the copyright notice reflects the correct financial year label, aligning the displayed year with the organisation's April-March financial year |
| BRC-010 | Dealer Filter Narrows Location List | Derivation | BR-005 | A specific dealer has been entered in the Dealer filter when the Dealer Name field is completed | Restrict the Location drop-down list to locations belonging to that dealer only | Ensures the Location list always shows only relevant options for the selected dealer, reducing the risk of selecting an incorrect location |
| BRC-011 | Location List Refreshed on Dealer Name Completion | Derivation | BR-005 | The user completes entry of the Dealer Name field | Rebuild and refresh the Location drop-down list using the current dealer filter value | Keeps the Location list current so the user always sees accurate, up-to-date options reflecting the current filter state |
| BRC-012 | Root Part Number Auto-Resolved from Part Number | Derivation | BR-006 | The user enters a value in the Part Number field and a matching record is found in the parts master | Automatically populate the Root Part Number field with the resolved root part number from the parts master | Saves the user from manually entering the root part number and reduces the risk of mismatched part/root-part combinations |
| BRC-013 | Part Number Lookup Failure Is Silent | Constraint | BR-006 | The user enters a part number that does not match any record in the parts master, or any other error occurs during the look-up | Leave the Root Part Number field unchanged and show no error message | Allows the user to enter a root part number manually without being blocked by a failed automatic look-up |
| BRC-014 | Part Identifier Required Before Stock Search | Validation | BR-007, BR-008 | The user triggers the stock search (by toggling the checkbox or navigating to the results area) but neither Part Number nor Root Part Number has been entered | Display *"Please enter Part Number or Root Part Number to get details"*, move the cursor to the Part Number field, and abort the search | Prevents the form from running a stock query that would return no meaningful results, guiding the user to supply the required part identifier |
| BRC-015 | Root Part Number Must Be Resolved for Stock Load | Validation | BR-007, BR-008 | The stock detail loader is called for a dealer/location combination but the Root Part Number has not been resolved | Raise an error via the standard null-check routine, move the cursor to the Root Part Number field, and stop loading stock for that combination | Ensures the stock query always runs against a valid root part number; prevents an unresolved identifier from causing incomplete or empty results |
| BRC-016 | Stock Filter Controls Inclusion of Zero-Stock Rows | Derivation | BR-007, BR-008 | The "Stock > 0" checkbox is selected when the stock search runs | Include only stores where the calculated net stock is greater than zero in the results grid | Allows users to focus on stores that actually have available stock, reducing noise from zero-stock entries |
| BRC-017 | Stock Results Scoped to Dealer and Location Filters | Derivation | BR-007, BR-008 | The Dealer and/or Location filters are set when the stock search runs | Restrict the locations searched to those matching the specified dealer, location, or combination of both | Narrows search results to the relevant scope and improves query performance by avoiding a full-network scan when more specific criteria are available |

**Total Business Rules Identified: 17**

---

## 6. Data Requirements

*This section covers the data entities, capture requirements, reference data, and lifecycle for the PE_LOC_STOCK part location stock enquiry form.*

### 6.1 Business Entities and Relationships

*The form queries and displays part stock data held in the stock master, with supporting information from the parts master, store master, and MRP pricing table; a dealer location master provides the dealer and location reference data used for filtering.*

#### Part Stock - PM_STOCK (via B_PM_STOCK)

The Part Stock entity holds the stock position for each part at each dealer location and store. The form reads current stock quantities (local and other-stock quantities, float stock, allocated quantity, reserved quantities), year-to-date receipt and issue quantities, open stock, values, and currency from this entity. All stock data shown in the results grid is sourced from PM_STOCK, joined with the store master and the MRP pricing table.

#### Parts Master - PM_PART

The Parts Master holds the catalogue of all parts recognised by the system, including the part number, description, and root part number hierarchy. The form uses PM_PART in two ways: to resolve a root part number from a user-entered part number (in the search filter look-up), and to retrieve the list of all part variants sharing a given root part number for the stock search query.

#### Dealer Location - AM_DEALER_LOC

The Dealer Location entity holds the mapping of dealers to their physical locations, including location code, location description, dealer code, dealer name, parent group, and principal mapping. The form uses this entity to populate the Location filter list and to identify which dealer/location combinations to include in the stock search.

#### Store Master - GM_STORE

The Store Master holds descriptive information about each store within a dealer/location combination, including the store code and store description. The form reads store descriptions from GM_STORE when loading stock detail rows into the results grid.

#### Part MRP Pricing - PI_PM_PART_MRP

The Part MRP Pricing entity holds the manufacturer's recommended price for each part, organised into pricing batches. The form retrieves the most recent pricing batch for each part to populate the recommended price column in the stock results.

#### Entity Relationships

The stock results displayed by this form are assembled by joining the Part Stock entity with the Store Master (on store code, dealer code, location code, and financial area), the Part MRP Pricing entity (on part number, using the most recent batch number), and the Parts Master (on root part number and principal). The Dealer Location master is referenced separately as a filter source to determine which dealer/location combinations to query.

```
AM_DEALER_LOC (dealer/location reference - filter source)
        │ (provides dealer_map_cd, loc_cd per search scope)
        └── PM_STOCK (part stock per dealer/location/store)
                ├── GM_STORE (store description - joined on stores_cd, dealer_map_cd, loc_cd, comp_fa)
                └── PI_PM_PART_MRP (recommended price - joined on part_num, max batch_num)

PM_PART (parts master - used for root-part look-up and part-variant iteration)
        └── PM_STOCK (stock rows matched to PM_PART.part_num via root_part_num)
```

### 6.2 Data Capture Requirements

*The form captures search filter inputs from the user; all results fields are read-only and auto-populated from the database. No data is inserted or updated through this form - it is a read-only enquiry form.*

#### Search Filters (User - before stock search)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Dealer Name (`DEALER_NAME`) | No | The name of the dealer to filter stock results by. Used as a display aid; the dealer code is used for the actual query. | Selected from the Dealer Name / Code lookup (LV_DEALER); used to narrow the Location list and the stock search scope. |
| Dealer (`DEALER`) | No | The numeric dealer code corresponding to the selected dealer. Filters the location list and stock results to a specific dealer when provided. | Must correspond to a valid dealer in the dealer/location master for the current principal and parent group. If blank, all dealers in the group are included. |
| Location (`LOCATION`) | No | The location code selected from the Location drop-down list. Filters stock results to a specific location when provided. | Populated from the Location list refreshed after dealer name entry; if blank, all locations are included. |
| Part Number (`PART_NUM`) | Conditional | The specific part number to search stock for. At least one of Part Number or Root Part Number must be provided to run the stock search. | At least one of Part Number or Root Part Number must be entered before the stock search can proceed. If entered, the system uses it to auto-resolve the Root Part Number. |
| Root Part Number (`ROOT_PART_NUM`) | Conditional | The root part number grouping all variant parts for the search. At least one of Part Number or Root Part Number must be provided. | Required before the stock detail loader runs; auto-populated from the parts master when a Part Number is entered; can be entered manually. |
| Stock > 0 (`STOCK_CHK`) | No | A checkbox that, when selected, restricts results to stores with positive current stock only. When not selected, all stores are included. | Toggle value; determines whether zero-stock rows are included in the results grid. |

#### Session / Globals (System - form context)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The principal organisation code for the current user's session. Scopes all queries to the correct principal. | Set externally before the form opens; used in all database queries as a mandatory filter. |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The parent group code for the current session. Used to scope dealer/location lookups and stock queries to the correct organisational group. | Set externally before the form opens; used in dealer location and stock queries. |
| Dealer (`GLOBAL.DEALER`) | Auto-Populated | The default dealer code for the current session. Used as a fallback dealer in part look-up queries when no specific dealer is entered. | Set externally before the form opens; used as `nvl(:cb_dummy.dealer, :GLOBAL.dealer)` in the parts master look-up. |
| Company Financial Area (`GLOBAL.COMP_FA`) | Auto-Populated | The company financial area code for the current session. Scopes stock and store queries to the correct financial area. | Set externally before the form opens; used as a mandatory filter in the stock and store queries. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Name / Code lookup (`LV_DEALER` LOV backed by `RG_DEALER` record group, sourced from `AM_DEALER_LOC`) | Provides the list of dealers and their codes available to the current user's principal and parent group | When the user opens the Dealer Name lookup to select a dealer, and when the Location list is refreshed after dealer name entry |
| Dealer Location master (`AM_DEALER_LOC`) | Provides dealer names, location codes, and location descriptions for the current principal and parent group; used to build the Location filter list and to determine which dealer/location combinations to query during the stock search | When the Location filter list is refreshed (after Dealer Name entry) and when the stock search iterates over dealer/location combinations |
| Parts master (`PM_PART`) | Holds part numbers, descriptions, and root part number hierarchy; used to resolve a root part number from a user-entered part number and to retrieve part variants for the stock search | When the user leaves the Part Number field, and when the stock detail loader retrieves part variants for a given root part number |
| Store master (`GM_STORE`) | Provides store descriptions for each store code within a dealer/location; used to populate the Stores column in the stock results grid | When the stock detail loader populates results rows from the cur_stk cursor |
| Part MRP pricing (`PI_PM_PART_MRP`) | Holds the manufacturer's recommended price per part per pricing batch; the most recent batch is used to populate the Part MRP column in the results | When the stock detail loader populates results rows from the cur_stk cursor |

### 6.4 Data Lifecycle

*Describes how records are accessed within this form's evidenced behaviour. This is a read-only enquiry form; no records are created, updated, or deleted through it.*

**Creation**

- No records are created by this form. All data displayed is retrieved from existing database records.

**Updates**

- The form does not update any database records. The only write operation is to the copyright display field (`CB_DUMMY.COPY_RIGHT`), which is a session-only, non-database field populated by the SF_COPYRIGHT_DECLARATION function when the form is cleared.
- All stock results fields in the results grid are non-database items populated programmatically from query results and are not persisted.

**Save and Commit**

- The KEY-COMMIT trigger (BR-003) provides a save capability; however, since all result-grid items are defined as non-database items (`databaseItem = false`), the commit primarily applies to any session-level or control-block values. After a successful commit, the form is cleared automatically.
- If the Save button is not enabled, the commit trigger has no effect.

**Retention and Audit**

- The form does not implement any audit stamps (created-by, modified-by, timestamps) in the form layer; no create/modify tracking is evidenced in the form's triggers or program units.
- No archival or purge policy is implemented by or referenced from this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ALLOC_QTY | Allocated quantity - the number of units of a part reserved for open job cards or repair orders and therefore not available for free sale | Allocated Stock | Current Stock, Float Stock |
| AM_DEALER_LOC | Dealer and location master table - maps each dealer to its branch locations within a parent group | Dealer Location Table | Dealer, Location, Parent Group |
| B_PM_STOCK | Stock results data block in the pe_loc_stock form - displays up to 15 rows of stock detail per dealer, location, and store | - | Block, PM_STOCK |
| CB_DUMMY | Control (search criteria) block in the pe_loc_stock form - holds the part number, root part number, dealer, and location filter fields; not bound to a database table | Search Block | Block, Part Number, Root Part Number |
| COMP_FA | Company financial authority code - session variable that scopes stock queries to the correct financial entity | - | Parent Group, Principal |
| Dealer | A franchised outlet or dealership registered in the DMS and identified by a dealer map code | Dealership | Dealer Map Code, Location, Parent Group |
| Dealer Map Code | Numeric identifier assigned to a dealer within the parent group; used as the primary key for dealer references across stock and location tables | DEALER_MAP_CD | Dealer, Location |
| DMS | Dealer Management System - the integrated software platform for managing dealership operations including parts, service, and sales | - | pe_loc_stock, Parts, Stock |
| DPL | DPL shared program library - the PL/SQL library attached to the pe_loc_stock form that provides reusable alert, validation, list population, and error-handling procedures | DPL.pld | PLD, CHECK_NULL, DISP_TEXT, RAISE_ERROR |
| Float Stock | Quantity of a part in transit or temporarily allocated between stores; included in gross stock but not available for immediate sale | OS Float Stock, LS Float Stock | Current Stock, ALLOC_QTY |
| LOV | List of Values - a popup selection list presented to the user to choose a valid value for a field | Dropdown, Picklist | RG_DEALER, LV_DEALER |
| LV_DEALER | Dealer LOV - the List of Values popup in pe_loc_stock that presents all dealers and locations within the current parent group | - | LOV, RG_DEALER |
| MRP | Maximum Retail Price - the manufacturer's recommended retail price for a part, sourced from the latest pricing batch | Part MRP, PART_MRP | pi_pm_part_mrp, Part Number |
| OLB | Oracle Object Library - a file containing shared property classes, visual attributes, and object groups subclassed by form modules | DPL.olb | DPL, Property Class |
| Parent Group | The top-level dealer group code that scopes all dealers, locations, and stock queries to the logged-in organisation | PARENT_GROUP | Dealer, Principal |
| Part Number | Alphanumeric identifier for a specific spare part within the DMS parts catalogue | PART_NUM | Root Part Number, PM_PART |
| Parts Manager | The role responsible for overseeing parts stock levels, replenishment, and dealer inventory across locations | - | Parts User, Stock Enquiry |
| Parts User | The front-line user of the pe_loc_stock screen; enters search criteria and reviews stock results | - | Parts Manager, Location Stock Enquiry |
| PCK | PL/SQL database package - a compiled set of stored procedures and functions in the Oracle database called from Oracle Forms | .pck | Package, Procedure |
| pe_loc_stock | Oracle Forms module name for the Location Stock Enquiry screen; displays stock positions across dealers, locations, and stores | PE_LOC_STOCK | DMS, Parts, Stock |
| pi_pm_part_mrp | Parts MRP pricing table - stores manufacturer retail price batches by part number; the latest batch is used in the stock enquiry results | - | MRP, Part Number |
| PLD | PL/SQL program library - a shared set of Oracle Forms PL/SQL routines attached to form modules at design time | .pld | DPL, Procedure |
| PM_PART | Parts master database table - records part numbers, root part numbers, descriptions, and principal associations | - | Part Number, Root Part Number |
| PM_STOCK | Parts stock database table - stores current, float, allocated, and reserved stock quantities by dealer, location, store, and part number | pm_Stock | Stock, B_PM_STOCK |
| Principal | The principal organisation map code - used as a secondary scope filter to restrict parts and location queries in multi-org deployments | Principal Map Code, PRINCIPAL | Parent Group, Dealer |
| RG_DEALER | Record group in the pe_loc_stock form that holds the SQL query result for the dealer and location list of values | - | LOV, LV_DEALER |
| Root Part Number | The parent part number under which a family of variant parts is grouped; the mandatory search key for the location stock enquiry | ROOT_PART_NUM | Part Number, PM_PART |
| Stock > 0 Filter | The STOCK_CHK checkbox on the pe_loc_stock screen; when checked, restricts the results grid to stores with net available stock greater than zero | STOCK_CHK | Current Stock, Filter |
| Store | A physical warehouse or storage location within a dealer branch, identified by a store code; the lowest-level inventory unit | STORES_CD | Dealer, Location, Stock |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pe_part (PE_PART)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DPL (DPL.pld program library), D2KWUTIL, DMS_EXCEL_REPORT
- First Navigation Block: -
- Console Window: WN_MAIN - Part Help (Rel : 2.3.11)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PK_PART_SEARCH_NEW
- Source artifacts: `pe_part_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DPL (DPL.pld program library); D2KWUTIL; DMS_EXCEL_REPORT; PCK `PK_PART_SEARCH_NEW.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed into the form context; used to scope form behaviour to the calling application |
| CATG_CD | Char | Trigger | Part category code used to filter part search results by category |
| COMP_FA | Char | ProgramUnit / Trigger | Company/financial authority code used to scope queries by organisation |
| CURRENCY | Char | Trigger | Currency code for the current session; used to display and convert pricing values |
| DEALER | Number | ProgramUnit / RecordGroup / Trigger | Current dealer map code set at session start for filtering dealer-specific records |
| EXIT_FLAG | Char | Trigger | Flag indicating whether the form should exit after returning a selected part to the calling form |
| FROM_REC | Number | ProgramUnit / Trigger | Starting record number for the current page of search results; used for pagination navigation |
| LANDED_COST | Number | Trigger | Landed cost value of the currently selected part; passed back to the calling form on exit |
| LOC_CD | Char | ProgramUnit / Trigger | Location code for the current session; used to filter stock and pricing by branch location |
| MCAT_CD | Char | Trigger | Main category code of the currently selected part; passed back to the calling form on exit |
| MIN_ORD_QTY | Number | Trigger | Minimum order quantity of the currently selected part; passed back to the calling form on exit |
| MRP_1 | Number | Trigger | Maximum retail price (MRP) of the currently selected part; passed back to the calling form on exit |
| ON_HAND_QTY | Number | Trigger | Current on-hand stock quantity of the selected part; passed back to the calling form on exit |
| PARA_PART_NUM | Char | Trigger | Part number parameter used to pre-populate the part search field when the form is called from another form |
| PARA_ROOT_PART_NUM | Char | Trigger | Root part number parameter used to pre-populate the root part filter when the form is called from another form |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent dealer group code used to scope all queries to the logged-in group |
| PART_DESC | Char | Trigger | Description of the currently selected part; passed back to the calling form on exit |
| PART_NUM | Char | Trigger | Part number of the currently selected part; passed back to the calling form on exit |
| PRINCIPAL | Number | ProgramUnit / RecordGroup / Trigger | Principal map code used to filter parts and locations by principal organisation |
| PURCHASE_PRICE | Number | Trigger | Purchase price of the currently selected part; passed back to the calling form on exit |
| P_FIN_YR | Char | Trigger | Financial year parameter used to scope pricing and stock queries to the correct fiscal period |
| ROOT_PART_NUM | Char | Trigger | Root part number of the currently selected part; passed back to the calling form on exit |
| SELL_PRICE | Number | Trigger | Selling price of the currently selected part; passed back to the calling form on exit |
| STORES_CD | Char | Trigger | Store code for the current session; used to filter stock queries by physical store or warehouse |
| TO_REC | Number | ProgramUnit / Trigger | Ending record number for the current page of search results; used for pagination navigation |
| USERID | Char | ProgramUnit / Trigger | Database user ID of the logged-in user; used for audit and session-scoping purposes |
| USER_NAME | Char | Trigger | Display name of the logged-in user; shown in form header or used in audit fields |
| VOR_YN | Char | Trigger | Vehicle-off-road indicator of the currently selected part; passed back to the calling form on exit |
| V_FINAL_WHERE_CLAUSE | Char | ProgramUnit / Trigger | Dynamically constructed final WHERE clause applied to the PM_PART block query after all filter criteria are assembled |
| V_ORG_WHERE_CLAUSE | Char | Trigger | Original or base WHERE clause template used as the starting point before dynamic filter criteria are appended |

### 8.1.2 Form Parameters

*All 8 ModuleParameter entries from pe_part_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_CONSG_CD | Char | - | Consignment code passed into the form at startup; used to scope part searches to a specific consignment context |
| P_APP_ID | Char | - | Application identifier passed at startup; used to set the APP_ID global and tailor form behaviour to the calling application |
| P_LS_FACTOR | Number | - | Local-currency selling price factor passed at startup; applied when calculating or displaying local sell prices |
| P_OS_FACTOR | Number | - | Overseas-currency selling price factor passed at startup; applied when calculating or displaying overseas sell prices |
| P_SRL_NUM | Number | 0 | Serial number parameter passed at startup; default of 0 indicates no pre-selected record; used to navigate directly to a specific part record |
| P_FINAL_WHERE_CLAUSE | Char | - | Pre-built final WHERE clause passed from the calling form; appended to the PM_PART block query to apply caller-defined filters |
| P_WHERE_CLAUSE | Char | - | Base WHERE clause passed from the calling form; used as the starting template for dynamic query construction |
| PRM_PART_NUM | Char | 112233 | Part number passed from the calling form to pre-populate the part search field; default value 112233 is a placeholder indicating no specific part |

**Total Parameters:** 8

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control block providing search/filter entry point for part number, root part number, category, model, store, bin location, price type, and sort order |
| PM_PART | PM_PART | 20 | Y/Y/Y/Y | Delayed | Primary data block querying the PM_PART table for part master records matching the assembled filter criteria |
| PB_BLK | - | 1 | N/N/N/N | Default | Inherited toolbar control block providing standard action buttons (save, insert, delete, cancel, print, exit, etc.) |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pe_part_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| PM_PART | Retrieves part master records from PM_PART for the current principal, filtering to rows where the dealer map code matches either the dealer or principal global, and the principal map code matches the principal global; results are ordered by root part number | root_part_num | dealer_map_cd in (:global.dealer,:global.principal)  and principal_map_cd =:global.principal |

### 8.3 Items Summary

*Complete item inventory from `pe_part_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 27 | 0 | 27 |
| PM_PART | 27 | 13 | 14 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **79** | **13** | **66** |

**Item detail (all 79 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | RECORD_START | false | Display field showing the first record number of the current page of search results; updated by pagination logic |
| CB_DUMMY | RECORD_END | false | Display field showing the last record number of the current page of search results; updated by pagination logic |
| CB_DUMMY | STORES_CD | false | Store code filter field; user-entered store code to narrow part search results to a specific store or warehouse |
| CB_DUMMY | BIN_LOC_CD_FROM | false | Bin location range start filter; user-entered lower bound of bin location code for filtering part search results |
| CB_DUMMY | BIN_LOC_CD_TO | false | Bin location range end filter; user-entered upper bound of bin location code for filtering part search results |
| CB_DUMMY | ROOT_PART_FILTER | false | Root part filter mode selector; controls whether the root part number filter is applied as an exact match or range |
| CB_DUMMY | ROOT_PART_NUM | false | Root part number search field; used to retrieve all parts classified under the specified root part |
| CB_DUMMY | PART_FILTER | false | Part number filter mode selector; controls whether the part number filter is applied as an exact match, prefix, or range |
| CB_DUMMY | PART_NUM | false | Part number search field; primary lookup field for querying parts by specific part number |
| CB_DUMMY | PART_DESC | false | Part description search field; allows user to filter parts by description text |
| CB_DUMMY | CATG_CD | false | Category code filter field; LOV-selected category code to narrow part search results by part category |
| CB_DUMMY | APPLY_MODEL_CD | false | Vehicle model filter field; LOV-selected model code to narrow part search results by applicable vehicle model |
| CB_DUMMY | SELL_PRICE | false | Sell price filter field; user-entered sell price threshold to filter parts by price |
| CB_DUMMY | ORDERBY1 | false | Primary sort order list item; user-selected column by which the search results are sorted |
| CB_DUMMY | ORDERBY | false | Hidden field holding the resolved ORDER BY clause string built from ORDERBY1 selection; passed to the dynamic query |
| CB_DUMMY | TEXT_ITEM148 | false | Unlabelled display text item; used for layout or informational purposes on the search panel |
| CB_DUMMY | TOT_REC | false | Display field showing the total number of records returned by the current search; updated after each query execution |
| CB_DUMMY | COMPARE | false | Compare mode flag or display field; used to indicate or enable side-by-side part comparison functionality |
| CB_DUMMY | PB_PREVIOUS | false | Previous page button; navigates the search results to the previous page of records |
| CB_DUMMY | PB_NEXT | false | Next page button; navigates the search results to the next page of records |
| CB_DUMMY | SORT_ORDER | false | Sort order direction selector (ascending/descending); applied together with ORDERBY1 to control result ordering |
| CB_DUMMY | STOCK_YN | false | Stock filter checkbox or flag; when active filters results to show only parts with stock on hand |
| CB_DUMMY | PRICE_TYPE | false | Price type selector; determines which price (local sell, overseas sell, MRP, etc.) is displayed in the results |
| CB_DUMMY | PUB_EXCEL | false | Publish to Excel button; triggers export of the current search results to an Excel file via WEBUTIL file transfer |
| CB_DUMMY | PB_SEARCH | false | Search button; executes the part search using the current filter criteria and populates the PM_PART block |
| CB_DUMMY | PB_PART_MAST | false | Part master button; opens the part master maintenance form for the currently selected part |
| CB_DUMMY | DISP_TEXT | false | Display text item used to show informational or status messages to the user on the search panel |
| PM_PART | SRL_NUM | true | Serial number - database-sourced sequential identifier for the part record in PM_PART |
| PM_PART | PART_NUM | true | Part number - primary identifier of the part as stored in PM_PART |
| PM_PART | ROOT_PART_NUM | true | Root part number - parent part number under which the part is classified in the parts hierarchy |
| PM_PART | STORES_CD | true | Store code - identifier of the store or warehouse where the part is primarily stocked |
| PM_PART | BIN_LOC_CD_1 | false | Bin location code - non-database display field showing the primary bin location for the part; populated via POST-QUERY |
| PM_PART | PART_DESC | true | Part description - descriptive name of the part as stored in PM_PART |
| PM_PART | PART_TAX | true | Part tax code - tax classification code for the part used in pricing and invoicing calculations |
| PM_PART | HS_CODE | true | Harmonised system code - customs classification code for the part used in import/export documentation |
| PM_PART | CATG_CD | true | Category code - classification code grouping the part into a parts category |
| PM_PART | APPLY_MODEL_CD | true | Apply model code - vehicle model code to which the part is applicable |
| PM_PART | PARTY_CD | false | Party/source code - non-database display field showing the supplier or source party code; populated via POST-QUERY or LOV |
| PM_PART | LS_SELL_PRICE | true | Local sell price - database-sourced local currency selling price of the part |
| PM_PART | CURR_STOCK | false | Current stock quantity - non-database calculated field showing net available stock for the part at the current location |
| PM_PART | FLOAT_STOCK | false | Float stock quantity - non-database field showing quantity in transit or temporarily allocated between stores |
| PM_PART | ALLOC_STOCK | false | Allocated stock quantity - non-database field showing quantity reserved for open repair orders or job cards |
| PM_PART | LANDED_COST | false | Landed cost - non-database display field showing the landed cost of the part after duties and freight |
| PM_PART | PURCHASE_PRICE | true | Purchase price - database-sourced cost price at which the part is purchased from the supplier |
| PM_PART | MRP_1 | false | Maximum retail price - non-database display field showing the MRP of the part from the latest pricing batch |
| PM_PART | MCAT_CD | false | Main category code - non-database display field showing the main category classification of the part |
| PM_PART | ITC_CD | false | ITC code - non-database display field showing the input tax credit classification code for the part |
| PM_PART | VOR_YN | false | Vehicle-off-road indicator - non-database flag indicating whether the part is classified as a VOR (vehicle off road) critical part |
| PM_PART | MIN_ORD_QTY | false | Minimum order quantity - non-database display field showing the minimum quantity required per order for the part |
| PM_PART | OS_SELL_PRICE | true | Overseas sell price - database-sourced overseas currency selling price of the part |
| PM_PART | MRP | true | MRP (database) - database-sourced maximum retail price of the part |
| PM_PART | ALL_BIN | false | All bin locations - non-database display field showing all bin location codes assigned to the part across stores |
| PM_PART | PART_STATUS | false | Part status - non-database display field showing the current status of the part (e.g. active, superseded, obsolete) |
| PM_PART | PB_CALL_FORM | false | Call form button - button item that opens a related detail or maintenance form for the currently selected part row |
| PB_BLK | PB_EXIT | false | Exit button (inherited) - closes the current form and returns to the calling form or menu |
| PB_BLK | PB_LIST | false | List button (inherited) - activates the LOV for the current field or displays a list of values |
| PB_BLK | PB_INSERT | false | Insert button (inherited) - initiates insertion of a new part record |
| PB_BLK | PM_CONT | false | Continue button - navigates or confirms continuation of the current operation in the toolbar block |
| PB_BLK | PB_DEL | false | Delete button (inherited) - marks the current record for deletion |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited) - cancels pending changes and reverts the form to its last saved state |
| PB_BLK | PB_SAVE | false | Save button (inherited) - commits all pending inserts, updates, and deletes to the database |
| PB_BLK | PB_PRINT | false | Print button (inherited) - triggers the print action for the current form or selected records |
| PB_BLK | PB_CUT | false | Cut button (inherited) - cuts the selected text or record to the clipboard |
| PB_BLK | PB_COPY | false | Copy button (inherited) - copies the selected text or record to the clipboard |
| PB_BLK | PB_PASTE | false | Paste button (inherited) - pastes clipboard content into the current field |
| PB_BLK | PB_ERR_EXIT | false | Error exit button (inherited) - exits the form in an error state, closing the error window |
| PB_BLK | NB_EXIT | false | Notification exit button - closes the notification or error overlay panel and returns focus to the main canvas |
| PB_BLK | NB_CLEAR | false | Notification clear button - clears the current message or error text displayed in the notification panel |
| PB_BLK | NB_OK | false | Notification OK button - acknowledges and dismisses the current notification or error message |
| CB_ERR | TXT_ERR | false | Error text display item (inherited from DPL OG_GROUP) - shows the error or notification message text in the CN_ERR error overlay canvas |
| WEBUTIL | DUMMY | false | WEBUTIL dummy item - placeholder item required by the WEBUTIL block to satisfy Oracle Forms block structure requirements |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WEBUTIL client info bean item - hosts the WebUtil JavaBean for retrieving client machine information |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WEBUTIL file functions bean item - hosts the WebUtil JavaBean for client-side file operations |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WEBUTIL host functions bean item - hosts the WebUtil JavaBean for executing host commands on the client |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WEBUTIL session functions bean item - hosts the WebUtil JavaBean for managing session-level client properties |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WEBUTIL file transfer bean item - hosts the WebUtil JavaBean for transferring files between server and client |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WEBUTIL OLE functions bean item - hosts the WebUtil JavaBean for OLE automation on the client |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WEBUTIL C API bean item - hosts the WebUtil JavaBean for calling native C API functions on the client |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WEBUTIL browser functions bean item - hosts the WebUtil JavaBean for controlling or querying the client browser |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CATEG | List of Parts Categories | RG_CATEG | CB_DUMMY.CATG_CD, PM_PART.SRL_NUM, PM_PART.STORES_CD, PM_PART.CATG_CD |
| LV_APPLY_MODEL | List of Models | RG_APPLY_MODEL | - |
| LV_SOURCE | List of Sources | RG_SOURCE | PM_PART.PARTY_CD |
| LV_BIN | List of Bin Locations | RG_BIN | PM_PART.BIN_LOC_CD_1 |

**Total LOVs:** 4

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Displayed by the WEBUTIL framework when a WebUtil operation (file transfer, host command, OLE, etc.) fails |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL OG_GROUP; displayed by GENERAL.DISP_TEXT or GENERAL.RAISE_ERROR to show error-level messages to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL OG_GROUP; displayed by GENERAL.DISP_TEXT to show informational messages to the user |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL OG_GROUP; displayed by GENERAL.ASK_CONFIRM to prompt the user for a yes/no confirmation |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL OG_GROUP; displayed by the DPL print-destination confirmation dialog (ASK_PRINT) |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **3 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| L_POP_LIST_ITEM | Procedure | GENERAL.L_POP_LIST_ITEM | Form-local wrapper that delegates to the DPL shared-library routine GENERAL.L_POP_LIST_ITEM; dynamically builds and populates a named list item from a record group, used to refresh dropdown lists (e.g. category, model) after filter changes |
| POPULATE_DETAILS | Procedure | PK_PART_SEARCH_NEW, GENERAL.DISP_TEXT | Executes the part search by calling the database package PK_PART_SEARCH_NEW with the assembled WHERE clause and pagination parameters (FROM_REC, TO_REC); populates the PM_PART block with the returned rows and updates TOT_REC, RECORD_START, and RECORD_END display fields; displays errors via GENERAL.DISP_TEXT |
| VIEW_EXCEL_REP | Procedure | WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST | Transfers the server-generated Excel report file to the client machine using WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, then opens it on the client using WEBUTIL_HOST.HOST; called from the PUB_EXCEL button trigger |

**Total Program Units:** 3

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT | Displays the AL_CONFIRM caution alert to prompt the user for yes/no confirmation before proceeding with a destructive or irreversible action such as exiting with unsaved changes |
| GENERAL.CHECK_NULL | Library routine | CB_DUMMY.BIN_LOC_CD_TO, CB_DUMMY.PB_SEARCH | Raises an error and halts execution if the supplied value is null, displaying the field name in the error message; used to enforce mandatory field entry before search or range validation |
| GENERAL.DISP_TEXT | Library routine | CB_DUMMY.BIN_LOC_CD_TO, CB_DUMMY.PB_PART_MAST, CB_DUMMY.PB_SEARCH, CB_DUMMY.PUB_EXCEL, CB_DUMMY.STORES_CD, Form level, PM_PART, PM_PART.PART_NUM, ProgramUnit: POPULATE_DETAILS | Displays an alert dialog with a given message text and title (Error or Note) to notify the user; used throughout the form for validation errors, informational messages, and exception handling |
| GENERAL.DROP_RECGRP | Library routine | Form level | Deletes a named record group from memory; called during form cleanup or before re-populating a record group to avoid duplicate group errors |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Dynamically builds and populates a named list item from a query or record group; used to refresh dropdown lists such as category and model filters when dependent criteria change |
| GENERAL.RAISE_ERROR | Library routine | Form level | Retrieves an error message by code and displays it via the AL_ERRINFO alert; raises FORM_TRIGGER_FAILURE for error-type messages to halt further processing |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | CB_DUMMY.PUB_EXCEL, ProgramUnit: VIEW_EXCEL_REP | Transfers a file from the application server to the client machine using the WEBUTIL file transfer mechanism; used to deliver the generated Excel report to the user's desktop |
| WEBUTIL_HOST.HOST | Library routine | CB_DUMMY.PUB_EXCEL, ProgramUnit: VIEW_EXCEL_REP | Executes a host command on the client machine; used after file transfer to open the downloaded Excel report in the client's default spreadsheet application |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Earlier implementation caught specific error codes and called GENERAL.DISP_TEXT or GENERAL.RAISE_ERROR directly; an extended version also handled optimistic lock errors and rolled back on ORA errors | Superseded by a revised active implementation with expanded error code handling and date-validation messages |
| **Inactive stub** | Form | - | FT_SAVE | Inherited toolbar save trigger; body contains no form-specific override code | Inherited from DPL OG_GROUP; form relies on PB_BLK.PB_SAVE button trigger for save behaviour instead |
| **Inactive stub** | Form | - | FT_DEL | Inherited toolbar delete trigger; body contains no form-specific override code | Inherited from DPL OG_GROUP; form relies on PB_BLK.PB_DEL button trigger for delete behaviour instead |
| **Inactive stub** | Form | - | FT_PRINT | Inherited toolbar print trigger; body contains no form-specific override code | Inherited from DPL OG_GROUP; form relies on PB_BLK.PB_PRINT button trigger for print behaviour instead |
| **Commented out** | CB_DUMMY | STORES_CD | WHEN-VALIDATE-ITEM | Earlier implementation validated the entered store code against a lookup and displayed an error if not found | Commented out; validation removed, possibly superseded by LOV-based selection or relaxed business rules |
| **Commented out** | CB_DUMMY | PB_SEARCH | WHEN-BUTTON-PRESSED | Earlier implementation of the search button trigger used a different query construction approach or called a different program unit | Commented out; superseded by the current active WHEN-BUTTON-PRESSED implementation calling POPULATE_DETAILS |
| **Commented out** | PM_PART | PART_NUM | WHEN-NEW-ITEM-INSTANCE | Earlier implementation set focus behaviour or pre-populated fields when the cursor entered the PART_NUM item | Commented out; current item-instance behaviour handled by the active WHEN-NEW-ITEM-INSTANCE trigger or removed as unnecessary |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (48 business triggers):**
*pe_part_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts form errors; displays user-friendly error text via GENERAL.DISP_TEXT; catches invalid date formats, non-numeric entry, record-update conflicts, and ORA errors; rolls back on concurrent update or unexpected SQL errors |
| ON-MESSAGE | Form | - | Form level | Intercepts form informational messages; displays message text via GENERAL.DISP_TEXT for standard Forms message codes |
| KEY-EXIT | Form | - | Form level | Exits the form; prompts for confirmation via GENERAL.ASK_CONFIRM if unsaved changes exist before closing |
| KEY-LISTVAL | Form | - | Form level | Activates the LOV popup for the current field when the list-of-values key is pressed |
| KEY-COMMIT | Form | - | Form level | Saves entered data; validates form state and commits pending changes to the database |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation and resets the search filter fields to their default state |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses or handles all other keyboard keys not explicitly mapped; inherited from DPL OG_GROUP |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Navigates focus to the next item in tab order; inherited from DPL OG_GROUP |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Navigates focus to the previous item in tab order; inherited from DPL OG_GROUP |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates focus to the next block; inherited from DPL OG_GROUP |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates focus to the previous block; inherited from DPL OG_GROUP |
| KEY-DOWN | Form | - | Form level (inherited) | Navigates focus down one record at form level; inherited from DPL OG_GROUP |
| KEY-UP | Form | - | Form level (inherited) | Navigates focus up one record at form level; inherited from DPL OG_GROUP |
| FT_SAVE | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited toolbar save trigger; no form-specific override; save behaviour handled by PB_BLK.PB_SAVE |
| FT_CANCEL | Form | - | Form level (inherited) | Cancels pending changes and reverts the form to its last committed state; inherited from DPL OG_GROUP |
| FT_INSERT | Form | - | Form level (inherited) | Initiates insertion of a new record in the current block; inherited from DPL OG_GROUP |
| FT_DEL | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited toolbar delete trigger; no form-specific override; delete behaviour handled by PB_BLK.PB_DEL |
| FT_LIST | Form | - | Form level (inherited) | Activates the LOV for the current field from the toolbar; inherited from DPL OG_GROUP |
| FT_PRINT | Form | - | Form level (inherited) | **INACTIVE STUB** - inherited toolbar print trigger; no form-specific override; print behaviour handled by PB_BLK.PB_PRINT |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises the form at startup; sets global variables from parameters, populates list items, applies the initial WHERE clause, and navigates to the first block; inherited from DPL OG_GROUP with form-specific extensions |
| PRE-FORM | Form | - | Form level | Executes before the form is displayed; sets session globals (USERID, PARENT_GROUP, PRINCIPAL, DEALER, etc.) from the database session context and incoming parameters |
| WHEN-VALIDATE-ITEM | CB_DUMMY | STORES_CD | CB_DUMMY.STORES_CD | Validates the entered store code; displays an error via GENERAL.DISP_TEXT if the code is not valid for the current dealer/location context |
| WHEN-VALIDATE-ITEM | CB_DUMMY | BIN_LOC_CD_TO | CB_DUMMY.BIN_LOC_CD_TO | Validates that BIN_LOC_CD_TO is greater than or equal to BIN_LOC_CD_FROM when both are entered; calls GENERAL.CHECK_NULL and GENERAL.DISP_TEXT on range violation |
| KEY-NEXT-ITEM | CB_DUMMY | SELL_PRICE | CB_DUMMY.SELL_PRICE | Overrides default tab navigation from the SELL_PRICE field; navigates focus to the next logical search filter item |
| WHEN-LIST-CHANGED | CB_DUMMY | ORDERBY1 | CB_DUMMY.ORDERBY1 | Responds to user selection of a sort column from the ORDERBY1 list; updates the hidden ORDERBY field with the corresponding ORDER BY clause string |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_PREVIOUS | CB_DUMMY.PB_PREVIOUS | Navigates to the previous page of search results; decrements FROM_REC and TO_REC globals and calls POPULATE_DETAILS to reload the PM_PART block |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_NEXT | CB_DUMMY.PB_NEXT | Navigates to the next page of search results; increments FROM_REC and TO_REC globals and calls POPULATE_DETAILS to reload the PM_PART block |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PUB_EXCEL | CB_DUMMY.PUB_EXCEL | Exports the current search results to an Excel file; calls VIEW_EXCEL_REP to transfer and open the server-generated report on the client via WEBUTIL; displays errors via GENERAL.DISP_TEXT |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_SEARCH | CB_DUMMY.PB_SEARCH | Executes the part search using the current filter criteria; assembles the dynamic WHERE clause, resets pagination globals, and calls POPULATE_DETAILS; validates mandatory fields via GENERAL.CHECK_NULL and displays errors via GENERAL.DISP_TEXT |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_PART_MAST | CB_DUMMY.PB_PART_MAST | Opens the part master maintenance form (CALL_FORM) for the currently selected part; passes the part number and relevant context parameters; displays an error via GENERAL.DISP_TEXT if no part is selected |
| KEY-UP | PM_PART | - | PM_PART | Navigates focus to the previous record in the PM_PART block; overrides default KEY-UP to manage pagination boundary behaviour |
| POST-QUERY | PM_PART | - | PM_PART | Fires after each row is fetched into the PM_PART block; populates non-database display fields (CURR_STOCK, FLOAT_STOCK, ALLOC_STOCK, LANDED_COST, MRP_1, MCAT_CD, ITC_CD, VOR_YN, MIN_ORD_QTY, ALL_BIN, PART_STATUS, PARTY_CD, BIN_LOC_CD_1) by querying related tables |
| KEY-DOWN | PM_PART | - | PM_PART | Navigates focus to the next record in the PM_PART block; overrides default KEY-DOWN to manage pagination boundary behaviour |
| WHEN-NEW-ITEM-INSTANCE | PM_PART | PART_NUM | PM_PART.PART_NUM | Fires when focus enters the PART_NUM item in PM_PART; sets the PART_NUM global variable to the current row value to support return-to-caller functionality |
| WHEN-BUTTON-PRESSED | PM_PART | PB_CALL_FORM | PM_PART.PB_CALL_FORM | Opens a related detail or maintenance form for the currently highlighted part row; passes part number and context globals to the called form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Exits the form; prompts for confirmation via GENERAL.ASK_CONFIRM if unsaved changes exist; returns selected part details to the calling form via globals before closing |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Activates the LOV for the currently focused item when the List toolbar button is pressed |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Initiates insertion of a new part record in the PM_PART block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Marks the current PM_PART record for deletion after confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Cancels all pending inserts, updates, and deletes in the current block and reverts to the last committed state |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Commits all pending changes in the form to the database |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Triggers the print action for the current form view or selected part records |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected text or field value to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected text or field value to the clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes clipboard content into the currently focused field |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Closes the notification or error overlay panel (CN_ERR canvas) and returns focus to the main canvas |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears the current message or error text displayed in the TXT_ERR item of the CN_ERR notification panel |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Acknowledges and dismisses the current notification or error message displayed in the CN_ERR overlay panel |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Part Help (Rel : 2.3.11) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR (inherited) |
| CN_TOOL | Vertical Toolbar | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in pe_part_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in pe_part_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pe_part_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*29 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pe_part_fmb.xml.*

#### PM_PART (29 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| APPLY_MODEL_CD | VARCHAR2 |
| CATG_CD | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| DEALER_MAP_CD | NUMBER |
| EFF_FROM_DATE | DATE |
| EFF_TO_DATE | DATE |
| LANDED_COST | NUMBER |
| MIN_ORD_QTY | NUMBER |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MRP_1 | NUMBER |
| PART_DESC | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| PRINCIPAL_MAP_CD | NUMBER |
| PURCHASE_PRICE | NUMBER |
| SELL_PRICE | NUMBER |
| SOURCE_CD | VARCHAR2 |
| UOM_CD | VARCHAR2 |
| ROOT_PART_NUM | VARCHAR2 |
| SEQ_NUM | NUMBER |
| TYPE_CD | VARCHAR2 |
| SUB_TYPE_CD | VARCHAR2 |
| TAG_CD | VARCHAR2 |
| MUL_YN | VARCHAR2 |
| VOR_YN | VARCHAR2 |
| SUB_CATG1_CD | VARCHAR2 |
| SUB_CATG2_CD | VARCHAR2 |
| BRAND_CD | VARCHAR2 |

**Total DataSourceColumns:** 29 across 1 blocks

## 9. Object Library

*The form references two Object Library (OLB) files: the shared DPL library (`DPL_olb.xml`) containing standard Visual Attributes, Property Classes, and common trigger templates used across all dealer management forms; and the WebUtil library (`webutil_olb.xml`) providing client-side utility object groups. The form's own module declares one Object Group (`OG_GROUP`).*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check box items | referenced from DPL_olb.xml | Check box items |
| VA_RB | VisualAttribute | Visual attribute for radio button items | referenced from DPL_olb.xml | Radio button items |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons | referenced from DPL_olb.xml | Iconic push button items |
| VA_DESC | VisualAttribute | Visual attribute for description/label text items | referenced from DPL_olb.xml | Description display items |
| VA_NUM | VisualAttribute | Visual attribute for numeric display items | referenced from DPL_olb.xml | Numeric text items |
| VA_MAND | VisualAttribute | Visual attribute for mandatory entry fields | referenced from DPL_olb.xml | Mandatory input items |
| VA_OPROMPT | VisualAttribute | Visual attribute for optional field prompts | referenced from DPL_olb.xml | Optional prompt labels |
| VA_MPROMPT | VisualAttribute | Visual attribute for mandatory field prompts | referenced from DPL_olb.xml | Mandatory prompt labels |
| VA_TEXT | VisualAttribute | Visual attribute for standard text entry items | referenced from DPL_olb.xml | Text input items |
| VA_BUTN | VisualAttribute | Visual attribute for standard push buttons | referenced from DPL_olb.xml | Push button items |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialog text | referenced from DPL_olb.xml | Alert items |
| VA_TITLE | VisualAttribute | Visual attribute for form and block title items | referenced from DPL_olb.xml | Title display items |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date items | referenced from DPL_olb.xml | Date transaction items |
| VA_LOV | VisualAttribute | Visual attribute for LOV-backed text items | referenced from DPL_olb.xml | LOV input items |
| VA_DISP | VisualAttribute | Visual attribute for read-only display items | referenced from DPL_olb.xml | Display-only items |
| PC_DESC | PropertyClass | Property class for description text items | referenced from DPL_olb.xml | Description items |
| PC_SC_DATE | PropertyClass | Property class for date items | referenced from DPL_olb.xml | Date input items |
| PC_TITLE | PropertyClass | Property class for title text items | referenced from DPL_olb.xml | Title text items |
| PC_FORMAT | PropertyClass | Property class for formatted text items | referenced from DPL_olb.xml | Formatted input items |
| PC_MR_BLK | PropertyClass | Property class for master/record block items | referenced from DPL_olb.xml | Block-level items |
| PC_DISP | PropertyClass | Property class for read-only display text items | referenced from DPL_olb.xml | Display text items |
| PC_LOV | PropertyClass | Property class for list-of-values items | referenced from DPL_olb.xml | LOV-backed items |
| PC_FORM | PropertyClass | Property class for form-level properties | referenced from DPL_olb.xml | Form module |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items | referenced from DPL_olb.xml | Date display items |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items | referenced from DPL_olb.xml | Numeric display items |
| PC_DATE | PropertyClass | Property class for date entry items | referenced from DPL_olb.xml | Date entry items |
| PC_DTTIME | PropertyClass | Property class for date and time items | referenced from DPL_olb.xml | Date/time items |
| PC_CB | PropertyClass | Property class for check box items | referenced from DPL_olb.xml | Check box items (STOCK_CHK) |
| PC_ALERT | PropertyClass | Property class for alert items | referenced from DPL_olb.xml | Alert items |
| PC_MDATE | PropertyClass | Property class for mandatory date items | referenced from DPL_olb.xml | Mandatory date items |
| PC_RB | PropertyClass | Property class for radio button items | referenced from DPL_olb.xml | Radio button items |
| PC_WIND | PropertyClass | Property class for windows | referenced from DPL_olb.xml | Window objects |
| PC_CANV | PropertyClass | Property class for canvas objects | referenced from DPL_olb.xml | Canvas objects |
| PC_BUTN | PropertyClass | Property class for push button items | referenced from DPL_olb.xml | Push button items |
| PC_TEXT | PropertyClass | Property class for standard text items | referenced from DPL_olb.xml | Standard text items |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | referenced from DPL_olb.xml | Mandatory text items |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | referenced from DPL_olb.xml | Uppercase input items |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | referenced from DPL_olb.xml | Mandatory uppercase items |
| PC_NUM | PropertyClass | Property class for numeric items | referenced from DPL_olb.xml | Numeric input items |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | referenced from DPL_olb.xml | Mandatory numeric items |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons | referenced from DPL_olb.xml | Iconic button items |
| PC_SCROLL | PropertyClass | Property class for scroll bar items | referenced from DPL_olb.xml | Scroll bar items |
| WEBUTIL | ObjectGroup | WebUtil object group containing all client-side utility components needed for web deployment (file transfer, session monitoring, OLE, C API) | referenced from webutil_olb.xml | WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil object group variant without OLE support, for deployments where OLE integration is not required | referenced from webutil_olb.xml | WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS |
| OG_GROUP | ObjectGroup | Form-level object group declared in the PE_LOC_STOCK form module | 1 (form module) | Form-level object group |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_BIN | Query | LV_BIN | BIN_DESC | BIN_LOC_CD | No | Lists all available bin locations (by description) for the user to select and populate the bin location field on a part record | LV_BIN -> PM_PART.BIN_LOC_CD_1 |
| RG_APPLY_MODEL | Query | LV_APPLY_MODEL | LINE_DESC | LINE_CD | No | Lists all applicable model lines (by description) for the user to select a model line association when filtering or assigning parts | LV_APPLY_MODEL |
| RG_CATEG | Query | LV_CATEG | CATG_DESC | CATG_CD | No | Lists all part categories (by description) for the user to select a category, driving population of the category code across the dummy control block and part detail fields | LV_CATEG -> CB_DUMMY.CATG_CD, PM_PART.SRL_NUM, PM_PART.STORES_CD, PM_PART.CATG_CD |
| RG_SOURCE | Query | LV_SOURCE | PARTY_NAME | PARTY_CD | No | Lists all source parties (by name) for the user to select a supply source and return the corresponding party code to the part record | LV_SOURCE -> PM_PART.PARTY_CD |

**Total Record Groups:** 4

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | BIN_LOC_CD_FROM, BIN_LOC_CD_TO, ROOT_PART_NUM, PART_NUM | No |
| PM_PART | PM_PART | PART_NUM, ROOT_PART_NUM, ITC_CD | Yes |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-NEW-FORM-INSTANCE | Dealer and location master - maps dealers to their branch locations for the parent group; queried at form startup to initialise dealer/location context. |
| `AM_DEALER_LOC_PARAM` | - | Trigger WHEN-NEW-FORM-INSTANCE | Dealer-location parameter table; supplies default parameter values for the current dealer and location during form initialisation. |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Standard Oracle single-row dummy table; used in WHEN-BUTTON-PRESSED to evaluate expressions or generate values (e.g. sequence retrieval, sysdate) without a real base-table query. |
| `GM_LINE` | - | RG_APPLY_MODEL | General-model line master; populates the RG_APPLY_MODEL record group with the list of applicable model lines for part-to-model association. |
| `GM_PARTY` | - | RG_SOURCE | General-model party master; populates the RG_SOURCE record group with valid source parties (e.g. principals/suppliers) available for selection. |
| `GM_STORE` | - | Trigger WHEN-NEW-FORM-INSTANCE | General-model store master; queried at form startup to resolve and validate the store(s) accessible to the current dealer and location. |
| `PI_PART_PRICE_MASTER` | - | POPULATE_DETAILS | Part price master; accessed by the POPULATE_DETAILS procedure to retrieve current pricing information for a given part number and dealer/principal combination. |
| `PI_PM_PART_MRP` | - | POPULATE_DETAILS | Part MRP (Maximum Retail Price) table; accessed by the POPULATE_DETAILS procedure to fetch MRP details associated with a part for display or validation. |
| `PM_APPLY_MODEL` | - | Trigger WHEN-NEW-FORM-INSTANCE | Parts-to-model applicability master; queried during form initialisation to load or validate which vehicle models a part is applicable to. |
| `PM_BIN_LOC` | - | RG_BIN | Parts bin-location master; populates the RG_BIN record group with valid bin location codes for the current store, supporting bin-range selection on the form. |
| `PM_CATEGORY` | - | RG_CATEG, Trigger WHEN-NEW-FORM-INSTANCE | Parts category master; populates the RG_CATEG record group with valid part categories and is also queried at form startup to initialise category-related defaults. |
| `PM_PART` | - | PM_PART, POPULATE_DETAILS, Trigger KEY-NEXT-ITEM | Parts master - holds part numbers, root part numbers, and descriptions by dealer and principal; drives the PM_PART block, detail population, and next-item key validation. |
| `PM_PART_VAR` | - | Trigger WHEN-BUTTON-PRESSED | Parts variant table; queried in WHEN-BUTTON-PRESSED to retrieve or validate part variant information (e.g. alternate part numbers or supersession details) for the selected part. |
| `PM_REP_CTRL` | - | Trigger WHEN-BUTTON-PRESSED | Parts replication control table; accessed in WHEN-BUTTON-PRESSED to check or update replication control flags governing how part data is synchronised across locations. |
| `PM_STOCK` | - | Trigger POST-QUERY | Parts stock table - stores current, float, allocated, and reserved stock quantities by dealer, location, store, and part number; queried in POST-QUERY to enrich displayed records with live stock figures. |

**Total Referenced Objects:** 15

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | GENERAL.DISP_TEXT | Displays formatted error and message text to the user during error handling and informational messaging |
| BR-001 | GENERAL.RAISE_ERROR | Raises a named business error code when a referential integrity or application constraint is violated |
| BR-003 | GENERAL.CHECK_NULL | Validates that a required field value is not null before a search or validation proceeds |
| BR-005 | GENERAL.L_POP_LIST_ITEM | Rebuilds a named record group from a supplied query at form initialisation and within the local wrapper program unit |
| - | POPULATE_DETAILS | Retrieves full stock and pricing detail records for a part filtered by principal, dealer, location, store, and bin location; populates the detail block |
| - | PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW | Cleans up temporary or session-scoped part-search working data for a given principal on form cancellation, exit, detail population, and Excel export |
| - | PK_PART_SEARCH_NEW.PART_DETAILS | Retrieves full stock detail records for a part filtered by parent, principal, company/FA, dealer, location, stores code, and bin location; used for detail block population and Excel export |
| - | PK_PART_SEARCH_NEW.ROWCOUNT_NEW | Calculates and returns the total number of rows matching the current part-search criteria before detail retrieval |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatcher; routes WHEN-CUSTOM-ITEM-EVENT processing to the appropriate internal WebUtil handler |
| - | WEBUTIL_C_API.ID_NULL | Tests whether a native C-API handle is null; guards against operating on invalid handles in L_POP_LIST_ITEM and VIEW_EXCEL_REP |
| - | SF_GET_PRICE | Standalone function; returns the current selling price for a given part/dealer combination for display or validation |
| - | SF_GET_STORE_BIN_LOC | Standalone function; returns the bin location code for a given store, used to resolve bin-location context |
| - | SF_GET_STORE_NAME | Standalone function; returns the store description for a given store code for display purposes |
| - | SP_GET_PART_SELL_PRICE_ONE | Standalone procedure; retrieves the single applicable selling price for one part/dealer record |
| - | SP_GET_STORES_STOCK | Standalone procedure; retrieves consolidated stock quantities across stores for a given part and dealer/location |
| - | VIEW_EXCEL_REPORT_NEW | Form-level or standalone program unit; orchestrates generation and client-side delivery of the Excel stock report |

> **Note on inactive/commented routines:** `GENERAL.CHECK_FORM_FAILURE`, `GENERAL.ASK_CONFIRM`, `GENERAL.DROP_RECGRP`, `WEBUTIL.FILE_SAVE_DIALOG`, `WEBUTIL.URL_TO_CLIENT`, and `WEBUTIL.HOST` appear only in commented or inactive trigger code in the form XML. They are catalogued in Section 12.2 for completeness but are not active in the current form build. `SF_COPYRIGHT_DECLARATION` and `POP_STOCK_DETAILS` from the prior module are absent from the new inventory and are not carried forward.

---

### 12.2 Procedure and Package Catalogue

#### GENERAL (Package - DPL attached library)

The `GENERAL` package is part of the DPL attached library (`DPL.pld` / `DPL.pll`). It provides common utility routines used across all dealer management forms for error display, null validation, form-failure checking, and list population.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package procedure | `POPULATE_DETAILS` program unit; Trigger: KEY-DOWN in PM_PART; Trigger: KEY-UP in PM_PART; Trigger: ON-ERROR (Form); Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_PART_MAST; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL; Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.BIN_LOC_CD_TO | Displays an alert dialog box with the supplied text and title; uses AL_ERRINFO for Error-titled messages and AL_NOTE for all others; called across error handling and informational messaging throughout the form |
| GENERAL.RAISE_ERROR | Package procedure | Trigger: ON-ERROR (Form) | Formats an error message string using the supplied code, displays it via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE when the message type is Error; used in ON-ERROR to surface database constraint violations |
| GENERAL.CHECK_NULL | Package procedure | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH; Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.BIN_LOC_CD_TO | Validates that the supplied value is not null; if null, displays "Enter a valid {column_title}" error message and raises FORM_TRIGGER_FAILURE; enforces that required fields are populated before a search or validation proceeds |
| GENERAL.L_POP_LIST_ITEM | Package procedure | Program unit: L_POP_LIST_ITEM (Form); Trigger: WHEN-NEW-FORM-INSTANCE (Form) | Drops any existing record group with the given name and creates a new one from the supplied SQL query string, then populates it; used to dynamically refresh list items at form initialisation and within the local wrapper program unit |
| GENERAL.CHECK_FORM_FAILURE | Package procedure *(inactive - commented-only)* | Trigger: KEY-COMMIT (Form) - *inactive* | Checks whether the last Forms statement succeeded; if the operation failed due to an ORA or FRM error, displays the error message via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE to halt the save sequence; currently inactive in the form |
| GENERAL.ASK_CONFIRM | Package function *(inactive - commented-only)* | Trigger: FT_CANCEL (Form); Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT; Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY - *all inactive* | Presents a confirmation dialog to the user with the supplied message and returns a numeric response code; referenced in exit and cancel paths to prompt the user before discarding unsaved changes; currently inactive in the form |
| GENERAL.DROP_RECGRP | Package procedure *(inactive - commented-only)* | Trigger: KEY-CLRFRM (Form) - *inactive* | Drops the record group associated with the supplied block name, releasing its resources; referenced in the clear-form trigger to clean up dynamically created record groups; currently inactive in the form |

---

#### PK_PART_SEARCH_NEW (Database package - PK_PART_SEARCH_NEW.pck)

Provides part-search query routines invoked by the form to locate stock items by part criteria. Encapsulates search logic, row-count calculation, and cleanup so that the form retrieves matching part/location stock records without embedding ad-hoc SQL in form triggers.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW | Package procedure | Trigger: FT_CANCEL (Form); Trigger: KEY-EXIT (Form); Program unit: POPULATE_DETAILS; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Cleans up temporary or session-scoped part-search working data for the given principal (`p_principal VARCHAR2`). Called on form cancellation, exit, detail population, and Excel export to ensure no stale search records persist across operations |
| PK_PART_SEARCH_NEW.PART_DETAILS | Package procedure | Program unit: POPULATE_DETAILS; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Retrieves full stock detail records for a part filtered by parent, principal, company/FA, dealer, location, stores code, and bin location (`pi_parent`, `pi_principal`, `pi_comp_fa`, `pi_dealer`, `pi_loc_cd`, `pi_stores_cd`, `pi_bin_loc_cd`, ...). Populates the detail block with matching inventory lines and is also invoked during Excel export to supply the data set for the spreadsheet output |
| PK_PART_SEARCH_NEW.ROWCOUNT_NEW | Package procedure | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH | Calculates and returns the total number of rows matching the current part-search criteria (`p_parent`, `p_dealer`, `p_loc_cd`, `p_comp_fa`, `p_principal`, `p_stores_cd`, `p_bin_loc_cd_from`, ...). Executed when the user initiates a search via PB_SEARCH to determine result-set size before detail retrieval |

---

#### POPULATE_DETAILS (Form-level program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POPULATE_DETAILS | Form program unit (procedure) | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH; other internal call sites within the form | Retrieves full stock and pricing detail records for a part filtered by principal, dealer, location, store, and bin location. Accesses `PM_PART`, `PI_PART_PRICE_MASTER`, and `PI_PM_PART_MRP`; invokes `PK_PART_SEARCH_NEW.PART_DETAILS` and `PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW`; displays messages via `GENERAL.DISP_TEXT`; populates the detail block with matching inventory lines |

---

#### L_POP_LIST_ITEM (Form-level program unit - wrapper)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| L_POP_LIST_ITEM | Form program unit (procedure) | Trigger: WHEN-NEW-FORM-INSTANCE (Form) and other internal call sites | Local wrapper around `GENERAL.L_POP_LIST_ITEM`; calls `WEBUTIL_C_API.ID_NULL` to guard against invalid handles before delegating to the library routine to rebuild a named record group from a supplied SQL query |

---

#### VIEW_EXCEL_REPORT_NEW (Form-level or standalone program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REPORT_NEW | Program unit (procedure) | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Orchestrates generation and client-side delivery of the Excel stock report. Invokes `PK_PART_SEARCH_NEW.PART_DETAILS` to obtain the data set, uses `WEBUTIL_C_API.ID_NULL` to validate handles, and references `WEBUTIL.FILE_SAVE_DIALOG`, `WEBUTIL.URL_TO_CLIENT`, and `WEBUTIL.HOST` in the export/transfer path (currently inactive in the form build) |

---

#### Standalone Database Functions and Procedures

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_PRICE | Standalone function | POPULATE_DETAILS program unit; Trigger: POST-QUERY in PM_PART (inferred from Section 11/Section 21 evidence) | Returns the current selling price for a given part and dealer/principal combination; used for price display or validation within the detail population flow |
| SF_GET_STORE_BIN_LOC | Standalone function | POPULATE_DETAILS program unit; Trigger: WHEN-NEW-FORM-INSTANCE (Form) (inferred from Section 21 evidence) | Returns the bin location code for a given store; used to resolve bin-location context during form initialisation and detail retrieval |
| SF_GET_STORE_NAME | Standalone function | POPULATE_DETAILS program unit; Trigger: WHEN-NEW-FORM-INSTANCE (Form) (inferred from Section 21 evidence) | Returns the store description for a given store code; used for display purposes in the store selection and detail population flow |
| SP_GET_PART_SELL_PRICE_ONE | Standalone procedure | POPULATE_DETAILS program unit (inferred from Section 21 evidence) | Retrieves the single applicable selling price for one part/dealer record; supplements SF_GET_PRICE for cases requiring a single-row price lookup |
| SP_GET_STORES_STOCK | Standalone procedure | POPULATE_DETAILS program unit; Trigger: POST-QUERY in PM_PART (inferred from Section 21 evidence) | Retrieves consolidated stock quantities across stores for a given part and dealer/location combination; supplies net, float, and allocated stock figures to the detail block |

---

#### WEBUTIL_CORE (Package - webutil.pld attached library)

The `WEBUTIL_CORE` package is part of the WebUtil attached library (`webutil.pld`). It provides the central event-dispatch infrastructure for all WebUtil bean items in the WEBUTIL block.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Package procedure | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; WEBUTIL.WEBUTIL_C_API_FUNCTIONS; WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; WEBUTIL.WEBUTIL_FILE_FUNCTIONS; WEBUTIL.WEBUTIL_HOST_FUNCTIONS; WEBUTIL.WEBUTIL_OLE_FUNCTIONS; WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher; receives the event name and its serialised parameters from each WebUtil bean item and routes processing to the appropriate internal WebUtil handler; fired by WHEN-CUSTOM-ITEM-EVENT on every WebUtil functional-area bean item in the WEBUTIL block |

---

#### WEBUTIL_C_API (Package - webutil.pld attached library)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_C_API.ID_NULL | Package function | Program unit: L_POP_LIST_ITEM; Program unit: VIEW_EXCEL_REP | Tests whether a native C-API handle is null; returns TRUE when the supplied pointer is uninitialised or has been released; guards against operating on invalid handles before making further C-API calls in list population and Excel export |

---

#### WEBUTIL - Inactive / Commented-Only Routines (webutil.pld)

The following WebUtil routines are referenced only in commented or inactive trigger and program-unit code in the form XML. They are catalogued here for completeness and potential future activation.

| Procedure/Package | Type | Called From (inactive) | Purpose |
| ----------------- | ---- | ---------------------- | ------- |
| WEBUTIL.FILE_SAVE_DIALOG | Package function *(inactive)* | Program unit: VIEW_EXCEL_REP; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Presents a native client-side Save File dialog pre-seeded with directory, filename, filter, and title; returns the fully qualified path chosen by the user, or NULL if cancelled; referenced in the Excel export path to obtain the client destination before transferring the generated report file |
| WEBUTIL.URL_TO_CLIENT | Package function *(inactive)* | Program unit: VIEW_EXCEL_REP; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Downloads a file from the supplied server-side URL to the specified client-side destination path; returns TRUE on success; referenced in the Excel export flow to deliver the generated report to the client machine |
| WEBUTIL.HOST | Package function *(inactive)* | Program unit: VIEW_EXCEL_REP; Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Executes the supplied operating-system command on the client machine and returns an integer exit code; referenced in the Excel export flow to open or process the transferred report file on the client |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PK-PART-SEARCH-NEW | Pk_Part_Search_New | Provides part-search query routines invoked by the form to locate stock items by part criteria (e.g. part number, description, location). Encapsulates the search logic so that the form retrieves matching part/location stock records without embedding ad-hoc SQL in form triggers. | The form must invoke `Pk_Part_Search_New` to execute part-based stock searches, ensuring that all search filtering, ranking, and result-set construction are performed within the package rather than in client-side form logic. | Given valid search parameters supplied by the form, `Pk_Part_Search_New` returns the correct set of matching part/location stock records; given invalid or out-of-range parameters, the package returns an empty result set or raises a handled exception without causing an unhandled form error. |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

**Source PCK file(s):** PK_PART_SEARCH_NEW.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PK_PART_SEARCH_NEW.pck | Pk_Part_Search_New | delete_part_search_new | Procedure | PROCEDURE delete_part_search_new(p_principal VARCHAR2) | FT_CANCEL in Form, KEY-EXIT in Form, ProgramUnit: POPULATE_DETAILS, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Cleans up temporary or session-scoped part-search working data for the given principal. Called on form cancellation, exit, detail population, and Excel export to ensure no stale search records persist across operations. |
| PK_PART_SEARCH_NEW.pck | Pk_Part_Search_New | part_details | Procedure | PROCEDURE part_details(pi_parent IN VARCHAR2, pi_principal IN NUMBER, pi_comp_fa IN VARCHAR2, pi_dealer IN NUMBER, pi_loc_cd IN VARCHAR2, pi_stores_cd IN VARCHAR2, pi_bin_loc_cd... | ProgramUnit: POPULATE_DETAILS, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Retrieves full stock detail records for a part filtered by parent, principal, company/FA, dealer, location, stores code, and bin location. Populates the detail block with matching inventory lines and is also invoked during Excel export to supply the data set for the spreadsheet output. |
| PK_PART_SEARCH_NEW.pck | Pk_Part_Search_New | rowcount_new | Procedure | PROCEDURE rowcount_new(p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc_cd IN VARCHAR2, p_comp_fa IN VARCHAR2, p_principal IN NUMBER, p_stores_cd IN VARCHAR2, p_bin_loc_cd_from I... | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH | Calculates and returns the total number of rows that match the current part-search criteria (parent, dealer, location, company/FA, principal, stores code, bin location range). Executed when the user initiates a search via PB_SEARCH to determine result set size before detail retrieval. |

**Total Matched Package Routines (called from form XML):** 3

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.BIN_LOC_CD_TO | Validates that the supplied value is not null; if null, displays "Enter a valid {column_title}" error message and raises FORM_TRIGGER_FAILURE; used to enforce that required fields are populated before a search or validation proceeds. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: POPULATE_DETAILS, Trigger: KEY-DOWN in PM_PART, Trigger: KEY-UP in PM_PART, Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_PART_MAST, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.BIN_LOC_CD_TO | Displays an alert dialog box with the supplied text and title; uses AL_ERRINFO for Error-titled messages and AL_NOTE for all others; called across error handling and informational messaging throughout the form. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE in Form | Drops any existing record group with the given name and creates a new one from the supplied SQL query string, then populates it; used to dynamically refresh list items at form initialisation and within the local wrapper program unit. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Formats an error message string using the supplied code, displays it via GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE when the message type is Error; used in ON-ERROR to surface database constraint violations. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_part_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message and returns a numeric response code; referenced in exit and cancel paths to prompt the user before discarding unsaved changes, but currently inactive in the form. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the last Forms statement succeeded; if the operation failed due to an ORA or FRM error, displays the error message via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE to halt the save sequence; currently inactive in the form. |
| DROP_RECGRP | Procedure | Procedure(block_name VARCHAR2) | Trigger: KEY-CLRFRM in Form | Drops the record group associated with the supplied block name, releasing its resources; referenced in the clear-form trigger to clean up dynamically created record groups, but currently inactive in the form. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 3

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher; receives the event name and its serialised parameters from each WebUtil bean item and routes processing to the appropriate internal WebUtil handler; fired by WHEN-CUSTOM-ITEM-EVENT on every WebUtil functional-area bean item in the WEBUTIL block. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | Tests whether a native C-API handle is null; returns TRUE when the supplied pointer is uninitialised or has been released; used within L_POP_LIST_ITEM and VIEW_EXCEL_REP to guard against operating on invalid handles before making further C-API calls. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_part_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Presents a native client-side Save File dialog pre-seeded with the supplied directory, filename, filter, and title; returns the fully qualified path chosen by the user, or NULL if the dialog is cancelled; referenced in the Excel export path to obtain the client destination before transferring the generated report file. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_part_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Downloads a file from the supplied server-side URL to the specified client-side destination path; the optional fileSize parameter hints at the expected transfer size; returns TRUE on success; referenced in the Excel export flow to deliver the generated report to the client machine. |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_part_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PUB_EXCEL | Executes the supplied operating-system command on the client machine and returns an integer exit code; referenced in the Excel export flow to open or process the transferred report file on the client, but currently inactive in the form. |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Part Stock Enquiry Service | PM_STOCK, GM_STORE, PI_PM_PART_MRP, PM_PART | rootPartNumber, dealerCode (optional), locationCode (optional), principalCode, parentGroup, companyFinancialArea, stockPositiveOnly (boolean) | List of stock detail rows: storeCode, storeDescription, locationCode, locationDescription, dealerCode, dealerName, partNumber, partDescription, currentStock, floatStock, allocatedStock, partMRP | Retrieves current stock quantities, float stock, allocated stock, and the manufacturer's recommended price for all part variants of a given root part number across the specified dealer/location scope | GET /api/parts/stock-enquiry |
| MS-002 | Root Part Number Resolution Service | PM_PART | partNumber, dealerCode (optional), principalCode | rootPartNumber | Looks up the root part number corresponding to an entered part number in the parts master, scoped to the current principal and dealer | GET /api/parts/{partNumber}/root |
| MS-003 | Dealer Location List Service | AM_DEALER_LOC | principalCode, parentGroup, dealerCode (optional) | List of locations: locationCode, locationDescription, dealerCode, dealerName | Retrieves the list of dealer locations for the current principal and parent group, optionally filtered to a specific dealer, ordered alphabetically by location description | GET /api/dealers/locations |
| MS-004 | Copyright Declaration Service | System date (no DB table) | currentDate | copyrightText (string) | Returns the formatted copyright notice string for the current period, using the previous calendar year for January-March and the current calendar year otherwise | GET /api/system/copyright |
| MS-005 | Form Error Display Service | GENERAL package (DPL library) | errorText, severity | N/A (side effect: message displayed) | Presents a formatted error or informational message to the user; used by error-handling and validation routines throughout the form | POST /api/notifications/display |
| MS-006 | Named Business Error Service | GENERAL package (DPL library) | errorCode | businessErrorMessage | Looks up and raises a named application error by code (e.g. referential integrity violation error 'E0088'), returning the corresponding business error message | GET /api/errors/{errorCode} |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Part Location Stock Enquiry | User enters search criteria (dealer, location, part number, root part number) and toggles the Stock checkbox or navigates to the results area | 1. User optionally selects a dealer and location from the filter fields. 2. User enters a part number; system auto-resolves the root part number. 3. User sets the Stock > 0 filter if desired. 4. User toggles the stock checkbox (or navigates to the results area). 5. System validates that at least one part identifier is present. 6. System clears previous results and iterates over applicable dealer/location combinations. 7. System calls the stock detail loader for each combination. 8. System populates the results grid with stock quantities, descriptions, and recommended prices. 9. System positions the display on the first result row. | Is at least one of Part Number / Root Part Number entered? (if not -> error, abort). Is Root Part Number resolved for each dealer/location combination? (if not -> error, skip that combination). Is Dealer filter set? (narrows location scope). Is Location filter set? (further narrows location scope). Is Stock > 0 filter active? (restricts rows to positive stock only). | Results grid populated with stock details across all applicable dealer/location combinations; display positioned on first row |
| WF-002 | Location Filter Refresh | User completes entry of the Dealer Name field | 1. User enters or changes the Dealer Name in the search filter. 2. System builds a location query scoped to the current principal and parent group. 3. If a specific dealer is also entered, the query is restricted to that dealer's locations. 4. System rebuilds the Location list data source from the query. 5. System refreshes the Location drop-down with the new list. | Is a specific dealer entered? (yes -> restrict location list to that dealer; no -> show all locations in the group). | Location drop-down refreshed with current applicable locations |
| WF-003 | Root Part Number Auto-Resolution | User leaves the Part Number field after entering a value | 1. User enters a part number and leaves the field (or presses the forward-navigation key). 2. System queries the parts master for the root part number matching the entered part number, scoped to the current principal and dealer. 3. If found, the Root Part Number field is populated with the resolved value. 4. If not found or any error occurs, the Root Part Number field is left unchanged (silent). 5. When the user presses the forward-navigation key, the cursor additionally advances to the Root Part Number field after the look-up. | Was a matching root part number found? (yes -> populate Root Part Number; no -> leave unchanged silently). Was the action a forward-navigation key press? (yes -> also move cursor to Root Part Number field). | Root Part Number field populated (or unchanged if not found); cursor in Root Part Number field when navigation key was used |
| WF-004 | Form Save and Clear | User presses the save key | 1. System checks whether the Save button is currently enabled. 2. If enabled, system enters the current record and checks for form errors. 3. If no errors, system commits the data to the database. 4. System checks that the commit succeeded. 5. If commit succeeded, system clears the form for the next use. | Is the Save button enabled? (no -> ignore key press; yes -> proceed). Did enter step succeed? (no -> display error, abort). Did commit succeed? (no -> display error, leave form open). | Form cleared and ready for next enquiry (on success); form remains open with error message displayed (on failure) |
| WF-005 | Form Exit Without Save | User presses the exit key | 1. User presses the exit key. 2. System closes the form immediately, discarding any unsaved changes. | None | Form closed; no changes saved |
| WF-006 | Form Clear and Copyright Refresh | User triggers the clear-form action | 1. User triggers the clear-form action (presses the clear key). 2. System clears all data from the form without saving. 3. System retrieves the current copyright text using the financial-year-aware copyright function. 4. System writes the copyright text to the copyright display field. | Is the current month January, February, or March? (yes -> use previous calendar year in copyright; no -> use current calendar year). | Form cleared; copyright notice updated with correct year |

**Total Workflows Identified: 6**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

*No routines from ``webutil.pld`` are referenced in ``pe_loc_stock_fmb.xml``.*


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When a Forms operation fails with an ORA or FRM error, then execution is halted and the error message is displayed to the user |
| PLD-002 | CHECK_NULL | Validation | ProgramUnit: POP_STOCK_DETAILS | /api/v1/pld/check_null | When a required field value is null, then an error message is shown and execution is stopped before stock details are populated |
| PLD-003 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-CHECKBOX-CHANGED in CB_DUMMY.STOCK_CHK, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_PM_STOCK | /api/v1/pld/disp_text | Displays an alert dialog with the supplied message and title to communicate error or informational notifications to the user |
| PLD-004 | l_pop_list_item | Business Logic | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.DEALER_NAME | /api/v1/pld/l_pop_list_item | Dynamically refreshes a list item by dropping and recreating its record group from the supplied SQL query, enabling runtime-filtered dropdown lists |
| PLD-005 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a database error code is encountered, then an error message is looked up, displayed to the user, and execution is halted |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pe_loc_stock_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``pe_loc_stock_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Part Stock Query (PM_STOCK) | Oracle table - SELECT | Retrieves stock quantities (local stock, other stock, float stock, allocated stock, reserved quantities) for parts at specified dealer/location/store combinations | Form -> PM_STOCK (read-only SELECT via cur_stk cursor in POP_STOCK_DETAILS) | Errors surfaced through ON-ERROR trigger; WHEN OTHERS in outer query loops cause processing to stop for the affected combination |
| Parts Master Lookup (PM_PART) | Oracle table - SELECT | Resolves root part numbers from entered part numbers, and retrieves all part variants (part number, description) for a given root part number | Form -> PM_PART (read-only SELECT in WHEN-VALIDATE-ITEM and KEY-NEXT-ITEM triggers, and in cur_part cursor of POP_STOCK_DETAILS) | WHEN OTHERS -> NULL in item-level triggers (silent); errors in POP_STOCK_DETAILS surfaced through root part number null-check |
| Store Master Query (GM_STORE) | Oracle table - SELECT | Retrieves store descriptions for each store code within dealer/location combinations, for display in the results grid | Form -> GM_STORE (read-only SELECT joined with PM_STOCK in cur_stk cursor of POP_STOCK_DETAILS) | Errors surfaced through ON-ERROR trigger |
| Part MRP Pricing Query (PI_PM_PART_MRP) | Oracle table - SELECT | Retrieves the most recent manufacturer's recommended price for each part variant displayed in the results grid | Form -> PI_PM_PART_MRP (read-only SELECT joined with PM_STOCK in cur_stk cursor of POP_STOCK_DETAILS, using max batch_num subquery) | Errors surfaced through ON-ERROR trigger |
| Dealer Location Query (AM_DEALER_LOC) | Oracle table - SELECT | Retrieves dealer/location combinations for the stock search scope, and supplies data for the Location filter drop-down list | Form -> AM_DEALER_LOC (read-only SELECT in WHEN-VALIDATE-ITEM on Dealer Name, WHEN-CHECKBOX-CHANGED on Stock checkbox, and WHEN-NEW-BLOCK-INSTANCE on B_PM_STOCK) | Errors surfaced through ON-ERROR trigger |
| DPL Utility Library (GENERAL package) | Attached PL/SQL library | Provides shared utility procedures for error display (GENERAL.DISP_TEXT), named error raising (GENERAL.RAISE_ERROR), form-failure checking (GENERAL.CHECK_FORM_FAILURE), null validation (GENERAL.CHECK_NULL), and list item population (GENERAL.L_POP_LIST_ITEM) | Form -> GENERAL package routines (call-only; no data returned except status/messages) | Errors in DISP_TEXT and RAISE_ERROR are surfaced to the user as messages; CHECK_FORM_FAILURE raises FORM_TRIGGER_FAILURE on detected failure |
| Copyright Declaration Function (SF_COPYRIGHT_DECLARATION) | Standalone PL/SQL function | Returns the correct financial-year copyright string for display in the copyright field when the form is cleared | Form -> SF_COPYRIGHT_DECLARATION (read-only function call returning a VARCHAR2 string) | Function always returns a valid string; no error path evidenced |

### 20.2 External System Integrations

This form has no external system integrations. All data access is to the local Oracle database via direct SQL queries and attached PL/SQL library calls. No cross-form navigation, external file access, report calls, or connections to external systems are evidenced in the form's triggers or program units.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| N/A | N/A | No external system integrations | N/A | N/A | N/A | N/A |

### 20.3 Report Integrations

No report calls are evidenced in this form. The `reference_data.reports` list is empty and no `RUN_PRODUCT`, `run_report`, or equivalent report-launch call appears in any active trigger or program unit.

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| N/A | N/A | N/A | N/A | N/A |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PE_PART form.

### 21.1 Catalogue Index

90 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--POPULATE_DETAILS) | POPULATE_DETAILS |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-011](#SP-011--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-013](#SP-013--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-014](#SP-014--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-015](#SP-015--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-016](#SP-016--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-017](#SP-017--PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW) | PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW |
| [SP-018](#SP-018--PK_PART_SEARCH_NEW.PART_DETAILS) | PK_PART_SEARCH_NEW.PART_DETAILS |
| [SP-019](#SP-019--PK_PART_SEARCH_NEW.ROWCOUNT_NEW) | PK_PART_SEARCH_NEW.ROWCOUNT_NEW |
| [SP-020](#SP-020--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-021](#SP-021--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-023](#SP-023--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-024](#SP-024--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-027](#SP-027--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-028](#SP-028--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-029](#SP-029--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-030](#SP-030--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-031](#SP-031--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-032](#SP-032--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-033](#SP-033--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-034](#SP-034--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-035](#SP-035--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-037](#SP-037--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-038](#SP-038--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-039](#SP-039--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-040](#SP-040--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-041](#SP-041--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-042](#SP-042--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-043](#SP-043--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-044](#SP-044--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-045](#SP-045--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-046](#SP-046--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-047](#SP-047--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-048](#SP-048--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-049](#SP-049--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-050](#SP-050--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-051](#SP-051--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-052](#SP-052--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-053](#SP-053--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-054](#SP-054--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-055](#SP-055--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-056](#SP-056--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-057](#SP-057--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-058](#SP-058--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-059](#SP-059--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-061](#SP-061--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-062](#SP-062--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-063](#SP-063--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-064](#SP-064--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-066](#SP-066--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-067](#SP-067--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-068](#SP-068--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-069](#SP-069--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-070](#SP-070--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-071](#SP-071--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-072](#SP-072--ADD_ERROR) | ADD_ERROR |
| [SP-073](#SP-073--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-074](#SP-074--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-075](#SP-075--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-076](#SP-076--DEBUGLOG) | DEBUGLOG |
| [SP-077](#SP-077--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-078](#SP-078--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-079](#SP-079--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-080](#SP-080--READ_REGISTRY) | READ_REGISTRY |
| [SP-081](#SP-081--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-082](#SP-082--SETDEBUG) | SETDEBUG |
| [SP-083](#SP-083--SF_GET_PRICE) | SF_GET_PRICE |
| [SP-084](#SP-084--SF_GET_STORE_BIN_LOC) | SF_GET_STORE_BIN_LOC |
| [SP-085](#SP-085--SF_GET_STORE_NAME) | SF_GET_STORE_NAME |
| [SP-086](#SP-086--SP_GET_PART_SELL_PRICE_ONE) | SP_GET_PART_SELL_PRICE_ONE |
| [SP-087](#SP-087--SP_GET_STORES_STOCK) | SP_GET_STORES_STOCK |
| [SP-088](#SP-088--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-089](#SP-089--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-090](#SP-090--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - POPULATE_DETAILS

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Retrieves and displays part details for a range of records on the PART HELP screen. When triggered by a button press, the procedure clears the PM_PART block, calls the back-end search package to fetch a paginated set of parts, enriches each row with the most current MRP from PI_PM_PART_MRP and consignment pricing from PI_PART_PRICE_MASTER where applicable, resolves all bin locations via SF_GET_STORE_BIN_LOC, flags closed parts with zero stock, and renders the results in the PM_PART block in read-only mode.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW ([SP-017](#SP-017--PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW)) - PK_PART_SEARCH_NEW.pck (or .pld)
- PK_PART_SEARCH_NEW.PART_DETAILS ([SP-018](#SP-018--PK_PART_SEARCH_NEW.PART_DETAILS)) - PK_PART_SEARCH_NEW.pck (or .pld)
- SF_GET_STORE_BIN_LOC ([SP-084](#SP-084--SF_GET_STORE_BIN_LOC)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Enable insert and update on the PM_PART block temporarily to allow programmatic population.
- Step 2 - Read the current pagination window from global variables (:GLOBAL.from_rec / :GLOBAL.to_rec) into local low/high variables; cap the high value at the total record count held in :cb_dummy.tot_rec to prevent over-fetching.
- Step 3 - Call PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW passing :GLOBAL.principal to purge any previously staged search results for the principal.
- Step 4 - Construct the ORDER BY clause by concatenating :cb_dummy.orderby and :cb_dummy.sort_order.
- Step 5 - Call PK_PART_SEARCH_NEW.PART_DETAILS with the full set of filter and pagination parameters (parent group, principal, company/FA, dealer, location, stores code, bin location range, where clauses, order-by, low/high bounds) to populate the PL/SQL table po_part_tab and return po_tot_rec, po_err_msg, and po_err_cd.
- Step 6 - If po_err_cd is greater than zero, display the error message via GENERAL.DISP_TEXT and disable the PUB_EXCEL button.
- Step 7 - If po_part_tab returns no rows, disable the PUB_EXCEL button, display a 'No Records retrieved' note via GENERAL.DISP_TEXT, and reset low and high to zero; otherwise enable the PUB_EXCEL button.
- Step 8 - Store the final low and high values in :cb_dummy.record_start and :cb_dummy.record_end.
- Step 9 - Disable form-level validation, navigate to the PM_PART block, and clear it without validation to remove stale rows.
- Step 10 - Iterate over each row in po_part_tab; for every row assign the serial number, part number, root part number, description, category code, local-selling price, overseas-selling price, and the col7 MRP from the result set.
- Step 11 - Attempt to retrieve the latest effective MRP for the part from PI_PM_PART_MRP (filtered by part number, principal, and maximum effective-from date); use this value if found, otherwise fall back to col7 from the result set.
- Step 12 - If the resolved MRP is zero or null and a consignment code parameter exists, query PI_PART_PRICE_MASTER for the most recent revision to derive local-selling price, overseas-selling price, and MRP using the configured LS and OS price factors; default all three to zero if the query returns no row.
- Step 13 - Assign bin location, stores code, current stock, float stock, and allocated stock from the result set row.
- Step 14 - Call SF_GET_STORE_BIN_LOC with parent group, dealer, location, part number, and stores code to populate the all-bin-locations field for the row.
- Step 15 - Query PM_PART to count active part records (tag_cd not in 1 or 3) for the current part across the principal and dealer; if such records exist and current stock is zero or less, zero out all prices and set the part status to 'Part Closed, Look for Alternate part'; otherwise set part status to blank.
- Step 16 - Advance to the next record in the block for all rows except the last.
- Step 17 - After the loop, navigate to the first record and set the PM_PART block back to insert-not-allowed and update-not-allowed to enforce read-only display.

---
**Decision Points**

DP-001
Condition: po_part_tab high value exceeds :cb_dummy.tot_rec.
TRUE: Cap the high variable at :cb_dummy.tot_rec before passing it to PK_PART_SEARCH_NEW.PART_DETAILS.
FALSE: Use the original high value from :GLOBAL.to_rec.

DP-002
Condition: po_err_cd returned by PK_PART_SEARCH_NEW.PART_DETAILS is greater than zero.
TRUE: Display the error message using GENERAL.DISP_TEXT with severity 'Error' and disable the PUB_EXCEL button.
FALSE: Continue processing the returned result set.

DP-003
Condition: po_part_tab.COUNT equals zero (no rows returned by PK_PART_SEARCH_NEW.PART_DETAILS).
TRUE: Disable the PUB_EXCEL button, display 'No Records retrieved' via GENERAL.DISP_TEXT with severity 'Note', and reset low and high to zero.
FALSE: Enable the PUB_EXCEL button and proceed to populate the PM_PART block.

DP-004
Condition: A row exists in PI_PM_PART_MRP for the current part number and principal at the maximum effective-from date.
TRUE: Use the MRP value retrieved from PI_PM_PART_MRP for the PM_PART.mrp field.
FALSE: Fall back to the MRP value in col7 of the po_part_tab result set row (via NVL).

DP-005
Condition: The resolved PM_PART.mrp is zero or null AND :parameter.p_consg_cd is not null.
TRUE: Query PI_PART_PRICE_MASTER for the latest revision to compute local-selling price, overseas-selling price, and MRP using the LS and OS price factors; default all three to zero if no row is found.
FALSE: Retain the previously resolved MRP and selling prices without querying PI_PART_PRICE_MASTER.

DP-006
Condition: PM_PART contains at least one active record (tag_cd not in 1 or 3) for the part under the current principal or dealer, AND the current stock is zero or less.
TRUE: Zero out local-selling price, overseas-selling price, and MRP for the row, and set part status to 'Part Closed, Look for Alternate part'.
FALSE: Set part status to a blank string and retain existing price values.

DP-007
Condition: The current loop iteration index i is not equal to po_part_tab.COUNT (i.e., not the last row).
TRUE: Call NEXT_RECORD to advance the block cursor.
FALSE: Do not call NEXT_RECORD; allow the loop to end naturally.

---
**Database Interactions**

- DB-001 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP for lookup or validation.
- DB-002 - Read PI_PART_PRICE_MASTER - Reads data from PI_PART_PRICE_MASTER for lookup or validation.
- DB-003 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - The pagination window must never exceed the total number of available records; the upper bound is capped at :cb_dummy.tot_rec before the search package is called.
- BR-002 - Previously staged search results for the active principal must be deleted via PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW before each new retrieval to prevent stale data from persisting in the result set.
- BR-003 - The most recently effective MRP from PI_PM_PART_MRP (determined by the maximum eff_from_dt for the part and principal combination) takes precedence over the MRP returned by the search package; the package value is used only as a fallback.
- BR-004 - When no MRP is available from either source and a consignment code is in context, local-selling price and overseas-selling price must be back-calculated from the latest PI_PART_PRICE_MASTER revision using the configured LS and OS markup factors; all three price fields default to zero if the consignment price record is absent.
- BR-005 - A part that has active PM_PART records (tag_cd not in 1 or 3) for the principal or dealer and has zero or negative current stock must have all prices zeroed and must display the status message 'Part Closed, Look for Alternate part' to prevent it from being selected for transactions.
- BR-006 - The PUB_EXCEL (export to Excel) button must be disabled whenever the search returns an error or zero records, and enabled only when at least one part row is successfully retrieved.
- BR-007 - The PM_PART block must be rendered read-only (insert and update disallowed) after population; insert and update permissions are granted only transiently during the programmatic load.
- BR-008 - Any unhandled exception raised during the PART_DETAILS call must be surfaced to the user via GENERAL.DISP_TEXT with severity 'Error' and must raise FORM_TRIGGER_FAILURE to halt further processing; unhandled exceptions in the outer block are similarly displayed before the procedure exits.

---
**Implementation Logic**

```plsql
PROCEDURE populate_details
IS
BEGIN
      DECLARE
            po_tot_rec    NUMBER (6);
            --Changed by Anjiv on 16-04-2006 to get ls_selling_price,os_selling_price,mrp
            --po_part_tab  PK_PART_SEARCH_NEW.PART_TAB_8 ;
            --Changed by Anjiv on 08/09/2006  to show bin location
            --po_part_tab   pk_part_search_new.part_tab_10;
            po_part_tab   pk_part_search_new.part_tab_11;
            po_err_msg    VARCHAR2 (3000);
            po_err_cd     NUMBER (10);
            low           NUMBER (10);
            high          NUMBER (10);
            remainder     NUMBER (10);
            order_by      VARCHAR2 (300);
            cnt						NUMBER (10) :=0;
            lv_mrp        pi_pm_part_mrp.mrp%type;
      BEGIN
            SET_BLOCK_PROPERTY ('pm_part', insert_allowed, property_true);
            SET_BLOCK_PROPERTY ('pm_part', update_allowed, property_true);
            low := :GLOBAL.from_rec;
            high := :GLOBAL.to_rec;

            --The growth rate of :global.from_rec and to_rec will be in 15,30,45..series
            --But  when evere we are passing to procedure we will control the lower and upper limit based on total number of records
            --disable the prvious button if :global.from_rec reached the first record
            --disable the next button if :global.to_rec reached the last record
            IF high > :cb_dummy.tot_rec THEN
                  high := :cb_dummy.tot_rec;
            END IF;

            pk_part_search_new.delete_part_search_new (:GLOBAL.principal);
            order_by := :cb_dummy.orderby || ' ' || :cb_dummy.sort_order;

            BEGIN
                  pk_part_search_new.part_details (:GLOBAL.parent_group,
                                                   :GLOBAL.principal,
                                                   :GLOBAL.comp_fa,
                                                   :GLOBAL.dealer,
                                                   :GLOBAL.loc_cd,
                                                   :cb_dummy.stores_cd,
                                                   :cb_dummy.bin_loc_cd_from,
                                                   :cb_dummy.bin_loc_cd_to,
                                                   --:GLOBAL.v_final_where_clause,                        --'AND PART_NUM=''GROIL'''
                                                   :parameter.p_where_clause,
                                                   :parameter.p_final_where_clause,
                                                   order_by,
                                                   low,
                                                   high,
                                                   po_tot_rec,
                                                   po_part_tab,
                                                   po_err_msg,
                                                   po_err_cd
                                                  );

                  IF po_err_cd > 0 THEN
                        general.disp_text (po_err_msg, 'Error');
                        SET_ITEM_PROPERTY ('cb_dummy.PUB_EXCEL', enabled, property_false);
                                            --Added by Anjiv on 04-08-2006 to disable the covert to excel button in case of error
                  END IF;

                  IF po_part_tab.COUNT = 0 THEN
                        SET_ITEM_PROPERTY ('cb_dummy.PUB_EXCEL', enabled, property_false);
                                    --Added by Anjiv on 04-08-2006 to disable the covert to excel button in case of zero resocrds
                        general.disp_text ('No Records retrieved', 'Note');
                        low := 0;
                        high := 0;
                  ELSE
                        SET_ITEM_PROPERTY ('cb_dummy.PUB_EXCEL', enabled, property_true);
                  END IF;
            /*
            :cb_dummy.tot_rec:=po_tot_rec;

            IF nvl(:cb_dummy.tot_rec,0) <= 20 THEN
                        SET_ITEM_PROPERTY ('cb_dummy.pb_next', enabled, property_false);
                        SET_ITEM_PROPERTY ('cb_dummy.pb_previous', enabled, property_false);
                        END IF;
                        */
            EXCEPTION
                  WHEN OTHERS THEN
                        general.disp_text (SQLERRM, 'Error');
                        RAISE form_trigger_failure;
            END;

            :cb_dummy.record_start := low;
            :cb_dummy.record_end := high;
                    /*
            if po_err_cd>0 then
                   general.disp_text('Unable to get part details'||po_err_msg,'Error');
            end if;*/
            SET_FORM_PROPERTY (:SYSTEM.current_form, VALIDATION, property_false);
            GO_BLOCK ('PM_PART');
            CLEAR_BLOCK (no_validate);                                 -- CLEARS THE OLD BLOCK WHEN THE NEW PART DETAIL IS ENTERED

            FOR i IN 1 .. po_part_tab.COUNT
            LOOP
                  :PM_PART.srl_num := :parameter.p_srl_num + i;
                  :PM_PART.part_num := po_part_tab (i).col1;
                  :PM_PART.root_part_num := po_part_tab (i).col2;
                  :PM_PART.part_desc := po_part_tab (i).col3;
                  :PM_PART.catg_cd := po_part_tab (i).col4;
                  :PM_PART.ls_sell_price := po_part_tab (i).col5;
                  :PM_PART.os_sell_price := po_part_tab (i).col6;
                  
                  /** added by sumit on 28092018  as told by aanand sir ***/  
                  begin
                  	select mrp into lv_mrp
										  from pi_pm_part_mrp ppm
										 where ppm.part_num = :PM_PART.part_num
										   and ppm.principal_map_cd = :global.principal
										   and ppm.eff_from_dt =
										       (select max(ppm1.eff_from_dt)
										          from pi_pm_part_mrp ppm1
										         where ppm1.part_num = :PM_PART.part_num
										           and ppm1.principal_map_cd = :global.principal);
                  exception when others then
                  	lv_mrp := null;
                  end;	
                  	
                  /**  end here added by sumit on 28092018 ***/ 
                  
                  :PM_PART.mrp := nvl(lv_mrp,po_part_tab (i).col7);
                  
                  
									--Added by Anjiv on 17/07/2007
                  IF NVL ( :PM_PART.mrp, 0) = 0 AND :parameter.p_consg_cd IS NOT NULL THEN
                        BEGIN
                              SELECT ROUND ((NVL ( mrp_1, 0) * 100) / (100 + NVL (:parameter.p_ls_factor, 0)), 2),
                                     ROUND ((NVL ( mrp_1, 0) * 100) / (100 + NVL (:parameter.p_os_factor, 0)), 2),
                                     mrp_1
                                INTO :PM_PART.ls_sell_price,
                                     :PM_PART.os_sell_price,
                                     :PM_PART.mrp
                                FROM PI_PART_PRICE_MASTER pi
                               WHERE consg_cd = :parameter.p_consg_cd
                                 AND part_num = :PM_PART.part_num
                                 AND revision_date = (SELECT MAX ( revision_date)
                                                        FROM PI_PART_PRICE_MASTER
                                                       WHERE part_num = pi.part_num AND consg_cd = pi.consg_cd);
                        EXCEPTION
                              WHEN OTHERS THEN
                                    :PM_PART.ls_sell_price := 0;
                                    :PM_PART.os_sell_price := 0;
                                    :PM_PART.mrp := 0;
                        END;
                  END IF;

                  :PM_PART.bin_loc_cd_1 := po_part_tab (i).col8;
                  :PM_PART.stores_cd := po_part_tab (i).col9;
                  :PM_PART.curr_stock := NVL (po_part_tab (i).col10, 0);
                  :PM_PART.float_stock := NVL (po_part_tab (i).col11, 0);
                  :PM_PART.alloc_stock := NVL (po_part_tab (i).col12, 0);
                  :PM_PART.all_bin :=
                        sf_get_store_bin_loc (:GLOBAL.parent_group,
                                              :GLOBAL.dealer,
                                              :GLOBAL.loc_cd,
                                              po_part_tab (i).col1,
                                              :cb_dummy.stores_cd
                                             );
                                          --   general.disp_text(po_part_tab (i).col13,'NOTE');

            --  general.disp_text ('Unable to populate 1' || SQLERRM, 'Error');
             :PM_PART.hs_code:= po_part_tab (i).col14;
             :PM_PART.part_tax:=po_part_tab (i).col15;
            --  general.disp_text ('Unable to populate 2' || SQLERRM, 'Error');
            BEGIN
            	SELECT count(1)
            	INTO cnt 
							FROM PM_PART
							WHERE dealer_map_cd  IN(:GLOBAL.principal,:GLOBAL.dealer)
							AND Part_num = :PM_PART.part_num
							AND tag_cd NOT IN (1,3);
							
							IF cnt > 0 and :PM_PART.curr_stock <= 0 THEN
								:PM_PART.ls_sell_price := 0;
                :PM_PART.os_sell_price := 0;
                :PM_PART.mrp := 0;
                :PM_PART.part_status := 'Part Closed, Look for Alternate part';
							ELSE
								:PM_PART.part_status := ' ';
							END IF;
            END;
            
                  IF i <> po_part_tab.COUNT THEN
                        NEXT_RECORD;
                  END IF;
            END LOOP;
      EXCEPTION
            WHEN OTHERS THEN
                  general.disp_text ('Unable to populate' || SQLERRM, 'Error');
      END;

      FIRST_RECORD;
      SET_BLOCK_PROPERTY ('pm_part', insert_allowed, property_false);
      SET_BLOCK_PROPERTY ('pm_part', update_allowed, property_false);
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying that the file exists at the supplied directory path before loading. If a path is provided, the procedure normalises it using STRIPDIRSEP, confirms the file is physically present, and then calls ORA_FFI.LOAD_LIBRARY. On success it optionally increments the package-level DLL load counter and marks the API as enabled. On any failure it marks the API as disabled and returns a null library handle, allowing the caller (REGISTER_FUNCTION_CALL) to handle the unavailable library gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-088](#SP-088--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is supplied. If it is null, skip file-existence validation and proceed directly to the library load attempt.
- Step 2 - Normalise TargetPath by passing it through STRIPDIRSEP to remove any extraneous directory separators, then append a single trailing backslash ('\') to form a well-structured directory path. This also discards any additional paths that may have been concatenated into the value.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R'). If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; the sole purpose of this operation is to confirm the file exists at the specified location.
- Step 4 - If the file cannot be opened, log a diagnostic message via DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') recording the DLL name and the path that was searched, then raise the BadLocation exception to abort the load attempt.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the library and obtain a library handle (hDLL).
- Step 6 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE, recording that a DLL was successfully loaded and that the API is available.
- Step 7 - Return the populated library handle hDLL to the caller.
- Step 8 - If any unhandled exception occurs during steps 5-6, set API_ENABLED to FALSE and return the null library handle hDLL, signalling to the caller that the load failed.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a trailing backslash, then perform file-existence validation (Steps 2-4) before attempting the library load.

FALSE: Skip path normalisation and file-existence validation; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the constructed file path (TargetPath || TargetDLL)

TRUE: Close the file handle immediately and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log a diagnostic message via DEBUGLOG and raise the BadLocation exception, aborting the load attempt.

---

DP-003

Condition: LoadCount IS TRUE (evaluated after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Return the library handle without updating the load counter or the API_ENABLED flag.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI.LOAD_LIBRARY call or the LoadCount update

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Normal execution continues; the valid library handle is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the first directory path value held in TargetPath is used; any additional concatenated paths are discarded by STRIPDIRSEP and the subsequent backslash append, ensuring a single, unambiguous load location.
- BR-002 - A trailing backslash directory separator must be present on TargetPath before the library load is attempted; STRIPDIRSEP is always called to normalise the value and the separator is then appended unconditionally.
- BR-003 - Physical existence of the DLL file must be confirmed via a read-mode TEXT_IO.FOPEN before ORA_FFI.LOAD_LIBRARY is invoked, but only when a TargetPath is provided; a null TargetPath bypasses this check.
- BR-004 - A failed file-existence check must be logged at severity level 99 through DEBUGLOG, capturing both the DLL name and the searched path, before the BadLocation exception is raised.
- BR-005 - DLL_LOAD_COUNT and API_ENABLED are updated only when the load succeeds and LoadCount is TRUE; a successful load with LoadCount FALSE leaves both package-level values unchanged.
- BR-006 - Any exception that propagates from the library load or counter update must result in API_ENABLED being set to FALSE, ensuring the calling context cannot assume the API is available after a failed load attempt.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (Open or Save) to the end user and returns the selected file path(s) in the in/out buffer. The procedure resolves special directory tokens, enforces a trailing backslash on the initial directory, applies a file-type filter, and delegates the actual dialog invocation to the lower-level D2KWUTIL.D2KWUTIL_CHOOSEFILE routine. It is invoked by D2KWUTIL.SAVE_FILE and operates only when the Win API layer is available.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-078](#SP-078--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-079](#SP-079--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all incoming arguments (CalledBy, Modal flag, title, initial directory, file filter, flags, separator character, and current buffer value) via DEBUGLOG for diagnostic traceability.
- Step 2 - Clear any previously accumulated errors from the error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return code (iRC) to 0.
- Step 4 - Determine the owner window handle: if Modal is TRUE, retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW; otherwise set the owner handle to 0 (non-modal).
- Step 5 - Verify that the Win API layer is enabled (WIN_API.API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 6 - Register the external function signature for D2KWUTIL_CHOOSEFILE using REGISTER_FUNCTION_CALL, supplying the function name and its parameter type string.
- Step 7 - Translate the CalledBy value to an operation mode integer: 'Open_File' maps to 1 (open mode); any other caller value maps to 2 (save mode).
- Step 8 - Assign the Flags parameter directly to the integer buffer iBuff2.
- Step 9 - Resolve the initial directory token in szInitDir: if the upper-cased value equals '$WINDIR$', substitute the actual Windows directory via GET_WINDOWS_DIRECTORY; if it equals '$TEMP$', substitute the temporary directory via GET_TEMP_DIRECTORY; otherwise use szInitDir as supplied.
- Step 10 - Ensure the resolved directory path ends with a backslash; if the last character is not '\', append one.
- Step 11 - Resolve the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 12 - Extract only the first character of SepChar to use as the single-character separator.
- Step 13 - Pad szBuffer with null characters (CHR(0)) to exactly 4,096 characters to prepare the output buffer for the external call, using WEBUTIL.LENGTH implicitly through the RPAD/length operations.
- Step 14 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE, passing the registered function handle, operation mode, owner window handle, title, resolved directory, file filter, flags, separator character, and padded buffer; capture the integer return code.
- Step 15 - Log the result (return code and returned buffer content) via DEBUGLOG.
- Step 16 - Write the populated buffer back to the IN OUT parameter szBuffer.
- Step 17 - Return the integer return code (iRC) to the caller.

---
**Decision Points**

DP-001

Condition: Modal IN parameter is TRUE.

TRUE: Retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it as the owner window (hwndOwner) so the dialog is modal to the current form window.

FALSE: Set hwndOwner to 0, causing the dialog to display without a modal owner.

---

DP-002

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Proceed with function registration, parameter preparation, and the external dialog call.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all dialog logic.

---

DP-003

Condition: CalledBy equals 'Open_File'.

TRUE: Set the operation mode integer (iBuff1) to 1, signalling an Open File dialog.

FALSE: Set the operation mode integer (iBuff1) to 2, signalling a Save File dialog.

---

DP-004

Condition: UPPER(szInitDir) equals '$WINDIR$'.

TRUE: Resolve the initial directory to the Windows system directory via GET_WINDOWS_DIRECTORY.

FALSE: Evaluate DP-005.

---

DP-005

Condition: UPPER(szInitDir) equals '$TEMP$'.

TRUE: Resolve the initial directory to the system temporary directory via GET_TEMP_DIRECTORY.

FALSE: Use szInitDir as supplied without substitution.

---

DP-006

Condition: The last character of the resolved directory path is not '\'.

TRUE: Append '\' to the directory path to ensure a valid trailing separator.

FALSE: Use the directory path unchanged.

---

DP-007

Condition: szFileFilter is NULL or an empty string.

TRUE: Default the file filter to 'All files(*.*)|*.*|'.

FALSE: Use the caller-supplied szFileFilter value.

---

DP-008

Condition: Exception WIN_API.NOT_AVAILABLE is raised.

TRUE: Record the error via ADD_ERROR using the WIN_API.NoAPI error code for the calling routine, then re-raise the exception to the caller.

FALSE: Not applicable (handled by the OTHERS branch).

---

DP-009

Condition: Any other (unhandled) exception is raised.

TRUE: Record the error via ADD_ERROR combining WIN_API.UError with any external errors collected by ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

FALSE: Normal execution completes without exception handling.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-chooser dialog may only be presented when the Win API layer is active (WIN_API.API_ENABLED is TRUE); if the API is unavailable the procedure raises WIN_API.NOT_AVAILABLE and no dialog is shown.
- BR-002 - The CalledBy value 'Open_File' exclusively identifies an Open File operation (mode 1); all other CalledBy values are treated as a Save File operation (mode 2).
- BR-003 - The special token '$WINDIR$' (case-insensitive) in szInitDir must be resolved to the actual Windows directory at runtime via GET_WINDOWS_DIRECTORY; it must never be passed literally to the external dialog.
- BR-004 - The special token '$TEMP$' (case-insensitive) in szInitDir must be resolved to the actual system temporary directory at runtime via GET_TEMP_DIRECTORY; it must never be passed literally to the external dialog.
- BR-005 - The resolved initial directory path must always end with a backslash ('\') before being passed to the external dialog; one is appended automatically if absent.
- BR-006 - If no file filter is provided (NULL or empty string), the dialog must default to showing all files using the filter 'All files(*.*)|*.*|'.
- BR-007 - Only the first character of the SepChar parameter is used as the file-name separator; any additional characters are silently discarded.
- BR-008 - The file-path buffer passed to the external dialog must be exactly 4,096 characters, padded with null characters (CHR(0)); this ensures sufficient capacity for multi-file selections.
- BR-009 - All invocations must be logged at debug level 99 both on entry (with all arguments) and on exit (with the return code and resulting buffer), providing a full audit trail via DEBUGLOG.
- BR-010 - On any exception, an error entry must be recorded against the CalledBy routine identifier via ADD_ERROR before the exception is re-raised, ensuring the error stack correctly attributes the failure to its originating caller.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers and exposes the external C-library function that retrieves the currently active window handle within the Oracle Forms runtime environment. The function wraps a foreign-function interface (FFI) call, accepting a pre-resolved function handle and returning a PLS_INTEGER representing the active window identifier for use by the parent utility package.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the foreign-function handle (hFunc) that has been bound by the caller (D2KWUTIL.GET_ACTIVE_WINDOW) to the underlying C-library entry point for active-window retrieval.
- Step 2 - Invoke the external function via the ORA_FFI mechanism using the supplied hFunc handle.
- Step 3 - Return the PLS_INTEGER value produced by the external call, representing the active window identifier, to the invoking routine.

---
**Decision Points**

No conditional decision points are present in this function. The implementation consists solely of a foreign-function invocation and a return of its result; no branching logic is evidenced in the available source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts exactly one input parameter (hFunc of type ORA_FFI.funcHandleType); no output parameters are defined in the signature, and the result is communicated exclusively through the function return value.
- BR-002 - The return type is PLS_INTEGER, meaning the active window identifier must be representable as a PL/SQL integer value as supplied by the underlying external library.
- BR-003 - The function carries no internal or external dependencies beyond the ORA_FFI handle passed in; the caller (D2KWUTIL.GET_ACTIVE_WINDOW) is solely responsible for resolving and providing a valid function handle before invoking this routine.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a wrapper interface to a native OS file-chooser dialog by invoking an external function handle (ORA_FFI.funcHandleType). The procedure accepts dialog configuration parameters-dialog type, owner window handle, title, initial directory, file filter, advanced flags, and a separator character-and returns the user-selected file path(s) in the szBuffer output parameter together with a PLS_INTEGER return code indicating the outcome of the dialog interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered external function handle (hFunc) that references the underlying OS file-chooser API entry point.
- Step 2 - Accept all dialog configuration inputs: dialog_type (open/save variant), hwndOwner (parent window handle), szTitle (dialog caption), szInitDir (starting directory), szFileFilter (file-type filter string), AdvancedFlags (bitmask of extended dialog options), and SepChar (character used to separate multiple selected file paths).
- Step 3 - Invoke the external function referenced by hFunc, passing all configuration parameters to the native OS file-chooser dialog.
- Step 4 - Receive the dialog result back from the OS: updated szTitle, szInitDir, szFileFilter, and szBuffer (containing the selected file path or paths delimited by SepChar) are populated as IN OUT parameters.
- Step 5 - Return a PLS_INTEGER result code to the caller reflecting whether the user confirmed a file selection or cancelled the dialog.

---
**Decision Points**

DP-001

Condition: The return value of the external function call (PLS_INTEGER) is evaluated by the caller to determine dialog outcome.

TRUE (non-zero / success): The user confirmed a file selection; szBuffer contains one or more file paths delimited by SepChar, and the IN OUT parameters reflect the final dialog state.

FALSE (zero / cancelled): The user cancelled or dismissed the dialog without selecting a file; szBuffer content is not guaranteed to contain a valid selection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function handle (hFunc) must be a valid, pre-registered ORA_FFI.funcHandleType referencing the native OS file-chooser API; no internal dependency resolution is performed within this routine.
- BR-002 - dialog_type must be supplied by the caller to distinguish between dialog variants (e.g., open vs. save); the routine does not default or validate this value internally.
- BR-003 - Multiple selected file paths are delimited in szBuffer using the character supplied in SepChar; the caller is responsible for defining and subsequently parsing on this separator.
- BR-004 - szTitle, szInitDir, szFileFilter, and szBuffer are declared IN OUT; the caller must allocate sufficient VARCHAR2 buffer length before invocation to accommodate values returned by the OS dialog.
- BR-005 - AdvancedFlags is passed directly to the external function as a bitmask; the caller is responsible for composing a valid flags value appropriate to the target OS dialog API.
- BR-006 - No database interactions occur within this routine; all processing is confined to the external OS dialog invocation and parameter marshalling.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to an underlying C-language routine within the D2KWUTIL library. It is invoked by the WINDEBUG stored procedure to relay diagnostic or debug messages from the Oracle Forms PL/SQL layer to the native D2KWUTIL C implementation, identified by the supplied function handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function entry point within the D2KWUTIL external library.
- Step 2 - Receive the debug text string (Text) to be transmitted to the external C routine.
- Step 3 - Invoke the bound C function via the ORA_FFI PRAGMA INTERFACE mechanism (interface code 11265), passing both the function handle and the text string directly to the native implementation.
- Step 4 - Return control to the calling procedure (WINDEBUG) upon completion; no output value is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation delegates unconditionally to the external C routine via the ORA_FFI interface; no conditional branching logic exists in the available specification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc) that has been previously registered and bound to the D2KWUTIL C library; the handle is not validated within this procedure.
- BR-002 - The Text parameter carries the debug string as-is to the external C routine; no transformation, truncation, or validation of the string content is performed at this layer.
- BR-003 - This procedure operates exclusively as a C-interface wrapper (PRAGMA INTERFACE, code 11265) and produces no return value, output parameters, or database side-effects.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. Given a function handle obtained via ORA_FFI, it accepts a source environment variable name and an output buffer, then delegates execution to the underlying OS-level function to expand the environment string into the supplied buffer. The integer return value indicates the outcome of the OS call.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the pre-registered OS environment-expansion function.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the OS function.
- Step 3 - Accept the destination expansion buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved environment variable value by the OS function.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum number of characters the OS function may write into ExpandStr.
- Step 5 - Invoke the OS-level function via the supplied ORA_FFI function handle, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return the PLS_INTEGER result code produced by the OS function, indicating success or the length of the expanded string to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld).

---
**Decision Points**

No explicit conditional decision points are present in the available specification. The function delegates all branching to the external OS routine invoked through the ORA_FFI handle; the return code communicates the outcome to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_FFI function handle (hFunc); the handle must have been registered prior to invocation, as no internal handle initialisation is performed within this function.
- BR-002 - ExpandStr must be pre-allocated by the caller to a length of at least InBuffLen characters to prevent buffer overrun when the OS function writes the expanded environment variable value.
- BR-003 - The integer return value is the direct result code from the OS-level call and must be evaluated by the caller (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved.
- BR-004 - Both SourceStr and ExpandStr are declared IN OUT; the caller must treat their values as potentially modified after the function returns.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that reads a Windows Registry key value. Given a registry root, path, and entry name, it retrieves the corresponding registry value into an OUT parameter and returns an integer status code indicating the outcome of the read operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld to abstract low-level OS registry access from higher-level application logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows API entry point responsible for reading registry keys.
- Step 2 - Accept the registry root identifier (RegRoot, e.g. HKEY_LOCAL_MACHINE), the registry path (RegPath), and the registry entry name (RegEntry) as inputs that together fully qualify the target registry key.
- Step 3 - Accept the maximum allowable length for the returned value (RegValueLength) and the expansion-control flag (RegDontExpand) that governs whether environment-variable placeholders within the registry value are expanded before return.
- Step 4 - Invoke the native Windows registry read operation via the ORA_FFI function handle, passing all qualified parameters.
- Step 5 - Populate the RegValue OUT parameter with the registry value string retrieved from the Windows Registry.
- Step 6 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) reflecting success or failure of the registry read attempt.

---
**Decision Points**

DP-001

Condition: Whether the RegDontExpand flag is set (non-zero) or unset (zero) when the native registry call is executed.

TRUE (RegDontExpand is non-zero): The registry value is returned exactly as stored, with no expansion of embedded environment-variable references.

FALSE (RegDontExpand is zero): Any environment-variable placeholders present in the registry value string are expanded by the OS before the value is returned in RegValue.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_FFI function handle (hFunc); the handle must have been initialised prior to invocation, as the procedure itself declares no internal or external dependencies and performs no handle setup.
- BR-002 - RegRoot must be a valid Windows Registry root constant (e.g. representing HKEY_LOCAL_MACHINE or HKEY_CURRENT_USER); no default or fallback root is applied by this function.
- BR-003 - RegValueLength must accurately reflect the maximum buffer size allocated for RegValue; supplying an insufficient length may result in a truncated or failed registry value retrieval.
- BR-004 - RegPath and RegEntry are declared IN OUT; callers must supply non-null, fully qualified values for both parameters before invocation, as the function does not construct or default either value internally.
- BR-005 - The integer return value must be inspected by the caller (READ_REGISTRY) to determine whether the registry read succeeded; this function delegates all error-state communication to that return code.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level FFI (Foreign Function Interface) wrapper function that retrieves a Windows directory path (either the Windows system directory or a temporary directory) by invoking an external native function handle. The result is written back into the WindowsDir buffer, and a PLS_INTEGER status code is returned to the caller. It is consumed exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the external native function handle (hFunc), the pre-allocated output buffer (WindowsDir), and the declared buffer length (InBuffLen) from the calling stored procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY).
- Step 2 - Delegate execution to the native Windows API function referenced by hFunc, passing WindowsDir as the target buffer and InBuffLen as its maximum capacity.
- Step 3 - Allow the external function to populate WindowsDir IN OUT with the resolved directory path string (e.g., the Windows directory or the system temporary directory).
- Step 4 - Return a PLS_INTEGER status code to the caller indicating the outcome of the native function call (typically the number of characters written or an error indicator as defined by the underlying Windows API).

---
**Decision Points**

No conditional decision points are present in the available implementation. The function signature is declarative only; all branching logic resides in the calling procedures (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY) based on the returned PLS_INTEGER status code.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI.funcHandleType handle (hFunc); the handle is prepared and supplied entirely by the calling procedure, and this function performs no handle validation itself.
- BR-002 - The caller is responsible for pre-allocating the WindowsDir buffer and supplying its length via InBuffLen before invoking this function; the function writes the directory path into the existing buffer up to InBuffLen characters.
- BR-003 - The function returns a PLS_INTEGER status code whose interpretation (success, failure, or character count) is the responsibility of the invoking procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY).
- BR-004 - This function has no direct database interactions; all side effects are confined to populating the WindowsDir OUT parameter via the native FFI call.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active window by invoking the external D2KWUTIL_ACTIVEWIN function via the WIN_API framework. The function returns the active window handle as a PLS_INTEGER. It is called by D2KWUTIL.CHOOSEFILE to identify the active window context before presenting a file-chooser dialog. If the underlying API is unavailable or the handle cannot be obtained, the function records a descriptive error and, when instructed, raises an exception to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: Call DEBUGLOG (at debug level 99) recording the procedure name 'Get_Active_Window' and the value of the RaiseExceptions input parameter, converted to a character representation via BOOLTOCHAR.
- Step 2 - Clear the error stack: Call CLEAN_ERROR_STACK to reset any previously accumulated WIN_API error messages before processing begins.
- Step 3 - Check API availability: Evaluate the WIN_API.API_ENABLED flag to determine whether the external Windows API layer is accessible.
- Step 4 - Register and invoke the external function: If the API is enabled, call REGISTER_FUNCTION_CALL to register the 'D2KWUTIL_ACTIVEWIN' function signature (return type INT, no additional argument) against the iActiveWin handle slot, then invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN passing the resolved function handle. Store the integer return code in iRC.
- Step 5 - Log the result: Call DEBUGLOG (at debug level 99) to record the return code received from D2KWUTIL.D2KWUTIL_ACTIVEWIN.
- Step 6 - Validate the returned handle: If iRC equals 0, the active window handle was not obtained; call ADD_ERROR to record the failure message 'Unable to obtain active window handle'. If RaiseExceptions is TRUE, raise NO_DATA_FOUND to propagate the failure to the caller.
- Step 7 - Return the handle: If iRC is non-zero (valid handle), return iRC to the caller.
- Step 8 - Exception handling: On NO_DATA_FOUND, re-raise immediately. On WIN_API.NOT_AVAILABLE (API not enabled), call ADD_ERROR with the standard no-API message and re-raise. On any other exception, call ADD_ERROR appending the output of ADD_EXTERNAL_ERRORS for full error context, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Register the external function via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN to retrieve the active window handle.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the local exception handler, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition: The integer return code iRC returned by D2KWUTIL.D2KWUTIL_ACTIVEWIN equals 0.

TRUE: The active window handle was not obtained; ADD_ERROR is called to record the failure. Processing then falls through to DP-003.

FALSE: The handle is valid; execution continues to return iRC to the caller without recording an error.

---

DP-003

Condition: iRC equals 0 AND RaiseExceptions is TRUE.

TRUE: Raise NO_DATA_FOUND so the caller is notified of the failure to obtain the active window handle.

FALSE: Suppress the exception; the function returns 0 to the caller, with the error recorded on the error stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must clear the WIN_API error stack at the start of every invocation to ensure error messages from prior calls do not contaminate the current operation.
- BR-002 - The external Windows API must be available (WIN_API.API_ENABLED = TRUE) before any attempt is made to retrieve the active window handle; if the API is unavailable the operation must be aborted and an error recorded.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_ACTIVEWIN is treated as a failure condition indicating that no valid active window handle was obtained; this must always be recorded as an error via ADD_ERROR.
- BR-004 - Exception propagation on a zero-handle result is controlled by the RaiseExceptions input parameter; callers that require strict failure handling must pass RaiseExceptions = TRUE to receive a NO_DATA_FOUND exception.
- BR-005 - All unexpected exceptions must be enriched with external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring the caller receives the fullest available diagnostic context.
- BR-006 - Diagnostic logging via DEBUGLOG must be performed both on entry (including the RaiseExceptions flag value) and after the external function call (including the return code), supporting runtime traceability at debug level 99.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-011 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a 'Save File As' dialog to the user and returns the file path selected for saving. The function delegates dialog rendering to D2KWUTIL.CHOOSEFILE, evaluates the outcome, and either returns the chosen file path or registers an error (and optionally raises an exception) when no file is selected.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-003](#SP-003--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the candidate file path by assigning the SampleName input parameter to the local variable vcReturnedFile, pre-populating the dialog with a suggested file name.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE, passing the operation label 'Save_File', the Modal flag, Title, StartDirectory, FileFilter, AdvancedFlags, a space delimiter, and the vcReturnedFile variable (IN/OUT) to display the Save File As dialog and capture the user's selection.
- Step 3 - Evaluate the integer return code (iLRC) from D2KWUTIL.CHOOSEFILE to determine whether the user completed or cancelled the dialog.
- Step 4 - If iLRC equals 1 (no file selected), call ADD_ERROR to record the message 'No file was selected' against the 'Save_File' context.
- Step 5 - If RaiseExceptions is TRUE and no file was selected, raise the NO_DATA_FOUND exception to propagate the failure to the caller.
- Step 6 - If iLRC does not equal 1 (a file was successfully selected), return vcReturnedFile containing the user-chosen save path to the caller.

---
**Decision Points**

DP-001

Condition: iLRC (return code from D2KWUTIL.CHOOSEFILE) equals 1.

TRUE: No file was selected by the user; ADD_ERROR is called with message 'No file was selected', and processing continues to DP-002.

FALSE: A file path was selected; vcReturnedFile is returned to the caller and the function exits.

---

DP-002

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iLRC = 1).

TRUE: The NO_DATA_FOUND exception is raised, propagating the failure to the calling routine.

FALSE: The function exits without raising an exception after the error has been registered via ADD_ERROR.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The SampleName parameter serves as the default pre-populated file name presented in the Save File As dialog; it must be supplied by the caller.
- BR-002 - A return code of 1 from D2KWUTIL.CHOOSEFILE is the definitive indicator that no file was selected (e.g., the user cancelled); any other return code is treated as a successful selection.
- BR-003 - When no file is selected, an error must always be registered via ADD_ERROR with the context label 'Save_File' and the message 'No file was selected', regardless of the RaiseExceptions flag.
- BR-004 - Exception propagation is opt-in: the caller controls whether a missing file selection causes a hard failure by setting RaiseExceptions to TRUE; the default behaviour (FALSE) suppresses the exception after logging the error.
- BR-005 - The function returns no value when the user does not select a file; callers relying on a return value must handle the NULL/no-return condition or enable RaiseExceptions to detect the failure programmatically.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-012 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a caller-supplied string representation of a C data type into the corresponding ORA_FFI integer constant. It is invoked by REGISTER_FUNCTION_CALL within D2kwutil.pld to resolve parameter and return-value type tokens into the numeric type codes required by the ORA_FFI foreign-function interface before an external library call is registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, storing the result in the local variable vcType to ensure case-insensitive matching.
- Step 2 - Compare vcType against the recognised C data-type tokens in sequence: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT'/'*BYTE', 'SHORT'/'BYTE', '*DOUBLE', 'DOUBLE', and '*VOID'.
- Step 3 - On the first matching token, assign the corresponding ORA_FFI constant (e.g. ORA_FFI.C_CHAR_PTR, ORA_FFI.C_CHAR, ORA_FFI.C_INT_PTR, ORA_FFI.C_INT, etc.) to the local integer variable iRC.
- Step 4 - Return iRC to the caller as a PLS_INTEGER representing the resolved ORA_FFI type code.

---
**Decision Points**

DP-001

Condition: vcType = '*CHAR'

TRUE: Assign iRC := ORA_FFI.C_CHAR_PTR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-002

Condition: vcType = 'CHAR'

TRUE: Assign iRC := ORA_FFI.C_CHAR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-003

Condition: vcType = '*INT'

TRUE: Assign iRC := ORA_FFI.C_INT_PTR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-004

Condition: vcType = 'INT'

TRUE: Assign iRC := ORA_FFI.C_INT and proceed to return.

FALSE: Evaluate the next condition.

---

DP-005

Condition: vcType = '*LONG'

TRUE: Assign iRC := ORA_FFI.C_LONG_PTR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-006

Condition: vcType = 'LONG'

TRUE: Assign iRC := ORA_FFI.C_LONG and proceed to return.

FALSE: Evaluate the next condition.

---

DP-007

Condition: vcType = '*SHORT' OR vcType = '*BYTE'

TRUE: Assign iRC := ORA_FFI.C_SHORT_PTR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-008

Condition: vcType = 'SHORT' OR vcType = 'BYTE'

TRUE: Assign iRC := ORA_FFI.C_SHORT and proceed to return.

FALSE: Evaluate the next condition.

---

DP-009

Condition: vcType = '*DOUBLE'

TRUE: Assign iRC := ORA_FFI.C_DOUBLE_PTR and proceed to return.

FALSE: Evaluate the next condition.

---

DP-010

Condition: vcType = 'DOUBLE'

TRUE: Assign iRC := ORA_FFI.C_DOUBLE and proceed to return.

FALSE: Evaluate the next condition.

---

DP-011

Condition: vcType = '*VOID'

TRUE: Assign iRC := ORA_FFI.C_VOID_PTR and proceed to return.

FALSE: No branch matches; iRC remains uninitialised (NULL) and that NULL value is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is treated as case-insensitive; the function uppercases the supplied value before any comparison, so 'int', 'INT', and 'Int' are all treated equivalently.
- BR-002 - Pointer variants of a type are denoted by prefixing the type token with an asterisk (e.g. '*INT' maps to ORA_FFI.C_INT_PTR, whereas 'INT' maps to ORA_FFI.C_INT).
- BR-003 - The tokens '*SHORT' and '*BYTE' are treated as synonyms and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType token does not match any of the eleven recognised patterns, the function returns NULL (no default or exception is raised), and the caller is responsible for handling an unresolved type code.
- BR-005 - The function performs no database reads or writes; it operates solely as an in-memory lookup against the ORA_FFI constant set.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-013 - GENERAL.CHECK_NULL

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Validates that a specified field value is not empty before a business operation continues. If the value is null, the procedure displays a prompt message telling the user to enter a valid value for the named field, then halts processing so the user can supply the required input.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value to be checked and the business label of the field (used in the error message).
- Step 2 - Compose the error message text as "Enter a valid " followed by the field label.
- Step 3 - Check whether the supplied field value is null.
- Step 4 - If the value is null, display the error message to the user via GENERAL.DISP_TEXT (SP-004) with the title "Error", then raise FORM_TRIGGER_FAILURE to stop processing.

---
**Decision Points**

DP-001

Condition: The supplied field value (P_value) is null.

TRUE: Display the error message "Enter a valid {column_title}" to the user and raise FORM_TRIGGER_FAILURE to halt processing.

FALSE: Return silently - the value is present and no action is needed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Null field check before operation: any field whose value is required for a subsequent operation must be verified as non-null by this routine before the operation proceeds; a null value immediately stops the operation and guides the user to supply the required input.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-014 - GENERAL.DISP_TEXT

**Invoked From:**

- pe_part_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pe_part_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pe_part_fmb.xml [Trigger: KEY-DOWN]
- pe_part_fmb.xml [Trigger: KEY-UP]
- pe_part_fmb.xml [Trigger: ON-ERROR]
- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pe_part_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Displays a message to the user in a standard alert dialog. The procedure selects the appropriate alert box based on the severity indicated - using the error alert for error-type messages and the informational alert for all others - sets the dialog title and message text, and presents it to the user so they see the notification clearly before returning control.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message text to display and the title string that indicates the severity.
- Step 2 - Check whether the title string is "ERROR" (case-insensitive). If it is, select the error alert dialog (AL_ERRINFO); otherwise select the informational note alert (AL_NOTE).
- Step 3 - Set the selected alert dialog's title property to the supplied title string.
- Step 4 - Set the selected alert dialog's message text property to the supplied message text.
- Step 5 - Display the alert dialog to the user and wait for them to dismiss it, then return control to the calling routine.

---
**Decision Points**

DP-001

Condition: The title_string parameter equals 'ERROR' (case-insensitive comparison).

TRUE: Use the error alert dialog (AL_ERRINFO) to display the message.

FALSE: Use the informational note alert dialog (AL_NOTE) to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Severity-based dialog selection: the alert box shown to the user is chosen based on whether the message is an error or an informational note, ensuring the visual presentation matches the message severity.
- BR-002 - Title and text set dynamically: both the dialog title and the message body are set from the caller's supplied values, making the routine reusable for any message across the application.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-015 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Rebuilds the data source (record group) for a named list item by replacing any existing version with a fresh one populated from a supplied query. The routine uses WEBUTIL.ID_NULL to evaluate the handle returned by the group lookup, ensuring safe deletion of stale groups before creating and populating a new one. This allows dropdown lists to be dynamically refreshed at runtime whenever the underlying filter criteria change, so the user always sees a current and relevant set of options.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the record group name (p_rg_name) and the SQL query string (p_select) to populate it with.
- Step 2 - Look up whether a record group with the given name already exists in the form using Find_Group, storing the returned handle in rg_id.
- Step 3 - Evaluate the handle using WEBUTIL.ID_NULL to determine whether the record group was found.
- Step 4 - If the record group already exists (handle is not null), delete it via delete_group so it can be replaced with a fresh version.
- Step 5 - Create a new record group from the supplied SQL query string using Create_Group_From_Query.
- Step 6 - Execute Populate_Group to run the query and load the matching rows into the new record group, capturing any error code returned.

---
**Decision Points**

DP-001

Condition: The handle returned by Find_Group is evaluated by WEBUTIL.ID_NULL - the record group with the given name already exists in the form (handle is not null).

TRUE: Delete the existing record group using delete_group before proceeding to create the new one.

FALSE: Skip deletion and proceed directly to create the new record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Null-safe existence check via WEBUTIL.ID_NULL: the routine delegates the null evaluation of the record group handle to WEBUTIL.ID_NULL rather than a direct comparison, ensuring consistent and safe detection of whether a group already exists before any destructive operation.
- BR-002 - Stale data source replaced before refresh: any existing record group with the same name is removed before creating the new one, preventing the list from showing outdated or duplicate options from a previous query run.
- BR-003 - Dynamic query drives the list content: the list item's data source is entirely determined by the query string supplied by the caller, making the routine generic and reusable for any dynamically filtered dropdown across the application.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-016 - GENERAL.RAISE_ERROR

**Invoked From:**

- pe_part_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up a named application error by its message code, composes the error message text, and displays it to the user. For error-type messages the procedure also halts further processing so the operation that caused the error cannot continue. Note error codes in the current implementation are not resolved via a database lookup - the message code itself is used as the display text due to a commented-out `get_message` call in the source.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code identifying the named application error (for example, 'E0088' for a referential integrity violation).
- Step 2 - Compose the display message text by concatenating the supplied message code with the unresolved message text variable (note: the `get_message` lookup call is commented out in the current source, so the message text variable is empty and only the code is shown).
- Step 3 - Determine the message type: if the type indicator is 'E' (Error), set the dialog title to "Error" and display the composed message via GENERAL.DISP_TEXT (SP-004), then raise FORM_TRIGGER_FAILURE to halt processing.
- Step 4 - If the message type is 'N' (Note), set the dialog title to "Note" and display the message via GENERAL.DISP_TEXT (SP-004) without halting processing.
- Step 5 - If the message type is 'C' (Caution), set the dialog title to "Caution" and display the message via GENERAL.DISP_TEXT (SP-004) without halting processing.

---
**Decision Points**

DP-001

Condition: The message type (mesg_type) is 'E' (Error).

TRUE: Display the error message with title "Error" via GENERAL.DISP_TEXT and raise FORM_TRIGGER_FAILURE to stop the current operation.

FALSE: Check whether the message type is 'N' or 'C'.

---

DP-002

Condition: The message type (mesg_type) is 'N' (Note).

TRUE: Display the message with title "Note" via GENERAL.DISP_TEXT; processing continues.

FALSE: Check whether the message type is 'C'.

---

DP-003

Condition: The message type (mesg_type) is 'C' (Caution).

TRUE: Display the message with title "Caution" via GENERAL.DISP_TEXT; processing continues.

FALSE: No action taken (unrecognised message type).

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Named error code displayed as message text: because the `get_message` database lookup is commented out, the error code itself is concatenated into the display text, so the user sees the code string rather than a resolved business message.
- BR-002 - Error-type messages halt processing: only messages with type 'E' raise FORM_TRIGGER_FAILURE; Note and Caution messages are informational and allow the operation to continue.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-017 - PK_PART_SEARCH_NEW.DELETE_PART_SEARCH_NEW

**Invoked From:**

- pe_part_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- pe_part_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pe_part_fmb.xml [Trigger: FT_CANCEL]
- pe_part_fmb.xml [Trigger: KEY-EXIT]
- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Clears the in-memory part search collection (lv_part_tab_11) held within the PK_PART_SEARCH_NEW package for the given principal. This procedure is called during navigation and cancellation events on the PART HELP screen to ensure that any previously populated part search results are purged before the screen is exited or refreshed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the principal identifier (p_principal) as an input parameter.
- Step 2 - Delete all elements from the package-level collection PK_PART_SEARCH_NEW.lv_part_tab_11 using the PL/SQL DELETE method, clearing every row stored in the collection regardless of the principal value passed.

---
**Decision Points**

No conditional decision points exist in this procedure. The DELETE operation on lv_part_tab_11 is executed unconditionally whenever the procedure is called.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The entire contents of the package-level collection lv_part_tab_11 must be removed in full; partial deletion is not supported - the DELETE method is applied to the whole collection.
- BR-002 - This procedure must be invoked on all exit paths from the PART HELP screen (cancel, key-exit, button press, and detail population) to guarantee that stale part search results do not persist in memory across sessions or navigations.

---
**Implementation Logic**

```plsql

  PROCEDURE delete_part_search_new(p_principal VARCHAR2) IS
  BEGIN
    Pk_Part_Search_New.lv_part_tab_11.DELETE;
  END;
```

#### SP-018 - PK_PART_SEARCH_NEW.PART_DETAILS

**Invoked From:**

- pe_part_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- pe_part_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Retrieves a paginated list of part records from PM_PART (and optionally PM_STOCK) matching the supplied search criteria, then enriches each part row with live stock quantity figures (available stock, float quantity, and campaign-allocated quantity) from PM_STOCK. The procedure supports four query paths determined by whether a stores code and/or a bin location code are provided, allowing the PART HELP screen to display filtered, page-bounded part search results with current stock positions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_parent | VARCHAR2 | IN |
| pi_principal | NUMBER | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_stores_cd | VARCHAR2 | IN |
| pi_bin_loc_cd | VARCHAR2 | IN |
| pi_where_clause | VARCHAR2 | IN |
| pi_order_by | VARCHAR2 | IN |
| p_low | NUMBER | IN |
| p_high | NUMBER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_tot_rec | NUMBER | OUT |
| po_part_tab | Pk_Part_Search_New.part_tab_8 | OUT |
| po_err_msg | VARCHAR2 | OUT |
| po_err_cd | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-029](#SP-029--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the pi_stores_cd input parameter to determine whether the search is restricted to a specific stores location or is dealer/principal-wide.
- Step 2 - Within the pi_stores_cd IS NULL branch, evaluate pi_bin_loc_cd to select the appropriate query path:
  - If pi_bin_loc_cd is also NULL, build a dynamic SQL query (lv_sql) that selects PART_NUM, ROOT_PART_NUM, PART_DESC, CATG_CD, and SELL_PRICE from PM_PART alone, filtered by DEALER_MAP_CD (matching pi_dealer or pi_principal) and PRINCIPAL_MAP_CD (matching pi_principal), with the caller-supplied WHERE clause and ORDER BY appended, and paginated using ROWNUM between p_low and p_high.
  - If pi_bin_loc_cd is NOT NULL, build a dynamic SQL query that joins PM_PART to PM_PART_VAR, adding filters on PV.PARENT_GROUP, PV.LOC_CD, and PV.DEALER_MAP_CD in addition to the PM_PART dealer/principal filters, with the same pagination.
- Step 3 - Within the pi_stores_cd IS NOT NULL branch, evaluate pi_bin_loc_cd to select the appropriate query path:
  - If pi_bin_loc_cd is NULL, build a dynamic SQL query that joins PM_PART to PM_STOCK, filtering on PS.DEALER_MAP_CD, PS.LOC_CD, PS.COMP_FA, PS.PARENT_GROUP, PS.STORES_CD, and the PM_PART dealer/principal filters, with pagination.
  - If pi_bin_loc_cd is NOT NULL, build a dynamic SQL query that joins PM_PART, PM_STOCK, and PM_PART_VAR, combining all filters from the stores-only path with additional PV.PARENT_GROUP, PV.LOC_CD, PV.PART_NUM, and PV.DEALER_MAP_CD filters, with pagination.
- Step 4 - Execute the selected dynamic SQL statement using EXECUTE IMMEDIATE ... BULK COLLECT INTO the package-level collection Pk_Part_Search_New.lv_part_tab_8, binding all relevant input parameters.
- Step 5 - Set po_tot_rec to the COUNT of rows collected in lv_part_tab_8.
- Step 6 - Iterate over each collected row (1 to po_tot_rec) and copy columns col1 through col5 (Part Number, Root Part Number, Part Description, Category Code, Selling Price) into the output collection po_part_tab.
- Step 7 - For each row, execute a second dynamic SQL statement (lv_sql1) against PM_STOCK to calculate three aggregated stock figures for the part: (a) net available stock quantity (os_stock_qty + ls_stock_qty minus os_float_qty, ls_float_qty, alloc_qty, and ws_resrv_qty), (b) net float quantity (os_float_qty + ls_float_qty minus float_alloc_qty), and (c) campaign-allocated quantity (camp_alloc_qty), filtered by pi_dealer, pi_loc_cd, pi_stores_cd (LIKE wildcard applied when NULL), pi_comp_fa, pi_parent, and the current part number.
- Step 8 - Assign the three stock figures to po_part_tab(a).col6, col7, and col8 respectively.
- Step 9 - If the PM_STOCK query returns NO_DATA_FOUND, default col6, col7, and col8 to 0 for that part row.
- Step 10 - After the loop completes successfully, set po_err_cd to 0 to signal clean execution.
- Step 11 - Any unhandled exception in the stock sub-query sets po_err_msg (appending 'in stock' and SQLERRM) and po_err_cd to 2; any unhandled exception at the procedure level sets po_err_msg to SQLERRM and po_err_cd to 1.

---
**Decision Points**

DP-001

Condition: pi_stores_cd IS NULL

TRUE: The part search queries PM_PART only (with an optional join to PM_PART_VAR when pi_bin_loc_cd is provided); no PM_STOCK join is applied in the primary SELECT.

FALSE: The part search joins PM_PART to PM_STOCK, restricting results to parts that have a stock record matching the supplied stores, location, component/FA, and parent group criteria.

---

DP-002

Condition: pi_bin_loc_cd IS NULL (evaluated within the pi_stores_cd IS NULL branch)

TRUE: The primary query selects from PM_PART alone, filtered only by dealer/principal mapping and the dynamic WHERE clause.

FALSE: The primary query joins PM_PART to PM_PART_VAR and additionally filters on PV.PARENT_GROUP, PV.LOC_CD, and PV.DEALER_MAP_CD to restrict results to parts associated with the specified bin location.

---

DP-003

Condition: pi_bin_loc_cd IS NULL (evaluated within the pi_stores_cd IS NOT NULL branch)

TRUE: The primary query joins PM_PART and PM_STOCK only, filtering on stores, location, component/FA, and parent group.

FALSE: The primary query joins PM_PART, PM_STOCK, and PM_PART_VAR, adding bin-location-level filters (PV.PARENT_GROUP, PV.LOC_CD, PV.PART_NUM, PV.DEALER_MAP_CD) to further narrow results.

---

DP-004

Condition: The per-row PM_STOCK aggregation query raises NO_DATA_FOUND

TRUE: col6, col7, and col8 for that part row are set to 0, and processing continues with the next row.

FALSE: The calculated net available stock, net float quantity, and campaign-allocated quantity values are assigned to col6, col7, and col8 respectively.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read PM_STOCK - Reads data from PM_STOCK for lookup or validation.
**Business Rules**

- BR-001 - A part is eligible for inclusion in search results only if its DEALER_MAP_CD matches either pi_dealer or pi_principal, and its PRINCIPAL_MAP_CD matches pi_principal exactly.
- BR-002 - When pi_stores_cd is provided, search results are further restricted to parts that have a corresponding PM_STOCK record for the specified dealer, location (pi_loc_cd), component/FA (pi_comp_fa), parent group (pi_parent), and stores code (pi_stores_cd).
- BR-003 - When pi_bin_loc_cd is provided, search results are additionally restricted to parts that have a PM_PART_VAR record matching the specified parent group (pi_parent) and location (pi_loc_cd), ensuring only bin-location-relevant parts are returned.
- BR-004 - Result pagination is enforced by the caller-supplied p_low and p_high row-number bounds; only rows with ROWNUM between p_low and p_high (inclusive) are returned, preventing unbounded result sets on the PART HELP screen.
- BR-005 - The dynamic WHERE clause (pi_where_clause) and ORDER BY clause (pi_order_by) are injected verbatim into the SQL string by the caller, allowing flexible, screen-driven filtering and sorting without altering the procedure's core logic.
- BR-006 - Net available stock quantity is calculated as (os_stock_qty + ls_stock_qty) minus (os_float_qty + ls_float_qty + alloc_qty + ws_resrv_qty); a NULL result is treated as zero.
- BR-007 - Net float quantity is calculated as (os_float_qty + ls_float_qty) minus float_alloc_qty; a NULL result is treated as zero.
- BR-008 - Campaign-allocated quantity is the sum of camp_alloc_qty; a NULL result is treated as zero.
- BR-009 - When pi_stores_cd is NULL in the per-row PM_STOCK stock aggregation query, a LIKE '%' wildcard is applied so that stock quantities are summed across all stores codes for the part at the given location, dealer, component/FA, and parent group.
- BR-010 - If no PM_STOCK record exists for a part row (NO_DATA_FOUND), all three stock quantity fields (col6, col7, col8) default to 0 rather than causing the row to be excluded or the procedure to fail.
- BR-011 - po_err_cd is set to 0 only after the full result set has been successfully built and enriched; a value of 1 indicates a fatal procedure-level error, and a value of 2 indicates a non-fatal per-row stock retrieval error.

---
**Implementation Logic**

```plsql

  PROCEDURE part_details(pi_parent       IN VARCHAR2,
                         pi_principal    IN NUMBER,
                         pi_comp_fa      IN VARCHAR2,
                         pi_dealer       IN NUMBER,
                         pi_loc_cd       IN VARCHAR2,
                         pi_stores_cd    IN VARCHAR2,
                         pi_bin_loc_cd   IN VARCHAR2,
                         pi_where_clause IN VARCHAR2,
                         pi_order_by     IN VARCHAR2,
                         p_low           IN NUMBER,
                         p_high          IN NUMBER,
                         po_tot_rec      OUT NUMBER,
                         po_part_tab     OUT NOCOPY Pk_Part_Search_New.part_tab_8,
                         po_err_msg      OUT VARCHAR2,
                         po_err_cd       OUT NUMBER) IS
    lv_sql        VARCHAR2(6000);
    lv_sql1       VARCHAR2(2000);
    lv_sql2       VARCHAR2(2000);
    po_sell_price NUMBER(30);
    po_part_desc  VARCHAR2(50);
  BEGIN
    NULL;

    IF pi_stores_cd IS NULL THEN
      IF pi_bin_loc_cd IS NULL THEN
        lv_sql := 'select d.PART_NUM, d.ROOT_PART_NUM,d.PART_DESC, d.CATG_CD, d.SELL_PRICE,NULL,NULL,NULL
       FROM (SELECT R.PART_NUM, R.ROOT_PART_NUM,R.PART_DESC, R.CATG_CD, R.SELL_PRICE,NULL,NULL,NULL,ROWNUM rn
                 FROM (
         SELECT PM.PART_NUM, PM.ROOT_PART_NUM, PM.PART_DESC,PM.CATG_CD,
          SELL_PRICE,NULL,NULL,NULL,ROWNUM
         FROM  PM_PART PM
         WHERE PM.DEALER_MAP_CD IN (:pi_dealer,:pi_principal)
         AND   PM.PRINCIPAL_MAP_CD = :pi_principal  ' ||
                  pi_where_clause || ' ORDER BY ' || pi_order_by ||
                  ')R)d
          WHERE d.rn >=:low  AND
         d.rn<=:high';

        EXECUTE IMMEDIATE lv_sql BULK COLLECT
          INTO Pk_Part_Search_New.lv_part_tab_8
          USING pi_dealer, pi_principal, pi_principal, p_low, p_high;
      ELSE
        lv_sql := 'select d.PART_NUM, d.ROOT_PART_NUM,d.PART_DESC, d.CATG_CD, d.SELL_PRICE,NULL,NULL,NULL
         FROM (SELECT R.PART_NUM, R.ROOT_PART_NUM,R.PART_DESC, R.CATG_CD, R.SELL_PRICE,NULL,NULL,NULL,ROWNUM rn
                   FROM (
           SELECT PM.PART_NUM, PM.ROOT_PART_NUM, PM.PART_DESC,PM.CATG_CD,
            SELL_PRICE,NULL,NULL,NULL,ROWNUM
           FROM  PM_PART PM,PM_PART_VAR PV
           WHERE PM.DEALER_MAP_CD IN (:pi_dealer,:pi_principal)
           AND   PM.PRINCIPAL_MAP_CD = :pi_principal
           AND   PV.DEALER_MAP_CD IN (:pi_dealer,:pi_principal)
           AND   PM.PART_NUM=PV.PART_NUM AND
           PV.PARENT_GROUP=:pi_parent AND
            PV.LOC_CD=:pi_loc_cd
           ' || pi_where_clause || ' ORDER BY ' ||
                  pi_order_by || ')R)d
            WHERE d.rn >=:low  AND
           d.rn<=:high';

        EXECUTE IMMEDIATE lv_sql BULK COLLECT
          INTO Pk_Part_Search_New.lv_part_tab_8
          USING pi_dealer, pi_principal, pi_principal, pi_dealer, pi_principal, pi_parent, pi_loc_cd, p_low, p_high;
      END IF;
    ELSE
      IF pi_bin_loc_cd IS NULL THEN
        lv_sql := 'select d.PART_NUM, d.ROOT_PART_NUM,d.PART_DESC, d.CATG_CD, d.SELL_PRICE,NULL,NULL,NULL
       FROM (SELECT R.PART_NUM, R.ROOT_PART_NUM,R.PART_DESC, R.CATG_CD, R.SELL_PRICE,NULL,NULL,NULL,ROWNUM rn
                 FROM (
         SELECT PM.PART_NUM, PM.ROOT_PART_NUM, PM.PART_DESC,PM.CATG_CD,
          SELL_PRICE,NULL,NULL,NULL,ROWNUM
         FROM  PM_PART PM,PM_STOCK PS
         WHERE PM.DEALER_MAP_CD IN (:pi_dealer,:pi_principal)
         AND   PM.PRINCIPAL_MAP_CD = :pi_principal
         AND   PS.DEALER_MAP_CD    =:pi_dealer
         AND   PS.LOC_CD           =:pi_loc_cd
         AND   PS.COMP_FA          =:pi_comp_fa
         AND   PS.PARENT_GROUP     =:pi_parent
         AND   PS.PART_NUM         =PM.PART_NUM
         AND   PS.STORES_CD        =:pi_stores_cd' ||
                  pi_where_clause || ' ORDER BY ' || pi_order_by ||
                  ')R)d
          WHERE d.rn >=:low  AND
         d.rn<=:high';

        EXECUTE IMMEDIATE lv_sql BULK COLLECT
          INTO Pk_Part_Search_New.lv_part_tab_8
          USING pi_dealer, pi_principal, pi_principal, pi_dealer, pi_loc_cd, pi_comp_fa, pi_parent, pi_stores_cd, p_low, p_high;
      ELSE
        lv_sql := 'select d.PART_NUM, d.ROOT_PART_NUM,d.PART_DESC, d.CATG_CD, d.SELL_PRICE,NULL,NULL,NULL
       FROM (SELECT R.PART_NUM, R.ROOT_PART_NUM,R.PART_DESC, R.CATG_CD, R.SELL_PRICE,NULL,NULL,NULL,ROWNUM rn
                 FROM (
         SELECT PM.PART_NUM, PM.ROOT_PART_NUM, PM.PART_DESC,PM.CATG_CD,
          SELL_PRICE,NULL,NULL,NULL,ROWNUM
         FROM  PM_PART PM,PM_STOCK PS,PM_PART_VAR PV
         WHERE PM.DEALER_MAP_CD IN (:pi_dealer,:pi_principal)
         AND   PM.PRINCIPAL_MAP_CD =:pi_principal
         AND   PS.DEALER_MAP_CD    =:pi_dealer
         AND   PS.LOC_CD           =:pi_loc_cd
         AND   PS.COMP_FA          =:pi_comp_fa
         AND   PS.PARENT_GROUP     =:pi_parent
         AND   PS.PART_NUM         =PM.PART_NUM
         AND   PS.STORES_CD        =:pi_stores_cd
         AND   PV.PARENT_GROUP     =:pi_parent
          AND   PV.LOC_CD      =:pi_loc_cd
          AND   PV.PART_NUM     =PS.PART_NUM
          AND   PV.DEALER_MAP_CD   =:pi_dealer ' ||
                  pi_where_clause || ' ORDER BY ' || pi_order_by ||
                  ')R)d
          WHERE d.rn >=:low  AND
         d.rn<=:high';

        EXECUTE IMMEDIATE lv_sql BULK COLLECT
          INTO Pk_Part_Search_New.lv_part_tab_8
          USING pi_dealer, pi_principal, pi_principal, pi_dealer, pi_loc_cd, pi_comp_fa, pi_parent, pi_stores_cd, pi_parent, pi_loc_cd, pi_dealer, p_low, p_high;
      END IF;
    END IF;

    po_tot_rec := Pk_Part_Search_New.lv_part_tab_8.COUNT;

    FOR a IN 1 .. po_tot_rec LOOP
      po_part_tab(a).col1 := lv_part_tab_8(a).col1; -- Part Number
      po_part_tab(a).col2 := Pk_Part_Search_New.lv_part_tab_8(a).col2;
      -- Root Part Number
      po_part_tab(a).col3 := Pk_Part_Search_New.lv_part_tab_8(a).col3;
      -- Part Description
      po_part_tab(a).col4 := Pk_Part_Search_New.lv_part_tab_8(a).col4;
      -- Category Code
      po_part_tab(a).col5 := Pk_Part_Search_New.lv_part_tab_8(a).col5;
      -- Selling Price

      BEGIN
        lv_sql1 := 'select nvl(
  SUM(
  NVL(os_stock_qty,0) + NVL(ls_stock_qty,0)-
    (NVL(os_float_qty,0) + NVL(ls_float_qty,0) +
  NVL(alloc_qty,0) + NVL(ws_resrv_qty,0))
 ),0),NVL(SUM( NVL(os_float_qty,0) + NVL(ls_float_qty,0)-
 NVL(float_alloc_qty,0)),0),
             NVL(SUM(
             NVL(camp_alloc_qty,0)),0)
       FROM   PM_STOCK
   WHERE  dealer_map_cd = :p_dealer
   AND    loc_cd        = :p_loc_cd
   AND    stores_cd     LIKE NVL(:p_stores_cd,''%'')
   AND    comp_fa       = :p_comp_fa
      AND    parent_group  = :p_parent
   AND    part_num      = :COL1';

        EXECUTE IMMEDIATE lv_sql1
          INTO po_part_tab(a).col6, po_part_tab(a).col7, po_part_tab(a).col8
          USING pi_dealer, pi_loc_cd, pi_stores_cd, pi_comp_fa, pi_parent, Pk_Part_Search_New.lv_part_tab_8(a).col1;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          po_part_tab(a).col6 := 0;
          po_part_tab(a).col7 := 0;
          po_part_tab(a).col8 := 0;
        WHEN OTHERS THEN
          po_err_msg := po_err_msg || 'in stock' || SQLERRM;
          po_err_cd  := 2;
      END;
    END LOOP;

    po_err_cd := 0;
  EXCEPTION
    WHEN OTHERS THEN
      po_err_msg := SQLERRM;
      po_err_cd  := 1;
  END part_details; -- PROCEDURE PART_DETALS
```

#### SP-019 - PK_PART_SEARCH_NEW.ROWCOUNT_NEW

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

Counts the total number of part records that match the caller-supplied search criteria on the PART HELP screen. The result is returned to the calling button trigger so that the screen can determine how many rows a subsequent part search will retrieve, supporting pagination or result-size validation before the full data set is fetched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_principal | NUMBER | IN |
| p_stores_cd | VARCHAR2 | IN |
| p_bin_loc_cd_from | VARCHAR2 | IN |
| p_bin_loc_cd_to | VARCHAR2 | IN |
| pi_where_clause | VARCHAR2 | IN |
| pi_final_where_clause | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| tot_rec | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-029](#SP-029--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive all input parameters: dealer code, principal code, parent group, location code, company/FA code, stores code, bin location range (from/to), a dynamic filter clause (pi_where_clause), and a final filter clause (pi_final_where_clause).
- Step 2 - Construct a dynamic SQL string (lv_sql) that performs a COUNT(1) over a derived result set. The inner query performs a UNION ALL of two PM_PART sub-queries: the first filters PM_PART by dealer_map_cd equal to the dealer value; the second filters PM_PART by dealer_map_cd equal to the principal value. Both sub-queries apply the caller-supplied pi_where_clause to restrict rows further.
- Step 3 - Join the combined PM_PART result set to PM_PART_VAR (outer join) using parent_group, dealer_map_cd, loc_cd, and part_num to retrieve pricing variant data.
- Step 4 - Join the combined PM_PART result set to PM_STOCK_BIN_LOC (outer join) using parent_group, dealer_map_cd, loc_cd, comp_fa, and part_num to retrieve bin location and stores data.
- Step 5 - Append pi_final_where_clause to the outer query to apply any remaining dynamic filter conditions (e.g., stores code or bin location range restrictions).
- Step 6 - Execute the fully assembled dynamic SQL statement using EXECUTE IMMEDIATE, binding p_dealer, p_principal, p_parent, p_dealer, p_loc_cd, p_parent, p_dealer, p_loc_cd, and p_comp_fa as bind variables in the prescribed order.
- Step 7 - Return the resulting count into the OUT parameter tot_rec.

---
**Decision Points**

DP-001

Condition: Whether pi_where_clause and pi_final_where_clause contain additional filter predicates at runtime.

TRUE: The dynamic SQL includes the extra predicates, narrowing the counted rows to only those parts matching the additional search criteria (e.g., part number pattern, category, bin location range, stores code).

FALSE: The dynamic SQL contains no additional predicates beyond the mandatory dealer/principal filter, and all parts for the given dealer and principal are counted.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Parts belonging to both the dealer (dealer_map_cd = p_dealer) and the principal (dealer_map_cd = p_principal) are included in the count; the UNION ALL ensures records from both ownership levels are considered without duplication suppression.
- BR-002 - Joins to PM_PART_VAR and PM_STOCK_BIN_LOC are outer joins, meaning parts with no corresponding pricing variant or bin location record are still counted.
- BR-003 - The caller is responsible for constructing and passing pi_where_clause and pi_final_where_clause; this procedure applies them verbatim, making the count result fully dependent on the correctness of those clauses.
- BR-004 - Bind variables are used for all runtime values (dealer, principal, parent group, location code, comp/FA) to prevent SQL injection and to comply with Oracle cursor-sharing requirements.
- BR-005 - The procedure returns exactly one numeric value (tot_rec) representing the total row count; no data rows are returned, and no DML operations are performed.

---
**Implementation Logic**

```plsql
  PROCEDURE rowcount_new(p_parent              IN VARCHAR2,
                         p_dealer              IN NUMBER,
                         p_loc_cd              IN VARCHAR2,
                         p_comp_fa             IN VARCHAR2,
                         p_principal           IN NUMBER,
                         p_stores_cd           IN VARCHAR2,
                         p_bin_loc_cd_from     IN VARCHAR2,
                         p_bin_loc_cd_to       IN VARCHAR2,
                         pi_where_clause       IN VARCHAR2,
                         pi_final_where_clause IN VARCHAR2,
                         tot_rec               OUT NUMBER) IS
    lv_sql VARCHAR2(6000);
  BEGIN
    lv_sql := 'SELECT count(1)
    FROM(
          SELECT PM.PART_NUM, PM.ROOT_PART_NUM, PM.PART_DESC,PM.CATG_CD,
                      PV.ls_sell_price,
                      PV.os_sell_price,
                      PV.MRP_1 mrp,
            PS.BIN_LOC,
            PS.stores_cd,
            NULL,NULL,NULL,ROWNUM rn
  FROM (SELECT part_num,
                             root_part_num,
                            part_desc,
                            catg_cd,
                   APPLY_MODEL_CD--,ROWNUM
          FROM PM_PART pm
         WHERE  dealer_map_cd = :pi_dealer ' ||
              pi_where_clause ||
              ' UNION ALL
     SELECT part_num,
                             root_part_num,
                            part_desc,
                            catg_cd,
                   APPLY_MODEL_CD--,ROWNUM
          FROM PM_PART pm
         WHERE  dealer_map_cd = :pi_principal ' ||
              pi_where_clause ||
              ' ) PM, PM_PART_VAR pv, PM_STOCK_BIN_LOC ps
 WHERE pv.parent_group(+) = :pi_parent AND pv.dealer_map_cd(+) = :pi_dealer AND pv.loc_cd(+) = :pi_loc_cd AND pv.part_num(+) = PM.part_num
 AND ps.parent_group(+) = :pi_parent AND ps.dealer_map_cd(+) = :pi_dealer AND ps.loc_cd(+) = :pi_loc_cd AND ps.comp_fa(+) = :pi_comp_fa AND ps.part_num(+) = PM.part_num ' ||
              pi_final_where_clause || ')';

    EXECUTE IMMEDIATE lv_sql
      INTO tot_rec
      USING p_dealer, p_principal, p_parent, p_dealer, p_loc_cd, p_parent, p_dealer, p_loc_cd, p_comp_fa;

    --Commented by Srinivasan on 04/06/2008 to use the part detail query
    /*IF p_stores_cd IS NULL
    THEN
       IF p_bin_loc_cd_to IS NULL
       THEN
          lv_sql :=
                'SELECT COUNT(1) FROM PM_PART PM,PM_STOCK_BIN_LOC PS
         WHERE PM.PART_NUM=PS.PART_NUM (+)
         AND PM.DEALER_MAP_CD IN (:P_DEALER, :P_PRINCIPAL)
         AND PS.DEALER_MAP_CD(+) =:P_DEALER
         AND PS.PARENT_GROUP(+)=:P_PARENT
         AND PS.LOC_CD(+)=:P_LOC_CD
         AND PS.COMP_FA(+)=:P_COMP_FA
         AND PM.PRINCIPAL_MAP_CD = :P_PRINCIPAL '
             || filter_query;

       --lv_sql :=

          EXECUTE IMMEDIATE lv_sql
                       INTO tot_rec
                      USING p_dealer,
                            p_principal,
                            p_dealer,
                            p_parent,
                            p_loc_cd,
                            p_comp_fa,
                            p_principal;
       ELSE
          lv_sql :=
                'SELECT COUNT(1) FROM PM_PART PM,PM_STOCK_BIN_LOC PS
         WHERE PM.PART_NUM=PS.PART_NUM
         AND PM.DEALER_MAP_CD IN (:P_DEALER, :P_PRINCIPAL)
         AND PS.DEALER_MAP_CD(+) =:P_DEALER
         AND PS.PARENT_GROUP(+)=:P_PARENT
         AND PS.LOC_CD(+)=:P_LOC_CD
         AND PS.COMP_FA(+)=:P_COMP_FA
         AND PS.BIN_LOC(+) BETWEEN :PI_BIN_LOC_FROM AND :PI_BIN_LOC_TO
         AND PM.PRINCIPAL_MAP_CD = :P_PRINCIPAL '
             || filter_query;

          EXECUTE IMMEDIATE lv_sql
                       INTO tot_rec
                      USING p_dealer,
                            p_principal,
                            p_dealer,
                            p_parent,
                            p_loc_cd,
                            p_comp_fa,
                            p_bin_loc_cd_from,
                            p_bin_loc_cd_to,
                            p_principal;
       END IF;
    ELSE
       IF p_bin_loc_cd_to IS NULL
       THEN
          lv_sql :=
                'SELECT COUNT(1)
      FROM  PM_PART  PM,PM_STOCK_BIN_LOC PS
     WHERE PM.DEALER_MAP_CD IN (:P_DEALER, :P_PRINCIPAL)
     AND   PM.PRINCIPAL_MAP_CD =:P_PRINCIPAL
     AND   PS.PARENT_GROUP(+)     =:P_PARENT
     AND   PS.DEALER_MAP_CD(+)    =:P_DEALER
     AND   PS.LOC_CD(+)           =:P_LOC_CD
     AND   PS.COMP_FA(+)          =:P_COMP_FA
     AND   PS.PART_NUM(+)         =PM.PART_NUM
     AND   PS.STORES_CD(+)        =:P_STORES_CD '
             || filter_query;

          EXECUTE IMMEDIATE lv_sql
                       INTO tot_rec
                      USING p_dealer,
                            p_principal,
                            p_principal,
                            p_parent,
                            p_dealer,
                            p_loc_cd,
                            p_comp_fa,
                            p_stores_cd;
       ELSE
          lv_sql :=
                'SELECT COUNT(1)
      FROM  PM_PART  PM,PM_STOCK_BIN_LOC PS
     WHERE PM.DEALER_MAP_CD IN (:P_DEALER, :P_PRINCIPAL)
     AND   PM.PRINCIPAL_MAP_CD =:P_PRINCIPAL
     AND   PS.PARENT_GROUP(+)     =:P_PARENT
     AND   PS.DEALER_MAP_CD(+)    =:P_DEALER
     AND   PS.LOC_CD(+)           =:P_LOC_CD
     AND   PS.COMP_FA(+)          =:P_COMP_FA
     AND   PS.PART_NUM(+)         =PM.PART_NUM
     AND   PS.STORES_CD(+)        =:P_STORES_CD
           AND PS.BIN_LOC(+) BETWEEN :PI_BIN_LOC_FROM AND :PI_BIN_LOC_TO
     '
             || filter_query;

          EXECUTE IMMEDIATE lv_sql
                       INTO tot_rec
                      USING p_dealer,
                            p_principal,
                            p_principal,
                            p_parent,
                            p_dealer,
                            p_loc_cd,
                            p_comp_fa,
                            p_stores_cd,
                            p_bin_loc_cd_from,
                            p_bin_loc_cd_to;
       END IF;
    END IF;*/
  END;
```

#### SP-020 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the Oracle Forms session waits for the command to complete before resuming. It delegates execution to WEBUTIL.EXECUTE, passing the caller-supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-029](#SP-029--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the operating-system command string (cmd) from the invoking routine WEBUTIL.HOST.
- Step 2 - Call WEBUTIL.EXECUTE, passing cmd as the command to run and BLOCKING_MODE as the execution mode flag.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller, representing the handle of the launched process.

---
**Decision Points**

No conditional decision points exist within this procedure. All branching and mode-handling logic is delegated entirely to WEBUTIL.EXECUTE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must be executed synchronously; BLOCKING_MODE is always passed to WEBUTIL.EXECUTE, ensuring the session does not proceed until the host process finishes.
- BR-002 - This function acts solely as a thin wrapper; it does not alter, validate, or default the cmd parameter before forwarding it to WEBUTIL.EXECUTE.
- BR-003 - The caller receives a PROCESS_ID return value, which is the direct result from WEBUTIL.EXECUTE and represents the identifier of the completed host process.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-021 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the correct version. For each library defined in the property bundle for the package, the procedure compares the installed version recorded in client settings against the required version. Where a library is absent, out-of-date, or a forced re-download is flagged, the procedure downloads the library from the configured URL to the client's system-library location and updates the recorded installed version. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-061](#SP-061--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) that specifies which package's system libraries must be checked.
- Step 2 - Enter a loop that iterates over sequentially numbered library entries (starting at index 1) defined in the property bundle.
- Step 3 - For each iteration, call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve the library specification using a key composed of the OS family, OS architecture, packageID, and the current index. If no entry is found for the OS-architecture-specific key, retry with an OS-family-only key (without architecture).
- Step 4 - If no library specification is returned for the current index, exit the loop; all libraries for the package have been processed.
- Step 5 - Increment the library index counter and parse the library specification string (pipe-delimited) to extract: library file name, expected file size, required version, and a flag indicating whether a progress indicator should be displayed during download.
- Step 6 - Call WEBUTIL.GETCLIENTSETTING to retrieve the version of the library currently recorded as installed on the client ('syslib.<libName>').
- Step 7 - Evaluate whether a download is required: if the installed version is null, does not match the required version, or the REDOWNLOAD_SYSLIB flag is set, proceed to download.
- Step 8 - Determine the download base URL by calling WEBUTIL.READFROMPROPERTYBUNDLE with progressively less specific keys: first OS-family plus architecture, then OS-family only, then a generic location key. The first non-null result is used.
- Step 9 - Call WEBUTIL.DOWNLOADFROMURLINT to download the library file from the resolved URL to the client's system-library install location, passing the file name, expected size, progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 10 - If the download succeeds, call WEBUTIL.SETCLIENTSETTING to record the newly installed library version against the client setting key ('syslib.<libName>').
- Step 11 - If the download fails, call WEBUTIL.LOG to record a failure message identifying the library that could not be downloaded.
- Step 12 - Return to Step 3 to process the next library entry in the bundle.

---
**Decision Points**

DP-001

Condition: The library specification retrieved from the property bundle using the OS-family-plus-architecture key is null.

TRUE: Retry the property bundle lookup using an OS-family-only key (without architecture segment).

FALSE: Use the specification returned by the OS-family-plus-architecture key.

---

DP-002

Condition: The library specification is null after both lookup attempts (OS-family-plus-architecture and OS-family-only).

TRUE: Exit the loop; no further libraries are defined for this package.

FALSE: Continue processing the current library entry.

---

DP-003

Condition: The installed version recorded in client settings is null, differs from the required version defined in the property bundle, or the REDOWNLOAD_SYSLIB flag is set.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip download and advance to the next library.

---

DP-004

Condition: The download base URL resolved from the OS-family-plus-architecture property bundle key is null.

TRUE: Attempt to resolve the URL using the OS-family-only key.

FALSE: Use the URL returned by the OS-family-plus-architecture key.

---

DP-005

Condition: The download base URL resolved from the OS-family-only property bundle key is null.

TRUE: Attempt to resolve the URL using the generic (non-OS-specific) location key.

FALSE: Use the URL returned by the OS-family-only key.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Call WEBUTIL.SETCLIENTSETTING to record the required library version as the installed version on the client.

FALSE: Call WEBUTIL.LOG to record a download failure message for the library and continue to the next library in the loop.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications must be defined in the property bundle under keys that follow the pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>' or the fallback pattern 'install.syslib.<OSFamily>.<packageID>.<index>'; the procedure will not process a library unless at least one of these keys yields a non-null value.
- BR-002 - Each library specification must be a pipe-delimited string encoding, in order: library file name, expected file size, required version, and a Boolean progress-display flag ('TRUE'/'FALSE').
- BR-003 - A library download is mandatory when the client has no recorded installed version, when the recorded installed version does not match the version specified in the property bundle, or when the REDOWNLOAD_SYSLIB flag is set.
- BR-004 - The download base URL is resolved with OS specificity preference: OS-family-plus-architecture takes precedence over OS-family-only, which takes precedence over the generic location key; the first non-null value found is used.
- BR-005 - On successful download, the client setting 'syslib.<libName>' must be updated to the required version so that subsequent invocations recognise the library as correctly installed.
- BR-006 - A failed download must be recorded via WEBUTIL.LOG with a message identifying the library name; processing continues with the remaining libraries rather than halting.
- BR-007 - Progress dialog labels displayed during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring localised text is presented to the user.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up a specific callback trigger once it is no longer needed, ensuring the collection does not retain stale callback registrations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the target callback entry within the internal m_callbacks collection.
- Step 2 - Check whether an entry exists in m_callbacks for the supplied callbackKey.
- Step 3 - If the entry exists, delete it from m_callbacks using the provided key.
- Step 4 - If no entry exists for the key, take no action and return silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - an entry is present in the m_callbacks collection for the supplied callbackKey.

TRUE: The entry is deleted from m_callbacks, removing the callback registration associated with that key.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A callback entry is removed from the collection only if it currently exists; attempting to clear a non-existent key is a no-op and does not raise an error.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to an index in the m_callbacks collection; the procedure performs no transformation or validation of the key beyond the existence check.
- BR-003 - Only the single entry identified by callbackKey is removed; all other entries in m_callbacks remain unaffected.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-023 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation to the WebUtil_DB package, ensuring that BLOB resources previously opened within a WebUtil session are properly released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the identifying key.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in this stored procedure. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a BLOB handle that was previously opened within the WebUtil session; the validity of the checksum is enforced by the delegated call to WebUtil_DB.CloseBlob.
- BR-002 - The success or failure of the close operation is communicated exclusively through the BOOLEAN return value; callers must evaluate this value to determine whether the BLOB handle was released successfully.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-024 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file reader object by invoking the corresponding Java method on the AppServerFileReader class. This procedure releases the file handle represented by the supplied Java object, ensuring that server-side file resources are properly freed after a file transfer or read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents an active AppServerFileReader instance on the application server.
- Step 2 - Clear the argument list by setting args to NULL, ensuring no stale parameters are passed to the Java method call.
- Step 3 - Invoke the closeFile() method on the AppServerFileReader Java class via JNI.CALL_BOOLEAN_METHOD, passing the supplied object reference and a NULL argument list.
- Step 4 - Return the Boolean result produced by the Java method call to the caller (WEBUTIL.SETDATA), indicating whether the file was successfully closed.

---
**Decision Points**

DP-001

Condition: The JNI call to oracle/forms/webutil/fileTransfer/AppServerFileReader.closeFile() returns TRUE or FALSE.

TRUE: The file reader on the application server was closed successfully; the Boolean value TRUE is returned to the calling routine.

FALSE: The file reader could not be closed (e.g., the object reference is invalid or the underlying Java method reports failure); the Boolean value FALSE is returned to the calling routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list must be reset to NULL before each JNI method invocation to prevent unintended parameter carry-over from prior calls.
- BR-002 - The file close operation is performed exclusively through the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class; no alternative close mechanism is used.
- BR-003 - The function must return the raw Boolean result of the Java closeFile() method without modification, preserving the success or failure signal for the invoking routine (WEBUTIL.SETDATA).
- BR-004 - A valid ORA_JAVA.JOBJECT reference to an AppServerFileReader instance must be supplied by the caller; the function does not perform null-object validation internally.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-025 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified entry point for downloading a file from a specified URL to a client-side destination. The procedure delegates all processing to the internal implementation function WEBUTIL.DOWNLOADFROMURLINT, passing fixed default values for internal control parameters (offset = 0, append = false, and three null auxiliary arguments). It returns a BOOLEAN indicating whether the download succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL, the client-side destination path, and the expected file size from the caller (WEBUTIL.URL_TO_CLIENT).
- Step 2 - Invoke WEBUTIL.DOWNLOADFROMURLINT, forwarding the source URL, client destination, and file size, while supplying fixed internal defaults: offset value of 0, append flag of FALSE, and three NULL auxiliary parameters.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT directly to the caller, indicating success or failure of the download operation.

---
**Decision Points**

No decision points are present in this procedure. All conditional logic is fully delegated to WEBUTIL.DOWNLOADFROMURLINT; this function unconditionally constructs the call and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file offset passed to WEBUTIL.DOWNLOADFROMURLINT is always fixed at 0, meaning the download always begins from the start of the source file; partial/resumable downloads are not initiated through this entry point.
- BR-002 - The append flag passed to WEBUTIL.DOWNLOADFROMURLINT is always FALSE, ensuring the client destination file is not appended to; the download overwrites or creates the destination file.
- BR-003 - The fileSize parameter defaults to 0 if not supplied by the caller, indicating that file size pre-validation is optional at this interface level.
- BR-004 - This function must return the BOOLEAN result of WEBUTIL.DOWNLOADFROMURLINT unchanged; no additional success or failure handling is applied at this layer.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-026 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DownLoadFromURLInt is the internal worker function that performs the actual file download from a specified URL to a client-side destination. It constructs a pipe-delimited instruction string encoding all download parameters (destination type, file size, progress display preferences, URL, and path), submits it to the WebUtil Core bean via a property call, and returns a BOOLEAN indicating whether the download succeeded. It is called exclusively by WEBUTIL.CHECKLIBS and WEBUTIL.DOWNLOADFROMURL, which act as its public-facing entry points.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception and return FALSE after logging error code 25.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception and return FALSE after logging error code 130.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, default the value to '0'; otherwise convert the supplied integer to a character. Append the result followed by the pipe separator to submitString.
- Step 4 - Evaluate fileSize: if null, append '0' and a pipe separator to submitString; otherwise append the character representation of fileSize and a pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' and a pipe separator to submitString; if TRUE, append 'Y' and a pipe separator.
- Step 6 - Concatenate the remaining fields into submitString in the following order: sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null), each separated by the pipe character.
- Step 7 - Submit the fully constructed submitString to the WebUtil Core bean by calling WebUtil_Core.setProperty with package constant WUC_PACKAGE, property key WUC_URL_DOWNLOAD, and the submit string.
- Step 8 - Retrieve the execution result by calling WebUtil_Core.getProperty with the same package and property key, storing the returned VARCHAR2 in result.
- Step 9 - Return TRUE if result equals the literal string 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception; log error code 25 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Continue processing.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception; log error code 130 via WebUtil_Core.Error referencing 'WEBUTIL_CORE.DownloadFromURLInt'; return FALSE.

FALSE: Continue processing.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Use the default value '0' as the specialDestination segment of submitString.

FALSE: Convert specialDestination to its character representation and use it as the segment.

---

DP-004

Condition: fileSize IS NULL

TRUE: Use '0' as the fileSize segment of submitString.

FALSE: Convert fileSize to its character representation and use it as the segment.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' to submitString, indicating no progress display.

FALSE: Append 'Y' to submitString, indicating progress display is required.

---

DP-006

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty call

TRUE: Display an alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: No action; normal processing continues.

---

DP-007

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty or getProperty call

TRUE: Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: No action; normal processing continues.

---

DP-008

Condition: result (returned by WebUtil_Core.getProperty) equals the literal string 'TRUE'

TRUE: Function returns BOOLEAN TRUE, signalling a successful download.

FALSE: Function returns BOOLEAN FALSE, signalling a failed or incomplete download.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-null source URL is mandatory; omitting it is a hard error that immediately terminates the function with a FALSE return and an error log entry (code 25).
- BR-002 - A non-null client destination path is mandatory; omitting it is a hard error that immediately terminates the function with a FALSE return and an error log entry (code 130).
- BR-003 - The specialDestination value must be within the inclusive range 0-2; any value outside this range (including null and negative integers) is silently coerced to 0 before submission.
- BR-004 - A null fileSize is treated as 0 to ensure a valid numeric segment is always present in the submission string.
- BR-005 - Progress display is opt-in; a null or FALSE withProgress value defaults to disabled ('N'), preventing unintended UI elements from appearing during download.
- BR-006 - Null values for progressTitle, progressSubTitle, and progressMessage are replaced with a single space character to preserve the fixed pipe-delimited structure of the submission string and avoid null segments.
- BR-007 - The download instruction is communicated to the client-side WebUtil bean exclusively through the WebUtil_Core property mechanism (setProperty / getProperty) using the WUC_URL_DOWNLOAD key; no direct database or file-system interaction occurs within this function.
- BR-008 - If the WebUtil bean is not registered on the client, the function must not silently fail; it raises FORM_TRIGGER_FAILURE after displaying an informational alert, ensuring the form halts in a controlled manner.
- BR-009 - A PROPERTY_ERROR returned by the WebUtil Core layer is treated as unrecoverable; the function raises FORM_TRIGGER_FAILURE without additional messaging, deferring error reporting to the Core layer.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-027 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then registers that message as a WebUtil property on the specified package instance. This provides a standardised mechanism for surfacing error details back to the WebUtil framework via the WUC_ERROR_MSG property.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package instance identifier (packageID), a numeric error code (code), the name of the program unit raising the error (pu_name), and up to three optional supplementary arguments (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR', the error code left-padded with leading zeros to three digits, a pipe delimiter, and the program unit name (e.g. 'ERROR001|SOME_PACKAGE').
- Step 3 - Evaluate whether arg1 is not null; if so, append a pipe delimiter followed by the value of arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is not null; if so, append a pipe delimiter followed by the value of arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is not null; if so, append a pipe delimiter followed by the value of arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty, passing the package instance identifier, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to register the error message on the WebUtil package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; processing continues to property registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error code must be formatted as a zero-padded three-digit string (e.g. code 7 becomes '007') to ensure consistent message structure across all error registrations.
- BR-002 - The error text string must always begin with the literal prefix 'ERROR' followed immediately by the zero-padded code and the program unit name, separated by pipe delimiters, establishing a mandatory minimum structure for every error message.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error text only when they carry a non-null value; null arguments are silently excluded, preventing empty pipe-delimited segments in the message.
- BR-004 - The fully assembled error message must be stored against the property key 'WUC_ERROR_MSG' on the identified package instance via Webutil_Core.setProperty, making it available to the WebUtil framework for downstream handling.
- BR-005 - The error text string is constrained to a maximum of 1024 characters, limiting the combined length of the code, program unit name, and any appended argument values.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-028 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the procedure populates it with the supplied error text and presents it as a modal alert dialog. If no alert object is registered, it falls back to the Oracle Forms MESSAGE built-in. The procedure is called by WEBUTIL.EXECUTE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE to surface bean-registration and bean-not-found errors in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message text (errText) passed by the calling procedure.
- Step 2 - Invoke WEBUTIL.ID_NULL (SP-050) to test whether the module-level alert handle m_errorAlert has been initialised (i.e. is non-null).
- Step 3 - If m_errorAlert is valid, set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert dialog to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid (ID_NULL returns TRUE), display the error by calling the Oracle Forms MESSAGE built-in with the concatenated string 'WebUtil Error: ' followed by errText.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - the module-level alert handle m_errorAlert is initialised and valid.

TRUE: Set the alert message text to errText via SET_ALERT_PROPERTY and display the alert dialog via SHOW_ALERT, discarding the return value.

FALSE: Fall back to the Oracle Forms MESSAGE built-in, outputting the string 'WebUtil Error: ' concatenated with errText.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is the single, standardised mechanism for surfacing WebUtil errors (specifically BEAN_NOT_REGISTERED and bean-not-found conditions) to the user; all calling procedures must route such errors through ERRORALERT rather than handling them inline.
- BR-002 - The alert title is not modified at runtime; it is assumed to be pre-set in the alert object's design-time properties, ensuring consistent branding without runtime overhead.
- BR-003 - The return value of SHOW_ALERT is intentionally discarded; no branching logic is applied based on the user's alert response, meaning the alert is purely informational.
- BR-004 - When the alert handle m_errorAlert is uninitialised, the MESSAGE built-in serves as the mandatory fallback so that error visibility is never suppressed regardless of alert object availability.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-029 - WEBUTIL.EXECUTE

**Invoked From:**

- PK_PART_SEARCH_NEW.pck [StoredProcedure: PK_PART_SEARCH_NEW.PART_DETAILS]
- PK_PART_SEARCH_NEW.pck [StoredProcedure: PK_PART_SEARCH_NEW.ROWCOUNT_NEW]
- SP_GET_STORES_STOCK.prc [StoredProcedure: SP_GET_STORES_STOCK]
- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell or system command to the WebUtil host execution layer and returns a process identifier for the spawned process. The procedure sets the execution mode and command string as WebUtil core properties, triggers execution on the client-side host bean, and retrieves the resulting process handle. If the required WebUtil bean is not registered, an error alert is raised to notify the user that host execution is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-037](#SP-037--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-043](#SP-043--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and execution mode flag (exemode) as input parameters.
- Step 2 - Check whether the command string is not null; if it is null, skip execution and return an uninitialised PROCESS_ID record.
- Step 3 - Set the execution mode on the WebUtil core host package property 'WUH_EXECUTION_MODE' using the supplied exemode value, controlling whether the command runs synchronously or asynchronously.
- Step 4 - Set the command to be executed on the WebUtil core host package property 'WUH_EXECUTE' using the supplied cmd value, triggering the client-side bean to launch the process.
- Step 5 - Retrieve the process handle assigned by the host bean by reading the 'WUH_EXECUTE' property back from the WebUtil core host package and converting it to a number, storing it in the local PROCESS_ID variable.
- Step 6 - Return the populated PROCESS_ID record (containing the numeric process handle) to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, invoke WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) with a message that identifies the missing implementation class (obtained via WEBUTIL.GETIMPLCLASS) and states that WEBUTIL_HOST.Execute will not work.

---
**Decision Points**

DP-001

Condition: The input parameter cmd IS NOT NULL.

TRUE: Set the execution mode property, set the execute command property, retrieve the process handle, and return a populated PROCESS_ID.

FALSE: Bypass all property-setting and handle-retrieval steps; return an uninitialised PROCESS_ID record to the caller.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during property-set or property-get operations.

TRUE: Call WEBUTIL.ERRORALERT with a message composed from WEBUTIL.GETIMPLCLASS identifying the missing bean, informing the user that host command execution is not available.

FALSE: No exception handling required; normal execution continues and the PROCESS_ID is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string must not be submitted to the host execution layer; if cmd is null the procedure returns immediately with an uninitialised process handle and no execution is attempted.
- BR-002 - The execution mode (exemode) must be set on the WebUtil core host package before the command property is written, ensuring the host bean applies the correct synchronous or asynchronous behaviour when it processes the command.
- BR-003 - The process handle returned to the caller is derived solely from the numeric value read back from the 'WUH_EXECUTE' property after the command is dispatched; no alternative handle source is used.
- BR-004 - If the required WebUtil host bean is not registered on the client, execution must be aborted and the user must be notified via WEBUTIL.ERRORALERT, with the missing bean identified by WEBUTIL.GETIMPLCLASS, before the procedure terminates.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-030 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened via the WebUtil file I/O framework. The procedure instructs the WebUtil client bean to release the file handle and then nullifies the handle reference on the server side, ensuring the file resource is cleanly released after use (e.g., following Excel report generation in VIEW_EXCEL_REPORT_NEW).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the IN OUT file handle (file_type) representing an open client-side text file.
- Step 2 - Check whether the file handle is currently active (file.handle IS NOT NULL); if it is NULL the procedure takes no action and exits silently.
- Step 3 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the active handle to instruct the WebUtil client bean to physically close the file on the client machine.
- Step 4 - Set file.handle to NULL, marking the server-side reference as closed and preventing any further operations against the same handle.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort the calling process.
- Step 6 - If a property communication error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort the calling process without additional messaging.

---
**Decision Points**

DP-001

Condition: file.handle IS NOT NULL

TRUE: The procedure calls WebUtil_Core.setProperty to close the file on the client and then nullifies file.handle.

FALSE: The procedure performs no action; the file is already closed or was never opened, so no close operation is attempted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only executed when the file handle is non-NULL; attempting to close an already-closed or uninitialised handle is silently ignored to prevent errors.
- BR-002 - After the client-side close instruction is issued, the server-side handle reference must be set to NULL immediately, ensuring the handle cannot be reused for subsequent file operations.
- BR-003 - If the WebUtil client bean required to perform the close is not registered, the procedure must surface an informative error alert identifying the missing bean class and then raise TOOL_ERR.TOOL_ERROR, halting further execution in the calling context.
- BR-004 - If a WebUtil property communication error occurs during the close attempt, TOOL_ERR.TOOL_ERROR must be raised to signal failure to the calling routine, ensuring errors are not silently swallowed.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-031 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the user with a native file-save dialog box, allowing them to browse to a target directory and specify a file name under which a file (typically an Excel report) will be saved. The function delegates to WEBUTIL.FILE_SELECTION_DIALOG_INT, passing a SAVE_FILE mode flag and fixed dialog-behaviour switches, and returns the fully qualified file path chosen by the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-032](#SP-032--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: directory_name (initial directory to open), file_name (default file name to pre-populate), file_filter (file-type filter to restrict visible files), and title (dialog window title).
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT, forwarding all four caller-supplied parameters together with three fixed arguments: the D2KWUTIL.SAVE_FILE mode constant (instructs the dialog to operate in save mode), TRUE (enables overwrite-confirmation behaviour), and FALSE (disables multi-file selection).
- Step 3 - Return the string result produced by WEBUTIL.FILE_SELECTION_DIALOG_INT to the caller, representing the fully qualified file path entered or selected by the user, or NULL if the user cancelled the dialog.

---
**Decision Points**

DP-001

Condition: User completes the save dialog and confirms a file path.

TRUE: WEBUTIL.FILE_SELECTION_DIALOG_INT returns the selected fully qualified file path string, which FILE_SAVE_DIALOG passes back to the caller.

FALSE: WEBUTIL.FILE_SELECTION_DIALOG_INT returns NULL (user cancelled), which FILE_SAVE_DIALOG passes back to the caller, signalling that no file destination was chosen.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog must operate exclusively in save-file mode; this is enforced by passing the D2KWUTIL.SAVE_FILE constant as the mode argument to WEBUTIL.FILE_SELECTION_DIALOG_INT.
- BR-002 - Multi-file selection is prohibited; the FALSE flag passed to WEBUTIL.FILE_SELECTION_DIALOG_INT ensures only a single file path can be returned.
- BR-003 - All input parameters (directory_name, file_name, file_filter, title) are optional and default to NULL; the dialog must remain operable even when none are supplied.
- BR-004 - The function returns the raw string result from WEBUTIL.FILE_SELECTION_DIALOG_INT without modification; responsibility for handling a NULL (cancelled) return value lies with the calling routine (VIEW_EXCEL_REPORT_NEW).

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-032 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file-selection dialog to the end user by delegating to the WebUtil client-side bean, then returns the selected file or directory path as a VARCHAR2 string. The function supports three dialog modes-Save File, Open Directory, and Open File-controlled by the dialog_type and select_file input parameters. It also normalises any escaped backslash sequences in the returned path before passing the result back to the caller (WEBUTIL.FILE_SAVE_DIALOG).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the initial directory context on the WebUtil bean by writing the directory_name value to the WUF_GFN_DIRNAME property via WebUtil_Core.setProperty.
- Step 2 - Set the default file name on the bean by writing file_name to the WUF_FILENAME property (marked as a display-refresh property).
- Step 3 - Set the file-type filter on the bean by writing file_filter to the WUF_FILTER property.
- Step 4 - Set the dialog title on the bean by writing title to the WUF_GFN_MESSAGE property.
- Step 5 - Set the multi-select flag on the bean by writing the multiselect Boolean to the WUF_GFN_MULTISELECT property (marked as a display-refresh property).
- Step 6 - Determine which dialog variant to invoke: if dialog_type equals the SAVE_FILE constant, retrieve the user's selection via the WUF_GFN_SAVEFILE property; else if select_file is FALSE, retrieve the selection via WUF_GFN_OPENDIR (directory picker); otherwise retrieve it via WUF_GFN_OPENFILE (file picker).
- Step 7 - Inspect the returned path string for a leading double-backslash ('\\') by locating its position with INSTR.
- Step 8 - If the path starts at position 1 with '\\', prepend an additional '\\' to the result string to protect the UNC prefix before normalisation.
- Step 9 - Replace all remaining '\\' sequences in the result with a single '\' to produce a clean file-system path.
- Step 10 - Return the normalised path string to the caller.
- Step 11 - If the WebUtil bean is not registered, raise an error alert identifying the missing implementation class and then raise FORM_TRIGGER_FAILURE to abort processing.
- Step 12 - If a property read/write error occurs, raise FORM_TRIGGER_FAILURE to abort processing.

---
**Decision Points**

DP-001

Condition: dialog_type = SAVE_FILE

TRUE: The function retrieves the user-selected path from the WUF_GFN_SAVEFILE bean property, presenting a Save File dialog.

FALSE: Evaluation continues to DP-002.

---

DP-002

Condition: select_file = FALSE (and dialog_type ≠ SAVE_FILE)

TRUE: The function retrieves the user-selected path from the WUF_GFN_OPENDIR bean property, presenting a directory-selection dialog.

FALSE: The function retrieves the user-selected path from the WUF_GFN_OPENFILE bean property, presenting an Open File dialog.

---

DP-003

Condition: The position of '\\' within the result string equals 1 (i.e., the path begins with a double-backslash, indicating a UNC path)

TRUE: An additional '\\' is prepended to the result before the global replace is executed, preserving the UNC prefix.

FALSE: No prefix is added; the global replace proceeds on the result as returned by the bean.

---

DP-004

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property access

TRUE: An error alert is displayed identifying the missing bean class, and FORM_TRIGGER_FAILURE is raised to halt form processing.

FALSE: Normal processing continues.

---

DP-005

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during bean property access

TRUE: FORM_TRIGGER_FAILURE is raised to halt form processing.

FALSE: Normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All five dialog configuration properties (initial directory, default file name, file filter, dialog title, and multi-select flag) must be written to the WebUtil bean before any dialog variant is invoked; no dialog may be presented with uninitialised properties.
- BR-002 - The dialog mode is determined exclusively by the combination of dialog_type and select_file: a dialog_type equal to SAVE_FILE always invokes the Save File variant regardless of select_file; a FALSE select_file (with any non-SAVE_FILE dialog_type) invokes the directory picker; any other combination invokes the Open File picker.
- BR-003 - The path returned by the bean must be normalised by collapsing all double-backslash sequences ('\\') to single backslashes ('\') before the value is returned to the caller, ensuring a consistent file-system path format.
- BR-004 - UNC paths (those beginning with '\\') must be protected prior to normalisation by prepending an extra '\\', so that the leading double-backslash is preserved intact after the global replace operation.
- BR-005 - If the required WebUtil client-side bean is not registered in the runtime environment, the function must not return a partial or empty result; it must alert the user with the missing bean's implementation class name and terminate form processing via FORM_TRIGGER_FAILURE.
- BR-006 - Any property-level error raised during bean communication must immediately terminate form processing via FORM_TRIGGER_FAILURE; no partial path value may be returned to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-033 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text-based read, write, or append operations and returns a file handle that subsequent WebUtil client-side file I/O routines can use. It is invoked as part of the Excel report generation flow in VIEW_EXCEL_REPORT_NEW to establish a writable client-side file stream before report data is written.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied filemode value (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is not recognised.
- Step 2 - Validate the file specification: confirm that the spec parameter is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR if the file path is absent.
- Step 3 - Transmit the file path to the WebUtil client bean by calling WebUtil_Core.setProperty with property key WUF_FILENAME and the supplied spec value.
- Step 4 - Transmit the file mode to the WebUtil client bean by calling WebUtil_Core.setProperty with property key WUF_TEXTIO_FILEMODE and the supplied filemode value.
- Step 5 - Transmit the character set to the WebUtil client bean: if charSet is NULL, set property WUF_TEXTIO_CHARSET to the literal string '(null)'; otherwise set it to the supplied charSet value.
- Step 6 - Request the client bean to open the file by calling WebUtil_Core.getProperty with property key WUF_TEXTIO_OPEN, which returns a Java-side file handle string (javaHandle).
- Step 7 - Validate the returned handle: if javaHandle is NULL, empty, or equals '-1', the file could not be opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid javaHandle string to a numeric value, assign it to the clientFile.handle field of the file_type record, and return the populated file_type record to the caller.

---
**Decision Points**

DP-001

Condition: The supplied filemode (converted to lower case) is NOT one of 'r', 'w', or 'a'.

TRUE: TOOL_ERR.TOOL_ERROR is raised immediately; processing does not continue.

FALSE: Validation passes and processing continues to the file-specification check.

---

DP-002

Condition: The supplied spec parameter is NULL or an empty string.

TRUE: TOOL_ERR.TOOL_ERROR is raised immediately; no attempt is made to open a file.

FALSE: Validation passes and processing continues to the WebUtil property-setting steps.

---

DP-003

Condition: The charSet parameter is NULL.

TRUE: The WUF_TEXTIO_CHARSET property is set to the literal string '(null)', signalling to the client bean that no explicit character set is required.

FALSE: The WUF_TEXTIO_CHARSET property is set to the caller-supplied charSet value.

---

DP-004

Condition: The javaHandle returned by WebUtil_Core.getProperty is NULL, an empty string, or equals '-1'.

TRUE: The client-side file could not be opened; TOOL_ERR.TOOL_ERROR is raised and no file handle is returned.

FALSE: The handle is valid; it is converted to a number, assigned to clientFile.handle, and the file_type record is returned to the caller.

---

DP-005

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is caught in the exception block.

TRUE: An error alert is displayed identifying the missing bean class, TOOL_ERR.TOOL_ERROR is raised, and NULL is returned.

FALSE: Exception does not occur; normal processing or other exception handlers apply.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively. Any other value is treated as an invalid request and causes immediate termination with an error.
- BR-002 - A non-null, non-empty file path (spec) is mandatory. Attempting to open a file without specifying a path is not permitted.
- BR-003 - Character set specification is optional. When omitted, the WebUtil client bean is explicitly instructed to apply no character set override by receiving the sentinel value '(null)'.
- BR-004 - A file is considered successfully opened only when the client bean returns a non-null, non-empty handle that is not equal to '-1'. Any other response is treated as a failure.
- BR-005 - The numeric file handle returned by the client bean is the sole mechanism for subsequent client-side file operations; it must be preserved in the returned file_type record's handle field.
- BR-006 - If the required WebUtil client bean is not registered in the Forms runtime environment, the function must surface a descriptive error alert and terminate with TOOL_ERR.TOOL_ERROR rather than silently failing.
- BR-007 - VALUE_ERROR encountered during handle conversion (to_number) is re-raised as TOOL_ERR.TOOL_ERROR, ensuring all failure modes surface through a consistent error-signalling mechanism.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-034 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of the callback trigger associated with a given numeric key from the internal callbacks collection. This function is used by WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback key during WebUtil data-processing operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) as input.
- Step 2 - Look up the entry at position callbackKey within the internal package-level collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup on the m_callbacks collection and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-populated index in the m_callbacks collection; supplying an undefined or out-of-range key will raise a standard PL/SQL collection error.
- BR-002 - The function returns exactly the VARCHAR2 value stored at the specified index in m_callbacks, with no transformation or defaulting applied.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-035 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This read-only accessor exposes the internally stored client OS family code, allowing calling routines to determine the client platform category without directly accessing the underlying module-level variable.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked with no input parameters.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client operating system family identifier.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller.

---
**Decision Points**

No decision points exist in this function. The implementation contains no conditional branching; it unconditionally returns the value of m_clientOSFamily.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts no input parameters; the client OS family value is sourced exclusively from the module-level variable m_clientOSFamily.
- BR-002 - The return value is of type PLS_INTEGER, representing the client operating system family identifier.
- BR-003 - The function performs no computation, transformation, or validation on the stored value; it returns m_clientOSFamily exactly as held at the time of invocation.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-036 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set and then read the local property, returning the resolved string value to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2) identifying the client-side configuration property to retrieve.
- Step 2 - If propertyName is not null, invoke WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied property name, instructing the WebUtil Core bean to resolve the requested client setting.
- Step 3 - Immediately invoke WebUtil_Core.getProperty for the same WUC_PACKAGE component and key WUC_GET_LOCAL_PROPERTY to read back the resolved value, storing it in the local variable result.
- Step 4 - If propertyName is null, skip Steps 2 and 3; result remains NULL.
- Step 5 - Return result (the resolved property value, or NULL if the input was null or no value was found).
- Step 6 - If the WebUtil Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a property interaction error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty to push the property name to the WebUtil Core bean, then call WebUtil_Core.getProperty to retrieve the resolved client setting value and assign it to result.

FALSE: Skip the bean interaction entirely; result remains NULL and is returned as-is.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean interaction

TRUE: Display an error alert concatenating the implementation class name with a message indicating the bean was not found and that GetClientSetting will not work, then raise FORM_TRIGGER_FAILURE.

FALSE: No exception of this type; continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during bean interaction

TRUE: Raise FORM_TRIGGER_FAILURE immediately to halt form processing.

FALSE: No exception of this type; continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any interaction with the WebUtil Core bean; the function returns NULL without attempting to set or retrieve any property.
- BR-002 - The property name must be passed to the WebUtil Core bean via WebUtil_Core.setProperty before its value can be read back via WebUtil_Core.getProperty; both calls must target the WUC_PACKAGE component using the key WUC_GET_LOCAL_PROPERTY.
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, form processing must be halted via FORM_TRIGGER_FAILURE after presenting a descriptive error alert that identifies the missing bean class.
- BR-004 - If a property interaction error (PROPERTY_ERROR) occurs, form processing must be halted via FORM_TRIGGER_FAILURE; no additional alert is presented for this condition.
- BR-005 - The returned property value must not exceed 255 characters, as enforced by the VARCHAR2(255 char) declaration of the result variable.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-037 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class entry for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Retrieve the implementation class string associated with packageID from the m_implClasses collection.
- Step 3 - Prepend the WEBUTIL_JAVA_ROOT constant to the retrieved implementation class string to form the fully qualified class name.
- Step 4 - Return the concatenated fully qualified Java implementation class name to the caller.

---
**Decision Points**

No decision points are present in this function. The logic is a single unconditional concatenation and return operation with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java implementation class name is always constructed by concatenating WEBUTIL_JAVA_ROOT with the entry stored in m_implClasses at the index corresponding to packageID; neither value is independently returned.
- BR-002 - The packageID supplied must correspond to a valid index in the m_implClasses collection; no bounds or null validation is performed within this function, so the caller (WEBUTIL.EXECUTE) is responsible for passing a valid packageID.
- BR-003 - The function returns a VARCHAR2 value and has no output parameters or database interactions; its sole responsibility is class-name resolution from in-memory package metadata.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-038 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function interrogates the underlying Java Native Interface (JNI) layer to obtain an integer error status from the active file-transfer session, allowing the caller (WEBUTIL.SETDATA) to determine whether a preceding file-transfer operation completed successfully or encountered a fault.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object reference (obj) passed in by the caller.
- Step 2 - Reset the JNI argument list by setting args to NULL, ensuring no stale arguments are forwarded to the Java method.
- Step 3 - Invoke the Java method getLastError on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_INT_METHOD, passing FALSE (non-static call), the object reference, the fully qualified class name, the method name, and the method signature '()I' (no parameters, returns integer).
- Step 4 - Return the integer error code produced by the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally resets the argument list, calls the Java method, and returns the resulting integer error code.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always reset the JNI argument list (args := NULL) before invoking the Java method to prevent argument contamination from any prior JNI call.
- BR-002 - The target Java method is instance-scoped (non-static); a valid AppServerFileReader object reference must be supplied via the obj parameter, as the JNI call is made with the static flag set to FALSE.
- BR-003 - The returned integer value represents the last error state of the AppServerFileReader object; a value of zero conventionally indicates no error, while any non-zero value signals a fault condition to be handled by the caller.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-039 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates to the JNI layer to invoke the native Java method and returns the error argument details as a VARCHAR2 string, allowing the calling routine (WEBUTIL.SETDATA) to obtain contextual error information from the underlying file-transfer component.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing FALSE (non-static call), the object reference, the fully qualified class path, the method name, and the method signature '()Ljava/lang/String;' with the cleared args list.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the caller, representing the error argument details from the last error recorded by the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence: clear args, invoke the JNI method, and return the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be explicitly set to NULL before the JNI call to prevent stale argument data from a previous invocation from being passed to the Java method.
- BR-002 - The function must target the fully qualified Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and the instance method getLastErrorArgs with signature ()Ljava/lang/String; to ensure the correct native method is resolved.
- BR-003 - The call must be made as a non-static (instance-level) invocation (FALSE flag to JNI.CALL_STRING_METHOD), requiring a valid AppServerFileReader object reference to be supplied by the caller.
- BR-004 - The function returns the raw VARCHAR2 value produced by the JNI layer without transformation; no null-handling or default substitution is applied.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-040 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and returns its value as a NUMBER. The procedure delegates string extraction to WEBUTIL.GETSTRING (SP-044) and applies a TO_NUMBER conversion to the result, providing a type-safe numeric counterpart to the string extraction utility for use within the WebUtil custom event handler framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-044](#SP-044--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-044), which locates and extracts the delimited token at the specified field position within the source string.
- Step 3 - Apply Oracle's TO_NUMBER function to the VARCHAR2 value returned by WEBUTIL.GETSTRING, converting it to a numeric data type.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

- DP-001

  Condition: The UnTerminated parameter is passed as TRUE.

  TRUE: WEBUTIL.GETSTRING treats the final field in the source string as unterminated (i.e., not followed by a delimiter), ensuring the last token is correctly extracted without requiring a trailing delimiter.

  FALSE: WEBUTIL.GETSTRING applies standard delimited parsing, expecting each field including the last to be bounded by the specified delimiter.

- DP-002

  Condition: The Delimiter parameter is supplied by the caller.

  TRUE: WEBUTIL.GETSTRING uses the caller-supplied delimiter character to tokenise the source string.

  FALSE: WEBUTIL.GETSTRING defaults to a comma (',') as the field delimiter.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a Source_string and a Field_position; both are mandatory IN parameters with no default values, and the function will not execute meaningful extraction without them.
- BR-002 - The Delimiter parameter defaults to a comma (',') if not explicitly provided by the caller, establishing comma-separated format as the standard tokenisation convention.
- BR-003 - The UnTerminated parameter defaults to FALSE, meaning the source string is assumed to have a delimiter following every field unless the caller explicitly overrides this behaviour.
- BR-004 - The extracted field value must be implicitly convertible to a NUMBER by Oracle's TO_NUMBER function; if WEBUTIL.GETSTRING returns a non-numeric string, the function will raise a standard Oracle numeric conversion error.
- BR-005 - All string extraction logic is exclusively delegated to WEBUTIL.GETSTRING (SP-044); WEBUTIL.GETNUMBER performs no independent parsing and adds only the numeric type conversion layer.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-041 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string. The function maps a raw OS name value to a predefined platform constant (Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown) and stores the result in the package-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluation. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive comparison.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform classification.
- Step 3 - Check whether the package-level cache variable m_clientOSFamily is already populated. If it is not null, skip all classification logic and proceed directly to Step 10.
- Step 4 - If m_clientOSFamily is null, inspect l_osName for the substring 'windows'. If found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' is not found, inspect l_osName for the substring 'mac'. If found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' is not found, inspect l_osName for the substring 'linux'. If found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' is not found, inspect l_osName for the substrings 'solaris' or 'sunos'. If either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator is found, inspect l_osName for the substring 'hp-ux'. If found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' is not found, inspect l_osName for the substring 'aix'. If found, set result to CLIENT_PLATFORM_AIX. If none of the known substrings matched, result remains CLIENT_PLATFORM_UNKNOWN.
- Step 10 - Assign the resolved result value to the package-level variable m_clientOSFamily, persisting the classification for the remainder of the session.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (the OS family has not yet been determined for this session).

TRUE: Execute the full OS name classification logic (Steps 4-10) and populate m_clientOSFamily with the resolved platform constant.

FALSE: Bypass all classification logic and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to evaluate the next OS family substring ('mac').

---

DP-003

Condition: l_osName contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to evaluate the next OS family substring ('linux').

---

DP-004

Condition: l_osName contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to evaluate the next OS family substrings ('solaris' / 'sunos').

---

DP-005

Condition: l_osName contains the substring 'solaris' OR the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to evaluate the next OS family substring ('hp-ux').

---

DP-006

Condition: l_osName contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to evaluate the next OS family substring ('aix').

---

DP-007

Condition: l_osName contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no recognised OS family was matched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison must be case-insensitive; the input value is converted to lowercase before any substring matching is performed.
- BR-002 - Platform classification is mutually exclusive and evaluated in strict priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and no further checks are performed.
- BR-003 - If the supplied OS name does not match any recognised platform substring, the function must return CLIENT_PLATFORM_UNKNOWN; no error is raised and processing completes normally.
- BR-004 - The resolved OS family is cached in the package-level variable m_clientOSFamily for the lifetime of the session. Once set, the classification logic is not re-executed on subsequent calls, ensuring consistent platform identification across all invocations within the same session.
- BR-005 - The function accepts 'solaris' and 'sunos' as equivalent indicators for the Solaris platform; either substring alone is sufficient to classify the client as CLIENT_PLATFORM_SOLARIS.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-042 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a given client-side process by iteratively polling the WebUtil host bean property until no further lines are available, returning the collected lines as an OUTPUT_ARRAY. The function is called by WEBUTIL.GET_STANDARD_OUTPUT to capture process output in a Forms web deployment context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-051](#SP-051--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil host package by calling WebUtil_Core.setProperty with the WUH_PACKAGE target, property key WUH_PROC_ID, and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a loop to retrieve output lines one at a time by calling WebUtil_Core.getProperty with the WUH_PACKAGE target and the caller-supplied property name (prop), storing the result in a buffer.
- Step 3 - Extract the first character of the buffer as a status indicator: 'Y' signals that more lines follow, 'N' signals this is the last line, and 'X' signals the buffer was empty.
- Step 4 - If the status is not 'X' (i.e., the buffer contains a valid line), extract the substring from position 2 onward as the line content and append it to the OUTPUT_ARRAY at the current index, then increment the index counter.
- Step 5 - Exit the loop when the status is not 'Y' (i.e., status is 'N' indicating the final line has been read, or 'X' indicating an empty buffer).
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - On exception, if the WebUtil bean is not registered (BEAN_NOT_REGISTERED), display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function.
- Step 8 - In the package initialisation block, call Webutil_Core.Init to ensure the core WebUtil infrastructure is instantiated before any function in the package is invoked.

---
**Decision Points**

DP-001

Condition: The first character of the buffer returned by WebUtil_Core.getProperty is not 'X'.

TRUE: The buffer contains a valid output line; the substring from position 2 is stored in the OUTPUT_ARRAY and the index is incremented.

FALSE: The buffer is empty; no entry is added to the OUTPUT_ARRAY and the loop proceeds to the exit evaluation.

DP-002

Condition: The status character extracted from the buffer is not 'Y'.

TRUE: No further output lines are expected (status is 'N' for last line, or 'X' for empty buffer); the loop exits and the collected array is returned.

FALSE: More output lines remain (status is 'Y'); the loop continues and retrieves the next line.

DP-003

Condition: A BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: The required WebUtil host bean is not available on the client; an error alert is displayed identifying the missing bean class and the function does not return an array.

FALSE: No exception is raised; normal processing completes and the OUTPUT_ARRAY is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil host package via WebUtil_Core.setProperty before any output lines are retrieved; this binding is mandatory and performed as the first action of the function.
- BR-002 - Output lines are retrieved sequentially in the order they are returned by WebUtil_Core.getProperty; the function does not support random access or reordering of lines.
- BR-003 - A buffer status of 'X' indicates an empty response and must not result in an entry being added to the OUTPUT_ARRAY; only status values 'Y' or 'N' produce stored output lines.
- BR-004 - The loop must terminate on any status value other than 'Y', ensuring that both a definitive end-of-output signal ('N') and an empty-buffer signal ('X') cause the retrieval loop to exit cleanly.
- BR-005 - If the WebUtil host bean is not registered on the client, the function must surface a descriptive error alert identifying the missing bean class and must not silently fail or return a partial array.
- BR-006 - Webutil_Core.Init must be executed at package initialisation to guarantee that the core WebUtil infrastructure is available before GetOutput or any other package routine is called.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-043 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property by delegating to the Java Native Interface (JNI) layer. The function accepts a property name, invokes the standard Java method System.getProperty on the Forms server JVM, and returns the corresponding string value. It is used internally by WEBUTIL.EXECUTE and WEBUTIL.REGISTERBEAN to interrogate runtime environment properties required for WebUtil operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (a0) as the sole input parameter.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1) and assign the result to the shared args variable.
- Step 3 - Append the property name string to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java static method java.lang.System.getProperty via JNI.CALL_STRING_METHOD, passing the prepared argument list, targeting the class 'java/lang/System', method 'getProperty', with the descriptor '(Ljava/lang/String;)Ljava/lang/String;'.
- Step 5 - Return the string value produced by the JNI call directly to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name supplied in parameter a0 must be a valid Java system property name recognised by the server-side JVM; the function passes it directly to java.lang.System.getProperty without prior validation.
- BR-002 - The function is a static-method invocation (first argument to JNI.CALL_STRING_METHOD is TRUE and the object reference is NULL), meaning it operates on the JVM class level rather than on an object instance.
- BR-003 - If the specified property does not exist in the JVM, the underlying Java method returns NULL, and consequently this function returns NULL to the caller; callers (WEBUTIL.EXECUTE and WEBUTIL.REGISTERBEAN) are responsible for handling a NULL return value.
- BR-004 - No database interactions occur; all processing is confined to the JNI/JVM layer, making the function side-effect-free with respect to Oracle database state.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-044 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string at a specified field position. Given a delimiter-separated string, the function returns the substring occupying the nth field (Field_position), supporting both pre-terminated and unterminated source strings. It is used internally by WEBUTIL.GETNUMBER to isolate individual fields before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaults to comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the working copy so that the last field is bounded and can be located consistently by subsequent instr calls.
- Step 4 - Determine the start pointer (iPtrStart): if Field_position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence Field_position - 1) and advance the pointer past the delimiter using WEBUTIL.LENGTH; otherwise set iPtrStart to 1 (first character).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the delimiter at occurrence Field_position within the working copy.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which corresponds exactly to the content of the requested field, excluding its surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any parsing begins, ensuring the final field is bounded and detectable by instr.

FALSE: The source string is used as-is; no modification is made to the working copy.

---

DP-002

Condition: Field_position is greater than 1.

TRUE: iPtrStart is calculated by finding the (Field_position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the target field.

FALSE: iPtrStart is set to 1, meaning extraction begins at the very start of the string (the first field has no preceding delimiter).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates on a working copy of the source string; the original Source_string parameter is never modified.
- BR-002 - When the source string does not end with a delimiter (UnTerminated = TRUE), the delimiter must be appended before parsing; failure to do so would cause the last field to be undetectable by the instr-based boundary logic.
- BR-003 - Field positions are 1-based; Field_position = 1 always starts extraction from the first character of the string.
- BR-004 - The delimiter defaults to a comma if not explicitly supplied, supporting standard CSV-style strings without requiring the caller to specify a delimiter.
- BR-005 - The extracted token excludes the delimiter characters themselves; only the content between delimiters is returned.
- BR-006 - The function supports source strings up to 32,000 characters in length, consistent with the varchar2(32000) working variable declaration.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-045 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named configuration variable from the client environment by applying a platform-specific resolution strategy. On Windows clients, the procedure first queries the Oracle registry key (HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE) and falls back to the Windows environment string if the registry lookup returns no value. On Unix clients, it executes a blocking 'env' command, captures the standard output, and parses the key=value pairs to locate the requested variable. On macOS and unknown platforms, no action is taken. The resolved value is returned to the caller via the IN OUT parameter VARVALUE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-077](#SP-077--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-080](#SP-080--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-035](#SP-035--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-048](#SP-048--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and the current value holder (VARVALUE) as input.
- Step 2 - Determine the client operating-system family by calling WEBUTIL.GETCLIENTOSFAMILY (WebUtil_Core.GetClientOSFamily).
- Step 3 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY (Client_Win_API_Environment.read_registry), passing VARNAME and a case-insensitive flag of false.
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to retrieving the value from the Windows environment using GET_ENVIRONMENT_STRING (CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING), passing VARNAME.
- Step 5 - If the client is macOS (CLIENT_PLATFORM_MAC) or an unknown platform (CLIENT_PLATFORM_UNKNOWN), take no action and leave VARVALUE unchanged.
- Step 6 - For all other platforms (Unix), execute the shell command 'env' as a blocking host process to obtain all environment variables, capturing the output via WEBUTIL.GET_STANDARD_OUTPUT (WebUtil_HOST.Get_Standard_Output), then release the process handle.
- Step 7 - Iterate over each line of the captured Unix output; for each line, locate the '=' delimiter, extract the key portion, and compare it to VARNAME. When a match is found, extract the value portion into VARVALUE and exit the loop.
- Step 8 - If a NO_DATA_FOUND exception is raised at any point during processing, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: The client OS family is Windows (WebUtil_Core.CLIENT_PLATFORM_WIN32).

TRUE: Attempt to resolve VARVALUE from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY; if the result is NULL or empty, fall back to GET_ENVIRONMENT_STRING.

FALSE: Proceed to DP-002.

DP-002

Condition: The registry lookup via READ_REGISTRY returns NULL or an empty string (Windows path only).

TRUE: Retrieve VARVALUE by calling GET_ENVIRONMENT_STRING with VARNAME.

FALSE: Use the non-null registry value already stored in VARVALUE; no further lookup is performed.

DP-003

Condition: The client OS family is macOS (CLIENT_PLATFORM_MAC) or unknown (CLIENT_PLATFORM_UNKNOWN).

TRUE: Take no action; VARVALUE remains unchanged.

FALSE: The client is a Unix platform; proceed to execute the 'env' command and parse its output.

DP-004

Condition: A '=' delimiter is found (iPos > 0) in the current line of Unix 'env' output.

TRUE: Extract the key and compare it to VARNAME; if they match, extract the value into VARVALUE and exit the loop.

FALSE: Skip the current line and continue iterating.

DP-005

Condition: The extracted Unix environment key (varKey) equals VARNAME.

TRUE: Assign the substring after '=' to VARVALUE and exit the loop immediately.

FALSE: Continue iterating through the remaining output lines.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE is always the primary source for variable resolution; the Windows environment string is only consulted as a secondary fallback when the registry returns no value.
- BR-002 - On macOS and unknown client platforms, variable resolution is explicitly suppressed; VARVALUE is not modified.
- BR-003 - On Unix clients, variable resolution is performed exclusively by parsing the output of the 'env' shell command; direct environment API calls are not used.
- BR-004 - Unix environment variable matching is exact and case-sensitive, based on a character-by-character key comparison against VARNAME.
- BR-005 - Once a matching Unix environment variable is found, iteration stops immediately; only the first match is used.
- BR-006 - A NO_DATA_FOUND exception during any resolution path results in VARVALUE being set to NULL, ensuring a safe, defined output state rather than an unhandled error.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-046 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure is used during Excel report generation (VIEW_EXCEL_REPORT_NEW) to retrieve file content line by line via the WebUtil client-server bridge.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle (file_type) that identifies the open client-side text file to be read.
- Step 2 - Pass the file handle to the WebUtil core layer by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component, making the target file known to the PJC bean.
- Step 3 - Request the next line of text from the PJC bean by reading the WUF_TEXTIO_GETLINE property from WUF_PACKAGE; the returned value is stored in a local VARCHAR2 buffer (up to 4000 characters).
- Step 4 - Inspect the buffer content: if the buffer contains a newline character (CHR(10)), this is the sentinel value placed by the PJC exception handler to signal end-of-file, so raise NO_DATA_FOUND to communicate EOF to the caller.
- Step 5 - If the buffer does not contain the sentinel value, assign the buffer content to the OUT parameter item and return it to the caller.
- Step 6 - On exception: if the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise TOOL_ERROR; if a property error occurs, raise TOOL_ERROR immediately.

---
**Decision Points**

DP-001

Condition: The value returned from WUF_TEXTIO_GETLINE equals CHR(10) (newline character), indicating the PJC bean has signalled end-of-file.

TRUE: Raise NO_DATA_FOUND to notify the caller that there are no more lines to read.

FALSE: Assign the buffer content to the OUT parameter item and return it to the caller.

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during property get/set operations, meaning the required WebUtil PJC bean is not available on the client.

TRUE: Display an error alert identifying the missing bean class and raise TOOL_ERROR to halt processing.

FALSE: Continue normal execution (no action taken for this exception path).

DP-003

Condition: A PROPERTY_ERROR exception is raised during property get/set operations.

TRUE: Raise TOOL_ERROR immediately to halt processing.

FALSE: Continue normal execution (no action taken for this exception path).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A newline character (CHR(10)) returned in the read buffer is reserved exclusively as an end-of-file sentinel placed by the PJC exception handler; it is never treated as valid line content and must trigger NO_DATA_FOUND.
- BR-002 - The maximum length of a single line that can be retrieved is 4000 characters, as enforced by the VARCHAR2(4000 CHAR) buffer declaration.
- BR-003 - The WebUtil PJC bean must be registered and reachable on the client before this procedure is called; absence of the bean is a fatal condition that raises TOOL_ERROR after alerting the user.
- BR-004 - Any property-level communication error with the WebUtil core layer is treated as a fatal condition and raises TOOL_ERROR without further recovery.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-047 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the numeric return code produced by a previously executed host process. Given a PROCESS_ID handle, the function communicates the process identifier to the WebUtil bean layer and reads back the integer return code that the host process generated, allowing the caller to evaluate whether the process succeeded or failed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of the host process whose return code is to be retrieved.
- Step 2 - Set the process handle property on the WebUtil bean by calling WebUtil_Core.setProperty, targeting the WUH_PACKAGE context with the property key WUH_PROC_ID and the value of process.handle.
- Step 3 - Read the return code from the WebUtil bean by calling WebUtil_Core.getProperty on the WUH_PACKAGE context with the property key WUH_RC, then convert the retrieved string value to a numeric integer using TO_NUMBER.
- Step 4 - Return the numeric return code to the caller.
- Step 5 - If the WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point, display an error alert via WebUtil_Core.ErrorAlert indicating that the required WebUtil Host bean could not be found and that Get_Return_Code will not function.

---
**Decision Points**

DP-001

Condition: Whether the WebUtil bean identified by WUH_PACKAGE is registered and available at runtime.

TRUE: The function sets the WUH_PROC_ID property, retrieves the WUH_RC property, converts it to a number, and returns it to the caller.

FALSE: The BEAN_NOT_REGISTERED exception is caught and WebUtil_Core.ErrorAlert is invoked to display an error message identifying the missing bean class; no return code is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A valid PROCESS_ID containing a non-null handle must be supplied; the handle is passed directly to the WebUtil bean as the WUH_PROC_ID property to identify which process result to retrieve.
- BR-002 - The return code is stored in the WebUtil bean layer under the property key WUH_RC and must be convertible to a PLS_INTEGER via TO_NUMBER; the function does not interact with the database to obtain this value.
- BR-003 - If the WebUtil Host bean is not registered, the function must raise an error alert that includes the bean implementation class name obtained from WebUtil_Core.getImplClass, clearly stating that WEBUTIL_HOST.Get_Return_Code will not work, and must not return a value.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-048 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output stream produced by a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT (SP-042), passing the fixed stream identifier 'WUH_STDOUT' to isolate standard output from other output channels associated with the given process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-042](#SP-042--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process identifier (PROCESS_ID) that references a previously executed host process whose output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-042), supplying the caller-provided process identifier and the hard-coded stream label 'WUH_STDOUT' to target the standard output channel.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller without further transformation.

---
**Decision Points**

No conditional decision points are present in this function. Execution follows a single, unconditional path: delegate to WEBUTIL.GETOUTPUT with a fixed stream identifier and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; callers cannot override this value, ensuring the function exclusively surfaces the standard output channel of the specified process.
- BR-002 - The function returns an OUTPUT_ARRAY type; the caller is responsible for handling an empty or null array if the process produced no standard output.
- BR-003 - All output retrieval logic is governed by WEBUTIL.GETOUTPUT (SP-042); this function introduces no additional filtering, transformation, or validation of the returned data.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-049 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command synchronously on the client machine from within an Oracle Forms session. The function submits the command via WEBUTIL.BLOCKING, waits for the process to complete, retrieves the OS return code, releases the client-side process handle, and returns the numeric exit code to the caller. It is used by the Excel report viewer (VIEW_EXCEL_REPORT_NEW) to launch external processes and confirm their outcome.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-020](#SP-020--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-047](#SP-047--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-064](#SP-064--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the OS command string (cmd) as input and initialise the return-code variable (RC) to -1, representing an unexecuted or failed state.
- Step 2 - Invoke WEBUTIL.BLOCKING(cmd) to execute the command on the client machine and block until the process finishes; the function returns a PROCESS_ID handle (procId) identifying the completed process.
- Step 3 - Evaluate the process handle using WEBUTIL.ID_NULL(procId) to determine whether a valid process was created.
- Step 4 - If the handle is valid (not null), invoke WEBUTIL.GET_RETURN_CODE(procId) to retrieve the numeric OS exit code returned by the completed process, and assign it to RC.
- Step 5 - Release the client-side process object by invoking WEBUTIL.RELEASE_PROCESS(procId), freeing any resources associated with the process handle.
- Step 6 - Return RC to the caller, conveying the OS exit code (or -1 if the process could not be started).

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(procId) evaluates to TRUE - the process handle returned by WEBUTIL.BLOCKING is null, indicating the host command failed to launch.

TRUE: The return-code retrieval and resource-release steps are skipped; RC retains its initialised value of -1, which is returned to the caller to signal that no process was executed.

FALSE: The process launched successfully; WEBUTIL.GET_RETURN_CODE is called to obtain the OS exit code, WEBUTIL.RELEASE_PROCESS is called to free the handle, and the actual exit code is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The host command must be executed in blocking mode (via WEBUTIL.BLOCKING), ensuring the Forms session waits for the OS process to complete before proceeding; asynchronous execution is not permitted by this procedure.
- BR-002 - A return code of -1 is the sentinel value indicating that the host process was never successfully started; callers must treat -1 as a failure condition distinct from any valid OS exit code.
- BR-003 - The client-side process handle must always be released via WEBUTIL.RELEASE_PROCESS after the return code is retrieved, preventing resource leaks on the client machine.
- BR-004 - Return-code retrieval (WEBUTIL.GET_RETURN_CODE) is only performed when a valid process handle exists; querying the return code of a null handle is not permitted.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-050 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given pointer handle is uninitialised (null). The function inspects the internal 'hnd' attribute of the supplied Pointer and returns a Boolean result, allowing callers such as WEBUTIL.ERRORALERT, WEBUTIL.HOST, WEBUTIL.INITWEBUTIL, WEBUTIL.REGISTER_FUNCTION, WEBUTIL.SHOWBEANS, GENERAL.L_POP_LIST_ITEM, and VIEW_EXCEL_REPORT_NEW to guard against operations on invalid or unallocated handles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Pointer argument 'handle' passed in by the calling routine.
- Step 2 - Inspect the 'hnd' attribute of the supplied Pointer to determine whether it holds a null value.
- Step 3 - If 'hnd' is null, return TRUE to indicate that the handle is uninitialised.
- Step 4 - If 'hnd' is not null, return FALSE to indicate that the handle references a valid, allocated resource.

---
**Decision Points**

DP-001

Condition: handle.hnd IS NULL

TRUE: The function returns TRUE, signalling to the caller that the Pointer is uninitialised and does not reference a valid resource.

FALSE: The function returns FALSE, signalling to the caller that the Pointer is initialised and references a valid resource.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A Pointer is considered null solely on the basis of its internal 'hnd' attribute; no other attribute or external state is evaluated.
- BR-002 - The function is read-only and produces no side effects; it neither modifies the supplied Pointer nor interacts with any database object or external resource.
- BR-003 - The function must return a definitive Boolean value (TRUE or FALSE) for every invocation; no intermediate or indeterminate state is permitted.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-051 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core utility. Its sole responsibility is to trigger package initialisation by delegating to WEBUTIL.INITWEBUTIL (SP-052) via the package body's initialisation block. The procedure body itself performs no work; entering the package is sufficient to establish the runtime environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-052](#SP-052--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.GETOUTPUT invokes WEBUTIL.INIT to ensure the WebUtil core package is initialised before any utility operations are performed.
- Step 2 - The INIT procedure body executes a NULL statement, performing no direct processing; the act of entering the package is intentionally relied upon to trigger the package-level initialisation block.
- Step 3 - The package body's BEGIN...END initialisation block automatically calls INITWEBUTIL (SP-052), which carries out the actual setup of the WebUtil core utility.
- Step 4 - Control returns to the calling routine (WEBUTIL.GETOUTPUT) with the package fully initialised and ready for use.

---
**Decision Points**

No conditional decision points exist within this procedure. The INIT procedure body unconditionally executes NULL, and the package initialisation block unconditionally calls INITWEBUTIL. There are no branching conditions to document.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - WEBUTIL.INIT must contain no substantive processing logic; entering the package is the mechanism by which initialisation is achieved, ensuring the package-level BEGIN block fires exactly once per session.
- BR-002 - The actual initialisation of the WebUtil core utility is exclusively delegated to WEBUTIL.INITWEBUTIL (SP-052); WEBUTIL.INIT must not duplicate or replace that logic.
- BR-003 - WEBUTIL.INIT accepts no input or output parameters; it is invoked purely for its side effect of triggering package initialisation.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-052 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form session. The procedure registers the Java implementation class names for each WebUtil sub-package, validates that the mandatory WebUtil object group (including its error alert and dummy item) is present in the calling form, optionally navigates to the WebUtil bean area to force bean instantiation, and determines the server-side file-path separator based on the host operating system. It must be called once, via WEBUTIL.INIT, before any other WebUtil functionality is used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-068](#SP-068--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to be used later in navigation logic.
- Step 2 - Populate the internal implementation-class registry (m_implClasses) by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java class name string. WUU_PACKAGE is registered with an empty string, indicating no Java class is assigned to that slot.
- Step 3 - Check whether the WebUtil error alert object (m_errorAlert) is null using WEBUTIL.ID_NULL. If it is null, the required WebUtil object group is absent from the form; display an error message and pause execution - WebUtil cannot proceed.
- Step 4 - If the error alert is present, evaluate whether explicit bean instantiation is required: the package-level flag FLAG_EXPICIT_INSTANCIATE must be TRUE and the form must be in NORMAL mode (SYSTEM.MODE = 'NORMAL').
- Step 5 - Within that branch, check whether the WebUtil dummy item exists (ID_NULL returns FALSE for hDummy). If it exists, navigate to it via GO_ITEM to trigger bean rendering.
- Step 6 - After navigating to the dummy item, determine whether the original cursor field resides in the same block as the dummy item. If it does, call NEXT_BLOCK to move focus away; otherwise, return focus to the original cursor field via GO_ITEM(startPoint).
- Step 7 - Invoke WEBUTIL.SHOWBEANS(false) to display the bean areas without forcing a repaint.
- Step 8 - If the dummy item does not exist, take no action; the developer is assumed to be managing bean setup independently.
- Step 9 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) is TRUE - the WebUtil error alert object is not found in the form.

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', pause execution, and abort further initialisation.

FALSE: The WebUtil object group is present; proceed with bean instantiation and OS detection steps.

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE = 'NORMAL'.

TRUE: Attempt explicit bean instantiation by navigating to the dummy item and calling WEBUTIL.SHOWBEANS.

FALSE: Skip bean instantiation navigation entirely (e.g., form is in Enter-Query mode, or the flag is set to suppress this behaviour).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) is FALSE - the standard WebUtil dummy item exists in the form.

TRUE: Navigate to the dummy item, resolve block context, and call WEBUTIL.SHOWBEANS(false).

FALSE: Take no action; the developer is responsible for managing bean area setup.

---

DP-004

Condition: The block containing the original cursor field (startPoint) is the same block as the one containing the dummy item.

TRUE: Call NEXT_BLOCK to move focus out of the dummy item's block after bean initialisation.

FALSE: Return focus directly to the original cursor field via GO_ITEM(startPoint).

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 - the server OS name contains 'WIN'.

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil object group, including its error alert object, must be present in the calling form before InitWebUtil can complete successfully. Absence of the error alert is treated as a fatal configuration error and all further WebUtil initialisation is halted.
- BR-002 - Explicit bean instantiation navigation is suppressed when the form is in Enter-Query mode (SYSTEM.MODE ≠ 'NORMAL') to avoid navigation conflicts, regardless of the FLAG_EXPICIT_INSTANCIATE setting.
- BR-003 - Explicit bean instantiation navigation is further controlled by the package-level flag FLAG_EXPICIT_INSTANCIATE, allowing the behaviour to be toggled on or off as a workaround without code changes.
- BR-004 - If the standard WebUtil dummy item is not present in the form, the procedure assumes the developer has implemented a custom bean setup strategy and takes no navigation action.
- BR-005 - After navigating to the dummy item, focus must be returned to the user's original location: if the original cursor field was in the same block as the dummy item, focus moves to the next block; otherwise it returns directly to the original cursor field, preserving the user's working context.
- BR-006 - WUU_PACKAGE is registered with an empty Java class name, indicating that no server-side Java implementation is mapped to that WebUtil package slot at initialisation time.
- BR-007 - The server file-path separator (m_serverFileSep) is determined once at initialisation by inspecting the application server's operating system; all subsequent WebUtil file-path operations within the session rely on this value.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-053 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean flag indicating whether the most recent WebUtil operation resulted in an error. It evaluates the internal module-level variable m_lastError and returns TRUE if a non-zero error code is held, allowing callers such as WEBUTIL.LOG to branch on error state without directly inspecting the raw error code.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the current value of the module-level variable m_lastError, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare m_lastError against zero to determine whether an error condition exists.
- Step 3 - Return TRUE if m_lastError is not equal to zero (an error is present), or FALSE if m_lastError equals zero (no error).

---
**Decision Points**

DP-001

Condition: m_lastError <> 0

TRUE: The function returns TRUE, signalling to the caller that the last WebUtil operation produced an error.

FALSE: The function returns FALSE, signalling to the caller that no error was recorded by the last WebUtil operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-zero value in m_lastError is the sole criterion for classifying the last WebUtil operation as an error; any non-zero code, regardless of its specific value, is treated as an error condition.
- BR-002 - The function is read-only with respect to m_lastError; it reports the error state but does not reset or modify it.
- BR-003 - The function accepts no input parameters; the error state is derived entirely from the module-level variable m_lastError, ensuring the result always reflects the most recent WebUtil operation in the current session context.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-054 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record (file) passed in by the caller.
- Step 2 - Inspect the handle attribute of the FILE_TYPE record to determine whether a valid file handle exists.
- Step 3 - If the handle is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate the file is currently open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling that no open file handle is associated with the supplied FILE_TYPE record.

FALSE: The function returns TRUE, signalling that a valid open file handle exists for the supplied FILE_TYPE record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its handle attribute is NOT NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs no file system operations and produces no side effects; it is a pure state-inspection utility that relies solely on the in-memory handle attribute of the FILE_TYPE record.
- BR-003 - The function must return a BOOLEAN result; no exception handling or default return value is defined, so the caller is responsible for ensuring a valid FILE_TYPE record is supplied.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-055 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL routines with a means to determine the size of a file on the server or client file system without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) that represents the target file whose size is to be determined.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the object reference, the class path 'java/io/File', the method name 'length', and the method signature '()J' (no parameters, returns a long).
- Step 4 - Return the numeric result received from the JNI call, representing the file size in bytes, to the calling routine.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input parameter obj must be a valid ORA_JAVA.JOBJECT reference to a java.io.File instance; the function does not perform null or validity checks on the object before invoking the JNI method.
- BR-002 - The file size is returned in bytes as a NUMBER, mapped from the Java primitive long returned by java.io.File.length().
- BR-003 - The JNI argument list (args) must be reset to NULL before each call to prevent argument pollution from prior JNI invocations within the same session context.
- BR-004 - The function performs no database reads or writes; all processing is confined to the JNI/Java layer, making the result entirely dependent on the file system state at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-056 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to a server-side log file, subject to configuration settings read from a property bundle. On first invocation, the procedure initialises a module-level logging cache (enabled flag, errors-only flag, and target file path) and communicates the resulting logging mode to the WebUtil client bean. Subsequent calls use the cached settings to append messages to the configured log file, optionally prefixing each entry with the client IP address and username.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-053](#SP-053--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-054](#SP-054--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level logging cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Read logging configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE: retrieve 'logging.enabled' (sets m_loggingAllowed), 'logging.errorsonly' (sets m_loggingErrorsOnly), and 'logging.file' (sets m_loggingFile).
- Step 3 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE) and report error WUC-008. If no bean is registered yet, raise the error as an alert via WEBUTIL.ERRORALERT; otherwise disable server-side logging on the bean (WUC_SRV_LOGGING = '0') and raise the error through WebUtil_Core.
- Step 4 - If at least one bean is registered, communicate the active logging mode to the bean by setting the WUC_SRV_LOGGING property: '1' for errors-only mode, '2' for full logging, or '0' if logging is disabled.
- Step 5 - After cache initialisation, evaluate whether logging is currently allowed (m_loggingAllowed = TRUE).
- Step 6 - If logging is allowed, evaluate whether the current message qualifies for writing: it qualifies if errors-only mode is off, or if errors-only mode is on and the isError parameter is TRUE.
- Step 7 - Open the log file in append mode (TEXT_IO.FOPEN). If the file cannot be opened, raise NO_DATA_FOUND to trigger the exception handler.
- Step 8 - Write the message to the log file. If m_clientIP is populated, prefix the message with the client IP address and username; otherwise write the message as-is. Close the file after writing.
- Step 9 - On exception: if SQLCODE is -302000 (file write failure), report error WUC-007 (via WEBUTIL.ERRORALERT if no bean is registered, or via WebUtil_Core otherwise), set WUC_SRV_LOGGING to '0', and permanently disable logging (m_loggingAllowed := FALSE). Any other exception is re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging cache not yet initialised).
TRUE: Read configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE, initialise module-level cache variables, and communicate the logging mode to the bean before proceeding.
FALSE: Use the already-cached logging settings and proceed directly to the write phase.

DP-002
Condition: Logging is enabled (m_loggingAllowed = TRUE) but m_loggingFile IS NULL.
TRUE: Disable logging (m_loggingAllowed := FALSE) and raise error WUC-008 indicating that no log file was specified.
FALSE: Retain the enabled state and continue with cache setup.

DP-003
Condition: At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) when reporting the WUC-008 / no-file error.
TRUE: Disable server-side logging on the bean (WUC_SRV_LOGGING = '0') and raise the error through WebUtil_Core.
FALSE: Raise the error in English via WEBUTIL.ERRORALERT (no bean available for property communication).

DP-004
Condition: At least one bean is registered after the logging cache is fully initialised.
TRUE: Set WUC_SRV_LOGGING on the bean to '1' (errors-only), '2' (full logging), or '0' (disabled) to reflect the active mode.
FALSE: Skip bean property communication; logging mode is held only in module-level variables.

DP-005
Condition: m_loggingAllowed = TRUE at the point of writing.
TRUE: Evaluate whether the message qualifies under the errors-only filter (DP-006) and attempt to write it.
FALSE: No action; the procedure exits without writing.

DP-006
Condition: m_loggingErrorsOnly = FALSE, OR (m_loggingErrorsOnly = TRUE AND isError = TRUE).
TRUE: Open the log file and write the message.
FALSE: Skip writing; the message does not meet the errors-only threshold.

DP-007
Condition: m_clientIP IS NULL at write time.
TRUE: Write the message text alone to the log file.
FALSE: Prefix the message with m_clientIP and m_clientUserName before writing.

DP-008
Condition: Exception is raised and SQLCODE = -302000 (file write failure).
TRUE: Report error WUC-007, set WUC_SRV_LOGGING to '0', and permanently disable logging (m_loggingAllowed := FALSE).
FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and log file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in module-level variables; subsequent calls reuse the cache without re-reading the bundle.
- BR-002 - If logging is enabled but no log file path is configured, logging must be disabled immediately and error WUC-008 must be reported; a missing file path is treated as a fatal configuration error that prevents any log writes.
- BR-003 - When errors-only mode is active (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently suppressed.
- BR-004 - Each log entry must be appended to the existing log file (open mode 'A'); the procedure must not overwrite prior log content.
- BR-005 - If the client IP address is known (m_clientIP IS NOT NULL), every log entry must be prefixed with the client IP address and username to support audit traceability.
- BR-006 - The active logging mode must be communicated to the registered WebUtil bean via the WUC_SRV_LOGGING property ('0' = disabled, '1' = errors only, '2' = full) whenever at least one bean is registered at the time of cache initialisation.
- BR-007 - If no bean is registered when an error condition (WUC-007 or WUC-008) must be reported, the error must be surfaced to the user via WEBUTIL.ERRORALERT in plain English, as no bean channel is available.
- BR-008 - A file write failure (SQLCODE -302000) must permanently disable logging for the session (m_loggingAllowed := FALSE) and report error WUC-007; any other exception must be re-raised unhandled.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-057 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if it holds the sentinel value '[NOTSET]', treat the path as unresolved and proceed to Step 2.
- Step 2 - Attempt to resolve the configuration file path from the environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, attempt to resolve the path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM.
- Step 4 - If all three sources fail to provide a path, raise NO_DATA_FOUND to trigger the error-handling branch.
- Step 5 - Write the resolved configuration file path back to WEBUTIL_CONFIG_GLOBAL so that subsequent calls can retrieve it directly without re-resolving.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no delimiter.
- Step 10 - For valid key-value lines, increment the property index, trim and lower-case the key portion, and trim and clean (removing CR characters) the value portion, then store both in the next slot of m_propertyBundle.
- Step 11 - After storing each entry, compare the stored key (lower-cased) against the lower-cased input propertyKey; if they match, capture the corresponding value as the result to be returned.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE.
- Step 13 - Return the captured result value (NULL if the key was not found in the file).

---
**Decision Points**

DP-001

Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains the sentinel value '[NOTSET]'.

TRUE: The configuration file path is unresolved; attempt resolution via the environment variable (TOOL_ENV.GETVAR) and then the Forms parameter before proceeding.

FALSE: Use the value already stored in WEBUTIL_CONFIG_GLOBAL as the configuration file path.

---

DP-002

Condition: The environment variable WEBUTIL_CONFIG_ENV returns a non-null configuration file path.

TRUE: Use the environment variable value as the configuration file path.

FALSE: Attempt to resolve the path from the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition: The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null configuration file path.

TRUE: Use the parameter value as the configuration file path.

FALSE: Raise NO_DATA_FOUND; no configuration file path is available and processing cannot continue.

---

DP-004

Condition: The first character of a line read from the configuration file is '#'.

TRUE: The line is a comment; skip it and read the next line.

FALSE: Attempt to parse the line as a key-value pair.

---

DP-005

Condition: The line contains an '=' character (INSTR returns a position greater than zero).

TRUE: Parse the line into a key and value, store them in m_propertyBundle, and check whether the key matches propertyKey.

FALSE: The line is not a valid key-value pair; skip it.

---

DP-006

Condition: The stored (lower-cased) property key matches the lower-cased input propertyKey.

TRUE: Capture the associated property value as the function result.

FALSE: Continue processing remaining lines without updating the result.

---

DP-007

Condition: A NO_DATA_FOUND exception is raised (no configuration file path was resolved) and m_registeredPackages is empty (no bean registered yet).

TRUE: Call WEBUTIL.ERRORALERT to display error message 'WUC-005: No WebUtil Configuration File specified' in English, set m_config_error to TRUE, and return NULL.

FALSE: Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 5, set m_config_error to TRUE, and return NULL.

---

DP-008

Condition: An OTHERS exception is raised and SQLCODE equals -302000 (file read failure), and m_registeredPackages is empty.

TRUE: Call WEBUTIL.ERRORALERT to display error message 'WUC-006: Unable to read WebUtil Configuration File' in English, set m_config_error to TRUE, and return NULL.

FALSE (bean registered): Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 6 and the configFile path, set m_config_error to TRUE, and return NULL. If SQLCODE is not -302000, re-raise the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources, evaluated in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing is aborted with an error.
- BR-002 - Once the configuration file path is resolved from the environment variable or Forms parameter, it must be written back to WEBUTIL_CONFIG_GLOBAL to cache the value for subsequent invocations.
- BR-003 - Lines beginning with '#' are treated as comments and must be excluded from parsing.
- BR-004 - Only lines containing an '=' character are valid key-value pairs; lines without this delimiter must be silently ignored.
- BR-005 - Property keys stored in m_propertyBundle must be lower-cased and stripped of leading and trailing whitespace; property values must be stripped of leading and trailing whitespace and have carriage-return characters (CHR(13)) removed.
- BR-006 - Key matching against the input propertyKey is case-insensitive; both the stored key and the input parameter are lower-cased before comparison.
- BR-007 - If no configuration file path is available (NO_DATA_FOUND) and no bean is registered, WEBUTIL.ERRORALERT must be used to present the error message in English; if a bean is registered, the error is delegated to Webutil_Core.Error.
- BR-008 - A file-read failure identified by SQLCODE -302000 must set m_config_error to TRUE and return NULL, using WEBUTIL.ERRORALERT when no bean is registered or Webutil_Core.Error otherwise; all other unexpected exceptions must be re-raised.
- BR-009 - The function returns NULL when the requested propertyKey is not found in the configuration file or when an error prevents file processing.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-058 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating to the WebUtil bean layer. It sets the active file handle and transmits the text argument to the WebUtil Text I/O bean, enabling Oracle Forms to perform client-side file write operations in a web-deployed environment. It is invoked as part of the Excel report generation flow in VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (arg) to be written.
- Step 2 - Register the active file handle with the WebUtil bean by calling WebUtil_Core.setProperty for the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component.
- Step 3 - Transmit the formatted text argument to the WebUtil bean by calling WebUtil_Core.setProperty for the WUF_TEXTIO_PUTF property on the WUF_PACKAGE component, instructing the bean to write the string to the file.
- Step 4 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 5 - If a property communication error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: The WebUtil bean identified by WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE) is registered and available at runtime.

TRUE: Both setProperty calls execute successfully; the file handle is set and the text string is written to the client-side file without error.

FALSE: A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed stating that the bean was not found and that CLIENT_TEXT_IO.putf will not work, after which TOOL_ERR.TOOL_ERROR is raised to terminate the calling process.

DP-002

Condition: The setProperty calls complete without a PROPERTY_ERROR exception (bean is registered but a property communication failure may still occur).

TRUE: The write operation completes normally and control returns to the caller.

FALSE: A PROPERTY_ERROR exception is raised; TOOL_ERR.TOOL_ERROR is raised immediately to terminate the calling process.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil bean corresponding to WUF_PACKAGE must be registered in the Forms session before this procedure is called; failure to register the bean prevents any client-side text file write operation and is treated as a fatal error.
- BR-002 - The file handle contained within the file_type parameter must be a valid, previously opened handle; it is passed directly to the WebUtil bean without additional validation by this procedure.
- BR-003 - Any failure in bean registration or property communication is treated as a fatal, non-recoverable error; TOOL_ERR.TOOL_ERROR is raised in both exception scenarios to ensure the calling process is halted rather than continuing with a failed or partial file write.
- BR-004 - No database interactions are performed by this procedure; its sole responsibility is client-side file I/O mediated through the WebUtil bean layer.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-059 - WEBUTIL.PUT_LINE

**Invoked From:**

- SP_GET_STORES_STOCK.prc [StoredProcedure: SP_GET_STORES_STOCK]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open client-side file by transmitting the text content and a newline instruction to the WebUtil bean via the WebUtil_Core property interface. It is invoked by SP_GET_STORES_STOCK to output store stock data line by line to a file on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, identifying the open file that will receive the text.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, passing the text string (item) as the content to write.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean to 1 via WebUtil_Core.setProperty, instructing the bean to append a newline character after the written text.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a property communication error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition: The WebUtil WUF_PACKAGE bean is registered and all three WebUtil_Core.setProperty calls complete without raising an exception.

TRUE: The file handle, text content, and newline flag are successfully transmitted to the bean; the line is written to the client-side file and the procedure exits normally.

FALSE: An exception is raised (either BEAN_NOT_REGISTERED or PROPERTY_ERROR), causing the procedure to enter the exception block and raise TOOL_ERR.TOOL_ERROR.

DP-002

Condition: The exception raised is WebUtil_Core.BEAN_NOT_REGISTERED.

TRUE: An error alert is displayed to the user identifying the missing bean class and stating that CLIENT_TEXT_IO.put_line will not work, after which TOOL_ERR.TOOL_ERROR is raised.

FALSE: The exception is WebUtil_Core.PROPERTY_ERROR; no alert is displayed and TOOL_ERR.TOOL_ERROR is raised immediately.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil WUF_PACKAGE bean must be registered on the client before this procedure is called; if it is not registered, the write operation cannot proceed and processing is halted with a TOOL_ERR.TOOL_ERROR.
- BR-002 - Every call to PUT_LINE appends a newline character (WUF_TEXTIO_NEWLINE = 1) after the supplied text, enforcing line-by-line file output semantics.
- BR-003 - Any property communication failure (PROPERTY_ERROR) is treated as a fatal error; the procedure raises TOOL_ERR.TOOL_ERROR without writing partial data, ensuring the file is not left in an inconsistent state.
- BR-004 - The file handle passed in the file parameter must correspond to a file already opened by the caller; this procedure does not open or validate the file itself.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-060 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been populated, it delegates initialisation to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. This function supports configuration-driven behaviour for routines such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, reusable mechanism for reading WebUtil configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory property bundle collection (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, immediately return NULL without further processing.
- Step 3 - If no configuration error exists and the property bundle collection is empty (propCount = 0), invoke WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested propertyKey, to initialise the bundle and obtain the result directly from that call.
- Step 4 - If the property bundle collection is already populated (propCount > 0), iterate through each entry in m_propertyBundle and compare the stored propertyKey (held in lowercase) against the lowercase-normalised form of the input propertyKey.
- Step 5 - On finding a matching entry, capture the corresponding propertyValue into the result variable and exit the loop immediately.
- Step 6 - Return the resolved result value (or NULL if no match was found or a config error was present) to the calling routine.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no property lookup is attempted.

FALSE: Proceed to evaluate the state of the property bundle collection.

---

DP-002

Condition: The property bundle collection (m_propertyBundle) contains zero entries (propCount = 0).

TRUE: Delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to initialise the bundle and retrieve the value for the requested key.

FALSE: Iterate through the existing collection entries to locate the matching property key.

---

DP-003

Condition: During iteration, the stored propertyKey of the current entry equals the lowercase form of the input propertyKey.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop.

FALSE: Continue to the next entry in the collection; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has previously been detected (m_config_error = TRUE), the function must return NULL without attempting any property lookup, preventing further processing against a known-bad configuration state.
- BR-002 - Property key comparisons are performed in a case-insensitive manner by comparing the input key against stored keys held in lowercase; callers may supply the key in any case.
- BR-003 - When the in-memory property bundle is empty, WEBUTIL.POPULATEPROPERTYBUNDLE must be invoked to load the bundle before a value can be returned; the function does not return a default or hard-coded fallback value.
- BR-004 - The returned property value is constrained to a maximum length of 1 000 characters (VARCHAR2(1 000 char)), consistent with the declared result variable.
- BR-005 - Once a matching entry is found during iteration, the loop exits immediately; only the first matching entry's value is returned, implying property keys within the bundle must be unique.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-061 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by submitting a property key and optional arguments to the WebUtil Core communication layer and reading back the resolved translation. The function is currently used exclusively by WEBUTIL.CHECKLIBS to obtain the localised title text for the progress bar displayed during library checking.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the mandatory propertyKey (identifying the message bundle entry to translate) and the optional args string (substitution arguments for the message).
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a single composite request value.
- Step 3 - Write the composite request value to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read the resolved translation back from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed set-then-get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The propertyKey parameter is mandatory and must identify a valid entry in the WebUtil message bundle; it is always included in the composite request value sent to the Core property store.
- BR-002 - The args parameter is optional (defaults to NULL); when NULL, the pipe delimiter is still appended to propertyKey, producing a trailing '|' in the composite request value.
- BR-003 - The translated message is retrieved immediately after it is set, using the same WUC_PACKAGE and WUC_TRANS_MSG identifiers, ensuring the return value corresponds to the request just submitted.
- BR-004 - The function does not perform any database reads or writes; all message resolution is delegated entirely to the Webutil_Core property store mechanism.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-062 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms session on its first contact. The procedure parses the bean's identification and environment data from the client, records the bean in the session's registered-package registry, resolves and communicates the system-library download directory to the client, initialises logging, and propagates heartbeat and server-logging configuration flags back to the registered bean. It is invoked once per unique bean type per form session from WEBUTIL_CORE.CUSTOMEVENTHANDLER.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-021](#SP-021--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-041](#SP-041--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-043](#SP-043--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-045](#SP-045--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) to identify which WebUtil package is registering.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding WEBUTIL_CORE package-ID constant.
- Step 3 - If the client IP address has not yet been captured (first bean registration in the session), mark the session for user-library checking and parse the remaining clientInfo fields: IP address (position 2), OS name (position 3), OS architecture (position 4), username (position 5), path separator (position 6), file separator (position 7), and language code (position 8). Determine the OS family via WEBUTIL.GETOSFAMILY and set the 64-bit architecture flag when the OS architecture string contains '64'.
- Step 4 - If the package ID has not already been registered in the m_registeredPackages array, record the current trigger item against that package ID and flag the package as new.
- Step 5 - If this is the first-bean initialisation pass (checkUserLibs = TRUE): reset REDOWNLOAD_SYSLIB to FALSE; retrieve the server host name using WEBUTIL.GETVAR with key 'COMPUTERNAME', falling back to 'HOST' if null.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with the OS-family- and architecture-specific key ('install.syslib.location.client.<family>.<arch>'), then with the OS-family-only key if the first lookup returns null.
- Step 7 - If no client library directory is found in the property bundle, send a syslib-directory property to the WUC bean containing only the server host and application config, letting the client default to the JRE directory. If a directory is found, replace the '$(SERVERHOST)' token with the resolved server host name, send the full path to the WUC bean, compare it against the previously stored client setting via WEBUTIL.GETCLIENTSETTING, and if the directory has changed, persist the new value via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version from the WUC bean property 'WUC_BEAN_VERSION' via WEBUTIL.GETPROPERTY.
- Step 9 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), write a connection log entry containing the current form name, client OS, and locale via WEBUTIL.LOG.
- Step 10 - If the package is newly registered, call WEBUTIL.CHECKLIBS with the package ID string to verify and download any required libraries for that bean.
- Step 11 - If this is the first-bean initialisation pass, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 12 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lower-cased value is 'true', 'yes', or '1', set the WUC_BLOCK_ALLOW_HEART_BEAT property on the registered bean to '1'; otherwise set it to '0'.
- Step 13 - Evaluate the server-logging flags: if both m_loggingAllowed and m_loggingErrorsOnly are true, set WUC_SRV_LOGGING to '1' (errors only); if only m_loggingAllowed is true, set it to '2' (full logging); otherwise set it to '0' (logging disabled).
- Step 14 - If this is the first-bean initialisation pass, call WEBUTIL.CHECKLIBS with the literal string 'user' to check for and download any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package-ID constant.
FALSE: packageID remains uninitialised; no package mapping is performed.

DP-002
Condition: m_clientIP IS NULL (no bean has yet registered in this session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, OS architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are not re-parsed; checkUserLibs remains FALSE.

DP-003
Condition: The OS architecture string (position 4 of clientInfo) contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit).
FALSE: m_clientOSArch retains its prior value (defaults to non-64-bit).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The package is recorded in m_registeredPackages using the current trigger item and newPackage is set to TRUE.
FALSE: The existing registration is preserved; newPackage remains FALSE.

DP-005
Condition: clientLibDir resolved from the architecture-specific property bundle key ('install.syslib.location.client.<family>.<arch>') IS NULL.
TRUE: A second lookup is attempted using the OS-family-only key ('install.syslib.location.client.<family>').
FALSE: The architecture-specific directory value is used directly.

DP-006
Condition: clientLibDir (after both property bundle lookups) IS NULL.
TRUE: The WUC_SYSLIB_DIR property is set to ':' || serverHost || ':' || CONFIG, signalling the client to default to its JRE directory.
FALSE: The resolved directory is used; the '$(SERVERHOST)' token is replaced and WUC_SYSLIB_DIR is set to the full path.

DP-007
Condition: clientLibDirOld (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: The new directory is persisted via WEBUTIL.SETCLIENTSETTING and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: No client setting update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-008
Condition: LOWER(ReadFromPropertyBundle('logging.connections')) = 'true'.
TRUE: A connection log entry is written via WEBUTIL.LOG.
FALSE: No connection log entry is written.

DP-009
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the package ID string to verify and download required libraries for the newly registered bean.
FALSE: Library checking for this bean is skipped.

DP-010
Condition: LOWER(ReadFromPropertyBundle('BlockAllowHeartBeat')) is 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the registered bean.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0' on the registered bean.

DP-011
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only mode).
FALSE: Evaluated further in DP-012.

DP-012
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging mode).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled).

DP-013
Condition: checkUserLibs is TRUE (end of procedure).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check and download user-defined libraries.
FALSE: User-library check is not performed.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only the ten recognised bean short names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are mapped to package IDs; any unrecognised short name results in no package registration.
- BR-002 - Client environment metadata (IP address, OS name, OS family, OS architecture, username, path separator, file separator, language code) is captured exactly once per form session, on the first bean registration; subsequent bean registrations do not overwrite these values.
- BR-003 - Each bean type may be registered only once per form session; if a bean short name is already present in the m_registeredPackages array, the duplicate registration is silently ignored and the first instance is retained.
- BR-004 - The OS architecture is classified as 64-bit only when the architecture string returned by the client contains the substring '64'; all other values are treated as non-64-bit.
- BR-005 - The system-library client directory is resolved with preference for the most specific property bundle key (OS family + architecture); the OS-family-only key is used as a fallback, and the client JRE default is used only when neither key yields a value.
- BR-006 - The '$(SERVERHOST)' token within a configured client library directory must be replaced with the runtime server host name before the value is transmitted to the client bean.
- BR-007 - The server host name is obtained first from the environment variable 'COMPUTERNAME' via WEBUTIL.GETVAR; 'HOST' is used only if 'COMPUTERNAME' returns null.
- BR-008 - When the resolved client system-library directory differs from the previously stored value (retrieved via WEBUTIL.GETCLIENTSETTING), the new value is persisted via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag is raised to trigger a re-download of system libraries.
- BR-009 - Connection logging is conditional: a log entry is written only when the 'logging.connections' property bundle entry is explicitly set to 'true' (case-insensitive).
- BR-010 - Library verification via WEBUTIL.CHECKLIBS is performed for a newly registered bean package only after that package has been recorded in m_registeredPackages, ensuring a handler bean exists to perform any required download.
- BR-011 - User-library checking via WEBUTIL.CHECKLIBS('user') is deferred until after the first bean package is registered and must occur after the logging flags (m_loggingAllowed, m_loggingErrorsOnly) have been initialised.
- BR-012 - The 'BlockAllowHeartBeat' configuration setting accepts three affirmative values ('true', 'yes', '1'); any other value (including null) is treated as disabled and the bean is instructed to allow heartbeat behaviour.
- BR-013 - Server-logging mode communicated to the client bean is derived from the combination of m_loggingAllowed and m_loggingErrorsOnly flags: errors-only (1), full logging (2), or disabled (0); these flags are initialised by calling WEBUTIL.LOG with a null message during first-bean registration.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-063 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that uniquely identifies the registered function for subsequent use. The procedure communicates the library and function specification to the WebUtil core component, retrieves the resulting handle token, and maintains an internal count of successfully registered functions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and transmit the combined specification to the WebUtil core layer by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 3 - Retrieve the string handle token assigned by the WebUtil core layer by reading the WUL_REGISTER_FUNCTION property from the WUL_PACKAGE component.
- Step 4 - Convert the retrieved string token to a numeric value and assign it to the hnd attribute of the FunctionHandle record (funcHnd).
- Step 5 - Evaluate the resulting FunctionHandle using WEBUTIL.ID_NULL (SP-050); if the handle is not null (i.e., registration was successful), increment the module-level function handle counter (m_funcHandleCount) by one.
- Step 6 - Return the populated FunctionHandle to the caller.
- Step 7 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt processing.
- Step 9 - If a VALUE_ERROR occurs during numeric conversion of the handle string, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: The FunctionHandle returned from the WebUtil core layer is evaluated by WEBUTIL.ID_NULL to determine whether a valid handle was issued.

TRUE (handle is NOT null - registration succeeded): The module-level counter m_funcHandleCount is incremented by one, recording that an additional function handle is active.

FALSE (handle IS null - registration did not yield a valid handle): The counter is not incremented; the null handle is still returned to the caller.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the WebUtil core property set or get operation, indicating the required WebUtil bean is absent.

TRUE: An error alert is displayed identifying the missing implementation class, and FORM_TRIGGER_FAILURE is raised to terminate the calling trigger.

FALSE: Processing continues normally without raising this exception.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during the WebUtil core property set or get operation.

TRUE: FORM_TRIGGER_FAILURE is raised immediately to terminate the calling trigger.

FALSE: Processing continues normally without raising this exception.

---

DP-004

Condition: A VALUE_ERROR exception is raised when converting the retrieved string handle token to a number via TO_NUMBER.

TRUE: TOOL_ERR.TOOL_ERROR is raised to signal an unexpected data conversion failure.

FALSE: Conversion succeeds and the numeric handle is stored in the FunctionHandle record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil core layer must be formed as the concatenation of libName, a pipe character ('|'), and funcName; no other delimiter or format is permitted.
- BR-002 - A FunctionHandle is considered successfully registered only when WEBUTIL.ID_NULL returns FALSE for the resulting handle; only in that case is the global handle counter incremented.
- BR-003 - The WebUtil bean corresponding to WUL_PACKAGE must be registered in the runtime environment before this function is called; absence of the bean is a fatal condition that prevents function registration and terminates the calling trigger.
- BR-004 - If the WebUtil core layer returns a value that cannot be converted to a number, the error is escalated as TOOL_ERR.TOOL_ERROR, indicating a corrupted or unexpected handle response.
- BR-005 - A PROPERTY_ERROR raised by the WebUtil core layer is treated as a fatal condition; no partial result is returned and the calling trigger is terminated via FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-064 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated WebUtil property and callback trigger, then nullifying the handle reference. This ensures that process resources are properly freed on the WebUtil infrastructure layer after a host process is no longer needed, preventing stale handle retention.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the WUH_CLEAR_PROC property on the WUH_PACKAGE, passing the current process handle value, signalling the WebUtil bean to release the associated native process resource.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the process handle to deregister any callback trigger that was registered against that handle.
- Step 4 - Set process.handle to NULL, marking the PROCESS_ID as released and preventing any further use of the stale handle by the caller.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), raise an error alert identifying the unregistered implementation class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition: The WebUtil bean identified by WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE) is registered and available at runtime.

TRUE: The procedure executes normally - clears the WUH_CLEAR_PROC property, deregisters the callback trigger, and nullifies the process handle.

FALSE: The BEAN_NOT_REGISTERED exception is caught and WebUtil_Core.ErrorAlert is called, displaying the missing bean class name and notifying the user that the release operation cannot be completed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle (PROCESS_ID.handle) must be passed IN OUT; the procedure unconditionally nullifies it upon successful completion, ensuring the caller cannot reuse a released handle.
- BR-002 - Both the WebUtil property clear (WUH_CLEAR_PROC) and the callback trigger deregistration must be performed before the handle is nullified, guaranteeing full cleanup of WebUtil infrastructure resources before the reference is discarded.
- BR-003 - If the WebUtil bean is not registered, the procedure must not silently fail; it must surface an error alert that identifies the missing bean class, allowing operators to diagnose the configuration issue.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-065 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean, allowing the Oracle Forms session to set a local client property at runtime. The procedure delegates the actual property assignment to WebUtil_Core.setProperty and enforces that only non-null property names are processed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if it is null, skip all processing and exit silently.
- Step 3 - Concatenate propertyName and propertyValue into a single string in the format 'propertyName=propertyValue'.
- Step 4 - Invoke WebUtil_Core.setProperty, passing the WebUtil_Core.WUC_PACKAGE identifier, the action constant WUC_SET_LOCAL_PROPERTY, and the concatenated property string, to transmit the setting to the client-side bean.
- Step 5 - If the WebUtil_Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 6 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue and call WebUtil_Core.setProperty to transmit the client setting.

FALSE: No action is taken; the procedure exits without invoking WebUtil_Core.setProperty.

DP-002

Condition: WebUtil_Core raises BEAN_NOT_REGISTERED during the setProperty call.

TRUE: Display an error alert identifying the unregistered bean class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal execution; no error alert is raised for this condition.

DP-003

Condition: WebUtil_Core raises PROPERTY_ERROR during the setProperty call.

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Continue normal execution; no error is raised for this condition.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted to the WebUtil bean if propertyName is not null; a null property name causes the procedure to exit silently with no update performed.
- BR-002 - The property name and value are combined into a single 'name=value' string before being passed to WebUtil_Core.setProperty; the value portion is accepted as supplied, including null or empty strings.
- BR-003 - If the WebUtil client bean is not registered at the time of invocation, the procedure must surface a descriptive error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE, preventing silent failure.
- BR-004 - If WebUtil_Core signals a property error, the procedure must raise FORM_TRIGGER_FAILURE immediately, ensuring the calling form trigger is aborted and no partial or invalid property state is left on the client.
- BR-005 - The procedure is invoked by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN; it must therefore be stable and exception-safe so that failures surface explicitly rather than propagating silently to those callers.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-066 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB or a server-side file - depending on the active transfer mode. It tracks remaining chunks, and when the final chunk is processed it closes the destination resource, marks the upload as succeeded or failed, fires any registered callback trigger, and clears that trigger registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-023](#SP-023--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-024](#SP-024--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-034](#SP-034--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-038](#SP-038--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-039](#SP-039--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-070](#SP-070--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or an empty string, set the package-level flag m_uploadSucceeded to FALSE and exit; no further processing is performed.
- Step 2 - Determine the write destination using the package-level flag m_toDB.
- Step 3 (m_toDB = TRUE) - Delegate the write operation to WebUtil_DB_LOCAL.WriteData, passing the chunk data.
- Step 4 (m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.WriteData to write the chunk to the application-server file. If the call returns FALSE, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception, aborting further processing.
- Step 5 - Decrement the package-level chunk counter m_chunks by 1.
- Step 6 - If m_chunks has reached 0 (all chunks received), proceed to close the destination resource.
- Step 7 (final chunk, m_toDB = TRUE) - Call WebUtil_DB_Local.CloseBlob passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error via WebUtil_DB_Local.getLastError, log it through WebUtil_Core.Error, and leave m_uploadSucceeded as FALSE.
- Step 8 (final chunk, m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error through WebUtil_Core.Error, delete the global Java reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 9 - After the destination is closed, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER with index -1. If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 10 - Call WEBUTIL.CLEARCALLBACKTRIGGER with index -1 to deregister the callback trigger regardless of whether it was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no write or close operations are attempted.

FALSE: Proceed to write the chunk to the designated destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk using WebUtil_DB_LOCAL.WriteData (database BLOB path).

FALSE: Write the chunk using JAVA_APPSERV_WRITER.WriteData (application-server file path).

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-write path only)

TRUE: Retrieve error details, log the error via WebUtil_Core.Error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks equals 0 after decrement (all expected chunks have been received)

TRUE: Proceed to close the destination resource and evaluate upload success.

FALSE: Return without closing; await subsequent chunk deliveries.

---

DP-005

Condition: m_toDB is TRUE (within the final-chunk close logic)

TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob.

FALSE: Close the file via JAVA_APPSERV_WRITER.CloseFile.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob returns TRUE (database BLOB close)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Log the error via WebUtil_Core.Error; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE (file close)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details, log via WebUtil_Core.Error, delete the global Java object reference, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER before clearing the registration.

FALSE: Skip trigger execution; proceed directly to WEBUTIL.CLEARCALLBACKTRIGGER.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is immediately marked as failed (m_uploadSucceeded = FALSE) and no write or close operation is performed.
- BR-002 - Every valid chunk must be written to exactly one destination: the database BLOB (when m_toDB = TRUE) or the application-server file (when m_toDB = FALSE); dual-writing is not permitted.
- BR-003 - A failed file-write (JAVA_APPSERV_WRITER.WriteData returning FALSE) is a fatal condition; the procedure logs the error and raises READWRITE_ERROR, preventing any further chunk processing or resource closure.
- BR-004 - The chunk counter m_chunks is decremented by exactly 1 for each successfully written chunk; the upload is considered complete only when m_chunks reaches 0.
- BR-005 - Resource closure (CloseBlob or CloseFile) is performed only after all expected chunks have been received (m_chunks = 0); partial uploads must not trigger closure.
- BR-006 - A failed CloseFile on the file path requires deletion of the persistent Java object reference (ORA_JAVA.DELETE_GLOBAL_REF) before raising READWRITE_ERROR, ensuring no orphaned Java resources remain.
- BR-007 - The upload success flag m_uploadSucceeded is set to TRUE only upon confirmed successful closure of the destination resource; any error during closure leaves the flag as FALSE.
- BR-008 - If a callback trigger is registered (via index -1) at the time the final chunk is processed, it must be executed before the registration is cleared; the trigger is always cleared after the final chunk regardless of whether it fired.
- BR-009 - Error reporting for both write and close failures on the file path must include the error code and error arguments retrieved from JAVA_APPSERV_WRITER, identifying 'WEBUTIL_FILE_TRANSFER.SetData' as the source location.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-067 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a Java system property at runtime within the Oracle Forms WebUtil layer by delegating to the underlying JNI bridge. The function accepts a property key and a property value, passes both to the Java Virtual Machine via the JNI interface, and returns the previous value that was associated with the specified key (or NULL if no prior value existed). This allows Oracle Forms sessions to programmatically configure JVM-level system properties required by WebUtil or dependent Java components.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive two VARCHAR2 input arguments: a0 (the system property key) and a1 (the system property value to be set).
- Step 2 - Initialise a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2), storing the handle in the shared args variable.
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the assembled argument list; the call targets the JVM class 'java/lang/System' and the method signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'.
- Step 6 - Return the VARCHAR2 result produced by JNI.CALL_STRING_METHOD to the caller, which represents the previous value of the named system property as reported by the JVM.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function follows a single unconditional execution path: build the JNI argument list, populate both string arguments, invoke the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly two arguments must be supplied to the JNI argument list; the property key (a0) must be added before the property value (a1) to match the method signature of java.lang.System.setProperty.
- BR-002 - The function delegates exclusively to the JNI bridge (JNI.CREATE_ARG_LIST, JNI.ADD_STRING_ARG, JNI.CALL_STRING_METHOD); no direct database interaction or additional PL/SQL processing is performed.
- BR-003 - The return value reflects the previous system property value as returned by the JVM; a NULL return indicates that the property had no prior value, which is a valid and expected outcome.
- BR-004 - The target Java method is fixed as java.lang.System.setProperty with the fully qualified JNI descriptor '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'; this binding must not be altered, as it is required for correct JVM dispatch.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-068 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) by either displaying or concealing it based on the supplied boolean flag. When showing the window, the procedure captures the current cursor item so focus can be restored when the window is subsequently hidden. Execution is suppressed entirely while the form is in Enter Query Mode to prevent interference with query operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Check whether the form system mode is 'NORMAL'; if the form is in Enter Query Mode or any other non-normal mode, all subsequent processing is skipped.
- Step 3 - Locate the WebUtil hidden window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the resulting window handle.
- Step 4 - Evaluate the window handle using WEBUTIL.ID_NULL (SP-050); if the handle is null (window not found), all subsequent processing is skipped.
- Step 5 - If 'show' is TRUE: capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; display the window using SHOW_WINDOW; navigate focus to WEBUTIL_DUMMY_ITEM.
- Step 6 - If 'show' is FALSE: check whether the previously stored m_infoFrom item handle is non-null using WEBUTIL.ID_NULL (SP-050); if non-null, navigate focus back to that item using GO_ITEM; hide the window using HIDE_WINDOW.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE equals 'NORMAL'.

TRUE: Proceed to locate the WebUtil hidden window and evaluate the show/hide logic.

FALSE: Exit the procedure immediately without performing any window or focus operations, protecting Enter Query Mode from interference.

---

DP-002

Condition: The window handle returned by FIND_WINDOW for WEBUTIL_HIDDEN_WINDOW is non-null (evaluated via WEBUTIL.ID_NULL, SP-050).

TRUE: Proceed to show or hide the window based on the 'show' parameter.

FALSE: Exit the procedure without attempting any window or focus operations.

---

DP-003

Condition: The 'show' parameter is TRUE.

TRUE: Capture the current cursor item into m_infoFrom, set the window title, display the hidden window, and move focus to WEBUTIL_DUMMY_ITEM.

FALSE: Proceed to the hide branch (DP-004).

---

DP-004

Condition: The stored m_infoFrom item handle is non-null (evaluated via WEBUTIL.ID_NULL, SP-050) during the hide branch.

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip the GO_ITEM call and proceed directly to hide the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus operations while the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this prevents disruption of query entry workflows.
- BR-002 - The WebUtil hidden window must exist (non-null handle) before any show or hide action is attempted; if the window cannot be located, the procedure takes no action.
- BR-003 - When displaying the WebUtil hidden window, the procedure must record the currently active form item (SYSTEM.CURSOR_ITEM) so that focus can be accurately restored when the window is later hidden.
- BR-004 - The WebUtil hidden window title must be set to 'WebUtil ' concatenated with the WEBUTIL_VERSION constant each time the window is shown.
- BR-005 - Focus must be moved to WEBUTIL_DUMMY_ITEM immediately after the hidden window is displayed, ensuring the WebUtil bean components receive the required focus context.
- BR-006 - Focus may only be restored to the previously captured item (m_infoFrom) on hide if that item handle is non-null; an invalid or unset handle must not trigger a GO_ITEM call.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-069 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-side URL to a specified destination path on the client machine. The procedure acts as a named wrapper that delegates the actual download operation to WEBUTIL.DOWNLOADFROMURL, providing a semantically clear interface for initiating URL-based file transfers to the client within Oracle Forms. It is invoked as part of the Excel report viewing workflow in dms_excel_report.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL (sourceURL), the target file path on the client machine (clientDestination), and an optional expected file size (fileSize, defaulting to 0) as input parameters.
- Step 2 - Delegate the download operation by calling WEBUTIL.DOWNLOADFROMURL (WebUtil_Core.DownLoadFromURL), passing all three parameters directly without transformation.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURL to the calling routine, indicating whether the file transfer to the client completed successfully.

---
**Decision Points**

No conditional decision points exist within this procedure. All branching logic is encapsulated within WEBUTIL.DOWNLOADFROMURL; this function unconditionally delegates to that dependency and returns its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fileSize parameter is optional; if not supplied by the caller, it defaults to 0, allowing WEBUTIL.DOWNLOADFROMURL to handle size determination internally.
- BR-002 - The function must return a BOOLEAN result to the caller, reflecting the success or failure of the file transfer as determined by WEBUTIL.DOWNLOADFROMURL.
- BR-003 - All three parameters (sourceURL, clientDestination, fileSize) are passed to WEBUTIL.DOWNLOADFROMURL without modification; no pre-processing or validation is applied at this layer.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-070 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the native Java method WriteData on the AppServerFileWriter class via the JNI bridge, returning a Boolean result that indicates whether the write operation succeeded. This procedure is a low-level wrapper called by WEBUTIL.SETDATA to physically write data content to a file on the application server.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) identifying the active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string data payload (a0) to the argument list by calling JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class through JNI.CALL_BOOLEAN_METHOD, passing the argument list and specifying the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result produced by the Java method to the caller, indicating success or failure of the write operation.

---
**Decision Points**

No decision points are present in the implementation logic. The procedure unconditionally constructs the JNI argument list, invokes the Java WriteData method, and returns the Boolean result without conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 string; it is added to the JNI argument list as a String type and passed to the Java layer without transformation.
- BR-002 - The Java method is invoked with a default failure value of FALSE, meaning that if the JNI call cannot be completed the function returns FALSE to the caller.
- BR-003 - The target Java class and method are fixed at 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' and 'WriteData' respectively; no dynamic resolution of the write target is permitted.
- BR-004 - The function returns a Boolean result directly from the Java layer; the caller (WEBUTIL.SETDATA) is responsible for interpreting and acting on this result.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-071 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires in pe_part_fmb.xml, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart metadata, and routes execution to the appropriate WebUtil handler (logging, error reporting, bean registration, host-command callback, or file-transfer completion). Events that are not in the recognised set are silently discarded; all other unexpected errors are re-raised.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-027](#SP-027--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-040](#SP-040--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-062](#SP-062--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-066](#SP-066--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-067](#SP-067--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive EventName and EventParameters from the calling WHEN-CUSTOM-ITEM-EVENT trigger.
- Step 2 - Validate that EventName is one of the five recognised values ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); if not, raise the local 'unhandled' exception, which is caught and silently suppressed.
- Step 3 - Extract the data payload by calling get_parameter_attr against the EventParameters string using the key 'WUC_DATA', storing the result in dataPayload.
- Step 4 - Extract the multipart descriptor by calling get_parameter_attr using the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive chunkNumber (position 1, delimiter '/') and PayloadChunks (position 2, delimiter '/'), establishing how many client messages compose the full payload.
- Step 6 - Route to the appropriate handler based on EventName:
  - WUC_LOG_EVENT: call WEBUTIL_CORE.LOG (via WEBUTIL.LOG) with dataPayload and the non-error flag (false).
  - WUC_ERROR_EVENT: call WEBUTIL_CORE.LOG with dataPayload and the error flag (true).
  - WUC_REGISTER: call registerBean (WEBUTIL.REGISTERBEAN) with dataPayload to register the client-side bean.
  - WUH_CALLBACK_EVENT: convert dataPayload to a number and store it in m_lastCallback; if conversion fails, call WEBUTIL.ERROR with package constant WUC_PACKAGE, error code 408, and the procedure identifier; if m_lastCallback is populated, execute the corresponding trigger stored in m_callbacks; if it is null, log a warning via WEBUTIL.LOG.
  - WUT_TRANSFER_EVENT: pass dataPayload to WEBUTIL.SETDATA to store the transferred file data, then call WEBUTIL.SETPROPERTY on the WUT_PACKAGE item with event key 'WUT_TRANSFER_EVENT' and value 'RECEIVED' to signal completion.
- Step 7 - On an unhandled event exception, suppress silently (no action). On any other exception, re-raise to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', or 'WUT_TRANSFER_EVENT'.

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the local 'unhandled' exception, which is caught in the exception block and silently suppressed (no error surfaced to the caller).

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag = false (informational log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag = true (error log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT' and TO_NUMBER conversion of dataPayload succeeds.

TRUE: Store the numeric value in m_lastCallback and proceed to DP-006.

FALSE (INVALID_NUMBER exception): Call WEBUTIL.ERROR with WUC_PACKAGE, error code 408, and context string 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains unset.

---

DP-006

Condition: m_lastCallback IS NOT NULL (within WUH_CALLBACK_EVENT branch).

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record the warning 'Callback trigger for host command not specified' with error flag = true.

---

DP-007

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to mark the transfer event as 'RECEIVED'.

FALSE: No further routing; the event was already handled by an earlier branch or is unrecognised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five explicitly whitelisted event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; any other event name is silently ignored and does not cause an application error (Bug 2839033 guard).
- BR-002 - The data payload and multipart descriptor must be extracted from EventParameters before any event-specific routing occurs; all routing branches depend on the values of dataPayload and dataMultiPart.
- BR-003 - For WUH_CALLBACK_EVENT, the payload must be convertible to a valid number representing a callback index; an INVALID_NUMBER condition is treated as a handled error reported via WEBUTIL.ERROR (error code 408) rather than propagated as an unhandled exception.
- BR-004 - A WUH_CALLBACK_EVENT with a null or unconvertible callback reference must not attempt trigger execution; a warning is logged via WEBUTIL.LOG instead.
- BR-005 - Completion of a WUT_TRANSFER_EVENT must be acknowledged by setting the 'WUT_TRANSFER_EVENT' property to 'RECEIVED' via WEBUTIL.SETPROPERTY immediately after the data is stored via WEBUTIL.SETDATA, ensuring the client receives a deterministic handshake signal.
- BR-006 - Unexpected runtime exceptions (OTHERS) are re-raised to the caller unchanged, preserving the ability of higher-level error handlers to capture and report them; only the locally defined 'unhandled' exception is suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-072 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a single error condition encountered during processing by setting a global error flag, composing a formatted error message that combines the calling function name with the error description, and forwarding the composed message to the debug logging facility. This procedure provides a centralised error-registration mechanism used by multiple D2KWUTIL utility routines to ensure errors are captured consistently before control returns to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that at least one error has been registered in the current execution context.
- Step 3 - Compose the error stack message by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, then assign the result to the global variable ERROR_STACK.
- Step 4 - Invoke DEBUGLOG (SP-076) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK string, so that the error is written to the debug log.

---
**Decision Points**

No conditional decision points are present in this procedure. All four steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error text stored in ERROR_STACK is truncated to a maximum of 1,968 characters to prevent overflow; any characters beyond this limit are silently discarded.
- BR-002 - The global flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, ensuring that any upstream logic inspecting this flag can detect that an error has occurred.
- BR-003 - The composed error message must prefix the error text with the calling function name followed by a colon-space separator, providing unambiguous identification of the originating routine in the error record.
- BR-004 - All registered errors are forwarded to DEBUGLOG at severity level 99, classifying them as the highest-priority debug entries.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-073 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and concatenates error messages from the Oracle Forms tool error stack (TOOL_ERR) into a single newline-delimited string buffer, falling back to the current SQL error message (SQLERRM) when no tool errors are present. The resulting string is returned to the caller for consolidated error reporting.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a PL/SQL integer counter (iCounter) and a VARCHAR2 buffer (vcErrBuff, max 1,968 characters) to hold the accumulated error text.
- Step 2 - Check whether the TOOL_ERR stack contains one or more errors by evaluating TOOL_ERR.NERRORS > 0.
- Step 3 - If tool errors exist, iterate from 1 to TOOL_ERR.NERRORS; on each iteration, append a newline character followed by the current TOOL_ERR.MESSAGE to vcErrBuff.
- Step 4 - After each successful append, call TOOL_ERR.POP to remove the processed error from the stack and advance to the next message.
- Step 5 - If appending a message would cause vcErrBuff to exceed its 1,968-character limit, a VALUE_ERROR exception is raised; the exception handler exits the loop immediately, preserving the messages collected so far.
- Step 6 - If the TOOL_ERR stack is empty (TOOL_ERR.NERRORS = 0) but SQLERRM is not null, assign a newline character followed by SQLERRM to vcErrBuff as the sole error entry.
- Step 7 - Return vcErrBuff to the caller, containing the consolidated error text (or an empty/null string if no errors were detected).

---
**Decision Points**

DP-001

Condition: TOOL_ERR.NERRORS > 0

TRUE: Enter the loop and iteratively concatenate each tool error message (prefixed with a newline) into vcErrBuff, popping each entry from the stack after processing. Exit the loop early if a VALUE_ERROR is raised.

FALSE: Skip the loop and evaluate the SQLERRM fallback condition (DP-002).

---

DP-002

Condition: SQLERRM IS NOT NULL (evaluated only when TOOL_ERR.NERRORS = 0)

TRUE: Assign a newline-prefixed SQLERRM value to vcErrBuff as the error message.

FALSE: vcErrBuff remains empty/null; no error text is added.

---

DP-003

Condition: A VALUE_ERROR exception is raised during string concatenation inside the loop

TRUE: Exit the loop immediately, retaining all messages successfully concatenated before the buffer limit was reached.

FALSE: Continue iterating and appending subsequent tool error messages.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Tool error messages take precedence over SQL error messages; SQLERRM is only used as a fallback when the TOOL_ERR stack is empty.
- BR-002 - Each error message appended to the buffer must be separated from the preceding content by a newline character (CHR(10)), ensuring individual messages remain distinguishable in the returned string.
- BR-003 - The accumulated error buffer must not exceed 1,968 characters; if concatenation would breach this limit, collection stops immediately and only the messages gathered up to that point are returned.
- BR-004 - Each TOOL_ERR entry is popped from the stack after it is appended to the buffer, ensuring the stack is consumed in order and no message is processed more than once.
- BR-005 - The function always returns a value (including NULL or an empty string) and does not raise exceptions to the caller; buffer overflow is handled internally via the VALUE_ERROR exception handler.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-074 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by multiple stored procedures within the D2KWUTIL package (CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, and READ_REGISTRY) to represent boolean results as character strings, enabling boolean state to be passed, displayed, or evaluated in contexts that require a character data type.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean from the calling routine.
- Step 2 - Evaluate the value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL is treated as the else branch), return the VARCHAR2 literal 'FALSE'.
- Step 5 - Return the resulting character string to the caller.

---
**Decision Points**

DP-001

Condition: ThisBoolean evaluates to TRUE.

TRUE: The function returns the VARCHAR2 string 'TRUE' to the calling routine.

FALSE: The function returns the VARCHAR2 string 'FALSE' to the calling routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 string; the only permitted return values are 'TRUE' and 'FALSE'.
- BR-002 - The input parameter ThisBoolean is a PL/SQL BOOLEAN; because PL/SQL BOOLEAN cannot be stored in a database column or passed directly through certain interfaces, this function provides the canonical mechanism for converting that value to a portable character representation.
- BR-003 - Any BOOLEAN value that does not explicitly evaluate to TRUE (including a NULL BOOLEAN) is returned as 'FALSE', as it falls into the ELSE branch of the conditional.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-075 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the error flag and discarding any accumulated error messages. This procedure is called at the start of utility operations to ensure no residual error information from a previous execution affects the current processing context.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error condition is currently active.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any error messages accumulated during prior processing.

---
**Decision Points**

No decision points. The procedure executes unconditionally; both variables are always reset regardless of their current values.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, unconditionally clearing any previously recorded error flag.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, unconditionally purging any previously accumulated error message content.
- BR-003 - The procedure accepts no input and produces no output; its sole effect is the side-effect reset of the two shared module-level error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-076 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes formatted diagnostic messages to either a Windows debug output stream or a flat log file, depending on the current debug configuration. It acts as the central logging routine for the D2KWUTIL library, called by multiple stored procedures to record trace information at runtime. Each message is prefixed with a severity level and an optional timestamp, and the procedure self-corrects if the Windows debug API is unavailable by transparently switching to file-based logging via SETDEBUG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-082](#SP-082--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-090](#SP-090--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Check whether debug logging is active (iDebugState = 0). If inactive, exit immediately without writing any output.
- Step 2 - Check whether debug logging is paused (bDebugPaused = TRUE). If paused, exit immediately without writing any output.
- Step 3 - Compare the incoming DebugLevel against the configured threshold iDebugLevel. If DebugLevel exceeds the threshold, exit immediately; the message is below the required verbosity.
- Step 4 - If a timestamp is enabled (bDebugTimeStamp = TRUE), format the current system time as HH24:MI:SS and append a '>' separator to form vcDateStamp.
- Step 5 - Construct the formatted debug string vcDebugString by concatenating: a zero-padded two-digit DebugLevel in angle brackets, the optional timestamp, and the LoggingCall padded to 30 characters with a colon suffix.
- Step 6 - Append the LogString to vcDebugString, truncating it so that the total string length does not exceed 2,000 characters. The available space is calculated as 2000 minus the current length of vcDebugString, and WEBUTIL.LENGTH is used in this length computation.
- Step 7 - Evaluate the debug output mode (iDebugState = 2 indicates Windows debug output mode).
- Step 8 - If iDebugState = 2 and DEBUG_API_ENABLED is TRUE, call WINDEBUG to write vcDebugString to the Windows debug output stream.
- Step 9 - If iDebugState = 2 and DEBUG_API_ENABLED is FALSE, the Windows debug API is unavailable. Call SETDEBUG to reconfigure logging to file mode (mode 1) targeting the current debug file (defaulting to 'd2kwutil.log'), then recursively call DEBUGLOG to log a warning message ('Unable to Log to Debugger Switching to File'), then recursively call DEBUGLOG to re-emit the original message under file mode, and set the flag bDebugType2Required to TRUE to record that Windows debug mode was originally requested.
- Step 10 - If iDebugState is not 2 (file logging mode) and bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE, the Windows debug API has become available again. Call SETDEBUG to restore Windows debug mode (mode 2), recursively call DEBUGLOG to log a restoration message ('Restoring Logging to Debugger'), set bDebugType2Required to FALSE, and recursively call DEBUGLOG to re-emit the original message under Windows debug mode.
- Step 11 - If iDebugState is not 2 and no mode restoration is required, open the log file specified by vcDebugFile in append mode using TEXT_IO.FOPEN, write vcDebugString as a line using TEXT_IO.PUT_LINE, and close the file using TEXT_IO.FCLOSE.
- Step 12 - If any unhandled exception occurs during the above steps, the exception handler suppresses the error by setting iDebugState to 0, disabling further debug logging to prevent the diagnostic routine from disrupting the calling application.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: Debug logging is disabled; the procedure exits immediately and performs no output.

FALSE: Proceed to DP-002.

---

DP-002

Condition: bDebugPaused = TRUE

TRUE: Debug logging is temporarily paused; the procedure exits immediately and performs no output.

FALSE: Proceed to DP-003.

---

DP-003

Condition: DebugLevel > iDebugLevel (incoming message level exceeds the configured verbosity threshold)

TRUE: The message is below the required detail level; the procedure exits immediately and performs no output.

FALSE: The message meets the verbosity threshold; proceed to format and emit the message.

---

DP-004

Condition: bDebugTimeStamp = TRUE

TRUE: Format the current system time (HH24:MI:SS) and include it in the debug string prefix.

FALSE: No timestamp is prepended; vcDateStamp remains empty.

---

DP-005

Condition: iDebugState = 2 (Windows debug output mode is configured)

TRUE: Attempt to write the message via the Windows debug API path; proceed to DP-006.

FALSE: Use file-based logging path; proceed to DP-007.

---

DP-006

Condition: DEBUG_API_ENABLED = TRUE (Windows debug API functions are available)

TRUE: Call WINDEBUG to write the formatted message to the Windows debug output stream.

FALSE: The Windows debug API is unavailable. Call SETDEBUG to switch to file logging mode, log a warning via recursive DEBUGLOG call, re-emit the original message via recursive DEBUGLOG call, and set bDebugType2Required to TRUE.

---

DP-007

Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (file mode is active but Windows debug API has become available again)

TRUE: Call SETDEBUG to restore Windows debug mode, log a restoration notice via recursive DEBUGLOG call, reset bDebugType2Required to FALSE, and re-emit the original message via recursive DEBUGLOG call.

FALSE: Write the formatted message directly to the log file using TEXT_IO.FOPEN (append), TEXT_IO.PUT_LINE, and TEXT_IO.FCLOSE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug output is only produced when iDebugState is non-zero and bDebugPaused is FALSE; any other state causes the procedure to silently discard the message without error.
- BR-002 - A message is only emitted if its DebugLevel does not exceed the configured threshold iDebugLevel; messages with a higher level than the threshold are silently discarded.
- BR-003 - The total length of the formatted debug string (level prefix, optional timestamp, padded caller name, and log text) must not exceed 2,000 characters; LogString is truncated to fit within this limit.
- BR-004 - The LoggingCall identifier is always right-padded with a colon to a fixed width of 30 characters in the output string, ensuring consistent columnar alignment across all log entries.
- BR-005 - When Windows debug output mode (iDebugState = 2) is requested but DEBUG_API_ENABLED is FALSE, the procedure automatically falls back to file logging by invoking SETDEBUG with mode 1, and records the fallback event in the log before re-emitting the original message; the flag bDebugType2Required is set to TRUE to track the outstanding intent to use Windows debug mode.
- BR-006 - When file logging mode is active and bDebugType2Required is TRUE and DEBUG_API_ENABLED becomes TRUE, the procedure automatically restores Windows debug mode by invoking SETDEBUG with mode 2, logs the restoration event, and re-emits the original message; bDebugType2Required is reset to FALSE.
- BR-007 - The log file is opened in append mode for each individual write operation and closed immediately after; no persistent file handle is maintained between calls.
- BR-008 - Any exception raised within DEBUGLOG is fully suppressed by setting iDebugState to 0, ensuring that a failure in the logging mechanism does not propagate errors to the calling business procedure.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-077 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function is invoked by WEBUTIL.GETVAR and returns the resolved variable value as a VARCHAR2 string. If the Win API layer is unavailable, or if the variable cannot be resolved, the function either raises an exception or returns NULL, depending on the caller-supplied RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG, recording the input VariableName and the string representation of RaiseExceptions (via BOOLTOCHAR).
- Step 2 - Clear any pre-existing error state on the Win API error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the Win API layer is enabled (WIN_API.API_ENABLED). If it is not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETDOSENV by calling REGISTER_FUNCTION_CALL, specifying the function name and its argument/return-type signature ('LONG','*CHAR,*CHAR,LONG').
- Step 5 - Prepare the lookup token by wrapping VariableName with percent signs (e.g., '%VAR_NAME%') into vcBuff1, and initialise the output buffer vcBuff2 as a 512-character null-padded string.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing the formatted variable name token, the output buffer, and the buffer length (512). Capture the integer return code in iRC.
- Step 7 - Log the result diagnostics by calling DEBUGLOG, recording the returned value length (iRC) and the content of the output buffer (vcBuff2).
- Step 8 - Evaluate the resolution outcome: if iRC equals 0 or the output buffer is unchanged from the input token (indicating the variable was not found), record an error via ADD_ERROR. Then, if RaiseExceptions is TRUE raise NO_DATA_FOUND; otherwise return NULL.
- Step 9 - If the variable was resolved successfully, return the populated output buffer vcBuff2 as the function result.
- Step 10 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR and re-raise; for all other exceptions, log the error via ADD_ERROR (appending external error details from ADD_EXTERNAL_ERRORS) and re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the native function handle and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all resolution logic.

---

DP-002

Condition: iRC equals 0 OR the output buffer vcBuff2 is identical to the formatted input token vcBuff1 (i.e., the environment variable was not found or not expanded).

TRUE: Record an error via ADD_ERROR indicating the variable value could not be retrieved, then branch on RaiseExceptions (see DP-003).

FALSE: Return the resolved environment variable value (vcBuff2) to the caller.

---

DP-003

Condition: RaiseExceptions is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return NULL silently to the caller.

---

DP-004

Condition: Exception handler - exception type is NO_DATA_FOUND.

TRUE: Re-raise NO_DATA_FOUND without additional error logging.

FALSE: Evaluate next exception handler (DP-005).

---

DP-005

Condition: Exception handler - exception type is WIN_API.NOT_AVAILABLE.

TRUE: Log the error via ADD_ERROR using WIN_API.NoAPI message text, then re-raise.

FALSE: Fall through to the OTHERS handler: log the error via ADD_ERROR appending ADD_EXTERNAL_ERRORS detail, then re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win API layer must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to resolve an environment variable; if the layer is unavailable the function always raises WIN_API.NOT_AVAILABLE and never returns a value.
- BR-002 - The environment variable name must be submitted to D2KWUTIL_GETDOSENV enclosed in percent signs (e.g., '%VARIABLE_NAME%') to form a valid DOS/Windows environment variable token.
- BR-003 - The output buffer is fixed at 512 characters; environment variable values longer than 512 characters cannot be fully retrieved by this function.
- BR-004 - A return code of 0 from D2KWUTIL_GETDOSENV, or an output buffer that equals the formatted input token, is treated as a failed resolution and is not returned as a valid value.
- BR-005 - The caller controls error propagation behaviour: passing RaiseExceptions = TRUE causes the function to raise NO_DATA_FOUND on resolution failure; passing FALSE (the default) causes the function to return NULL instead.
- BR-006 - All errors, including resolution failures and unexpected exceptions, must be recorded on the Win API error stack via ADD_ERROR before the function raises or returns, ensuring the error context is available to the calling layer.
- BR-007 - Unexpected exceptions must append external error detail (via ADD_EXTERNAL_ERRORS) to the ADD_ERROR message before re-raising, providing full diagnostic context to upstream handlers.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-078 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows temporary directory path for the current session by invoking the D2KWUTIL Windows API utility function. The function registers and calls the underlying OS-level directory lookup, strips any trailing directory separator from the returned path, and returns the clean path string to the caller. Error handling is configurable via the RaiseExceptions flag, allowing the caller to control whether a missing result raises an exception or silently returns NULL.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-088](#SP-088--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the function entry and the value of the RaiseExceptions input parameter using DEBUGLOG.
- Step 2 - Clear any pre-existing errors from the error stack via CLEAN_ERROR_STACK.
- Step 3 - Initialise the return code (iRC) to 0.
- Step 4 - Check whether the Windows API is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for the D2KWUTIL temporary-directory lookup using REGISTER_FUNCTION_CALL, supplying the function handle, the external function name ('d2kwutil_TmpDir'), and its signature ('INT','*CHAR,INT').
- Step 6 - Initialise the output buffer (vcBuff1) as a 512-character null-padded string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR with the registered function handle, the output buffer, and the buffer size (512) to obtain the temporary directory path; capture the integer return code in iRC.
- Step 8 - Log the raw return code and the raw buffer value returned by the API call using DEBUGLOG.
- Step 9 - Evaluate the return code: if iRC = 0, the API returned no value; record an error via ADD_ERROR and either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL (if RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), strip any trailing directory separator from vcBuff1 using STRIPDIRSEP and return the resulting path string.
- Step 11 - In the NO_DATA_FOUND exception handler, re-raise the exception to the caller.
- Step 12 - In the WIN_API.NOT_AVAILABLE exception handler, record the no-API error via ADD_ERROR and re-raise.
- Step 13 - In the OTHERS exception handler, record the unexpected error (including any external error detail from ADD_EXTERNAL_ERRORS) via ADD_ERROR and re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the temporary directory path.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception; no API call is attempted.

---

DP-002

Condition: The return code (iRC) from D2KWUTIL.D2KWUTIL_WINDIR equals 0.

TRUE: The API returned no directory value; log the error via ADD_ERROR and branch on RaiseExceptions (see DP-003).

FALSE: The API returned a valid path; strip the trailing directory separator via STRIPDIRSEP and return the cleaned path.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise NO_DATA_FOUND to propagate the missing-value condition to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API must be enabled (WIN_API.API_ENABLED) before any attempt is made to retrieve the temporary directory; if the API is unavailable the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The external function 'd2kwutil_TmpDir' must be registered with the correct signature ('INT','*CHAR,INT') via REGISTER_FUNCTION_CALL before it is invoked; the output buffer must be pre-allocated to 512 characters.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure (no value returned); an error must be recorded via ADD_ERROR in this case.
- BR-004 - When the API returns no value, the caller's RaiseExceptions flag governs the failure mode: TRUE causes a NO_DATA_FOUND exception to be raised; FALSE causes NULL to be returned without raising an exception.
- BR-005 - Any trailing directory separator must be removed from the returned path using STRIPDIRSEP before the value is returned to the caller, ensuring a consistently formatted directory path.
- BR-006 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be re-raised after error recording, ensuring that error conditions are always propagated to the invoking context.
- BR-007 - Unexpected errors must capture both the internal error detail and any external error information (via ADD_EXTERNAL_ERRORS) before re-raising, to support complete error diagnostics.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-079 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows system directory path for the current environment by invoking the external D2KWUtil library function D2KWUTIL_WINDIR. The result is sanitised by stripping any trailing directory separator before being returned to the caller. Error handling behaviour (silent null return versus raised exception) is governed by the RaiseExceptions input flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-088](#SP-088--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (severity 99), recording the procedure name and the value of RaiseExceptions (converted to a character representation via BOOLTOCHAR).
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Win API layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call by invoking REGISTER_FUNCTION_CALL, binding the function handle iWinDir to the external entry point 'd2kwutil_WinDir' with signature INT / *CHAR, INT.
- Step 6 - Initialise the 512-byte output buffer vcBuff1 with space-padded null characters.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and the buffer size (512). Capture the integer return code in iRC.
- Step 8 - Log the outcome by calling DEBUGLOG (severity 99), recording the return code and the raw buffer content.
- Step 9 - Evaluate iRC. If iRC equals 0, the external call returned no value; record the failure via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero, call STRIPDIRSEP to remove any trailing directory separator from vcBuff1 and return the cleaned path to the caller.
- Step 11 - In the exception block, handle NO_DATA_FOUND by re-raising it; handle WIN_API.NOT_AVAILABLE by logging via ADD_ERROR and re-raising; handle all other exceptions by logging a generic error combined with any external error detail from ADD_EXTERNAL_ERRORS and re-raising.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the Windows directory path.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing the external call entirely.

---

DP-002

Condition: The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR equals 0.

TRUE: The external function returned no value; log the failure via ADD_ERROR and branch to DP-003 to determine the error response mode.

FALSE: The external function succeeded; strip the trailing directory separator from the buffer via STRIPDIRSEP and return the resulting path.

---

DP-003

Condition: The RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows directory path may only be retrieved when the Win API layer is active (WIN_API.API_ENABLED = TRUE); if the API is unavailable the function must not attempt the external call and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition meaning no directory value was returned; this must be recorded as an error via ADD_ERROR.
- BR-003 - When iRC equals 0 and RaiseExceptions is TRUE, the function must raise NO_DATA_FOUND to allow the caller to handle the absence of a value; when RaiseExceptions is FALSE the function must return NULL instead, providing a non-fatal fallback.
- BR-004 - The returned directory path must always have its trailing directory separator removed via STRIPDIRSEP before being delivered to the caller, ensuring a consistent path format.
- BR-005 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be re-raised after error logging, ensuring that error state is never silently swallowed by this function.
- BR-006 - Unhandled exceptions must be logged by combining the generic unexpected-error token (WIN_API.UError) with any additional external error detail obtained from ADD_EXTERNAL_ERRORS before re-raising.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-080 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a given registry path and entry key. It translates a human-readable root hive name (e.g., HKEY_LOCAL_MACHINE) into the numeric constant expected by the underlying D2KWUTIL platform call, invokes D2KWUTIL.D2KWUTIL_GETREGKEY to perform the native read, and returns the value as a VARCHAR2 string. The caller may optionally request that failures raise PL/SQL exceptions rather than returning NULL, giving upstream code flexible error-handling control.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the values of RegPath, RegEntry, and RaiseExceptions (the boolean converted to a character via BOOLTOCHAR) so that the call can be traced at runtime.
- Step 2 - Reset the error stack: call CLEAN_ERROR_STACK to clear any previously accumulated errors before processing begins.
- Step 3 - Check API availability: evaluate WIN_API.API_ENABLED; if the Windows API layer is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle: call REGISTER_FUNCTION_CALL to bind the iGetRegKey handle to the D2KWUTIL_GETREGKEY external function signature before it is invoked.
- Step 5 - Resolve the registry root hive: extract the portion of RegPath before the first backslash, convert it to upper case, and map it to its numeric constant (0 = HKEY_LOCAL_MACHINE, 1 = HKEY_CLASSES_ROOT, 2 = HKEY_CURRENT_USER, 3 = HKEY_USERS, 4 = HKEY_CURRENT_CONFIG). If the root hive is unrecognised, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call parameters: set the output buffer (vcBuff3) to a 2000-character NUL-padded string, isolate the sub-path after the first backslash into vcBuff1, copy RegEntry into vcBuff2, and set the buffer-length indicator iBuff2 to 2000.
- Step 7 - Apply compatibility flag: if WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, set iBuff3 to 1 to suppress environment-variable expansion in registry values and log a compatibility note via DEBUGLOG; otherwise set iBuff3 to 0 to allow expansion.
- Step 8 - Invoke the registry read: call D2KWUTIL.D2KWUTIL_GETREGKEY with the resolved handle, root constant, sub-path, entry name, output buffer, buffer length, and expansion flag; capture the integer return code in iRC.
- Step 9 - Log the result: call DEBUGLOG (severity 99) recording iRC and the content of vcBuff3.
- Step 10 - Evaluate the return code and handle errors: inspect iRC and, for each error code, record a descriptive message via ADD_ERROR then either return NULL or raise the appropriate exception depending on the value of RaiseExceptions (see Decision Points).
- Step 11 - Return the value: if iRC indicates success (not -1, -2, -3, or -4), return vcBuff3 to the caller.
- Step 12 - Exception handling: propagate NO_DATA_FOUND and VALUE_ERROR as raised; for WIN_API.NOT_AVAILABLE record the standard no-API message via ADD_ERROR then re-raise; for all other exceptions record the unexpected-error message combined with ADD_EXTERNAL_ERRORS output via ADD_ERROR then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root-hive resolution, and the registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately; no registry access is attempted.

DP-002
Condition: The upper-cased root portion of RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant to iBuff1 and continue.
FALSE: Call ADD_ERROR with 'Invalid Registry Key'; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (iRC remains 0 and the subsequent D2KWUTIL call will proceed with an uninitialised root constant).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE.
TRUE: Set iBuff3 to 0, allowing D2KWUTIL_GETREGKEY to expand environment-variable references within the registry value.
FALSE: Set iBuff3 to 1, suppressing environment-variable expansion; log a compatibility note via DEBUGLOG.

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (entry not found).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent error-code conditions (DP-005 onwards).

DP-005
Condition: iRC equals -2 (unsupported data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: Evaluate subsequent error-code conditions.

DP-006
Condition: iRC equals -3 (value exceeds buffer length of 2000 bytes).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise VALUE_ERROR.
FALSE: Evaluate subsequent error-code conditions.

DP-007
Condition: iRC equals -4 (environment-string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, if TRUE raise NO_DATA_FOUND.
FALSE: No error condition applies; return vcBuff3 to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED = TRUE) before any registry access is attempted; if it is not active the procedure raises WIN_API.NOT_AVAILABLE and no registry read is performed.
- BR-002 - The registry root hive supplied in RegPath must be one of exactly five recognised values: HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, or HKEY_CURRENT_CONFIG; any other value is treated as invalid and an error is recorded.
- BR-003 - The output buffer for the registry value is fixed at 2000 bytes; values longer than this limit cause an error (iRC = -3) and, when RaiseExceptions is TRUE, raise VALUE_ERROR rather than NO_DATA_FOUND to signal an overflow condition distinct from a missing entry.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when that flag is FALSE, expansion is suppressed to maintain backward compatibility with environments that store literal percent-delimited strings.
- BR-005 - The RaiseExceptions parameter governs the error-surfacing contract: when FALSE the procedure absorbs retrieval failures and returns NULL, allowing callers to handle absence gracefully; when TRUE all retrieval failures propagate as exceptions, enforcing strict error handling at the call site.
- BR-006 - All errors, including invalid root hive, retrieval failures, unsupported data types, buffer overflow, expansion failures, API unavailability, and unexpected exceptions, are recorded through ADD_ERROR before any exception is raised or NULL is returned, ensuring the error stack is always populated for upstream diagnostics.
- BR-007 - Unexpected exceptions are enriched with the output of ADD_EXTERNAL_ERRORS before being re-raised, ensuring that any externally sourced error detail is captured in the error stack alongside the standard unexpected-error prefix.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-081 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a native DLL function is registered with the Oracle FFI layer before it is called by any D2KWUTIL procedure. For each invocation, the procedure verifies that the target DLL is loaded, then checks whether the function has already been registered under the current DLL load cycle. If the function has never been registered, or if the DLL has been reloaded since the last registration, the procedure re-registers the function handle, its parameter types, and its return type so that subsequent FFI calls execute against a valid, current binding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-063](#SP-063--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the Oracle FFI library cache by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant; store the result in DLL_HANDLE.
- Step 2 - If FIND_LIBRARY raises ORA_FFI.FFI_ERROR (DLL not currently loaded), attempt a fresh load by calling D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_Path and DLL_NAME.
- Step 3 - If ATTEMPT_DLL_LOAD also raises ORA_FFI.FFI_ERROR, set the package flag API_ENABLED to FALSE, record the failure via ADD_ERROR (source tag 'D2KWUTIL', message DLL_NAME||' not found.'), and raise NO_DATA_FOUND to abort processing.
- Step 4 - Check the FunctionLoad associative array: if no entry exists for FunctionID, or if the stored load-count for FunctionID differs from the current DLL_LOAD_COUNT, proceed with (re-)registration; otherwise skip to the end.
- Step 5 - Register the function with the DLL handle by calling ORA_FFI.REGISTER_FUNCTION, passing Win_API.DLL_HANDLE, FunctionName, and ORA_FFI.C_STD calling convention; store the returned handle in FunctionHandle(FunctionID).
- Step 6 - If FunctionName is not 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (level 99, source 'Register_Function_Call') indicating whether this is an initial registration or a re-registration, including the current DLL_LOAD_COUNT.
- Step 7 - Append a comma delimiter to FunctionArgs and iterate through each comma-separated type token; for each token, call D2KWUTIL.TRANSLATETYPE to convert the string type name to the corresponding ORA_FFI type constant and register it as a parameter via ORA_FFI.REGISTER_PARAMETER. Continue until the argument string is exhausted, NULL, or equals 'VOID'.
- Step 8 - If FunctionReturn is not 'VOID' (case-insensitive) and is not NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the result as the function's return type via ORA_FFI.REGISTER_RETURN.
- Step 9 - Record FunctionID's current DLL_LOAD_COUNT in the FunctionLoad array to prevent unnecessary re-registration on future calls within the same DLL load cycle.
- Step 10 - If ORA_FFI.FFI_ERROR is raised at any point during registration, call ADD_ERROR with FunctionName and the concatenated error text from WIN_API.UError and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001
Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL in the FFI cache.
TRUE: DLL_HANDLE is populated; processing continues to the registration check (DP-002).
FALSE: ORA_FFI.FFI_ERROR is raised; processing falls through to the inner exception handler which attempts D2KWUTIL.ATTEMPT_DLL_LOAD (DP-002 path B).

DP-002
Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in loading the DLL when FIND_LIBRARY failed.
TRUE: DLL_HANDLE is populated; processing continues to the registration check.
FALSE: ORA_FFI.FFI_ERROR is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised to abort.

DP-003
Condition: FunctionLoad does not contain an entry for FunctionID, OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.
TRUE: The function must be (re-)registered; proceed with Steps 5-9.
FALSE: The function is already registered under the current DLL load cycle; skip registration entirely.

DP-004
Condition: FunctionName equals 'd2kwutil_DebugString'.
TRUE: Skip the DEBUGLOG diagnostic call to avoid recursive logging.
FALSE: Call DEBUGLOG to record whether this is an initial registration or a re-registration.

DP-005
Condition: An entry for FunctionID already exists in FunctionLoad at the time the debug log is written.
TRUE: Log a re-registration message that includes the previous load count.
FALSE: Log an initial registration message.

DP-006
Condition: The remaining FunctionArgs string is non-NULL, not equal to ',', and not equal to 'VOID,'.
TRUE: Extract the next comma-delimited type token, translate it via D2KWUTIL.TRANSLATETYPE, register it as a parameter, and advance the string.
FALSE: Exit the parameter registration loop.

DP-007
Condition: FunctionReturn is not 'VOID' (case-insensitive) AND FunctionReturn is not NULL.
TRUE: Translate FunctionReturn via D2KWUTIL.TRANSLATETYPE and register it as the FFI return type.
FALSE: No return type is registered (procedure-style call or explicitly void function).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or successfully reloaded via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; failure to satisfy either condition disables the API (API_ENABLED = FALSE) and prevents further calls.
- BR-002 - A function registration is only performed when strictly necessary: either the function has never been registered (no FunctionLoad entry for FunctionID) or the DLL has been reloaded since the last registration (FunctionLoad(FunctionID) ≠ DLL_LOAD_COUNT). This prevents redundant FFI overhead on repeated calls.
- BR-003 - Function parameters are registered in the order they appear in the comma-separated FunctionArgs string; a parameter list that is NULL, empty after delimiting, or equal to 'VOID' results in no parameters being registered.
- BR-004 - A return type is registered only when FunctionReturn is explicitly non-void and non-null; a value of 'VOID' (any case) or NULL indicates a procedure-style FFI call with no return registration.
- BR-005 - The internal function 'd2kwutil_DebugString' is excluded from diagnostic logging during registration to prevent recursive invocation of the debug subsystem.
- BR-006 - On any ORA_FFI.FFI_ERROR during the registration phase, the error is captured via ADD_ERROR (incorporating ADD_EXTERNAL_ERRORS for supplementary detail) and NO_DATA_FOUND is raised to signal the calling procedure that the function is unavailable.
- BR-007 - Type translation from string representation to ORA_FFI constants is always delegated to D2KWUTIL.TRANSLATETYPE; no inline type mapping is performed within this procedure.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-082 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging state for the application session by setting the debug output type (file or message), target file path, logging level, and timestamp preference. Depending on the requested debug type, the procedure activates file-based logging, activates message-based logging, or stops logging entirely, and records the resulting state change via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept four input parameters: DebugType (logging mode selector), DebugFile (target file path, defaults to NULL), DebugLevel (verbosity threshold, defaults to 98), and TimeStamp (flag to include timestamps, defaults to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel.
- Step 5 - Evaluate DebugType to determine the logging mode to activate (see Decision Points).
- Step 6 - Set the package-level variable iDebugState to reflect the chosen mode (1 for file logging, 2 for message logging, 0 for logging stopped).
- Step 7 - Call DEBUGLOG to record a confirmation message that describes the action taken (file logging started with file name, message logging started, or logging stopped).

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging) and call DEBUGLOG with the message 'Logging to File' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging) and call DEBUGLOG with the message 'Logging Started'.

FALSE: Call DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, disabling all logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType must be 1 to enable file-based logging; any value other than 1 or 2 is treated as a request to stop logging.
- BR-002 - DebugType must be 2 to enable message-based logging.
- BR-003 - The DebugFile parameter is only meaningful when DebugType = 1; it is stored unconditionally but is relevant only for file-based logging mode.
- BR-004 - DebugLevel defaults to 98 if not supplied, establishing a high-verbosity threshold unless the caller explicitly overrides it.
- BR-005 - Timestamp inclusion defaults to FALSE; the caller must explicitly pass TRUE to attach timestamps to log entries.
- BR-006 - Every invocation of SETDEBUG must result in a DEBUGLOG entry confirming the outcome of the configuration change, regardless of which mode is selected.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-083 - SF_GET_PRICE

**Invoked From:**

- SP_GET_STORES_STOCK.prc [StoredProcedure: SP_GET_STORES_STOCK]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

SF_GET_PRICE is a scalar function that retrieves the applicable unit price for a given part based on a caller-supplied price-type code. It is invoked by SP_GET_STORES_STOCK to populate price values during stock enquiry processing. Depending on the price type requested ('NA', 'P', 'O', 'L', 'M', or 'LC'), the function queries the appropriate price field from PM_PART or PM_PART_VAR, delegating sell-price calculation for types 'O' and 'L' to SP_GET_PART_SELL_PRICE_ONE. If no matching record is found in the variant table, the function falls back to the master part table. The function always returns a numeric price, defaulting to zero on any unresolvable condition.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | pm_part_var.parent_group%TYPE | IN |
| p_dealer_map_cd | pm_part_var.dealer_map_cd%TYPE | IN |
| p_loc_cd | pm_part_var.loc_cd%TYPE | IN |
| p_principal | pm_part_var.dealer_map_cd%TYPE | IN |
| p_price_type | VARCHAR2 | IN |
| p_part_num | pm_part_var.part_num%TYPE | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SP_GET_PART_SELL_PRICE_ONE ([SP-086](#SP-086--SP_GET_PART_SELL_PRICE_ONE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return variable v_price to 0.
- Step 2 - Evaluate the price type code supplied in p_price_type (case-insensitive) to determine which price field to retrieve.
- Step 3 - If price type is 'NA', query PM_PART for sell_price where the part number matches and dealer_map_cd is either the dealer or the principal, filtered by principal_map_cd.
- Step 4 - If price type is 'P', query PM_PART_VAR for purchase_price using the combination of parent_group, dealer_map_cd, loc_cd, and part_num; apply NVL defaulting to 0.
- Step 5 - If price type is 'O' or 'L', first query AM_DEALER_LOC joined to GM_STATE to derive the GST state code (lv_gst_state_cd) for the dealer location. Then call SP_GET_PART_SELL_PRICE_ONE passing principal, parent_group, dealer_map_cd, loc_cd, part_num, price-type indicator 'O', and the derived GST state code to obtain the sell price into v_price. If any exception occurs within this block, v_price is set to 0.
- Step 6 - If price type is 'M', query PM_PART_VAR for mrp_1 using the standard location key; apply NVL defaulting to 0.
- Step 7 - If price type is 'LC', query PM_PART_VAR for landed_cost using the standard location key; apply NVL defaulting to 0.
- Step 8 - Return v_price to the caller.
- Step 9 - On a NO_DATA_FOUND exception from the primary queries, execute a fallback lookup against PM_PART: retrieve purchase_price for type 'P'; sell_price for types 'L' or 'O'; mrp_1 for type 'M'; matching on part_num, dealer_map_cd (dealer or principal), and principal_map_cd. Return the fallback price.
- Step 10 - If the fallback query also raises NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception, set v_price to 0 and return it.
- Step 11 - On TOO_MANY_ROWS or any other exception at the outer level, set v_price to 0 and return it.

---
**Decision Points**

DP-001

Condition: UPPER(p_price_type) = 'NA'

TRUE: Query PM_PART for sell_price filtered by part_num, dealer_map_cd IN (p_dealer_map_cd, p_principal), and principal_map_cd = p_principal; return that value.

FALSE: Proceed to evaluate further price type codes (DP-002 onwards).

---

DP-002

Condition: UPPER(p_price_type) = 'P'

TRUE: Query PM_PART_VAR for NVL(purchase_price, 0) using parent_group, dealer_map_cd, loc_cd, and part_num.

FALSE: Proceed to evaluate type 'O' or 'L' (DP-003).

---

DP-003

Condition: UPPER(p_price_type) = 'O' OR UPPER(p_price_type) = 'L'

TRUE: Derive lv_gst_state_cd from AM_DEALER_LOC joined to GM_STATE, then delegate price retrieval to SP_GET_PART_SELL_PRICE_ONE; on any exception within this block, set v_price to 0.

FALSE: Proceed to evaluate type 'M' (DP-004).

---

DP-004

Condition: UPPER(p_price_type) = 'M'

TRUE: Query PM_PART_VAR for NVL(mrp_1, 0) using the standard location key.

FALSE: Proceed to evaluate type 'LC' (DP-005).

---

DP-005

Condition: UPPER(p_price_type) = 'LC'

TRUE: Query PM_PART_VAR for NVL(landed_cost, 0) using the standard location key.

FALSE: No matching price type; v_price remains 0.

---

DP-006

Condition: Primary query raises NO_DATA_FOUND

TRUE: Execute fallback lookup against PM_PART based on the price type ('P' -> purchase_price; 'L' or 'O' -> sell_price; 'M' -> mrp_1), matching on part_num, dealer_map_cd IN (p_principal, p_dealer_map_cd), and principal_map_cd = p_principal; return the fallback value.

FALSE: No fallback required; return the price obtained from the primary query.

---

DP-007

Condition: Fallback PM_PART query raises NO_DATA_FOUND, TOO_MANY_ROWS, or OTHERS

TRUE: Set v_price to 0 and return 0.

FALSE: Return the successfully retrieved fallback price.

---

DP-008

Condition: Outer exception handler catches TOO_MANY_ROWS or OTHERS (not NO_DATA_FOUND)

TRUE: Set v_price to 0 and return 0.

FALSE: Normal execution path; return the resolved price.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-003 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - Price type comparison is always performed case-insensitively (UPPER applied to p_price_type) to prevent missed matches due to mixed-case input.
- BR-002 - For price type 'NA', the sell price is sourced from the master part table PM_PART and the dealer_map_cd match accepts either the dealer's own code or the principal code, ensuring multi-company scenarios are handled correctly.
- BR-003 - For price type 'P', the purchase price is sourced from the location-level variant table PM_PART_VAR; a NULL purchase_price is treated as zero via NVL.
- BR-004 - For price types 'O' and 'L', the GST state code must be resolved from AM_DEALER_LOC joined to GM_STATE before the sell price can be calculated; the resolved GST state code is passed to SP_GET_PART_SELL_PRICE_ONE as a mandatory input.
- BR-005 - For price types 'O' and 'L', sell price calculation is fully delegated to SP_GET_PART_SELL_PRICE_ONE; the fixed price-type indicator passed to that procedure is always 'O' regardless of whether the caller requested 'O' or 'L'.
- BR-006 - For price type 'M', the MRP (mrp_1) is sourced from PM_PART_VAR; a NULL value is treated as zero via NVL.
- BR-007 - For price type 'LC', the landed cost is sourced from PM_PART_VAR; a NULL value is treated as zero via NVL.
- BR-008 - When the primary PM_PART_VAR lookup returns no row, the function falls back to PM_PART for price types 'P', 'O', 'L', and 'M'; price type 'LC' has no defined fallback and will return 0 if no variant record exists.
- BR-009 - In all fallback PM_PART queries, principal_map_cd must equal p_principal, enforcing multi-company data segregation.
- BR-010 - The function is non-throwing: every exception path (NO_DATA_FOUND, TOO_MANY_ROWS, OTHERS) at both primary and fallback levels results in a return value of 0, ensuring the calling procedure SP_GET_STORES_STOCK always receives a numeric result.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Price(p_parent_group  pm_part_var.parent_group%TYPE,
                                        p_dealer_map_cd pm_part_var.dealer_map_cd%TYPE,
                                        p_loc_cd        pm_part_var.loc_cd%TYPE,
                                        p_principal     pm_part_var.dealer_map_cd%TYPE,
                                        p_price_type    VARCHAR2,
                                        p_part_num      pm_part_var.part_num%TYPE)
  RETURN pm_part_var.purchase_price%TYPE IS
  v_price      pm_part_var.purchase_price%TYPE := 0;
  v_sql        VARCHAR2(2000);
  v_price_code VARCHAR2(100);
	lv_gst_state_cd gm_state.gst_state_cd%type;
	lv_ccy        VARCHAR2(10);
	lv_po_ccy     VARCHAR2(10);
	lv_tax_cd     pm_part_var.part_tax_cd%type;
BEGIN
  IF UPPER(p_price_type) = 'NA' THEN
    SELECT sell_price
      INTO v_price
      FROM pm_part
     WHERE dealer_map_cd IN (p_dealer_map_cd, p_principal)
       AND part_num = p_part_num
       AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
  ELSE
    IF UPPER(p_price_type) = 'P' THEN
      SELECT NVL(purchase_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
 ELSIF UPPER(p_price_type) = 'O' or UPPER(p_price_type) = 'L' then
		   begin
   SELECT  gst_state_cd into   lv_gst_state_cd
    FROM am_dealer_loc l, gm_state g
   WHERE l.parent_group = p_parent_group
     AND l.dealer_map_cd = p_dealer_map_cd
     AND l.loc_cd = p_loc_cd
     AND g.principal_map_cd = l.principal_map_cd
     AND g.state_cd = l.state_cd;
    Sp_Get_Part_Sell_Price_One(--------------------v_1
                               p_principal,
                               p_parent_group,
                               p_dealer_map_cd,
                               p_loc_cd,
                               p_part_num,
                               'O',
                               lv_po_ccy,
                               v_price,
                               lv_tax_cd,
                               'Y',
                               lv_gst_state_cd
                               )
                               ;
       exception
         when others then
           v_price:=0;
      end;

    /*  SELECT NVL(os_sell_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    ELSIF UPPER(p_price_type) = 'L' THEN
      SELECT NVL(ls_sell_price, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;*/
    ELSIF UPPER(p_price_type) = 'M' THEN
      SELECT NVL(mrp_1, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    ELSIF UPPER(p_price_type) = 'LC' THEN
      SELECT NVL(landed_cost, 0)
        INTO v_price
        FROM pm_part_var
       WHERE parent_group = p_parent_group
         AND dealer_map_cd = p_dealer_map_cd
         AND loc_cd = p_loc_cd
         AND part_num = p_part_num;
    END IF;
  END IF;

  RETURN v_price;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    BEGIN
      IF UPPER(p_price_type) = 'P' THEN
        SELECT purchase_price
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      ELSIF UPPER(p_price_type) = 'L' OR UPPER(p_price_type) = 'O' THEN
        SELECT sell_price
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      ELSIF UPPER(p_price_type) = 'M' THEN
        SELECT mrp_1
          INTO v_price
          FROM pm_part
         WHERE part_num = p_part_num
           AND dealer_map_cd IN (p_principal, p_dealer_map_cd)
           AND principal_map_cd = p_principal;  --Added by Rajeev for multi company changes
      END IF;

      RETURN v_price;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        v_price := 0;
        RETURN v_price;
      WHEN TOO_MANY_ROWS THEN
        v_price := 0;
        RETURN v_price;
      WHEN OTHERS THEN
        v_price := 0;
        RETURN v_price;
    END;
  WHEN TOO_MANY_ROWS THEN
    v_price := 0;
    RETURN v_price;
  WHEN OTHERS THEN
    v_price := 0;
    RETURN v_price;
END;

```

#### SP-084 - SF_GET_STORE_BIN_LOC

**Invoked From:**

- pe_part_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- pe_part_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

SF_GET_STORE_BIN_LOC is a scalar function that retrieves the bin location(s) associated with a specific part number within a dealer's stock. It first resolves the company financial area code for the given parent group, dealer, and location, then queries active default bin locations from PM_STOCK_BIN_LOC, optionally filtering by store code. The function returns a comma-separated string of matching bin locations for display on the PART HELP screen.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | PM_PART_VAR.parent_group%TYPE | IN |
| p_dealer | PM_PART_VAR.dealer_map_cd%TYPE | IN |
| p_loc_cd | PM_PART_VAR.loc_cd%TYPE | IN |
| p_part_num | VARCHAR2 | IN |
| p_store_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return variable lv_bin_loc to NULL and lv_comp_fa to NULL.
- Step 2 - Attempt to resolve the company financial area code (lv_comp_fa) by querying AM_DEALER_LOC_COMPANY_MASTER for a distinct comp_code matching the supplied p_parent, p_dealer, and p_loc_cd. If no row is found or any exception occurs, lv_comp_fa remains NULL and processing continues.
- Step 3 - Execute cursor c1 against PM_STOCK_BIN_LOC, filtering on p_parent, p_dealer, p_loc_cd, p_store_cd, p_part_num, the resolved lv_comp_fa (or all comp_fa values if NULL), ACTIVE_YN = 'Y', and DEFAULT_YN = 'Y'. This path applies when a store code is provided.
- Step 4 - Iterate over c1 results. For the first matching row, assign bin_loc to lv_bin_loc. For each subsequent row, append the bin_loc value to lv_bin_loc separated by a comma and space.
- Step 5 - Evaluate whether p_store_cd is NULL. If it is, execute cursor c2, which queries PM_STOCK_BIN_LOC with the same filters as c1 except that the stores_cd filter is omitted and DISTINCT bin_loc values are selected using an index hint (IDX_PMS_BIN_LOC_PART).
- Step 6 - Iterate over c2 results using the same concatenation logic as Step 4, building or extending lv_bin_loc.
- Step 7 - Return lv_bin_loc to the caller. The value is either a single bin location, a comma-separated list of bin locations, or NULL if no active default bin locations were found.

---
**Decision Points**

DP-001

Condition: Whether the SELECT against AM_DEALER_LOC_COMPANY_MASTER returns a distinct comp_code for the given p_parent, p_dealer, and p_loc_cd.

TRUE: lv_comp_fa is populated with the retrieved comp_code and is used as an exact filter in the subsequent PM_STOCK_BIN_LOC cursors.

FALSE (exception or no data): lv_comp_fa remains NULL; the NVL(lv_comp_fa, comp_fa) expression in both cursors causes the comp_fa filter to be bypassed, returning bin locations regardless of company financial area.

DP-002

Condition: Whether lv_bin_loc is NULL at the point each bin_loc row is processed in the cursor loops (c1 and c2).

TRUE: lv_bin_loc is assigned the current bin_loc value directly (no leading separator).

FALSE: The current bin_loc value is appended to lv_bin_loc with a ', ' separator, building a comma-separated list.

DP-003

Condition: Whether p_store_cd is NULL after the c1 loop completes.

TRUE: Cursor c2 is executed to retrieve distinct active default bin locations for the part without any store code restriction, and its results are merged into lv_bin_loc.

FALSE: Cursor c2 is skipped entirely; only the store-code-specific results from c1 are used.

---
**Database Interactions**

- DB-001 - Read PM_STOCK_BIN_LOC - Reads data from PM_STOCK_BIN_LOC for lookup or validation.
- DB-002 - Read AM_DEALER_LOC_COMPANY_MASTER - Reads data from AM_DEALER_LOC_COMPANY_MASTER for lookup or validation.
**Business Rules**

- BR-001 - Only bin locations that are both active (ACTIVE_YN = 'Y') and flagged as default (DEFAULT_YN = 'Y') in PM_STOCK_BIN_LOC are eligible for return.
- BR-002 - When a store code is supplied (p_store_cd IS NOT NULL), bin location lookup is restricted to rows matching that specific stores_cd in PM_STOCK_BIN_LOC (cursor c1).
- BR-003 - When no store code is supplied (p_store_cd IS NULL), the store code filter is omitted and all distinct matching bin locations across stores are returned (cursor c2); cursor c1 will return no rows in this scenario because stores_cd = NULL never matches a real value.
- BR-004 - If the company financial area code can be resolved from AM_DEALER_LOC_COMPANY_MASTER, it is applied as an exact filter on comp_fa in PM_STOCK_BIN_LOC; if it cannot be resolved, the comp_fa filter is effectively suppressed via NVL, and bin locations for all company financial areas are included.
- BR-005 - Multiple bin locations satisfying the filter criteria are concatenated into a single comma-separated string; the function always returns a VARCHAR2 value (NULL when no qualifying rows exist).
- BR-006 - The company financial area lookup requires a unique comp_code for the combination of parent_group, dealer_map_cd, and loc_cd; any ambiguity or absence is silently handled, defaulting to the no-filter behaviour described in BR-004.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Store_Bin_Loc (
      p_parent     PM_PART_VAR.parent_group%TYPE,
      p_dealer     PM_PART_VAR.dealer_map_cd%TYPE,
      p_loc_cd     PM_PART_VAR.loc_cd%TYPE,
      p_part_num   VARCHAR2,
      p_store_cd   VARCHAR2
)
      RETURN VARCHAR2
IS
      lv_bin_loc   VARCHAR2 (4000)                               := NULL;
      lv_comp_fa   AM_DEALER_LOC_COMPANY_MASTER.comp_code%TYPE;

      CURSOR c1
      IS
            SELECT bin_loc
              FROM PM_STOCK_BIN_LOC
             WHERE parent_group = p_parent
               AND dealer_map_cd = p_dealer
               AND loc_cd = p_loc_cd
               AND stores_cd = p_store_cd
               AND part_num = p_part_num
               AND comp_fa = NVL (lv_comp_fa, comp_fa)
			   AND ACTIVE_YN ='Y'
			   AND DEFAULT_YN = 'Y';

      CURSOR c2
      IS
        SELECT /*+ index (pm IDX_PMS_BIN_LOC_PART)*/DISTINCT bin_loc --index hint added by Arpan on 08-oct-13
          FROM PM_STOCK_BIN_LOC pm
         WHERE pm.parent_group = p_parent
           AND pm.dealer_map_cd = p_dealer
           AND pm.loc_cd = p_loc_cd
           AND pm.part_num = p_part_num
           AND pm.comp_fa = NVL (lv_comp_fa, pm.comp_fa)
           AND pm.ACTIVE_YN ='Y'
           AND pm.DEFAULT_YN = 'Y';
BEGIN
      BEGIN
            SELECT DISTINCT comp_code
                       INTO lv_comp_fa
                       FROM AM_DEALER_LOC_COMPANY_MASTER
                      WHERE parent_group = p_parent AND dealer_map_cd = p_dealer AND loc_cd = p_loc_cd;
      EXCEPTION
            WHEN OTHERS THEN
                  NULL;
      END;

      /* With Stores Code */
      FOR i IN c1
      LOOP
            IF lv_bin_loc IS NULL THEN
                  lv_bin_loc := i.bin_loc;
            ELSE
                  lv_bin_loc := lv_bin_loc || ', ' || i.bin_loc;
            END IF;
      END LOOP;

      /* Without Stores Code */
      IF p_store_cd IS NULL THEN
            FOR i IN c2
            LOOP
                  IF lv_bin_loc IS NULL THEN
                        lv_bin_loc := i.bin_loc;
                  ELSE
                        lv_bin_loc := lv_bin_loc || ', ' || i.bin_loc;
                  END IF;
            END LOOP;
      END IF;

      RETURN lv_bin_loc;
END;

```

#### SP-085 - SF_GET_STORE_NAME

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART HELP (N/A / CN_MAIN)

---

**Purpose**

SF_GET_STORE_NAME is a scalar function that retrieves the store description name from the GM_STORE reference table for a given dealer map code, location code, and store code combination. It is used on the PART HELP screen to resolve a store code into its human-readable description when a button-press event is triggered in pe_part_fmb.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer_map_cd | number | IN |
| p_loc_cd | varchar2 | IN |
| p_store_cd | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: dealer map code (p_dealer_map_cd), location code (p_loc_cd), and store code (p_store_cd).
- Step 2 - Query the GM_STORE table, selecting the STORES_DESC column where DEALER_MAP_CD, LOC_CD, and STORES_CD match the supplied input values.
- Step 3 - If a matching row is found, assign the retrieved store description to the local variable lv_name.
- Step 4 - If no matching row exists (NO_DATA_FOUND exception), set lv_name to NULL.
- Step 5 - Return lv_name (either the store description string or NULL) to the calling context.

---
**Decision Points**

DP-001

Condition: A row exists in GM_STORE where DEALER_MAP_CD = p_dealer_map_cd AND LOC_CD = p_loc_cd AND STORES_CD = p_store_cd.

TRUE: The STORES_DESC value is assigned to lv_name and returned to the caller.

FALSE: A NO_DATA_FOUND exception is raised; lv_name is set to NULL and NULL is returned to the caller.

---
**Database Interactions**

- DB-001 - Read GM_STORE - Reads data from GM_STORE for lookup or validation.
**Business Rules**

- BR-001 - The store lookup requires all three key attributes (dealer map code, location code, and store code) to be provided; the GM_STORE query applies all three as mandatory filter conditions.
- BR-002 - If no store record matches the supplied key combination, the function returns NULL rather than raising an unhandled exception, ensuring the calling screen continues to operate without error.
- BR-003 - The function returns at most one store description; the SELECT INTO construct implicitly enforces a single-row result from GM_STORE for the given key.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_get_store_name(p_dealer_map_cd number, p_loc_cd varchar2, p_store_cd varchar2)
return varchar2 is
lv_name varchar2(100);
begin
begin
  select stores_desc into lv_name from gm_store where dealer_map_cd = p_dealer_map_cd and loc_cd = p_loc_cd and stores_cd = p_store_cd;
exception
    when no_data_found then
       lv_name := null;
end;

  return(lv_name);
end;

```

#### SP-086 - SP_GET_PART_SELL_PRICE_ONE

**Invoked From:**

- SF_GET_PRICE.fnc [StoredProcedure: SF_GET_PRICE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the selling price and part tax code for a specified part, returning values that vary based on the requested price type (sell, purchase, OS sell, LS sell, or MRP). When GST tax logic applies, the procedure derives a back-calculated selling price from the part's MRP by stripping out applicable charge/tax percentages sourced from AM_CHARGE and PM_TAX, taking into account the customer's GST state, the list/non-list indicator, and the CESS flag. The procedure is invoked exclusively by SF_GET_PRICE to supply part pricing data during price resolution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PRINCIPAL | NUMBER | IN |
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER_MAP_CD | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_PART_NUM | VARCHAR2 | IN |
| P_TAX_TYPE | VARCHAR2 | IN |
| pi_lst_yn | VARCHAR2 | IN |
| pi_cust_gst_state_cd | ph_issue.cust_gst_state_cd%type | IN |
| PI_CESS_FLAG | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| PO_CCY | VARCHAR2 | OUT |
| PO_PRICE | NUMBER | OUT |
| PO_TAX_CD | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive input parameters identifying the principal, parent group, dealer/location, part number, tax type, list price indicator, customer GST state code, and CESS flag.
- Step 2 - Evaluate P_TAX_TYPE. If it equals 'NA' (case-insensitive), execute the simplified path: query PM_PART for the part's SELL_PRICE using DEALER_MAP_CD (matched against either P_DEALER_MAP_CD or P_PRINCIPAL) and PRINCIPAL_MAP_CD = P_PRINCIPAL, assign the result to V_PRICE, and skip all GST logic.
- Step 3 - If P_TAX_TYPE is not 'NA', enter the GST pricing path. Query PM_PART_VAR for the PART_TAX_CD matching the combination of P_PARENT_GROUP, P_DEALER_MAP_CD, P_LOC_CD, and P_PART_NUM; store the result in LN_PTAX.
- Step 4 - Query PM_PART_VAR for MRP_1 using the same key (PARENT_GROUP, DEALER_MAP_CD, LOC_CD, PART_NUM). If no row is found, fall back to PM_PART using DEALER_MAP_CD IN (P_PRINCIPAL, P_DEALER_MAP_CD) and PRINCIPAL_MAP_CD = P_PRINCIPAL; if that also fails, default LN_MRP_1 to 0.
- Step 5 - Determine the tax applicability indicator (LV_TAXTYPE): set to 'O' if PI_LST_YN = 'Y' (list price), otherwise set to 'C' (common/non-list).
- Step 6 - Cursor-loop over AM_CHARGE joined to PM_TAX for the dealer/location, filtering on TAX_TYPE = 'S', COMMON_IND = LV_TAXTYPE, PART_TAX_CD = LN_PTAX, PARENT_GROUP = P_PARENT_GROUP, and GST_STATE_CD matched via DECODE(PI_LST_YN, 'Y', B.GST_STATE_CD, PI_CUST_GST_STATE_CD). Exclude charge types 'TCN', 'TCP', and 'TCT'.
- Step 7 - Accumulate charge values into LV_OS_FACTOR: include a CHARGE_TYPE = 'CES' row only when PI_CESS_FLAG = 'Y'; always include all other charge types.
- Step 8 - Back-calculate the selling price from MRP: LN_OS_SELL_PRICE = TRUNC((LN_MRP_1 × 100) / (100 + LV_OS_FACTOR), 2). Assign the same computed value to LN_LS_SELL_PRICE.
- Step 9 - Select the final price (V_PRICE) based on P_TAX_TYPE: 'P' -> LN_PURCHASE_PRICE; 'O' -> LN_OS_SELL_PRICE; 'L' -> LN_LS_SELL_PRICE; 'M' -> LN_MRP_1.
- Step 10 - Assign V_PRICE to output parameter PO_PRICE and LN_PTAX to output parameter PO_TAX_CD. PO_CCY is declared as an OUT parameter but is not explicitly set within this procedure.

---
**Decision Points**

DP-001

Condition: UPPER(P_TAX_TYPE) = 'NA'

TRUE: Query PM_PART directly for SELL_PRICE using DEALER_MAP_CD IN (P_DEALER_MAP_CD, P_PRINCIPAL) and PRINCIPAL_MAP_CD = P_PRINCIPAL; assign to V_PRICE; bypass all GST/tax charge logic.

FALSE: Enter the GST pricing path to retrieve PART_TAX_CD, MRP_1, and accumulated charge factors.

---

DP-002

Condition: PM_PART_VAR returns NO_DATA_FOUND when queried for MRP_1

TRUE: Attempt a fallback query against PM_PART for MRP_1 using DEALER_MAP_CD IN (P_PRINCIPAL, P_DEALER_MAP_CD) and PRINCIPAL_MAP_CD = P_PRINCIPAL; if that also fails, default LN_MRP_1 to 0.

FALSE: Use the MRP_1 value (NVL to 0) returned from PM_PART_VAR.

---

DP-003

Condition: PI_LST_YN = 'Y'

TRUE: Set LV_TAXTYPE = 'O' (outside/list pricing indicator) and match GST_STATE_CD to the stored PM_TAX value (B.GST_STATE_CD).

FALSE: Set LV_TAXTYPE = 'C' (common/non-list pricing indicator) and match GST_STATE_CD to PI_CUST_GST_STATE_CD.

---

DP-004

Condition: K.CHARGE_TYPE = 'CES' (CESS charge row encountered in the cursor loop)

TRUE: Include the CESS charge value in LV_OS_FACTOR only if PI_CESS_FLAG = 'Y'; otherwise skip it.

FALSE: Unconditionally add the charge value to LV_OS_FACTOR.

---

DP-005

Condition: UPPER(P_TAX_TYPE) evaluated against 'P', 'O', 'L', 'M' (after GST path completes)

TRUE ('P'): V_PRICE = LN_PURCHASE_PRICE.
TRUE ('O'): V_PRICE = LN_OS_SELL_PRICE (back-calculated from MRP).
TRUE ('L'): V_PRICE = LN_LS_SELL_PRICE (back-calculated from MRP).
TRUE ('M'): V_PRICE = LN_MRP_1.

FALSE (none match): V_PRICE retains its initialised value of 0.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-003 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
**Business Rules**

- BR-001 - When P_TAX_TYPE = 'NA', the part's sell price is retrieved directly from PM_PART without any tax or charge adjustment; no GST logic is applied.
- BR-002 - Part pricing data in PM_PART is scoped to the principal's multi-org context by filtering on both DEALER_MAP_CD IN (P_DEALER_MAP_CD, P_PRINCIPAL) and PRINCIPAL_MAP_CD = P_PRINCIPAL.
- BR-003 - The PART_TAX_CD (LN_PTAX) is resolved from PM_PART_VAR using the unique combination of PARENT_GROUP, DEALER_MAP_CD, LOC_CD, and PART_NUM; if more than one row is found, the procedure raises application error -20032 to prevent ambiguous tax code assignment.
- BR-004 - MRP_1 is sourced preferentially from PM_PART_VAR; if absent, a fallback to PM_PART is attempted; if both sources yield no data, MRP_1 defaults to 0 to prevent arithmetic failure.
- BR-005 - Only tax charges with TAX_TYPE = 'S' (sell) are considered when accumulating the GST factor used for back-calculation.
- BR-006 - Charge types 'TCN', 'TCP', and 'TCT' are explicitly excluded from the charge accumulation loop and must not contribute to the computed selling price.
- BR-007 - The GST state code matching logic is list-price-aware: for list pricing (PI_LST_YN = 'Y') the stored GST state on PM_TAX is used; for non-list pricing the customer's GST state (PI_CUST_GST_STATE_CD) governs the match.
- BR-008 - CESS charges (CHARGE_TYPE = 'CES') are included in the tax factor accumulation only when PI_CESS_FLAG = 'Y'; when the flag is 'N' (default), CESS is excluded from the price back-calculation.
- BR-009 - The selling price is derived by back-calculating from MRP using the formula: TRUNC((MRP_1 × 100) / (100 + total_charge_factor), 2), ensuring the price is truncated to two decimal places.
- BR-010 - Both LN_OS_SELL_PRICE and LN_LS_SELL_PRICE are assigned the same back-calculated value, making the OS and LS sell prices identical under the current GST logic.
- BR-011 - The price type returned to the caller is governed by P_TAX_TYPE: 'P' returns purchase price, 'O' returns OS sell price, 'L' returns LS sell price, and 'M' returns MRP; any unrecognised value results in a price of 0.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        Sp_Get_Part_Sell_Price_One
/*
  $Log: SP_GET_PART_SELL_PRICE.sql,v $
  Revision 1.2  2005/02/22 10:00:28  vidyah
  exception handling
  */

   /***********************************************************************************************************************************************
  * Created/Modified By    Date        Change Indicator   SCR#              Description
  * Ravi                  05-06-17      v_1.3              GST      Gst changes

  ************************************************************************************************************************************************/

(P_PRINCIPAL     IN NUMBER,
 P_PARENT_GROUP  IN VARCHAR2,
 P_DEALER_MAP_CD IN NUMBER,
 P_LOC_CD        IN VARCHAR2,
 P_PART_NUM      IN VARCHAR2,
 P_TAX_TYPE      IN VARCHAR2,
 PO_CCY          OUT VARCHAR2,
 PO_PRICE        OUT NUMBER,
 PO_TAX_CD       OUT VARCHAR2,
 pi_lst_yn       IN VARCHAR2,----Added against v_1.3
 pi_cust_gst_state_cd in ph_issue.cust_gst_state_cd%type, ----Added against v_1.3
 PI_CESS_FLAG         IN VARCHAR2 DEFAULT 'N'   ---ADDED BY SUMIT ON 29052019
 ) IS
  LN_PTAX      PM_PART_VAR.PART_TAX_CD%TYPE;
  v_price      NUMBER := 0;
  v_sql        VARCHAR2(1000);
  v_price_code VARCHAR2(100);

  LN_PURCHASE_PRICE PM_PART_VAR.PURCHASE_PRICE%TYPE;
  LN_OS_SELL_PRICE  PM_PART_VAR.OS_SELL_PRICE%TYPE;
  LN_LS_SELL_PRICE  PM_PART_VAR.LS_SELL_PRICE%TYPE;
  LN_MRP_1          PM_PART_VAR.MRP_1%TYPE;
BEGIN
  -- PROCEDURE TO RETURN sell price and PART TAX CODE FOR A PART
  IF UPPER(p_TAX_type) = 'NA' THEN
    SELECT sell_price
      INTO v_price
      FROM PM_PART
     WHERE dealer_map_cd IN (p_dealer_map_cd, P_PRINCIPAL) --Added by prerna for multi-org
       AND part_num = p_part_num
       and PRINCIPAL_MAP_CD = P_PRINCIPAL; ---neha multi org changes
  ELSE
    /*  BEGIN
       SELECT nvl(PURCHASE_PRICE,0), nvl(OS_SELL_PRICE,0),
              nvl(LS_SELL_PRICE,0), nvl(MRP_1,0)
         INTO LN_PURCHASE_PRICE, LN_OS_SELL_PRICE, LN_LS_SELL_PRICE, LN_MRP_1
         FROM PM_PART_VAR
        WHERE PARENT_GROUP  = p_parent_group
          AND DEALER_MAP_CD = p_dealer_map_cd
          AND LOC_CD        = p_loc_cd
          AND PART_NUM = p_part_num ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        BEGIN
           SELECT nvl(PURCHASE_PRICE,0), nvl(SELL_PRICE,0),
                  nvl(SELL_PRICE,0), nvl(MRP_1,0)
             INTO LN_PURCHASE_PRICE, LN_OS_SELL_PRICE, LN_LS_SELL_PRICE, LN_MRP_1
             FROM PM_PART
            WHERE DEALER_MAP_CD in (p_principal,p_dealer_map_cd )
              AND PART_NUM = p_part_num
              and PRINCIPAL_MAP_CD=P_PRINCIPAL;---neha multi org changes
         EXCEPTION WHEN OTHERS THEN
           LN_PURCHASE_PRICE := 0;
           LN_OS_SELL_PRICE  := 0;
           LN_LS_SELL_PRICE  := 0;
           LN_MRP_1          := 0;
         END;
      WHEN OTHERS THEN
           LN_PURCHASE_PRICE := 0;
           LN_OS_SELL_PRICE  := 0;
           LN_LS_SELL_PRICE  := 0;
           LN_MRP_1          := 0;
    END;*/ -----------------------------COMMENT BY RAVI 08062017
    -----------------------------ravi ---begin--against GST---
    DECLARE
      lv_ls_factor PM_TAX_HDR.ls_factor%TYPE;
      lv_os_factor PM_TAX_HDR.os_factor%TYPE;
      lv_taxtype   PM_TAX.COMMON_IND%TYPE;
      lv_taxcd     PM_TAX.PART_TAX_CD%TYPE;
    BEGIN
      BEGIN
        SELECT PART_TAX_CD
          INTO LN_PTAX
          FROM PM_PART_VAR
         WHERE PARENT_GROUP = P_PARENT_GROUP
           AND DEALER_MAP_CD = P_DEALER_MAP_CD
           AND LOC_CD = P_LOC_CD
           AND PART_NUM = P_PART_NUM; --ADDED TO GET THE DETAILS FOR THAT PARTICUALAR DEALER LOCATION
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          NULL;
        WHEN TOO_MANY_ROWS THEN
          RAISE_APPLICATION_ERROR(-20032,
                                  'More than one Part tax code found for ' ||
                                  P_PART_NUM);
        WHEN VALUE_ERROR THEN
          RAISE_APPLICATION_ERROR(-20033,
                                  'Width problem/Incompatible data while retrieving Part tax code');
        WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20034,
                                  'Execution failed while retrieving Part tax code ' ||
                                  SQLERRM);
      END;
      BEGIN
        SELECT nvl(MRP_1, 0)
          INTO LN_MRP_1
          FROM PM_PART_VAR
         WHERE PARENT_GROUP = p_parent_group
           AND DEALER_MAP_CD = p_dealer_map_cd
           AND LOC_CD = p_loc_cd
           AND PART_NUM = p_part_num;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          LN_MRP_1 := 0;
          BEGIN

            SELECT nvl(MRP_1, 0)
              INTO LN_MRP_1
              FROM PM_PART
             WHERE DEALER_MAP_CD in (p_principal, p_dealer_map_cd)
               AND PART_NUM = p_part_num
               and PRINCIPAL_MAP_CD = P_PRINCIPAL; ---neha multi org changes
          EXCEPTION
            WHEN OTHERS THEN
              LN_MRP_1 := 0;
          END;
      END;

      IF pi_lst_yn = 'Y' THEN
        lv_taxtype := 'O';
      ELSE
        lv_taxtype := 'C';
      END IF;
      BEGIN
        BEGIN
          FOR K IN (SELECT a.charge_type,
                           a.charge_ind,
                           a.charge_value,
                           a.charge_cd,
                           b.common_ind,
                           b.order_srl
                      FROM am_charge a, pm_tax b
                     WHERE b.dealer_map_cd = p_dealer_map_cd
                       AND a.dealer_map_cd = b.dealer_map_cd
                       AND a.loc_cd = p_loc_cd
                       AND b.loc_cd = p_loc_cd
                       AND a.charge_type = b.charge_type
                       AND a.charge_cd = b.charge_cd
                       AND b.tax_type = 'S'
                       AND gst_state_cd=decode(pi_lst_yn,'Y',b.gst_state_cd,pi_cust_gst_state_cd)------Added against v_1.3
                       AND (b.common_ind = lv_taxtype)
                       AND b.part_tax_cd = LN_PTAX
                       AND b.parent_group = p_parent_group
                       AND a.CHARGE_TYPE NOT IN ('TCN','TCP','TCT')  ---added by Saurav on 30Jun2021 DMSSPR-13396
                     ORDER BY charge_srl) LOOP

           /*** ADDED BY SUMIT ON 29052019 FOR CESS ***/
            IF K.CHARGE_TYPE = 'CES' AND PI_CESS_FLAG = 'Y' THEN

           lv_os_factor := NVL(lv_os_factor, 0) + K.charge_value;
           ELSIF K.CHARGE_TYPE <> 'CES' THEN
           lv_os_factor := NVL(lv_os_factor, 0) + K.charge_value;
           end if;
           /***  ADDED BY SUMIT ON 29055019 ***/

          END LOOP;
        END;

        ln_os_sell_price := TRUNC((NVL(LN_MRP_1, 0) * 100) /
                                  (100 + NVL(lv_os_factor, 0)),
                                  2);

        ln_ls_sell_price := TRUNC((NVL(LN_MRP_1, 0) * 100) /
                                  (100 + NVL(lv_os_factor, 0)),
                                  2);

      END;
    END;
    --------------- end ---------

    IF UPPER(p_TAX_type) = 'P' THEN
      v_price := LN_PURCHASE_PRICE;
    ELSIF UPPER(p_TAX_type) = 'O' THEN
      v_price := LN_OS_SELL_PRICE;
    ELSIF UPPER(p_TAX_type) = 'L' THEN
      v_price := LN_LS_SELL_PRICE;
    ELSIF UPPER(p_TAX_type) = 'M' THEN
      v_price := LN_MRP_1;
    END IF;
  END IF;

  PO_PRICE  := V_PRICE;
  PO_TAX_CD := LN_PTAX;
END;

```

#### SP-087 - SP_GET_STORES_STOCK

**Invoked From:**

- pe_part_fmb.xml [Trigger: POST-QUERY]

---

**Screen:**

N/A

---

**Purpose**

Retrieves the current available stock quantity, part description, and selling price for a specified part number within a given dealer, location, stores, and company/FA combination. The procedure is invoked during the POST-QUERY trigger of the parts screen (pe_part_fmb.xml) to populate stock and pricing information for pick-ticket and purchase-return processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | NUMBER | IN |
| p_dealer | NUMBER | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_stores_cd | VARCHAR2 | IN |
| p_part_num | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_stock_qty | NUMBER | OUT |
| p_part_desc | VARCHAR2 | OUT |
| p_sell_price | NUMBER | OUT |
| p_errmsg | VARCHAR2 | OUT |
| p_error_cd | NUMBER | OUT |

---

**Dependencies**

- SF_GET_PRICE ([SP-083](#SP-083--SF_GET_PRICE)) - standalone source file
- WEBUTIL.EXECUTE ([SP-029](#SP-029--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-059](#SP-059--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept six input parameters identifying the principal, dealer, company/FA code, location code, stores code, and part number to be queried.
- Step 2 - Build and execute a dynamic SQL statement that joins PM_PART and PM_STOCK to compute the net available quantity as (OS_STOCK_QTY + LS_STOCK_QTY) minus (OS_FLOAT_QTY + LS_FLOAT_QTY + ALLOC_QTY + WS_RESRV_QTY), filtering PM_STOCK by dealer, location, stores, and company/FA, and PM_PART by part number and dealer/principal mapping.
- Step 3 - Retrieve the computed stock quantity, part description, and sell price from PM_PART into the corresponding OUT parameters; set P_ERROR_CD to 0 to indicate initial success.
- Step 4 - Override the sell price returned by the query by calling SF_GET_PRICE with the dealer, location, principal, order type 'O', and part number to obtain the authoritative selling price from the pricing function.
- Step 5 - Evaluate whether the net stock quantity is zero or negative; if so, raise the user-defined NO_STOCK exception.
- Step 6 - Handle all exceptions: set P_ERRMSG to a descriptive message and P_ERROR_CD to the appropriate error code (1 for no data found, 3 for zero/negative stock, 2 for all other errors) before returning control to the caller.

---
**Decision Points**

DP-001

Condition: NVL(P_STOCK_QTY, 0) <= 0 after the dynamic SQL query executes successfully.

TRUE: The NO_STOCK user-defined exception is raised, P_ERRMSG is set to 'Stock not found for the Part Number <p_part_num>', and P_ERROR_CD is set to 3.

FALSE: Processing completes normally; P_ERROR_CD remains 0 and the stock quantity, part description, and sell price are returned to the caller.

DP-002

Condition: The dynamic SQL query returns NO_DATA_FOUND (part number does not exist in PM_PART or no matching PM_STOCK row exists).

TRUE: P_ERRMSG is set to 'Stock not found for the Part Number <p_part_num>' and P_ERROR_CD is set to 1.

FALSE: Query returns at least one row; processing continues to the sell-price override step.

DP-003

Condition: The dynamic SQL query returns TOO_MANY_ROWS.

TRUE: P_ERRMSG is set to 'More than one stock detail found for the part-<p_part_num>' and P_ERROR_CD is set to 2.

FALSE: Exactly one row is returned; processing continues normally.

DP-004

Condition: A VALUE_ERROR exception occurs during query execution or data assignment.

TRUE: P_ERRMSG is set to 'Width problem/Incompatible Data for the part-<p_part_num>' and P_ERROR_CD is set to 2.

FALSE: No value/width mismatch; processing continues normally.

DP-005

Condition: Any other unhandled exception occurs during execution.

TRUE: P_ERRMSG is set to 'Execution failed while stock fetching for the part-<p_part_num>-<SQLERRM>' and P_ERROR_CD is set to 2.

FALSE: No unhandled exception; processing completes normally.

---
**Database Interactions**

- DB-001 - Read PM_STOCK - Reads data from PM_STOCK for lookup or validation.
- DB-002 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Available stock quantity is calculated as the sum of OS_STOCK_QTY and LS_STOCK_QTY minus the sum of OS_FLOAT_QTY, LS_FLOAT_QTY, ALLOC_QTY, and WS_RESRV_QTY, with all NULL values treated as zero.
- BR-002 - A part is considered valid only when it exists in PM_PART with a DEALER_MAP_CD matching either the principal (P_PRINCIPAL) or the dealer (P_DEALER); the stock lookup in PM_STOCK uses an outer join so that part description is still retrievable even when no stock record exists.
- BR-003 - The PM_STOCK filter must include the COMP_FA column (P_COMP_FA) in addition to dealer, location, and stores code to uniquely identify the correct stock record.
- BR-004 - The sell price derived from the PM_PART query is always superseded by the value returned by SF_GET_PRICE, which is called with order type 'O' to obtain the operative selling price; the query-derived sell price is discarded.
- BR-005 - A net available stock quantity of zero or less is treated as a stock-not-found condition and results in error code 3, distinguishing it from a completely absent part record which returns error code 1.
- BR-006 - P_ERROR_CD value 2 is used for all data-integrity or runtime errors (TOO_MANY_ROWS, VALUE_ERROR, and OTHERS), indicating a system-level or data-quality issue rather than a business stock absence.
- BR-007 - P_ERROR_CD value 0 is set immediately after a successful data retrieval and before the stock-quantity validation, ensuring it is only returned to the caller when both the query succeeds and the stock quantity is positive.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE sp_get_stores_stock
/*
$Log: SP_GET_STORES_STOCK.sql,v $
Modified by Anjiv on 09-02-06 to get sell_price from pm_part_var
Revision 1.6  2005/02/05 10:06:13  ponmuthurajaa
Exception Handling is done
Revision 1.4  2004/11/08 10:34:24  shekarp
Changed the error code being returned to 3, for the exception
no_stock
Revision 1.3  2004/09/13 10:35:11  shekarp
Added the exception, If the part number is found in the table pm_stock with Zero stock
and exception should be raised and an error message to be passed out
to the calling procedure
Revision 1.2  2004/09/02 08:38:03  sanjeevkn
Added the parameter p_comp_fa on Sep 02, 04
Revision 1.1  2004/08/21 06:35:46  ponmuthurajaa
To get the particular stores stock
*/
(
      p_principal    IN       NUMBER,
      p_dealer       IN       NUMBER,
      p_comp_fa      IN       VARCHAR2,
                                 -- Added by Sanjeev on Sep 02, 04 as the PM_STOCK table was updated to include the COMP_FA column
      p_loc_cd       IN       VARCHAR2,
      p_stores_cd    IN       VARCHAR2,
      p_part_num     IN       VARCHAR2,
      p_stock_qty    OUT      NUMBER,
      p_part_desc    OUT      VARCHAR2,
      p_sell_price   OUT      NUMBER,
      p_errmsg       OUT      VARCHAR2,
      p_error_cd     OUT      NUMBER
)
IS
      v_sql1     VARCHAR2 (2000);
      no_stock   EXCEPTION;
BEGIN
  --This will return current stock for particular store
  --This is used by pick_ticket,purchase returns
/* V_Sql1 := 'SELECT ( nvl(os_stock_qty,0) + nvl(ls_stock_qty,0) - ( nvl(os_float_qty,0) + nvl(ls_float_qty,0) + nvl(alloc_qty,0) + nvl(ws_resrv_qty,0) )), p.part_desc, p.sell_price
   FROM   pm_stock s, pm_part p
   WHERE  s.part_num = p.part_num
   AND    s.dealer_map_cd = :p_dealer
   AND    s.loc_cd = :p_loc_cd
   AND    s.stores_cd = :p_stores_cd
   AND    s.part_num  = :p_part_num';*/
      v_sql1 :=
            'SELECT B.QTY,A.PART_DESC,A.SELL_PRICE FROM PM_PART A,
(SELECT PART_NUM,loc_cd,dealer_map_cd,
(
  NVL(os_stock_qty,0) + NVL(ls_stock_qty,0) -
(
  NVL(os_float_qty,0) + NVL(ls_float_qty,0) + NVL(alloc_qty,0) + NVL(ws_resrv_qty,0)
 ))AS QTY
FROM PM_STOCK WHERE dealer_map_cd = :p_dealer
AND    loc_cd = :p_loc_cd
AND    STORES_CD =:p_stores_cd
AND    comp_fa  = :p_comp_fa ) B  			 -- included the condition for comp_fa on Sep 02, 04
WHERE A.PART_NUM=B.PART_NUM(+)
AND    a.part_num  = :p_part_num
AND a.dealer_map_cd IN (:p_principal,:p_dealer)';
      EXECUTE IMMEDIATE v_sql1
                   INTO p_stock_qty,
                        p_part_desc,
                        p_sell_price
                  USING p_dealer, p_loc_cd, p_stores_cd, p_comp_fa, p_part_num, p_principal, p_dealer;
      p_error_cd := 0;
      DBMS_OUTPUT.put_line ('STOCK ' || p_stock_qty);
      --Added by Anjiv on 09-02-06 to get sell_price from pm_part_var
      p_sell_price := sf_get_price (NULL, p_dealer, p_loc_cd, p_principal, 'O', p_part_num);
-----------------------------------------------------------------------------
      IF NVL ( p_stock_qty, 0) <= 0 THEN
            RAISE no_stock;
      END IF;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
            p_errmsg := ' Stock not found for the Part Number ' || p_part_num;
            p_error_cd := 1;
      WHEN no_stock THEN
            p_errmsg := ' Stock not found for the Part Number ' || p_part_num;
                              /* Added by Shekar to display the error message if the part is available but no stock 13-sep-2004*/
            p_error_cd := 3;
      WHEN TOO_MANY_ROWS THEN
            p_errmsg := 'More than one stock detail found for the part-' || p_part_num;
            p_error_cd := 2;
      WHEN VALUE_ERROR THEN
            p_errmsg := 'Width problem/Incompatible Data for the part-' || p_part_num;
            p_error_cd := 2;
      WHEN OTHERS THEN
            p_errmsg := 'Execution failed while stock fetching for the part-' || p_part_num || '-' || SQLERRM;
            p_error_cd := 2;
END;

```

#### SP-088 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a directory path string by removing any semicolon-delimited suffix and any trailing backslash, returning a clean, single-path value. This ensures that path strings passed to downstream routines such as ATTEMPT_DLL_LOAD, GET_TEMP_DIRECTORY, and GET_WINDOWS_DIRECTORY are well-formed and contain no extraneous separators.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working variable (vcPath) with the value of the InPath input parameter.
- Step 2 - Inspect vcPath for the presence of a semicolon character. If one is found, truncate vcPath to retain only the substring that precedes the first semicolon, discarding everything from the semicolon onward.
- Step 3 - Inspect the last character of the (possibly already truncated) vcPath. If that character is a backslash ('\'), remove it by retaining only the substring up to but not including the final character.
- Step 4 - Return the sanitised vcPath value to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path string contains at least one semicolon.

TRUE: vcPath is truncated to the substring before the first semicolon, effectively discarding any additional paths or parameters appended after the semicolon.

FALSE: vcPath is left unchanged and processing continues to DP-002.

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash.

TRUE: The trailing backslash is stripped by retaining only the substring from position 1 to LENGTH(vcPath) - 1.

FALSE: vcPath is left unchanged and the current value is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path preceding the first semicolon is considered valid; any text at or after a semicolon is discarded to prevent multi-path or parameter injection into directory-resolution routines.
- BR-002 - A directory path must not end with a trailing backslash; if one is present it is unconditionally removed before the value is returned.
- BR-003 - Both sanitisation rules (semicolon stripping and trailing backslash removal) are applied sequentially on every invocation; the semicolon check is always evaluated before the trailing backslash check.
- BR-004 - The function operates solely on the supplied InPath string and produces no side-effects; it does not interact with any database table or external session state.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-089 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- pe_part_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates and delivers a CSV/Excel report to the client workstation. The procedure determines the appropriate report-generation path based on whether a dedicated report server is configured for the given principal and application, then either delegates CSV creation to a remote database procedure or builds the file locally from an in-memory record group, transfers the resulting file to the client via WebUtil, and opens it on the client desktop.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-030](#SP-030--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-031](#SP-031--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-033](#SP-033--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-046](#SP-046--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-049](#SP-049--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-058](#SP-058--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-069](#SP-069--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS to retrieve the report server (rep_server) associated with the supplied p_principal and p_app_id combination. If no matching row exists, rep_server is set to NULL.
- Step 2 - Evaluate whether a report server is configured (rep_server IS NOT NULL) to determine which of two processing paths to follow.
- Step 3 (Report-Server Path) - Determine the output file name: if p_file_name is NULL, prompt the user with a file-save dialog (WEBUTIL.FILE_SAVE_DIALOG); otherwise use p_file_name. Append the '.csv' extension to form the final FILENAME.
- Step 4 (Report-Server Path) - Validate that FILENAME contains no spaces in its folder path. If spaces are detected, redirect the file to 'C:\' using only the base file name and display an informational message to the user.
- Step 5 (Report-Server Path) - Invoke the remote procedure sp_csv_report_generate via the database link dms1_db3_lnk, passing FILENAME and p_query, to generate the CSV file in the server's /utl_dir/ directory.
- Step 6 (Report-Server Path) - Execute a shell command via WEBUTIL.HOST to move the generated file from /utl_dir/ to /iashome/ias/reports/printer/.
- Step 7 (Report-Server Path) - Read the base URL for the reports directory from the server-side text file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and WEBUTIL.GET_LINE, then close the file with WEBUTIL.FCLOSE.
- Step 8 (Report-Server Path) - Construct the full URL (formserverpath) by concatenating the retrieved URL with the base file name, then transfer the file to the client using WEBUTIL.URL_TO_CLIENT. If the transfer fails, display a failure message.
- Step 9 (Report-Server Path) - Open the transferred file on the client desktop by issuing a 'cmd /c' command via WEBUTIL.HOST.
- Step 10 (No Report-Server Path) - Determine FILENAME using the same file-name and space-validation logic as Steps 3-4.
- Step 11 (No Report-Server Path) - Check whether a record group named 'DataRecordSet' already exists using WEBUTIL.ID_NULL; if it does, delete it. Create a new record group from p_query and populate it, then obtain the row count.
- Step 12 (No Report-Server Path) - Read the base URL from /reports/DMS/excelpath.txt (WEBUTIL.FOPEN / WEBUTIL.GET_LINE / WEBUTIL.FCLOSE) and construct formserverpath.
- Step 13 (No Report-Server Path) - Open the server-side output file for writing using WEBUTIL.FOPEN, locate the target column in the record group, and iterate over every row, writing each cell value followed by a newline character using WEBUTIL.PUTF.
- Step 14 (No Report-Server Path) - Close the output file with WEBUTIL.FCLOSE, transfer it to the client with WEBUTIL.URL_TO_CLIENT (displaying a failure message if unsuccessful), and open it on the client desktop via WEBUTIL.HOST.
- Step 15 - If any unhandled exception occurs during execution, display an error message combining ERROR_CODE and ERROR_TEXT, then raise FORM_TRIGGER_FAILURE to halt form processing.

---
**Decision Points**

DP-001

Condition: rep_server retrieved from EH_REPORTS for the given p_principal and p_app_id is NOT NULL.

TRUE: Use the report-server path - delegate CSV generation to the remote procedure sp_csv_report_generate via the database link, move the file on the server, then transfer and open it on the client.

FALSE: Use the local path - build the CSV in-memory using a Forms record group populated from p_query, write it to the server file system, then transfer and open it on the client.

---

DP-002

Condition: p_file_name IS NULL (evaluated in both the report-server path and the local path).

TRUE: Prompt the user with a file-save dialog (WEBUTIL.FILE_SAVE_DIALOG) to obtain the destination file name.

FALSE: Use the value supplied in p_file_name as the destination file name.

---

DP-003

Condition: The resolved FILENAME contains a space character within its folder path (INSTR(FILENAME, ' ') > 0).

TRUE: Override FILENAME to place the file directly on 'C:\' using only the base file name, and display an informational message advising the user of the path change.

FALSE: Retain the original FILENAME path without modification.

---

DP-004

Condition: The record group named 'DataRecordSet' already exists (WEBUTIL.ID_NULL returns FALSE for rg_id) - evaluated only in the local path.

TRUE: Delete the existing record group before creating a new one from p_query.

FALSE: Proceed directly to creating the new record group from p_query.

---

DP-005

Condition: The file transfer to the client via WEBUTIL.URL_TO_CLIENT returns FALSE (file_transfer_bool is FALSE) - evaluated in both paths.

TRUE: Display a 'File Transfer failed' message and pause form execution.

FALSE: Proceed to open the file on the client desktop via WEBUTIL.HOST.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report server to be used is determined by the combination of p_principal and p_app_id; both values must match a row in EH_REPORTS for the report-server path to be activated. If no match exists, the procedure falls back to local record-group-based file generation.
- BR-002 - The output file name is always suffixed with '.csv' in the report-server path, regardless of whether the name was supplied by the caller or obtained via the file-save dialog.
- BR-003 - File paths containing spaces in any folder name are not permitted. When spaces are detected, the file is automatically redirected to the root of the C drive ('C:\') using only the base file name, and the user is notified.
- BR-004 - In the local path, any pre-existing Forms record group named 'DataRecordSet' must be deleted before a new record group is created from the supplied query, ensuring no stale data is included in the output.
- BR-005 - The server-side URL prefix used to construct the download path is read at runtime from the configuration file /reports/DMS/excelpath.txt; this file must be accessible and contain a valid URL on the first line.
- BR-006 - A successful client-side file transfer via WEBUTIL.URL_TO_CLIENT is required before the file is opened on the client desktop. If the transfer fails, the procedure alerts the user and does not attempt to open the file.
- BR-007 - Any unhandled exception terminates the procedure by raising FORM_TRIGGER_FAILURE, preventing further form processing and surfacing the Oracle error code and text to the user.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-090 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output mechanism by delegating to the external D2KWUTIL library function D2KWUTIL_DEBUGSTRING. It accepts a text string, appends a newline character, registers the external function call through the WIN_API framework, and dispatches the formatted string to the debug output channel. The procedure enforces availability of the WIN_API layer before attempting the call and surfaces structured error messages if the API is unavailable or an unexpected runtime fault occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter Text (VARCHAR2) and initialise the local buffer vcBuff1 by appending a newline character (CHR(10)) to Text.
- Step 2 - Evaluate whether the WIN_API layer is active by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for D2KWUTIL_DEBUGSTRING against the debug-string function handle (iDebugString) using REGISTER_FUNCTION_CALL, specifying the function name 'd2kwutil_DebugString', a NULL module reference, and the '*CHAR' parameter type descriptor.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the function handle obtained from WIN_API.FunctionHandle(iDebugString) and the formatted buffer vcBuff1, to write the debug string to the external debug output.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to abort processing.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception to the caller.
- Step 7 - On any other exception, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message formed by concatenating WIN_API.UError with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: The procedure registers the external function call via REGISTER_FUNCTION_CALL and dispatches the debug string to D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: The WIN_API.NOT_AVAILABLE exception is raised, bypassing the external call entirely.

DP-002

Condition: The exception raised is WIN_API.NOT_AVAILABLE.

TRUE: ADD_ERROR is called with the procedure identifier 'WinDebug' and the WIN_API.NoAPI error code; the exception is then re-raised.

FALSE: The WHEN OTHERS handler is invoked; ADD_ERROR is called with the procedure identifier 'WinDebug' and a composite message combining WIN_API.UError and the output of ADD_EXTERNAL_ERRORS; the exception is then re-raised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API layer must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to write a debug string; if the layer is unavailable the operation is rejected and WIN_API.NOT_AVAILABLE is raised.
- BR-002 - Every debug string dispatched to the external library must be terminated with a newline character (CHR(10)); this formatting is applied unconditionally to the input text before the external call.
- BR-003 - The external function D2KWUTIL_DEBUGSTRING must be formally registered via REGISTER_FUNCTION_CALL, using the handle iDebugString, the literal function name 'd2kwutil_DebugString', and the '*CHAR' type descriptor, before each invocation.
- BR-004 - When the WIN_API layer is unavailable, the error must be recorded through ADD_ERROR using the WIN_API.NoAPI error code and the originating procedure name 'WinDebug', and the exception must be propagated to the caller.
- BR-005 - For all other runtime exceptions, the error must be recorded through ADD_ERROR using a composite message that combines WIN_API.UError with the supplementary detail returned by ADD_EXTERNAL_ERRORS, and the exception must be propagated to the caller.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

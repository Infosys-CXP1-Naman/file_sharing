# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - No-Show AMC Enquiry - VH_AMC_ENQ
    - Dealer Location - MULDMS.AM_DEALER_LOC
    - AMC Package Description - VM_AMC_PKG (INFERRED - referenced in inline SQL)
    - Vehicle Master - GM_VIN
    - Enquiry Status List - MULDMS.AM_LIST_RANGE
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (User - report request entry)
    - Session and Working Fields (System - auto-populated)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT
    - SP-002 - VIEW_EXCEL_REP
    - SP-003 - GENERAL.ASK_CONFIRM
    - SP-004 - GENERAL.CHECK_NULL
    - SP-005 - GENERAL.DISP_TEXT
    - SP-006 - GENERAL.RAISE_ERROR
    - SP-007 - SF_COPYRIGHT_DECLARATION
    - SP-008 - SF_GET_DEALER_NAME

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_NSC_SUMM - Business Requirements Document |
| Form Module Name | VR_NSC_SUMM |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_nsc_summ No Show Customer Summary form, its purpose, and roles referenced in the module.*

The **vr_nsc_summ** Oracle Forms module is the **No Show Customer Summary** screen. It enables authorised users to retrieve and export AMC (Annual Maintenance Contract) enquiry records for customers who did not show up for scheduled service appointments. The user enters a date range and a dealer code, then submits the criteria either to export a CSV file containing the matching enquiry records or to generate and view a formatted PDF report. Before submission, mandatory fields are validated - the system confirms that From Date, To Date, and Dealer Code are all entered and that the date range does not exceed 30 days for the CSV export. The resulting data covers enquiry reference, customer details, contact information, vehicle details, package information, enquiry age, and enquiry status for the selected period and location.

### Key Stakeholders

*Who uses vr_nsc_summ*

| Stakeholder | Role |
| :--- | :--- |
| **Service Operations User** | INFERRED - Primary interactive user of the form. Enters the date range, dealer, and location criteria, then generates either the CSV export or the PDF report for the selected period. |
| **Dealer / Location Management** | INFERRED - Represented through the Dealer Code and Location Code filter criteria entered on the form; the report data is scoped to the selected dealer and location. |
| **Customer (AMC enquiry subject)** | AMC enquiry customer whose no-show details are captured in the underlying data and surfaced in the report; the customer does not interact with the form directly. |

---

---

## 3. System Context

*Describes the vr_nsc_summ module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_nsc_summ** module is the **No Show Customer Summary** screen within the Dealer Management System (DMS). It provides service operations users with a targeted reporting tool for AMC (Annual Maintenance Contract) enquiries where the customer did not arrive for the scheduled service. Users specify a date range, dealer code, and location, then retrieve the matching no-show enquiry records either as a downloadable CSV file or as a formatted PDF report.

**System purpose:** Enable authorised users to filter, export, and report on AMC no-show enquiry records for a specified dealer, location, and date range - as implemented in the vr_nsc_summ Oracle Forms module.

**In scope:**

- Entry of report criteria: From Date, To Date, Dealer Code, and Location Code
- Date range validation ensuring From Date is present, To Date is not earlier than From Date, and the range does not exceed 30 days for CSV export
- Mandatory field validation before report generation
- Dynamic CSV export of no-show AMC enquiry data including customer, vehicle, package, and enquiry status details
- PDF report generation and browser-based display using the vr_nsc_summ report definition
- Form-level error handling for invalid date formats, non-numeric input, and concurrent update conflicts
- Copyright declaration display at form initialisation and form clear

**Process Name:** No Show Customer Summary Reporting

**Process Owner:** INFERRED - Service Operations Manager

**Process Objective:** Allow service operations users to enter a dealer, location, and date range, validate the criteria, and generate a no-show AMC enquiry report (CSV or PDF) for review and follow-up.

**Process Trigger:** A service operations user opens the No Show Customer Summary screen to review customers who missed scheduled AMC service appointments within a given period.

**Process Flow:**

The complete no show customer summary reporting process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The No Show Customer Summary screen is launched.
         The copyright declaration is displayed and the form title is set.
         Application logging is started if enabled.

STEP 2 ── FROM DATE ENTRY
         The user enters the report start date in DD/MM/YYYY format.
         The system automatically sets To Date to From Date plus 30 days.

STEP 3 ── FROM DATE VALIDATION
         The system checks that From Date is not empty.
         If empty, an error message is displayed and the user must supply a value.

STEP 4 ── TO DATE ENTRY
         The user reviews or adjusts the To Date (defaulted from From Date + 30).
         The system confirms the date is not earlier than From Date.

STEP 5 ── TO DATE VALIDATION
         The system checks that To Date is not empty and is not earlier than From Date.
         If either check fails, an error message is displayed and the user must correct the value.

STEP 6 ── DEALER ENTRY
         The user enters the dealer name or code to filter enquiry records.
         The system validates that the Dealer field is not empty before the user can proceed.

STEP 7 ── DEALER CODE AND LOCATION CODE ENTRY
         The user enters the dealer code and location code to further scope the report.
         These values are used as filter parameters in both the CSV query and the PDF report.

STEP 8 ── CSV EXPORT - SUBMIT2 BUTTON
         ├── User clicks the SUBMIT2 (CSV Export) button.
         └── The system validates From Date is not null and date range does not exceed 30 days.
             If validation fails, an error message is displayed and the export is stopped.

STEP 9 ── DYNAMIC QUERY CONSTRUCTION (CSV PATH)
         The system builds a dynamic SQL query filtered by location, date range, principal group,
         and dealer, selecting AMC enquiry records with open status from the enquiry, package,
         and vehicle tables.

STEP 10 ── CSV FILE GENERATION
          The system populates a record group from the query, writes the results as a
          comma-separated file including header rows for location, date range, and column labels,
          and saves the file to the application server.

STEP 11 ── CSV FILE DISPLAY
          The generated CSV file is opened in the user's browser for download or review.

STEP 12 ── PDF REPORT - SUBMIT BUTTON
          ├── User clicks the SUBMIT button.
          └── The system validates that From Date, To Date, and Dealer Code are all entered.
              If any mandatory field is missing, an error message is displayed.

STEP 13 ── DATE RANGE RE-VALIDATION (PDF PATH)
          The system confirms To Date is not earlier than From Date before proceeding.
          If the check fails, the user is directed back to the From Date field.

STEP 14 ── REPORT PARAMETERS SET
          The system configures the vr_nsc_summ report with principal code, From Date, To Date,
          location code, and dealer code as runtime parameters.

STEP 15 ── PDF REPORT SUBMISSION
          The report is submitted to the report server and the resulting PDF is displayed
          in the browser for the user to review.

STEP 16 ── FORM CLEAR (KEY-CLRFRM)
          The user may clear the form at any point; all fields are reset,
          the copyright declaration is repopulated, and the form title is restored.

STEP 17 ── FORM EXIT
          The user closes the screen; session application info is cleared.
```

**Major process interactions:**

- **AMC enquiry data** - the form queries open AMC enquiry records (vehicle, customer, package, and status details) from the underlying enquiry and related tables to populate the report
- **Dealer location master** - dealer location descriptions are retrieved to enrich the exported data with readable location names
- **AMC status list** - enquiry status codes are resolved to readable descriptions from the status list reference data
- **Vehicle inventory** - vehicle VIN records are joined to provide vehicle details on the report
- **AMC package master** - package codes and descriptions are sourced from the package reference table
- **Report server** - the PDF report is submitted to and retrieved from the configured Oracle Reports server
- **Application server file system** - CSV export files are written to and served from the application server

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Session Instrumentation

**Business Description:**
When the No-Show Customer Summary screen is opened, the system prepares the session for use in two phases. First, before the form opens, the system optionally starts a performance timer and registers the screen context in the database session so monitoring tools can identify the active module. Second, once the form loads, the system maximises the application and form windows, pre-populates the dealer code, dealer name, and location code from the user's session context, populates the copyright declaration, navigates focus to the start date field, and sets the screen title to "No Show Customer Search Screen". Together these steps ensure the screen opens fully configured and ready for the user to enter report criteria.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has authenticated and launched the No-Show Customer Summary screen from the application menu.
- Session-level globals for dealer group, dealer code, and location code are set by the calling application.

**Main Flow:**

**Step 1 - Performance timer started when logging is active**
Before the screen opens, if application logging has been switched on for the current session (GLOBAL.app_log = 'Y'), the system starts a performance timer. This allows response-time monitoring to capture how long the form takes to become ready for use.

**Step 2 - Session context registered for monitoring**
The system registers the current screen's module identifier and action label (module name: `enroll_pend`) in the database session context. This allows database administrators and monitoring tools to identify which application module the user is running at any point in time.

**Step 3 - Application and form windows maximised on load**
When the form instance is created, the system maximises both the main application window (FORMS_MDI_WINDOW) and the form's main working window (WN_MAIN) so the screen occupies the full display area immediately on open.

**Step 4 - Dealer code and dealer name pre-populated from session context**
The system reads the dealer code stored in the session global (GLOBAL.DEALER) and sets the Dealer Code field accordingly. It then calls the dealer name lookup function, passing the parent group, dealer code, and location code from the session globals, to retrieve and display the matching dealer name in the Dealer field.

*Procedures called:*
- **SF_GET_DEALER_NAME** - retrieves the dealer name for the given parent group, dealer code, and location code from the application reference data and returns it for display on screen.
    * **Step 1** - Accept the parent group identifier, dealer code, and location code.
    * **Step 2** - Look up the corresponding dealer name in the reference data.
    * **Step 3** - Return the dealer name to be displayed in the Dealer field on screen.

**Step 5 - Copyright declaration populated**
The system calls the copyright declaration function and writes the returned copyright text into the copyright display field on the screen.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-006](#SP-006--SF_COPYRIGHT_DECLARATION)) - retrieves the current copyright declaration text and returns it for display on screen.
    * **Step 1** - Retrieve the standard copyright declaration text from the system.
    * **Step 2** - Return the copyright text to be displayed in the copyright declaration field.

**Step 6 - Location code pre-populated and focus set to start date**
The system copies the location code from the session global (GLOBAL.LOC_CD) into the Location Code field and moves input focus to the From Date field so the user can begin entering filter criteria without additional navigation.

**Step 7 - Screen title set to standard label**
The system sets the screen title to *"No Show Customer Search Screen"*, confirming to the user which screen is open.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Code (`DEALER_CD`) | Auto-populated | Character | N/A | Session global GLOBAL.DEALER | Dealer code from session context | Form open | System-set only; pre-populated from session on open | N/A |
| Dealer Name (`DEALER`) | Auto-populated | Character | N/A | SF_GET_DEALER_NAME lookup | Dealer name matched by parent group, dealer code, and location | Form open | System-set only; retrieved from reference data on open | N/A |
| Location Code (`LOC_CD`) | Auto-populated | Character | N/A | Session global GLOBAL.LOC_CD | Location code from session context | Form open | System-set only; pre-populated from session on open | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Character | N/A | SF_COPYRIGHT_DECLARATION | Current copyright text | Form open | System-set only; populated on every form open | N/A |
| Screen Title (`TITLE`) | Auto-populated | Character | N/A | N/A | Fixed value: "No Show Customer Search Screen" | Form open | System-set only; set to standard label on every form open | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** From Date Entry, Mandatory Validation, and To Date Auto-Population

**Business Description:**
When the user enters the start date for the report period, the system enforces that the field is not left blank and automatically sets the end date to thirty days after the start date. This ensures the report period is pre-populated with a standard thirty-day window, reducing the effort needed to configure the date range.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open and the user is entering filter criteria.

**Main Flow:**

**Step 1 - From Date entered and validated as not blank**
The user enters the start date for the reporting period. When the user moves focus away from the start date field, the system checks that a date has been entered. If the field is blank, the user is shown an error and must supply a valid date before proceeding.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the start date has not been entered; the trigger then stops further processing until the user corrects the field.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not blank | From Date mandatory check - GENERAL.DISP_TEXT [SP-004] | When the user moves focus away from the From Date field | Ensures a start date is always provided before the reporting period can be configured | *"Enter From Date"* is shown; the trigger stops processing and the user must enter a date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - From Date field left empty - *"Enter From Date"*; processing stops and the user must enter the start date.

**Step 2 - To Date automatically set to thirty days after the From Date**
Once a valid start date is entered, the system automatically populates the end date field with a date thirty calendar days later. The user can still override the end date, but a default thirty-day window is provided as a convenience.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) From Date is blank when focus leaves the field: *"Enter From Date"* is displayed and the trigger stops; the user must enter a valid start date before the system will auto-populate the To Date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`FROM_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | Screen is open | Must not be blank | *"Enter From Date"* - processing stops |
| To Date (`TO_DATE`) | Auto-populated | Date | DD/MM/YYYY | N/A | Calculated as From Date + 30 days | From Date entered | Auto-set to From Date + 30 days | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** To Date Mandatory and Date-Range Validation

**Business Description:**
When the user enters the end date for the reporting period and moves to the next field, the system validates that the field is not blank and that the end date falls on or after the start date. These checks ensure the report period is logically valid before the user proceeds to run the report.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- The user has entered or moved past the To Date field.

**Main Flow:**

**Step 1 - To Date checked as not blank**
When the user moves focus away from the end date field, the system first checks that a date has been entered. If the field is blank, the user is shown an error and processing stops until a date is provided.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the end date has not been entered; the trigger then stops further processing until the user corrects the field.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not blank | To Date mandatory check - GENERAL.DISP_TEXT [SP-004] | When the user moves focus away from the To Date field | Ensures an end date is always provided before the report period can be submitted | *"Enter to date"* is shown; processing stops and the user must enter an end date |
| To Date is not before From Date | Date order check - GENERAL.DISP_TEXT [SP-004] | When the user moves focus away from the To Date field (after blank check passes) | Ensures the end date is the same as or later than the start date so the report covers a valid period | *"To Date should be greater than From date !"* is shown; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - To Date field left empty - *"Enter to date"*; processing stops and the user must enter an end date.
- **BR-003-ES-02** - To Date is earlier than From Date - *"To Date should be greater than From date !"*; processing stops and the user must correct the end date.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) To Date is blank: *"Enter to date"* is displayed and the trigger stops; the user must enter a valid end date.
- **BR-003-AF-02** - (from Step 1) To Date is earlier than From Date: *"To Date should be greater than From date !"* is displayed and the trigger stops; the user must correct the end date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`TO_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | Screen is open | Must not be blank; must be on or after the From Date | *"Enter to date"* or *"To Date should be greater than From date !"* - processing stops |
| From Date (`FROM_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | Screen is open | Read by this validation to compare against To Date | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Dealer Name Mandatory Validation

**Business Description:**
When the user moves past the Dealer Name field without entering a value, the system alerts the user that the Dealer Name is a required field and prevents further navigation until a value is supplied. This ensures the report can always be associated with a specific dealership.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- The user has moved focus away from the Dealer Name field.

**Main Flow:**

**Step 1 - Dealer Name checked as not blank**
When the user moves focus away from the Dealer Name field, the system checks whether a dealer name has been entered. If the field is blank, the system calls the standard null-check routine, which displays an appropriate error message to the user, and processing stops until a valid value is entered.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-003](#SP-003--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - checks whether a required field has been left blank; if the field is empty, displays a descriptive error message telling the user which field needs to be filled in and stops further processing.
    * **Step 1** - Receive the field value and the field's business label from the calling trigger.
    * **Step 2** - Check whether the supplied value is empty or absent.
    * **Step 3** - If the value is absent, display a message indicating that the labelled field (Dealer) must be provided, and signal that the trigger should stop.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Name is not blank | Dealer mandatory check - GENERAL.CHECK_NULL [SP-003] | When the user moves focus away from the Dealer Name field | Ensures a dealership is always selected so the report is always filtered to a specific dealer | Error message displayed for the "Dealer" field; processing stops and the user must enter a dealer name |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Dealer Name field left empty - the system displays a mandatory-field error for the Dealer field; processing stops and the user must enter the dealer name.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) Dealer Name is blank when focus leaves the field: the standard null-check error for the "Dealer" label is displayed and the trigger stops; the user must enter a valid dealer name before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer Name (`DEALER`) | Mandatory | Character | N/A | N/A | N/A | Screen is open | Must not be blank | Mandatory-field error for "Dealer" is displayed; processing stops |

---

---

#### Requirement ID: BR-005

**Requirement Title:** No-Show Customer Summary Excel Report Generation

**Business Description:**
When the user clicks the Submit Report button on the search screen, the system validates the date range entered, builds a detailed comma-separated value (CSV) data extract of all open no-show enquiries within the specified period and location, and opens the resulting file in the browser for download. The report covers customer and vehicle details, enquiry package information, and enquiry status for all outstanding no-show customers within the selected filter criteria.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- The user has entered a start date, an end date, and a location or dealer filter.

**Main Flow:**

**Step 1 - From Date validated as not blank**
When the user clicks the first Submit Report button, the system immediately checks that the start date has been entered. If it is missing, an error is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the start date has not been entered; the button action is stopped.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not blank | From Date mandatory check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the first Submit Report button | Ensures a start date is provided before the extract is attempted | *"Enter From Date"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - From Date is blank - *"Enter From Date"*; the submit action stops and the user must enter a start date.

**Step 2 - Date range validated: To Date must not be before From Date**
The system checks that the end date is not earlier than the start date. If the end date precedes the start date, an error is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the end date is earlier than the start date; the button action is stopped.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not before From Date | Date order check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the first Submit Report button (after From Date check passes) | Prevents a logically invalid date range from producing an empty or misleading extract | *"To Date could not be Less than From Date!"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-02** - To Date is earlier than From Date - *"To Date could not be Less than From Date!"*; the submit action stops and the user must correct the end date.

**Step 3 - Date range validated: period must not exceed thirty days**
The system checks that the reporting period does not span more than thirty calendar days. If the end date is more than thirty days after the start date, an error is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the date range exceeds thirty days; the button action is stopped.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range does not exceed 30 days | 30-day period limit check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the first Submit Report button (after date order check passes) | Limits the extract to a manageable period to prevent excessively large output files | *"Report Could Not Be Generate More Than 30 days !"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-03** - Date range exceeds thirty days - *"Report Could Not Be Generate More Than 30 days !"*; the submit action stops and the user must reduce the date range to thirty days or fewer.

**Step 4 - Output filename constructed from session context**
When all validations pass, the system constructs a unique output filename by combining the logged-in user's identifier, the selected location code, and the current date and time. This ensures each extract file has a unique, traceable name.

**Step 5 - No-show enquiry data queried and formatted for CSV export**
The system builds a SQL query that retrieves open no-show customer enquiries from the system. The query is filtered by the selected location (or all locations if no specific location is chosen), the entered date range, the current dealership group, and the manufacturer principal. For each matching enquiry the query returns: location, enquiry number, enquiry date, customer name and address details, mobile number, email, vehicle model, VIN, registration number, current odometer reading, vehicle invoice date, engine number, chassis number, enquired package code and description, enquiry age in days, and enquiry status. The query result is stored as an internal working value on the screen.

**Step 6 - CSV file generated and opened in the browser**
The system passes the constructed query and filename to the Excel report generation routine, which executes the query, writes the results to a file on the report server, and opens the file in a new browser window for the user to download or view.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-002](#SP-002--VIEW_EXCEL_REP)) - VIEW_EXCEL_REP - executes the no-show enquiry query, writes the rows to a CSV file on the server, and opens the file in the browser for the user to download; handles oversized result sets and file path issues.
    * **Step 1** - Receive the target filename, the report query, and the column name to extract from the result.
    * **Step 2** - If the target filename contains spaces in the path, save the file to the default drive root instead and inform the user that the specified path could not be used.
    * **Step 3** - Look up the server-side output directory path from the configuration file on the report server.
    * **Step 4** - Execute the supplied query and load the results into a temporary in-memory data set.
    * **Step 5** - If the result set exceeds 65,535 rows, inform the user that the output will be truncated to that limit.
    * **Step 6** - Write each row of the result set as a line in the output CSV file on the server.
    * **Step 7** - Open the completed file in a new browser window so the user can download or view it.
    * **Step 8** - If any error occurs during file writing or browser opening, display the error code and error text and stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces | File path check - VIEW_EXCEL_REP [SP-002] | When the first Submit Report button action reaches the file-generation step | Ensures the output file can be saved correctly; paths with spaces are redirected to the C drive root | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - file is saved to C drive instead |
| Result set size limit | Row count check - VIEW_EXCEL_REP [SP-002] | During file generation, after the query is executed | Prevents the output file from exceeding the maximum Excel row limit | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - output is capped at 65,535 rows |
| No errors during file generation and browser open | Exception handler - VIEW_EXCEL_REP [SP-002] | If any unexpected error occurs during file generation | Ensures the user is informed if the file cannot be produced or opened | The error code and error text are displayed as *"Error  -"* followed by the error code and error text; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-01** - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - the file is redirected to the C drive root and generation continues.
- **BR-005-IC-02** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - the output file is capped at 65,535 rows; the user is informed before the file is opened.
- **BR-005-ES-04** - An unexpected error occurs during file generation - the error code and error text are shown as *"Error  -"* followed by the system error code and error text; processing stops.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 1) From Date is blank: *"Enter From Date"* is displayed; submit action stops.
- **BR-005-AF-02** - (from Step 2) To Date is earlier than From Date: *"To Date could not be Less than From Date!"* is displayed; submit action stops.
- **BR-005-AF-03** - (from Step 3) Date range exceeds thirty days: *"Report Could Not Be Generate More Than 30 days !"* is displayed; submit action stops.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`FROM_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | Screen is open | Must not be blank | *"Enter From Date"* - submit action stops |
| To Date (`TO_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | From Date entered | Must not be before From Date; range must not exceed 30 days | *"To Date could not be Less than From Date!"* or *"Report Could Not Be Generate More Than 30 days !"* - submit action stops |
| Location Code (`LOC_CD`) | Optional | Character | N/A | N/A | Location code or "ALL" for all locations | Screen is open | Used to filter the extract; if not specified the extract covers all locations | N/A |
| Query Working Field (`T1`) | Auto-populated | Character | Up to 10000 characters | N/A | SQL query string constructed at runtime | Date and location filters entered | System-set only; holds the dynamically built report query | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** No-Show Customer Summary PDF Report Generation

**Business Description:**
When the user clicks the main Submit Report button after entering the required filter criteria, the system validates that all mandatory fields have been completed and that the date range is valid, then generates and opens a PDF version of the No-Show Customer Summary report. The PDF report is produced by the reporting server and opened directly in the browser, allowing the user to view or save the formatted summary.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- The user has entered values in the filter fields and clicks the main Submit Report button.

**Main Flow:**

**Step 1 - All mandatory fields checked together**
When the user clicks the main Submit Report button, the system first checks that the start date, end date, and dealer code fields are all populated. If any one of these is missing, an error message is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when one or more mandatory fields are empty; the button action is stopped.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date, To Date, and Dealer Code are all populated | Combined mandatory-fields check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the main Submit Report button | Ensures no required filter is missing before the report run begins | *"Please Enter All Mandatory Fields"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - One or more of the start date, end date, or dealer code fields are blank - *"Please Enter All Mandatory Fields"*; the submit action stops and the user must complete the missing fields.

**Step 2 - From Date individually validated as not blank**
The system performs an additional individual check that the start date is not blank. If it is missing, an error is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the start date is not entered.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not blank (individual check) | From Date individual mandatory check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the main Submit Report button (after the combined check passes) | Second confirmation that the start date is present before the date-order check runs | *"Enter From Date"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-02** - From Date field is blank at the individual check - *"Enter From Date"*; the submit action stops.

**Step 3 - Date range validated: To Date must not be before From Date**
The system checks that the end date is not earlier than the start date. If the end date precedes the start date, an error is shown and the submit action is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a labelled error message to the user when the end date is earlier than the start date; the button action is stopped.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date is not before From Date | Date order check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the main Submit Report button (after all mandatory-field checks pass) | Ensures the reporting period is logically valid before the report is run | *"To Date could not be Less than From Date!"* is shown; the submit action stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-03** - To Date is earlier than From Date - *"To Date could not be Less than From Date!"*; the submit action stops and the user must correct the end date.

**Step 4 - PDF report generated and opened in the browser**
Once all validations pass, the system calls the report generation routine. The routine locates the No-Show Customer Summary report object, configures it with the selected filters (manufacturer principal, start date, end date, location code, and dealer code), submits the report to the reporting server for PDF rendering, and opens the resulting PDF in a new browser window. If an unexpected error occurs during this step, the database error text is shown to the user as a system message.

*Procedures called:*
- **CALL_REPORT** ([SP-001](#SP-001--CALL_REPORT)) - CALL_REPORT - locates the No-Show Customer Summary report object, applies the user's filter parameters (principal, date range, location, and dealer), runs the report on the configured report server in PDF format, and opens the rendered PDF in the browser.
    * **Step 1** - Locate the report object registered under the name "REPORT_CALL" in the current form session.
    * **Step 2** - Set the report filename to the No-Show Customer Summary report ("vr_nsc_summ").
    * **Step 3** - Configure the report output format as PDF and apply the filter parameters: manufacturer principal, start date, end date (end date is shifted forward by one day to include the full final day), location code, and dealer code.
    * **Step 4** - Set the report server to the currently configured report server for this session.
    * **Step 5** - Submit the report to the report server and receive the job identifier for the submitted run.
    * **Step 6** - Open the completed PDF report in a new browser window using the report server job identifier.

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-04** - An unexpected error occurs while running the report - the database error text is displayed as a system message; the report is not produced.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) One or more mandatory fields are blank: *"Please Enter All Mandatory Fields"* is displayed; submit action stops.
- **BR-006-AF-02** - (from Step 2) From Date is individually found blank: *"Enter From Date"* is displayed; submit action stops.
- **BR-006-AF-03** - (from Step 3) To Date is earlier than From Date: *"To Date could not be Less than From Date!"* is displayed; submit action stops.
- **BR-006-AF-04** - (from Step 4) An unexpected error occurs during report generation: the database error text is shown as a system message; the report is not produced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`FROM_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | Screen is open | Must not be blank | *"Please Enter All Mandatory Fields"* or *"Enter From Date"* - submit action stops |
| To Date (`TO_DATE`) | Mandatory | Date | DD/MM/YYYY | N/A | N/A | From Date entered | Must not be blank; must be on or after From Date | *"Please Enter All Mandatory Fields"* or *"To Date could not be Less than From Date!"* - submit action stops |
| Dealer Code (`DEALER_CD`) | Mandatory | Character | N/A | N/A | N/A | Screen is open | Must not be blank | *"Please Enter All Mandatory Fields"* - submit action stops |
| Location Code (`LOC_CD`) | Optional | Character | N/A | N/A | N/A | Screen is open | Passed to the report as a filter; not individually validated at submit | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Form Exit Without Saving

**Business Description:**
When the user presses the Exit key, the system closes the No-Show Customer Summary screen immediately without checking for or saving any unsaved changes. The session monitoring context is also cleared so that database monitoring tools no longer show this screen as active for the user's session.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.

**Main Flow:**

**Step 1 - Screen closed without saving changes**
The user presses the Exit key. The system closes the screen immediately, discarding any entries or changes the user may have made, and returns the user to the previous application context. No save or validation of field values is performed on exit.

**Step 2 - Session monitoring context cleared**
After closing the screen, the system clears the session context information (module and action labels) that was registered when the screen was opened. This ensures database session monitoring tools accurately reflect that the user is no longer on this screen.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Form Clear, Window Maximise, and Copyright Reset

**Business Description:**
When the user presses the Clear Form key, clicks the Save toolbar button, or clicks the Cancel toolbar button, the system clears all entered values from the screen without saving. When the Cancel toolbar button is used and the form contains unsaved changes, the user is asked to confirm that entered data will be discarded before the screen is cleared. For the Clear Form key action, the system also maximises the application window, refreshes the copyright declaration, and resets the screen title to its standard label. Together these actions restore the screen to a clean, ready state for fresh input.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.

**Main Flow:**

**Step 1 - All fields cleared without saving (via Clear Form key)**
The user presses the Clear Form key. The system immediately clears all entered values from the screen without performing any validation or saving any changes.

**Step 2 - Application window maximised**
The system maximises both the main application window and the form's main working window so that the screen occupies the full display area.

**Step 3 - Copyright declaration refreshed**
The system calls the copyright declaration function to retrieve the current copyright text and writes it into the copyright display area on the screen.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-006](#SP-006--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - retrieves the current copyright declaration text and returns it to be displayed on the screen.
    * **Step 1** - Retrieve the standard copyright declaration text from the system.
    * **Step 2** - Return the copyright text to the calling trigger so it can be assigned to the copyright display area.

**Step 4 - Screen title reset to standard label**
The system sets the screen title back to the standard label "No Show Customer Search Screen", ensuring the heading correctly identifies the screen after the clear.

**Step 5 - Save toolbar button clears the form**
When the user clicks the Save toolbar button, the system clears the form in the same way as the Clear Form key action (Step 1). On this reporting screen the Save button does not commit data; it triggers a full form clear instead, discarding any entered values.

**Step 6 - Cancel toolbar button clears the form, with confirmation when changes are pending**
When the user clicks the Cancel toolbar button and the form contains unsaved changes, the system shows a confirmation prompt before clearing. If the user confirms, the form is cleared. If no changes are pending, the form is cleared immediately without prompting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Form has unsaved changes | Form status check - FT_CANCEL | When the user clicks the Cancel toolbar button | Prevents the user from accidentally discarding data they have entered | *"Entered data will not be Saved"* confirmation prompt shown; form is cleared only if the user confirms |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-IC-01** - User clicks Cancel toolbar button while the form contains unsaved changes - *"Entered data will not be Saved"* confirmation shown; if the user confirms, the form is cleared; if the user does not confirm, the screen remains open with the entered data intact.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 6) User clicks Cancel toolbar button when no changes are pending: the form is cleared immediately without a confirmation prompt.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Character | N/A | N/A | Retrieved from the copyright declaration function | Screen cleared | System-set only; refreshed on every form clear | N/A |
| Screen Title (`TITLE`) | Auto-populated | Character | N/A | N/A | Fixed value: "No Show Customer Search Screen" | Screen cleared | System-set only; reset to the standard label on every form clear | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Form-Level Error Interception and User-Friendly Messaging

**Business Description:**
Whenever a system or database error occurs anywhere on the No-Show Customer Summary screen, the form-level error handler intercepts the error and translates it into a plain, user-friendly message where applicable. Specific error conditions are mapped to descriptive guidance (such as date format errors or data-type errors), a child-record integrity error raises a pre-defined error code, concurrent-update conflicts are reported clearly with a rollback, and any other database error is presented with its database message text. Informational form messages that do not require user action are silently suppressed.

**Actors:** System (automatic on any error event)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- A system or database error has occurred during a user action or background processing step.

**Main Flow:**

**Step 1 - Invalid date error intercepted and user notified**
If a date entered on the screen is not a valid calendar date (error code 50004), the system displays a clear message telling the user the date is invalid and stops processing so the user can correct it.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"Entered Date is not valid Date"* to the user; the trigger stops further processing.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value is a valid calendar date | Invalid date check (error 50004) - GENERAL.DISP_TEXT [SP-004] | When any date entry on the screen produces a date-validity error | Replaces a cryptic system error with a readable message so the user knows the date they entered is not valid | *"Entered Date is not valid Date"* is displayed; the trigger stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Date value is not a valid calendar date - *"Entered Date is not valid Date"*; processing stops.

**Step 2 - Date format error intercepted and user notified**
If a date is entered in the wrong format (error codes 50025 or 50026), the system displays a message instructing the user to enter the date in the required DD-MM-YYYY format and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"Enter the Date in the proper format (DD-MM-YYYY)"* to the user.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date is entered in the correct format | Date format check (errors 50025, 50026) - GENERAL.DISP_TEXT [SP-004] | When any date entry on the screen produces a date-format error | Guides the user to enter dates in the supported DD-MM-YYYY format | *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-02** - Date entered in an incorrect format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; processing stops.

**Step 3 - Non-numeric or special-character entry intercepted**
If the user enters letters or special characters in a field that expects a numeric value (error codes 40209 or 50016), the system displays a message instructing the user to enter a numeric value only and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message *"Characters/Special Characters are not allowed here, enter the numeric value"* to the user.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric field contains only numeric input | Non-numeric entry check (errors 40209, 50016) - GENERAL.DISP_TEXT [SP-004] | When a numeric field on the screen receives non-numeric input | Prevents invalid data from being entered into fields that require numeric values | *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-03** - Non-numeric input in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; processing stops.

**Step 4 - Other Forms field-level validation error passed through**
If a standard field-level validation error (error code 40207) occurs, the system displays the Forms error text associated with that error to the user and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the Forms error text for the specific error to the user.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Field-level validation passes | Forms validation error passthrough (error 40207) - GENERAL.DISP_TEXT [SP-004] | When a standard field-level validation error occurs anywhere on the screen | Displays the specific validation error text so the user understands what has failed | The Forms error text for that field is displayed; processing stops |

**Step 5 - Child-record integrity constraint violation handled**
If a database child-record integrity error occurs (database error code -02292), the system raises a pre-defined application error code to present the appropriate standard error message to the user.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-005](#SP-005--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - raises a standard application-level error corresponding to the child-record integrity violation, so the user sees a consistent, pre-defined error message.
    * **Step 1** - Accept the application error code (E0088) to be raised.
    * **Step 2** - Look up the message text registered for that error code in the application's error catalogue.
    * **Step 3** - Display the corresponding error message to the user and stop processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Database child-record integrity constraint | Child-record integrity check (DB error -02292) - GENERAL.RAISE_ERROR [SP-005] | When a database action fails due to a child-record dependency constraint | Informs the user that the record cannot be changed because dependent child records exist | Standard application error E0088 is raised and its message is shown; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** - Database child-record integrity violation - standard application error E0088 displayed; processing stops.

**Step 6 - Concurrent-update conflict detected, changes rolled back**
If the system detects that a record has been updated by another user (error codes 40654, 40655, 40656, 40657, or 40659), it displays a clear message asking the user to re-query the record before making changes, rolls back any pending changes, and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the concurrent-update message to the user; a rollback is performed and the trigger stops.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record has not been updated by another user | Concurrent-update check (errors 40654, 40655, 40656, 40657, 40659) - GENERAL.DISP_TEXT [SP-004] | When an attempted save or update detects a concurrent modification | Prevents data loss by notifying the user of the conflict and rolling back the uncommitted change | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; changes are rolled back; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-05** - Record modified by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back; processing stops.

**Step 7 - Any other database error reported and changes rolled back**
For any other database error (SQL error code not equal to zero), the system displays the database error text and rolls back any pending changes before stopping processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error message text to the user; changes are rolled back and the trigger stops.
    * **Step 1** - Accept the database error message text and severity label.
    * **Step 2** - Display the database error text in the notification area so the user can see what went wrong.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No unhandled database errors remain | General database error handler (sqlcode <> 0) - GENERAL.DISP_TEXT [SP-004] | When any database operation on the screen raises an unhandled SQL error | Ensures the user is informed of any database error and that uncommitted changes are not silently lost | The database error text is displayed; changes are rolled back; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-06** - Unhandled database error - the database error text is displayed; changes are rolled back; processing stops.

**Step 8 - Informational messages silently suppressed**
If the error event carries error codes 40401 or 40405 (standard informational form messages), the system takes no action and the message is silently ignored. These codes do not represent errors requiring user attention.

---

---

#### Requirement ID: BR-010

**Requirement Title:** System Message Interception and Error-Format Display

**Business Description:**
Whenever the form generates specific informational or validation messages (error codes 40209 or 40207), the system intercepts them before they are displayed in the default style and re-presents them to the user in a standardised error-format that includes the message type, code, and text. This ensures consistency in how these messages appear to the user across the screen.

**Actors:** System (automatic on any message event)

**Preconditions:**
- The No-Show Customer Summary screen is open.
- The form has generated a message event with code 40209 or 40207.

**Main Flow:**

**Step 1 - System message intercepted and reformatted for display**
When the form's ON-MESSAGE trigger fires for a message with code 40209 or 40207, the system intercepts it, combines the message type abbreviation, code number, and the original message text into a single string, and displays it to the user as an error-level message. Processing is then stopped to prevent the default message display from also appearing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the reformatted message (combining message type, code, and text) to the user; the ON-MESSAGE trigger stops further processing to prevent duplicate display.
    * **Step 1** - Accept the combined message string (type, code, and text) and the severity label.
    * **Step 2** - Display the message in the appropriate notification area so the user can see the formatted error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Form message codes 40209 and 40207 are intercepted | ON-MESSAGE - message interception check (codes 40209, 40207) - GENERAL.DISP_TEXT [SP-004] | ON-MESSAGE fires when the form raises a message event with code 40209 or 40207 | Ensures these messages are presented in a consistent error format rather than the default system style | The reformatted message (type-code-text) is displayed; the default message is suppressed |

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1) Message code is neither 40209 nor 40207: the ON-MESSAGE trigger takes no action and the message is handled by the default form mechanism.

---

---

#### Requirement ID: BR-011

**Requirement Title:** Toolbar Operation Controls - Insert Blocked, Delete with Confirmation, and Save Commit Disabled

**Business Description:**
On the No-Show Customer Summary screen, the toolbar operation controls behave as follows. The Insert toolbar button is active but the insert operation is not permitted on this screen; when clicked, the system informs the user that the operation cannot be performed here. The Delete toolbar button is active and, when the user is positioned on the correct data block, the system asks the user to confirm before deleting the current record. The save and commit keyboard shortcut is disabled and has no effect. Together these controls enforce the data-access rules appropriate for this reporting screen.

**Actors:** User (report requester)

**Preconditions:**
- The No-Show Customer Summary screen is open.

**Main Flow:**

**Step 1 - Insert toolbar button clicked; operation blocked**
When the user clicks the Insert toolbar button and the button is enabled, the system immediately displays an error message informing the user that an insert operation cannot be performed on this screen. No data is inserted.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-004](#SP-004--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message to the user when an insert is attempted on this screen.
    * **Step 1** - Accept the message text and severity label to be shown to the user.
    * **Step 2** - Display the message in the appropriate notification area so the user can see what needs to be corrected.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert is not permitted on this screen | Insert-blocked check - GENERAL.DISP_TEXT [SP-004] | When the user clicks the Insert toolbar button | Prevents the user from inadvertently trying to add records on a screen that does not support insert | *"This Operation Cannot be performed Here"* is displayed; no insert takes place |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - User clicks Insert toolbar button - *"This Operation Cannot be performed Here"*; no insert is performed.

**Step 2 - Delete toolbar button clicked; user asked to confirm before record is removed**
When the user clicks the Delete toolbar button and the button is enabled, and the cursor is positioned on the main data block, the system temporarily suspends form-level validation and prompts the user to confirm the deletion. If the user confirms, the current record is deleted. After the delete attempt, form-level validation is re-enabled.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User confirms the delete action | Delete confirmation check - FT_DEL | When the user clicks the Delete toolbar button while positioned on the main data block | Prevents accidental deletion of records by requiring an explicit user confirmation | *"Are you sure to Delete?"* confirmation shown; if the user does not confirm, no deletion takes place |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-IC-01** - User clicks Delete toolbar button - *"Are you sure to Delete?"* confirmation shown; record is deleted only if the user confirms.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 2) User clicks Delete toolbar button but does not confirm: no deletion takes place and the form remains open with the record unchanged.

**Step 3 - Commit key pressed; no action taken (COMMENTED OUT / INACTIVE - does not execute)**
When the user presses the commit/save key, the trigger fires but executes no logic. The screen remains open and unchanged. This is an intentional design choice for this reporting screen.

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Date Mandatory on Validate | Validation | BR-002 | From Date field is left blank when the user moves focus away | Display *"Enter From Date"* and stop processing until the user enters a start date | Ensures every report request has a defined start date |
| BRC-002 | To Date Auto-Populated to 30 Days After From Date | Derivation | BR-002 | From Date has been successfully validated as not blank | Automatically set the To Date to thirty calendar days after the entered From Date | Reduces data entry effort by defaulting the report period to the standard thirty-day window |
| BRC-003 | To Date Mandatory on Validate | Validation | BR-003 | To Date field is left blank when the user moves focus away | Display *"Enter to date"* and stop processing until the user enters an end date | Ensures every report request has a defined end date |
| BRC-004 | To Date Must Not Be Before From Date (Validate) | Validation | BR-003 | To Date is earlier than From Date when the user moves focus away from the To Date field | Display *"To Date should be greater than From date !"* and stop processing until the user corrects the end date | Prevents logically invalid date ranges from reaching the report |
| BRC-005 | Dealer Name Mandatory on Validate | Validation | BR-004 | Dealer Name field is left blank when the user moves focus away | Call the standard null-check routine for the "Dealer" label and stop processing until a dealer name is entered | Ensures every report request is associated with a specific dealership |
| BRC-006 | From Date Mandatory on Excel Submit | Validation | BR-005 | From Date is blank when the user clicks the first Submit Report button | Display *"Enter From Date"* and cancel the submit action | Prevents the CSV extract from running without a start date filter |
| BRC-007 | To Date Must Not Be Before From Date on Excel Submit | Validation | BR-005 | To Date is earlier than From Date when the user clicks the first Submit Report button | Display *"To Date could not be Less than From Date!"* and cancel the submit action | Prevents an invalid date range from producing an empty or misleading CSV extract |
| BRC-008 | Report Period Must Not Exceed 30 Days on Excel Submit | Constraint | BR-005 | The selected date range exceeds thirty calendar days when the user clicks the first Submit Report button | Display *"Report Could Not Be Generate More Than 30 days !"* and cancel the submit action | Limits the CSV extract to a manageable period to prevent excessively large output files |
| BRC-009 | CSV File Path Must Not Contain Spaces | Constraint | BR-005 | The generated CSV filename or path contains a space character | Redirect the file to the C drive root and inform the user with *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Ensures the file can be saved when the default path contains spaces |
| BRC-010 | CSV Row Count Must Not Exceed 65535 | Constraint | BR-005 | The query result set exceeds 65,535 rows during CSV generation | Truncate the output to 65,535 rows and inform the user with *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents the CSV output from exceeding the maximum Excel row limit |
| BRC-011 | All Mandatory Fields Required on PDF Submit | Validation | BR-006 | One or more of the start date, end date, or dealer code fields are blank when the user clicks the main Submit Report button | Display *"Please Enter All Mandatory Fields"* and cancel the submit action | Ensures no required filter is missing before the PDF report is run |
| BRC-012 | From Date Mandatory (Individual Check) on PDF Submit | Validation | BR-006 | From Date is blank at the individual check step when the user clicks the main Submit Report button | Display *"Enter From Date"* and cancel the submit action | Secondary confirmation that the start date is present before the date-order check runs |
| BRC-013 | To Date Must Not Be Before From Date on PDF Submit | Validation | BR-006 | To Date is earlier than From Date when the user clicks the main Submit Report button | Display *"To Date could not be Less than From Date!"* and cancel the submit action | Prevents the PDF report from running over an invalid date range |
| BRC-014 | Date Entry Must Be a Valid Calendar Date | Validation | BR-009 | A date entered on the screen is not a valid calendar date (system error 50004) | Display *"Entered Date is not valid Date"* and stop processing | Replaces a cryptic system error with a readable message guiding the user to enter a valid date |
| BRC-015 | Date Entry Must Use DD-MM-YYYY Format | Validation | BR-009 | A date is entered in an unsupported format (system errors 50025 or 50026) | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop processing | Guides the user to use the required date format |
| BRC-016 | Numeric Fields Must Not Contain Non-Numeric Input | Validation | BR-009 | A non-numeric or special character is entered in a numeric-only field (system errors 40209 or 50016) | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop processing | Prevents invalid data types from being entered in numeric fields |
| BRC-017 | Child-Record Integrity Constraint Must Not Be Violated | Constraint | BR-009 | A database child-record integrity error occurs (database error -02292) | Raise standard application error E0088 and stop processing | Informs the user that a record cannot be changed because dependent child records exist |
| BRC-018 | Concurrent Record Updates Are Detected and Rolled Back | Validation | BR-009 | A record has been updated by another user (system errors 40654-40659) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and stop processing | Prevents data loss from undetected concurrent updates |
| BRC-019 | All Unhandled Database Errors Are Reported and Rolled Back | Validation | BR-009 | Any unhandled SQL error occurs (SQL error code is not zero) | Display the database error text and roll back pending changes | Ensures the user is informed of unexpected database errors and uncommitted changes are not silently lost |
| BRC-020 | System Message Codes 40209 and 40207 Are Reformatted | Derivation | BR-010 | The form generates a message event with code 40209 or 40207 | Reformat and display the message as type-code-text in a standardised error style; suppress the default message display | Ensures consistent error message presentation for these specific system message codes |

**Total Business Rules Identified: 20**

---

## 6. Data Requirements

*This section describes the data entities queried by the No-Show Customer Summary form, the filter fields captured on screen, the reference data sources used, and the data lifecycle for this reporting screen.*

### 6.1 Business Entities and Relationships

*The form does not maintain its own base table. It reads from the AMC (After Market Campaign) enquiry transaction table, vehicle master, dealer location, package description, and status look-up tables to build the on-screen extract and PDF report.*

#### No-Show AMC Enquiry - VH_AMC_ENQ

The no-show AMC enquiry entity stores all after-market campaign (AMC) package enquiry records, including customer details, vehicle information, enquiry status, and the package being enquired about. The form reads this table to retrieve open no-show enquiries within the user's selected date range, location, and dealership group.

#### Dealer Location - MULDMS.AM_DEALER_LOC

The dealer location entity holds the descriptive name and mapping for each dealership location within the multi-dealership management system. The form joins this entity to the enquiry records to resolve the human-readable location name for each enquiry row in the extract.

#### AMC Package Description - VM_AMC_PKG (INFERRED - referenced in inline SQL)

The AMC package description entity provides the description of each after-market campaign package. The form joins this entity to the enquiry record to include the package description alongside the package code in the extract output.

#### Vehicle Master - GM_VIN

The vehicle master entity stores the VIN-level vehicle record including the manufacturer principal association. The form joins this entity to the enquiry records to ensure each no-show enquiry is linked to a valid, known vehicle registered under the correct principal.

#### Enquiry Status List - MULDMS.AM_LIST_RANGE

The enquiry status list entity provides the human-readable description for each enquiry status code. The form looks up the status description for each enquiry row so the extract shows a readable status label rather than a raw code.

#### Entity Relationships

The No-Show Customer Summary form queries a set of related entities: the AMC enquiry record is the central entity, joined to the dealer location for its readable name, the vehicle master for VIN validation and principal matching, the AMC package description for package name resolution, and the enquiry status list for status label resolution.

```
VH_AMC_ENQ (No-Show AMC Enquiry)
        ├── MULDMS.AM_DEALER_LOC (Dealer Location - via parent_group, dealer_map_cd, loc_cd)
        ├── VM_AMC_PKG (AMC Package Description - via pkg_code, principal_map_cd)
        ├── GM_VIN (Vehicle Master - via vin, principal_map_cd)
        └── MULDMS.AM_LIST_RANGE (Enquiry Status - via principal_map_cd, list_name, list_code)
```

### 6.2 Data Capture Requirements

*The form captures filter parameters only; no data is inserted or updated. Filters govern the date range, location, and dealer for the report extract.*

#### Report Filter Criteria (User - report request entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| From Date (`FROM_DATE`) | Yes | Start date for the report period; determines the earliest enquiry creation date to include in the output | Must not be blank; must be in DD/MM/YYYY format; validated on field exit and on submit |
| To Date (`TO_DATE`) | Yes | End date for the report period; automatically set to thirty days after the From Date but can be changed by the user | Must not be blank; must not be earlier than the From Date; validated on field exit and on submit |
| Dealer Name (`DEALER`) | Yes | Name of the dealership for which the report is requested; used as a display label | Must not be blank; validated on field exit |
| Dealer Code (`DEALER_CD`) | Yes | Internal code of the dealership; passed to the PDF report as the dealer filter parameter | Must not be blank at the time the main Submit Report button is clicked |
| Location Code (`LOC_CD`) | No | Location code used to filter enquiries to a specific dealership location; if set to "ALL" or left blank the extract covers all locations | No individual field validation; applied as a filter in the report query |

#### Session and Working Fields (System - auto-populated)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Query Working Field (`T1`) | Auto-Populated | Internal field that holds the dynamically constructed SQL query string for the CSV extract; not displayed to the user as a user-editable field | System-set only; holds up to 10,000 characters of SQL text |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Displays the current copyright declaration text retrieved from the copyright declaration function; refreshed each time the form is cleared | System-set; read-only display field |
| Screen Title (`TITLE`) | Auto-Populated | Displays the screen title "No Show Customer Search Screen"; reset to the standard label whenever the form is cleared | System-set; fixed label |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form when building the report extract.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Location master (`MULDMS.AM_DEALER_LOC`) | Provides the human-readable location description for each enquiry location code in the extract | When building the CSV or PDF extract, to resolve the location code to a readable name |
| AMC Package master (`VM_AMC_PKG`) | Provides the package description corresponding to the enquired package code | When building the CSV extract, to include the package description alongside the package code for each enquiry row |
| Vehicle master (`GM_VIN`) | Validates that each enquiry record is linked to a known vehicle under the correct manufacturer principal | When building the CSV extract, to filter and join to the VIN record |
| Enquiry status list (`MULDMS.AM_LIST_RANGE`) | Provides the human-readable enquiry status label for each enquiry status code; list filtered to the current manufacturer principal and the list named "AMC_ENQSTATUS" | When building the CSV extract, to resolve the status code to a readable status label for each enquiry |
| Report server configuration file (`/reports/DMS/excelpath.txt`) | Provides the URL base path for the report server output directory, used to construct the browser-accessible URL for the generated CSV file | When generating the CSV file, to determine the server path and browser URL for the output file |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and used within this form's evidenced behaviour.*

**Creation**

- This form does not create any records. It is a reporting-only screen; all output is produced as a read-only PDF report or CSV extract.

**Updates**

- This form does not update any records. No inserts, updates, or deletes are performed against any database table.

**Save and Commit**

- The KEY-COMMIT trigger is inactive (does not execute). No save or commit action is available on this screen. The form operates in read-only/reporting mode only.

**Retention and Audit**

- No retention or audit behaviour is implemented by this form. Session context labels are set on open (via the database session module/action registration) and cleared on exit, but no audit trail is written to any table.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | From Date, To Date | Location |  | AM_DEALER_LOC | LOC_DESC | Scalar subquery retrieves the dealer location description (LOC_DESC) from AM_DEALER_LOC matching the enquiry's parent_group, dealer_map_cd, and loc_cd; comma characters are removed via REPLACE. |
| 2 | From Date, To Date | MCP Enquiry No |  | VH_AMC_ENQ | ENQ_NUM | The AMC enquiry number (ENQ_NUM) sourced directly from the VH_AMC_ENQ header record. |
| 3 | From Date, To Date | MCP Enquiry Date |  | VH_AMC_ENQ | ENQ_DATE | The AMC enquiry date (ENQ_DATE) from VH_AMC_ENQ, formatted DD/MM/YYYY via TO_CHAR for display. |
| 4 | From Date, To Date | Customer Name |  | VH_AMC_ENQ | CUST_NAME | Customer name (CUST_NAME) from VH_AMC_ENQ; comma characters are removed via REPLACE to avoid CSV delimiter conflicts. |
| 5 | From Date, To Date | Cust Addr1 |  | VH_AMC_ENQ | CUST_ADDR1 | First customer address line (CUST_ADDR1) from VH_AMC_ENQ; comma characters are removed via REPLACE. |
| 6 | From Date, To Date | Cust Addr2 |  | VH_AMC_ENQ | CUST_ADDR2 | Second customer address line (CUST_ADDR2) from VH_AMC_ENQ; comma characters are removed via REPLACE. |
| 7 | From Date, To Date | Cust Addr3 |  | VH_AMC_ENQ | CUST_ADDR3 | Third customer address line (CUST_ADDR3) from VH_AMC_ENQ; comma characters are removed via REPLACE. |
| 8 | From Date, To Date | Mobile |  | VH_AMC_ENQ | MOBILE | Customer mobile number (MOBILE) sourced directly from the VH_AMC_ENQ enquiry record. |
| 9 | From Date, To Date | Email |  | VH_AMC_ENQ | EMAIL | Customer email address (EMAIL) sourced directly from the VH_AMC_ENQ enquiry record. |
| 10 | From Date, To Date | Model |  | VH_AMC_ENQ | SVAR_CD | Service variant code (SVAR_CD) from VH_AMC_ENQ identifying the vehicle model associated with the AMC enquiry. |
| 11 | From Date, To Date | Vin |  | VH_AMC_ENQ | VIN | Vehicle Identification Number (VIN) sourced directly from the VH_AMC_ENQ enquiry record. |
| 12 | From Date, To Date | Reg Num |  | VH_AMC_ENQ | REG_NUM | Vehicle registration number (REG_NUM) sourced directly from the VH_AMC_ENQ enquiry record. |
| 13 | From Date, To Date | Current Mileage |  | VH_AMC_ENQ | ODOMETER_READING | Current odometer reading (ODOMETER_READING) from VH_AMC_ENQ representing the vehicle mileage at the time of enquiry. |
| 14 | From Date, To Date | Veh Inv Dt |  | INV_DATE | INV | Shows the Veh Inv Dt taken from the enquiry's related records. |
| 15 | From Date, To Date | Engine No |  | VH_AMC_ENQ | ENGINE_NUM | Vehicle engine number (ENGINE_NUM) sourced directly from the VH_AMC_ENQ enquiry record. |
| 16 | From Date, To Date | Chassis No |  | VH_AMC_ENQ | CHASSIS_NUM | Vehicle chassis number (CHASSIS_NUM) sourced directly from the VH_AMC_ENQ enquiry record. |
| 17 | From Date, To Date | Enquired Package Code |  | VH_AMC_ENQ | PKC | AMC package code (PKG_CODE) from VH_AMC_ENQ identifying the service package the customer enquired about. |
| 18 | From Date, To Date | Enquired Package Desc |  | VM_AMC_PKG | PKD | Package description (PKG_DESC) joined from VM_AMC_PKG via PKG_CODE; comma characters are removed via REPLACE. |
| 19 | From Date, To Date | Enquiry Age (in days) |  | VH_AMC_ENQ | AG | Derived count of days since the enquiry was raised, calculated as ROUND(TRUNC(SYSDATE) - TRUNC(ENQ_DATE)) from VH_AMC_ENQ; no single stored column. |
| 20 | From Date, To Date | Enquiry Status |  | AM_DEALER_LOC | LOC | Shows the Enquiry Status taken from the enquiry's related records. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AMC | Annual Maintenance Contract - a service agreement under which a vehicle owner is entitled to scheduled maintenance services at a dealership | Annual Maintenance Contract | AMC Enquiry, Package |
| AMC Enquiry | A customer service enquiry raised under an AMC, tracking the customer's scheduled maintenance appointment and current status | Enquiry | AMC, No-Show, Enquiry Status |
| CB_BLK | Control Block - the single Oracle Forms data block in vr_nsc_summ that holds all user-entry fields and buttons without a direct database binding | Control Block | Block, Oracle Forms |
| CSV | Comma-Separated Values - a plain-text file format used to export the no-show AMC enquiry report for download and review | Comma-Separated Values | Export, Report |
| Dealer Code | A unique code identifying a dealership within the DMS, used to filter AMC enquiry records to a specific dealer | DEALER_CD | Dealer, Location Code |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which vr_nsc_summ operates | Dealer Management System | System |
| DPL | The program library (`DPL.pld`) attached to the form that provides shared utility procedures and functions such as DISP_TEXT, CHECK_NULL, and RAISE_ERROR | DPL.pld | PLD, Program Library |
| Enquiry Status | A coded status describing the current state of an AMC enquiry (e.g. Open); resolved to a readable description from the AMC status reference list | Enq_Status | AMC Enquiry, Status Code |
| From Date | The start date of the report date range entered by the user; mandatory field for both CSV export and PDF report generation | FROM_DATE | To Date, Date Range |
| Location Code | A code identifying a specific service location within a dealer, used as a filter parameter in both the CSV export and the PDF report | LOC_CD | Dealer Code, Dealer Location |
| No-Show | A customer who held an AMC service appointment but did not attend; the subject record type reported by vr_nsc_summ | No Show | AMC Enquiry, Customer |
| Oracle Forms | Oracle application development framework used to build the vr_nsc_summ module; the form is defined in a `.fmb` source and runs as an `.xml` deployment | Oracle Forms Builder | DMS, Module |
| Package (AMC) | A defined Annual Maintenance Contract service package identified by a package code and description, linked to each AMC enquiry record | PKG_CODE, Package Code | AMC, AMC Enquiry |
| PDF | Portable Document Format - the output format of the vr_nsc_summ report submitted to the Oracle Reports server and displayed in the browser | Portable Document Format | Report, Report Server |
| PLD | Program Library Document - a compiled Oracle Forms shared library (`DPL.pld`) that provides reusable procedures and functions attached to the form | Program Library | DPL, Shared Library |
| Principal | A group-level identifier (principal map code) representing the vehicle manufacturer or distributor principal; used to scope AMC enquiry data and as a report parameter | PRINCIPAL, Principal Map Code | Dealer, Parent Group |
| Principal Group | A hierarchical grouping above dealer level used to scope AMC enquiry data by the correct dealer group in the dynamic query | PARENT_GROUP | Principal, Dealer |
| Report Server | The Oracle Reports server to which the vr_nsc_summ PDF report job is submitted; the server name is held in a session global variable | REP_SERVER, Oracle Reports | PDF, Report |
| To Date | The end date of the report date range entered by the user; must not be earlier than From Date; mandatory for both CSV export and PDF report generation | TO_DATE | From Date, Date Range |
| VIN | Vehicle Identification Number - a unique code identifying an individual vehicle; used to join vehicle records in the AMC enquiry export query | Vehicle Identification Number | Vehicle, Chassis Number |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_nsc_summ (VR_NSC_SUMM)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN (inherited from DPL parent via PC_FORM property class; ConsoleWindow XML attribute not set directly on this form module). The runtime screen title "No Show Customer Search Screen" is assigned by the KEY-CLRFRM trigger.
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx, database packages PKG_CODE, PKG_DESC, PK_PART_SEARCH_NEW
- Source artifacts: `vr_nsc_summ_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Application logging flag; when set to `Y`, performance timer is started at form open |
| COMP_FA | Char | Trigger | Company financial area code read at form initialisation and used to scope financial-year queries |
| CURRENCY | Char | Trigger | Currency code for the current session; used to format monetary values in reports and exports |
| CUR_DATE | Date | ProgramUnit | Current business date used as upper boundary for date validation |
| DEALER | Char | Trigger | Dealer name or code captured at session level; used to pre-populate or cross-validate the CB_BLK.DEALER field |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session; used to constrain date-range defaults |
| FIN_END | Char | Trigger | Financial year end date for the current session; used to constrain date-range defaults |
| LOC_CD | Char | Trigger | Location code for the current session; used to pre-populate or cross-validate the CB_BLK.LOC_CD field |
| PARENT_GROUP | Char | Trigger | Principal group identifier used to filter AMC enquiry data to the correct dealer group |
| PRINCIPAL | Char | ProgramUnit / Trigger | Principal map code passed as parameter to the report and used in AMC enquiry queries |
| P_FIN_YR | Char | Trigger | Current financial year identifier; used to scope queries and report parameters to the active fiscal year |
| REP_SERVER | Char | ProgramUnit / Trigger | Report server name used to route the PDF report job |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the current session |
| USERID | Char | ProgramUnit / Trigger | Logged-in user identifier used to generate unique CSV file names |
| USER_NAME | Char | Trigger | Display name of the logged-in user; used for session context and DBMS application info |

### 8.1.2 Form Parameters

*No ModuleParameter entries found in vr_nsc_summ_fmb.xml.*

**Total Parameters:** 0

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control block - entry point for report criteria selection |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_nsc_summ_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_nsc_summ_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_nsc_summ_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 10 | 0 | 10 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **23** | **0** | **23** |

**Item detail (all 23 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | SUBMIT2 | false | Button that generates and exports AMC enquiry data as a CSV file |
| CB_BLK | FROM_DATE | false | Report start date entered by the user (DD/MM/YYYY format) |
| CB_BLK | TO_DATE | false | Report end date entered by the user (DD/MM/YYYY format) |
| CB_BLK | DEALER | false | Dealer name or description entered to filter the report |
| CB_BLK | SUBMIT | false | Button that generates and launches the PDF report for the selected criteria |
| CB_BLK | DEALER_CD | false | Dealer code used as a filter parameter in the report query |
| CB_BLK | T1 | false | Internal text item that holds the dynamically built SQL query string |
| CB_BLK | COPYRIGHT_DECLARATION | false | Displays the copyright declaration text populated at form open |
| CB_BLK | LOC_CD | false | Location code used to filter AMC enquiry data by dealer location |
| CB_BLK | TITLE | false | Display label showing the form title: No Show Customer Search Screen |
| PB_BLK | PB_EXIT | false | Inherited toolbar button that closes the current form (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_LIST | false | Inherited toolbar button that displays the LOV for the current item (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button that inserts a new record; inactive on this read-only reporting form (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PM_CONT | false | Inherited toolbar button providing context-menu or continuation action (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_DEL | false | Inherited toolbar button that deletes the current record; inactive on this read-only reporting form (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button that cancels pending changes (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button that saves changes; inactive on this read-only reporting form (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button that triggers the print action (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_CUT | false | Inherited toolbar button that cuts selected text (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_COPY | false | Inherited toolbar button that copies selected text (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button that pastes clipboard text (inherited from DPL.olb PB_BLK object group) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button that dismisses the error window and returns focus to the main canvas (inherited from DPL.olb PB_BLK object group) |
| CB_ERR | TXT_ERR | false | Inherited display-only text item on the error canvas (CN_ERR) that shows the current error message text (inherited from DPL.olb CB_ERR object group) |

### 8.4 List of Values

*No LOVs found in vr_nsc_summ_fmb.xml.*

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | Not invoked by any active trigger or program unit in the current form version |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb; displayed by DPL library routines when a print action is initiated |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.RAISE_ERROR and GENERAL.DISP_TEXT when an error-level message is raised |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.DISP_TEXT when an informational note is raised |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb; displayed by GENERAL.ASK_CONFIRM when a confirmation prompt is required (e.g. PB_EXIT) |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | `GENERAL.CHECK_NULL`, `GENERAL.DISP_TEXT` | **COMMENTED OUT / INACTIVE** - All procedure body is commented out; no calls are made at runtime |
| CHECK_BEFORE_DELETE | Unknown | `GENERAL.DISP_TEXT` | **COMMENTED OUT / INACTIVE** - All procedure body is commented out; deletion check against SH_ENQUIRY not active |
| POPULATE_ERRORS | Package spec | `PK_PLSQL_TABLE.CODE_TAB` | Package spec declaring a PL/SQL table variable `v_tab` of type `CODE_TAB`; used as an error table holder |
| VIEW_EXCEL_REP | Procedure | `CREATE_GROUP_FROM_QUERY`, `POPULATE_GROUP`, `GET_GROUP_ROW_COUNT`, `FIND_COLUMN`, `GET_GROUP_CHAR_CELL`, `TEXT_IO`, `WEB.SHOW_DOCUMENT`, `WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT`, `WEBUTIL_HOST.HOST` | Generates a dynamic record group from a query string, writes results to a CSV file on the application server, and opens the file in the browser |
| CALL_REPORT | Procedure | `FIND_REPORT_OBJECT`, `SET_REPORT_OBJECT_PROPERTY`, `RUN_REPORT_OBJECT`, `WEB.SHOW_DOCUMENT` | Configures and submits the `vr_nsc_summ` report with principal, date range, location, and dealer parameters; displays the resulting PDF in the browser |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays the AL_CONFIRM caution alert and returns the user's Yes/No response; used to confirm destructive navigation such as form exit |
| GENERAL.CHECK_NULL | Library routine | CB_BLK.DEALER (WHEN-VALIDATE-ITEM), ProgramUnit: VALIDATE_CN_MAIN (inactive) | Validates that the supplied field is not null; raises an error and halts navigation if the field is empty |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.FROM_DATE (WHEN-VALIDATE-ITEM), CB_BLK.SUBMIT (WHEN-BUTTON-PRESSED), CB_BLK.SUBMIT2 (WHEN-BUTTON-PRESSED), CB_BLK.TO_DATE (WHEN-VALIDATE-ITEM), Form level (ON-ERROR, ON-MESSAGE), ProgramUnit: CHECK_BEFORE_DELETE (inactive), ProgramUnit: VALIDATE_CN_MAIN (inactive) | Displays an alert dialog (error or note) with the supplied message text and title |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR) | Looks up an error message by code and displays it via AL_ERRINFO; raises FORM_TRIGGER_FAILURE for error-type messages |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers the generated CSV file from the application server to the client machine for download |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the application server during CSV file generation |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Two earlier versions of the error handler are fully block-commented; the first checked error codes 40209 and 40207 and called GENERAL.DISP_TEXT; the second extended handling to include ORA-02292 foreign key violation, date format errors (50004, 50025, 50026), numeric-only field errors (40209, 50016), and concurrent update codes (40654-40659) with a RollBack | Superseded by the active third version of ON-ERROR which is now the live implementation |
| **Inactive stub** | Form | - | KEY-COMMIT | Body contains only `NULL;` - no commit processing is performed | Disabled - form is a reporting/search screen with no insert, update, or delete operations |
| **Commented out** | Form | - | FT_SAVE | Earlier implementation of the toolbar Save action is fully block-commented; previously called the standard DPL save routine | Superseded or disabled; the inherited FT_SAVE object-group trigger from DPL.olb is the current reference |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Earlier form initialisation logic is fully block-commented; previously populated global variables and set the window title | Superseded; active initialisation is now performed by PRE-FORM and KEY-CLRFRM |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Earlier exit handler is fully block-commented; previously called GENERAL.ASK_CONFIRM and then EXIT_FORM | Superseded by the inherited WHEN-BUTTON-PRESSED on PB_EXIT from DPL.olb PB_BLK object group |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (40 business triggers):**
*vr_nsc_summ_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts runtime form and database errors; displays user-friendly messages for invalid date format (50004, 50025, 50026), non-numeric input (40209, 50016), field-level validation errors (40207), foreign key violations (ORA-02292), and concurrent update conflicts (40654-40659) |
| ON-MESSAGE | Form | - | Form level | Intercepts informational form messages for error codes 40209 and 40207; displays them as an error dialog instead of the default status bar message |
| KEY-EXIT | Form | - | Form level | Closes the form without validation and clears the DBMS application info session context |
| KEY-LISTVAL | Form | - | Form level | Identifies the LOV attached to the current cursor item and displays it; advances to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Body is `NULL;`; no commit processing occurs (see Section 8.7.1) |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, maximises the MDI and main windows, repopulates the copyright declaration, and resets the form title |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses or handles all other unassigned key events at the form level (inherited from DPL.olb object group) |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Provides default next-item navigation at the form level (inherited from DPL.olb object group) |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Provides default previous-item navigation at the form level (inherited from DPL.olb object group) |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates to the next block at the form level (inherited from DPL.olb object group) |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates to the previous block at the form level (inherited from DPL.olb object group) |
| KEY-DOWN | Form | - | Form level (inherited) | Moves the cursor down one record at the form level (inherited from DPL.olb object group) |
| KEY-UP | Form | - | Form level (inherited) | Moves the cursor up one record at the form level (inherited from DPL.olb object group) |
| FT_SAVE | Form | - | Form level (inherited) | Inherited toolbar Save trigger from DPL.olb; active version handles save action for the form; earlier local version is commented out (see Section 8.7.1) |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited toolbar Cancel trigger from DPL.olb; cancels pending changes and refreshes the current block |
| FT_INSERT | Form | - | Form level (inherited) | Inherited toolbar Insert trigger from DPL.olb; initiates insert mode; inactive on this read-only reporting form |
| FT_DEL | Form | - | Form level (inherited) | Inherited toolbar Delete trigger from DPL.olb; initiates record deletion; inactive on this read-only reporting form |
| FT_LIST | Form | - | Form level (inherited) | Inherited toolbar List trigger from DPL.olb; displays the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited toolbar Print trigger from DPL.olb; initiates the print action using AL_PRINT |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Inherited form-startup trigger from DPL.olb; performs standard DPL initialisation; earlier local version is commented out (see Section 8.7.1) |
| PRE-FORM | Form | - | Form level | Starts the performance timer if application logging is enabled (`APP_LOG = Y`); sets the DBMS application info module to `enroll_pend` |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT2 | CB_BLK.SUBMIT2 | Validates From Date is not null and date range is not more than 30 days; builds a dynamic SQL query against AMC enquiry and related tables; exports the result set to a CSV file via VIEW_EXCEL_REP and opens it in the browser |
| WHEN-VALIDATE-ITEM | CB_BLK | FROM_DATE | CB_BLK.FROM_DATE | Validates From Date is not null; auto-populates To Date as From Date plus 30 days |
| KEY-NEXT-ITEM | CB_BLK | FROM_DATE | CB_BLK.FROM_DATE | Navigates the cursor to the TO_DATE field |
| WHEN-VALIDATE-ITEM | CB_BLK | TO_DATE | CB_BLK.TO_DATE | Validates To Date is not null and is not earlier than From Date |
| KEY-NEXT-ITEM | CB_BLK | TO_DATE | CB_BLK.TO_DATE | Navigates the cursor to the SUBMIT button |
| WHEN-VALIDATE-ITEM | CB_BLK | DEALER | CB_BLK.DEALER | Validates that the Dealer field is not null using GENERAL.CHECK_NULL |
| KEY-NEXT-ITEM | CB_BLK | DEALER | CB_BLK.DEALER | Navigates the cursor to the LOC_CD field |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Validates that From Date, To Date, and Dealer Code are all entered; invokes CALL_REPORT to generate and display the PDF report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar Exit button handler; calls GENERAL.ASK_CONFIRM and exits the form if confirmed |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar List button handler; displays the LOV for the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar Insert button handler; initiates insert mode; inactive on this read-only reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar context/continuation button handler; behaviour defined by DPL.olb |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar Delete button handler; initiates record deletion; inactive on this read-only reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar Cancel button handler; cancels pending changes |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar Save button handler; inactive on this read-only reporting form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar Print button handler; triggers the print action using AL_PRINT |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar Cut button handler; cuts selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar Copy button handler; copies selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar Paste button handler; pastes clipboard text into the focused item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | NSC Search Screen Report (Rel 1.0.0) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vr_nsc_summ_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_nsc_summ_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_nsc_summ_fmb.xml.*

## 9. Object Library

*The form references the DPL Object Library for shared visual attributes, property classes, and object groups. The table below catalogues all objects in the library as sourced from the DPL_olb.xml file. The form-level visual attributes (VA_MANDATORY, VA_DEFAULT, VA_DISPLAY) and object group (OG_GROUP) are also declared directly in the form module.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check-box item visual style: gray background, Arial 8pt, black foreground, transparent fill | referenced | Check-box items |
| VA_RB | VisualAttribute | Radio-button item visual style: gray background, Arial 8pt, black foreground, transparent fill | referenced | Radio-button items |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual style: white background, black foreground, transparent fill | referenced | Iconic push buttons |
| VA_DESC | VisualAttribute | Descriptive label visual style: gray background, Small Fonts 7pt, blue foreground, transparent fill | referenced | Display/label items |
| VA_NUM | VisualAttribute | Numeric field visual style: white background, Arial 8pt medium-weight, black foreground, transparent fill | referenced | Numeric text items |
| VA_MAND | VisualAttribute | Mandatory field visual style: CYAN background, Arial 9pt medium-weight, black foreground, transparent fill | referenced | Mandatory text items |
| VA_OPROMPT | VisualAttribute (Prompt) | Optional field prompt style: white background, Arial 9pt, black prompt foreground, transparent fill | referenced | Prompts for optional fields |
| VA_MPROMPT | VisualAttribute (Prompt) | Mandatory field prompt style: white background, Arial 9pt, red prompt foreground, transparent fill | referenced | Prompts for mandatory fields |
| VA_TEXT | VisualAttribute | Standard text item visual style: white background, Arial 9pt medium-weight, black foreground, transparent fill | referenced | Standard text items |
| VA_BUTN | VisualAttribute | Push button visual style: gray background, Arial 10pt bold, black foreground, transparent fill | referenced | Push buttons |
| VA_ALERT | VisualAttribute | Alert dialog visual style: gray background, MT Extra 11pt, black foreground, transparent fill | referenced | Alert dialogs |
| VA_TITLE | VisualAttribute | Screen title visual style: gray background, Arial 10pt bold, blue foreground, transparent fill | referenced | Title items |
| VA_TRNI_DT | VisualAttribute | Transaction date display style: white background, Courier bold, black foreground, transparent fill | referenced | Transaction date display items |
| VA_LOV | VisualAttribute | LOV (list of values) visual style: gray background, Arial 9pt, dark-blue foreground, transparent fill | referenced | LOV-linked items |
| VA_DISP | VisualAttribute | Display-only item style: r25g75b75 background, Arial 8pt bold, black foreground, transparent fill | referenced | Read-only display items |
| PC_DESC | PropertyClass | Display item for descriptive text: left-aligned, 250px wide, 110 chars max, Arial 9pt, blue foreground, lowered bevel, no border | referenced | Descriptive display items |
| PC_SC_DATE | PropertyClass | Display-style date item: 73px wide, 10-char max, gray background, Arial 8pt bold, blue foreground, DD-MM-YY or DD/MM/YY format hint | referenced | Short date display items |
| PC_TITLE | PropertyClass | Centre-aligned title text item: gray background, Arial 10pt bold, blue foreground, upper case | referenced | Screen title items |
| PC_FORMAT | PropertyClass | Centre-aligned format text: 60px wide, 12 chars max, Arial 9pt, black foreground, upper case | referenced | Formatted code items |
| PC_MR_BLK | PropertyClass | Master-record block navigation: next-block navigation to PB_BLK, vertical orientation, change-record style | referenced | Master blocks |
| PC_DISP | PropertyClass | Read-only display item: disabled, Arial 9pt medium-weight, gray8 background, lowered bevel, non-keyboard-navigable | referenced | Read-only display text items |
| PC_LOV | PropertyClass | LOV-linked field: 250px wide, gray background, Arial 8pt, dark-blue foreground, auto-select off, 200px height | referenced | LOV-linked text items |
| PC_FORM | PropertyClass | Form-level defaults: item-level validation, no savepoint, console window WN_MAIN, menu menu.mmx; includes ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM triggers | referenced | Form module |
| PC_DISP_DATE | PropertyClass | Read-only date display: disabled, gray8 background, Arial 9pt, DD-MM-RRRR format, non-keyboard-navigable | referenced | Read-only date display items |
| PC_DISP_NUM | PropertyClass | Read-only numeric display: right-aligned, disabled, gray8 background, Arial 9pt, lowered bevel, non-keyboard-navigable | referenced | Read-only numeric display items |
| PC_DATE | PropertyClass | Editable date input: 60px wide, 10 chars max, DD-MM-RRRR format, Date data type, white background, Arial 9pt, mouse-navigate, DD-MM-YYYY or DD/MM/YYYY hint | referenced | Editable date fields |
| PC_DTTIME | PropertyClass | Date-time input: 80px wide, 15 chars max, DD-MM-RRRR HH24:MI format, DateTime data type, initialized to current DB date-time | referenced | Date-time input fields |
| PC_CB | PropertyClass | Check-box item: white background, Arial 9pt | referenced | Check-box items |
| PC_ALERT | PropertyClass | Alert dialog: gray background, MT Extra 11pt | referenced | Alert dialogs |
| PC_MDATE | PropertyClass | Mandatory date input: 60px wide, DD-MM-RRRR format, Date type, red prompt, mouse-navigate; includes WHEN-VALIDATE-ITEM trigger enforcing non-null entry | referenced | Mandatory date fields |
| PC_RB | PropertyClass | Radio button: gray background, Arial 9pt | referenced | Radio-button items |
| PC_WIND | PropertyClass | Window defaults: resizable, movable, maximisable, minimisable, hide on exit, gray background, Arial 10pt bold, blue foreground, 464×286px | referenced | Window objects |
| PC_CANV | PropertyClass | Canvas defaults: white background, 750px wide, 440px high, raises on enter, linked to WN_MAIN | referenced | Canvas objects |
| PC_BUTN | PropertyClass | Push button: 42px wide, gray background, Arial 9pt bold, mouse-navigate off | referenced | Push button items |
| PC_TEXT | PropertyClass | Standard editable text item: left-aligned, Arial 9pt, white background, black foreground, mixed case | referenced | Standard text input items |
| PC_MTEXT | PropertyClass | Mandatory editable text item: left-aligned, Arial 9pt, white background, red prompt, mixed case; includes WHEN-VALIDATE-ITEM trigger enforcing non-null entry | referenced | Mandatory text input items |
| PC_UTEXT | PropertyClass | Upper-case editable text item: left-aligned, Arial 9pt, white background, upper case | referenced | Upper-case text items |
| PC_MUTEXT | PropertyClass | Mandatory upper-case text item: left-aligned, Arial 9pt, white background, red prompt, upper case; includes WHEN-VALIDATE-ITEM trigger enforcing non-null entry | referenced | Mandatory upper-case text items |
| PC_NUM | PropertyClass | Numeric input: right-aligned, Arial 9pt, white background, lower bound 0, upper case | referenced | Numeric input items |
| PC_MNUM | PropertyClass | Mandatory numeric input: right-aligned, Arial 9pt, white background, lower bound 0, red prompt; includes WHEN-VALIDATE-ITEM trigger enforcing non-zero entry | referenced | Mandatory numeric input items |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button: 20px wide, iconic, white background, bevel None, mouse-navigate off | referenced | Iconic button items |
| PC_SCROLL | PropertyClass | Scroll bar: 13px wide | referenced | Scroll bar objects |
| VA_MANDATORY | VisualAttribute | Form-level mandatory field visual attribute (declared in form module) | referenced | Mandatory form items |
| VA_DEFAULT | VisualAttribute | Form-level default visual attribute (declared in form module) | referenced | Default-styled form items |
| VA_DISPLAY | VisualAttribute | Form-level display-only visual attribute (declared in form module) | referenced | Display-only form items |
| OG_GROUP | ObjectGroup | Form-level object group (declared in form module) | referenced | Shared object grouping |

---

## 10. Record Groups

*No record groups found in `vr_nsc_summ_fmb.xml`.*

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle pseudo-table - used to generate header rows (location and date range labels) in the dynamic CSV export query |

**Total Referenced Objects:** 1

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-005 | VIEW_EXCEL_REP | Executes the no-show enquiry query, writes the result to a CSV file on the report server, and opens the file in the browser for download |
| BR-006 | CALL_REPORT | Configures and submits the No-Show Customer Summary PDF report to the report server and opens the rendered PDF in the browser |
| BR-004 | GENERAL.CHECK_NULL | Validates that a mandatory field is not blank; displays a field-labelled error message if the value is absent |
| BR-002, BR-003, BR-005, BR-006, BR-009, BR-010 | GENERAL.DISP_TEXT | Displays a labelled error or information message to the user; used by validations, error handlers, and message interceptors across the form |
| BR-009 | GENERAL.RAISE_ERROR | Raises a pre-defined application-level error by its error code; used to present standard application error messages (such as the child-record integrity error) |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog to the user before a cancellation or deletion action proceeds; returns the user's choice as a numeric value |
| BR-008 | SF_COPYRIGHT_DECLARATION | Returns the current copyright declaration text to be displayed on the screen |
| - | SF_GET_DEALER_NAME | Returns the dealer name corresponding to a given dealer code; used to populate or validate the dealer display on the form |
| BR-001 | STOP_WATCH.START_TIMER | Starts a performance timer when application logging is active at form open |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose | Classification |
| ----------------- | ---- | ----------- | ------- | -------------- |
| CALL_REPORT | Form Program Unit | WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT) | Locates the report object, applies filter parameters (principal, date range, location, dealer), runs the PDF report on the report server, and opens the result in the browser | Form Program Unit |
| VIEW_EXCEL_REP | Form Program Unit | WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT2) | Executes the supplied SQL query (including DUAL-based header rows for location and date range labels), writes the rows to a CSV file on the server, handles oversized result sets and file-path issues, and opens the file in the browser | Form Program Unit |
| GENERAL.ASK_CONFIRM | Attached library function (DPL) | FT_CANCEL (Form-level trigger), FT_DEL (Form-level trigger) | Displays a confirmation dialog presenting the supplied message text and returns a numeric value indicating the user's choice; called before cancellation or deletion actions to obtain explicit user confirmation before the operation proceeds | DPL Library Function |
| GENERAL.CHECK_NULL | Attached library procedure (DPL) | WHEN-VALIDATE-ITEM (CB_BLK.DEALER) | Checks whether a field value is null; if null, displays a mandatory-field error message reading "Enter a valid {column_title}" for the named field and raises FORM_TRIGGER_FAILURE to halt navigation | DPL Library Procedure |
| GENERAL.DISP_TEXT | Attached library procedure (DPL) | FT_INSERT (Form-level trigger), ON-ERROR (Form-level trigger), ON-MESSAGE (Form-level trigger), WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT, CB_BLK.SUBMIT2), WHEN-VALIDATE-ITEM (CB_BLK.FROM_DATE, CB_BLK.TO_DATE) | Displays an alert dialog with the supplied message text and title; uses AL_ERRINFO for error-titled alerts and AL_NOTE for all others; used across all validation, error-handling, and button-press flows on the form, and additionally from FT_INSERT to surface insert-time feedback | DPL Library Procedure |
| GENERAL.RAISE_ERROR | Attached library procedure (DPL) | ON-ERROR (Form-level trigger) | Looks up the message text and type for the given message code (e.g., E0088 for ORA-02292 foreign key violation); displays the resolved message via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE when the message type is 'E' | DPL Library Procedure |
| SF_COPYRIGHT_DECLARATION | External function (SF_COPYRIGHT_DECLARATION.fnc) | KEY-CLRFRM | Returns the current copyright declaration text string; called on form clear to refresh the copyright display area | External Function (SF_COPYRIGHT_DECLARATION.fnc) |
| SF_GET_DEALER_NAME | External function | Form program units / triggers referencing dealer display | Returns the dealer name corresponding to a supplied dealer code; used to populate or validate the dealer name field on the form | External Function |
| STOP_WATCH.START_TIMER | Package (STOP_WATCH.pck) | PRE-FORM | Starts a session-level performance timer when application logging is active; used for response-time monitoring | External Package (STOP_WATCH.pck) |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package | PRE-FORM, KEY-EXIT | Registers or clears the client information label in the current database session context for monitoring purposes | Oracle Built-in Package |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package | PRE-FORM, KEY-EXIT | Registers or clears the module name and action label in the current database session context for monitoring purposes | Oracle Built-in Package |
| WEB.SHOW_DOCUMENT | Oracle Forms Web package | CALL_REPORT, VIEW_EXCEL_REP | Opens a specified URL in a new browser window; used to display the generated PDF or CSV file to the user | Oracle Forms Built-in |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in the input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form source inputs. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays a confirmation dialog presenting the supplied `confirm_msg` text and returns a numeric value indicating the user's choice. Called from the FT_CANCEL and FT_DEL form-level triggers to prompt the user to confirm a cancellation or deletion action before the operation proceeds. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-VALIDATE-ITEM in CB_BLK.DEALER | Validates that the supplied field value is not null. If null, displays an error dialog with the message "Enter a valid {column_title}" and raises FORM_TRIGGER_FAILURE to halt navigation. Called from the DEALER field validation trigger to ensure the dealer is entered before submission. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT2, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | Displays an alert dialog with the supplied message text and title. Uses AL_ERRINFO for titles that equal 'ERROR' and AL_NOTE for all others. Called across error handling, field validation, and button-press triggers to present user-facing error and informational messages, and additionally from FT_INSERT to surface insert-time feedback to the user. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up the message text and type for the given message code (e.g., E0088 for foreign key violation). Displays the message via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE when the message type is 'E' (error). Called from ON-ERROR to handle the ORA-02292 constraint violation. |

**Total Active Routines:** 4 of 24 in DPL.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | No-Show Enquiry CSV Export | VH_AMC_ENQ, MULDMS.AM_DEALER_LOC, VM_AMC_PKG, GM_VIN, MULDMS.AM_LIST_RANGE | principal, fromDate, toDate, locCd, dealerCd, parentGroup | CSV file (streamed or URL) | Executes the no-show AMC enquiry query filtered by date range, location, dealer, and principal; returns results as a downloadable CSV containing customer, vehicle, package, and enquiry status details | POST /api/nsc-summary/export/csv |
| MS-002 | No-Show Enquiry PDF Report | REPORT_CALL / vr_nsc_summ report | principal, fromDate, toDate, locCd, dealerCd | PDF file (URL or stream) | Submits the No-Show Customer Summary report to the report server with the supplied filters and returns a link to the rendered PDF output | POST /api/nsc-summary/report/pdf |
| MS-003 | Copyright Declaration Retrieval | SF_COPYRIGHT_DECLARATION | (none) | Copyright declaration text string | Returns the current copyright declaration text for display on the screen | GET /api/system/copyright-declaration |
| MS-004 | Mandatory Field Validation - Null Check | GENERAL.CHECK_NULL (DPL library) | fieldValue, fieldLabel | Validation result and error message | Validates that a required field is not null; returns a descriptive error message identifying the empty field if validation fails | POST /api/validation/check-null |
| MS-005 | Application Error Message Lookup | GENERAL.RAISE_ERROR (DPL library) | errorCode | Error message text | Looks up and returns the standard application error message text for a given application error code | GET /api/errors/{errorCode} |

**Total Microservices Identified: 5**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialization | User opens the No-Show Customer Summary screen (PRE-FORM trigger fires) | 1. Check if application logging is active. 2. If logging active, start performance timer. 3. Register module name and action label in database session context. | Is application logging active? If yes, start timer; if no, skip timer. | Screen is open, session context registered, and performance timer running (if logging active). |
| WF-002 | CSV Report Generation via First Submit Button | User clicks the first Submit Report button (WHEN-BUTTON-PRESSED on SUBMIT2 fires) | 1. Validate From Date is not blank. 2. Validate To Date is not before From Date. 3. Validate date range does not exceed thirty days. 4. Construct unique output filename from user ID, location code, and current date-time. 5. Build the no-show enquiry SQL query with the entered filter criteria. 6. Store the query in the working field. 7. Execute the query and write the results to a CSV file on the report server. 8. Open the CSV file in a new browser window. | Is From Date blank? (-> error, stop). Is To Date before From Date? (-> error, stop). Does range exceed 30 days? (-> error, stop). Does filename path contain spaces? (-> redirect to C drive). Does result set exceed 65535 rows? (-> truncate and inform user). | CSV file generated and opened in browser; or error message shown and submit cancelled. |
| WF-003 | PDF Report Generation via Main Submit Button | User clicks the main Submit Report button (WHEN-BUTTON-PRESSED on SUBMIT fires) | 1. Check all mandatory fields (From Date, To Date, Dealer Code) are populated. 2. Individually validate From Date is not blank. 3. Validate To Date is not before From Date. 4. Locate the report object. 5. Set report filename, output format (PDF), and filter parameters. 6. Set the report server. 7. Submit the report to the report server. 8. Open the rendered PDF in a new browser window. | Are any mandatory fields blank? (-> error, stop). Is From Date blank individually? (-> error, stop). Is To Date before From Date? (-> error, stop). Does an unexpected error occur during report submission? (-> show error, stop). | PDF report generated and opened in browser; or error message shown and submit cancelled. |
| WF-004 | Form Exit | User presses the Exit key (KEY-EXIT trigger fires) | 1. Close the screen immediately without validating or saving any entries. 2. Clear the module name and action label from the database session context. | None. | Screen closed; session context cleared. |
| WF-005 | Form Clear and Reset | User presses the Clear Form key (KEY-CLRFRM trigger fires) | 1. Clear all field values from the screen without saving. 2. Maximise the main application window and the form window. 3. Retrieve and display the current copyright declaration text. 4. Reset the screen title to the standard label. | None. | Screen cleared; windows maximised; copyright refreshed; title reset. |
| WF-006 | Error Interception and User Notification | A system or database error occurs while the user is working on the screen (ON-ERROR trigger fires) | 1. Check error code: if invalid date (50004) -> display date-invalid message. 2. If date-format error (50025/50026) -> display format-guidance message. 3. If non-numeric in numeric field (40209/50016) -> display numeric-only message. 4. If field-level validation error (40207) -> display Forms error text. 5. If child-record integrity error (DB -02292) -> raise application error E0088. 6. If concurrent-update conflict (40654-40659) -> display conflict message and rollback. 7. If other database error (sqlcode ≠ 0) -> display database error text and rollback. 8. If informational code (40401/40405) -> silently ignore. | Which error code is active? Each branch maps to a specific user message or silent suppression. | User sees a relevant, plain-language error message and processing stops; or message is silently suppressed. |
| WF-007 | System Message Reformatting | The form generates a message event with code 40209 or 40207 (ON-MESSAGE trigger fires) | 1. Intercept the message event. 2. Reformat the message as type-code-text string. 3. Display the reformatted message and suppress the default display. | Is the message code 40209 or 40207? If yes, reformat and display; if no, take no action. | Reformatted message shown to user; or message event passed to default handling. |

**Total Workflows Identified: 7**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | Trigger: WHEN-VALIDATE-ITEM in CB_BLK.DEALER | /api/v1/pld/check_null | When the Dealer field is empty, then an error is raised and navigation is blocked until a value is entered |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT2, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.FROM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.TO_DATE | /api/v1/pld/disp_text | Presents an alert dialog with a supplied message and title to communicate errors or information to the user |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a known error code is encountered during form error handling, then the corresponding message is displayed and execution is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_nsc_summ_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_nsc_summ_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| No-Show AMC Enquiry - VH_AMC_ENQ | Relational database table (SELECT) | Retrieves open no-show customer AMC enquiry records for the CSV extract | Form -> Database: filter parameters (date range, location, dealer group, principal, status = "O"); Database -> Form: enquiry rows with customer, vehicle, package, and status details | The query is embedded in the dynamic SQL built by the SUBMIT2 button; errors are caught by the ON-ERROR trigger and displayed to the user |
| Dealer Location - MULDMS.AM_DEALER_LOC | Relational database table (SELECT) | Resolves the location code on each enquiry row to a human-readable location description | Form -> Database: parent_group, dealer_map_cd, loc_cd keys; Database -> Form: location description | As above - caught by ON-ERROR |
| Enquiry Status List - MULDMS.AM_LIST_RANGE | Relational database table (SELECT) | Resolves the enquiry status code to a human-readable status label for the extract output | Form -> Database: principal_map_cd, list_name = "AMC_ENQSTATUS", list_code (status value); Database -> Form: status description | As above - caught by ON-ERROR |
| Vehicle Master - GM_VIN | Relational database table (SELECT) | Joins to validate each enquiry row against a known vehicle record under the correct manufacturer principal | Form -> Database: VIN value, principal_map_cd = 1; Database -> Form: joined vehicle row | As above - caught by ON-ERROR |
| AMC Package Description - VM_AMC_PKG | Relational database table (SELECT) | Resolves the AMC package code on each enquiry row to a human-readable package description | Form -> Database: pkg_code, principal_map_cd = 1; Database -> Form: package description | As above - caught by ON-ERROR |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report submission (RUN_REPORT_OBJECT / WEB.SHOW_DOCUMENT) | Receives the No-Show Customer Summary report run request and returns a rendered PDF; the report server name is read from the session global at runtime | Oracle Reports HTTP | Report server URL constructed as `/reports/rwservlet/getjobid{jobId}?server={serverName}` | Form -> Reports Server: report filename (vr_nsc_summ), output format (PDF), filter parameters (principal, date range, location, dealer); Reports Server -> Browser: PDF document URL | Success: report job ID returned and PDF opened in browser; Error: exception caught in SUBMIT button handler - database error text shown as system message |
| Report Server File Output Path | Text file read (TEXT_IO) | Provides the URL base path for the server-side CSV output directory so the generated CSV can be opened in the browser | Local file read on the Oracle Forms application server | `/reports/DMS/excelpath.txt` | File -> Form: URL base path string; Form uses it to construct the browser-accessible URL for the generated CSV file | Success: path string read and used; Error: exception caught in VIEW_EXCEL_REP - *"Error  -"* followed by the error code and error text is displayed |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| vr_nsc_summ | Configured report server (read from session global `REP_SERVER` at runtime) | P_PRINCIPAL (manufacturer principal), P_FROM_DATE (start date), P_TO_DATE (end date + 1 day), P_LOC_CD (location code), P_DEALER (dealer code) | PDF | CALL_REPORT program unit called from WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT) |
| rep.rdf | Configured report server (read from session global `REP_SERVER` at runtime) | P_PRINCIPAL (manufacturer principal), P_FROM_DATE (start date), P_TO_DATE (end date + 1 day), P_LOC_CD (location code), P_DEALER (dealer code) | PDF | CALL_REPORT program unit - declarative report object `REPORT_CALL` whose source file is `rep.rdf`; located via `Find_Report_Object('REPORT_CALL')` and executed via `RUN_REPORT_OBJECT` |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_NSC_SUMM form.

### 21.1 Catalogue Index

8 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT) | CALL_REPORT |
| [SP-002](#SP-002--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-003](#SP-003--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-004](#SP-004--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-005](#SP-005--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-006](#SP-006--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-007](#SP-007--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-008](#SP-008--SF_GET_DEALER_NAME) | SF_GET_DEALER_NAME |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

DD-MM-YYYY (N/A / CN_MAIN)

---

**Purpose**

Configures and submits the No-Show Customer Summary PDF report to the Oracle Reports server using the filter criteria supplied by the user, then opens the rendered PDF in the user's browser. The procedure acts as the bridge between the user's report request (principal, date range, location, and dealer) and the report server, ensuring the report is produced in the correct format and made immediately available for viewing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | VARCHAR2 | IN |
| p_from_date | DATE | IN |
| p_to_date | DATE | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise local variables, including capturing the configured report server name from the session global `REP_SERVER`.
- Step 2 - Locate the report object registered under the name `REPORT_CALL` in the current form session to obtain its runtime handle.
- Step 3 - Set the report filename to `vr_nsc_summ`, identifying the No-Show Customer Summary report definition on the report server.
- Step 4 - Set the report output format to PDF so the generated report can be viewed directly in the user's browser.
- Step 5 - Apply the user's filter parameters to the report via the `Report_Other` property: principal code (cast to number), start date, end date, location code, and dealer code. Also set the destination type to FILE, the rendering mode to BITMAP, and suppress blank pages.
- Step 6 - Set the report server property on the report object to the server name captured in Step 1, routing the job to the correct server.
- Step 7 - Submit the report job to the report server and capture the unique job identifier string returned.
- Step 8 - Extract the numeric portion of the job identifier (the substring following the last underscore) and construct the report retrieval URL using the `/reports/rwservlet/getjobid` endpoint and the server name.
- Step 9 - Open the constructed URL in a new browser window (`_blank`) so the user can immediately view or save the completed PDF report.

---
**Decision Points**

No conditional branches exist in the procedure body. All steps execute unconditionally once the procedure is invoked; error handling is delegated to the calling trigger's exception handler.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report output format is always PDF; this is hard-coded via `Report_Desformat = 'PDF'`.
- BR-002 - The report filename is always set to `vr_nsc_summ`, which maps to the No-Show Customer Summary report definition on the server.
- BR-003 - The report server is always taken from the session global `REP_SERVER`; the server name is not hard-coded in the procedure.
- BR-004 - The principal parameter is explicitly cast to a number (`TO_NUMBER(p_principal)`) before being passed to the report, enforcing that only valid numeric principal codes are accepted.
- BR-005 - The report destination type is always FILE and the rendering mode is always BITMAP with blank pages suppressed; these settings are hard-coded in the `Report_Other` property string.

---
**Implementation Logic**

```plsql
PROCEDURE Call_Report(p_principal VARCHAR2,p_from_date DATE,p_to_date DATE,p_loc_cd VARCHAR2, p_dealer VARCHAR2) IS
 --Call_Report(:global.principal,:cb_blk.FROM_DATE,:cb_blk.TO_DATE,:cb_blk.DEALER);                                 
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);

Begin 
	
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'vr_nsc_summ';

		Set_Report_Object_Property(repid,Report_Desformat,'PDF');
	  
	  Set_Report_Object_Property(repid,Report_Other,' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_FROM_DATE='||p_from_date||
                                                  ' P_TO_DATE='||p_to_date||
                                                  ' P_LOC_CD='||p_loc_cd||
                                                  ' P_DEALER='||p_dealer||
                                                  ' REPORT_DESTYPE =FILE'||
                                                  ' MODE=BITMAP BLANKPAGES=NO');

		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
END;
```

#### SP-002 - VIEW_EXCEL_REP

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Accepts a SQL query, a column name, and an optional filename, executes the query to retrieve data into an in-memory record group, writes the results row by row to a CSV file on the application server, and opens the file in the user's browser for download. The procedure handles filename path issues caused by spaces, oversized result sets exceeding 65,535 rows, and runtime errors, ensuring the user receives a usable export or a clear error message.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the logged-in user's identifier from the global variable ':global.userid' and construct the output filename by appending the current date-time stamp in the format YYYYMMDDHHMISS and the '.csv' extension.
- Step 2 - If the constructed filename is not null, assign it to the working FILENAME variable (the null branch performs no action).
- Step 3 - If the FILENAME path contains a space character, redirect the file to the C drive root by stripping all folder path components and display the message *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*
- Step 4 - Check whether a record group named 'DataRecordSet' already exists in the session using FIND_GROUP; if it does (ID is not null), delete it with DELETE_GROUP to avoid conflicts.
- Step 5 - Create a new in-memory record group from the supplied SQL query using CREATE_GROUP_FROM_QUERY, then populate it by executing POPULATE_GROUP.
- Step 6 - Count the number of rows returned using GET_GROUP_ROW_COUNT. If the count exceeds 65,536, display the message *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*, clear the message, and cap the row count at 65,535.
- Step 7 - Construct the server-side file path by combining the fixed directory '/iashome/ias/reports/printer/' with the base filename (stripping any folder prefix).
- Step 8 - Open the configuration file '/reports/DMS/excelpath.txt' for reading using TEXT_IO.FOPEN, read the URL base path with TEXT_IO.GET_LINE, and close the configuration file.
- Step 9 - Construct the full browser-accessible URL by concatenating the URL base path read in Step 8 with the base filename.
- Step 10 - Open the server-side output file for writing using TEXT_IO.FOPEN with mode 'W'.
- Step 11 - Locate the target column in the record group using FIND_COLUMN with the composite name 'DataRecordSet.<p_column_name>'.
- Step 12 - Iterate through each row up to the (possibly capped) row count, retrieve the cell value using GET_GROUP_CHAR_CELL, and write each value as a line to the CSV file using TEXT_IO.PUT_LINE.
- Step 13 - Close the output CSV file using TEXT_IO.FCLOSE.
- Step 14 - Open the constructed browser URL in a new browser window using WEB.SHOW_DOCUMENT with target '_blank'.
- Step 15 - If any exception occurs during the above steps, display the message *"Error  -"* followed by the error code and error text, then raise FORM_TRIGGER_FAILURE to halt processing.

---
**Decision Points**

DP-001

Condition: The constructed FILENAME path contains a space character (INSTR(FILENAME,' ') > 0)

TRUE: Strip all folder path components, redirect the filename to the C drive root, and display the space-path redirection message to the user.

FALSE: Use the filename as constructed without modification.

DP-002

Condition: A record group named 'DataRecordSet' already exists in the session (FIND_GROUP returns a non-null ID)

TRUE: Delete the existing record group using DELETE_GROUP before creating a new one.

FALSE: Proceed directly to create the new record group.

DP-003

Condition: The query result row count exceeds 65,536 rows

TRUE: Display the row-count truncation message, clear the message, and cap the processing count at 65,535.

FALSE: Process all rows returned by the query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output filename is always auto-generated from the session user ID (read from ':global.userid') and the current timestamp in the format YYYYMMDDHHMISS with a '.csv' extension; no externally supplied filename is used.
- BR-002 - If the generated filename path contains a space character, the file is unconditionally redirected to the C drive root and the user is informed with the space-path message.
- BR-003 - The maximum number of rows written to the CSV file is 65,535; any result set larger than 65,536 rows is silently truncated to 65,535 rows and the user is notified.
- BR-004 - The browser-accessible URL base path for the output directory is read at runtime from the server configuration file '/reports/DMS/excelpath.txt' rather than being hard-coded, allowing the deployment path to be changed without modifying the procedure.
- BR-005 - Only a single named column (identified by p_column_name) is written to the CSV file per invocation; multi-column exports require separate calls or a query that concatenates columns.
- BR-006 - On any unhandled exception, the procedure displays the Oracle error code and error text to the user and raises FORM_TRIGGER_FAILURE, preventing silent failure.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile        varchar2(150);
	lv_user       varchar2(150);
	l_Old_URL     varchar2(500);	
		l_new_URL   varchar2(500);	
	v_string      varchar2(5000);
	bin_str       varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;
```

#### SP-003 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: FT_CANCEL]
- vr_nsc_summ_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function is used by cancellation and deletion triggers to obtain explicit user confirmation before proceeding with a destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value supplied in confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed against the constant ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (affirmative confirmation), or return 0 for any other button press (non-confirmation).

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the user selected the first/affirmative button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the calling trigger (FT_CANCEL or FT_DEL) that the user confirmed the action.

FALSE:
The function returns 0, signalling to the calling trigger that the user did not confirm the action and the operation should not proceed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined alert named AL_CONFIRM; the function sets its message text dynamically at runtime rather than relying on a static design-time message.
- BR-002 - Only ALERT_BUTTON1 constitutes a positive confirmation; any other button response (e.g. Cancel or Close) is treated as a rejection and returns 0.
- BR-003 - The function must be invoked with a non-null, meaningful confirmation message so that the user is presented with context-appropriate text before committing to the cancel or delete action.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-004 - GENERAL.CHECK_NULL

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

DD-MM-YYYY (N/A / CN_MAIN)

---

**Purpose**

Validates that a required field has not been left blank. If the supplied field value is null, displays an error message to the user identifying which field needs to be completed and stops further processing. This procedure is the standard mandatory-field null-check used throughout the form for fields that must be non-null before the user can proceed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value to be checked and the business label identifying the field.
- Step 2 - Construct the error message text as "Enter a valid " followed by the field's business label.
- Step 3 - Check whether the supplied field value is null.
- Step 4 - If the value is null, call GENERAL.DISP_TEXT with the error message text at severity "Error" to display the message to the user, then raise FORM_TRIGGER_FAILURE to stop navigation until the user provides a value.
- Step 5 - If the value is not null, exit normally without displaying any message.

---
**Decision Points**

DP-001

Condition: The supplied field value is null

TRUE: Display the "Enter a valid {column_title}" error message and raise FORM_TRIGGER_FAILURE to halt navigation.

FALSE: Exit the procedure normally; no error is raised.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message is always formatted as "Enter a valid " followed by the field's business label, ensuring the user knows which field is missing.
- BR-002 - If the field is null, FORM_TRIGGER_FAILURE is always raised after displaying the error; the user cannot proceed until a value is entered.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-005 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_nsc_summ_fmb.xml [Trigger: FT_INSERT]
- vr_nsc_summ_fmb.xml [Trigger: ON-ERROR]
- vr_nsc_summ_fmb.xml [Trigger: ON-MESSAGE]
- vr_nsc_summ_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_nsc_summ_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

DD-MM-YYYY (N/A / CN_MAIN)

---

**Purpose**

Displays a labelled alert dialog to the user with a supplied message text and a title. Selects the alert style (error vs. informational) based on the title supplied, sets the alert's title and message text, then shows the alert. This procedure is the central user notification mechanism used across all validation, error-handling, and message-interception flows on the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message text and the severity label from the calling trigger or procedure.
- Step 2 - Determine which alert to use: if the severity label is "ERROR" (case-insensitive), select the error-style alert (AL_ERRINFO); otherwise select the informational-style alert (AL_NOTE).
- Step 3 - Set the selected alert's title to the supplied severity label.
- Step 4 - Set the selected alert's message text to the supplied message text.
- Step 5 - Display the alert to the user and wait for the user to dismiss it.

---
**Decision Points**

DP-001

Condition: The title_string parameter value is "ERROR" (case-insensitive)

TRUE: Use the AL_ERRINFO alert (error-style visual).

FALSE: Use the AL_NOTE alert (informational/note-style visual).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error-severity messages always use the AL_ERRINFO alert; all other messages use AL_NOTE.
- BR-002 - The alert title is always set to the supplied title_string, making the severity label visible to the user.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-006 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Raises a standard application-level error identified by an error code. Constructs the error message text by combining the error code with any pre-registered message text, then displays it using the appropriate severity style (Error, Note, or Caution) and, for error-type messages, raises FORM_TRIGGER_FAILURE to stop processing. This procedure is the centralised application error-raising mechanism for the form's ON-ERROR handler.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the application error code to be raised.
- Step 2 - Construct the display message text by combining the error code with the message text variable (note: the call to GENERAL.get_message to populate mesg_text is commented out, so mesg_text is always empty at runtime; the message text is the error code followed by " : ").
- Step 3 - Determine the message type from the mesg_type variable (note: mesg_type is also unset at runtime because get_message is commented out, so the procedure falls through all conditions without displaying any alert).
- Step 4 - If the message type is "E" (Error), set the title to "Error", display the message via GENERAL.DISP_TEXT, and raise FORM_TRIGGER_FAILURE to stop processing.
- Step 5 - If the message type is "N" (Note), set the title to "Note" and display the message via GENERAL.DISP_TEXT without stopping processing.
- Step 6 - If the message type is "C" (Caution), set the title to "Caution" and display the message via GENERAL.DISP_TEXT without stopping processing.

---
**Decision Points**

DP-001

Condition: The message type resolved from the error code is "E" (Error)

TRUE: Display the message with "Error" severity and raise FORM_TRIGGER_FAILURE.

FALSE: Continue to check the next condition.

DP-002

Condition: The message type resolved from the error code is "N" (Note)

TRUE: Display the message with "Note" severity; do not raise FORM_TRIGGER_FAILURE.

FALSE: Continue to check the next condition.

DP-003

Condition: The message type resolved from the error code is "C" (Caution)

TRUE: Display the message with "Caution" severity; do not raise FORM_TRIGGER_FAILURE.

FALSE: No action is taken; the procedure exits without displaying a message.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Only error-type messages (type "E") cause FORM_TRIGGER_FAILURE to be raised; note and caution messages display without stopping processing.
- BR-002 - The message lookup (GENERAL.get_message) is commented out in the current implementation; the mesg_type and mesg_text variables are always unset at runtime, meaning no message is actually displayed through this procedure at runtime.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-007 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: KEY-CLRFRM]
- vr_nsc_summ_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

DD-MM-YYYY (N/A / CN_MAIN)

---

**Purpose**

Returns the current financial-year copyright declaration text for display on the No-Show Customer Summary screen. The function determines the correct copyright year based on the current calendar month: if the current month is January, February, or March (which fall within the prior financial year), the prior calendar year is used; otherwise the current calendar year is used. The returned string is assigned to the copyright display area both when the form is cleared (KEY-CLRFRM) and when the form is first opened (WHEN-NEW-FORM-INSTANCE).

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current database date by assigning SYSDATE to a local date variable.
- Step 2 - Extract the three-letter month abbreviation from the captured date and check whether it is JAN, FEB, or MAR.
- Step 3 - If the month is JAN, FEB, or MAR, construct the copyright string as '- ' concatenated with the current four-digit year minus 1, followed by ' Maruti Suzuki India Limited '.
- Step 4 - If the month is any other month (APR through DEC), construct the copyright string as '- ' concatenated with the current four-digit year, followed by ' Maruti Suzuki India Limited '.
- Step 5 - Return the constructed copyright string to the calling trigger (KEY-CLRFRM or WHEN-NEW-FORM-INSTANCE) for display on the screen.

---
**Decision Points**

DP-001

Condition: The three-letter abbreviation of the current calendar month (derived from SYSDATE) is JAN, FEB, or MAR.

TRUE: Use the prior calendar year (current RRRR minus 1) in the copyright string.

FALSE: Use the current calendar year (RRRR) in the copyright string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The financial year runs from April to March; months January, February, and March belong to the prior financial year, so the copyright year displayed is the previous calendar year during those months.
- BR-002 - The copyright owner is always 'Maruti Suzuki India Limited'; this value is hard-coded in the function and is never derived from a database table or parameter.
- BR-003 - The function is invoked on both form initialisation (WHEN-NEW-FORM-INSTANCE) and form clear (KEY-CLRFRM), ensuring the copyright text is always current regardless of how the screen is refreshed.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-008 - SF_GET_DEALER_NAME

**Invoked From:**

- vr_nsc_summ_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

DD-MM-YYYY (N/A / CN_MAIN)

---

**Purpose**

SF_GET_DEALER_NAME is a scalar function that retrieves the dealer name associated with a specific dealer location. Given a parent group, a dealer mapping code, and a location code, it queries the AM_DEALER_LOC table and returns the corresponding dealer_name value. It is invoked during form initialisation of the NSC Summary screen to populate or resolve dealer identity for display purposes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | VARCHAR2 | IN |
| p_dealer_map_cd | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: p_parent_group (VARCHAR2), p_dealer_map_cd (NUMBER), and p_loc_cd (VARCHAR2), which together uniquely identify a dealer location record.
- Step 2 - Query the AM_DEALER_LOC table, selecting the dealer_name column where parent_group matches p_parent_group, dealer_map_cd matches p_dealer_map_cd, and loc_cd matches p_loc_cd.
- Step 3 - Store the retrieved dealer_name value in the local variable lv_loc_desc.
- Step 4 - Return lv_loc_desc to the caller as the function result.
- Step 5 - If any exception occurs during the SELECT (e.g., no data found, multiple rows, or any other runtime error), set lv_loc_desc to NULL and return NULL to the caller.

---
**Decision Points**

DP-001

Condition: The SELECT statement against AM_DEALER_LOC executes without raising an exception (i.e., exactly one matching row exists for the supplied p_parent_group, p_dealer_map_cd, and p_loc_cd combination).

TRUE: The dealer_name value is stored in lv_loc_desc and returned to the caller.

FALSE: The WHEN OTHERS exception handler is triggered; lv_loc_desc is set to NULL and NULL is returned to the caller.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - The combination of parent_group, dealer_map_cd, and loc_cd must uniquely identify a single record in AM_DEALER_LOC; the function is designed to return one dealer name per call.
- BR-002 - If no matching dealer location record exists, or if any runtime error occurs during retrieval, the function returns NULL rather than raising an exception to the calling context, ensuring form initialisation is not interrupted by a missing dealer name.
- BR-003 - The returned dealer name is sourced exclusively from the AM_DEALER_LOC.dealer_name column; no derivation, concatenation, or transformation is applied to the value before it is returned.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION Sf_Get_Dealer_Name
(p_parent_group VARCHAR2,
p_dealer_map_cd NUMBER,
p_loc_cd VARCHAR2)
RETURN VARCHAR2
IS
lv_loc_desc AM_DEALER_LOC.dealer_name%TYPE;
BEGIN
SELECT dealer_name
INTO lv_loc_desc
FROM AM_DEALER_LOC
WHERE parent_group=p_parent_group
AND dealer_map_cd=p_dealer_map_cd
AND loc_cd=p_loc_cd;
RETURN lv_loc_desc;

EXCEPTION
WHEN OTHERS THEN
lv_loc_desc:=NULL;
RETURN lv_loc_desc;
END;

```

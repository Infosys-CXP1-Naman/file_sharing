# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Business Scenarios - How the results display differs by report type
    - Requirement ID: BR-006
    - Business Scenarios - How search results differ by report type
    - Requirement ID: BR-007
    - Business Scenarios - How the export content differs by report type
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Vehicle Hold-Up Header - VH_RO_HOLD_UP
    - Vehicle Hold-Up Detail - VD_RO_HOLD_UP
    - Parts Requisition - VT_REQ
    - Parts Master - PM_PART
    - Vehicle Model Master - GM_MOD
    - Reference List - AM_LIST
    - Location Master - AM_DEALER_LOC / AM_USER_DEALER_MASTER
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Criteria (User - before running a search or export)
    - Session and Global Context (System - set at form startup)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_VH (29 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL
    - DBMS_APPLICATION_INFO
    - POPULATE_DETAILS
    - VIEW_EXCEL_REPORT_NEW
    - VIEW_EXCEL_REP
    - CLEAR_ITEMS
    - WEBUTIL_CORE
    - WEBUTIL (C API)
    - WEB
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - POPULATE_DETAILS
    - SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-003 - D2KWUTIL.CHOOSEFILE
    - SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-009 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-011 - D2KWUTIL.SAVE_FILE
    - SP-012 - D2KWUTIL.TRANSLATETYPE
    - SP-013 - GENERAL.ASK_CONFIRM
    - SP-014 - GENERAL.DISP_TEXT
    - SP-015 - GENERAL.L_POP_LIST_ITEM
    - SP-016 - GENERAL.RAISE_ERROR
    - SP-017 - WEBUTIL.BLOCKING
    - SP-018 - WEBUTIL.CHECKLIBS
    - SP-019 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-020 - WEBUTIL.CLOSEBLOB
    - SP-021 - WEBUTIL.CLOSEFILE
    - SP-022 - WEBUTIL.DOWNLOADFROMURL
    - SP-023 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-024 - WEBUTIL.ERROR
    - SP-025 - WEBUTIL.ERRORALERT
    - SP-026 - WEBUTIL.EXECUTE
    - SP-027 - WEBUTIL.FCLOSE
    - SP-028 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-029 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-030 - WEBUTIL.FOPEN
    - SP-031 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-032 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-033 - WEBUTIL.GETCLIENTSETTING
    - SP-034 - WEBUTIL.GETIMPLCLASS
    - SP-035 - WEBUTIL.GETLASTERROR
    - SP-036 - WEBUTIL.GETLASTERRORARGS
    - SP-037 - WEBUTIL.GETNUMBER
    - SP-038 - WEBUTIL.GETOSFAMILY
    - SP-039 - WEBUTIL.GETOUTPUT
    - SP-040 - WEBUTIL.GETPROPERTY
    - SP-041 - WEBUTIL.GETSTRING
    - SP-042 - WEBUTIL.GETVAR
    - SP-043 - WEBUTIL.GET_LINE
    - SP-044 - WEBUTIL.GET_RETURN_CODE
    - SP-045 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-046 - WEBUTIL.HOST
    - SP-047 - WEBUTIL.ID_NULL
    - SP-048 - WEBUTIL.INIT
    - SP-049 - WEBUTIL.INITWEBUTIL
    - SP-050 - WEBUTIL.ISERROR
    - SP-051 - WEBUTIL.IS_OPEN
    - SP-052 - WEBUTIL.LENGTH
    - SP-053 - WEBUTIL.LOG
    - SP-054 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-055 - WEBUTIL.PUTF
    - SP-056 - WEBUTIL.PUT_LINE
    - SP-057 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-058 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-059 - WEBUTIL.REGISTERBEAN
    - SP-060 - WEBUTIL.REGISTER_FUNCTION
    - SP-061 - WEBUTIL.RELEASE_PROCESS
    - SP-062 - WEBUTIL.SETCLIENTSETTING
    - SP-063 - WEBUTIL.SETDATA
    - SP-064 - WEBUTIL.SETPROPERTY
    - SP-065 - WEBUTIL.SHOWBEANS
    - SP-066 - WEBUTIL.URL_TO_CLIENT
    - SP-067 - WEBUTIL.WRITEDATA
    - SP-068 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-069 - ADD_ERROR
    - SP-070 - ADD_EXTERNAL_ERRORS
    - SP-071 - BOOLTOCHAR
    - SP-072 - CLEAN_ERROR_STACK
    - SP-073 - DEBUGLOG
    - SP-074 - GET_ENVIRONMENT_STRING
    - SP-075 - GET_TEMP_DIRECTORY
    - SP-076 - GET_WINDOWS_DIRECTORY
    - SP-077 - READ_REGISTRY
    - SP-078 - REGISTER_FUNCTION_CALL
    - SP-079 - SETDEBUG
    - SP-080 - STRIPDIRSEP
    - SP-081 - VIEW_EXCEL_REPORT_NEW
    - SP-082 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PI_VEH_HOLD_UP - Business Requirements Document |
| Form Module Name | PI_VEH_HOLD_UP |
| Document Version | 1.0 |
| Date Created | August 19, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 19, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pi_veh_hold_up Vehicle Pending in Workshop for want of Parts form, its purpose, and roles referenced in the module.*

The **pi_veh_hold_up** Oracle Forms module is the Dealer Management System **Vehicle Pending in Workshop for want of Parts** enquiry screen. A service workshop user opens the screen, selects their authorized workshop location, specifies a hold-up reference date, chooses a service type (Accidental, Non-Accidental, or All), and optionally switches between a Summary and a Detail view. When the user triggers the search, the system verifies that hold-up records exist for the chosen date and location, then loads either a service-category summary - showing how many vehicles have been waiting for parts for more than 1, 3, or 7 days - or a full per-vehicle detail list showing each job card, the parts requested, requisition status, quantities issued, stock availability, and the purchase order number. Users can also export the results directly to a CSV file for offline analysis. The form is read-only and contains no data-entry or save operations.

### Key Stakeholders

*Who uses pi_veh_hold_up*

| Stakeholder | Role |
| :--- | :--- |
| **Service Workshop User** | **Primary interactive user** of pi_veh_hold_up. Selects the workshop location and date, triggers the search, reviews hold-up data on screen, and exports results to Excel as needed. |
| **Parts Manager / Workshop Manager** | Reviews hold-up summary and detail to prioritize parts procurement and expedite workshop throughput; does not interact with the form directly. |
| **Vehicle Owner / Customer** | Owner of the vehicle pending in the workshop; captured indirectly via job card data displayed on screen. Does not use the form. |

---

---

## 3. System Context

*Describes the pi_veh_hold_up module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pi_veh_hold_up** module is the Dealer Management System **Vehicle Pending in Workshop for want of Parts** enquiry screen. It sits within the after-sales service management area and provides workshop and parts staff with visibility into vehicles that are held up in the workshop because required parts have not yet been issued. The form reads from hold-up records created by upstream workshop and parts requisition processes; it does not create or modify any records itself.

**System purpose:** Allow authorised workshop users to select a location, date, and service type, retrieve hold-up data for vehicles awaiting parts, view a summary count by service category or a full per-vehicle detail with requisition and stock information, and export the data as a CSV file for further analysis.

**In scope:**

- Authorize the user to their allocated workshop locations via a location selector
- Validate search criteria - hold-up date (must be present and not in the future) and service type (Accidental, Non-Accidental, or All)
- Retrieve hold-up summary data showing vehicle counts pending more than 1, 3, and 7 days per service category
- Retrieve hold-up detail data showing per-vehicle job card, part number, requisition number, quantities requested and issued, live and dead stock availability, availability source, and purchase order number
- Switch the view between Summary and Detail displays without re-entering search criteria
- Export hold-up data to a CSV file and open it in the browser for offline analysis
- Display vehicle model description and service type description from master data lookups

**Process Name:** Vehicle Hold-Up Enquiry

**Process Owner:** Workshop / Parts Manager

**Process Objective:** Select a workshop location, date, and service type, retrieve vehicles currently held up for want of parts, review pending counts and part availability details, and optionally export the results to a file for follow-up action.

**Process Trigger:** A workshop user or parts manager needs to identify vehicles that are awaiting parts as of a given date in order to plan procurement and expedite service delivery.

**Process Flow:**

The complete vehicle hold-up enquiry process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The user opens the Vehicle Pending in Workshop for want of Parts screen.
         The search criteria area is displayed with default service type set to All (Y)
         and report type defaulting to Detail.

STEP 2 ── SELECT WORKSHOP LOCATION
         The user opens the location selector (LOV) to choose their authorized
         dealer workshop location.
         The system presents only locations assigned to the logged-in user
         for the current principal, limited to 2S/3S spares dealer types.

STEP 3 ── LOCATION CONFIRMED
         The user selects a location; the system populates the location code and
         location description fields from the selected entry.

STEP 4 ── ENTER HOLD-UP DATE
         The user enters the hold-up reference date (format DD/MM/YYYY).
         The date field accepts manual entry and validates the format.

STEP 5 ── VALIDATE HOLD-UP DATE
         The system validates that the hold-up date is not empty.
         ├── If empty: error message is displayed and the user must correct it.
         └── If date is in the future: error message is displayed and the user must correct it.

STEP 6 ── SELECT SERVICE TYPE
         The user selects the service type from the drop-down list:
         Accidental (body and paint), Non-Accidental (non-BANDP), or All.
         ├── If an invalid or null value is present: error is displayed.
         └── If valid: proceeds to report type selection.

STEP 7 ── SELECT REPORT TYPE
         The user selects the report view: Summary or Detail.
         When the selection changes, the previously loaded result block is cleared.

STEP 8 ── TRIGGER SEARCH
         The user clicks the Search button.
         The system checks that the hold-up date is not null.

STEP 9 ── VALIDATE DATA AVAILABILITY
         The system queries the hold-up summary table to confirm records exist
         for the selected date, dealer location, and location code.
         ├── If no records exist: error message is displayed; search aborted.
         └── If records exist: proceeds to populate results.

STEP 10 ── POPULATE RESULTS - SUMMARY VIEW (when Summary selected)
          The system loads the summary block with service category descriptions
          and counts of vehicles pending more than 1, 3, and 7 days per category.
          Totals are calculated and displayed at the bottom of the summary grid.

STEP 11 ── POPULATE RESULTS - DETAIL VIEW (when Detail selected)
          The system loads the detail block with one row per vehicle per part,
          showing job card number, vehicle registration, pending days, job card date,
          part number, requisition number, dates, quantities, stock availability,
          and purchase order number.

STEP 12 ── LOOKUP MODEL DESCRIPTION
          For each detail record, the system resolves the vehicle model code to its
          model description from the vehicle model master.

STEP 13 ── LOOKUP SERVICE TYPE DESCRIPTION
          For each detail record, the system resolves the service category code to
          its description from the application master list.

STEP 14 ── LOOKUP PART DESCRIPTION
          For each detail record, the system resolves the part number to its
          description from the parts master.

STEP 15 ── LOOKUP AVAILABILITY SOURCE DESCRIPTION
          For each detail record, the system resolves the part availability source
          code to its description from the application master list.

STEP 16 ── RESULTS DISPLAYED
          The selected view (Summary or Detail) is populated and displayed.
          The user can scroll through the results or switch views by changing the
          Report Type drop-down, which clears the displayed block automatically.

STEP 17 ── EXPORT TO EXCEL (optional)
          The user clicks Export to Excel.
          The system re-validates the hold-up date and data availability.

STEP 18 ── BUILD EXPORT QUERY
          ├── SUMMARY EXPORT: builds a CSV with service type, and counts >1 day,
          │   >3 days, and >7 days per category.
          └── DETAIL EXPORT: builds a CSV with all detail fields including pending days,
              vehicle number, job card, model, service type, job card date, part number,
              part description, requisition details, quantities, stock flags, and order number.

STEP 19 ── GENERATE CSV FILE
          The system generates a CSV file named after the logged-in user and current
          timestamp, and opens it in the browser for download.

STEP 20 ── CLEAR FORM
          The user can clear the form at any time using the Clear button,
          which removes all loaded results and resets the criteria block.

STEP 21 ── EXIT
          The user exits the screen using the Exit button or keyboard shortcut.
          Application context information is cleared on exit.
```

**Major process interactions:**

- **Hold-up header and detail tables** - primary source of vehicle hold-up data; read-only by this screen
- **Application master list** - provides descriptions for service categories and part availability sources
- **Vehicle model master** - provides vehicle model descriptions for each hold-up record
- **Parts master** - provides part descriptions for each hold-up record
- **User-dealer authorization master** - controls which workshop locations the logged-in user may query
- **Excel export service** - generates and delivers CSV files to the user's browser for offline analysis

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Initialisation and Application Tracking Setup

**Business Description:**
When the vehicle parts hold-up enquiry form is opened, the system first registers the current session with the application monitoring framework before the screen appears, then completes a series of initialisation steps as the form loads. The monitoring registration ensures operational visibility into which users are accessing the hold-up enquiry module and when. The initialisation steps pre-fill default search criteria (yesterday's date as the default Hold Up Date), load the Status dropdown with the reference options applicable to the current organisation, and resolve the user's primary dealer location so that it is pre-selected on the search criteria screen. Together these steps ensure the user reaches a fully ready form with meaningful defaults already in place.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The user has successfully authenticated with the system and holds access rights to the vehicle parts hold-up enquiry module.

**Main Flow:**

**Step 1 - Application monitoring context is registered before the form opens**
Before the form is displayed to the user, the system registers the form's session identity with the application monitoring service. It sets the client information to `pi_veh_hold_up` and records the module name as `pi_veh_hold_up` with a blank action name. This registration happens silently before any screen is shown and ensures the session is identifiable in monitoring tools from the moment the form starts.

**Step 2 - Application identifier global is initialised and form defaults are set**
When the form first opens, the system sets the application identifier global (`global.app_id`) to `pi_veh_hold_up` so that the form can identify itself to downstream services throughout the session. The system also suppresses informational messages by raising the system message level, and pre-fills the Hold Up Date field with yesterday's date (today minus one day) so the user has an immediately usable search date without manual entry.

**Step 3 - Status dropdown list is populated from reference data**
The system calls the list-population routine with the `L_ITEM` record group, querying the reference code list (`am_list`) for control-point values applicable to the current principal organisation. The results are loaded into the Status field (`CB_DUMMY.STATUS`) dropdown, making the available status options ready for the user before the search criteria screen is displayed.

**Step 4 - User's default dealer location is resolved and pre-filled**
The system looks up the user's primary dealer location from the dealer and location reference data, matching on the authenticated user identity and the current principal organisation. It retrieves the location code, dealer mapping code, and location description and pre-fills the corresponding search criteria fields (`CB_LOC_CD`, `CB_DEALER_MAP_CD`, `CB_LOC_DESC`). If the primary location lookup fails, the system falls back to resolving the location using the global parent group, dealer, and location context values. If neither lookup succeeds, the location fields are left blank and the form opens without a pre-selected location.

**Alternative Flows:**

None evidenced beyond the location-lookup fallback described in Step 4.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Session Context (`DBMS_APPLICATION_INFO.SET_CLIENT_INFO`) | Auto-populated | System/session | N/A | N/A | Fixed value `pi_veh_hold_up` | Form startup (PRE-FORM) | System-set only; not user-editable | N/A |
| Module Registration (`DBMS_APPLICATION_INFO.SET_MODULE`) | Auto-populated | System/session | N/A | N/A | Module name `pi_veh_hold_up`, blank action name | Form startup (PRE-FORM) | System-set only; not user-editable | N/A |
| Application Identifier (`global.app_id`) | Auto-populated | Character | N/A | N/A | Fixed value `pi_veh_hold_up` | Form open (WHEN-NEW-FORM-INSTANCE) | System-set only; not user-editable | N/A |
| Hold Up Date (`CB_DUMMY.HOLD_UP_DATE`) | Auto-populated default | Date | DD/MM/RRRR | N/A | Yesterday's date (`trunc(sysdate-1)`) | Form open | Pre-filled; user may override | N/A |
| Status (`CB_DUMMY.STATUS`) | Auto-populated | List item | N/A | Record group `L_ITEM` (from `am_list` where `list_name = 'CEO_CTRL_POINT'`) | Control-point options for current principal | Form open | Populated from reference data; not directly editable | N/A |
| Location Code (`CB_DUMMY.CB_LOC_CD`) | Auto-populated | Character | N/A | Dealer location master (`am_dealer_loc`) | User's primary location code | Form open | System-resolved from user's dealer access | Left blank if lookup fails |
| Dealer Mapping Code (`CB_DUMMY.CB_DEALER_MAP_CD`) | Auto-populated | Character | N/A | Dealer location master (`am_dealer_loc`) | User's dealer mapping code | Form open | System-resolved from user's dealer access | Left blank if lookup fails |
| Location Description (`CB_DUMMY.CB_LOC_DESC`) | Auto-populated | Character | 200 | Dealer location master (`am_dealer_loc`) | Location description | Form open | System-resolved from user's dealer access | Left blank if lookup fails |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form-Level Error Handling and Error Message Display

**Business Description:**
When any error occurs while the user is working in the vehicle parts hold-up enquiry form, the system intercepts the error and presents it in a consistent, user-readable format rather than showing a raw system code. Different categories of error - data-entry format errors, record-locking conflicts, and general database errors - are each handled with an appropriate message, ensuring the user always knows what went wrong and can take corrective action.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The form is open and the user is performing an operation (entering data, querying, or navigating) when an error condition is raised by the system.

**Main Flow:**

**Step 1 - Referential-integrity violation is detected and a structured error message is shown**
If a database operation fails because it would break a related data constraint (specifically an Oracle integrity error -02292), the system calls the standard error-raising routine to present the appropriate business-level message to the user and stops further processing.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-008](#SP-008--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - raises a business-level error message corresponding to the error code provided; the form stops processing the current action and remains open so the user can correct the problem.
    * **Step 1** - Receive the business error code to be raised.
    * **Step 2** - Look up the corresponding user-readable error message for that code from the standard error message catalogue.
    * **Step 3** - Display the retrieved message to the user and halt current processing, leaving the form open for the user to take corrective action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential-integrity breach check | Database integrity constraint violation (-02292) - GENERAL.RAISE_ERROR [SP-008] | When a database action triggers a child-record constraint violation | Prevents saving data that would leave related records in an inconsistent state | Business-level error message displayed; user remains on the form to correct the data |

**Step 2 - Data-entry format and navigation errors are displayed and processing is halted**
For specific Oracle Forms error codes related to invalid data entry (codes 40209, 40207, 50026, 50004), the system displays the error type, code number, and error text in the message dialog via the text-display routine, then stops processing the triggering action. The user stays on the form to correct the problem.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays a message of the given severity (here "Error") in the standard message dialog; does not close the form.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Data-entry format error codes check | ON-ERROR trigger's own condition - error codes 40209, 40207, 50026, 50004 | When a data-entry or validation error fires with a code in the monitored set | Presents a readable description of the data-entry fault so the user can correct it | Error type, code, and text displayed via GENERAL.DISP_TEXT [SP-007]; processing halted; user remains on form |

**Step 3 - Record-locking conflict is detected, the transaction is rolled back, and the user is notified**
If another user has modified the same record since the current user last loaded it (Oracle Forms error codes 40654-40659), the system displays a fixed message instructing the user to re-query the record, rolls back any pending changes, and stops processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the record-locking advisory message to the user.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record-locking conflict detection | ON-ERROR trigger's own condition - error codes 40654, 40655, 40656, 40657, 40659 | When a concurrent record-update conflict is raised by the database | Protects data integrity by preventing the user from overwriting another user's changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* displayed; pending changes rolled back; processing halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Record locked or updated by another user - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; pending changes rolled back; user must re-query the record before making changes.

**Step 4 - Unhandled database errors are displayed and the transaction is rolled back**
For any remaining database error (where the SQL error code is non-zero and not otherwise intercepted), the system displays the database engine's own error message text via the text-display routine, rolls back any pending changes, and stops the current action.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the database error message text (the system's own error description) to the user.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unhandled database error catch-all | ON-ERROR trigger's own condition - SQL error code non-zero (after all specific checks) | When a database error is not covered by the specific intercepts above | Ensures the user always sees a meaningful error description rather than a silent failure | Database error text displayed; pending changes rolled back; processing halted |

**Step 5 - Informational navigation codes are silently suppressed**
For Oracle Forms informational status codes 40401 and 40405 (record-not-found and end-of-records navigation signals), the system takes no visible action - the user is not shown any message and no error is raised. These are normal navigation states, not errors.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-IC-01** - `error_code IN (40401, 40405)` - no message is displayed; normal record navigation or end-of-record set reached; silently suppressed.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) Database integrity error -02292 fires: GENERAL.RAISE_ERROR [SP-008] is called with error code `E0088`; structured business-level error message displayed; action halted.
- **BR-002-AF-02** - (from Step 4) SQL error code is zero (no actual database error): the trigger exits without taking any action; form processing continues normally.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Error Code (`ERROR_CODE`) | Auto-populated | Numeric | N/A | N/A | System-generated error code | An error condition must have been raised | Read-only system variable; evaluated by the error handler | N/A - itself the trigger of the handler |
| Error Text (`ERROR_TEXT`) | Auto-populated | Character | 200 | N/A | System-generated error description | An error condition must have been raised | Read-only system variable | N/A |
| Database Error Code (`DBMS_ERROR_CODE`) | Auto-populated | Numeric | N/A | N/A | Oracle database error code | An error condition must have been raised | Read-only system variable | N/A |
| Database Error Text (`DBMS_ERROR_TEXT`) | Auto-populated | Character | 200 | N/A | Oracle database error description | An error condition must have been raised | Read-only system variable | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Service Type Selection Validation on Search Criteria Screen

**Business Description:**
When the user changes the Service Type selection on the search criteria screen, the system validates that the selected value is one of the permitted service type options before allowing the user to proceed. If the user has provided an invalid or blank value, the system alerts the user and prevents progression until a correct selection is made. This ensures that hold-up data searches are always scoped to a recognised service type.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The search criteria screen is displayed and the user has moved away from the Service Type field after making a selection or entry.

**Main Flow:**

**Step 1 - Service type value is checked against the permitted options**
When the user leaves the Service Type field, the system first checks whether the selected value is one of the three accepted service type values. If the value is not one of the accepted options, the system displays an error message and prevents the user from continuing.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message at the specified severity and returns control to the form; the form remains open.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Service type must be a recognised option | WHEN-VALIDATE-ITEM on CB_DUMMY.SRV_TYPE - own condition `SRV_TYPE NOT IN ('A','N','Y')` | When the user leaves the Service Type field | Ensures only valid service type options drive the hold-up data query | *"Plase select service type from list"* displayed; processing halted; user remains on the field |

**Step 2 - Service type blank check**
Immediately after the permitted-option check, the system also confirms the Service Type field is not empty. If the field is blank, the system displays a separate mandatory-field error message and prevents the user from continuing.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the mandatory-field error message.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Service Type must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.SRV_TYPE - own condition `SRV_TYPE IS NULL` | When the user leaves the Service Type field with no value selected | Service Type is mandatory to scope the hold-up data search correctly | *"Service Type can not be null"* displayed; processing halted; user must select a service type before continuing |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Service type value is not one of the accepted options - *"Plase select service type from list"*; user must select a valid service type from the list before proceeding.
- **BR-003-ES-02** - Service Type field is blank - *"Service Type can not be null"*; user must make a selection before proceeding.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) Value is one of the three accepted options and is not blank: both checks pass; the form allows the user to continue to the next field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service Type (`SRV_TYPE`) | Mandatory | List item | N/A | N/A | Accepted values: All ('A'), Non-BANDP ('N'), BANDP ('Y') | Service Type field displayed on screen | Must be one of the three accepted values and must not be blank | *"Plase select service type from list"* if invalid; *"Service Type can not be null"* if blank |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Hold Up Date Validation

**Business Description:**
When the user enters a date in the Hold Up Date field on the search criteria screen and moves to the next field, the system validates that the date has been provided and that it does not fall in the future. Because the hold-up report is historical in nature - showing vehicles awaiting parts as of a specific past or current date - only today's date or an earlier date is meaningful. If the user enters a future date, or leaves the field empty, the system alerts the user and prevents the search from proceeding.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The search criteria screen is displayed and the user has typed a value into the Hold Up Date field and moved the cursor away.

**Main Flow:**

**Step 1 - Hold Up Date is checked: not null, then not in the future**
When the user leaves the Hold Up Date field, the system first checks whether the field has been filled in. If a date has been provided, the system then compares it against today's date. If the entered date is later than today, the system sets an alert message to inform the user that the date cannot be in the future, shows the alert dialog, and stops the user from continuing.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold Up Date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.HOLD_UP_DATE - own condition `HOLD_UP_DATE > sysdate` | When the user leaves the Hold Up Date field after entering a date | The hold-up report is retrospective; a future date would return no meaningful data | Alert shown: *"Hold Up Date cannot be greater than Current Date"*; processing halted; form trigger failure raised |

**Step 2 - Hold Up Date blank check**
If the Hold Up Date field is empty (the ELSE branch when no date was provided at all), the system displays a mandatory-field error message via the standard display routine and prevents the user from continuing.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the mandatory-field error message at "Error" severity; the form remains open.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold Up Date must not be blank | WHEN-VALIDATE-ITEM on CB_DUMMY.HOLD_UP_DATE - own condition `HOLD_UP_DATE IS NULL` (ELSE branch) | When the user leaves the Hold Up Date field without entering a date | Hold Up Date is required to identify which day's hold-up snapshot to retrieve | *"From Date can not be empty"* displayed via GENERAL.DISP_TEXT [SP-007]; processing halted; user must enter a valid date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Hold Up Date is in the future - *"Hold Up Date cannot be greater than Current Date"* (shown via alert dialog); processing halted; user must enter today's date or an earlier date.
- **BR-004-ES-02** - Hold Up Date is blank - *"From Date can not be empty"*; processing halted; user must enter a date before continuing.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) Date is provided and is on or before today: both checks pass; the form allows the user to continue to the next field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Hold Up Date (`HOLD_UP_DATE`) | Mandatory | Date | DD/MM/RRRR (max 12 chars) | N/A | N/A | Search criteria screen is open | Must be provided and must not be a future date | *"Hold Up Date cannot be greater than Current Date"* if future; *"From Date can not be empty"* if blank |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Report Type Selection Controls the Results Display Format

**Business Description:**
When the user changes the Report Type selection on the search criteria screen, the system immediately clears any results currently shown and switches the results area to match the newly chosen display format. Selecting the summary view clears and resets the summary results block, while selecting the detailed view clears and resets the detail results block. This ensures the results area always matches the type of report the user intends to run, and no stale data from a previous selection is left visible on screen.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The search criteria screen is displayed and a Report Type value is available for selection.

**Main Flow:**

**Step 1 - Report Type changes to Summary: summary results block is cleared**
When the user selects the Summary report type, the system navigates to the summary results block, clears all data currently displayed there, and then returns focus to the search criteria area. Any previously displayed detail results remain untouched but are no longer in the active view.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Report Type changes to Detail: detail results block is cleared**
When the user selects any report type other than Summary (i.e., the detail view), the system navigates to the detail results block, clears all data currently displayed there, and then returns focus to the search criteria area. Any previously displayed summary results remain untouched but are no longer in the active view.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

#### Business Scenarios - How the results display differs by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Summary report type selected** | The summary results block (showing service-type groupings with pending day counts) is cleared; the detail results block is not touched. |
| **Detail report type selected** | The detail results block (showing individual vehicle and parts rows) is cleared; the summary results block is not touched. |

**Alternative Flows:**

None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List item | N/A | N/A | Summary ('S') or Detail (any other value) | Search criteria screen is open | Must be selected before searching | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Search and Populate Vehicle Parts Hold-Up Data

**Business Description:**
When the user clicks the Search button after entering the required search criteria, the system checks that data exists for the specified date and location, then retrieves and displays the vehicle parts hold-up information on screen. For a summary report type, the system shows each service category with counts of vehicles pending for more than one, three, and seven days. For a detail report type, the system shows individual vehicle records with part requisition details, stock availability, and pending day counts. If no data is found for the given criteria, the user is informed accordingly.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The Hold Up Date has been entered and is valid (present or past).
- A Location has been selected.
- A Service Type has been selected.
- A Report Type has been selected.

**Main Flow:**

**Step 1 - Hold Up Date presence is verified before executing the search**
When the user presses the Search button, the system first checks whether the Hold Up Date field has been filled in. If it is empty, the system displays an error message and cancels the search.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message at "Error" severity; the form remains open.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold Up Date must be provided before searching | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH - own condition `HOLD_UP_DATE IS NULL` | When the user clicks the Search button | A search without a date is not meaningful | *"Hold Up Date can not be null"* displayed; search cancelled; user must enter a date |

**Step 2 - Existence of hold-up data for the specified date and location is confirmed**
If the Hold Up Date is present, the system queries the hold-up data store to count records matching the entered date, the user's dealer location, and the selected location code. If no matching records are found, the system displays an error message and cancels the search.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the "no data" error message.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold-up data must exist for the given date and location | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH - SELECT COUNT from VD_RO_HOLD_UP where count <= 0 | When the user clicks the Search button and date is present | Prevents showing an empty results screen when no hold-up records match the criteria | *"Vehicle Pending for Parts Data is not available for Date"* displayed; search cancelled |

**Step 3 - Hold-up data is retrieved and displayed according to the selected report type**
Once the existence check passes, the system calls the data-population routine to retrieve and fill the appropriate results block on screen, based on the Report Type selected. The routine queries the hold-up records and associated reference data, then renders the results into the relevant block.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **POPULATE_DETAILS** ([SP-001](#SP-001--POPULATE_DETAILS)) - POPULATE_DETAILS - retrieves vehicle parts hold-up data from the database and populates the on-screen results block according to the selected report type; displays a warning if no data is found.
    * **Step 1** - Check the selected report type to determine whether to populate the summary view or the detail view.
    * **Step 2** - If the summary view is required: clear the summary results block and execute the summary query, which groups hold-up records by service category, counts vehicles pending for more than one, three, and seven days, and populates each row in the summary block. Navigate to the first record when done.
    * **Step 3** - If the detail view is required: clear the detail results block and execute the detail query, which retrieves individual vehicle and part requisition records. For each record, populate the vehicle number, job card number and date, part number, requisition details (number, date, required quantity, issued quantity), stock availability flags (live and dead stock), and order number. Look up the vehicle model description, service category description, part description, and part availability source description from the corresponding reference tables and display them. Navigate to the first record when done.
    * **Step 4** - If no data is found during retrieval (no matching records), display a notice to the user that data is not available and stop populating.
    * **Step 5** - If any other unexpected error occurs during retrieval, display the system error message together with the database error description and stop populating.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Data retrieval and display by report type | POPULATE_DETAILS [SP-001] - report type check and query execution | When the Search button is pressed and existence check passes | Retrieves and renders the correct set of hold-up data (summary or detail) for the selected criteria | *"Data not available"* shown if the query returns no rows; database error text with *"Unable to populate"* prefix shown if retrieval fails unexpectedly |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Hold Up Date is blank when Search is clicked - *"Hold Up Date can not be null"*; search cancelled; user must enter a date.
- **BR-006-ES-02** - No hold-up records exist for the entered date and location - *"Vehicle Pending for Parts Data is not available for Date"*; search cancelled.
- **BR-006-WS-01** - *"Data not available"* - shown by POPULATE_DETAILS when the database query returns no rows after the existence check passed; results block remains empty.
- **BR-006-SM-01** - Results displayed successfully - the appropriate results block (summary or detail) is populated with vehicle parts hold-up data; no explicit success message is displayed.

#### Business Scenarios - How search results differ by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Summary report type** | The summary results block is populated with one row per service category, showing the category description and counts of vehicles pending for more than 1, 3, and 7 days respectively. |
| **Detail report type** | The detail results block is populated with one row per vehicle-part combination, showing vehicle number, job card details, part information, requisition details, stock availability, and order number for each pending item. |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 2) The query to count hold-up records raises an unhandled exception: the exception is silently suppressed (`WHEN OTHERS THEN NULL`) and the count variable retains its default value of zero, leading to the "no data" error message in Step 2.
- **BR-006-AF-02** - (from Step 3) POPULATE_DETAILS encounters a no-data-found condition on the inner queries for model description, service category, part description, or availability source: each such sub-query is individually protected and silently suppressed (`WHEN OTHERS THEN NULL`); the corresponding display field is left blank and processing continues with the next record.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Hold Up Date (`HOLD_UP_DATE`) | Mandatory | Date | DD/MM/RRRR (max 12 chars) | N/A | N/A | Search criteria screen open | Must be provided and must not be a future date | *"Hold Up Date can not be null"* if blank at search time |
| Location Description (`CB_LOC_DESC`) | Mandatory | Text | 200 | Location LOV (LOV_LOC / RG_LOC) | Location description | User's dealer access | Must be selected from the authorised locations for the current user | N/A |
| Service Type (`SRV_TYPE`) | Mandatory | List item | N/A | N/A | All ('A'), Non-BANDP ('N'), BANDP ('Y') | Search criteria screen open | Must be a valid accepted value and not blank | Validated on field exit per BR-003 |
| Report Type (`REPORT_TYPE`) | Mandatory | List item | N/A | N/A | Summary ('S') or Detail | Search criteria screen open | Must be selected | N/A |
| Type of Service (`SRV_DESC`) | Read-only display | Text | N/A | N/A | Service category description | Summary report type selected | System-populated | N/A |
| More than 1 day (`PEND_1`) | Read-only display | Numeric | N/A | N/A | Count | Summary report populated | System-populated | N/A |
| More than 3 days (`PEND_3`) | Read-only display | Numeric | N/A | N/A | Count | Summary report populated | System-populated | N/A |
| More than 7 days (`PEND_7`) | Read-only display | Numeric | N/A | N/A | Count | Summary report populated | System-populated | N/A |
| Vehicle No. (`VEH_NO`) | Read-only display | Text | 20 | N/A | Vehicle registration number | Detail report populated | System-populated | N/A |
| Job Card Num (`RO_NUM`) | Read-only display | Text | 12 | N/A | Job card number | Detail report populated | System-populated | N/A |
| Job Card Date (`RO_DATE`) | Read-only display | Date | dd-mm-yyyy | N/A | N/A | Detail report populated | System-populated | N/A |
| Part Number (`PART_NUM`) | Read-only display | Text | 20 | N/A | Part number | Detail report populated | System-populated | N/A |
| Requisition No (`REQ_NUM`) | Read-only display | Text | 500 | N/A | Requisition number | Detail report populated | System-populated | N/A |
| Requisition Date & Time (`REQ_DATE`) | Read-only display | Character | 500 | N/A | Formatted date and time | Detail report populated | System-populated | N/A |
| Required Qty (`REQ_QTY`) | Read-only display | Numeric | 20 | N/A | Quantity required | Detail report populated | System-populated | N/A |
| Issue Qty (`ISS_QTY`) | Read-only display | Numeric | 20 | N/A | Quantity issued | Detail report populated | System-populated | N/A |
| Live Stk Avl (`LIVE_STOCK_AVL`) | Read-only display | Text | 20 | N/A | Yes / No | Detail report populated | System-populated | N/A |
| Dead Stk Avl (`DEAD_STOCK_AVL`) | Read-only display | Text | 20 | N/A | Yes / No | Detail report populated | System-populated | N/A |
| Availability Source (`PART_STATUS`) | Read-only display | Text | 20 | Availability source list (AM_LIST - AVAIL_SOURCE) | Source description | Detail report populated | System-populated | N/A |
| Order Number (`ORDER_NUM`) | Read-only display | Text | 20 | N/A | Order number | Detail report populated | System-populated | N/A |
| Model (`MODEL`) | Read-only display | Text | 100 | Vehicle model master (GM_MOD) | Model description | Detail report populated | System-populated; silently blank if not found | N/A |
| Service Type Description (`SERVICE_TYPE`) | Read-only display | Text | 100 | Service category list (AM_LIST - RCATEG_CD) | Category description | Detail report populated | System-populated; silently blank if not found | N/A |
| Part Description (`PART_DESC`) | Read-only display | Text | 100 | Parts master (PM_PART) | Part description | Detail report populated | System-populated; silently blank if not found | N/A |
| Pending Day (`PEND_DAY`) | Read-only display | Text | 20 | N/A | Number of days | Detail report populated | System-populated | N/A |
| Sl. No (`SL_NO`) | Read-only display | Text | 20 | N/A | Sequential row number | Detail report populated | System-populated | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Export Vehicle Parts Hold-Up Data to Excel (CSV)

**Business Description:**
When the user clicks the Export to Excel button, the system verifies that hold-up data exists for the entered date and location, constructs a report of the hold-up data in a spreadsheet-compatible format, and saves it as a CSV file that the user can open in Excel. The content of the export differs based on the Report Type selected: the summary export shows service-category hold-up counts, while the detail export shows individual vehicle and parts-requisition rows. The file is named using the current user's identifier and the current date and time to ensure uniqueness. Any unexpected error during the export is silently suppressed.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The Hold Up Date has been entered and is valid (present or past).
- A Location has been selected.
- A Service Type has been selected.
- A Report Type has been selected.

**Main Flow:**

**Step 1 - Hold Up Date presence is verified before executing the export**
When the user presses the Export to Excel button, the system first checks whether the Hold Up Date field has been filled in. If it is empty, the system displays an error message and cancels the export.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message at "Error" severity; the form remains open.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold Up Date must be provided before exporting | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL - own condition `HOLD_UP_DATE IS NULL` | When the user clicks the Export to Excel button | An export without a date has no meaningful data to produce | *"Hold Up Date can not be null"* displayed; export cancelled |

**Step 2 - Existence of hold-up data for the specified date and location is confirmed**
If the Hold Up Date is present, the system counts matching records in the hold-up data store for the entered date, dealer location, and selected location code. If no matching records are found, the system displays an error message and cancels the export.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the "no data" error message.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold-up data must exist for the given date and location | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL - SELECT COUNT from VD_RO_HOLD_UP where count <= 0 | When the user clicks the Export to Excel button and date is present | Prevents generating an empty export file | *"Vehicle Pending for Parts Data is not available for Date"* displayed; export cancelled |

**Step 3 - A uniquely named output file is prepared and the export query is built**
Once the existence check passes, the system constructs a unique CSV filename from the current user's identifier, the current date, and the current time. The system then constructs the appropriate SQL query to produce the CSV content depending on the Report Type selected.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - The CSV data is generated and delivered to the user via the Excel reporting service**
The system calls the Excel reporting service, passing the principal identifier, the generated filename, the constructed query, the column alias, and the application identifier. The service executes the query, formats the results as a comma-separated file (CSV), and delivers the file to the user.

*Screen: Search Criteria (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-063](#SP-063--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - executes the provided SQL query, writes the results to a CSV file with the given filename, and makes the file available to the user; the principal identifier and application identifier are passed for multi-organisation support.
    * **Step 1** - Receive the principal identifier, target filename, SQL query, column alias, and application identifier.
    * **Step 2** - Execute the SQL query to retrieve the result data.
    * **Step 3** - Write the query results as comma-separated rows to the target file.
    * **Step 4** - Make the generated file available to the user for download or opening.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Export query execution and file delivery | VIEW_EXCEL_REPORT_NEW [SP-063] - query execution and file write | When the existence check passes and the user clicks Export to Excel | Generates a downloadable CSV file of the hold-up data for the selected criteria | If an exception occurs during export, it is silently suppressed (`WHEN OTHERS THEN NULL`); no error message is shown to the user |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Hold Up Date is blank when Export is clicked - *"Hold Up Date can not be null"*; export cancelled.
- **BR-007-ES-02** - No hold-up records exist for the entered date and location - *"Vehicle Pending for Parts Data is not available for Date"*; export cancelled.
- **BR-007-SM-01** - CSV file generated and delivered - the file named `[userid]_[YYYYMMDDHH24MISS].csv` is made available to the user for download; no explicit success message is displayed.

#### Business Scenarios - How the export content differs by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Summary report type** | The CSV contains one header row (Type of Service, More than 1 day, More than 3 days, More than 7 days) and one data row per service category with the corresponding pending day counts. |
| **Detail report type** | The CSV contains one header row (Pending Days, Vehicle No., Job Card No., Model, Type of Service, Job Card Date, Part Num, Part Desc, Requisition No, Requisition Date, Required Qty, Issue Qty, Live Stk Avl, Dead Stk Avl, Availability Source, Order Number) and one data row per vehicle-part combination. |

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 2) The count query raises an unhandled exception: silently suppressed (`WHEN OTHERS THEN NULL`); count retains default zero; export proceeds to the "no data" error in Step 2.
- **BR-007-AF-02** - (from Step 4) An exception occurs anywhere during file generation or delivery: silently suppressed (`WHEN OTHERS THEN NULL` at the outer level); no message is shown and the form remains open.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Hold Up Date (`HOLD_UP_DATE`) | Mandatory | Date | DD/MM/RRRR | N/A | N/A | Search criteria screen open | Must be provided | *"Hold Up Date can not be null"* if blank at export time |
| Location Description (`CB_LOC_DESC`) | Mandatory | Text | 200 | Location LOV (LOV_LOC / RG_LOC) | Location description | User's dealer access | Must be selected | N/A |
| Service Type (`SRV_TYPE`) | Mandatory | List item | N/A | N/A | All ('A'), Non-BANDP ('N'), BANDP ('Y') | Search criteria screen open | Must be a valid accepted value | Validated on field exit per BR-003 |
| Report Type (`REPORT_TYPE`) | Mandatory | List item | N/A | N/A | Summary ('S') or Detail | Search criteria screen open | Must be selected | N/A |
| Export Filename (`lv_filename`) | Auto-populated | Character | 5000 | N/A | `[userid]_[YYYYMMDDHH24MISS].csv` | Export button clicked | System-generated; not user-editable | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Exit the Form

**Business Description:**
Users can leave the vehicle parts hold-up enquiry form at any time without saving any pending changes, using the Exit keyboard shortcut, the Exit button, or the OK button on the navigation bar. All paths close the form immediately, discarding any unsaved changes, and the keyboard-shortcut path also clears the form's application tracking registration to clean up the session context.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Application tracking context is cleared and the form is closed (keyboard exit)**
When the user presses the Exit key shortcut, the system first clears the application tracking client information (setting it to null) and clears the module registration, then closes the form without saving any pending changes.

**Step 2 - Exit button pressed: form is closed after checking session mode**
When the user clicks the Exit button, the system checks whether the form is in enter-query mode. Regardless of the mode and regardless of whether the form has unsaved changes, the system closes the form without saving.

**Step 3 - OK button pressed: form is closed immediately**
When the user clicks the OK button on the navigation bar, the system closes the form immediately without saving any pending changes.

**Step 4 - Exit navigation bar button pressed: exit flag is set and form is closed**
When the user clicks the Exit button on the navigation bar, the system sets a global exit indicator to signal the exit intent, then closes the form without saving any pending changes.

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-IC-01** - `EXIT_FLAG = 'EXIT'` - the global exit flag is set when the navigation bar Exit button is used; the form closes without saving.

**Alternative Flows:**

None evidenced - all exit paths lead unconditionally to the form closing without saving.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Exit Flag (`GLOBAL.EXIT_FLAG`) | Auto-populated | Character | N/A | N/A | Fixed value `EXIT` | Navigation bar Exit button clicked | System-set only; not user-editable | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Clear Form Data

**Business Description:**
Users can clear all data currently displayed in the form using the Clear keyboard shortcut, the Clear button on the navigation bar, or the Cancel button on the toolbar. The Clear shortcut and Clear navigation bar button discard all data without saving, returning the form to a blank state ready for a new search. The Cancel toolbar button additionally re-initialises the form to its opening defaults after clearing, so the user can start a fresh search immediately.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The form is open with data displayed or entered.

**Main Flow:**

**Step 1 - Clear key shortcut: all form data is cleared without saving**
When the user presses the Clear key shortcut, the system clears all blocks in the form - discarding any displayed results and any entered criteria - without saving or validating the current state.

**Step 2 - Clear navigation bar button: named block and criteria block are cleared**
When the user clicks the Clear button on the navigation bar, the system navigates to the `PM_PART_DEAD_STOCK` block, clears it without validation, then navigates to the `cb_dummy` (search criteria) block and clears that too without validation. Both blocks are reset to a blank state.

**Step 3 - Cancel toolbar button: form is cleared and re-initialised to its opening defaults**
When the user clicks the Cancel button on the toolbar (`PB_BLK.PB_CANCEL`), the system first checks whether that button is currently enabled. If it is enabled, the system clears all form data (regardless of whether the form has unsaved changes) and then immediately re-runs the form initialisation sequence, restoring all default values and dropdown list content to the same state as when the form was first opened. If the Cancel button is disabled, no action is taken.

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-IC-01** - Cancel button is disabled - no action is taken; the form state is unchanged.

**Alternative Flows:**

None evidenced.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Hold Up Date (`HOLD_UP_DATE`) | Optional | Date | DD/MM/RRRR | N/A | N/A | Clear action invoked | Cleared without validation | N/A |
| Location Description (`CB_LOC_DESC`) | Optional | Text | 200 | N/A | N/A | Clear action invoked | Cleared without validation | N/A |
| Service Type (`SRV_TYPE`) | Optional | List item | N/A | N/A | N/A | Clear action invoked | Cleared without validation | N/A |
| Report Type (`REPORT_TYPE`) | Optional | List item | N/A | N/A | N/A | Clear action invoked | Cleared without validation | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Service Type Validation in Summary Results Block

**Business Description:**
When the user moves away from the Type of Service field in the summary results block, the system applies the same service-type validation that governs the search criteria screen: the selected value must be one of the three accepted service type options and must not be blank. This ensures data integrity is maintained even if a user directly edits the service type within the results display.

**Actors:** Service Advisor / Parts Staff

**Preconditions:**
- The summary results block is visible and the user has moved away from the Type of Service field.

**Main Flow:**

**Step 1 - Type of Service value is checked against the permitted options in the results block**
When the user leaves the Type of Service field in the summary results block, the system checks whether the selected value is one of the three accepted service type values. If not, an error is displayed and processing is halted.

*Screen: Summary (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error message at "Error" severity; the form remains open.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Type of Service must be a recognised option in results block | WHEN-VALIDATE-ITEM on B_VD.SRV_DESC - own condition `SRV_TYPE NOT IN ('A','N','Y')` | When the user leaves the Type of Service field in the summary results block | Maintains service-type data integrity within the results block | *"Plase select service type from list"* displayed; processing halted |

**Step 2 - Type of Service blank check in the results block**
Immediately after the permitted-option check, the system also verifies the Type of Service field is not empty. If it is blank, a mandatory-field error message is displayed.

*Screen: Summary (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the mandatory-field error message.
    * **Step 1** - Receive the message text and its severity level.
    * **Step 2** - Format and present the message in the standard notification dialog at the specified severity.
    * **Step 3** - Return control to the caller; the form remains open.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Type of Service must not be blank in results block | WHEN-VALIDATE-ITEM on B_VD.SRV_DESC - own condition `SRV_TYPE IS NULL` | When the user leaves the Type of Service field in the summary results block with no value | Maintains service-type data integrity | *"Service Type can not be null"* displayed; processing halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - Type of Service value is not a recognised option in the results block - *"Plase select service type from list"*; processing halted.
- **BR-010-ES-02** - Type of Service is blank in the results block - *"Service Type can not be null"*; processing halted.

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1) Value is one of the three accepted options and is not blank: both checks pass; the form allows the user to continue.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Type of Service (`SRV_DESC`) | Mandatory | Text | N/A | N/A | Accepted values: All ('A'), Non-BANDP ('N'), BANDP ('Y') | Summary results block is displayed | Must be one of the three accepted values and must not be blank | *"Plase select service type from list"* if invalid; *"Service Type can not be null"* if blank |

---

---

#### Requirement ID: BR-011

**Requirement Title:** On-Message Handling (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A form-level message-handling routine was previously included in the form to intercept and display Oracle Forms informational or confirmation messages for specific error codes (40209, 40207) in the same manner as the error handler. This routine has been entirely commented out and replaced with a `null;` no-op statement. It does not execute and has no effect on current form behaviour. It is documented here for completeness only.

**Actors:** Not applicable - code is inactive.

**Preconditions:**

Not applicable - code is inactive.

**Main Flow:**

Not applicable - this trigger contains only `null;` and does not execute any business logic. It is retained in the form source as a commented-out block (COMMENTED OUT / INACTIVE - does not execute).

**Alternative Flows:**

Not applicable.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Key-Commit Save Action (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A keyboard-driven commit (save) routine was previously included in the form to allow the user to save the current form state, validate the result, and then clear the form. This routine has been entirely commented out and replaced with a `null;` no-op statement. It does not execute and has no effect on current form behaviour. It is documented here for completeness only.

**Actors:** Not applicable - code is inactive.

**Preconditions:**

Not applicable - code is inactive.

**Main Flow:**

Not applicable - this trigger contains only `null;` and does not execute any business logic. It is retained in the form source as a commented-out block (COMMENTED OUT / INACTIVE - does not execute).

**Alternative Flows:**

Not applicable.

---

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Hold Up Date cannot be in the future | Validation | BR-004 | The Hold Up Date entered by the user is later than today's date | Show alert *"Hold Up Date cannot be greater than Current Date"* and stop the user from continuing | Prevents the user from searching for hold-up records on a future date, which would return no meaningful data and waste processing time |
| BRC-002 | Hold Up Date is mandatory for search and export | Validation | BR-004, BR-006, BR-007 | The Hold Up Date field is left blank when the user attempts to search or export | Show *"From Date can not be empty"* (on field exit) or *"Hold Up Date can not be null"* (on Search/Export button click) and stop processing | Hold Up Date is the primary key for the hold-up snapshot; without it, neither a search nor an export can be directed at any specific date |
| BRC-003 | Service Type must be a recognised value | Validation | BR-003, BR-010 | The Service Type (on the search criteria screen or in the summary results block) is not one of the three accepted values | Show *"Plase select service type from list"* and stop processing | Ensures that the service-type filter applied to hold-up data queries is always one of the three defined categories, preventing corrupted query results |
| BRC-004 | Service Type is mandatory | Validation | BR-003, BR-010 | The Service Type field is blank | Show *"Service Type can not be null"* and stop processing | Service Type is required to scope the hold-up query correctly; a blank value would include or exclude records unpredictably |
| BRC-005 | Hold-up data must exist for the selected date and location before a search is run | Validation | BR-006 | A search is triggered but no hold-up records exist in the data store for the given date, dealer location, and location code | Show *"Vehicle Pending for Parts Data is not available for Date"* and cancel the search | Prevents showing an empty results screen and clarifies to the user that no hold-up data was captured for the selected date and location |
| BRC-006 | Hold-up data must exist for the selected date and location before an export is run | Validation | BR-007 | An export is triggered but no hold-up records exist in the data store for the given date, dealer location, and location code | Show *"Vehicle Pending for Parts Data is not available for Date"* and cancel the export | Prevents generating an empty CSV file and clarifies to the user that there is no data to export |
| BRC-007 | Referential-integrity violations are intercepted and presented as business messages | Constraint | BR-002 | A database operation attempts to violate a child-record constraint (Oracle error -02292) | Call the standard error-raising routine with the mapped error code and stop processing | Presents a meaningful business-level message instead of a raw Oracle constraint error, protecting data integrity and improving user experience |
| BRC-008 | Record-locking conflicts are detected, rolled back, and communicated to the user | Constraint | BR-002 | Another user has updated the same record since the current user last loaded it (Oracle Forms error codes 40654-40659) | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and stop processing | Protects against one user silently overwriting another user's concurrent changes; instructs the user to reload before retrying |
| BRC-009 | Report Type selection clears the corresponding results block immediately | Derivation | BR-005 | The user changes the Report Type selection | Clear the results block corresponding to the newly selected type (summary or detail) without waiting for a new search | Ensures stale results from a previous search are never left visible when the user changes the intended report format |
| BRC-010 | Summary report populates service-category pending-day counts | Derivation | BR-006 | The user runs a search with Report Type set to Summary | Populate the summary results block with one row per service category, showing counts of vehicles pending for more than 1, 3, and 7 days | Gives managers and parts staff a high-level picture of hold-up severity by service type for the selected date |
| BRC-011 | Detail report populates individual vehicle and parts-requisition rows | Derivation | BR-006 | The user runs a search with Report Type set to Detail | Populate the detail results block with one row per vehicle-part combination, including vehicle number, job card details, part and requisition information, stock availability, and order number | Gives parts staff the specific vehicle and part information needed to action individual hold-up cases |
| BRC-012 | Export filename is uniquely generated per user and timestamp | Derivation | BR-007 | The user clicks Export to Excel and all pre-checks pass | Generate the CSV filename by concatenating the current user's identifier with the current date and time in YYYYMMDDHH24MISS format | Ensures that multiple exports by the same or different users do not overwrite each other's files |
| BRC-013 | Export content matches the selected report type | Derivation | BR-007 | The user exports with Summary report type selected | Build the summary CSV header and data rows (service type, more-than-1-day count, more-than-3-day count, more-than-7-day count) | Ensures the exported file is consistent with what the user sees on screen for the summary view |
| BRC-014 | Export detail content includes all vehicle and parts columns | Derivation | BR-007 | The user exports with Detail report type selected | Build the detail CSV header and data rows covering all vehicle, job card, part, requisition, stock, and order columns | Ensures the exported file provides the full detail needed for parts staff to work from outside the system |
| BRC-015 | Informational navigation status codes are silently suppressed | Constraint | BR-002 | Oracle Forms raises status code 40401 or 40405 during navigation | Take no visible action; suppress the code silently | These codes indicate normal end-of-records or no-record navigation states; surfacing them as errors would confuse users unnecessarily |
| BRC-016 | Session tracking is registered at form startup and cleared on keyboard exit | Authorization | BR-001, BR-008 | The form opens (PRE-FORM) or the user exits via the keyboard shortcut (KEY-EXIT) | On open: register the form name and empty action with the application monitoring service. On keyboard exit: clear the client information and module registration before closing | Enables system-level visibility of which users are accessing the hold-up enquiry module and ensures session context is cleaned up on exit |

**Total Business Rules Identified: 16**

---

## 6. Data Requirements

*This form captures search criteria (Hold Up Date, Location, Service Type, Report Type) and displays vehicle parts hold-up data in two formats - a summary by service category and a detail by individual vehicle and part. Reference data for locations, service categories, parts, vehicle models, and availability sources are read from master tables. No data is written or persisted by this form; it is a read-only enquiry form.*

### 6.1 Business Entities and Relationships

*The form queries two primary hold-up tables (header and detail), joining them to requisition, parts, vehicle model, and reference list tables. All entities are read-only within this form.*

#### Vehicle Hold-Up Header - VH_RO_HOLD_UP

The vehicle hold-up header stores one record per vehicle repair order that is being held up pending parts delivery, for a given hold-up date. This entity is the primary source for the detail results view; it holds the vehicle identifier, repair order number and date, service category, repair-order status, promised delivery date, and the parent dealer group. The form reads this table to populate both the summary and detail results blocks for vehicles whose repair orders are open (status 10) and whose hold-up date is on or after the promised date.

#### Vehicle Hold-Up Detail - VD_RO_HOLD_UP

The vehicle hold-up detail stores one record per part that is held up against a vehicle repair order. This entity provides the parts-level information in the detail results view: part number, stock availability flags (live stock and dead stock), availability source, and order number. The form also uses this table for the pre-search existence check (counting matching records before displaying results).

#### Parts Requisition - VT_REQ

The parts requisition entity stores requisition requests raised against a repair order for specific parts. The form reads this table in the detail query to display the requisition number, requisition date and time, required quantity, and issued quantity for each vehicle-part combination shown in the detail results.

#### Parts Master - PM_PART

The parts master provides descriptive information about each part number. The form looks up the part description from this table for each part in the detail results view, using the part number and principal (dealer organisation) as the lookup key. Where no matching part description is found, the field is left blank.

#### Vehicle Model Master - GM_MOD

The vehicle model master provides model description for each vehicle model code. The form looks up the model description from this table for each vehicle in the detail results view. Where no matching model description is found, the field is left blank.

#### Reference List - AM_LIST

The reference list is a general-purpose code-description lookup table used for multiple attributes. On this form it provides:
- Service category descriptions (list name `RCATEG_CD`) - used in both the summary results and the detail results to display the type of service.
- Availability source descriptions (list name `AVAIL_SOURCE`) - used in the detail results to display the human-readable availability source for each held-up part.

#### Location Master - AM_DEALER_LOC / AM_USER_DEALER_MASTER

The location master and user-dealer mapping table together provide the list of locations the current user is authorised to search against. The form populates the Location LOV from a query joining these two tables, filtered to the current user's identifier, the current principal, and dealer type and spares access conditions.

#### Entity Relationships

The hold-up header is the central entity; the detail and requisition entities link to it by repair order and dealer/location keys. Reference tables are looked up independently by code value.

```
VH_RO_HOLD_UP (Vehicle Hold-Up Header)
        ├── VD_RO_HOLD_UP (Vehicle Hold-Up Detail)    <- h.parent_group = d.parent_group, h.dealer_map_cd = d.dealer_map_cd, h.loc_cd = d.loc_cd, h.ro_num = d.ro_num, h.hold_up_date = d.hold_up_date
        │       └── VT_REQ (Parts Requisition)         <- d.dealer_map_cd = r.dealer_map_cd(+), d.loc_cd = r.loc_cd(+), d.ro_num = r.ro_num(+), d.part_num = r.part_num(+)
        ├── AM_LIST (Reference List - RCATEG_CD)       <- a.list_code = b.rcateg_cd / h.rcateg_cd
        ├── GM_MOD (Vehicle Model Master)              <- m.model_cd = h.model_code
        └── PM_PART (Parts Master)                     <- p.part_num = d.part_num
```

### 6.2 Data Capture Requirements

*The form captures search filter values from the user; all results fields are system-populated and read-only. Mandatory fields are validated on field exit and again on button click.*

#### Search Criteria (User - before running a search or export)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Hold Up Date (`HOLD_UP_DATE`) | Yes | The specific date for which the user wants to view vehicles that were held up pending parts. Entered by the user in DD/MM/RRRR format. | Must be provided. Must not be a future date. Validated on field exit (BR-004) and again when Search or Export is clicked (BR-006, BR-007). |
| Location (`CB_LOC_DESC` / `CB_LOC_CD` / `CB_DEALER_MAP_CD`) | Yes | The dealer location for which the hold-up data should be retrieved. Selected from the authorised location list for the current user. | Must be selected from the location lookup list. The LOV is pre-filtered to the current user's authorised dealer locations and spares-type access. |
| Service Type (`SRV_TYPE`) | Yes | The category of service work to filter the hold-up data. Accepted options are All, Non-BANDP, and BANDP. | Must be one of the three accepted values and must not be blank. Validated on field exit (BR-003). |
| Report Type (`REPORT_TYPE`) | Yes | Selects whether the results are displayed in summary (by service category) or detail (by individual vehicle and part) format. | Must be selected. Changing this selection immediately clears the previously displayed results (BR-005). |

#### Session and Global Context (System - set at form startup)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Client Info (`GLOBAL` / session context) | Auto-Populated | The form identifier (`pi_veh_hold_up`) set with the application monitoring service at form startup, and cleared on keyboard exit. | System-set only; not user-editable. |
| User ID (`GLOBAL.USERID`) | Auto-Populated | The identifier of the currently authenticated user, used to generate unique export filenames and to filter the location LOV. | System-provided; not user-editable. |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The dealer organisation identifier (principal map code), used to scope all database queries and lookups to the current dealer organisation. | System-provided; not user-editable. |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The parent dealer group identifier, used to filter hold-up records to the correct group. | System-provided; not user-editable. |
| Application ID (`PARAMETER.P_APP_ID`) | Auto-Populated | The application identifier passed to the Excel reporting service for multi-organisation support. | System-provided; not user-editable. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Location lookup (LOV_LOC / RG_LOC - AM_DEALER_LOC, AM_USER_DEALER_MASTER) | Provides the list of dealer locations the current user is authorised to search, filtered by user ID, principal, dealer type ('2S' or '3S'), and spares dealer type | When the user opens the Location field lookup to select a location for the hold-up search |
| Service category list (AM_LIST - list name RCATEG_CD) | Provides human-readable service category descriptions (e.g. type of service) corresponding to the category codes stored in the hold-up records | When POPULATE_DETAILS populates the summary results block (group-by label) and the detail results block (service type column), and when the Excel export builds its CSV content |
| Availability source list (AM_LIST - list name AVAIL_SOURCE) | Provides human-readable descriptions of the part availability source corresponding to the source codes stored in the hold-up detail records | When POPULATE_DETAILS populates the Availability Source column in the detail results block, and when the Excel export builds its detail CSV content |
| Vehicle model master (GM_MOD) | Provides vehicle model descriptions corresponding to the model codes stored in the hold-up header records | When POPULATE_DETAILS populates the Model column in the detail results block, and when the Excel export builds its detail CSV content |
| Parts master (PM_PART) | Provides part descriptions corresponding to the part numbers stored in the hold-up detail records | When POPULATE_DETAILS populates the Part Description column in the detail results block, and when the Excel export builds its detail CSV content |
| CEO control point list (RG_CEO - AM_LIST - list name CEO_CONTROL_POINT) | A reference record group defined in the form; loaded from the reference list for CEO control points for the current principal | Available as a record group in the form; not directly used in any of the form's active trigger logic visible in the slice |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create any database records. It is a read-only enquiry form; all hold-up data is pre-loaded into the database by upstream processes and is only read here.

**Updates**

- This form does not update any database records. No DML statements are present in the active code. The results blocks are populated programmatically (block insert/update allowed is set to true within the POPULATE_DETAILS routine to allow in-memory block population, but no database commit is performed).

**Save and Commit**

- No save or commit action is available to the user. The KEY-COMMIT trigger is entirely commented out (INACTIVE). The Save button on the navigation bar delegates to a `FT_SAVE` trigger handler, but no active commit logic is evidenced in the current form's active code.

**Retention and Audit**

- The form does not create, modify, or maintain any audit or timestamp records. Session activity is registered and cleared via the application monitoring service (DBMS_APPLICATION_INFO) at form open and keyboard-exit respectively, but this is a session-level tracking mechanism only and does not persist to any audit table evidenced in this form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Pending Days |  | VH_RO_HOLD_UP | HOLD_UP_DATE | Shows the Pending Days taken from the enquiry's related records. |
| 2 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Vehicle No. |  | VH_RO_HOLD_UP | VIN | Shows the Vehicle No. taken from the enquiry's related records. |
| 3 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Job Card No. |  | VH_RO_HOLD_UP | RO_NUM | Shows the Job Card No. taken from the enquiry's related records. |
| 4 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Model |  | GM_MOD | MODEL_DESC | Shows the Model taken from the enquiry's related records. |
| 5 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Type of Service |  | AM_LIST | LIST_DESC | Shows the Type of Service taken from the enquiry's related records. |
| 6 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Part Num |  | VD_RO_HOLD_UP | PART_NUM | Shows the Part Num taken from the enquiry's related records. |
| 7 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Requisition No |  | VT_REQ | REQ_NUM | Shows the Requisition No taken from the enquiry's related records. |
| 8 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Requisition Date |  | VT_REQ | REQ_DATE | Shows the Requisition Date taken from the enquiry's related records. |
| 9 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Required Qty |  | VT_REQ | REQ_QTY | Shows the Required Qty taken from the enquiry's related records. |
| 10 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Issue Qty |  | VT_REQ | ISS_QTY | Shows the Issue Qty taken from the enquiry's related records. |
| 11 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Live Stk Avl |  | VD_RO_HOLD_UP | LIVE_STOCK_AVL | Shows the Live Stk Avl taken from the enquiry's related records. |
| 12 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Dead Stk Avl |  | VD_RO_HOLD_UP | DEAD_STOCK_AVL | Shows the Dead Stk Avl taken from the enquiry's related records. |
| 13 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Availability Source |  | AM_LIST | LIST_DESC | Shows the Availability Source taken from the enquiry's related records. |
| 14 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | Order Number |  | VD_RO_HOLD_UP | ORDER_NUM | Shows the Order Number taken from the enquiry's related records. |
| 15 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | More than 1 day |  | VH_RO_HOLD_UP |  | Derived aggregate: SUM(DECODE(SIGN(hold_up_date - TRUNC(ro_date)), 1, 1, 0)) over VH_RO_HOLD_UP rows filtered by the Summary branch; counts ROs where the hold-up date is more than 1 day after the RO date. |
| 16 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | More than 3 days |  | VH_RO_HOLD_UP |  | Derived aggregate: SUM(DECODE(SIGN((hold_up_date - TRUNC(ro_date)) - 2), 1, 1, 0)) over VH_RO_HOLD_UP rows filtered by the Summary branch; counts ROs where the hold-up duration exceeds 3 days. |
| 17 | Hold Up Date, Service Type, USERID, CB Dealer MAP, CB LOC, Parent Group, Summary | More than 7 days |  | VH_RO_HOLD_UP |  | Derived aggregate: SUM(DECODE(SIGN((hold_up_date - TRUNC(ro_date)) - 6), 1, 1, 0)) over VH_RO_HOLD_UP rows filtered by the Summary branch; counts ROs where the hold-up duration exceeds 7 days. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_LIST | Application master list table - stores coded reference values (service categories, availability sources, control points) used across the DMS | - | RCATEG_CD, AVAIL_SOURCE |
| AVAIL_SOURCE | Availability source - coded value indicating where a part can be sourced (e.g. live stock, dead stock, order) | Part Status | PART_STATUS, Live Stock, Dead Stock |
| B_VD | Summary block - displays hold-up counts per service category in the Summary view | Summary Block | B_VH, PEND_1, PEND_3, PEND_7 |
| B_VH | Detail block - displays per-vehicle hold-up records in the Detail view | Detail Block | B_VD, Job Card, Requisition |
| BANDP | Body and Paint - service category code representing accidental/body repair services | Accidental | RCATEG_CD, Service Type |
| CB_DUMMY | Control block - holds search criteria fields (date, location, service type, report type) used to filter hold-up data | Search Criteria Block | Hold-Up Date, Location, Service Type |
| CSV | Comma-Separated Values - plain-text file format used for the Excel export output | Spreadsheet Export | Export to Excel |
| Dead Stock | Parts held in a secondary or inactive inventory that are available for issue | - | Live Stock, AVAIL_SOURCE |
| DMS | Dealer Management System - integrated software platform for managing dealer service, parts, and sales operations | - | Workshop, Parts Master |
| Hold-Up Date | Reference date used to identify vehicles that were pending parts as of that date | - | HOLD_UP_DATE, VH_RO_HOLD_UP |
| ISS_QTY | Issued quantity - number of parts already issued against a requisition | Issue Qty | REQ_QTY, Requisition |
| Job Card | Workshop repair order document raised when a vehicle is booked for service | RO, Repair Order | RO_NUM, RO_DATE |
| Live Stock | Parts available in the active current inventory for immediate issue | - | Dead Stock, AVAIL_SOURCE |
| LOV | List of Values - dropdown selection popup used in the form to select a workshop location | Dropdown, Picklist | LOV_LOC, RG_LOC |
| LOV_LOC | Location list of values - popup selector for dealer workshop locations authorized to the current user | Location LOV | RG_LOC |
| PART_NUM | Part number - unique identifier for a spare part in the parts master catalogue | Part Code | PM_PART, PART_DESC |
| PEND_1 | Count of vehicles pending parts for more than 1 day | Pending > 1 day | PEND_3, PEND_7 |
| PEND_3 | Count of vehicles pending parts for more than 3 days | Pending > 3 days | PEND_1, PEND_7 |
| PEND_7 | Count of vehicles pending parts for more than 7 days | Pending > 7 days | PEND_1, PEND_3 |
| PB_BLK | Toolbar button block - standard set of action buttons (Exit, Cancel, Clear, OK) inherited from the DPL object library | Toolbar Block | DPL |
| PI_VEH_HOLD_UP | Oracle Forms module name for the Vehicle Pending in Workshop for want of Parts enquiry screen | pi_veh_hold_up | Vehicle Hold-Up Enquiry |
| PM_PART | Parts master table - stores part numbers, descriptions, and pricing per dealer and principal | Parts Master | PART_NUM, PART_DESC |
| Principal | Manufacturer or brand entity within the DMS multi-organization setup; used to scope all queries and lookups | PRINCIPAL, Brand | Dealer, Parent Group |
| RCATEG_CD | Repair category code - classifies a job card as accidental (BANDP) or non-accidental; sourced from AM_LIST | Repair Category | Service Type, BANDP |
| REQ_DATE | Requisition date and time - when the parts requisition was raised against the job card | Requisition Date | REQ_NUM, REQ_QTY |
| REQ_NUM | Requisition number - unique identifier for a parts request raised against a job card | Requisition No | REQ_DATE, REQ_QTY |
| REQ_QTY | Requisition quantity - number of parts requested in the requisition | Required Qty | ISS_QTY, REQ_NUM |
| RG_CEO | CEO control point record group - loads coded CEO control point values from the application master list | CEO Record Group | AM_LIST |
| RG_LOC | Location record group - SQL-based list of active dealer workshop locations authorized to the current user | Location Record Group | LOV_LOC, AM_USER_DEALER_MASTER |
| RO | Repair Order - workshop job card document raised for a vehicle service; identified by RO_NUM | Job Card | RO_NUM, RO_DATE |
| RO_DATE | Job card date - date the repair order was opened | Job Card Date | RO_NUM, Hold-Up Date |
| RO_NUM | Repair order number - unique identifier for the vehicle's job card | Job Card Number | RO_DATE, VH_RO_HOLD_UP |
| Service Type | Classification of vehicle service as Accidental, Non-Accidental, or All; used as a filter criterion | SRV_TYPE | RCATEG_CD, BANDP |
| VD_RO_HOLD_UP | Vehicle hold-up detail table - stores part-level hold-up records per job card | Hold-Up Detail | VH_RO_HOLD_UP |
| VH_RO_HOLD_UP | Vehicle hold-up header table - stores job card hold-up records for vehicles pending parts in the workshop | Hold-Up Header | VD_RO_HOLD_UP |
| VIN | Vehicle Identification Number - unique chassis identifier for the vehicle | Vehicle Number | VEH_NO |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pi_veh_hold_up (PI_VEH_HOLD_UP)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Vehicle Pending in Workshop for want of Parts (Rel : 1.1.1)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `pi_veh_hold_up_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier global; mirrors the P_APP_ID parameter value at runtime for use across triggers and program units |
| COMP_FA | Char | Trigger | Company financial authority code; set at session initialisation and used for organisation-level filtering |
| DEALER | Char | ProgramUnit / Trigger | Dealer map code identifying the current dealer; used to filter hold-up data |
| EXIT_FLAG | Char | Trigger | Exit control flag; set to 'EXIT' when user clicks the NB_EXIT button |
| LOC_CD | Char | Trigger | Location code of the currently selected workshop; set from LOV_LOC selection and used to scope hold-up queries |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent organization group code for multi-organization data filtering |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code identifying the principal (manufacturer) for multi-organization queries |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used to filter authorized dealer locations and generate export filenames |

### 8.1.2 Form Parameters

*All 1 ModuleParameter entries from pi_veh_hold_up_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup; used when exporting data to Excel via VIEW_EXCEL_REPORT_NEW |

**Total Parameters:** 1

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | - | 1 | N/N/N/N | Default | Control - search criteria entry block for hold-up date, location, service type, and report type |
| B_VD | - | 3 | N/N/N/N | Default | Control - displays summary hold-up counts per service category; populated programmatically |
| B_VH | - | 9 | Y/Y/Y/N | Delayed | Control - displays detail hold-up vehicle records; populated programmatically via POPULATE_DETAILS |
| PB_BLK | - | 1 | N/N/N/N | Default | Control - standard toolbar button block inherited from DPL object library |

**Total Blocks:** 4 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pi_veh_hold_up_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pi_veh_hold_up_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pi_veh_hold_up_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 9 | 0 | 9 |
| B_VD | 7 | 0 | 7 |
| B_VH | 17 | 2 | 15 |
| PB_BLK | 15 | 0 | 15 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **58** | **2** | **56** |

**Item detail (all 58 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | STATUS | false | Service status filter list item; values 700 (active) and blank; controls query scope |
| CB_DUMMY | CB_DEALER_MAP_CD | false | Dealer map code returned from LOV_LOC; identifies the dealer location |
| CB_DUMMY | CB_LOC_CD | false | Location code returned from LOV_LOC; filters hold-up data by workshop location |
| CB_DUMMY | CB_LOC_DESC | false | Location description selected from LOV; displays the dealer workshop location name |
| CB_DUMMY | SRV_TYPE | false | Service type filter - Accidental (A), Non-Accidental (N), or All (Y) |
| CB_DUMMY | HOLD_UP_DATE | false | Hold-up reference date; records pending as of this date are retrieved (DD/MM/RRRR format) |
| CB_DUMMY | REPORT_TYPE | false | Report view selector - Detail (D) or Summary (S); controls which result block is displayed |
| CB_DUMMY | PB_SEARCH | false | Search button; validates inputs and populates hold-up data |
| CB_DUMMY | PB_EXCEL | false | Export to Excel button; generates CSV file of hold-up data |
| B_VD | SRV_DESC | false | Service category description displayed in summary view |
| B_VD | PEND_1 | false | Count of vehicles pending more than 1 day for the service category |
| B_VD | PEND_3 | false | Count of vehicles pending more than 3 days for the service category |
| B_VD | PEND_7 | false | Count of vehicles pending more than 7 days for the service category |
| B_VD | PEND_1_SUM | false | Summary total of all vehicles pending more than 1 day |
| B_VD | PEND_3_SUM | false | Summary total of all vehicles pending more than 3 days |
| B_VD | PEND_7_SUM | false | Summary total of all vehicles pending more than 7 days |
| B_VH | SL_NO | false | Serial number (row sequence) in the detail listing |
| B_VH | PEND_DAY | false | Number of days the vehicle has been pending for parts |
| B_VH | VEH_NO | true | Vehicle registration number (mapped to VIN/reg_num from hold-up table) |
| B_VH | RO_NUM | true | Job card (Repair Order) number for the pending vehicle |
| B_VH | RO_DATE | false | Date the job card was opened (dd-mm-yyyy format) |
| B_VH | PART_NUM | false | Part number required but unavailable, causing the hold-up |
| B_VH | REQ_NUM | false | Parts requisition number raised for the unavailable part |
| B_VH | REQ_DATE | false | Date and time of the parts requisition |
| B_VH | REQ_QTY | false | Quantity of parts requested in the requisition |
| B_VH | ISS_QTY | false | Quantity of parts already issued against the requisition |
| B_VH | SERVICE_TYPE | false | Service category description (e.g. Body and Paint, Non-Accidental) |
| B_VH | PART_DESC | false | Description of the required but unavailable part |
| B_VH | MODEL | false | Vehicle model description derived from model code |
| B_VH | LIVE_STOCK_AVL | false | Whether the part is available in live stock (Yes/No) |
| B_VH | DEAD_STOCK_AVL | false | Whether the part is available in dead stock (Yes/No) |
| B_VH | PART_STATUS | false | Part availability source description |
| B_VH | ORDER_NUM | false | Purchase order number raised for the unavailable part |
| PB_BLK | PB_EXIT | false | Exit button - closes the form |
| PB_BLK | PB_LIST | false | List button - inherited toolbar; disabled in this form |
| PB_BLK | PB_INSERT | false | Insert button - inherited toolbar; disabled in this form |
| PB_BLK | PM_CONT | false | Continue button - inherited toolbar; disabled in this form |
| PB_BLK | PB_DEL | false | Delete button - inherited toolbar; disabled in this form |
| PB_BLK | PB_CANCEL | false | Cancel button - cancels current operation |
| PB_BLK | PB_SAVE | false | Save button - inherited toolbar; disabled in this form |
| PB_BLK | PB_PRINT | false | Print button - inherited toolbar; disabled in this form |
| PB_BLK | PB_CUT | false | Cut button - cuts selected text region |
| PB_BLK | PB_COPY | false | Copy button - copies selected text region |
| PB_BLK | PB_PASTE | false | Paste button - pastes clipboard text region |
| PB_BLK | PB_ERR_EXIT | false | Error exit button - inherited; closes form on error |
| PB_BLK | NB_EXIT | false | Exit button (alternative) - sets exit flag and exits form without validation |
| PB_BLK | NB_CLEAR | false | Clear button - clears CB_DUMMY and B_VH/B_VD block data |
| PB_BLK | NB_OK | false | OK button - exits form without validation |
| CB_ERR | TXT_ERR | false | Error message display item in the inherited CB_ERR block (CN_ERR canvas); shows runtime error text surfaced by the ON-ERROR handler (inherited from DPL object group) |
| WEBUTIL | DUMMY | false | WebUtil placeholder item; hosts the WHEN-BUTTON-PRESSED trigger that fires WEBUTIL_ERROR alert on component errors (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item providing client machine information functions (hostname, IP address, OS) at runtime |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item providing client-side file system access functions used for file upload/download operations |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item providing host command execution functions on the client machine |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item providing session-level utility functions (e.g. client locale, session ID) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item providing file transfer functions between client and application server |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item providing OLE/COM automation functions for client-side Office integration |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item providing access to client-side C API / DLL calls |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item providing browser control functions (e.g. WEB.SHOW_DOCUMENT target control) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LOV_LOC | - | RG_LOC | CB_DUMMY.CB_DEALER_MAP_CD, CB_DUMMY.CB_LOC_CD, CB_DUMMY.CB_LOC_DESC |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Trigger: WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY (inherited from webutil.olb); fired when a WebUtil component reports an error |
| AL_ERRINFO | Error | (set at runtime) | Called by GENERAL.DISP_TEXT when displaying error-level messages; inherited from DPL object group |
| AL_NOTE | Note | (set at runtime) | Called by GENERAL.DISP_TEXT when displaying informational/note-level messages; inherited from DPL object group |
| AL_CONFIRM | Caution | (set at runtime) | Called by DPL library routines requiring user confirmation (Yes/No); inherited from DPL object group |
| AL_PRINT | Print | (set at runtime) | Called by ASK_PRINT DPL routine to present Screen / Printer / Cancel print options; inherited from DPL object group |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **3 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | ID_NULL (webutil), Find_Group, Delete_Group, Create_Group_From_Query, Populate_Group, TEXT_IO, WEB.SHOW_DOCUMENT | Legacy Excel export procedure that builds a CSV from a query record group and opens it in the browser. **NOTE: this is the old version - the active export uses VIEW_EXCEL_REPORT_NEW called directly from triggers.** |
| CLEAR_ITEMS | Procedure | (none) | Empty stub procedure; body contains no logic (IS BEGIN END) |
| POPULATE_DETAILS | Procedure | VH_RO_HOLD_UP, VD_RO_HOLD_UP, AM_LIST, GM_MOD, PM_PART, GENERAL.DISP_TEXT | Populates B_VD (summary) or B_VH (detail) blocks by executing CUR_SUM or CUR_DTL cursors against hold-up tables based on the selected REPORT_TYPE |

**Total Program Units:** 3

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.DISP_TEXT | Library routine | B_VD.SRV_DESC (WHEN-VALIDATE-ITEM), CB_DUMMY.HOLD_UP_DATE (WHEN-VALIDATE-ITEM), CB_DUMMY.PB_EXCEL (WHEN-BUTTON-PRESSED), CB_DUMMY.PB_SEARCH (WHEN-BUTTON-PRESSED), CB_DUMMY.SRV_TYPE (WHEN-VALIDATE-ITEM), Form level (ON-ERROR), ProgramUnit: POPULATE_DETAILS | Displays a text message in an alert dialog (AL_ERRINFO for errors, AL_NOTE for notes) with the supplied title |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Populates a list item with values at runtime; used during form initialisation to load drop-down list options |
| GENERAL.RAISE_ERROR | Library routine | Form level (ON-ERROR) | Looks up and displays an error message by code; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | FT_SAVE | Formerly committed the current record; delegated to the standard DPL save flow | Body is `null;`; inherited object group version is overridden by this empty stub |
| **Inactive stub** | Form | - | FT_DEL | Formerly deleted the current record; delegated to the standard DPL delete flow | Body is `null;`; inherited object group version is overridden by this empty stub |
| **Inactive stub** | Form | - | FT_PRINT | Formerly invoked the ASK_PRINT/RUN_REPORT print flow | Body is `null;`; inherited object group version is overridden by this empty stub |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (40 business triggers):**
*pi_veh_hold_up_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts form errors; displays error messages via GENERAL.DISP_TEXT for known error codes; handles record-locked errors and ORA exceptions; silently suppresses record-not-found messages (40401, 40405) |
| ON-MESSAGE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body is null; formerly displayed message-type form errors |
| KEY-EXIT | Form | - | Form level | Clears Oracle application context info and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current item; navigates to next item after successful selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - body is null; formerly validated inputs, committed the form, and cleared it |
| KEY-CLRFRM | Form | - | Form level | Clears the entire form without validation |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses unhandled key events; inherited from DPL object group |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Navigates to the next item in tab order; inherited from DPL object group |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Navigates to the previous item in tab order; inherited from DPL object group |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates to the next block; inherited from DPL object group |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates to the previous block; inherited from DPL object group |
| KEY-DOWN | Form | - | Form level (inherited) | Navigates to the next record within the current block; inherited from DPL object group |
| KEY-UP | Form | - | Form level (inherited) | Navigates to the previous record within the current block; inherited from DPL object group |
| FT_SAVE | Form | - | Form level (inherited) | **INACTIVE STUB** - overrides inherited DPL save trigger with a null body; save is not applicable for this read-only reporting form |
| FT_CANCEL | Form | - | Form level (inherited) | Cancels the current operation and reverts unsaved changes; inherited from DPL object group |
| FT_INSERT | Form | - | Form level (inherited) | Initiates insert mode on the current block; inherited from DPL object group |
| FT_DEL | Form | - | Form level (inherited) | **INACTIVE STUB** - overrides inherited DPL delete trigger with a null body; delete is not applicable for this reporting form |
| FT_LIST | Form | - | Form level (inherited) | Displays the LOV for the current item; inherited from DPL object group |
| FT_PRINT | Form | - | Form level (inherited) | **INACTIVE STUB** - overrides inherited DPL print trigger with a null body; print via report server is not used in this form |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises the form session: sets global variables (DEALER, PRINCIPAL, USERID, PARENT_GROUP), populates list items via GENERAL.L_POP_LIST_ITEM, and sets default values on CB_DUMMY; inherited from DPL object group |
| PRE-FORM | Form | - | Form level | Sets Oracle DBMS application info context to identify the running module for monitoring |
| WHEN-VALIDATE-ITEM | CB_DUMMY | SRV_TYPE | CB_DUMMY.SRV_TYPE | Validates that SRV_TYPE is one of 'A', 'N', 'Y' and not null; displays error via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE if invalid |
| WHEN-VALIDATE-ITEM | CB_DUMMY | HOLD_UP_DATE | CB_DUMMY.HOLD_UP_DATE | Validates that hold-up date is not null and not in the future; displays error via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE if invalid |
| WHEN-LIST-CHANGED | CB_DUMMY | REPORT_TYPE | CB_DUMMY.REPORT_TYPE | Clears B_VH or B_VD block depending on selected report type (Summary or Detail) |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_SEARCH | CB_DUMMY.PB_SEARCH | Validates hold-up date, checks data exists in VD_RO_HOLD_UP, then calls POPULATE_DETAILS to load results |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_EXCEL | CB_DUMMY.PB_EXCEL | Validates hold-up date and data availability, then exports hold-up data as CSV via VIEW_EXCEL_REPORT_NEW |
| WHEN-VALIDATE-ITEM | B_VD | SRV_DESC | B_VD.SRV_DESC | Validates that SRV_TYPE is a valid value (A, N, or Y) and not null; displays error via GENERAL.DISP_TEXT if invalid |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Checks form mode and status then exits the form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Delegates to inherited FT_LIST trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Delegates to inherited FT_INSERT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Delegates to inherited FT_DEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Delegates to inherited FT_CANCEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Delegates to inherited FT_SAVE trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Delegates to inherited FT_PRINT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Cuts the selected text region to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Copies the selected text region to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Pastes text from clipboard to current item |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_EXIT | PB_BLK.NB_EXIT | Sets :global.exit_flag to 'EXIT' and exits the form without validation |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_CLEAR | PB_BLK.NB_CLEAR | Clears CB_DUMMY and result blocks without validation |
| WHEN-BUTTON-PRESSED | PB_BLK | NB_OK | PB_BLK.NB_OK | Exits the form without validation |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Vehicle Pending in Workshop for want of Parts (Rel : 1.1.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_TOOL | Vertical Toolbar | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in pi_veh_hold_up_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in pi_veh_hold_up_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pi_veh_hold_up_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*29 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pi_veh_hold_up_fmb.xml.*

#### B_VH (29 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| APPLY_MODEL_CD | VARCHAR2 |
| CATG_CD | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| DEALER_MAP_CD | NUMBER |
| EFF_FROM_DATE | DATE |
| EFF_TO_DATE | DATE |
| LANDED_COST | NUMBER |
| MIN_ORD_QTY | NUMBER |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MRP_1 | NUMBER |
| PART_DESC | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| PRINCIPAL_MAP_CD | NUMBER |
| PURCHASE_PRICE | NUMBER |
| SELL_PRICE | NUMBER |
| SOURCE_CD | VARCHAR2 |
| UOM_CD | VARCHAR2 |
| ROOT_PART_NUM | VARCHAR2 |
| SEQ_NUM | NUMBER |
| TYPE_CD | VARCHAR2 |
| SUB_TYPE_CD | VARCHAR2 |
| TAG_CD | VARCHAR2 |
| MUL_YN | VARCHAR2 |
| VOR_YN | VARCHAR2 |
| SUB_CATG1_CD | VARCHAR2 |
| SUB_CATG2_CD | VARCHAR2 |
| BRAND_CD | VARCHAR2 |

**Total DataSourceColumns:** 29 across 1 blocks

## 9. Object Library

*This form references two Object Library files: `DPL_olb.xml` (the DPL library, containing Visual Attributes and Property Classes used across DMS forms) and `webutil_olb.xml` (the WebUtil library, containing the WEBUTIL object group for client-side utility integration). The form-level object_library metadata carries two object groups: `OG_GROUP` and `WEBUTIL`.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Visual attribute for check-box items; gray background, Arial 8pt | referenced | N/A |
| VA_RB | VisualAttribute | Visual attribute for radio-button items; gray background, Arial 8pt | referenced | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Visual attribute for iconic push buttons; white background, black foreground, transparent fill | referenced | N/A |
| VA_DESC | VisualAttribute | Visual attribute for description text items; gray background, Small Fonts 7pt | referenced | N/A |
| VA_NUM | VisualAttribute | Visual attribute for numeric text items; white background, Arial 8pt | referenced | N/A |
| VA_MAND | VisualAttribute | Visual attribute for mandatory input fields; cyan background, Arial 9pt | referenced | N/A |
| VA_OPROMPT | VisualAttribute | Prompt visual attribute for optional fields; transparent fill, white background, 8pt | referenced | N/A |
| VA_MPROMPT | VisualAttribute | Prompt visual attribute for mandatory fields; transparent fill, white background, 8pt | referenced | N/A |
| VA_TEXT | VisualAttribute | Visual attribute for general text items; white background, Arial 9pt | referenced | N/A |
| VA_BUTN | VisualAttribute | Visual attribute for push buttons; gray background, Arial 10pt bold | referenced | N/A |
| VA_ALERT | VisualAttribute | Visual attribute for alert dialogs; gray background, MT Extra 11pt demilight | referenced | N/A |
| VA_TITLE | VisualAttribute | Visual attribute for title/header labels; gray background, Arial 10pt bold | referenced | N/A |
| VA_TRNI_DT | VisualAttribute | Visual attribute for transaction date fields; white background, Courier bold, black foreground | referenced | N/A |
| VA_LOV | VisualAttribute | Visual attribute for LOV (list of values) fields; gray background, Arial 9pt, dark-blue foreground | referenced | N/A |
| VA_DISP | VisualAttribute | Visual attribute for display-only items; background r25g75b75, Arial 8pt bold | referenced | N/A |
| PC_DESC | PropertyClass | Property class for description text items; left-justified, 250 wide, transparent fill, max 110 chars | referenced | N/A |
| PC_SC_DATE | PropertyClass | Property class for date fields on search criteria; max 11 chars, gray background (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_TITLE | PropertyClass | Property class for title/header text items; centre-justified, transparent fill (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_FORMAT | PropertyClass | Property class for formatted text items; centre-justified, 60 wide, max 12 chars (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MR_BLK | PropertyClass | Property class for multi-record blocks; sets next navigation block to PB_BLK, no reverse direction, scrollbar width 12 | referenced | N/A |
| PC_DISP | PropertyClass | Property class for display-only items; left-justified, disabled, prompt 9pt, transparent fill (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_LOV | PropertyClass | Property class for LOV-linked fields; LOV position x=80 y=96, 250 wide, transparent fill (PROPERTY CLASS FOR LIST OF VALUES) | referenced | N/A |
| PC_FORM | PropertyClass | Property class for the form itself; validation unit = Item, savepoint mode off, console window WN_MAIN | referenced | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items; transparent fill (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items; transparent fill (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_DATE | PropertyClass | Property class for editable date fields; transparent fill (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_DTTIME | PropertyClass | Property class for date-and-time fields (Property class for Date and Time) | referenced | N/A |
| PC_CB | PropertyClass | Property class for check-box items | referenced | N/A |
| PC_ALERT | PropertyClass | Property class for alert dialogs | referenced | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date fields (PROPERTY CLASS FOR DATE) | referenced | N/A |
| PC_RB | PropertyClass | Property class for radio-button items | referenced | N/A |
| PC_WIND | PropertyClass | Property class for windows (PROPERTY CLASS FOR WINDOWS) | referenced | N/A |
| PC_CANV | PropertyClass | Property class for canvases | referenced | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | N/A |
| PC_TEXT | PropertyClass | Property class for standard text input items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text input items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_UTEXT | PropertyClass | Property class for upper-case text input items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory upper-case text input items (PROPERTY CLASS FOR TEXT ITEMS) | referenced | N/A |
| PC_NUM | PropertyClass | Property class for numeric input items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric input items (PROPERTY CLASS FOR NUMERIC ITEMS) | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (PROPERTY CLASS FOR PUSH BUTTONS) | referenced | N/A |
| PC_SCROLL | PropertyClass | Property class for scroll bars | referenced | N/A |
| OG_GROUP | ObjectGroup | Form-level object group defined in the form itself | 1 (form-level) | Form |
| WEBUTIL | ObjectGroup | The WebUtil object group containing all items, triggers, and program units needed to use WebUtil in Oracle Forms (from webutil_olb.xml) | 1 (form-level, WEBUTIL block) | WEBUTIL block items |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_LOC | Query | LOV_LOC | LOC_DESC | LOC_CD | No | Lists active dealer workshop locations authorized for the logged-in user to filter hold-up data | LOV_LOC -> CB_DUMMY.CB_DEALER_MAP_CD, CB_DUMMY.CB_LOC_CD, CB_DUMMY.CB_LOC_DESC |
| RG_CEO | Query | - | LIST_DESC | LIST_CODE | No | Lists CEO control point codes from the application master list for the current principal | - |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | - | - | No |
| B_VD | - | - | No |
| B_VH | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-NEW-FORM-INSTANCE | Dealer location master - queried during form initialisation to resolve and validate the dealer location context for the current session |
| `AM_LIST` | - | POPULATE_DETAILS, RG_CEO, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Application master list - lookup table for service categories (RCATEG_CD), availability sources (AVAIL_SOURCE), CEO control points, and other coded values; also consulted during form initialisation to seed parameter defaults |
| `AM_USERS` | - | Trigger WHEN-NEW-FORM-INSTANCE | Application users master - queried at form startup to retrieve user profile attributes (e.g. principal, dealer assignment) that govern the session's filtering and access behaviour |
| `AM_USER_DEALER_MASTER` | - | RG_LOC | User-dealer master - maps logged-in users to their authorized dealer locations for access control |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle system dual table - used as a query anchor for building CSV header rows in Excel export SQL |
| `GM_MOD` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Vehicle model master - provides model descriptions by model code and principal for display in hold-up detail |
| `PM_PART` | - | POPULATE_DETAILS | Parts master - provides part descriptions by part number and dealer for display in hold-up detail |
| `VD_RO_HOLD_UP` | - | Trigger WHEN-BUTTON-PRESSED | Vehicle hold-up detail - stores part-level hold-up records per job card, linked to VH_RO_HOLD_UP header |
| `VH_RO_HOLD_UP` | - | POPULATE_DETAILS, Trigger WHEN-BUTTON-PRESSED | Vehicle hold-up header - stores job card hold-up records for vehicles pending in workshop for want of parts |

**Total Referenced Objects:** 9

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | GENERAL.RAISE_ERROR | Raises a business-level error message mapped from an Oracle error code; used in the form-level error handler for referential-integrity violations |
| BR-002, BR-003, BR-004, BR-006, BR-007, BR-010 | GENERAL.DISP_TEXT | Displays a user-facing message at a specified severity (Error, Warning, Note) in the standard message dialog |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Sets (or clears) the client identifier for the current database session in the Oracle application monitoring infrastructure |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_MODULE | Sets (or clears) the module name and action name for the current database session in the Oracle application monitoring infrastructure |
| BR-006 | POPULATE_DETAILS | Retrieves vehicle parts hold-up data and populates the appropriate on-screen results block (summary or detail) based on the selected report type |
| BR-007 | VIEW_EXCEL_REPORT_NEW | Executes a dynamic SQL query and writes the results as a CSV file for download; used for both summary and detail Excel exports |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog to the user and returns the user's choice; called from the WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY before proceeding with a potentially destructive action |
| - | GENERAL.L_POP_LIST_ITEM | Populates a list item control from a named record group; called during form initialisation (WHEN-NEW-FORM-INSTANCE) to seed drop-down controls before user interaction |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatch routine; routes asynchronous client-side events raised by WebUtil bean items to the appropriate WebUtil functional module |
| - | WEBUTIL.ID_NULL | Checks whether an Oracle Forms object handle is null; used in VIEW_EXCEL_REP to test whether the DataRecordSet record group already exists before attempting to delete it |

---

### 12.2 Procedure and Package Catalogue

#### GENERAL

The GENERAL package is provided by the DPL attached library (`DPL.pld` / `DPL.pll`). It supplies common utility routines used across DMS Oracle Forms.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Package procedure | ON-ERROR trigger (form level); WHEN-VALIDATE-ITEM on CB_DUMMY.SRV_TYPE; WHEN-VALIDATE-ITEM on CB_DUMMY.HOLD_UP_DATE; WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH; WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL; WHEN-VALIDATE-ITEM on B_VD.SRV_DESC; POPULATE_DETAILS program unit | Displays a message dialog to the user using alert AL_ERRINFO (when title is 'Error') or AL_NOTE (all other titles). Accepts the message text and dialog title as parameters. Used throughout the form to report validation errors, data-not-found conditions, and general information messages |
| GENERAL.RAISE_ERROR | Package procedure | ON-ERROR trigger (form level) | Looks up the business-level error message for the supplied error code, formats it with a type prefix, and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE to halt processing. Called when a database integrity constraint violation (ORA-02292) is detected |
| GENERAL.ASK_CONFIRM | Package function | WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message text and returns a numeric result indicating the user's choice; used to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action |
| GENERAL.L_POP_LIST_ITEM | Package procedure | WHEN-NEW-FORM-INSTANCE trigger (form level) | Populates a list item control from a named record group. Accepts the record group name and an optional default selection value. Called during form initialisation to load list-of-values data into drop-down controls before the user begins interacting with the form |

#### DBMS_APPLICATION_INFO

The DBMS_APPLICATION_INFO package is an Oracle-supplied built-in package for session-level application tracking.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Package procedure | PRE-FORM trigger; KEY-EXIT trigger | Sets (PRE-FORM: `pi_veh_hold_up`) or clears (KEY-EXIT: null) the client identifier for the current database session to enable activity monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Package procedure | PRE-FORM trigger; KEY-EXIT trigger | Sets (PRE-FORM: module `pi_veh_hold_up`, action `''`) or clears (KEY-EXIT: module `''`, action `''`) the module and action names for the current database session |

#### POPULATE_DETAILS

POPULATE_DETAILS is a form-level program unit (PROCEDURE) defined in the form XML itself.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POPULATE_DETAILS | Form program unit (Procedure) | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH | Queries VH_RO_HOLD_UP and VD_RO_HOLD_UP (joined) with VT_REQ, AM_LIST, GM_MOD, and PM_PART; populates either the summary results block (report type Summary) or the detail results block (report type Detail) with the retrieved hold-up data. Calls GENERAL.DISP_TEXT to surface data-not-found and validation messages to the user |

#### VIEW_EXCEL_REPORT_NEW

VIEW_EXCEL_REPORT_NEW is provided by the DMS_EXCEL_REPORT attached library (`dms_excel_report.pld` / `dms_excel_report.pll`). It is the active replacement for the older VIEW_EXCEL_REP form program unit.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REPORT_NEW | Library procedure | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL | Accepts a principal identifier, filename, SQL query string, column alias, and application ID; executes the query and writes results as a CSV file for delivery to the user |

#### VIEW_EXCEL_REP

VIEW_EXCEL_REP is a form-level program unit (PROCEDURE) defined in the form XML itself. It is an older export implementation that has been superseded by VIEW_EXCEL_REPORT_NEW; its call-site lines in PB_EXCEL are commented out.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REP | Form program unit (Procedure) - superseded, call sites commented out | WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL (commented out) | Legacy implementation: creates a record group from a query, writes rows to a server-side text file, reads a URL path from an external configuration file, and opens the resulting file in the browser - no longer called in the current active code |

#### CLEAR_ITEMS

CLEAR_ITEMS is a form-level program unit (PROCEDURE) defined in the form XML itself. Its body contains only a BEGIN/END with no statements.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| CLEAR_ITEMS | Form program unit (Procedure) - empty body | Not called from any active trigger or program unit in the current slice | Placeholder procedure with no implementation; does not execute any business logic |

#### WEBUTIL_CORE

The WEBUTIL_CORE package is provided by the WebUtil attached library (`webutil.pld` / `webutil.pll`). It supplies the central event-dispatch infrastructure for the WebUtil client-integration framework.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Package procedure | WHEN-CUSTOM-ITEM-EVENT trigger on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_C_API_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_FILE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_HOST_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_OLE_FUNCTIONS; WHEN-CUSTOM-ITEM-EVENT on WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine. Receives the name and serialised parameters of a custom client-side event raised by a WebUtil bean item and routes processing to the appropriate WebUtil functional module, ensuring that asynchronous responses from the WebUtil Java applet (file transfer completions, host command results, OLE callbacks, session data, etc.) are handled in a single, consistent entry point |

#### WEBUTIL (C API)

The WEBUTIL.ID_NULL function is part of the WebUtil C-API wrapper exposed through the WebUtil attached library (`webutil.pld` / `webutil.pll`).

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL.ID_NULL | Package function | VIEW_EXCEL_REP form program unit (superseded - call sites commented out) | Checks whether a given Oracle Forms object handle (such as a RecordGroup ID) is null; returns TRUE if the handle is uninitialised. Used in VIEW_EXCEL_REP to determine whether the DataRecordSet record group already exists before attempting to delete it. Referenced only in the legacy VIEW_EXCEL_REP routine, which is no longer called |

#### WEB

The WEB package is referenced in the VIEW_EXCEL_REP form program unit (via `web.show_document`). It is an Oracle Forms Web utility package used to open URLs in the browser.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Package procedure | VIEW_EXCEL_REP form program unit (superseded - call sites commented out) | Opens the generated report file URL in the browser window; only referenced in the legacy VIEW_EXCEL_REP routine, which is no longer called |

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/section-rewrite-pipeline/workspaces/191cd5d1-c6ef-4ca7-a37f-debb9fa44dcc/inputs/form_sources``. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/191cd5d1-c6ef-4ca7-a37f-debb9fa44dcc/inputs/form_sources`. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message text and returns a numeric result indicating the user's choice. Called from the WHEN-BUTTON-PRESSED trigger on WEBUTIL.DUMMY to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-VALIDATE-ITEM in B_VD.SRV_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.HOLD_UP_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.SRV_TYPE | Displays a message dialog to the user using alert AL_ERRINFO (when title is 'Error') or AL_NOTE (all other titles). Accepts the message text and dialog title as parameters. Used throughout the form to report validation errors, data-not-found conditions, and general information messages. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a list item control from a named record group. Accepts the record group name and an optional default selection value. Called during form initialisation (WHEN-NEW-FORM-INSTANCE) to load list-of-values data into drop-down controls before the user begins interacting with the form. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by code, formats it with type prefix, and displays it via DISP_TEXT. Raises FORM_TRIGGER_FAILURE for error-type messages. Called from ON-ERROR when a database integrity constraint violation (ORA-02292) is detected. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pi_veh_hold_up_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | **COMMENTED OUT / INACTIVE** - Previously called after enter and commit_form in KEY-COMMIT to verify the form operation succeeded and raise FORM_TRIGGER_FAILURE if not. The entire KEY-COMMIT trigger body is block-commented and the active body is null. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatch routine. Receives the name and serialised parameters of a custom client-side event raised by a WebUtil bean item and routes processing to the appropriate WebUtil functional module. Each WHEN-CUSTOM-ITEM-EVENT trigger on the named WEBUTIL canvas items delegates immediately to this procedure, ensuring that asynchronous responses from the WebUtil Java applet (file transfer completions, host command results, OLE callbacks, session data, etc.) are handled in a single, consistent entry point. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a given Oracle Forms object handle (such as a RecordGroup ID) is null. Returns TRUE if the handle is uninitialized. Used in VIEW_EXCEL_REP to determine whether the DataRecordSet record group already exists before attempting to delete it. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Vehicle Hold-Up Summary Service | VH_RO_HOLD_UP, VD_RO_HOLD_UP, AM_LIST | holdUpDate, dealerMapCd, locCd, srvType, parentGroup, principal | Array of service-category rows: categoryCode, categoryDescription, pendingOver1Day (count), pendingOver3Days (count), pendingOver7Days (count) | Retrieves vehicle hold-up summary data grouped by service category for a given date, location, and service type; provides the data underlying the Summary report view | GET /api/v1/vehicle-hold-up/summary |
| MS-002 | Vehicle Hold-Up Detail Service | VH_RO_HOLD_UP, VD_RO_HOLD_UP, VT_REQ, AM_LIST, GM_MOD, PM_PART | holdUpDate, dealerMapCd, locCd, srvType, parentGroup, principal | Array of vehicle-part rows: pendingDays, vehicleNo, jobCardNo, model, serviceType, jobCardDate, partNum, partDesc, requisitionNo, requisitionDate, requiredQty, issuedQty, liveStockAvailable, deadStockAvailable, availabilitySource, orderNumber | Retrieves individual vehicle parts hold-up detail records for a given date, location, and service type; provides the data underlying the Detail report view | GET /api/v1/vehicle-hold-up/detail |
| MS-003 | Hold-Up Existence Check Service | VD_RO_HOLD_UP | holdUpDate, dealerMapCd, locCd | Boolean: dataExists (true/false), recordCount | Checks whether any hold-up records exist for the given date and location before the user runs a search or export; prevents meaningless empty result operations | GET /api/v1/vehicle-hold-up/exists |
| MS-004 | Hold-Up Excel Export Service | VH_RO_HOLD_UP, VD_RO_HOLD_UP, VT_REQ, AM_LIST, GM_MOD, PM_PART | holdUpDate, dealerMapCd, locCd, srvType, reportType (summary or detail), parentGroup, principal, userId, appId | CSV file stream (MIME type text/csv), filename in Content-Disposition header | Generates and delivers a downloadable CSV export of the vehicle parts hold-up data for the selected criteria and report type; replaces the VIEW_EXCEL_REPORT_NEW library call | POST /api/v1/vehicle-hold-up/export |
| MS-005 | Location Lookup Service | AM_DEALER_LOC, AM_USER_DEALER_MASTER | userId, principal | Array of location rows: locationDescription, locationCode, dealerMapCd | Retrieves the list of dealer locations the current user is authorised to access for the hold-up enquiry; replaces the LOV_LOC / RG_LOC record group query | GET /api/v1/locations/authorised |
| MS-006 | Reference List Lookup Service | AM_LIST | principal, listName | Array of code-description pairs: listCode, listDesc | Retrieves code-description pairs from the reference list for a given list name (e.g. RCATEG_CD for service categories, AVAIL_SOURCE for availability sources); used to resolve display labels for coded values in results | GET /api/v1/reference/list/{listName} |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Startup | User opens the vehicle parts hold-up enquiry form (PRE-FORM fires) | 1. Set application client info to `pi_veh_hold_up`. 2. Set application module name to `pi_veh_hold_up` with blank action. 3. Form opens and displays the search criteria screen. | None | Search criteria screen displayed; session tracking active |
| WF-002 | Error Interception and User Notification | An error is raised during any form operation (ON-ERROR fires) | 1. Capture error code, error text, error type, database error code, and database error text. 2. Check if database error code is -02292 (referential-integrity violation) -> call GENERAL.RAISE_ERROR with `E0088`; stop. 3. Check if error code is in (40209, 40207, 50026, 50004) -> display formatted error message via GENERAL.DISP_TEXT; raise FORM_TRIGGER_FAILURE; stop. 4. Check if error code is in (40654-40659) -> display record-locking message via GENERAL.DISP_TEXT; rollback; raise FORM_TRIGGER_FAILURE; stop. 5. Check if SQL error code is non-zero -> display database error text via GENERAL.DISP_TEXT; rollback; raise FORM_TRIGGER_FAILURE; stop. 6. Check if error code is in (40401, 40405) -> suppress silently (null); stop. | Multiple branches by error code | User sees appropriate error message (or no message for suppressed codes); pending transaction rolled back where applicable; form remains open |
| WF-003 | Service Type Validation on Field Exit | User leaves the Service Type field on the search criteria screen or the Type of Service field in the summary results block (WHEN-VALIDATE-ITEM fires) | 1. Check if service type value is not in the three accepted options -> display *"Plase select service type from list"* via GENERAL.DISP_TEXT; raise FORM_TRIGGER_FAILURE; stop. 2. Check if service type value is null -> display *"Service Type can not be null"* via GENERAL.DISP_TEXT; raise FORM_TRIGGER_FAILURE; stop. 3. Both checks pass -> validation succeeds; user continues. | Two sequential guard checks | Validation passed (user proceeds) or error displayed (user corrects the field) |
| WF-004 | Hold Up Date Validation on Field Exit | User leaves the Hold Up Date field (WHEN-VALIDATE-ITEM fires) | 1. Check if Hold Up Date is not null. 2. If provided: check if date is later than today -> show alert *"Hold Up Date cannot be greater than Current Date"*; raise FORM_TRIGGER_FAILURE; stop. 3. If not provided: display *"From Date can not be empty"* via GENERAL.DISP_TEXT; raise FORM_TRIGGER_FAILURE; stop. 4. Both checks pass -> validation succeeds; user continues. | Date-present branch; date-future sub-check | Validation passed (user proceeds) or error displayed (user corrects the field) |
| WF-005 | Report Type Change Clears Results | User changes the Report Type selection (WHEN-LIST-CHANGED fires) | 1. Check if new Report Type is Summary ('S'). 2. If Summary: navigate to summary results block; clear block; navigate back to search criteria block. 3. If not Summary (Detail): navigate to detail results block; clear block; navigate back to search criteria block. | Report type branch (Summary vs Detail) | Results block matching the newly selected type is cleared; search criteria remain unchanged |
| WF-006 | Search and Display Hold-Up Data | User clicks the Search button (WHEN-BUTTON-PRESSED on CB_DUMMY.PB_SEARCH) | 1. Check if Hold Up Date is null -> display *"Hold Up Date can not be null"*; raise FORM_TRIGGER_FAILURE; stop. 2. Query VD_RO_HOLD_UP for count of records matching date, dealer, and location. 3. If count ≤ 0 -> display *"Vehicle Pending for Parts Data is not available for Date"*; raise FORM_TRIGGER_FAILURE; stop. 4. Call POPULATE_DETAILS. 5. POPULATE_DETAILS: check report type; if Summary -> clear B_VD block; open CUR_SUM cursor; for each row populate service description, pending-over-1/3/7-day counts; navigate to first record. If Detail -> clear B_VH block; open CUR_DTL cursor; for each row populate all detail fields including lookups from GM_MOD, AM_LIST (RCATEG_CD), PM_PART, AM_LIST (AVAIL_SOURCE); navigate to first record. 6. On NO_DATA_FOUND -> display *"Data not available"* warning; stop. 7. On WHEN OTHERS -> display *"Unable to populate"* + SQLERRM error text; stop. | Null-date check; count check; report-type branch; individual-lookup exception branches | Results block populated with hold-up data, or user sees an appropriate error/warning if data is unavailable or an error occurs |
| WF-007 | Export Hold-Up Data to Excel | User clicks the Export to Excel button (WHEN-BUTTON-PRESSED on CB_DUMMY.PB_EXCEL) | 1. Check if Hold Up Date is null -> display *"Hold Up Date can not be null"*; raise FORM_TRIGGER_FAILURE; stop. 2. Query VD_RO_HOLD_UP for count of records matching date, dealer, and location. 3. If count ≤ 0 -> display *"Vehicle Pending for Parts Data is not available for Date"*; raise FORM_TRIGGER_FAILURE; stop. 4. Build unique CSV filename from user ID and current timestamp. 5. Check report type: if Summary -> build summary SQL query (service-type grouping with pending-day counts); if Detail -> build detail SQL query (all vehicle and parts columns). 6. Call VIEW_EXCEL_REPORT_NEW with principal, filename, query, column alias, and application ID. 7. On WHEN OTHERS (outermost) -> suppress silently (null); stop. | Null-date check; count check; report-type branch for query construction; outer exception suppression | CSV file delivered to user for download (Summary or Detail format), or silent suppression of any outer-level error |
| WF-008 | Exit Form | User presses the Exit key shortcut, or clicks PB_EXIT, NB_EXIT, or NB_OK | Keyboard (KEY-EXIT): 1. Clear DBMS_APPLICATION_INFO client info (null). 2. Clear DBMS_APPLICATION_INFO module and action (both ''). 3. Close form without saving. PB_EXIT button: 1. Check if form is in ENTER-QUERY mode -> close form. 2. If form has unsaved changes -> close form without saving. 3. Otherwise -> close form without saving. NB_EXIT button: 1. Set GLOBAL.EXIT_FLAG to 'EXIT'. 2. Close form without saving. NB_OK button: 1. Close form without saving. | KEY-EXIT vs PB_EXIT vs NB_EXIT vs NB_OK; enter-query mode check (PB_EXIT) | Form closed without saving; session context cleared (keyboard exit only) |
| WF-009 | Clear Form Data | User presses the Clear key shortcut or clicks NB_CLEAR | KEY-CLRFRM: 1. Clear all form blocks without validation. NB_CLEAR: 1. Navigate to PM_PART_DEAD_STOCK block; clear without validation. 2. Navigate to cb_dummy block; clear without validation. | KEY-CLRFRM vs NB_CLEAR | All data cleared from the relevant blocks; form ready for a new search |

**Total Workflows Identified: 9**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is evaluated, then returns whether the handle is null to guide group creation or deletion logic. |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | **COMMENTED OUT / INACTIVE** - When KEY-COMMIT fires, then verifies the form operation succeeded and raises failure if not; entire call site is block-commented. |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: POPULATE_DETAILS, Trigger: ON-ERROR in Form, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in CB_DUMMY.PB_SEARCH, Trigger: WHEN-VALIDATE-ITEM in B_VD.SRV_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.HOLD_UP_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.SRV_TYPE | /api/v1/pld/disp_text | When an error or informational condition arises, then a labelled alert dialog is displayed to the user with the supplied message text and title. |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a database error code is caught during form error handling, then the error message is looked up by code and displayed; execution is halted for error-type messages. |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pi_veh_hold_up_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pi_veh_hold_up-abfdb6c1b14e/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Vehicle Hold-Up Header (VH_RO_HOLD_UP) | Table - SELECT | Source of vehicle-level hold-up records; used by POPULATE_DETAILS and the Excel export query to retrieve hold-up data filtered by date, location, service type, and repair-order status | Form -> Database (read) | Inner exceptions on individual lookup sub-queries suppressed with WHEN OTHERS THEN NULL; main query NO_DATA_FOUND triggers *"Data not available"* warning; WHEN OTHERS triggers error display |
| Vehicle Hold-Up Detail (VD_RO_HOLD_UP) | Table - SELECT | Source of part-level hold-up records; joined to VH_RO_HOLD_UP in data queries; also used standalone for the pre-search/pre-export existence count | Form -> Database (read) | WHEN OTHERS on count query suppressed with NULL; WHEN OTHERS on main query triggers error display |
| Parts Requisition (VT_REQ) | Table - SELECT (outer join) | Provides requisition details (requisition number, date, required qty, issued qty) for each vehicle-part combination in the detail results view | Form -> Database (read) | Joined as outer join; no separate error handler; exceptions on main query covered by POPULATE_DETAILS WHEN OTHERS |
| Parts Master (PM_PART) | Table - SELECT | Provides part descriptions for display in the detail results block; looked up per part number and principal | Form -> Database (read) | WHEN OTHERS THEN NULL on individual per-row sub-query; field left blank if not found |
| Vehicle Model Master (GM_MOD) | Table - SELECT | Provides vehicle model descriptions for display in the detail results block; looked up per model code and principal | Form -> Database (read) | WHEN OTHERS THEN NULL on individual per-row sub-query; field left blank if not found |
| Reference List (AM_LIST) | Table - SELECT | Provides human-readable descriptions for service categories (RCATEG_CD) and availability sources (AVAIL_SOURCE) in both on-screen results and Excel export; also used as source for CEO control point record group (RG_CEO) | Form -> Database (read) | WHEN OTHERS THEN NULL on individual per-row sub-queries; field left blank if not found |
| Location Master (AM_DEALER_LOC, AM_USER_DEALER_MASTER) | Tables - SELECT (record group query) | Provides the list of authorised dealer locations for the Location LOV, filtered by current user, principal, dealer type, and spares access | Form -> Database (read) | Standard record-group population; errors handled by form-level ON-ERROR trigger |
| Oracle Application Monitoring (DBMS_APPLICATION_INFO) | Oracle built-in package - CALL | Registers and clears the form's identity in the database session tracking framework at form open and keyboard exit | Form -> Database session (write) | No explicit error handling; if call fails, form continues normally |

### 20.2 External System Integrations

This form does not directly integrate with any external system outside the Oracle database. The attached library `DMS_EXCEL_REPORT` (VIEW_EXCEL_REPORT_NEW) generates a CSV file and makes it available for client-side download, but this is handled entirely within the Oracle Forms and library infrastructure; no external web service or messaging system is invoked. The WebUtil library provides client-side file utilities (used by the WEBUTIL block) but no active triggers in this form invoke any WebUtil routines for external system communication.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS Excel Report Library (VIEW_EXCEL_REPORT_NEW) | Attached PL/SQL library - in-process call | Generates and delivers a CSV export of vehicle hold-up data to the user | In-process (Oracle Forms library call) | N/A - in-process | SQL query results written as CSV file; file delivered to client | Silent WHEN OTHERS suppression at outer level; no explicit return code |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - Oracle Reports server | INFERRED - report parameters not explicitly set in the active trigger code | INFERRED - Oracle Reports output (PDF/HTML) | WHEN-BUTTON-PRESSED on PB_BLK.PB_PRINT delegates to EXECUTE_TRIGGER('FT_PRINT'); the FT_PRINT trigger is not defined within this form's active code - rep.rdf is the report filename registered in the form's Report object (REPORT_CALL); actual invocation is via the FT_PRINT trigger mechanism which is not included in this form's active trigger set |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PI_VEH_HOLD_UP form.

### 21.1 Catalogue Index

82 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--POPULATE_DETAILS) | POPULATE_DETAILS |
| [SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-003](#SP-003--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-011](#SP-011--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-013](#SP-013--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-014](#SP-014--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-015](#SP-015--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-016](#SP-016--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-017](#SP-017--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-018](#SP-018--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-019](#SP-019--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-020](#SP-020--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-021](#SP-021--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-024](#SP-024--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-025](#SP-025--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-026](#SP-026--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-027](#SP-027--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-028](#SP-028--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-029](#SP-029--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-030](#SP-030--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-034](#SP-034--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-035](#SP-035--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-037](#SP-037--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-038](#SP-038--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-039](#SP-039--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-040](#SP-040--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-041](#SP-041--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-042](#SP-042--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-043](#SP-043--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-044](#SP-044--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-045](#SP-045--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-046](#SP-046--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-047](#SP-047--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-048](#SP-048--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-049](#SP-049--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-050](#SP-050--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-051](#SP-051--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-052](#SP-052--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-053](#SP-053--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-054](#SP-054--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-055](#SP-055--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-056](#SP-056--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-058](#SP-058--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-059](#SP-059--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-060](#SP-060--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-061](#SP-061--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-063](#SP-063--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-064](#SP-064--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-065](#SP-065--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-066](#SP-066--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-067](#SP-067--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-068](#SP-068--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-069](#SP-069--ADD_ERROR) | ADD_ERROR |
| [SP-070](#SP-070--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-071](#SP-071--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-072](#SP-072--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-073](#SP-073--DEBUGLOG) | DEBUGLOG |
| [SP-074](#SP-074--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-075](#SP-075--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-076](#SP-076--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-077](#SP-077--READ_REGISTRY) | READ_REGISTRY |
| [SP-078](#SP-078--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-079](#SP-079--SETDEBUG) | SETDEBUG |
| [SP-080](#SP-080--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-081](#SP-081--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-082](#SP-082--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - POPULATE_DETAILS

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Populates the vehicle hold-up screen with either a summary view or a detailed view of repair orders (ROs) that are currently on hold, based on the selected report type. For the summary view, the procedure aggregates pending RO counts by service category and ageing bands. For the detail view, it retrieves individual RO lines enriched with part, model, service-type, and part-status descriptions. Any data retrieval failure is surfaced to the user via GENERAL.DISP_TEXT.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the :REPORT_TYPE global variable to determine whether to populate the summary block (B_VD) or the detail block (B_VH).
- Step 2 (Summary path - :REPORT_TYPE = 'S') - Enable insert and update properties on block B_VD, navigate to the block, clear existing records, and reset the serial counter.
- Step 3 (Summary path) - Execute CUR_SUM, which joins VH_RO_HOLD_UP, VD_RO_HOLD_UP, and AM_LIST to aggregate, per service category, the total pending RO count and three ageing-band counts (>1 day, >3 days, >7 days) filtered by parent group, dealer, location, hold-up date, RO status 10, promised-date rule, service-type filter, and principal map code.
- Step 4 (Summary path) - For each row returned by CUR_SUM, write the service description, pend_1, pend_3, and pend_7 values into the current B_VD record and advance to the next record; return focus to the first record when the loop ends.
- Step 5 (Detail path - :REPORT_TYPE ≠ 'S') - Enable insert and update properties on block B_VH, navigate to the block, clear existing records, and reset the serial counter.
- Step 6 (Detail path) - Execute CUR_DTL, which joins VH_RO_HOLD_UP, VD_RO_HOLD_UP, and VT_REQ (outer join) applying the same filter criteria as the summary cursor, ordering results by RO date and part number.
- Step 7 (Detail path) - For each row returned by CUR_DTL, populate B_VH fields: serial number (system cursor record), pending days, vehicle registration, RO number, RO date, part number, requisition number, requisition date, requested quantity, issued quantity, order number, live-stock availability flag (decoded to Yes/No), and dead-stock availability flag (decoded to Yes/No).
- Step 8 (Detail path) - Perform a scalar lookup against GM_MOD filtered by principal_map_cd and model_cd to resolve the model description into :B_VH.model; suppress any exception silently.
- Step 9 (Detail path) - Perform a scalar lookup against AM_LIST (list_name = 'RCATEG_CD') filtered by principal_map_cd and list_code to resolve the service-type description into :B_VH.service_type; suppress any exception silently.
- Step 10 (Detail path) - Perform a scalar lookup against PM_PART filtered by dealer_map_cd, principal_map_cd, and part_num to resolve the part description into :B_VH.part_desc; suppress any exception silently.
- Step 11 (Detail path) - Perform a scalar lookup against AM_LIST (list_name = 'AVAIL_SOURCE') filtered by principal_map_cd and list_code to resolve the part-status description into :B_VH.part_status; suppress any exception silently.
- Step 12 (Detail path) - Advance to the next B_VH record after each iteration; return focus to the first record when the loop ends.
- Step 13 (Exception handling) - If NO_DATA_FOUND is raised at the outer level, call GENERAL.DISP_TEXT to display 'Data not available' with severity 'Note'. For any other exception, call GENERAL.DISP_TEXT to display 'Unable to populate' concatenated with SQLERRM with severity 'Error'.

---
**Decision Points**

DP-001

Condition:
:REPORT_TYPE = 'S'

TRUE:
The procedure populates the summary block (B_VD) by executing CUR_SUM, which groups hold-up ROs by service category and computes ageing-band counts (pend_1, pend_3, pend_7).

FALSE:
The procedure populates the detail block (B_VH) by executing CUR_DTL, which retrieves individual RO lines with part, requisition, and stock-availability details.

---

DP-002

Condition:
:CB_DUMMY.srv_type = 'N'

TRUE:
Only ROs whose rcateg_cd is NOT equal to 'BANDP' (non-body-and-paint service categories) are included in both cursors.

FALSE:
Evaluate DP-003.

---

DP-003

Condition:
:CB_DUMMY.srv_type = 'A'

TRUE:
Only ROs whose rcateg_cd equals 'BANDP' (body-and-paint) are included in both cursors.

FALSE:
:CB_DUMMY.srv_type = 'Y' is assumed; all ROs regardless of rcateg_cd are included (tautological predicate rcateg_cd = rcateg_cd).

---

DP-004

Condition:
h.hold_up_date >= NVL(TRUNC(promised_date), h.hold_up_date)

TRUE:
The RO has reached or passed its promised date (or has no promised date), and is eligible for inclusion in the hold-up results.

FALSE:
The RO has not yet reached its promised date and is excluded from both cursors.

---

DP-005

Condition:
Scalar lookup against GM_MOD, AM_LIST (RCATEG_CD), PM_PART, or AM_LIST (AVAIL_SOURCE) raises an exception during detail-row processing.

TRUE:
The exception is silently suppressed (EXCEPTION WHEN OTHERS THEN NULL); the corresponding description field remains unpopulated, and processing continues with the next field or record.

FALSE:
The description value is successfully retrieved and written to the corresponding B_VH field.

---

DP-006

Condition:
Outer-level NO_DATA_FOUND exception is raised.

TRUE:
GENERAL.DISP_TEXT is called with the message 'Data not available' and severity 'Note'.

FALSE:
If a different exception is raised, GENERAL.DISP_TEXT is called with 'Unable to populate' concatenated with SQLERRM and severity 'Error'.

---
**Database Interactions**

- DB-001 - Read VH_RO_HOLD_UP - Reads data from VH_RO_HOLD_UP for lookup or validation.
- DB-002 - Read GM_MOD - Reads data from GM_MOD for lookup or validation.
- DB-003 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-004 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Only ROs with ro_status = 10 are considered active hold-up records eligible for display in either the summary or detail view.
- BR-002 - An RO is included only when the hold-up date is on or after the NVL-adjusted promised date (NVL(TRUNC(promised_date), hold_up_date)), ensuring that ROs not yet due are excluded.
- BR-003 - Results are always scoped to the current session's parent group (:GLOBAL.PARENT_GROUP), dealer (:CB_DUMMY.CB_DEALER_MAP_CD), location (:CB_DUMMY.CB_LOC_CD), and hold-up date (:CB_DUMMY.HOLD_UP_DATE), preventing cross-dealer or cross-location data leakage.
- BR-004 - Service-type filtering is mutually exclusive: srv_type 'N' restricts to non-BANDP categories, srv_type 'A' restricts to BANDP only, and srv_type 'Y' returns all categories.
- BR-005 - All reference-data lookups (service category descriptions via AM_LIST, model descriptions via GM_MOD, part descriptions via PM_PART, part-status descriptions via AM_LIST) are filtered by :GLOBAL.principal (principal_map_cd) to enforce multi-organisation data isolation.
- BR-006 - Ageing bands in the summary view are calculated as the difference between hold_up_date and the truncated ro_date: pend_1 counts ROs with a difference greater than 1 day, pend_3 counts those greater than 3 days, and pend_7 counts those greater than 6 days (representing a 7-day threshold via SIGN(diff-6) > 0).
- BR-007 - Live-stock and dead-stock availability indicators stored as 'Y'/'N' flags are decoded to human-readable 'Yes'/'No' values before display in the detail block.
- BR-008 - Failures in individual scalar description lookups (model, service type, part description, part status) are silently suppressed so that a missing reference-data entry does not prevent the remainder of the RO detail record from being displayed.
- BR-009 - When no data is found at the outer procedure level, the user is notified via GENERAL.DISP_TEXT with a 'Note' severity; all other unexpected errors are reported via GENERAL.DISP_TEXT with an 'Error' severity including the Oracle error message.

---
**Implementation Logic**

```plsql
PROCEDURE populate_details 
IS
  CURSOR CUR_SUM IS
		SELECT rcateg_cd, list_desc srv_desc, 
    	     count(ro_num) pending,
       		 SUM(decode(sign(diff),1,1,0))   pend_1 ,
       		 SUM(decode(sign(diff-2),1,1,0)) pend_3 ,
       		 SUM(decode(sign(diff-6),1,1,0)) Pend_7 	   
  		FROM (SELECT distinct h.parent_group, h.dealer_map_cd, h.loc_cd, 
      			 		   h.hold_up_date, h.ro_num, h.ro_date, h.rcateg_cd,
	   		   				 h.hold_up_date - trunc(h.ro_date) diff
          		FROM vh_ro_hold_up h, vd_ro_hold_up d
         		 WHERE h.parent_group = :GLOBAL.PARENT_GROUP
   	       		 AND h.dealer_map_cd = :CB_DUMMY.CB_DEALER_MAP_CD --:GLOBAL.DEALER
   		   			 AND h.loc_cd = :CB_DUMMY.CB_LOC_CD
   		   			 AND h.hold_up_date = :CB_DUMMY.HOLD_UP_DATE
   		   			 AND h.ro_status = 10 
   		   			 AND h.hold_up_date >= nvl(trunc(promised_date),h.hold_up_date)    
   		   			 AND (:CB_DUMMY.srv_type = 'N' and h.rcateg_cd != 'BANDP' or :CB_DUMMY.srv_type = 'A' and h.rcateg_cd = 'BANDP'
               		                                                      or :CB_DUMMY.srv_type = 'Y' and h.rcateg_cd = h.rcateg_cd) 
           		 AND h.hold_up_date >= nvl(trunc(h.promised_date),h.hold_up_date)
   		   			 AND h.parent_group = d.parent_group
   		   			 AND h.dealer_map_cd = d.dealer_map_cd
   		   			 AND h.loc_cd = d.loc_cd
   		   			 AND h.ro_num = d.ro_num
   		   			 AND h.hold_up_date = d.hold_up_date 
						 )b, am_list a
 	   WHERE list_name = 'RCATEG_CD'   
   		 AND a.principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
   		 AND a.list_code = b.rcateg_cd		
 		 GROUP BY rcateg_cd, list_desc;

  CURSOR CUR_DTL IS
		SELECT h.hold_up_date - trunc(h.ro_date) pend_day,
       		 h.vin, h.rcateg_cd, h.ro_num, h.reg_num,
       		 h.ro_date,
       		 --to_char(h.ro_date,'dd-mm-yyyy hh24:mi') ro_date, 
       		 h.model_code, d.part_num,
	   			 r.req_num, to_char(r.req_date,'dd-mm-yyyy hh24:mi') req_dt, 
	   			 r.req_qty, r.iss_qty, d.order_num, d.part_status,
	   			 decode(d.live_stock_avl,'Y','Yes','N','No') live_stock,
	   			 decode(d.dead_stock_avl,'Y','Yes','N','No') dead_stock 
  		FROM vh_ro_hold_up h, vd_ro_hold_up d, vt_req r
 		 WHERE h.parent_group = :GLOBAL.PARENT_GROUP
   		 AND h.dealer_map_cd = :CB_DUMMY.CB_DEALER_MAP_CD--:GLOBAL.DEALER
   		 AND h.loc_cd = :CB_DUMMY.CB_LOC_CD
   		 AND h.hold_up_date = :CB_DUMMY.HOLD_UP_DATE
   		 AND h.ro_status = 10 
   		 AND h.hold_up_date >= nvl(trunc(promised_date),h.hold_up_date)    
   		 AND (:CB_DUMMY.srv_type = 'N' and h.rcateg_cd != 'BANDP' or :CB_DUMMY.srv_type = 'A' and h.rcateg_cd = 'BANDP'
       		                                                      or :CB_DUMMY.srv_type = 'Y' and h.rcateg_cd = h.rcateg_cd) 
   		 AND h.hold_up_date >= nvl(trunc(h.promised_date),h.hold_up_date)
   		 AND h.parent_group = d.parent_group
   		 AND h.dealer_map_cd = d.dealer_map_cd
   		 AND h.loc_cd = d.loc_cd
   		 AND h.ro_num = d.ro_num
   		 AND h.hold_up_date = d.hold_up_date       
   		 AND d.dealer_map_cd = r.dealer_map_cd(+)
   		 AND d.loc_cd  = r.loc_cd(+)
   		 AND d.ro_num = r.ro_num(+)
   		 AND d.part_num = r.part_num(+)
   	 order by h.ro_date,d.part_num ;

  lv_srl_num number := 0;
	CNT1 NUMBER;
	CNT NUMBER;
  
BEGIN
  IF :REPORT_TYPE = 'S' THEN
    SET_BLOCK_PROPERTY('B_VD',insert_allowed,property_true);
    SET_BLOCK_PROPERTY('B_VD',update_allowed,property_true);

    go_block('B_VD');
    clear_block;
    first_record;
    lv_srl_num := 0;    
		FOR i in CUR_SUM LOOP
			:B_VD.srv_desc 		:= i.srv_desc;
		  :B_VD.pend_1   		:= i.pend_1;
		  :B_VD.pend_3 			:= i.pend_3;
		  :B_VD.pend_7 			:= i.pend_7;			  		
		  exit when CUR_SUM%NOTFOUND;
		  next_record;
		END LOOP;
		first_record;
	ELSE 
    SET_BLOCK_PROPERTY('B_VH',insert_allowed,property_true);
    SET_BLOCK_PROPERTY('B_VH',update_allowed,property_true);

    go_block('B_VH');
    clear_block;
    first_record;
    lv_srl_num := 0;    
		FOR i in CUR_DTL LOOP
			:B_VH.sl_no	    := :system.cursor_record;
			:B_VH.pend_day	:= i.pend_day;
		  :B_VH.veh_no  	:= i.reg_num;
		  :B_VH.ro_num 		:= i.ro_num;
		  :B_VH.ro_date 	:= i.ro_date;
		  :B_VH.part_num 	:= i.part_num;			  				  
		  :B_VH.req_num  	:= i.req_num;			  		
		  :B_VH.req_date 	:= i.req_dt;			  		
		  :B_VH.req_qty 	:= i.req_qty;			  		
		  :B_VH.iss_qty 	:= i.iss_qty;	
		  :B_VH.order_num := i.order_num;
		  :B_VH.live_stock_avl := i.live_stock;
		  :B_VH.dead_stock_avl := i.dead_stock;
			BEGIN
				SELECT m.model_desc into :B_VH.model
				  FROM gm_mod m
	     	 WHERE m.principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
		   		 AND m.model_cd = i.model_code;
			EXCEPTION WHEN OTHERS THEN
				NULL;
		 	END;  		 
			BEGIN
				SELECT a.list_desc into :B_VH.service_type
				  FROM am_list a
	     	 WHERE a.list_name = 'RCATEG_CD'  
	     	   AND a.principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
		   		 AND a.list_code = i.rcateg_cd;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;  
			BEGIN
				SELECT p.part_desc into :B_VH.part_desc
				  FROM pm_part p
	     	 WHERE p.dealer_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
	     	   and p.principal_map_cd=:global.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
		   		 AND p.part_num = i.part_num;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;  
			BEGIN
				SELECT a.list_desc into :B_VH.part_status
				  FROM am_list a
	     	 WHERE a.list_name = 'AVAIL_SOURCE'  
	     	   AND a.principal_map_cd = :GLOBAL.principal  -- PMC added by Abhishek for multi organization on 03-june-2014..
		   		 AND a.list_code = i.part_status;
			EXCEPTION WHEN OTHERS THEN
				NULL;
			END;  
		  exit when CUR_DTL%NOTFOUND;
		  next_record;
		END LOOP;
		first_record;
 	END IF;	
EXCEPTION
	when no_data_found then 
 		general.disp_text('Data not available ' ,'Note');
  WHEN OTHERS THEN
    general.disp_text('Unable to populate' || SQLERRM, 'Error');
END;
```

#### SP-002 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying that the file exists at a given path before loading. The procedure normalises the target path, confirms physical file presence, invokes the FFI library loader, and maintains a running load count and an API-availability flag to reflect whether the DLL was successfully loaded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is supplied; if it is null, skip path validation and proceed directly to the library load attempt.
- Step 2 - Normalise TargetPath by passing it to STRIPDIRSEP to remove any trailing directory separator, then append a single backslash, ensuring a consistent path format regardless of how the caller supplied the value.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL in read mode using TEXT_IO.FOPEN, then immediately close it; this confirms the DLL file physically exists at the specified location before any load is attempted.
- Step 4 - If the file-open attempt raises any exception, call DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort processing.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into memory and capture the resulting library handle (hDLL).
- Step 6 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by one and set the package-level flag API_ENABLED to TRUE, recording that a DLL was successfully loaded and the API is available.
- Step 7 - Return the library handle hDLL to the caller.
- Step 8 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null library handle hDLL, signalling to the caller that the load failed.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash, then verify the DLL file exists by attempting to open and close it before proceeding to the library load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN raises an exception (DLL file not found at the specified path)

TRUE: Log the failure via DEBUGLOG and raise the BadLocation exception, aborting the load attempt.

FALSE: File opened successfully; close the handle and continue to the library load step.

---

DP-003

Condition: LoadCount parameter is TRUE

TRUE: Increment DLL_LOAD_COUNT by one and set API_ENABLED to TRUE, recording a successful load.

FALSE: Skip counter increment and flag update; return the library handle without altering load-tracking state.

---

DP-004

Condition: An unhandled exception occurs during ORA_FFI.LOAD_LIBRARY or surrounding logic

TRUE: Set API_ENABLED to FALSE and return a null library handle to the caller.

FALSE: No exception; return the valid library handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must be normalised to a single trailing backslash before use; STRIPDIRSEP is applied to remove any existing trailing separator, and a backslash is then appended, preventing duplicate or missing separators in the constructed file path.
- BR-002 - When a non-null TargetPath is provided, the physical existence of the DLL file must be confirmed via a read-mode file open before the library load is attempted; a DLL that cannot be opened raises BadLocation and the load is aborted.
- BR-003 - Any file-not-found condition must be recorded through DEBUGLOG at severity level 99, capturing the procedure name and the full unresolved file path, before the BadLocation exception is propagated.
- BR-004 - Multiple paths embedded within a single TargetPath value are not supported; only the first path segment is used after STRIPDIRSEP processing, and any additional segments are discarded.
- BR-005 - DLL_LOAD_COUNT must be incremented and API_ENABLED set to TRUE only when LoadCount is TRUE and the library load completes without exception, ensuring load-tracking state reflects only successful, intentionally counted loads.
- BR-006 - If the library load fails for any reason, API_ENABLED must be set to FALSE and a null library handle returned, allowing the caller to detect the failure without an unhandled exception propagating further.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-003 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (open or save) to the end user and returns the selected file path(s) in the IN OUT buffer. The procedure resolves special directory tokens, normalises the initial directory path, registers the underlying Win32 call via the D2KWUTIL bridge, and delegates the actual dialog invocation to D2KWUTIL.D2KWUTIL_CHOOSEFILE. It is invoked by D2KWUTIL.SAVE_FILE and is designed to operate only when the Win32 API layer is available.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-010](#SP-010--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-075](#SP-075--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-076](#SP-076--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all input arguments (CalledBy, Modal flag, title, initial directory, file filter, flags, separator character, and current buffer value) using DEBUGLOG for diagnostic traceability.
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return code (iRC) to 0.
- Step 4 - Determine the owner window handle: if the Modal flag is TRUE, retrieve the currently active window handle via D2KWUTIL.GET_ACTIVE_WINDOW; otherwise set the handle to 0 (non-modal / no owner).
- Step 5 - Check whether the Win32 API layer is enabled (WIN_API.API_ENABLED). If not enabled, raise WIN_API.NOT_AVAILABLE immediately.
- Step 6 - Register the external function call for 'd2kwutil_ChooseFile' with its argument-type signature using REGISTER_FUNCTION_CALL, binding it to the internal handle iChooseFile.
- Step 7 - Derive the dialog mode integer (iBuff1): set to 1 when CalledBy equals 'Open_File'; set to 2 for all other callers (save mode).
- Step 8 - Assign the Flags parameter directly to iBuff2 for pass-through to the Win32 call.
- Step 9 - Copy szTitle into the local buffer vcBuff1.
- Step 10 - Resolve the initial directory token in szInitDir: if the uppercased value equals '$WINDIR$', retrieve the Windows directory via GET_WINDOWS_DIRECTORY; if it equals '$TEMP$', retrieve the temporary directory via GET_TEMP_DIRECTORY; otherwise use szInitDir as supplied.
- Step 11 - Ensure the resolved directory path ends with a backslash ('\'); append one if the final character is not already a backslash.
- Step 12 - Resolve the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 13 - Take only the first character of SepChar as the effective separator (vcBuff4).
- Step 14 - Pad the input szBuffer to exactly 4 096 characters with null characters (CHR(0)) to form the output buffer vcBuff5 required by the Win32 call.
- Step 15 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE, passing the function handle, dialog mode, owner window handle, title, resolved directory, file filter, flags, separator character, and the padded buffer; capture the integer return code.
- Step 16 - Log the result (return code and returned buffer content) using DEBUGLOG.
- Step 17 - Write the populated buffer (vcBuff5) back into the IN OUT parameter szBuffer and return the integer result code to the caller.
- Step 18 - Exception handling: if WIN_API.NOT_AVAILABLE is raised, record the error via ADD_ERROR using the NoAPI message and re-raise; for all other exceptions, record the error via ADD_ERROR concatenated with ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition:
Modal IN parameter is TRUE.

TRUE:
Retrieve the active window handle by calling D2KWUTIL.GET_ACTIVE_WINDOW and assign it to hwndOwner, making the dialog modal to that window.

FALSE:
Set hwndOwner to 0, rendering the dialog non-modal with no owner window.

---

DP-002

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Proceed with registering the external function, resolving parameters, and invoking D2KWUTIL.D2KWUTIL_CHOOSEFILE.

FALSE:
Raise WIN_API.NOT_AVAILABLE; the dialog is not presented and an error is recorded via ADD_ERROR.

---

DP-003

Condition:
CalledBy equals the literal string 'Open_File'.

TRUE:
Set dialog mode integer (iBuff1) to 1, indicating an Open File dialog.

FALSE:
Set dialog mode integer (iBuff1) to 2, indicating a Save File dialog.

---

DP-004

Condition:
UPPER(szInitDir) equals '$WINDIR$'.

TRUE:
Resolve the initial directory to the Windows system directory by calling GET_WINDOWS_DIRECTORY.

FALSE:
Evaluate the next condition (DP-005).

---

DP-005

Condition:
UPPER(szInitDir) equals '$TEMP$'.

TRUE:
Resolve the initial directory to the system temporary directory by calling GET_TEMP_DIRECTORY.

FALSE:
Use szInitDir as supplied without substitution.

---

DP-006

Condition:
The last character of the resolved initial directory path is not a backslash ('\').

TRUE:
Append a backslash to the resolved directory path to ensure a valid trailing separator.

FALSE:
Leave the directory path unchanged.

---

DP-007

Condition:
szFileFilter is NULL or an empty string.

TRUE:
Default the file filter to 'All files(*.*)|*.*|' to allow selection of any file type.

FALSE:
Use the caller-supplied szFileFilter value.

---

DP-008

Condition:
An exception of type WIN_API.NOT_AVAILABLE is raised during execution.

TRUE:
Call ADD_ERROR with CalledBy and WIN_API.NoAPI to record the unavailability error, then re-raise the exception.

FALSE:
If any other exception is raised, call ADD_ERROR with CalledBy and the concatenation of WIN_API.UError and ADD_EXTERNAL_ERRORS, then re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-chooser dialog may only be presented when the Win32 API layer is available (WIN_API.API_ENABLED is TRUE); if the API is unavailable the procedure raises WIN_API.NOT_AVAILABLE and records an error without displaying any dialog.
- BR-002 - A modal dialog must be anchored to the currently active Oracle Forms window; the window handle is obtained at runtime via D2KWUTIL.GET_ACTIVE_WINDOW and must not be hardcoded.
- BR-003 - The caller identity string 'Open_File' is the sole determinant of dialog mode; any other CalledBy value results in Save File mode (iBuff1 = 2).
- BR-004 - The special token '$WINDIR$' (case-insensitive) in szInitDir must always be resolved to the actual Windows directory at runtime via GET_WINDOWS_DIRECTORY; it must never be passed literally to the Win32 layer.
- BR-005 - The special token '$TEMP$' (case-insensitive) in szInitDir must always be resolved to the actual system temporary directory at runtime via GET_TEMP_DIRECTORY; it must never be passed literally to the Win32 layer.
- BR-006 - The resolved initial directory path must end with a backslash ('\') before being passed to D2KWUTIL.D2KWUTIL_CHOOSEFILE; one is appended automatically if absent.
- BR-007 - When no file filter is provided (NULL or empty string), the dialog must default to displaying all files using the filter 'All files(*.*)|*.*|'.
- BR-008 - Only the first character of the SepChar parameter is used as the multi-file separator; any additional characters are silently discarded.
- BR-009 - The file path buffer passed to the Win32 call must be exactly 4 096 characters, padded with null characters (CHR(0)); this ensures sufficient capacity for multi-file selections returned by the dialog.
- BR-010 - All invocations must be logged at debug level 99 both on entry (with all input arguments) and on exit (with the return code and populated buffer), supporting post-incident diagnostics via DEBUGLOG.
- BR-011 - Any error encountered must be recorded via ADD_ERROR before the exception is re-raised, ensuring the calling routine (D2KWUTIL.SAVE_FILE) receives a populated error stack; external Win32 errors are appended using ADD_EXTERNAL_ERRORS.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Declares the foreign-function interface binding that allows Oracle Forms PL/SQL to invoke the native Windows API call responsible for returning the currently active window handle. The function accepts a pre-registered FFI function handle and returns a platform-level integer representing the active window, enabling the parent routine D2KWUTIL.GET_ACTIVE_WINDOW to surface the active window identity to calling form logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that has been registered by the caller (D2KWUTIL.GET_ACTIVE_WINDOW) against the underlying Windows API entry point.
- Step 2 - Delegate execution through the ORA_FFI mechanism to the mapped native function using the supplied handle.
- Step 3 - Return the PLS_INTEGER value produced by the native call, which represents the handle of the currently active window, to the invoking routine.

---
**Decision Points**

No conditional decision points are present in the available source. The function specification contains no branching logic; execution follows a single, unconditional path from input receipt to return of the native function result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function operates solely as an FFI wrapper; it does not perform any business validation, data retrieval, or state mutation beyond invoking the mapped native Windows API call.
- BR-002 - The caller is responsible for registering and supplying a valid ORA_FFI.funcHandleType handle before invoking this function; the function specification imposes no internal guard against an invalid or null handle.
- BR-003 - The return value is typed as PLS_INTEGER and represents a native window handle; consuming code must treat this value as an opaque platform identifier and must not apply arithmetic business logic to it directly.
- BR-004 - No database interactions occur within this function; all processing is confined to the Oracle Forms FFI layer and the underlying operating-system call.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Windows file-chooser dialog to the Oracle Forms runtime by delegating to an external foreign-function interface (FFI) handle. The function accepts dialog configuration parameters (title, initial directory, file filter, flags, and separator character) and returns the user-selected file path(s) in the IN OUT buffer, together with a PLS_INTEGER return code indicating the outcome of the dialog interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered FFI function handle (hFunc) that references the underlying Windows file-dialog library entry point.
- Step 2 - Accept the dialog configuration inputs: dialog_type (open vs. save variant), hwndOwner (parent window handle), szTitle (dialog caption), szInitDir (starting directory), szFileFilter (file-type filter string), AdvancedFlags (extended dialog behaviour flags), and SepChar (separator character for multi-file selections).
- Step 3 - Invoke the external Windows file-chooser dialog through the ORA_FFI mechanism using the supplied hFunc handle and all configuration parameters.
- Step 4 - Receive the user's selection back into the IN OUT parameters: szBuffer is populated with the selected file path(s), and szTitle, szInitDir, and szFileFilter may be updated to reflect the state at dialog close.
- Step 5 - Return a PLS_INTEGER result code to the caller (D2KWUTIL.CHOOSEFILE) indicating whether the user confirmed a selection or cancelled the dialog.

---
**Decision Points**

DP-001

Condition:
The user either confirms a file selection or cancels/closes the Windows file-chooser dialog.

TRUE (selection confirmed):
szBuffer is populated with the selected file path(s) delimited by SepChar, IN OUT parameters reflect final dialog state, and a non-zero success code is returned.

FALSE (dialog cancelled or closed without selection):
szBuffer remains empty or unchanged, and the return code signals cancellation to the calling routine D2KWUTIL.CHOOSEFILE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function signature is defined only as a specification; the actual execution is performed by the external Windows library referenced through the ORA_FFI function handle (hFunc), which must be registered and valid before invocation.
- BR-002 - The dialog_type parameter controls the variant of the file-chooser presented (e.g., Open vs. Save As); the caller is responsible for supplying a valid type value recognised by the underlying FFI target.
- BR-003 - szFileFilter must be formatted in accordance with Windows common-dialog filter string conventions; an incorrectly formatted filter may result in no file types being displayed.
- BR-004 - When multiple file selections are enabled via AdvancedFlags, individual file paths in szBuffer are delimited by the character supplied in SepChar; the caller must parse szBuffer accordingly.
- BR-005 - szTitle, szInitDir, szFileFilter, and szBuffer are declared IN OUT; the caller must allocate sufficient VARCHAR2 buffer length before invocation to accommodate values written back by the external dialog.
- BR-006 - No database interactions occur within this function; all processing is confined to the external Windows dialog and the ORA_FFI call stack.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C library routine identified by the supplied function handle. It is used by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages at runtime via the Oracle Forms ORA_FFI mechanism.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the target C-level debug-string routine registered in the Oracle Forms FFI layer.
- Step 2 - Receive the debug text string (Text) to be transmitted to the external C routine.
- Step 3 - Invoke the external C function bound to hFunc, passing Text as the message payload, as declared by the PRAGMA INTERFACE(C, d2kwutil_DebugString, 11265) directive.
- Step 4 - Return control to the calling procedure (WINDEBUG) upon completion; no output value is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a foreign-function call with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc); the handle must have been registered and bound to the C entry point before invocation, as the PRAGMA INTERFACE directive delegates execution entirely to the external C layer.
- BR-002 - The Text parameter carries the debug message content; no transformation or validation of the string is performed within this procedure - the value is passed as-is to the C routine.
- BR-003 - This procedure produces no return value or output parameters; any result or side-effect is owned entirely by the external C function referenced by hFunc.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-007 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle, a source environment variable name, and an output buffer, then returns an integer status code indicating the outcome of the environment variable lookup. This procedure is exposed to Oracle Forms through the parent stored procedure GET_ENVIRONMENT_STRING in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying OS-level routine responsible for resolving environment variables.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter, identifying which OS environment variable is to be retrieved.
- Step 3 - Accept the expansion output buffer (ExpandStr) as an IN OUT parameter, which will be populated with the resolved value of the environment variable.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum allowable size of the expanded result string.
- Step 5 - Delegate execution to the OS-level function referenced by hFunc, passing SourceStr and ExpandStr with the specified buffer length constraint.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) indicating success or failure of the environment variable resolution.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional logic has been resolved.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid FFI function handle (hFunc); the handle is the mechanism by which the correct OS-level environment variable routine is identified and called.
- BR-002 - The SourceStr parameter serves as both the input identifier for the environment variable name and an IN OUT channel, meaning the OS routine may modify or normalise the source string during resolution.
- BR-003 - The ExpandStr parameter must be pre-allocated by the caller to a size of at least InBuffLen characters, as InBuffLen governs the maximum length of the value written into ExpandStr.
- BR-004 - The function returns a PLS_INTEGER status code; the calling routine (GET_ENVIRONMENT_STRING) is responsible for interpreting this return value to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows Registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry value string and returns an integer result code indicating the outcome of the registry read operation. It is invoked exclusively by the READ_REGISTRY stored procedure within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows Registry API entry point, along with the registry root identifier (RegRoot), registry path (RegPath), and entry name (RegEntry).
- Step 2 - Accept the buffer control parameters: RegValueLength (maximum length of the value to be retrieved) and RegDontExpand (flag controlling whether environment-variable expansion is applied to the retrieved string).
- Step 3 - Delegate execution to the native Windows Registry function via the ORA_FFI mechanism using the supplied hFunc handle, passing all input parameters to the external call.
- Step 4 - Receive the results from the external call; RegPath, RegEntry, and RegValue are updated IN OUT, with RegValue populated with the registry entry's data string.
- Step 5 - Return a PLS_INTEGER result code to the caller (READ_REGISTRY) indicating success or failure of the registry read operation.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no PL/SQL body or conditional logic is exposed in the implementation extract.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); this handle must be pre-registered by the calling context (READ_REGISTRY) before D2KWUTIL_GETREGKEY is called.
- BR-002 - RegValueLength must be supplied by the caller to constrain the maximum number of characters written into RegValue, preventing buffer overrun in the underlying native call.
- BR-003 - The RegDontExpand flag governs whether environment-variable references embedded in the registry value string are expanded; the caller is responsible for passing the correct flag value to obtain the intended string form.
- BR-004 - RegPath, RegEntry, and RegValue are declared IN OUT; the caller must initialise these parameters before invocation and must read their potentially modified values after the call returns.
- BR-005 - The integer return code must be evaluated by the caller (READ_REGISTRY) to determine whether the registry read succeeded; no exception handling is visible within this function's specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that delegates to the underlying Windows API to retrieve either the Windows system directory or the temporary directory path. The function accepts a pre-registered FFI function handle, a buffer to receive the directory path, and the buffer length, returning a PLS_INTEGER status code. It is called exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld to resolve the relevant file-system path at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the specific Windows API function to invoke (either the Windows directory or temp directory variant, as determined by the calling procedure).
- Step 2 - Accept the pre-allocated VARCHAR2 buffer (WindowsDir) that will hold the returned directory path, along with InBuffLen indicating the maximum number of characters the buffer can accommodate.
- Step 3 - Invoke the foreign function referenced by hFunc, passing WindowsDir as an IN OUT buffer and InBuffLen as the buffer size constraint, thereby delegating execution to the native Windows API.
- Step 4 - Allow the Windows API to populate WindowsDir with the resolved directory path (e.g., the Windows directory or the temporary directory) up to the length specified by InBuffLen.
- Step 5 - Return a PLS_INTEGER result code to the caller (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) indicating the outcome of the Windows API call.

---
**Decision Points**

No conditional decision points are present in this function. The routine acts as a pass-through FFI declaration; all branching logic regarding which directory type to retrieve is handled by the invoking procedures (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY), which supply the appropriate hFunc handle before calling this function.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid, pre-registered ORA_FFI function handle (hFunc); the handle determines which Windows directory (system or temporary) is retrieved and must be initialised by the calling procedure before invocation.
- BR-002 - The caller is responsible for supplying a VARCHAR2 buffer (WindowsDir) sized to at least InBuffLen characters to prevent truncation of the returned directory path.
- BR-003 - InBuffLen must accurately reflect the allocated size of the WindowsDir buffer; passing an incorrect length may result in an incomplete or invalid directory path being returned by the Windows API.
- BR-004 - The function returns a PLS_INTEGER status code; the calling procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) is responsible for interpreting this return value to determine success or failure of the directory retrieval.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active window by invoking the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN via the WIN_API framework. The function returns the active window handle as a PLS_INTEGER and, optionally, raises an exception if the handle cannot be obtained. It is called by D2KWUTIL.CHOOSEFILE to identify the parent window context before presenting a file-chooser dialog.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry point and the value of the RaiseExceptions flag using DEBUGLOG (Win_API_Debug.DebugLog) to support runtime diagnostics.
- Step 2 - Clear any previously accumulated errors from the WIN_API error stack by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack).
- Step 3 - Check whether the WIN_API framework is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external DLL function call by invoking REGISTER_FUNCTION_CALL (win_api.Register_function_call) for the 'D2KWUTIL_ACTIVEWIN' function, specifying the return type as INT.
- Step 5 - Execute the external function D2KWUTIL.D2KWUTIL_ACTIVEWIN (d2kwutil_ActiveWin) via the registered function handle to obtain the active window handle, storing the result in iRC.
- Step 6 - Log the returned result code using DEBUGLOG for traceability.
- Step 7 - Evaluate the return code iRC. If iRC equals zero, the active window handle could not be obtained; record the failure via ADD_ERROR (Win_API.Add_error) and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 8 - If iRC is non-zero, return the active window handle value to the caller.
- Step 9 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR and re-raise; for all other exceptions, log the error combined with any external error details via ADD_ERROR and ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the WIN_API framework is available and the external DLL interface is initialised.

TRUE:
Proceed to register and invoke the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN to retrieve the active window handle.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 - the external DLL function returned zero, indicating that no active window handle was obtained.

TRUE:
Record a descriptive error message via ADD_ERROR ('Unable to obtain active window handle') and evaluate the RaiseExceptions flag (see DP-003).

FALSE:
Return the non-zero window handle value (iRC) to the caller as a valid result.

---

DP-003

Condition:
RaiseExceptions is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND, which propagates to the caller after being re-raised in the exception handler.

FALSE:
Suppress the exception; the function continues and will return 0 to the caller, with the error recorded on the WIN_API error stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API framework must be enabled (WIN_API.API_ENABLED) before any attempt is made to call the external DLL function; if the framework is unavailable the operation is aborted immediately and WIN_API.NOT_AVAILABLE is raised.
- BR-002 - The WIN_API error stack must be cleared at the start of each invocation via CLEAN_ERROR_STACK to ensure that error state from prior calls does not contaminate the current operation.
- BR-003 - A return value of zero from D2KWUTIL.D2KWUTIL_ACTIVEWIN is treated as a failure condition; the function records an error via ADD_ERROR regardless of the RaiseExceptions setting.
- BR-004 - Exception propagation is caller-controlled: when RaiseExceptions is TRUE and no valid window handle is returned, the function raises NO_DATA_FOUND; when RaiseExceptions is FALSE the error is silently recorded and zero is returned.
- BR-005 - All exceptions (WIN_API.NOT_AVAILABLE and unhandled others) must be logged via ADD_ERROR before being re-raised, ensuring the error stack is populated for upstream error-handling routines; unhandled exceptions additionally append external error details via ADD_EXTERNAL_ERRORS.
- BR-006 - Every invocation must be traced via DEBUGLOG at entry (with the RaiseExceptions argument) and at result (with the return code) to maintain an auditable debug log of external DLL interactions.
- BR-007 - The external DLL function must be registered via REGISTER_FUNCTION_CALL before execution, binding the call to the correct function handle (iActiveWin) and declaring the INT return type contract.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-011 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a 'Save File As' dialog to the user and returns the file path chosen for saving. The function delegates dialog rendering to D2KWUTIL.CHOOSEFILE and handles the case where no file is selected by logging an error via ADD_ERROR and optionally raising an exception, depending on the caller's preference.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-003](#SP-003--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the candidate file path by assigning the caller-supplied SampleName to the local variable vcReturnedFile; this pre-populates the dialog with a default file name.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE (SP-003), passing the operation label 'Save_File', the Modal flag, Title, StartDirectory, FileFilter, AdvancedFlags, a blank delimiter, and the pre-populated vcReturnedFile (IN/OUT) to display the Save File As dialog and capture the user's selection.
- Step 3 - Evaluate the integer return code (iLRC) from D2KWUTIL.CHOOSEFILE to determine whether a file was selected.
- Step 4 - If iLRC equals 1 (no file selected), call ADD_ERROR (SP-069) with the context label 'Save_File' and the message 'No file was selected' to register the error condition.
- Step 5 - If the RaiseExceptions flag is TRUE and no file was selected, raise the NO_DATA_FOUND exception to propagate the error to the calling routine.
- Step 6 - If iLRC does not equal 1 (a file was successfully selected), return the user-chosen file path held in vcReturnedFile to the caller.

---
**Decision Points**

DP-001

Condition:
iLRC (return code from D2KWUTIL.CHOOSEFILE) equals 1, indicating that no file was selected by the user.

TRUE:
Call ADD_ERROR with context 'Save_File' and message 'No file was selected'. Then evaluate DP-002 to determine whether an exception should be raised.

FALSE:
Return the selected file path (vcReturnedFile) to the caller; no error is recorded.

---

DP-002

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when DP-001 is TRUE).

TRUE:
Raise the NO_DATA_FOUND exception, propagating the no-selection error to the calling routine.

FALSE:
Silently absorb the error after ADD_ERROR has been called; the function exits without returning a value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The SampleName parameter must be supplied by the caller and is used as the pre-populated default file name in the Save File As dialog; it is not validated or defaulted internally.
- BR-002 - A return code of 1 from D2KWUTIL.CHOOSEFILE is the definitive indicator that the user did not select a file; any other return code is treated as a successful selection.
- BR-003 - When no file is selected, an error must always be registered via ADD_ERROR regardless of the RaiseExceptions setting, ensuring the event is captured in the error log.
- BR-004 - Exception propagation on a no-selection outcome is opt-in; callers must explicitly set RaiseExceptions to TRUE to receive a NO_DATA_FOUND exception, allowing silent-failure behaviour where appropriate.
- BR-005 - The function returns a file path only on a successful selection; it does not return a value in the no-selection branch, so callers relying on the return value must handle the case where RaiseExceptions is FALSE and no path is returned.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-012 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name into its corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer when registering external C function signatures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, storing the result in the local variable vcType to ensure case-insensitive matching.
- Step 2 - Evaluate vcType against each recognised C data type token in sequence using an IF-ELSIF chain.
- Step 3 - For each matched token, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR; 'CHAR' maps to ORA_FFI.C_CHAR; '*INT' maps to ORA_FFI.C_INT_PTR; 'INT' maps to ORA_FFI.C_INT; '*LONG' maps to ORA_FFI.C_LONG_PTR; 'LONG' maps to ORA_FFI.C_LONG; '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR; 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT; '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR; 'DOUBLE' maps to ORA_FFI.C_DOUBLE; '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 4 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR.
FALSE: Evaluation continues to DP-002.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR.
FALSE: Evaluation continues to DP-003.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR.
FALSE: Evaluation continues to DP-004.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT.
FALSE: Evaluation continues to DP-005.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR.
FALSE: Evaluation continues to DP-006.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG.
FALSE: Evaluation continues to DP-007.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR.
FALSE: Evaluation continues to DP-008.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT.
FALSE: Evaluation continues to DP-009.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluation continues to DP-010.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE.
FALSE: Evaluation continues to DP-011.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR.
FALSE: No branch is matched; iRC remains unassigned (NULL) and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType value is treated as case-insensitive; it is uppercased before matching, so callers may supply the token in any case.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' represents a pointer to INT); the absence of the asterisk denotes the scalar type.
- BR-003 - The tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType token does not match any recognised value, the function returns NULL (iRC is never assigned), and no error is raised; the caller is responsible for handling a NULL return value.
- BR-005 - The set of supported type tokens is fixed at eleven logical types: *CHAR, CHAR, *INT, INT, *LONG, LONG, *SHORT/*BYTE, SHORT/BYTE, *DOUBLE, DOUBLE, and *VOID; no other tokens are recognised.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-013 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert dialog (AL_CONFIRM) to the user and returns a numeric indicator reflecting the button pressed. This function is used to obtain explicit user confirmation before proceeding with a sensitive or irreversible action, such as those triggered by button-press events in the vehicle hold-update form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert dialog AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert dialog to the user using show_alert and capture the button pressed into p_albtn_pressed.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1 (the affirmative/confirm button), return 1 to indicate confirmation; otherwise return 0 to indicate cancellation or rejection.

---
**Decision Points**

DP-001

Condition:
The button pressed by the user (p_albtn_pressed) equals ALERT_BUTTON1.

TRUE:
Return 1, signalling that the user confirmed the action.

FALSE:
Return 0, signalling that the user did not confirm the action (cancelled or dismissed).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation dialog must always use the predefined alert named AL_CONFIRM; no other alert is used by this function.
- BR-002 - The message displayed to the user is entirely driven by the confirm_msg parameter supplied by the caller; the function does not impose or default any message text.
- BR-003 - Only ALERT_BUTTON1 is treated as a positive confirmation; any other button response is treated as a non-confirmation, returning 0.
- BR-004 - The function returns a binary numeric result (1 = confirmed, 0 = not confirmed); callers are responsible for interpreting and acting on this return value.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-014 - GENERAL.DISP_TEXT

**Invoked From:**

- pi_veh_hold_up_fmb.xml [ProgramUnit: POPULATE_DETAILS]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pi_veh_hold_up_fmb.xml [StoredProcedure: POPULATE_DETAILS]
- pi_veh_hold_up_fmb.xml [Trigger: ON-ERROR]
- pi_veh_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pi_veh_hold_up_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Detail (N/A / CN_MAIN); Search Criteria (N/A / CN_MAIN); Summary (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a given message and title. The procedure selects the appropriate Oracle Forms alert template ('AL_ERRINFO' for error messages, 'AL_NOTE' for all other notifications), sets its title and message text dynamically, and presents it to the user. It is used across multiple triggers and program units within the vehicle hold-up screen to surface both error and informational messages in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (`text_string`) and dialog title (`title_string`) as input parameters.
- Step 2 - Evaluate the `title_string` value (case-insensitive) to determine which alert template to use: if it equals 'ERROR', assign alert name 'AL_ERRINFO'; otherwise assign alert name 'AL_NOTE'.
- Step 3 - Call `SET_ALERT_PROPERTY` to set the TITLE property of the selected alert to the supplied `title_string`.
- Step 4 - Call `SET_ALERT_PROPERTY` to set the ALERT_MESSAGE_TEXT property of the selected alert to the supplied `text_string`.
- Step 5 - Call `SHOW_ALERT` to display the configured alert dialog to the user and capture the user's response in the local variable `p_alert_id` (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert template 'AL_ERRINFO' is selected, indicating the message is an error notification.

FALSE:
The alert template 'AL_NOTE' is selected, indicating the message is a general informational notification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title comparison is case-insensitive; any capitalisation variant of the word 'ERROR' routes the dialog to the error alert template 'AL_ERRINFO'.
- BR-002 - Any title value that is not a variant of 'ERROR' (including blank or NULL) routes the dialog to the informational alert template 'AL_NOTE'.
- BR-003 - The alert title and message text are always set dynamically at runtime from the supplied parameters; no hard-coded message content is displayed.
- BR-004 - The return value of `SHOW_ALERT` (the button pressed by the user) is captured but not acted upon; the procedure does not branch or raise exceptions based on the user's alert response.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-015 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query, ensuring any pre-existing group of the same name is removed before recreation. This procedure is called during form initialisation (WHEN-NEW-FORM-INSTANCE) to load list-item data into the record group identified by the caller-supplied name and SELECT statement.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters; assign the name to a local variable rg_name.
- Step 2 - Attempt to locate an existing Oracle Forms record group with the name rg_name using Find_Group, storing the result in rg_id.
- Step 3 - Evaluate whether a record group with that name already exists by testing rg_id with WEBUTIL.ID_NULL (Id_Null). If the group exists (i.e., rg_id is NOT null), delete it using Delete_Group to prevent duplicate group errors.
- Step 4 - Create a new record group from the supplied query by calling Create_Group_From_Query with rg_name and p_select; store the returned group handle in rg_id.
- Step 5 - Populate the newly created record group with data by calling Populate_Group(rg_id), capturing the return code in errcode.

---
**Decision Points**

DP-001

Condition: The record group identified by rg_name already exists in the current Oracle Forms session (i.e., Find_Group returns a non-null handle and WEBUTIL.ID_NULL / Id_Null evaluates to FALSE).

TRUE: The existing record group is deleted via Delete_Group(rg_id) before a fresh group is created from the query.

FALSE: No deletion is performed; the procedure proceeds directly to create the record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group name must be unique within the form session at the point of population; any pre-existing group sharing the same name must be destroyed before a new one is created to avoid conflicts.
- BR-002 - The record group must be built dynamically from the caller-supplied SQL SELECT statement (p_select); the structure and content of the group are entirely determined by that query at runtime.
- BR-003 - The procedure does not expose or act upon the numeric error code returned by Populate_Group; the caller is responsible for any downstream validation of the populated record group.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-016 - GENERAL.RAISE_ERROR

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms triggers. Given a message code, the procedure constructs a display string and routes it to GENERAL.DISP_TEXT with an appropriate dialogue title ('Error', 'Note', or 'Caution') based on the message type. When the message type indicates a hard error, the procedure additionally raises FORM_TRIGGER_FAILURE to halt further form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Concatenate mesg_code with the (currently unresolved) mesg_text variable to form the full display string in the format 'mesg_code : mesg_text'.
- Step 3 - Evaluate the mesg_type variable to determine the category of the message (Error, Note, or Caution).
- Step 4 - If mesg_type is 'E', set mesg_title to 'Error', call GENERAL.DISP_TEXT to present the message to the user, then raise FORM_TRIGGER_FAILURE to abort the triggering form action.
- Step 5 - If mesg_type is 'N', set mesg_title to 'Note' and call GENERAL.DISP_TEXT to present the informational message; no exception is raised and processing continues.
- Step 6 - If mesg_type is 'C', set mesg_title to 'Caution' and call GENERAL.DISP_TEXT to present the cautionary message; no exception is raised and processing continues.
- Step 7 - If mesg_type does not match 'E', 'N', or 'C', no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the composed message and title, then raise FORM_TRIGGER_FAILURE to stop form processing.

FALSE:
Proceed to evaluate whether mesg_type is 'N'.

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the composed message and title; processing continues normally.

FALSE:
Proceed to evaluate whether mesg_type is 'C'.

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the composed message and title; processing continues normally.

FALSE:
None of the recognised message types matched; the procedure takes no action and exits silently.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The display string presented to the user must always include the original message code as a prefix, separated from the message text by ' : ', ensuring the code is visible for support and traceability purposes.
- BR-002 - A message classified as type 'E' (Error) is considered fatal to the current form operation; FORM_TRIGGER_FAILURE must be raised after displaying the error to prevent the triggering action from completing.
- BR-003 - Messages of type 'N' (Note) and type 'C' (Caution) are non-fatal; they are displayed to the user via GENERAL.DISP_TEXT but do not interrupt form processing.
- BR-004 - Only the three recognised message types ('E', 'N', 'C') produce a user-visible dialogue; any other mesg_type value results in no display and no exception, effectively suppressing the message.
- BR-005 - All user-facing message display must be routed through GENERAL.DISP_TEXT (SP-014); direct use of Oracle Forms built-in alert mechanisms within this procedure is not permitted.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-017 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the Oracle Forms session waits for the command to complete before control is returned to the caller. It delegates execution to WEBUTIL.EXECUTE (SP-026), passing the supplied command string together with the BLOCKING_MODE constant, and returns the resulting process identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-026](#SP-026--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the host command string (cmd) as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-026) with cmd and the predefined constant BLOCKING_MODE to run the command synchronously.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller (WEBUTIL.HOST).

---
**Decision Points**

No conditional decision points exist in this procedure. Execution follows a single, unconditional path: delegate to WEBUTIL.EXECUTE with BLOCKING_MODE and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The procedure must return a PROCESS_ID to the caller, as supplied by WEBUTIL.EXECUTE (SP-026); no alternative return path is provided.
- BR-003 - All actual execution logic is owned by WEBUTIL.EXECUTE (SP-026); WEBUTIL.BLOCKING acts solely as a mode-specific wrapper and must not perform independent command processing.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-018 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the expected version. For each library defined in the property bundle for the package, the procedure compares the installed version recorded in the client settings against the required version. Where a library is absent, out-of-date, or a forced re-download is configured, the procedure downloads the library from the appropriate URL to the client's system-library location and records the new version in the client settings. The procedure is called by WEBUTIL.REGISTERBEAN as part of the package registration and installation lifecycle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-058](#SP-058--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a library counter (lib = 1) and begin iterating through library entries defined in the property bundle for the supplied packageID.
- Step 2 - Attempt to read the library specification from the property bundle using the most specific key, which includes the client OS family, OS architecture, packageID, and the current counter value (READFROMPROPERTYBUNDLE).
- Step 3 - If no specification is found at the architecture-specific key, fall back to a less specific key that omits the OS architecture component (READFROMPROPERTYBUNDLE).
- Step 4 - If the specification is still null after both lookups, exit the loop; all libraries for the package have been processed.
- Step 5 - Increment the library counter and parse the specification string into its constituent fields: library name, expected file size, required version, and a progress-indicator flag, using pipe-delimited parsing.
- Step 6 - Retrieve the currently installed version of the library from the client settings using the key 'syslib.<libName>' (GETCLIENTSETTING).
- Step 7 - Evaluate whether a download is required: proceed if the installed version is null (library not present), does not match the required version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 8 - When a download is required, resolve the download base URL from the property bundle using a three-level fallback: OS-family + OS-architecture specific, OS-family specific, then global (READFROMPROPERTYBUNDLE).
- Step 9 - Invoke WEBUTIL.DOWNLOADFROMURLINT with the resolved URL concatenated with the library name, the target file name, the system-library install type indicator (1), the expected file size, the progress-indicator flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 10 - If the download succeeds, record the newly installed version in the client settings using the key 'syslib.<libName>' (SETCLIENTSETTING).
- Step 11 - If the download fails, write a failure message to the WebUtil log via WEBUTIL.LOG and continue the loop to process any remaining libraries.
- Step 12 - Return to Step 2 for the next library entry until no further entries are found.

---
**Decision Points**

DP-001

Condition: The architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib>') returns a non-null library specification.

TRUE: Use the returned specification and proceed to parse library attributes.

FALSE: Attempt the less specific OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<lib>') before deciding whether to exit the loop.

---

DP-002

Condition: The OS-family-only property bundle key returns a non-null library specification.

TRUE: Use the returned specification and proceed to parse library attributes.

FALSE: No further library entries exist for this package; exit the loop.

---

DP-003

Condition: The installed version retrieved from client settings is null, differs from the required version, or the REDOWNLOAD_SYSLIB flag is set.

TRUE: A download of the library is required; proceed to resolve the download URL.

FALSE: The library is already installed at the correct version; skip download and advance to the next library entry.

---

DP-004

Condition: The OS-family + OS-architecture specific download URL key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the OS-family-only URL key.

---

DP-005

Condition: The OS-family-only download URL key ('install.syslib.location.<OSFamily>') returns a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Fall back to the global download URL key ('install.syslib.location').

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the required version against the library name in client settings via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message via WEBUTIL.LOG and continue processing remaining libraries.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are defined in the property bundle under hierarchical keys that incorporate the client OS family, OS architecture, packageID, and a sequential index; the procedure must evaluate the most specific key first and fall back to less specific keys before concluding that no entry exists.
- BR-002 - Each library specification must encode, in pipe-delimited format, the library name (position 1), expected file size in bytes (position 2), required version string (position 3), and a Boolean progress-indicator flag (position 4).
- BR-003 - A library must be downloaded if its installed version is absent from client settings, its recorded version does not match the required version, or the system-wide REDOWNLOAD_SYSLIB flag is active.
- BR-004 - The download base URL is resolved using a three-level fallback hierarchy (OS-family + architecture, OS-family only, global); the most specific available URL must be used.
- BR-005 - Downloads are classified as system-library installs (type indicator value 1) and are directed to the designated system-library location on the client.
- BR-006 - Progress dialog labels presented to the user during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys INST_PGRS_TITLE and INST_PGRS_SUBTITLE, ensuring localisation compliance.
- BR-007 - On successful download, the installed version recorded in client settings must be updated to the required version using the key 'syslib.<libName>' so that subsequent invocations do not trigger unnecessary re-downloads.
- BR-008 - A failed download must be logged via WEBUTIL.LOG with a message identifying the library name; the failure of one library must not prevent the procedure from attempting to process remaining libraries in the package.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-019 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up a callback trigger once it is no longer needed, preventing stale entries from accumulating in the collection.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed.
- Step 2 - Check whether an entry with the supplied key exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection using the supplied key.
- Step 4 - If the entry does not exist, take no action and return silently.

---
**Decision Points**

DP-001

Condition:
Does an entry with the value of callbackKey exist in the m_callbacks collection (m_callbacks.exists(callbackKey))?

TRUE:
Delete the entry identified by callbackKey from the m_callbacks collection (m_callbacks.delete(callbackKey)).

FALSE:
No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to delete a callback entry if it is confirmed to exist in the m_callbacks collection; no deletion is performed against a non-existent key.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to the key used when the callback was originally registered in the m_callbacks collection.
- BR-003 - The procedure produces no output and raises no exception regardless of whether the supplied key exists or not, ensuring silent, safe cleanup behaviour.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-020 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by a checksum value. The procedure delegates the close operation to the WebUtil_DB layer, returning a Boolean result that indicates whether the BLOB was successfully closed. It is invoked by WEBUTIL.SETDATA as part of BLOB lifecycle management.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the Boolean result produced by WebUtil_DB.CloseBlob to the caller, indicating success or failure of the close operation.

---
**Decision Points**

DP-001

Condition: WebUtil_DB.CloseBlob returns TRUE or FALSE based on whether the BLOB handle identified by the supplied checksum was successfully closed.

TRUE: The BLOB handle was found and closed successfully; TRUE is returned to the caller.

FALSE: The BLOB handle could not be closed (e.g., handle not found or already closed); FALSE is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter is mandatory and must be supplied by the caller; it serves as the unique identifier for the BLOB handle to be closed.
- BR-002 - All close logic is encapsulated within WebUtil_DB.CloseBlob; WEBUTIL.CLOSEBLOB must not perform any direct BLOB manipulation itself.
- BR-003 - The Boolean return value from WebUtil_DB.CloseBlob must be propagated unchanged to the caller; no result transformation or suppression is permitted.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-021 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open file handle on the application server by invoking the native Java method closeFile on the AppServerFileReader object. This procedure is called by WEBUTIL.SETDATA to release server-side file resources once file transfer operations are complete, returning a Boolean result indicating whether the close operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an open AppServerFileReader instance on the application server.
- Step 2 - Clear the argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java native method closeFile on the oracle/forms/webutil/fileTransfer/AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and a NULL argument list.
- Step 4 - Return the Boolean result produced by the Java method, indicating whether the file handle was successfully closed.

---
**Decision Points**

DP-001

Condition: The JNI call to closeFile on the AppServerFileReader Java object returns TRUE or FALSE.

TRUE: The file handle on the application server has been successfully closed; the Boolean value TRUE is returned to the caller (WEBUTIL.SETDATA).

FALSE: The file handle could not be closed; the Boolean value FALSE is returned to the caller, signalling that the close operation failed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before invoking the Java method to prevent any residual argument data from corrupting the JNI call.
- BR-002 - The procedure must be invoked with a valid AppServerFileReader Java object reference (obj); the object must represent a currently open file handle on the application server.
- BR-003 - The success or failure of the close operation is determined solely by the Boolean return value of the underlying Java closeFile method; no additional server-side validation is performed within this procedure.
- BR-004 - This function is intended to be called from WEBUTIL.SETDATA and should not be invoked independently outside of the established file transfer lifecycle.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-022 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified public entry point for downloading a file from a URL to a client-side destination. The procedure accepts a source URL, a client file path, and an optional file size, then delegates all processing to the internal implementation routine WEBUTIL.DOWNLOADFROMURLINT (SP-023), passing fixed defaults for the additional parameters that the internal routine requires. This abstraction shields callers from the full complexity of the internal download interface.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL, client destination path, and optional file size (defaulting to 0 if not supplied) as input parameters.
- Step 2 - Invoke WEBUTIL.DOWNLOADFROMURLINT (SP-023), forwarding: the source URL, the client destination path, a hard-coded offset value of 0, the supplied file size, a hard-coded Boolean flag of FALSE, and three hard-coded NULL arguments that correspond to optional internal parameters.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT directly to the caller (WEBUTIL.URL_TO_CLIENT).

---
**Decision Points**

No conditional decision points exist within this routine. All branching and conditional logic is deferred entirely to WEBUTIL.DOWNLOADFROMURLINT (SP-023).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file size parameter is optional; when not provided by the caller it defaults to 0, which is passed unchanged to WEBUTIL.DOWNLOADFROMURLINT.
- BR-002 - The byte offset passed to WEBUTIL.DOWNLOADFROMURLINT is always 0, meaning the download must begin from the start of the remote resource; partial/resumable downloads are not supported through this public interface.
- BR-003 - The authenticated/proxy flag passed to WEBUTIL.DOWNLOADFROMURLINT is always FALSE, meaning this entry point does not support authenticated or proxy-based URL downloads.
- BR-004 - The three additional optional arguments (credential or proxy parameters) passed to WEBUTIL.DOWNLOADFROMURLINT are always NULL, confirming that no authentication credentials or proxy settings may be supplied through this public interface.
- BR-005 - The success or failure of the download operation is communicated solely through the returned BOOLEAN value, which reflects the outcome reported by WEBUTIL.DOWNLOADFROMURLINT.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-023 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Performs the internal download operation that transfers a file from a specified URL to a client-side destination path. It constructs a delimited instruction string from the supplied parameters, dispatches the request to the WebUtil Core bean via a property set/get exchange, and returns a BOOLEAN indicating whether the download succeeded. This function is the low-level worker called by WEBUTIL.CHECKLIBS and WEBUTIL.DOWNLOADFROMURL.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its character representation. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its character representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to the submit string, each separated by the pipe delimiter.
- Step 7 - Call WebUtil_Core.setProperty with the WUC_PACKAGE target, property key 'WUC_URL_DOWNLOAD', the fully assembled submit string, and the synchronous flag set to TRUE to dispatch the download request to the client-side bean.
- Step 8 - Call WebUtil_Core.getProperty with the same package and key to retrieve the result string returned by the bean.
- Step 9 - Return TRUE if the result string equals 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition:
sourceURL IS NULL

TRUE:
Raise the URL_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 25 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue processing to the next validation.

---

DP-002

Condition:
clientDestination IS NULL

TRUE:
Raise the CLIENT_FILE_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 130 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue building the submit string.

---

DP-003

Condition:
specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE:
Append literal '0' followed by the pipe separator to the submit string.

FALSE:
Append the character representation of specialDestination followed by the pipe separator to the submit string.

---

DP-004

Condition:
fileSize IS NULL

TRUE:
Append literal '0' followed by the pipe separator to the submit string.

FALSE:
Append the character representation of fileSize followed by the pipe separator to the submit string.

---

DP-005

Condition:
withProgress IS NULL OR withProgress = FALSE

TRUE:
Append 'N' followed by the pipe separator to the submit string (progress bar suppressed).

FALSE:
Append 'Y' followed by the pipe separator to the submit string (progress bar requested).

---

DP-006

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception raised during the setProperty/getProperty call

TRUE:
Call WebUtil_Core.ErrorAlert to notify that the required bean class was not found, then raise FORM_TRIGGER_FAILURE to abort the calling form trigger.

FALSE:
Not applicable; this branch is only reached on the named exception.

---

DP-007

Condition:
WebUtil_Core.PROPERTY_ERROR exception raised during the setProperty/getProperty call

TRUE:
Raise FORM_TRIGGER_FAILURE to abort the calling form trigger.

FALSE:
Not applicable; this branch is only reached on the named exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-null source URL is mandatory; attempting a download without one is an error condition that terminates the function with a FALSE return and logs error code 25.
- BR-002 - A non-null client destination path is mandatory; attempting a download without one is an error condition that terminates the function with a FALSE return and logs error code 130.
- BR-003 - The specialDestination flag must be 0, 1, or 2; any null, negative, or out-of-range value is normalised to 0 before the request is dispatched.
- BR-004 - A null fileSize is normalised to 0 in the submit string; callers that do not know the file size in advance must pass null or 0.
- BR-005 - Progress-bar display is opt-in; unless withProgress is explicitly TRUE, the submit string signals the client bean to suppress the progress indicator ('N').
- BR-006 - Null progress text fields (progressTitle, progressSubTitle, progressMessage) are substituted with a single space to preserve the fixed pipe-delimited positional format required by the client bean.
- BR-007 - The download is dispatched synchronously (blocking flag = TRUE on setProperty), meaning the function waits for the bean to complete the transfer before reading the result.
- BR-008 - If the WebUtil Core bean is not registered on the client, the function raises FORM_TRIGGER_FAILURE after alerting the user; the download cannot proceed without the bean.
- BR-009 - A PROPERTY_ERROR returned by the WebUtil Core layer causes an immediate FORM_TRIGGER_FAILURE; no partial result is returned to the caller.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-024 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Formats a structured error message string from a numeric error code, a program-unit name, and up to three optional argument values, then publishes the assembled message to the WebUtil core property store under the key 'WUC_ERROR_MSG' so that the calling event handler (WEBUTIL_CORE.CUSTOMEVENTHANDLER) can retrieve and surface the error to the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text by concatenating the literal prefix 'ERROR', the three-digit zero-padded error code (derived from the numeric `code` parameter), a pipe delimiter, and the program-unit name (`pu_name`).
- Step 2 - Evaluate whether the first optional argument (`arg1`) has been supplied; if it is not null, append a pipe delimiter followed by the value of `arg1` to the error text.
- Step 3 - Evaluate whether the second optional argument (`arg2`) has been supplied; if it is not null, append a pipe delimiter followed by the value of `arg2` to the error text.
- Step 4 - Evaluate whether the third optional argument (`arg3`) has been supplied; if it is not null, append a pipe delimiter followed by the value of `arg3` to the error text.
- Step 5 - Publish the fully assembled error text to the WebUtil core property store by calling `Webutil_Core.setProperty` with the session identifier (`packageID`), the property key `'WUC_ERROR_MSG'`, and the constructed error text string.

---
**Decision Points**

DP-001

Condition:
`arg1` IS NOT NULL

TRUE:
Append a pipe delimiter and the value of `arg1` to the error text string.

FALSE:
Leave the error text string unchanged; `arg1` is omitted from the message.

---

DP-002

Condition:
`arg2` IS NOT NULL

TRUE:
Append a pipe delimiter and the value of `arg2` to the error text string.

FALSE:
Leave the error text string unchanged; `arg2` is omitted from the message.

---

DP-003

Condition:
`arg3` IS NOT NULL

TRUE:
Append a pipe delimiter and the value of `arg3` to the error text string.

FALSE:
Leave the error text string unchanged; `arg3` is omitted from the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the literal prefix 'ERROR' immediately followed by the numeric error code zero-padded to exactly three digits (e.g., code 5 becomes 'ERROR005'), ensuring a consistent, parseable message format.
- BR-002 - The program-unit name (`pu_name`) is a mandatory component of the error message and is always appended after the formatted error code, separated by a pipe delimiter.
- BR-003 - Each of the three supplementary arguments (`arg1`, `arg2`, `arg3`) is optional (defaults to NULL); an argument is included in the error message only when its value is not null, keeping the message compact when full context is unavailable.
- BR-004 - Message segments are separated exclusively by pipe ('|') delimiters, producing a pipe-delimited string that downstream consumers can reliably parse.
- BR-005 - The assembled error message must be stored against the property key `'WUC_ERROR_MSG'` in the WebUtil core property store for the current session (identified by `packageID`), making it accessible to the invoking event handler without requiring a formal output parameter.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-025 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the error text is presented in a modal alert dialog; otherwise the message is surfaced via the Oracle Forms MESSAGE built-in. This procedure is the centralised error-notification mechanism called by WEBUTIL.FCLOSE, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE when a bean registration or bean-not-found condition is detected.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error description text via the errText IN parameter.
- Step 2 - Call WEBUTIL.ID_NULL (SP-047) to test whether the module-level alert handle m_errorAlert has been initialised (i.e. is not null).
- Step 3 - If m_errorAlert is valid, set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert dialog to the user by calling SHOW_ALERT; the return value is captured in the local variable ignore (no further processing is performed on it).
- Step 5 - If m_errorAlert is not valid (ID_NULL returns TRUE), fall back to the Oracle Forms MESSAGE built-in, concatenating the literal prefix 'WebUtil Error: ' with errText so the user still receives the error information.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(m_errorAlert) returns FALSE - the alert handle m_errorAlert has been initialised and is usable.

TRUE:
Set the ALERT_MESSAGE_TEXT property of m_errorAlert to errText and display the alert dialog via SHOW_ALERT; the integer return value is discarded.

FALSE:
Bypass the alert mechanism entirely and issue the error text through the Oracle Forms MESSAGE built-in, prefixed with 'WebUtil Error: '.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is specifically intended for signalling BEAN_NOT_REGISTERED or bean-not-found errors; it must not be repurposed as a general-purpose messaging utility without review of all three calling procedures (WEBUTIL.FCLOSE, WEBUTIL.LOG, WEBUTIL.POPULATEPROPERTYBUNDLE).
- BR-002 - The alert title is not modified at runtime; it is assumed to be pre-set as 'WebUtil Error' in the alert's design-time properties, ensuring consistent presentation without redundant property assignments.
- BR-003 - The return value of SHOW_ALERT is intentionally ignored; no branching logic is performed based on the user's alert button selection.
- BR-004 - A fallback display path via MESSAGE must always be available so that error information reaches the user even when the alert object has not been initialised, guaranteeing that no error is silently swallowed.
- BR-005 - Determination of whether m_errorAlert is valid must be delegated exclusively to WEBUTIL.ID_NULL (SP-047); direct null-comparison logic must not be duplicated inline.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-026 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Submits a shell or operating-system command for execution on the client machine by delegating to the WebUtil host bean. The procedure sets the desired execution mode, passes the command string to the WebUtil Core property mechanism, retrieves the resulting process handle, and returns it to the caller as a PROCESS_ID. If the required WebUtil bean is not registered on the client, an error alert is raised and no process handle is returned.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (`cmd`) and the execution mode flag (`exemode`) as input parameters.
- Step 2 - Check whether `cmd` is not null before attempting any execution; if null, skip all processing and return an uninitialised PROCESS_ID to the caller.
- Step 3 - Set the execution mode on the WebUtil host bean by calling `WebUtil_Core.setProperty` with the key `WUH_EXECUTION_MODE` and the supplied `exemode` value.
- Step 4 - Pass the command string to the WebUtil host bean by calling `WebUtil_Core.setProperty` with the key `WUH_EXECUTE` and the supplied `cmd` value, which triggers client-side execution.
- Step 5 - Retrieve the process handle assigned by the client bean by calling `WebUtil_Core.getProperty` with the key `WUH_EXECUTE` and converting the returned string value to a number; store the result in `procId.handle`.
- Step 6 - Return the populated `procId` (PROCESS_ID) to the caller.
- Step 7 - If a `BEAN_NOT_REGISTERED` exception is raised at any point, display an error alert identifying the missing implementation class and suppress further processing; the function exits without returning a valid process handle.

---
**Decision Points**

DP-001

Condition:
`cmd` IS NOT NULL

TRUE:
Set the execution mode property, pass the command to the WebUtil host bean, retrieve and store the resulting process handle in `procId.handle`, then return `procId`.

FALSE:
Skip all WebUtil Core property calls and return an uninitialised PROCESS_ID to the caller.

---

DP-002

Condition:
`WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised during property set or get operations.

TRUE:
Display an error alert combining the implementation class name (obtained via `WebUtil_Core.getImplClass`) with a message stating that `WEBUTIL_HOST.Execute` will not work; function terminates without returning a process handle.

FALSE:
Normal execution continues; a valid PROCESS_ID is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null `cmd` value is treated as a no-operation; the function returns an uninitialised PROCESS_ID without invoking any client-side execution, preventing blank or unintended commands from being dispatched to the host.
- BR-002 - The execution mode (`exemode`) must be explicitly set on the WebUtil host bean before the command is submitted, ensuring the client executes the command under the correct mode (e.g., synchronous or asynchronous).
- BR-003 - The process handle returned by the client bean is stored as a numeric value (`to_number`) within the PROCESS_ID record; the caller is responsible for using this handle to monitor or interact with the spawned process.
- BR-004 - If the WebUtil host bean is not registered on the client, the function must not silently fail; an error alert identifying the missing bean class must be displayed so that the issue is visible to the end user and support staff.
- BR-005 - No database interactions are performed by this procedure; all state is managed exclusively through the WebUtil Core property mechanism on the client tier.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-027 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by releasing the underlying WebUtil file handle. The procedure signals the WebUtil bean to perform the physical close operation, nullifies the in-memory handle to prevent reuse, and raises a terminal error if the required WebUtil bean is unavailable or if the close operation itself fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-034](#SP-034--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file_type record (IN OUT parameter) representing an open client-side text file.
- Step 2 - Check whether the file handle (file.handle) is non-NULL; if it is NULL the file is already closed and no action is taken.
- Step 3 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the current handle value to instruct the WebUtil bean to close the physical file on the client.
- Step 4 - Set file.handle to NULL, marking the file_type record as closed and preventing any further operations against the same handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a descriptive message that identifies the implementation class obtained from WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass), then raise TOOL_ERR.TOOL_ERROR to terminate the calling process.
- Step 6 - If a PROPERTY_ERROR exception is raised (the bean is registered but the close operation fails), raise TOOL_ERR.TOOL_ERROR to terminate the calling process without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to close the physical file by calling WebUtil_Core.setProperty with WUF_TEXTIO_CLOSE and then null the handle.

FALSE:
Skip all close logic; the file is already closed or was never opened. Procedure exits normally with no action.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE:
Call WEBUTIL.ERRORALERT to present a user-facing message that includes the implementation class name retrieved by WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to abort the calling transaction.

FALSE:
Exception is not of this type; fall through to the PROPERTY_ERROR handler.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to abort the calling transaction; no alert is displayed.

FALSE:
No exception occurred; procedure completes normally after nullifying the handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is non-NULL; a NULL handle is treated as an already-closed file and requires no further processing.
- BR-002 - Closing a file is performed by instructing the WebUtil bean via WebUtil_Core.setProperty; direct client file-system access is not performed within PL/SQL.
- BR-003 - After a successful close, the file handle must be set to NULL to prevent any subsequent operation from referencing a stale or invalid handle.
- BR-004 - If the WebUtil bean required to close the file is not registered (BEAN_NOT_REGISTERED), the procedure must surface a descriptive error message to the user via WEBUTIL.ERRORALERT, incorporating the implementation class name obtained from WEBUTIL.GETIMPLCLASS, before raising a terminal error.
- BR-005 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions are treated as unrecoverable; in both cases TOOL_ERR.TOOL_ERROR is raised to ensure the calling process does not continue with an unclosed file handle.
- BR-006 - No database table interactions are performed; this procedure operates exclusively on client-side file state and WebUtil bean properties.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-028 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the client-side operating-system Save File dialog to the end user, allowing them to choose a file path and name under which a file (typically an Excel report) will be saved. The function delegates entirely to WEBUTIL.FILE_SELECTION_DIALOG_INT, passing a fixed mode of SAVE_FILE so that the dialog is rendered in save-rather than open-mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-029](#SP-029--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: directory_name (initial directory), file_name (default file name), file_filter (file-type filter string), and title (dialog window title).
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT (SP-029), forwarding all four caller-supplied parameters together with three fixed arguments: the D2KWUTIL constant SAVE_FILE (SP-011) to designate save mode, TRUE to indicate that the dialog should prompt for a file name, and FALSE to suppress multi-selection.
- Step 3 - Return the Varchar2 result produced by WEBUTIL.FILE_SELECTION_DIALOG_INT to the caller (VIEW_EXCEL_REPORT_NEW in dms_excel_report.pld), which represents the fully qualified file path selected or entered by the user, or NULL if the dialog was cancelled.

---
**Decision Points**

No conditional branching exists within FILE_SAVE_DIALOG itself. All decision logic (e.g., whether the user confirms or cancels the dialog) is encapsulated inside WEBUTIL.FILE_SELECTION_DIALOG_INT (SP-029) and its resolution of the SAVE_FILE constant supplied by D2KWUTIL (SP-011).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog must always operate in save mode; this is enforced by passing the D2KWUTIL.SAVE_FILE constant (SP-011) as the mode argument to FILE_SELECTION_DIALOG_INT-callers cannot override this behaviour.
- BR-002 - Multi-file selection is explicitly disabled (FALSE passed as the multi-select argument), ensuring the user can designate only a single save target per invocation.
- BR-003 - All four input parameters (directory_name, file_name, file_filter, title) are optional (default NULL); the function remains callable without any arguments, in which case the OS dialog applies its own defaults.
- BR-004 - The function returns the user-selected file path as a Varchar2 value; a NULL return indicates the user cancelled the dialog, and the caller (VIEW_EXCEL_REPORT_NEW) is responsible for handling that outcome.

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-029 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file-selection dialog to the end user by communicating with the WebUtil client-side bean, then returns the selected path as a normalised string. The dialog can operate in three modes-Save File, Open Directory, or Open File-controlled by the dialog_type and select_file input parameters. The function is the internal engine called by WEBUTIL.FILE_SAVE_DIALOG and delegates persistent file-save confirmation to D2KWUTIL.SAVE_FILE (SP-011).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-011](#SP-011--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Push all dialog configuration to the WebUtil client bean by calling WebUtil_Core.setProperty for each input parameter: directory_name (WUF_GFN_DIRNAME), file_name (WUF_FILENAME), file_filter (WUF_FILTER), title (WUF_GFN_MESSAGE), and multiselect flag (WUF_GFN_MULTISELECT).
- Step 2 - Determine the dialog mode: if dialog_type equals the SAVE_FILE constant, retrieve the result via the WUF_GFN_SAVEFILE property; else if select_file is FALSE, retrieve the result via WUF_GFN_OPENDIR (directory selection); otherwise retrieve the result via WUF_GFN_OPENFILE (file selection).
- Step 3 - Inspect the returned path string for a leading double-backslash ('\\') that JFileChooser may emit for UNC paths; if the string starts at position 1 with '\\', prepend an additional '\\' to preserve the UNC prefix before normalisation.
- Step 4 - Apply a global replace of every '\\' sequence with a single '\' to normalise the path separator throughout the returned string.
- Step 5 - Return the normalised path string to the caller.
- Step 6 - If the WebUtil bean is not registered, raise an error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE to abort the calling form trigger.
- Step 7 - If a property read/write error occurs (WebUtil_Core.PROPERTY_ERROR), raise FORM_TRIGGER_FAILURE to abort the calling form trigger.

---
**Decision Points**

DP-001

Condition:
dialog_type = SAVE_FILE

TRUE:
Retrieve the user-selected path from the WebUtil bean using the WUF_GFN_SAVEFILE property (Save File dialog mode).

FALSE:
Proceed to DP-002 to distinguish between Open Directory and Open File modes.

---

DP-002

Condition:
select_file = FALSE (evaluated only when dialog_type ≠ SAVE_FILE)

TRUE:
Retrieve the user-selected path from the WebUtil bean using the WUF_GFN_OPENDIR property (directory-selection mode).

FALSE:
Retrieve the user-selected path from the WebUtil bean using the WUF_GFN_OPENFILE property (file-selection mode).

---

DP-003

Condition:
The position of '\\' within the result string equals 1 (i.e., the path begins with a double-backslash, indicating a UNC path returned by JFileChooser).

TRUE:
Prepend '\\' to the result string before applying the global normalisation replace, so the UNC prefix is preserved correctly after normalisation.

FALSE:
Proceed directly to the global replace without prepending any characters.

---

DP-004

Condition:
Exception WebUtil_Core.BEAN_NOT_REGISTERED is raised during bean property interaction.

TRUE:
Display an error alert identifying the unregistered bean class and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Normal execution continues; no error handling invoked.

---

DP-005

Condition:
Exception WebUtil_Core.PROPERTY_ERROR is raised during bean property interaction.

TRUE:
Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Normal execution continues; no error handling invoked.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All five dialog configuration properties (directory, filename, filter, title, multiselect) must be transmitted to the WebUtil client bean before the dialog is invoked; the function does not support partial configuration.
- BR-002 - The dialog_type parameter is the primary discriminator for dialog mode: a value equal to the SAVE_FILE constant forces Save File mode regardless of the select_file flag.
- BR-003 - When dialog_type is not SAVE_FILE, the select_file Boolean exclusively determines whether a directory-picker or a file-picker is presented to the user.
- BR-004 - Paths beginning with a double-backslash (UNC paths as returned by JFileChooser) must have an additional '\\' prepended prior to normalisation to ensure the UNC prefix survives the replace operation intact.
- BR-005 - All double-backslash sequences in the returned path must be collapsed to a single backslash before the path is returned to the caller, ensuring a consistent path format.
- BR-006 - If the required WebUtil bean is not registered on the client, the function must surface a descriptive error alert and terminate the calling form trigger via FORM_TRIGGER_FAILURE; silent failure is not permitted.
- BR-007 - Any WebUtil property read/write error must immediately terminate the calling form trigger via FORM_TRIGGER_FAILURE to prevent the form from proceeding with an invalid or empty file path.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-030 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file for reading, writing, or appending by communicating with the WebUtil Java bean layer. The function validates the supplied file mode and file specification, passes the parameters to the WebUtil core component via property calls, retrieves a Java file handle, and returns a typed file handle (FILE_TYPE) for subsequent client-side text I/O operations. It is invoked during Excel report generation to establish a writable file channel on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is outside this set.
- Step 2 - Validate the file specification: confirm that the `spec` parameter is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR immediately if the file name is absent.
- Step 3 - Transmit the file name to the WebUtil bean by calling WebUtil_Core.setProperty with property key 'WUF_FILENAME' and the value of `spec`.
- Step 4 - Transmit the file mode to the WebUtil bean by calling WebUtil_Core.setProperty with property key 'WUF_TEXTIO_FILEMODE' and the value of `filemode`.
- Step 5 - Transmit the character set to the WebUtil bean: if `charSet` is NULL, set property 'WUF_TEXTIO_CHARSET' to the literal string '(null)'; otherwise set it to the supplied `charSet` value.
- Step 6 - Trigger the file-open operation on the client by calling WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) with property key 'WUF_TEXTIO_OPEN'. The returned value is a VARCHAR2 Java handle.
- Step 7 - Validate the Java handle: if the handle is NULL, empty, or equals '-1', the file was not successfully opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid Java handle to a NUMBER and assign it to the `handle` field of the local FILE_TYPE variable.
- Step 9 - Return the populated FILE_TYPE record to the caller.
- Step 10 - Handle exceptions: if the WebUtil bean is not registered, surface a descriptive error alert (via WebUtil_Core.ErrorAlert incorporating the implementation class name) and re-raise TOOL_ERR.TOOL_ERROR. Propagate PROPERTY_ERROR, VALUE_ERROR (as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition:
Is the supplied `filemode` (converted to lower case) a member of the set {'r', 'w', 'a'}?

TRUE:
Processing continues to the file-specification validation step.

FALSE:
TOOL_ERR.TOOL_ERROR is raised immediately and the function does not proceed.

---

DP-002

Condition:
Is `spec` NULL or an empty string?

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately; no file-open attempt is made.

FALSE:
Processing continues; `spec` is passed to the WebUtil bean as 'WUF_FILENAME'.

---

DP-003

Condition:
Is the `charSet` parameter NULL?

TRUE:
The literal string '(null)' is set for property 'WUF_TEXTIO_CHARSET', signalling the bean to use the platform default encoding.

FALSE:
The caller-supplied `charSet` value is set for property 'WUF_TEXTIO_CHARSET'.

---

DP-004

Condition:
Is the Java handle returned by WEBUTIL.GETPROPERTY ('WUF_TEXTIO_OPEN') NULL, empty, or equal to '-1'?

TRUE:
The file could not be opened on the client; TOOL_ERR.TOOL_ERROR is raised.

FALSE:
The handle is valid; it is converted to a NUMBER, stored in FILE_TYPE.handle, and the record is returned to the caller.

---

DP-005

Condition:
Does the EXCEPTION block catch WebUtil_Core.BEAN_NOT_REGISTERED?

TRUE:
An error alert is displayed (via WebUtil_Core.ErrorAlert) identifying the missing bean class, TOOL_ERR.TOOL_ERROR is re-raised, and NULL is returned.

FALSE:
Other exception handlers (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) apply as appropriate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r', 'w', or 'a' (case-insensitive); any other value is an invalid request and must be rejected before any client interaction occurs.
- BR-002 - A non-null, non-empty file specification (path/name) is mandatory; the function must not attempt to open a file when no name has been provided.
- BR-003 - When no character set is specified by the caller, the system must explicitly signal the absence to the WebUtil bean by passing the literal '(null)', ensuring deterministic encoding behaviour rather than leaving the property unset.
- BR-004 - A Java handle value of NULL, empty string, or '-1' is treated as a failed file-open condition; the function must not return a partially initialised FILE_TYPE record under these circumstances.
- BR-005 - The Java handle must be convertible to a NUMBER before being stored in FILE_TYPE.handle; a VALUE_ERROR during this conversion is treated as a hard failure and re-raised as TOOL_ERR.TOOL_ERROR.
- BR-006 - If the WebUtil bean is not registered on the client, the function must present a descriptive alert identifying the missing implementation class before propagating the error, ensuring the end user or support team can diagnose the configuration issue.
- BR-007 - All file-open parameters (file name, file mode, character set) must be communicated to the WebUtil bean exclusively through WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty / setProperty) calls; no direct file-system access is performed within this function.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-031 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger from the internal callbacks collection using a numeric key. This function supports the WEBUTIL.SETDATA procedure by supplying the trigger identifier associated with a given callback registration entry.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer key (callbackKey) that identifies a specific entry in the internal callbacks collection (m_callbacks).
- Step 2 - Look up and return the VARCHAR2 value stored at position callbackKey within the m_callbacks collection.
- Step 3 - Return the resolved callback trigger name to the calling routine (WEBUTIL.SETDATA).

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct indexed lookup against the m_callbacks collection without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey supplied must correspond to a valid, pre-existing index within the m_callbacks collection; no bounds checking or default handling is performed within this function.
- BR-002 - The function returns the callback trigger name exactly as stored in m_callbacks, without transformation or validation of the returned value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-032 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as previously stored in the package-level variable `m_clientOSFamily`. This allows calling code (invoked via WEBUTIL.GETVAR) to retrieve a numeric classification of the client OS without performing any additional lookup or computation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR within webutil.pld.
- Step 2 - The function reads the package-level variable `m_clientOSFamily`, which holds the pre-populated OS family identifier for the current client session.
- Step 3 - The integer value stored in `m_clientOSFamily` is returned directly to the caller as a PLS_INTEGER.

---
**Decision Points**

No decision points exist in this function. The implementation contains a single unconditional RETURN statement; no branching logic is present.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The client OS family identifier must have been populated into the package-level variable `m_clientOSFamily` prior to invoking this function; the function performs no initialisation or defaulting of that value.
- BR-002 - The function returns a PLS_INTEGER, meaning the OS family is represented as a numeric code; interpretation of specific code values is the responsibility of the calling routine.
- BR-003 - No input parameters are accepted and no database interactions are performed; the function is a pure in-memory accessor for the cached client OS family value.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-033 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil core bean. Given a property name, the function delegates to WebUtil_Core to set and then read the property value from the local (client) context, returning the result to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - If propertyName is not null, invoke WebUtil_Core.setProperty targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied property name, instructing the WebUtil core bean to resolve the named client setting.
- Step 3 - Immediately retrieve the resolved value by calling WebUtil_Core.getProperty for the same WUC_PACKAGE component and WUC_GET_LOCAL_PROPERTY key, storing the result in the local variable.
- Step 4 - If propertyName is null, skip Steps 2-3; the local result variable retains its default NULL value.
- Step 5 - Return the result value (populated or NULL) to the caller.
- Step 6 - If the WebUtil core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 7 - If a property interaction error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty to push the property name to the WebUtil core bean, then call WebUtil_Core.getProperty to retrieve the resolved client setting value.

FALSE: Skip the bean interaction entirely; return NULL to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean interaction

TRUE: Display an error alert containing the implementation class name and the message that WEBUTIL_CORE.GetClientSetting will not work, then raise FORM_TRIGGER_FAILURE.

FALSE: Continue normal processing.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during bean interaction

TRUE: Raise FORM_TRIGGER_FAILURE immediately, suppressing further processing without an additional user-facing alert.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must not attempt any bean interaction when propertyName is NULL; in that case it returns NULL unconditionally.
- BR-002 - The property name and value exchange with the client is performed exclusively through the WebUtil_Core.WUC_PACKAGE component using the reserved key WUC_GET_LOCAL_PROPERTY.
- BR-003 - If the WebUtil core bean is not registered at the time of invocation, the function must surface an informative error alert that identifies the missing implementation class before terminating form execution via FORM_TRIGGER_FAILURE.
- BR-004 - A PROPERTY_ERROR condition must cause immediate termination of form execution via FORM_TRIGGER_FAILURE; no user-facing alert is raised for this error type.
- BR-005 - The returned property value is constrained to a maximum length of 255 characters.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-034 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class suffix for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Retrieve the implementation class suffix associated with packageID from the internal collection m_implClasses.
- Step 3 - Prepend the constant WEBUTIL_JAVA_ROOT to the retrieved suffix to form the fully qualified Java class name.
- Step 4 - Return the concatenated fully qualified class name to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The logic executes unconditionally: the implementation class suffix is looked up from m_implClasses using packageID and concatenated with WEBUTIL_JAVA_ROOT before being returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java implementation class name must always be constructed by prefixing the value stored in m_implClasses(packageID) with the WEBUTIL_JAVA_ROOT constant; neither component alone constitutes a valid class reference.
- BR-002 - A valid packageID must exist as an index in the m_implClasses collection; supplying an unregistered packageID will result in a collection subscript error, implying that package registration is a prerequisite before this function is called.
- BR-003 - This function is read-only and performs no side effects; it neither modifies the m_implClasses collection nor interacts with any database table.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-035 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function interrogates the underlying JNI layer to obtain an integer error status from the active file-transfer session, allowing the calling routine (WEBUTIL.SETDATA) to determine whether a prior file-transfer operation completed successfully or encountered a fault.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object reference (obj) as the target instance on which the error check will be performed.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale parameters are passed to the Java method.
- Step 3 - Invoke the JNI.CALL_INT_METHOD call against the oracle/forms/webutil/fileTransfer/AppServerFileReader class, targeting the getLastError method with signature ()I (no arguments, returns an integer).
- Step 4 - Return the integer error code produced by the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to JNI.CALL_INT_METHOD, returning whatever integer value the Java layer supplies.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list (args) must be set to NULL before invoking the Java method to prevent unintended parameter passing to the AppServerFileReader.getLastError() call.
- BR-002 - The function must target the exact Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and method signature ()I; any deviation would result in an incorrect or failed JNI invocation.
- BR-003 - The returned integer value represents the last error state of the supplied AppServerFileReader object instance; the validity of the result is therefore contingent on the caller supplying a non-null, properly initialised obj reference.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-036 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying JNI layer, invoking the Java method getLastErrorArgs on the supplied Java object, and returns the error argument detail as a VARCHAR2 string for use by the calling context (WEBUTIL.SETDATA).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data influences the JNI call.
- Step 3 - Invoke JNI.CALL_STRING_METHOD, targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class and its getLastErrorArgs method, passing the cleared args value and the resolved Java object reference.
- Step 4 - Return the VARCHAR2 string result produced by the JNI call, which contains the error argument detail from the last error recorded by the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call is made, ensuring that no previously accumulated argument data is inadvertently forwarded to the AppServerFileReader Java method.
- BR-002 - The function targets the fixed Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and the fixed method signature ()Ljava/lang/String;; the class and method reference must not be altered, as they correspond to the deployed WebUtil Java library contract.
- BR-003 - The function returns the raw error argument string exactly as provided by the JNI layer; no transformation, truncation, or validation is applied to the returned value.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-037 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and converts it to a numeric value. The function acts as a numeric wrapper around WEBUTIL.GETSTRING (SP-041), delegating string extraction and then applying a TO_NUMBER conversion to the result. It is invoked indirectly via WEBUTIL_CORE.CUSTOMEVENTHANDLER.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-041](#SP-041--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional Boolean flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Delegate the field extraction to WEBUTIL.GETSTRING (SP-041), passing all four input parameters unchanged.
- Step 3 - Apply TO_NUMBER to the string value returned by WEBUTIL.GETSTRING to convert it to a numeric data type.
- Step 4 - Return the resulting number to the caller.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is not supplied by the caller.

TRUE: The default value FALSE is used, indicating the source string is fully terminated and the last field has a closing delimiter.

FALSE: The caller-supplied Boolean value is forwarded to WEBUTIL.GETSTRING, signalling that the final field in the string may lack a trailing delimiter.

DP-002

Condition: Delimiter parameter is not supplied by the caller.

TRUE: The default comma character (',') is used as the field separator when WEBUTIL.GETSTRING parses the source string.

FALSE: The caller-supplied delimiter character is forwarded to WEBUTIL.GETSTRING to govern field parsing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a non-null Source_string and a valid Field_position; these are passed directly to WEBUTIL.GETSTRING (SP-041) without independent validation within this function.
- BR-002 - The delimiter defaults to a comma (',') if not explicitly provided by the caller, establishing comma-separated parsing as the standard behaviour.
- BR-003 - The UnTerminated flag defaults to FALSE, meaning the source string is assumed to be fully delimited unless the caller explicitly overrides this.
- BR-004 - The string value extracted by WEBUTIL.GETSTRING must be implicitly convertible to a number via TO_NUMBER; no explicit error handling is implemented within this function, so non-numeric field content will raise a runtime exception to the caller.
- BR-005 - No database interactions are performed; the function operates entirely on the in-memory string passed by the caller.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-038 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by analysing the supplied OS name string. The function maps the raw OS name to a predefined platform constant (WIN32, MAC, LINUX, SOLARIS, HP, AIX, or UNKNOWN) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluation. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the raw OS name string (osName) and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive comparison.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is NULL. If it is NOT NULL, skip all classification logic and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily IS NULL, evaluate whether l_osName contains the substring 'windows'. If TRUE, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If Step 4 is FALSE, evaluate whether l_osName contains the substring 'mac'. If TRUE, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If Step 5 is FALSE, evaluate whether l_osName contains the substring 'linux'. If TRUE, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If Step 6 is FALSE, evaluate whether l_osName contains the substring 'solaris' OR the substring 'sunos'. If TRUE, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If Step 7 is FALSE, evaluate whether l_osName contains the substring 'hp-ux'. If TRUE, set result to CLIENT_PLATFORM_HP.
- Step 9 - If Step 8 is FALSE, evaluate whether l_osName contains the substring 'aix'. If TRUE, set result to CLIENT_PLATFORM_AIX. If none of the conditions in Steps 4-9 matched, result remains CLIENT_PLATFORM_UNKNOWN.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, caching it for the lifetime of the session.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (i.e., the OS family has not yet been determined and cached for this session).

TRUE: Execute the full OS name classification logic (Steps 4-10) to resolve and cache the platform constant.

FALSE: Bypass all classification logic and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: The lowercase OS name (l_osName) contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to evaluate the next OS family condition (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to evaluate the next OS family condition (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to evaluate the next OS family condition (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR the substring 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to evaluate the next OS family condition (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to evaluate the next OS family condition (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN, indicating an unrecognised operating system.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is always performed in lowercase; the input value is converted via LOWER() before any substring search, ensuring the classification is case-insensitive.
- BR-002 - The OS family classification is evaluated once per session. Once m_clientOSFamily is populated, the cached value is returned on all subsequent calls without re-evaluating the OS name string.
- BR-003 - If the supplied OS name does not match any of the recognised platform substrings (windows, mac, linux, solaris, sunos, hp-ux, aix), the function returns CLIENT_PLATFORM_UNKNOWN; no error is raised.
- BR-004 - The Solaris platform is identified by either the substring 'solaris' or 'sunos' in the OS name; both identifiers map to the single constant CLIENT_PLATFORM_SOLARIS.
- BR-005 - The classification conditions are mutually exclusive and evaluated in strict priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX -> UNKNOWN. The first matching condition determines the platform and no further conditions are evaluated.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-039 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a completed or running host process by iterating over a WebUtil bean property until no further lines are available. The function returns the collected lines as an OUTPUT_ARRAY for use by the calling routine (WEBUTIL.GET_STANDARD_OUTPUT). It relies on WEBUTIL.INIT (SP-048) to ensure the WebUtil Core package is instantiated before any bean communication occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-048](#SP-048--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil Core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a loop to retrieve output lines one at a time: call WebUtil_Core.getProperty with the WUH_PACKAGE constant and the caller-supplied prop parameter to obtain a buffered line.
- Step 3 - Extract the single-character status indicator from the first character of the returned buffer (Y = more lines follow; N = this is the last line; X = buffer was empty).
- Step 4 - If the status is not 'X' (i.e., the buffer contains data), store the remainder of the buffer (characters from position 2 onward) into the OUTPUT_ARRAY at the current index, then increment the index counter.
- Step 5 - Exit the loop when the status is not 'Y', meaning either the last line has been read (status 'N') or the buffer was empty (status 'X').
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function.
- Step 8 - On package initialisation (BEGIN block), call Webutil_Core.Init to ensure the Core singleton is instantiated before any function in the package is used.

---
**Decision Points**

DP-001

Condition:
The status character extracted from the buffer is not equal to 'X'.

TRUE:
The buffer contains a valid output line; the substring from position 2 is appended to the OUTPUT_ARRAY and the index counter is incremented.

FALSE:
The buffer was empty; no entry is added to the OUTPUT_ARRAY and the loop continues to the exit evaluation.

---

DP-002

Condition:
The status character is not equal to 'Y'.

TRUE:
No further lines are expected (status is 'N' or 'X'); the loop exits and the collected OUTPUT_ARRAY is returned.

FALSE:
More lines are available (status is 'Y'); the loop continues and the next buffer line is retrieved.

---

DP-003

Condition:
The WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property retrieval.

TRUE:
An error alert is displayed to the user, identifying the unregistered bean class and stating that WEBUTIL_HOST.GetOutput will not work. No array is returned.

FALSE:
No exception occurs; normal processing continues and the OUTPUT_ARRAY is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil Core package via WebUtil_Core.setProperty before any output lines are retrieved; this binding is mandatory for each invocation.
- BR-002 - The first character of every buffer value returned by WebUtil_Core.getProperty is reserved as a status indicator ('Y', 'N', or 'X') and must never be treated as part of the output content; only characters from position 2 onward constitute the actual output line.
- BR-003 - Lines are collected only when the status indicator is not 'X'; an empty buffer (status 'X') is silently skipped without adding a blank entry to the output array.
- BR-004 - The retrieval loop must terminate as soon as the status indicator is not 'Y', ensuring that exactly the available lines are captured without over-reading.
- BR-005 - The WebUtil Core package must be initialised (via Webutil_Core.Init) at package load time; this is enforced by the package-level BEGIN block to guarantee readiness before any function call.
- BR-006 - If the required WebUtil bean is not registered on the client, the function must surface a descriptive error alert rather than silently failing or returning a partial result.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-040 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the underlying Java Virtual Machine via the JNI bridge. Callers such as WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN use this function to obtain environment-level configuration values (e.g., file-system paths, OS identifiers) that are held in the JVM's system-property map rather than in the Oracle database.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property name (a0) as the single input parameter.
- Step 2 - Initialise a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the property-name string to the argument list via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the prepared argument list and targeting the JVM class 'java/lang/System'.
- Step 5 - Return the VARCHAR2 value returned by the JVM to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name supplied in parameter a0 must be a valid Java system-property key; the JVM returns NULL if no matching property exists, and that NULL is passed back to the caller without further handling.
- BR-002 - Exactly one string argument must be registered in the JNI argument list before the JVM method is invoked; the argument list is always initialised with a capacity of 1.
- BR-003 - The function targets the standard Java class java/lang/System and its getProperty method with the signature (Ljava/lang/String;)Ljava/lang/String;; these identifiers must not be altered, as they are fixed JVM contract references.
- BR-004 - The function has no database interactions; all data retrieval is performed exclusively through the JNI bridge to the JVM, with no Oracle table reads or writes.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-041 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts and returns a single delimited token from a source string at a specified positional index. Given a delimiter-separated string, the function locates the Nth field (identified by Field_position) and returns its value as a VARCHAR2. It is used internally within the WEBUTIL package, notably by WEBUTIL.GETNUMBER, to parse structured string data before further type conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position (1-based), an optional Boolean flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaulting to comma).
- Step 2 - If UnTerminated is TRUE, append the delimiter to a working copy of the source string so that the last token is consistently bounded and can be located using the same positional logic as all other tokens.
- Step 3 - Determine the start pointer (iPtrStart) for the target token: if Field_position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence Field_position - 1) and advance the pointer past the delimiter; if Field_position equals 1, set the start pointer to position 1 (the beginning of the string).
- Step 4 - Determine the end pointer (iPtrEnd) by locating the Nth occurrence of the delimiter within the working copy, where N equals Field_position.
- Step 5 - Extract and return the substring between iPtrStart and iPtrEnd (exclusive), representing the value of the requested delimited field.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string (vcSourceStrCopy) before any positional parsing begins, ensuring the final token is correctly bounded.

FALSE: The source string is used as-is; no modification is made to vcSourceStrCopy.

---

DP-002

Condition: Field_position is greater than 1.

TRUE: The start pointer (iPtrStart) is calculated by finding the (Field_position - 1)th occurrence of the delimiter and advancing past it by the length of the delimiter string.

FALSE: Field_position equals 1; the start pointer is set to 1, meaning extraction begins at the very start of the working string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_position value of 1 always refers to the first token in the delimited string.
- BR-002 - When the source string does not end with the delimiter (UnTerminated = TRUE), the delimiter must be appended to the working copy before parsing so that the last field can be located using the same occurrence-based logic applied to all other fields.
- BR-003 - The delimiter defaults to a comma if not explicitly supplied, allowing the function to parse standard CSV-style strings without requiring the caller to specify a delimiter.
- BR-004 - The function returns only the content between the bounding delimiters; the delimiter characters themselves are never included in the returned value.
- BR-005 - The working string copy is limited to 32,000 characters (VARCHAR2(32000)), establishing the maximum supported source string length for token extraction.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-042 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named client-side variable (VARNAME) and returns it in VARVALUE. The resolution strategy is platform-aware: on Windows clients the procedure first queries the Oracle registry key under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE via READ_REGISTRY, then falls back to GET_ENVIRONMENT_STRING if the registry lookup yields no value; on Unix/Linux clients it executes the 'env' command via a blocking host process, captures standard output through WEBUTIL.GET_STANDARD_OUTPUT, and parses the output to locate the matching variable; on macOS and unknown platforms no action is taken. The procedure is invoked by WEBUTIL.REGISTERBEAN to resolve Oracle environment or registry settings needed during bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-074](#SP-074--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-077](#SP-077--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-045](#SP-045--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive VARNAME (the variable name to resolve) and the IN OUT parameter VARVALUE from the caller (WEBUTIL.REGISTERBEAN).
- Step 2 - Call WEBUTIL.GETCLIENTOSFAMILY (SP-032) to determine the client operating-system family.
- Step 3 - If the client OS is WIN32, call READ_REGISTRY (SP-077) with the path 'HKEY_LOCAL_MACHINE\\SOFTWARE\\ORACLE' and VARNAME to attempt a registry lookup; store the result in VARVALUE.
- Step 4 - If the registry lookup returned NULL or an empty string, call GET_ENVIRONMENT_STRING (SP-074) with VARNAME to retrieve the value from the Windows environment variables; store the result in VARVALUE.
- Step 5 - If the client OS is MAC or UNKNOWN, take no action and leave VARVALUE unchanged (null path).
- Step 6 - For all other OS families (Unix/Linux), execute the shell command 'env' as a blocking host process to capture the full environment.
- Step 7 - Retrieve the command's standard output array by calling WEBUTIL.GET_STANDARD_OUTPUT (SP-045) with the process handle, then release the process handle.
- Step 8 - Iterate over each line of the output array; for each line locate the '=' delimiter using INSTR.
- Step 9 - If a '=' delimiter is found, extract the key portion (left of '=') and compare it to VARNAME; if they match, extract the value portion (right of '=') into VARVALUE and exit the loop.
- Step 10 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return gracefully.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.GETCLIENTOSFAMILY returns CLIENT_PLATFORM_WIN32.

TRUE:
Attempt registry lookup via READ_REGISTRY; proceed to DP-002.

FALSE:
Proceed to DP-003.

---

DP-002

Condition:
The value returned by READ_REGISTRY is NULL or empty string.

TRUE:
Call GET_ENVIRONMENT_STRING with VARNAME to retrieve the value from the Windows environment and assign it to VARVALUE.

FALSE:
Use the registry value already stored in VARVALUE; no further lookup is performed.

---

DP-003

Condition:
WEBUTIL.GETCLIENTOSFAMILY returns CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE:
Take no action; VARVALUE remains unchanged.

FALSE:
Treat the client as a Unix/Linux platform; proceed to execute the 'env' command and parse its output (Steps 6-9).

---

DP-004

Condition:
While iterating Unix 'env' output, INSTR finds a '=' character at position > 0 in the current line.

TRUE:
Extract the key and compare it to VARNAME; if equal, assign the value portion to VARVALUE and exit the loop.

FALSE:
Skip the current line and continue iterating.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Variable resolution is strictly client-platform-dependent; the same VARNAME may be resolved from different sources (registry, environment, or shell output) depending on the detected client OS family.
- BR-002 - On Windows, the Oracle registry path 'HKEY_LOCAL_MACHINE\\SOFTWARE\\ORACLE' is always the primary lookup source before the environment variable fallback; the environment is only consulted when the registry yields no value.
- BR-003 - On macOS and unknown client platforms, no variable resolution is attempted and VARVALUE is returned unchanged (effectively NULL unless pre-populated by the caller).
- BR-004 - On Unix/Linux platforms, variable resolution relies on parsing the output of the 'env' shell command; the first matching key terminates the search, ensuring the earliest occurrence of a duplicate key takes precedence.
- BR-005 - A NO_DATA_FOUND exception during any resolution path is handled silently by returning NULL in VARVALUE, preventing propagation of the error to the caller.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-043 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual file-read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, then maps a PJC-specific end-of-file sentinel value (a newline character) to the standard Oracle NO_DATA_FOUND exception so that callers can detect end-of-file using conventional PL/SQL exception handling.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle (file_type IN parameter) that identifies the client-side text file to be read.
- Step 2 - Pass the file handle to the WebUtil PJC by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Request the next line of text from the PJC by reading the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty; the result is stored in a local VARCHAR2 buffer (up to 4 000 characters).
- Step 4 - Evaluate the buffer value: if the buffer contains a lone newline character (CHR(10)), the PJC has signalled end-of-file; raise NO_DATA_FOUND to propagate this condition to the caller in a standard way.
- Step 5 - If the buffer does not contain the end-of-file sentinel, assign the buffer content to the OUT parameter item and return normally.
- Step 6 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERROR to abort processing.
- Step 7 - If a property-level error occurs (PROPERTY_ERROR exception), raise TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition:
The value returned by WebUtil_Core.getProperty for WUF_TEXTIO_GETLINE equals CHR(10) (a lone newline character).

TRUE:
The PJC has signalled end-of-file; the procedure raises NO_DATA_FOUND so the caller can handle end-of-file via standard exception handling.

FALSE:
The buffer contains a genuine line of text; it is assigned to the OUT parameter item and the procedure returns successfully.

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is raised during the WebUtil_Core property calls, indicating the required WebUtil PJC bean is absent on the client.

TRUE:
An error alert is displayed identifying the missing implementation class, and TOOL_ERROR is raised to terminate processing.

FALSE:
No bean-registration error; processing continues normally.

---

DP-003

Condition:
A PROPERTY_ERROR exception is raised during the WebUtil_Core property calls, indicating a failure in the PJC property interaction.

TRUE:
TOOL_ERROR is raised immediately to terminate processing.

FALSE:
No property error; processing continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle supplied to GET_LINE must already be open; the procedure does not open or validate the file itself - that responsibility belongs to the caller.
- BR-002 - A lone newline character (CHR(10)) returned by the PJC is exclusively reserved as the end-of-file sentinel; GET_LINE will never return this value as legitimate line content, because the PJC normally uses newline as a line delimiter rather than line content.
- BR-003 - End-of-file is communicated to the caller via the standard NO_DATA_FOUND exception, ensuring compatibility with conventional PL/SQL loop patterns used by callers such as VIEW_EXCEL_REPORT_NEW.
- BR-004 - The maximum length of a single line that can be read and returned is 4 000 characters (the declared size of the internal buffer); lines exceeding this length may be truncated.
- BR-005 - If the WebUtil PJC bean is not registered on the client, the procedure must not silently fail; it must display a descriptive error alert and raise TOOL_ERROR to prevent further execution.
- BR-006 - Any property-level error returned by the WebUtil_Core layer must cause immediate termination via TOOL_ERROR; no partial or default result may be returned to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-044 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the numeric return code produced by a previously executed host process. Given a PROCESS_ID handle, the function communicates with the WebUtil client-side bean to obtain the exit/return code of that process and returns it as a PLS_INTEGER to the caller (WEBUTIL.HOST).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of the host process whose return code is being queried.
- Step 2 - Set the process handle on the WebUtil bean by calling WebUtil_Core.setProperty, passing the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID.
- Step 3 - Retrieve the return code string from the WebUtil bean by calling WebUtil_Core.getProperty with the WUH_PACKAGE constant and the property key 'WUH_RC'.
- Step 4 - Convert the retrieved string value to a numeric PLS_INTEGER using TO_NUMBER and return it to the caller.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and the failing function, then exit without returning a value.

---
**Decision Points**

DP-001

Condition:
The WebUtil bean identified by WebUtil_Core.WUH_PACKAGE is registered and reachable when setProperty and getProperty are called.

TRUE:
The process handle is set successfully, the return code property is read, converted to a PLS_INTEGER, and returned to the caller.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed to the user stating that the bean was not found and that WEBUTIL_HOST.Get_Return_Code will not work, and the function terminates without returning a value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function requires a valid PROCESS_ID whose handle can be resolved by the WebUtil bean; the handle is set via the 'WUH_PROC_ID' property before the return code is read.
- BR-002 - The return code is stored in the WebUtil bean under the property key 'WUH_RC' and must be convertible to a number; the function applies TO_NUMBER to produce the PLS_INTEGER result.
- BR-003 - If the WebUtil bean is not registered at the time of invocation, the function must not silently fail; it must present a descriptive error alert that includes the bean implementation class name and the fully qualified function name (WEBUTIL_HOST.Get_Return_Code).
- BR-004 - No database interactions are performed; all state is maintained exclusively through the WebUtil client-side bean properties.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-045 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream collected from a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT (SP-039), passing the fixed stream identifier 'WUH_STDOUT' to isolate standard output from other output channels.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-039](#SP-039--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (`process`) that references a previously executed host process whose output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-039) with the supplied `process` identifier and the hard-coded stream label `'WUH_STDOUT'` to fetch all lines written to the standard output channel of that process.
- Step 3 - Return the resulting OUTPUT_ARRAY directly to the caller (WEBUTIL.GETVAR) without further transformation.

---
**Decision Points**

No conditional decision points are present in this function. The function unconditionally delegates to WEBUTIL.GETOUTPUT (SP-039) with a fixed stream identifier and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve process output is always `'WUH_STDOUT'`; this function exclusively targets the standard output channel and cannot be redirected to any other stream.
- BR-002 - The caller is responsible for supplying a valid `PROCESS_ID`; this function performs no validation of the process identifier before passing it to WEBUTIL.GETOUTPUT (SP-039).
- BR-003 - The return value is an OUTPUT_ARRAY as defined and populated by WEBUTIL.GETOUTPUT (SP-039); this function introduces no additional filtering or transformation of that array.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-046 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command synchronously on the client machine and returns the process exit code to the caller. The function delegates command launch to WEBUTIL.BLOCKING, waits for completion, retrieves the return code via WEBUTIL.GET_RETURN_CODE, and releases the client-side process handle via WEBUTIL.RELEASE_PROCESS. It is invoked by the Excel report viewer (VIEW_EXCEL_REPORT_NEW) to open or process files on the client workstation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-017](#SP-017--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-044](#SP-044--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-061](#SP-061--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the host command string (cmd) as input and initialise the return code (RC) to -1, indicating an unsuccessful or uninitialised state.
- Step 2 - Invoke WEBUTIL.BLOCKING (SP-017) with the command string to launch the host process on the client and block until the process completes; the call returns a PROCESS_ID handle (procId).
- Step 3 - Evaluate whether the returned PROCESS_ID is valid by calling WEBUTIL.ID_NULL (SP-047).
- Step 4 - If the PROCESS_ID is not null (i.e., the process was successfully launched), call WEBUTIL.GET_RETURN_CODE (SP-044) with the process handle to retrieve the exit code of the completed host process and assign it to RC.
- Step 5 - Release the client-side process object by calling WEBUTIL.RELEASE_PROCESS (SP-061) with the process handle, freeing any associated client resources.
- Step 6 - Return RC to the caller; a value of -1 indicates the process could not be launched, while any other value reflects the actual exit code of the host command.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(procId) evaluates to FALSE - i.e., the PROCESS_ID returned by WEBUTIL.BLOCKING is a valid (non-null) handle, meaning the host command was successfully launched on the client.

TRUE (ID_NULL returns FALSE - process is valid):
Retrieve the process exit code via WEBUTIL.GET_RETURN_CODE and then release the client-side process object via WEBUTIL.RELEASE_PROCESS; RC is updated with the actual exit code.

FALSE (ID_NULL returns TRUE - process handle is null):
Skip exit-code retrieval and resource release; RC retains its initialised value of -1, signalling to the caller that the host command failed to launch.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The return code is initialised to -1 before process launch; this sentinel value is returned to the caller whenever the host process cannot be started, allowing the caller to distinguish a launch failure from a successful execution with a zero or positive exit code.
- BR-002 - The host command is executed in blocking mode (via WEBUTIL.BLOCKING); the function does not return control to the caller until the client-side process has completed, ensuring sequential processing of the command.
- BR-003 - The client-side process handle must be released via WEBUTIL.RELEASE_PROCESS immediately after the exit code is retrieved; this rule ensures that client-side resources are not leaked regardless of the exit code value.
- BR-004 - Exit-code retrieval and resource release are performed only when a valid PROCESS_ID is obtained; if the process handle is null, neither WEBUTIL.GET_RETURN_CODE nor WEBUTIL.RELEASE_PROCESS is called, preventing operations on an invalid handle.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-047 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a reusable boolean utility that determines whether a given Pointer handle is uninitialised (null). Callers across the WebUtil and reporting layers use this function to guard against operations on invalid or unallocated handles before proceeding with host calls, bean registration, alert display, and similar actions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming Pointer argument (handle) supplied by the calling routine.
- Step 2 - Inspect the internal handle identifier (handle.hnd) to determine whether it holds a null value.
- Step 3 - If handle.hnd is null, return TRUE to signal that the handle is uninitialised.
- Step 4 - If handle.hnd is not null, return FALSE to signal that the handle is valid and populated.

---
**Decision Points**

DP-001

Condition:
handle.hnd IS NULL

TRUE:
The function returns TRUE, indicating the Pointer handle carries no valid reference and the caller should treat it as uninitialised.

FALSE:
The function returns FALSE, indicating the Pointer handle contains a valid reference and the caller may safely proceed with handle-dependent operations.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A Pointer handle is considered null solely on the basis of its internal hnd attribute; no other attribute or external state is evaluated.
- BR-002 - The function is read-only and produces no side effects; it neither modifies the handle nor interacts with any database object or session state.
- BR-003 - The function must return a boolean result for every possible input, including an explicitly null handle argument, ensuring callers always receive a deterministic TRUE or FALSE response.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-048 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the public initialisation entry point for the WEBUTIL_CORE package. Although the procedure body itself performs no explicit processing (it executes a null statement), the act of entering the package triggers the package initialisation block, which calls WEBUTIL.INITWEBUTIL (SP-049) to set up the WebUtil runtime environment on the client.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-049](#SP-049--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.GETOUTPUT invokes WEBUTIL.INIT to trigger package initialisation.
- Step 2 - The procedure body executes a null statement; no explicit logic is performed within the procedure itself.
- Step 3 - Oracle's package initialisation mechanism fires the package-level BEGIN block, which calls WEBUTIL.INITWEBUTIL (SP-049) to perform the actual WebUtil environment setup.
- Step 4 - Control returns to the calling routine (WEBUTIL.GETOUTPUT) with the WebUtil runtime fully initialised.

---
**Decision Points**

No conditional decision points exist within this procedure. The procedure body is unconditionally a null operation; the package initialisation block executes WEBUTIL.INITWEBUTIL (SP-049) automatically upon first package entry without any branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - WEBUTIL.INIT must be called before any WebUtil functionality is used; entering the package is sufficient to trigger the initialisation of the WebUtil runtime environment via WEBUTIL.INITWEBUTIL (SP-049).
- BR-002 - The procedure itself performs no processing; all substantive initialisation is delegated exclusively to WEBUTIL.INITWEBUTIL (SP-049) through the package-level initialisation block.
- BR-003 - No input or output parameters are required; the procedure is a side-effect-only entry point whose sole value is causing the package initialisation block to execute.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-049 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form session. The procedure registers the Java bean implementation classes for each WebUtil package component, verifies that the mandatory WebUtil object group (including its error alert and dummy item) is present in the form, conditionally navigates to and renders the bean areas, and determines the server-side file-path separator based on the host operating system. It is called once by WEBUTIL.INIT at form start-up to make all subsequent WebUtil functionality available.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-065](#SP-065--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) for later use.
- Step 2 - Populate the m_implClasses associative array by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java bean class name, establishing the component registry for the session.
- Step 3 - Check whether the WebUtil error alert object (m_errorAlert) is null using ID_NULL (SP-047). If it is null, the required WebUtil object group is absent from the form.
- Step 4 - If the error alert is absent, display a message informing the user that the WEBUTIL object group is not available and that WebUtil cannot operate, then pause execution. No further initialisation is performed.
- Step 5 - If the error alert is present, evaluate whether explicit bean instantiation is enabled (FLAG_EXPICIT_INSTANCIATE) and whether the form is in NORMAL mode (not Enter-Query mode).
- Step 6 - If both conditions are met, check whether the dummy item handle (hDummy) is non-null via ID_NULL (SP-047). A non-null handle indicates the standard WebUtil object group is in use.
- Step 7 - If the dummy item exists, navigate to it with GO_ITEM, then determine whether the original cursor field and the dummy item reside in the same block. If they share a block, advance to the next block with NEXT_BLOCK; otherwise navigate back to the original cursor field with GO_ITEM.
- Step 8 - Call SHOWBEANS (SP-065) with the parameter FALSE to render the bean areas without forcing focus, completing the visual initialisation of the WebUtil bean components.
- Step 9 - If the dummy item does not exist, take no action, deferring bean-area setup to the calling programmer.
- Step 10 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN', set the server file-path separator (m_serverFileSep) to a backslash; otherwise set it to a forward slash.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns TRUE (the WebUtil error alert object is not present in the form).

TRUE:
Display a message stating that the WEBUTIL object group is not available and WebUtil cannot work, then pause. Remaining initialisation steps are skipped.

FALSE:
Proceed with conditional bean instantiation and server OS detection.

---

DP-002

Condition:
FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE:
Attempt explicit bean instantiation: evaluate the dummy item handle and, if valid, navigate and call SHOWBEANS (SP-065).

FALSE:
Skip explicit bean instantiation entirely; proceed directly to server OS detection.

---

DP-003

Condition:
ID_NULL(hDummy) returns FALSE (the dummy item handle is valid, indicating the standard WebUtil object group is present).

TRUE:
Navigate to the dummy item, perform block-navigation logic, and call SHOWBEANS (SP-065) with FALSE.

FALSE:
Take no action; the programmer is assumed to manage bean-area setup independently.

---

DP-004

Condition:
The original cursor field (startPoint) and the dummy item (hDummy) belong to the same block (GET_ITEM_PROPERTY block names are equal).

TRUE:
Call NEXT_BLOCK to move focus away from the dummy item's block.

FALSE:
Call GO_ITEM(startPoint) to return focus to the original cursor position.

---

DP-005

Condition:
INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 (the server OS name contains 'WIN').

TRUE:
Set m_serverFileSep to '\' (Windows backslash separator).

FALSE:
Set m_serverFileSep to '/' (Unix/Linux forward-slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert object, must be present in the form before WebUtil can be initialised; if absent, initialisation is aborted and the user is notified.
- BR-002 - Explicit bean instantiation via navigation is only performed when the form is in NORMAL mode; Enter-Query mode must not trigger bean navigation to avoid known form-navigation conflicts.
- BR-003 - Explicit bean instantiation is further gated by the FLAG_EXPICIT_INSTANCIATE flag, allowing the behaviour to be enabled or disabled as a configurable workaround without code changes.
- BR-004 - When the standard WebUtil object group is in use (dummy item is non-null), the procedure must navigate to the dummy item and call SHOWBEANS (SP-065) with FALSE to ensure bean areas are rendered before the form is used.
- BR-005 - After navigating to the dummy item, the procedure must restore the user's original cursor position: if the dummy item shares a block with the original field, NEXT_BLOCK is used; otherwise GO_ITEM returns focus to the exact original field.
- BR-006 - If the dummy item is not found, no bean-area navigation is performed; responsibility for bean setup is delegated to the form developer.
- BR-007 - The server file-path separator (m_serverFileSep) must be set to '\' for Windows server environments and '/' for all other operating systems, ensuring correct server-side path construction throughout the WebUtil session.
- BR-008 - All ten WebUtil package components must have their Java bean implementation class registered in m_implClasses during initialisation; an empty string is a valid registration value (as used for WUU_PACKAGE).

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-050 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a lightweight Boolean indicator of whether the most recent WebUtil operation resulted in an error. Callers (such as WEBUTIL.LOG) use this function to determine whether an error condition is currently active before taking further action.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the value of the package-level variable `m_lastError`, which holds the error code set by the most recent WebUtil operation.
- Step 2 - Evaluate whether `m_lastError` is not equal to zero.
- Step 3 - Return TRUE if `m_lastError` is non-zero (an error exists), or FALSE if `m_lastError` equals zero (no error).

---
**Decision Points**

DP-001

Condition:
`m_lastError <> 0`

TRUE:
The function returns TRUE, indicating that the last WebUtil operation recorded an error code.

FALSE:
The function returns FALSE, indicating that no error was recorded by the last WebUtil operation (error code is zero).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An error condition is defined solely by the package-level variable `m_lastError` holding a non-zero value; a value of zero always represents a clean (no-error) state.
- BR-002 - The function accepts no input parameters and performs no database interaction; it is a pure in-memory state check.
- BR-003 - The function is read-only with respect to `m_lastError`; it reports the current error state without modifying it.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-051 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not. This utility function is used by WEBUTIL.LOG to guard against operations on unopened file references.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed in via the `file` input parameter.
- Step 2 - Inspect the `handle` attribute of the FILE_TYPE record to determine whether a valid file handle exists.
- Step 3 - If `file.handle` is NULL, return FALSE to indicate the file is not open.
- Step 4 - If `file.handle` is NOT NULL, return TRUE to indicate the file is currently open.

---
**Decision Points**

DP-001

Condition:
`file.handle IS NULL`

TRUE:
The file handle has not been assigned; the function returns FALSE, signalling that the file is not open.

FALSE:
The file handle is populated; the function returns TRUE, signalling that the file is open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its `handle` attribute is non-NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs no side-effects and does not interact with any database objects; it is a pure state-inspection utility.
- BR-003 - The function accepts exactly one input parameter of type FILE_TYPE and always returns a BOOLEAN result; no output parameters are used.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-052 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java `java.io.File.length()` method via the Oracle JNI bridge, providing Oracle Forms PL/SQL routines with a reliable way to determine file size without direct database or filesystem SQL access.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (`obj`) passed in by the calling routine (e.g., D2KWUTIL.CHOOSEFILE, WEBUTIL.GETSTRING, or other callers listed under Invoked From).
- Step 2 - Clear the JNI argument list by setting `args` to NULL, ensuring no stale arguments are carried over from a previous call.
- Step 3 - Invoke the Java instance method `java.io.File.length()` on the supplied object via `JNI.CALL_LONG_METHOD`, passing FALSE (non-static call), the target object, the fully-qualified class name, the method name, and the method descriptor `()J` (no arguments, returns a long integer).
- Step 4 - Return the numeric result (file size in bytes) to the calling routine as an Oracle NUMBER.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI call and returns its result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid, non-null Java `java.io.File` object; the JNI layer assumes the object reference is properly initialised by the caller.
- BR-002 - The JNI argument list (`args`) must be reset to NULL before each invocation to prevent argument contamination from prior JNI calls.
- BR-003 - File size is returned in bytes as reported by the underlying Java runtime; the function does not perform unit conversion or rounding.
- BR-004 - The function performs no database interaction; file-length resolution is handled entirely through the JNI bridge to the Java Virtual Machine.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-053 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to the server-side WebUtil log file. On first invocation the procedure initialises the logging configuration cache by reading three property-bundle settings (enabled flag, errors-only flag, and target file path) via WEBUTIL.READFROMPROPERTYBUNDLE, then propagates the resolved logging mode to the client bean via a WUC_SRV_LOGGING property. Subsequent calls use the cached configuration to append the supplied message - optionally prefixed with the client IP address and username - to the log file, provided logging is permitted and the message severity satisfies the active filter.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-050](#SP-050--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-051](#SP-051--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-056](#SP-056--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-6; otherwise skip to Step 7.
- Step 2 - Read the three logging properties from the property bundle using WEBUTIL.READFROMPROPERTYBUNDLE: 'logging.enabled', 'logging.errorsonly', and 'logging.file', storing results in module-level variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile respectively.
- Step 3 - If logging is enabled but no log file path was returned, disable logging (set m_loggingAllowed to FALSE) and raise error WUC-008. If no bean is registered yet, display the error in English via WEBUTIL.ERRORALERT; otherwise propagate the error through the registered bean and set the WUC_SRV_LOGGING client property to '0'.
- Step 4 - If at least one bean is registered, synchronise the WUC_SRV_LOGGING client property to reflect the resolved mode: '1' for errors-only logging, '2' for full logging, or '0' for logging disabled.
- Step 5 - Evaluate whether the current call should produce output: logging must be allowed AND either errors-only mode is OFF or the isError flag is TRUE.
- Step 6 - Open the log file in append mode using TEXT_IO.FOPEN and verify it is open via WEBUTIL.IS_OPEN. If the file cannot be opened, raise NO_DATA_FOUND.
- Step 7 - Write the message to the log file using WEBUTIL.PUT_LINE. If a client IP address is available (m_clientIP IS NOT NULL), prefix the message with the client IP and username; otherwise write the message as supplied.
- Step 8 - Close the log file with TEXT_IO.FCLOSE.
- Step 9 - In the exception handler, if SQLCODE equals -302000 (file write failure), disable logging and raise error WUC-007 via WEBUTIL.ERRORALERT (no bean) or via the registered bean; all other exceptions are re-raised.

---
**Decision Points**

DP-001

Condition:
m_loggingAllowed IS NULL (logging configuration cache not yet initialised).

TRUE:
Read logging properties from the property bundle and initialise the cache (Steps 2-4).

FALSE:
Skip initialisation and proceed directly to the write phase using the existing cached values.

---

DP-002

Condition:
Logging is enabled (m_loggingAllowed = TRUE) but the log file path (m_loggingFile) is NULL.

TRUE:
Disable logging and raise error WUC-008. Route the error through WEBUTIL.ERRORALERT if no bean is registered, or through the bean with WUC_SRV_LOGGING set to '0' if a bean is available.

FALSE:
Retain the enabled state and continue.

---

DP-003

Condition:
At least one bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the point of cache initialisation.

TRUE:
Set the WUC_SRV_LOGGING client property to '1' (errors-only), '2' (full), or '0' (disabled) to match the resolved logging mode.

FALSE:
Skip the client property update; the bean is not yet available to receive it.

---

DP-004

Condition:
m_loggingAllowed is TRUE AND (m_loggingErrorsOnly is FALSE OR isError is TRUE).

TRUE:
Open the log file and write the message.

FALSE:
Skip writing; the message does not meet the active logging filter.

---

DP-005

Condition:
m_clientIP IS NULL.

TRUE:
Write the message to the log file without a prefix.

FALSE:
Prefix the message with the client IP address and username before writing.

---

DP-006

Condition:
Exception handler fires with SQLCODE = -302000 (file write error).

TRUE:
Disable logging (m_loggingAllowed := FALSE) and raise error WUC-007 via WEBUTIL.ERRORALERT (no bean) or via the registered bean with WUC_SRV_LOGGING set to '0'.

FALSE:
Re-raise the exception for the caller to handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration is read from the property bundle exactly once per session; the resolved values are cached in module-level variables and reused on all subsequent calls to avoid repeated property lookups.
- BR-002 - Logging is only active when all three conditions are met: the 'logging.enabled' property resolves to 'true', a non-null log file path is configured, and no unrecoverable file error has occurred.
- BR-003 - If 'logging.errorsonly' is 'true', only calls where isError = TRUE produce a log entry; informational messages are silently discarded.
- BR-004 - A missing log file path is treated as a configuration error: logging is immediately disabled and error WUC-008 is raised to alert the administrator.
- BR-005 - The WUC_SRV_LOGGING client property must reflect the server-side logging mode ('0' = off, '1' = errors only, '2' = full) so that the client bean can coordinate its own logging behaviour; this property is only set when at least one bean is registered.
- BR-006 - Each log entry is appended to the file (mode 'A'); the file is opened and closed per call to ensure data is flushed and the file handle is not held open between invocations.
- BR-007 - When a client IP address is known, every log entry is prefixed with the client IP and username to support audit traceability across multi-user deployments.
- BR-008 - A file write failure (SQLCODE -302000) permanently disables logging for the session and raises error WUC-007; this prevents repeated failed write attempts and alerts the administrator through the appropriate channel (WEBUTIL.ERRORALERT or the registered bean).

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-054 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and parses the WebUtil configuration file, populates the in-memory property bundle (m_propertyBundle) with all key-value pairs found in that file, and returns the value associated with the requested propertyKey. The configuration file path is resolved by checking, in order, a Forms global variable, an operating-system environment variable, and a Forms parameter. If the file cannot be found or read, an error alert is raised via WEBUTIL.ERRORALERT and the procedure signals a configuration error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global is unset, attempt to retrieve the file path from the operating-system environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, fall back to the Forms parameter identified by WEBUTIL_CONFIG_PARAM via NAME_IN.
- Step 4 - If all three sources return null, raise NO_DATA_FOUND to trigger the error-handling branch.
- Step 5 - Persist the resolved file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL using COPY.
- Step 6 - Open the configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no delimiter.
- Step 10 - For valid key-value lines, increment the property index, then store the trimmed, lower-cased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 11 - After storing each entry, compare the stored key (lower-case) against the lower-case form of the input propertyKey; if they match, capture the corresponding value in the result variable.
- Step 12 - After the loop completes, close the file using TEXT_IO.FCLOSE and return the captured result (NULL if the key was not found in the file).
- Step 13 - On NO_DATA_FOUND in the outer exception handler (configuration file not specified): if no bean package is registered yet, call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 14 - On SQLCODE -302000 (file unreadable): if no bean package is registered yet, call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - For any other unexpected exception, re-raise to the caller.

---
**Decision Points**

DP-001

Condition:
The value read from WEBUTIL_CONFIG_GLOBAL equals the sentinel '[NOTSET]'.

TRUE:
Clear configFile and attempt to resolve the path from the OS environment variable (TOOL_ENV.GETVAR).

FALSE:
Use the global variable value as the configuration file path; skip environment and parameter lookups.

---

DP-002

Condition:
configFile is still NULL after the environment variable lookup.

TRUE:
Attempt to resolve the path from the Forms parameter WEBUTIL_CONFIG_PARAM.

FALSE:
Use the environment variable value as the configuration file path.

---

DP-003

Condition:
configFile is NULL after all three resolution sources (global, environment, parameter) have been exhausted.

TRUE:
Raise NO_DATA_FOUND to trigger the configuration-missing error path.

FALSE:
Proceed to persist the resolved path and open the file.

---

DP-004

Condition:
The first character of a line read from the file is '#'.

TRUE:
Skip the line entirely (treated as a comment).

FALSE:
Attempt to parse the line as a key-value pair.

---

DP-005

Condition:
The line contains an '=' character (INSTR returns a position greater than zero).

TRUE:
Split the line into key and value, store them in m_propertyBundle, and check whether the key matches propertyKey.

FALSE:
Skip the line (no valid key-value pair present).

---

DP-006

Condition:
The lower-cased stored key equals the lower-cased input propertyKey.

TRUE:
Capture the corresponding value into the result variable.

FALSE:
Continue reading subsequent lines without updating the result.

---

DP-007

Condition:
A NO_DATA_FOUND exception is raised in the outer handler (configuration file path not specified) AND m_registeredPackages.FIRST is NULL (no bean registered).

TRUE:
Call WEBUTIL.ERRORALERT with 'WUC-005: No WebUtil Configuration File specified'.

FALSE:
Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 5.

---

DP-008

Condition:
SQLCODE equals -302000 (file cannot be read) AND m_registeredPackages.FIRST is NULL (no bean registered).

TRUE:
Call WEBUTIL.ERRORALERT with 'WUC-006: Unable to read WebUtil Configuration File'.

FALSE:
Delegate the error to Webutil_Core.Error with error code WUC_PACKAGE / 6, passing configFile as context.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the OS environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing cannot continue.
- BR-002 - Once the configuration file path is successfully resolved, it must be written back to WEBUTIL_CONFIG_GLOBAL so that subsequent calls within the same Forms session do not repeat the resolution process.
- BR-003 - Lines beginning with '#' are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are valid key-value entries; lines without this delimiter must be silently skipped.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed, ensuring case-insensitive, whitespace-tolerant key matching.
- BR-006 - Property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped, ensuring clean values regardless of file line-ending format.
- BR-007 - All valid key-value pairs in the file are loaded into the in-memory collection m_propertyBundle regardless of whether they match the requested key, making the full property set available for subsequent lookups without re-reading the file.
- BR-008 - When the configuration file is missing or unspecified (NO_DATA_FOUND) or unreadable (SQLCODE -302000), the procedure must set m_config_error to TRUE and return NULL rather than propagating the exception, so that the caller can handle the failure gracefully.
- BR-009 - Error messages must be surfaced via WEBUTIL.ERRORALERT only when no bean package has been registered (m_registeredPackages.FIRST is NULL); once a bean is registered, errors are routed through the Webutil_Core error framework instead.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-055 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating to the WebUtil Core bean layer. The procedure sets the active file handle and the text payload as properties on the WUF_PACKAGE bean, enabling Oracle Forms to perform client-side text I/O during operations such as Excel report generation invoked from VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target client file handle (file.handle extracted from the file_type parameter) and the text string to be written (arg).
- Step 2 - Register the file handle with the WebUtil Core bean by calling WebUtil_Core.setProperty for the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean, making it the active output target.
- Step 3 - Transmit the formatted text string to the same bean by calling WebUtil_Core.setProperty for the WUF_TEXTIO_PUTF property, triggering the actual write operation on the client.
- Step 4 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 5 - If a property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
The WebUtil Core bean for WUF_PACKAGE is registered and available on the client at the time setProperty is called.

TRUE:
Both setProperty calls (WUF_TEXTIO_HANDLE and WUF_TEXTIO_PUTF) complete successfully and the text is written to the client file; the procedure exits normally.

FALSE:
A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed naming the missing implementation class, and TOOL_ERR.TOOL_ERROR is raised to halt execution.

---

DP-002

Condition:
A setProperty call succeeds without raising a PROPERTY_ERROR exception.

TRUE:
The property is set correctly and processing continues to the next step.

FALSE:
A PROPERTY_ERROR exception is raised; TOOL_ERR.TOOL_ERROR is raised immediately to halt execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle embedded in the file_type parameter must be passed to the WebUtil Core bean before the text payload is set; the handle registration (WUF_TEXTIO_HANDLE) must always precede the write instruction (WUF_TEXTIO_PUTF).
- BR-002 - The WebUtil Core bean for WUF_PACKAGE must be registered on the client; if it is not, the procedure must not silently fail - it must alert the user and raise a fatal error.
- BR-003 - Any property-set failure (PROPERTY_ERROR) is treated as a fatal condition and must propagate as TOOL_ERR.TOOL_ERROR, ensuring the calling routine (VIEW_EXCEL_REPORT_NEW) is notified of the failure.
- BR-004 - No database interaction is performed; this procedure operates exclusively through client-side WebUtil bean communication, keeping file I/O entirely on the client tier.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-056 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil bean via three sequential property-set calls. It is called exclusively by WEBUTIL.LOG to append log entries to a file on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Transmit the file handle to the WebUtil bean by calling WebUtil_Core.setProperty with the WUF_PACKAGE context, property key WUF_TEXTIO_HANDLE, and the value file.handle, establishing which open file subsequent write operations will target.
- Step 3 - Transmit the text content by calling WebUtil_Core.setProperty with property key WUF_TEXTIO_PUT and the value item, instructing the bean to write that string to the file.
- Step 4 - Signal a newline by calling WebUtil_Core.setProperty with property key WUF_TEXTIO_NEWLINE and the value 1, causing the bean to append a line terminator after the written text.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If any property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
The WebUtil bean identified by WebUtil_Core.WUF_PACKAGE is registered and available at the time any setProperty call is made.

TRUE:
All three property-set calls (WUF_TEXTIO_HANDLE, WUF_TEXTIO_PUT, WUF_TEXTIO_NEWLINE) complete successfully and the line is written to the client file.

FALSE:
The BEAN_NOT_REGISTERED exception is raised; an error alert is displayed naming the missing implementation class, and TOOL_ERR.TOOL_ERROR is raised to halt execution.

DP-002

Condition:
A property-set call succeeds without raising a PROPERTY_ERROR exception.

TRUE:
Processing continues to the next property-set call (or completes normally after the third call).

FALSE:
The PROPERTY_ERROR exception is caught and TOOL_ERR.TOOL_ERROR is raised to halt execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil bean (WUF_PACKAGE) must be registered on the client before PUT_LINE is invoked; if it is absent the procedure raises a fatal error and no data is written.
- BR-002 - A line written by PUT_LINE always includes a newline terminator (WUF_TEXTIO_NEWLINE = 1); partial or unterminated lines are not supported by this procedure.
- BR-003 - The file handle must be supplied as a valid file_type value; the procedure does not perform its own validation of the handle and relies on the WebUtil bean to enforce file-open state.
- BR-004 - Any property communication failure (PROPERTY_ERROR) is treated as a fatal condition; the error is not suppressed or retried, and TOOL_ERR.TOOL_ERROR is raised immediately.
- BR-005 - The procedure produces no return value; success is implicit when no exception is raised, and failure is always signalled by propagating TOOL_ERR.TOOL_ERROR to the caller.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-057 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from the in-memory property bundle cache. If the bundle has not yet been populated, it delegates initialisation to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. The function is used by WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN to resolve configuration properties at runtime without repeated file reads.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-054](#SP-054--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory collection m_propertyBundle.
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, return NULL immediately and take no further action.
- Step 3 - If no configuration error exists but the property bundle is empty (count = 0), call WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) passing the requested key, and assign its return value as the result.
- Step 4 - If the property bundle is already populated (count > 0), iterate through each entry in m_propertyBundle and compare the stored propertyKey (held in lower-case) against the lower-case form of the supplied propertyKey.
- Step 5 - On finding a matching entry, assign the corresponding propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the resolved result value (or NULL if no match was found or a config error was present) to the calling routine.

---
**Decision Points**

DP-001

Condition:
m_config_error flag is TRUE (a prior configuration file read error has been recorded).

TRUE:
Return NULL immediately; no further processing is performed.

FALSE:
Proceed to check whether the property bundle has been populated.

---

DP-002

Condition:
The in-memory property bundle collection m_propertyBundle is empty (COUNT = 0).

TRUE:
Delegate to WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) to load and return the property value for the supplied key; assign the returned value as the result.

FALSE:
The bundle is already loaded; iterate through existing entries to locate the matching key.

---

DP-003

Condition:
During iteration of m_propertyBundle, the current entry's propertyKey matches the lower-case form of the supplied propertyKey.

TRUE:
Assign the entry's propertyValue to the result variable and exit the loop.

FALSE:
Continue to the next entry in the collection; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has been detected in a prior execution (m_config_error = TRUE), the function must return NULL without attempting any property lookup or bundle population.
- BR-002 - Property key matching is case-insensitive; stored keys are held in lower-case and the supplied key is compared in lower-case to ensure consistent resolution regardless of the case used by the caller.
- BR-003 - The property bundle is populated lazily: WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) is invoked only when the bundle is empty, avoiding redundant initialisation on subsequent calls.
- BR-004 - Once a matching property key is found during iteration, the loop exits immediately; only the first matching entry is returned, enforcing uniqueness of key resolution within the bundle.
- BR-005 - The function returns NULL when no matching property key exists in the bundle and no config error is present, allowing callers to handle missing configuration gracefully.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-058 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by sending a property key and optional arguments to the WebUtil Core layer and reading back the resolved translation. This function is currently used by WEBUTIL.CHECKLIBS to obtain localised text such as the progress bar title.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the message bundle property key and an optional arguments string as input.
- Step 2 - Concatenate the property key and the arguments string with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WUC_TRANS_MSG property slot on the WUC_PACKAGE object via Webutil_Core.setProperty, triggering the client-side translation resolution.
- Step 4 - Read the resolved translated message back from the same WUC_TRANS_MSG property slot via Webutil_Core.getProperty.
- Step 5 - Return the resolved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed set-then-get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and arguments must be combined using a pipe character ('|') as the delimiter before being passed to the WebUtil Core property mechanism; this format is required for the client-side bundle resolver to parse them correctly.
- BR-002 - The args parameter is optional and defaults to NULL; when NULL, the composite value passed to Webutil_Core.setProperty will be the property key followed by a trailing pipe character.
- BR-003 - Translation resolution is performed entirely through the Webutil_Core.setProperty and Webutil_Core.getProperty mechanism using the WUC_PACKAGE scope and the WUC_TRANS_MSG property name; no direct database lookup or alternative resolution path is used.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-059 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms session on first contact. The procedure parses the bean's registration packet, maps the bean short name to an internal package identifier, captures one-time client environment details (IP address, OS, architecture, user name, locale, path and file separators), configures the system-library download directory on the client, retrieves and stores the WebUtil bean version, applies heartbeat-blocking and server-logging settings, and triggers required library availability checks for both the newly registered package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-018](#SP-018--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-038](#SP-038--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-042](#SP-042--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the extracted short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant and assign it to packageID.
- Step 3 - Check whether m_clientIP is null to determine whether this is the very first bean registration in the session. If so, set checkUserLibs to TRUE and parse positions 2-8 of clientInfo to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), clientOSArch, m_clientOSArch (set to 1 when the architecture string contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 4 - Check whether packageID already exists in the m_registeredPackages associative array. If it does not, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) as the registration entry and set newPackage to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - If checkUserLibs is TRUE, perform one-time session initialisation: set REDOWNLOAD_SYSLIB to FALSE; resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with the key 'install.syslib.location.client.{OSFamily}.{OSArch}', then retrying without the architecture suffix if the result is null.
- Step 7 - If no client library directory is found in the property bundle, transmit a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config, letting the client default to its JRE location. If a directory is found, replace the '$(SERVERHOST)' token with the resolved server host name, transmit the full WUC_SYSLIB_DIR value, compare it against the previously stored value retrieved via WEBUTIL.GETCLIENTSETTING, and if the two differ, persist the new value via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for WUC_BEAN_VERSION and assigning the result to WEBUTIL_CORE.WEBUTIL_VERSION.
- Step 9 - If the 'logging.connections' property bundle entry evaluates to 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG containing the current form name, client OS, and locale code.
- Step 10 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS with the string representation of packageID to verify and download any required package-specific libraries.
- Step 11 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 12 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lowercase value is 'true', 'yes', or '1', set the WUC_BLOCK_ALLOW_HEART_BEAT property to '1' on the registered package; otherwise set it to '0'.
- Step 13 - Evaluate the m_loggingAllowed and m_loggingErrorsOnly flags and transmit the WUC_SRV_LOGGING property to the registered package: '1' for errors-only logging, '2' for full logging, or '0' for logging disabled.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known bean codes (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package-ID constant.
FALSE: packageID remains unassigned; no further mapping is performed for unrecognised bean names.

DP-002
Condition: m_clientIP IS NULL (first bean registration in the current session).
TRUE: checkUserLibs is set to TRUE and client environment fields (IP, OS, OS family, architecture, user name, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; parsing is skipped and checkUserLibs remains FALSE.

DP-003
Condition: The architecture string extracted from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch retains its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The package is registered using the current trigger item and newPackage is set to TRUE.
FALSE: The package was already registered; the existing entry is preserved and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.GETVAR returns a non-null value for 'COMPUTERNAME'.
TRUE: serverHost is set to the COMPUTERNAME environment variable value.
FALSE: WEBUTIL.GETVAR is called again for 'HOST' to resolve the server host name.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family-and-architecture-specific key 'install.syslib.location.client.{OSFamily}.{OSArch}'.
TRUE: clientLibDir is set to that value; the OS-family-only fallback lookup is skipped.
FALSE: WEBUTIL.READFROMPROPERTYBUNDLE is called again using only the OS-family key 'install.syslib.location.client.{OSFamily}'.

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is set to a value containing only the server host and application config, deferring directory resolution to the client JRE.
FALSE: clientLibDir is used; the '$(SERVERHOST)' token is replaced, WUC_SYSLIB_DIR is transmitted with the full path, and the old stored directory is compared against the new one.

DP-008
Condition: clientLibDirOld (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The stored directory is current; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: The lowercase value of the 'logging.connections' property bundle entry equals 'true'.
TRUE: WEBUTIL.LOG records a connection entry including the form name, client OS, and locale code.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to validate and download package-specific libraries.
FALSE: Library check for this package is skipped.

DP-011
Condition: The lowercase value of 'BlockAllowHeartBeat' from the property bundle is 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the registered package, instructing the client bean to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', allowing normal heartbeat behaviour.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging).
FALSE: Evaluate whether m_loggingAllowed is TRUE without the errors-only restriction (see DP-013).

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging enabled).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled).

DP-014
Condition: checkUserLibs is TRUE (evaluated after the newPackage library check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to verify and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only recognised bean short names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are mapped to a package ID; unrecognised names do not receive a packageID assignment.
- BR-002 - Client environment details (IP address, OS name, OS family, architecture, user name, path separator, file separator, language code) are captured exactly once per session, on the first bean registration call (when m_clientIP is null).
- BR-003 - A client machine with a 64-bit indicator in its architecture string is flagged as 64-bit (m_clientOSArch = 1); all others are treated as non-64-bit.
- BR-004 - Each bean type may be registered only once per form session; if multiple instances of the same bean exist (e.g. in a multi-row block), only the first instance is recorded in m_registeredPackages.
- BR-005 - The system-library client directory is resolved with OS-family and architecture specificity first; the architecture-agnostic OS-family key is used only as a fallback.
- BR-006 - When no client library directory is configured, the client bean is responsible for determining the download location (defaults to the client JRE); the server transmits only host and config context.
- BR-007 - When a configured client library directory changes between sessions (detected by comparing the new value against the value stored via WEBUTIL.GETCLIENTSETTING), REDOWNLOAD_SYSLIB is set to TRUE and the new directory is persisted via WEBUTIL.SETCLIENTSETTING.
- BR-008 - The '$(SERVERHOST)' token within a configured client library directory path must be substituted with the resolved server host name before the path is transmitted to the client.
- BR-009 - Connection logging is conditional: a log entry is written only when the 'logging.connections' property bundle entry is explicitly set to 'true' (case-insensitive).
- BR-010 - Library availability checks (WEBUTIL.CHECKLIBS) for a specific package are performed only when that package is newly registered in the current session.
- BR-011 - User-library checks (WEBUTIL.CHECKLIBS with 'user') are performed only once per session, during the same first-registration pass that captures client environment details.
- BR-012 - The heartbeat-blocking instruction sent to the client bean is governed solely by the 'BlockAllowHeartBeat' configuration entry; accepted affirmative values are 'true', 'yes', and '1' (case-insensitive).
- BR-013 - Server-side logging state is communicated to the client bean via the WUC_SRV_LOGGING property using a three-value scheme: 0 = disabled, 1 = errors only, 2 = full logging.
- BR-014 - The WEBUTIL.LOG initialisation call (null message) must occur after at least one bean has been registered in m_registeredPackages so that a handler bean exists to process subsequent client communication.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-060 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native library function with the WebUtil client-side bean so that Oracle Forms can subsequently invoke it via a FunctionHandle. The procedure transmits the library name and function name to the WebUtil bean, retrieves the resulting handle token, converts it to a numeric handle, and increments the internal function-handle counter when registration succeeds. It is called exclusively by REGISTER_FUNCTION_CALL in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and push the combined specification to the WebUtil bean by calling WebUtil_Core.setProperty with the WUL_PACKAGE context and the WUL_FUNCTION_SPEC property key.
- Step 3 - Retrieve the registration result from the WebUtil bean by calling WebUtil_Core.getProperty with the WUL_PACKAGE context and the WUL_REGISTER_FUNCTION property key; the bean returns an 8-character string token representing the handle.
- Step 4 - Convert the string token to a numeric value using TO_NUMBER and assign it to the hnd field of the local FunctionHandle variable (funcHnd).
- Step 5 - Call ID_NULL (SP-047) to determine whether the returned handle is a valid (non-null) registration.
- Step 6 - If the handle is valid (ID_NULL returns FALSE), increment the module-level counter m_funcHandleCount by 1 to track the total number of successfully registered function handles.
- Step 7 - Return the populated FunctionHandle to the caller.
- Step 8 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 9 - If a property interaction error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to abort processing.
- Step 10 - If the string-to-number conversion fails (VALUE_ERROR exception), raise TOOL_ERR.TOOL_ERROR to signal a data conversion failure.

---
**Decision Points**

DP-001

Condition:
After retrieving the handle string from the WebUtil bean, ID_NULL(funcHnd) is evaluated to determine whether the returned FunctionHandle represents a valid registration.

TRUE (handle IS null / invalid):
The function-handle counter (m_funcHandleCount) is NOT incremented; the null handle is still returned to the caller.

FALSE (handle is valid / non-null):
m_funcHandleCount is incremented by 1, recording the successful registration before the handle is returned.

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty calls, indicating the WebUtil bean class is absent on the client.

TRUE:
An error alert is displayed to the user citing the missing bean class name, and FORM_TRIGGER_FAILURE is raised to halt form processing.

FALSE:
Normal processing continues (no alert, no forced failure).

---

DP-003

Condition:
A PROPERTY_ERROR exception is raised during bean property interaction.

TRUE:
FORM_TRIGGER_FAILURE is raised immediately to abort processing; no alert is issued.

FALSE:
Normal processing continues.

---

DP-004

Condition:
A VALUE_ERROR exception is raised when TO_NUMBER attempts to convert the handle string returned by the bean.

TRUE:
TOOL_ERR.TOOL_ERROR is raised to signal an unrecoverable data conversion failure.

FALSE:
Conversion succeeds and the numeric handle is stored in funcHnd.hnd.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil bean MUST be formatted as a pipe-delimited string combining libName and funcName (libName || '|' || funcName); no other delimiter or ordering is permitted.
- BR-002 - The module-level counter m_funcHandleCount MUST be incremented only when the registered FunctionHandle is non-null, as determined by ID_NULL (SP-047); null handles do not count toward the registered-function total.
- BR-003 - If the WebUtil bean is not present on the client at the time of registration, the procedure MUST alert the user with the bean class name and MUST raise FORM_TRIGGER_FAILURE; silent failure is not permitted.
- BR-004 - A VALUE_ERROR during handle conversion (i.e., the bean returned a non-numeric token) MUST be escalated as TOOL_ERR.TOOL_ERROR, distinguishing it from a form-trigger failure.
- BR-005 - The procedure MUST return a FunctionHandle to the caller in all non-exception paths, even when the handle is null, ensuring the caller can perform its own null-handle checks.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-061 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This procedure ensures that process resources managed by the WebUtil host mechanism are properly cleaned up after use, preventing stale handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) as an IN OUT parameter representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE, passing the WUH_CLEAR_PROC property key and the current process handle value.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the process handle to deregister any callback trigger associated with that process.
- Step 4 - Set the process handle to NULL, signalling to the caller that the handle is no longer valid.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert identifying the missing implementation class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to clear the process property or callback trigger (i.e., the WebUtil host bean identified by WebUtil_Core.WUH_PACKAGE is not registered in the current session).

TRUE:
WebUtil_Core.ErrorAlert is called with a message composed of the implementation class name retrieved via WebUtil_Core.getImplClass and a static notification that WEBUTIL_HOST.Release_Process will not work; normal release steps are abandoned.

FALSE:
The property is cleared, the callback trigger is deregistered, and the process handle is set to NULL; processing completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be passed as IN OUT; the procedure nullifies it upon successful release, and the caller must treat a NULL handle as an indication that the process has been fully released.
- BR-002 - Both the property clear (WebUtil_Core.setProperty with WUH_CLEAR_PROC) and the callback trigger deregistration (WebUtil_Core.ClearCallbackTrigger) must be performed before nullifying the handle, ensuring no orphaned callbacks remain.
- BR-003 - If the WebUtil host bean is not registered, the release operation must not silently fail; an error alert must be presented to the user identifying the missing bean and the affected procedure.
- BR-004 - No database interactions are performed during process release; the operation is confined entirely to WebUtil session-level state management.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-062 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named client-side configuration property by delegating to the WebUtil Core bean. The procedure accepts a property name and value, concatenates them into a key=value assignment string, and forwards the instruction to the WebUtil Core package bean via WebUtil_Core.setProperty. It is called during library initialisation (WEBUTIL.CHECKLIBS) and bean registration (WEBUTIL.REGISTERBEAN) to apply local client settings required for WebUtil operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if it is null, no action is taken and the procedure exits silently.
- Step 3 - Construct the assignment string by concatenating propertyName, the literal '=', and propertyValue.
- Step 4 - Invoke WebUtil_Core.setProperty, passing the constant WebUtil_Core.WUC_PACKAGE as the bean identifier, the constant 'WUC_SET_LOCAL_PROPERTY' as the property action, and the constructed assignment string as the value.
- Step 5 - If WebUtil_Core raises BEAN_NOT_REGISTERED, display an error alert identifying the missing bean class (retrieved via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to halt further processing.
- Step 6 - If WebUtil_Core raises PROPERTY_ERROR, raise FORM_TRIGGER_FAILURE to halt further processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue into the assignment string and call WebUtil_Core.setProperty to apply the client setting.

FALSE: Skip the setProperty call entirely; the procedure exits without error and without modifying any client setting.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty execution.

TRUE: Display an error alert identifying the unregistered bean class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal execution (no exception handling required for this path).

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty execution.

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Continue normal execution (no exception handling required for this path).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName is treated as a no-operation; the procedure must not attempt to set a client property when no property name is supplied.
- BR-002 - The property assignment must be formatted as a single concatenated string in the form propertyName=propertyValue before being passed to WebUtil_Core.setProperty.
- BR-003 - The target bean is always identified by the constant WebUtil_Core.WUC_PACKAGE, and the action is always identified by the constant 'WUC_SET_LOCAL_PROPERTY'; callers may not override these identifiers.
- BR-004 - If the WebUtil Core bean is not registered at the time of invocation, the procedure must surface a descriptive error alert (including the bean implementation class name) and terminate the form trigger via FORM_TRIGGER_FAILURE.
- BR-005 - If a property error occurs during the setProperty call, the procedure must terminate the form trigger via FORM_TRIGGER_FAILURE without surfacing an additional alert to the user.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-063 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via the local DB writer or a server-side file via the application-server writer. When the final chunk is received (chunk counter reaches zero), the procedure closes the target resource, marks the upload as succeeded or failed, fires any registered callback trigger, and clears it. It is the core data-ingestion step within the WebUtil file-transfer upload sequence, invoked by WEBUTIL_CORE.CUSTOMEVENTHANDLER.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-019](#SP-019--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-020](#SP-020--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-021](#SP-021--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-035](#SP-035--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-067](#SP-067--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 parameter representing one chunk of the file being uploaded.
- Step 2 - Validate that uploadData is not NULL and not an empty string; if either condition is true, set the module-level flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the write destination by evaluating the module-level flag m_toDB.
- Step 4 (m_toDB = TRUE) - Delegate the chunk write to WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 5 (m_toDB = FALSE) - Attempt to write the chunk to the application-server file via JAVA_APPSERV_WRITER.WriteData. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_core.Error, and raise the READWRITE_ERROR exception.
- Step 6 - Decrement the module-level chunk counter m_chunks by 1.
- Step 7 - If m_chunks has reached zero (i.e., this was the last chunk), proceed to close the target resource.
- Step 8 (last chunk, m_toDB = TRUE) - Call WebUtil_DB_Local.CloseBlob passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error via WebUtil_DB_Local.getLastError, log it through WebUtil_core.Error, and leave m_uploadSucceeded as FALSE.
- Step 9 (last chunk, m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error code and arguments, log the error through WebUtil_core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 10 - After closing the resource, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1); if a non-null trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 11 - Call WEBUTIL.CLEARCALLBACKTRIGGER(-1) to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately without writing any data.

FALSE: Proceed to write the chunk to the designated destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk using WebUtil_DB_LOCAL.WriteData (database BLOB path).

FALSE: Write the chunk using JAVA_APPSERV_WRITER.WriteData (application-server file path).

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (write failure on the file path)

TRUE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks equals 0 after decrement (final chunk has been received)

TRUE: Proceed to close the target resource (BLOB or file) and handle post-upload completion logic.

FALSE: No further action for this invocation; await subsequent chunks.

---

DP-005

Condition: On final chunk, m_toDB is TRUE

TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob(m_fileSize).

FALSE: Close the server file via JAVA_APPSERV_WRITER.CloseFile(m_persistObj, m_fileSize).

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob returns TRUE (BLOB close succeeded)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the error via WebUtil_DB_Local.getLastError, log it through WebUtil_core.Error, and leave m_uploadSucceeded as FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns TRUE (file close succeeded)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An empty or NULL data chunk is treated as an error condition; m_uploadSucceeded is set to FALSE and no write operation is attempted, preventing partial or corrupt data from being persisted.
- BR-002 - Every chunk must be written to exactly one destination: either the database BLOB path (when m_toDB is TRUE) or the application-server file path (when m_toDB is FALSE); the two paths are mutually exclusive within a single upload session.
- BR-003 - A write failure on the application-server file path is a terminal error for that chunk; the procedure logs the error using the error code and arguments retrieved from the writer and raises READWRITE_ERROR, aborting further processing.
- BR-004 - The upload session tracks remaining chunks via the counter m_chunks; the counter is decremented by exactly 1 per successful chunk write, ensuring the close-and-finalize logic executes only when all expected chunks have been received.
- BR-005 - Resource closure (BLOB or file) is performed only after the last chunk has been processed (m_chunks = 0), guaranteeing that the target resource is not closed prematurely while data is still in transit.
- BR-006 - A successful resource close is the definitive condition for setting m_uploadSucceeded to TRUE; a failed close prevents the upload from being marked as succeeded and triggers error logging.
- BR-007 - On a file-close failure in the application-server path, the Java global reference m_persistObj must be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR, preventing resource leaks.
- BR-008 - After the final chunk is processed and the resource is closed, any registered callback trigger (identified by WEBUTIL.GETCALLBACKTRIGGER(-1)) must be fired before it is cleared, ensuring downstream processes are notified of upload completion.
- BR-009 - WEBUTIL.CLEARCALLBACKTRIGGER(-1) is always called after the final-chunk close sequence, regardless of whether a callback trigger was registered or executed, ensuring no stale trigger reference persists for subsequent operations.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-064 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a PL/SQL wrapper that delegates to the Java Virtual Machine via the JNI bridge to set a named JVM system property to a specified value. The function accepts a property key and its new value, invokes the standard Java method java.lang.System.setProperty, and returns the previous value of the property as a VARCHAR2 string. It is called by WEBUTIL_CORE.CUSTOMEVENTHANDLER to manipulate runtime JVM system properties from within Oracle Forms.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Allocate a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2) and storing the handle in the module-level variable args.
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the new property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully-qualified class name 'java/lang/System', the method name 'setProperty', and the JNI method descriptor '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'.
- Step 6 - Return the VARCHAR2 result from JNI.CALL_STRING_METHOD, which represents the previous value of the named system property (or NULL if the property was not previously set).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally and returns the result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly two arguments must be supplied (property key and new value); the JNI argument list is created with a fixed capacity of 2, so both a0 and a1 are mandatory for correct JNI invocation.
- BR-002 - The target Java method is always the static method java.lang.System.setProperty; no alternative class or method may be substituted by callers of this wrapper.
- BR-003 - The function returns the previous value of the system property as reported by the JVM; callers must handle a NULL return, which indicates the property had no prior value.
- BR-004 - Property mutation is performed at the JVM level and is therefore global to the running Forms session; callers are responsible for ensuring that overwriting a system property does not adversely affect other JVM-dependent components.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-065 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil Java Beans. When called with show = TRUE, the procedure navigates focus to the dummy bean item inside the hidden window and displays it; when called with show = FALSE, it restores focus to the previously active item and hides the window. The procedure is guard-railed to execute only when the form is in NORMAL mode, preventing interference during Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the hidden window handle by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store it in the local variable hWin.
- Step 2 - Check whether the form system mode (SYSTEM.MODE) is 'NORMAL'. If the form is in any other mode (e.g., Enter Query), all subsequent processing is skipped entirely (Bug 2955789 guard).
- Step 3 - Validate that hWin is a real window object by calling ID_NULL (SP-047). If the window handle is null, all subsequent processing is skipped.
- Step 4 - Evaluate the input parameter show to determine the direction of the visibility change.
- Step 5 (show = TRUE) - Capture the current cursor item by reading SYSTEM.CURSOR_ITEM via NAME_IN and store the resolved item handle in the module-level variable m_infoFrom for later restoration.
- Step 6 (show = TRUE) - Set the hidden window title to 'WebUtil ' concatenated with WEBUTIL_VERSION using SET_WINDOW_PROPERTY.
- Step 7 (show = TRUE) - Display the hidden window by calling SHOW_WINDOW(hWin), then navigate form focus to WEBUTIL_DUMMY_ITEM via GO_ITEM so that the Java Bean can receive events.
- Step 8 (show = FALSE) - Check whether m_infoFrom holds a valid item handle using ID_NULL (SP-047). If valid, restore form focus to that item via GO_ITEM.
- Step 9 (show = FALSE) - Hide the window by calling HIDE_WINDOW(hWin), removing the WebUtil bean window from the user's view.

---
**Decision Points**

DP-001

Condition:
NAME_IN('SYSTEM.MODE') = 'NORMAL'

TRUE:
Proceed to evaluate the window handle and perform show/hide logic.

FALSE:
Exit the procedure immediately without making any changes; protects against execution during Enter Query Mode (Bug 2955789).

---

DP-002

Condition:
ID_NULL(hWin) is FALSE (i.e., the WEBUTIL_HIDDEN_WINDOW handle is valid)

TRUE:
Proceed to evaluate the show parameter and perform the appropriate visibility action.

FALSE:
Skip all visibility logic; the hidden window does not exist so no action can be taken.

---

DP-003

Condition:
show = TRUE

TRUE:
Capture the current cursor item into m_infoFrom, set the window title, display the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE:
Attempt to restore focus to m_infoFrom (subject to DP-004), then hide the window.

---

DP-004

Condition:
ID_NULL(m_infoFrom) is FALSE (i.e., a prior cursor item was captured and is still valid)

TRUE:
Navigate form focus back to m_infoFrom before hiding the window.

FALSE:
Skip the GO_ITEM call; no restorable item is available. Proceed directly to HIDE_WINDOW.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus manipulation when the form is in Enter Query Mode; SYSTEM.MODE must equal 'NORMAL' before any action is taken (Bug 2955789).
- BR-002 - The hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) must resolve to a non-null handle via ID_NULL (SP-047) before any show or hide operation is attempted; a null handle causes the procedure to exit silently.
- BR-003 - When showing the WebUtil bean window, the currently active form item (SYSTEM.CURSOR_ITEM) must be captured and stored in m_infoFrom prior to navigating away, ensuring focus can be correctly restored when the window is subsequently hidden.
- BR-004 - The hidden window title must be set to 'WebUtil ' concatenated with WEBUTIL_VERSION each time the window is shown, keeping the displayed version label current.
- BR-005 - Form focus must be explicitly moved to WEBUTIL_DUMMY_ITEM after the window is shown, so that the hosted Java Bean is able to receive form events.
- BR-006 - Focus restoration on hide is conditional: GO_ITEM is called on m_infoFrom only if ID_NULL(SP-047) confirms that m_infoFrom holds a valid item handle, preventing a runtime error from navigating to a null item.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-066 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-side URL to the client machine by delegating the download operation to WEBUTIL.DOWNLOADFROMURL (SP-022). It is invoked during Excel report generation to deliver the generated report file to the end user's local file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the three input parameters: the server-side source URL (sourceURL), the target path on the client machine (clientDestination), and the expected file size in bytes (fileSize, defaulting to 0 if not supplied).
- Step 2 - Delegate the download operation by calling WEBUTIL.DOWNLOADFROMURL (SP-022) with all three parameters passed through unchanged.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURL to the caller, indicating whether the file transfer succeeded or failed.

---
**Decision Points**

No conditional decision points exist in this procedure. All branching logic is encapsulated within the delegated call to WEBUTIL.DOWNLOADFROMURL (SP-022); this function acts solely as a pass-through wrapper.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must forward the sourceURL, clientDestination, and fileSize values to WEBUTIL.DOWNLOADFROMURL (SP-022) without modification; no transformation or validation of input parameters is performed at this layer.
- BR-002 - The fileSize parameter defaults to 0 when not explicitly provided by the caller, allowing invocation sites to omit it when the file size is unknown.
- BR-003 - The success or failure of the file transfer is determined entirely by WEBUTIL.DOWNLOADFROMURL (SP-022); this function returns that result directly to the caller without further processing.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-067 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a string data payload to a server-side file by invoking the Java method WriteData on the AppServerFileWriter class via the Oracle Forms JNI bridge. This procedure acts as a PL/SQL wrapper that passes the supplied string argument to the underlying Java file-writer object, enabling server-side file content to be written incrementally as part of a file transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string data payload (a0) to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java WriteData method on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result produced by the Java method, indicating whether the write operation succeeded (TRUE) or failed (FALSE).

---
**Decision Points**

DP-001

Condition: JNI.CALL_BOOLEAN_METHOD returns TRUE or FALSE after executing the Java WriteData method on the AppServerFileWriter object.

TRUE: The data string was successfully written to the server-side file; the function returns TRUE to the caller (WEBUTIL.SETDATA).

FALSE: The Java write operation did not succeed; the function returns FALSE to the caller (WEBUTIL.SETDATA), signalling a write failure.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The obj parameter must be a valid, pre-initialised ORA_JAVA.JOBJECT reference to an AppServerFileWriter instance; no object creation or validation is performed within this function.
- BR-002 - Exactly one string argument is accepted per invocation; the JNI argument list is explicitly created with a capacity of one, preventing additional arguments from being passed.
- BR-003 - The function returns a Boolean result directly derived from the Java layer; no additional transformation or error-handling is applied at the PL/SQL level.
- BR-004 - This function is intended to be called exclusively from WEBUTIL.SETDATA and must not be invoked independently outside that controlled invocation context.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-068 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil Java bean on the client side. When a WHEN-CUSTOM-ITEM-EVENT trigger fires in pi_veh_hold_up_fmb, this procedure receives the event name and its serialised parameters, validates the event against a known whitelist, extracts the data payload and multipart chunk metadata, and routes execution to the appropriate WebUtil handler (logging, error reporting, bean registration, host-command callback, or file-transfer completion).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-024](#SP-024--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-037](#SP-037--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-059](#SP-059--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-063](#SP-063--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-064](#SP-064--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming event name (EventName) and its serialised parameter string (EventParameters).
- Step 2 - Validate EventName against the permitted whitelist: WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, and WUT_TRANSFER_EVENT. If the event name is not in this list, raise the local 'unhandled' exception, which is silently swallowed, and exit the procedure.
- Step 3 - Extract the primary data payload by calling get_parameter_attr for the WUC_DATA attribute from EventParameters, storing the result in dataPayload.
- Step 4 - Extract the multipart chunk descriptor by calling get_parameter_attr for the WUC_DATA_MULTIPART attribute, storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber) and the total number of chunks required to form the complete payload (PayloadChunks).
- Step 6 - Route to the appropriate handler based on EventName:
  - WUC_LOG_EVENT: call WEBUTIL.LOG (via WebUtil_Core.log) with dataPayload and the non-error flag (false).
  - WUC_ERROR_EVENT: call WEBUTIL.LOG (via WebUtil_Core.log) with dataPayload and the error flag (true).
  - WUC_REGISTER: call WEBUTIL.REGISTERBEAN (via registerBean) passing dataPayload to register the bean.
  - WUH_CALLBACK_EVENT: convert dataPayload to a number and store it in m_lastCallback; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is populated, execute the corresponding trigger stored in m_callbacks; if m_lastCallback is null, call WEBUTIL.LOG to record that no callback trigger was specified.
  - WUT_TRANSFER_EVENT: call WEBUTIL.SETDATA (via WebUtil_File_Transfer.setData) with dataPayload to store the transferred file data, then call WEBUTIL.SETPROPERTY (via WebUtil_Core.setProperty) to mark the WUT_TRANSFER_EVENT property as 'RECEIVED'.
- Step 7 - Any exception other than 'unhandled' is re-raised to the caller.

---
**Decision Points**

DP-001

Condition: EventName is contained in the whitelist ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the local 'unhandled' exception; the exception handler silently suppresses it and the procedure exits without further action.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to false (informational log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to true (error log entry).

FALSE: Evaluate subsequent event-name conditions.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN passing dataPayload to register the client-side bean.

FALSE: Evaluate subsequent event-name conditions.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number and assign it to m_lastCallback; evaluate DP-006 and DP-007.

FALSE: Evaluate the WUT_TRANSFER_EVENT condition.

---

DP-006

Condition: Conversion of dataPayload to a number raises INVALID_NUMBER during the WUH_CALLBACK_EVENT branch.

TRUE: Call WEBUTIL.ERROR with package constant WUC_PACKAGE and error code 408, identifying the source as 'WEBUTIL_CORE.CustomEventHandler'.

FALSE: Assign the numeric value to m_lastCallback and proceed to DP-007.

---

DP-007

Condition: m_lastCallback IS NOT NULL after successful numeric conversion.

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback) to fulfil the host-command callback.

FALSE: Call WEBUTIL.LOG to record that no callback trigger was specified for the host command.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to set the WUT_TRANSFER_EVENT property to 'RECEIVED'.

FALSE: No further routing actions are taken (end of event-dispatch chain).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only events explicitly listed in the whitelist (WUC_LOG_EVENT, WUC_ERROR_EVENT, WUC_REGISTER, WUH_CALLBACK_EVENT, WUT_TRANSFER_EVENT) are processed; any unrecognised event name is silently ignored without raising an error to the caller (Bug 2839033 compliance).
- BR-002 - Every inbound event must carry a WUC_DATA attribute and a WUC_DATA_MULTIPART attribute within EventParameters; both are extracted unconditionally before event-specific routing begins.
- BR-003 - The multipart descriptor (WUC_DATA_MULTIPART) must be formatted as 'chunkNumber/PayloadChunks' (slash-delimited); the procedure uses this to determine the current chunk sequence and total chunk count.
- BR-004 - For WUH_CALLBACK_EVENT, the data payload must be convertible to a valid integer index into the m_callbacks collection; an INVALID_NUMBER condition is treated as a handled error (code 408) rather than a fatal exception.
- BR-005 - A WUH_CALLBACK_EVENT with a null or unconvertible callback index must not silently succeed; the procedure logs a warning via WEBUTIL.LOG when no callback trigger can be resolved.
- BR-006 - Completion of a WUT_TRANSFER_EVENT must be acknowledged by setting the WUT_TRANSFER_EVENT property to 'RECEIVED' via WEBUTIL.SETPROPERTY immediately after the data is stored via WEBUTIL.SETDATA.
- BR-007 - Any exception that is not the locally defined 'unhandled' exception is re-raised, ensuring unexpected runtime errors propagate to the calling trigger for proper error handling.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-069 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a module-level error flag and composing a standardised error message that combines the calling function name with the supplied error text. The composed message is immediately forwarded to the debug logging facility (DEBUGLOG) so that error details are captured in the debug trace for diagnostic purposes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the error description text (SetErrorText) as input parameters.
- Step 2 - Set the module-level boolean flag ERROR_ENCOUNTERED to TRUE, signalling that at least one error has occurred in the current execution context.
- Step 3 - Compose the ERROR_STACK message by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess to prevent overflow.
- Step 4 - Invoke DEBUGLOG (SP-073) at debug level 99, identifying the source as 'Add_Error', and passing the composed ERROR_STACK message for persistent debug trace logging.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The ERROR_ENCOUNTERED flag must be set to TRUE on every call, ensuring that any upstream logic checking this flag is correctly informed that an error condition exists.
- BR-002 - The error message stored in ERROR_STACK must follow the format '<CallingFunction>: <ErrorText>', providing unambiguous attribution of the error to its originating routine.
- BR-003 - The error text component of ERROR_STACK is capped at 1,968 characters (via SUBSTR) to prevent value errors caused by oversized string assignment.
- BR-004 - Every recorded error must be forwarded to DEBUGLOG at severity level 99, guaranteeing that all error events are captured in the debug trace regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-070 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single text buffer for upstream display or logging. The function first drains the Oracle Forms tool_err error stack, appending each message to a running string; if no tool_err entries exist it falls back to the current SQL error message (SQLERRM). The resulting buffer is returned to the caller for further processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local counter (iCounter) and an empty varchar2 buffer (vcErrBuff, max 1968 characters) to accumulate error text.
- Step 2 - Check whether the tool_err error stack contains one or more entries (tool_err.nerrors > 0).
- Step 3 - If errors exist, iterate over each entry on the stack (1 to tool_err.nerrors). For each iteration, append a newline character followed by the current tool_err message to vcErrBuff. If appending would exceed the 1968-character buffer limit (VALUE_ERROR), exit the loop immediately to prevent overflow.
- Step 4 - After appending each message, pop it from the tool_err stack (tool_err.pop) to advance to the next entry.
- Step 5 - If the tool_err stack is empty but SQLERRM is not null, append a newline followed by the SQLERRM text to vcErrBuff as a fallback error source.
- Step 6 - Return vcErrBuff (which may be an empty string if neither error source contained data) to the calling routine.

---
**Decision Points**

DP-001

Condition:
tool_err.nerrors > 0 (the tool_err stack holds at least one error entry)

TRUE:
Enter the loop to iterate over all tool_err stack entries, appending each message to vcErrBuff and popping each entry after it is read.

FALSE:
Skip the loop and evaluate the SQLERRM fallback (DP-002).

---

DP-002

Condition:
SQLERRM is not null (evaluated only when tool_err.nerrors = 0)

TRUE:
Append a newline and the SQLERRM text to vcErrBuff as the sole error message.

FALSE:
Leave vcErrBuff unchanged; the function will return an empty/null string.

---

DP-003

Condition:
A VALUE_ERROR exception is raised during string concatenation inside the loop (vcErrBuff would exceed 1968 characters)

TRUE:
Exit the loop immediately, discarding any remaining tool_err entries, to prevent a buffer overflow.

FALSE:
Continue the loop normally, processing the next tool_err entry.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The accumulated error buffer must not exceed 1968 characters; any concatenation that would breach this limit causes immediate termination of error collection, and messages beyond the limit are silently discarded.
- BR-002 - The tool_err stack takes precedence over SQLERRM; SQLERRM is only consulted when the tool_err stack is empty (nerrors = 0).
- BR-003 - Each tool_err message must be popped from the stack after it is read, ensuring the stack is progressively consumed during the collection loop.
- BR-004 - Every appended error message is prefixed with a newline character (chr(10)) to ensure visual separation when the buffer is displayed or logged by the caller.
- BR-005 - The function always returns a value (empty string if no errors are present), guaranteeing a safe result for the caller regardless of error-stack state.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-071 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). This utility function is used by multiple D2KWUTIL stored procedures that require a character representation of a boolean result, enabling boolean state to be passed or displayed where a character type is expected.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean.
- Step 2 - Evaluate the value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition:
ThisBoolean IS TRUE

TRUE:
Return the VARCHAR2 string 'TRUE' to the caller.

FALSE:
Return the VARCHAR2 string 'FALSE' to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; every possible boolean input maps to either 'TRUE' or 'FALSE'.
- BR-002 - The returned string values are fixed literals: 'TRUE' for a TRUE boolean input and 'FALSE' for any non-TRUE boolean input.
- BR-003 - The function has no dependencies on other internal routines or database objects; its output is derived solely from the supplied input parameter.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-072 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error-tracking state by clearing the error flag and discarding any accumulated error messages. It is called by multiple D2KWUTIL utility procedures before they begin their own processing to ensure no residual error information from a prior operation is carried forward.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any error messages accumulated during previous processing.
- Step 3 - Return control to the calling procedure with a clean error state.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, regardless of its prior value, to prevent stale error flags from affecting subsequent utility operations.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring that error messages from a previous call do not persist into the next operation.
- BR-003 - The procedure accepts no input parameters and produces no output parameters; its sole effect is the unconditional reset of shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-073 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel on behalf of any calling procedure within D2kwutil.pld. It guards against unnecessary work by checking the global debug state, pause flag, and caller-supplied severity level before constructing a timestamped, padded log string. Output is routed either to a Windows debug viewer via WINDEBUG or to a flat file via TEXT_IO, with automatic fallback and recovery between the two channels managed through SETDEBUG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-079](#SP-079--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-082](#SP-082--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState) and pause flag (bDebugPaused); if debugging is disabled (iDebugState = 0) or paused, exit immediately without producing any output.
- Step 2 - Compare the caller-supplied DebugLevel against the active threshold (iDebugLevel); if DebugLevel exceeds the threshold, exit immediately (message is below current verbosity requirement).
- Step 3 - Optionally prepend a timestamp: if bDebugTimeStamp is TRUE, format SYSDATE as HH24:MI:SS and append '> ' to form vcDateStamp.
- Step 4 - Construct the formatted debug string (vcDebugString) by combining the zero-padded DebugLevel, the optional timestamp, the right-padded LoggingCall label (30 characters), and a truncated LogString so that the total does not exceed 2 000 characters.
- Step 5 - If iDebugState = 2 (Windows debugger mode), check DEBUG_API_ENABLED:
  - Step 5a - If the debug API is available, call WINDEBUG (win_api_debug.WinDebug) to write vcDebugString to the Windows debug viewer.
  - Step 5b - If the debug API is unavailable, call SETDEBUG to switch the channel to file-based logging (defaulting to 'd2kwutil.log'), log a channel-switch notice via recursive DEBUGLOG calls, re-log the original message, and set bDebugType2Required to TRUE to flag that a return to debugger mode is desired.
- Step 6 - If iDebugState ≠ 2 (file logging mode), check whether a prior fallback occurred (bDebugType2Required = TRUE) and the debug API has since become available:
  - Step 6a - If recovery is possible, call SETDEBUG to reinstate Windows debugger mode (iDebugState = 2), log a restoration notice via recursive DEBUGLOG calls, reset bDebugType2Required to FALSE, and re-log the original message.
  - Step 6b - Otherwise, open the target file in append mode using TEXT_IO.FOPEN, write vcDebugString with TEXT_IO.PUT_LINE, and close the file with TEXT_IO.FCLOSE.
- Step 7 - If any unhandled exception occurs during the above steps, set iDebugState to 0 to disable debugging silently, preventing diagnostic code from disrupting normal application processing.

---
**Decision Points**

DP-001

Condition:
iDebugState = 0 (debugging is globally disabled)

TRUE:
Procedure exits immediately; no message is written and no further logic executes.

FALSE:
Processing continues to DP-002.

---

DP-002

Condition:
bDebugPaused is TRUE (debug output is temporarily suspended)

TRUE:
Procedure exits immediately; no message is written.

FALSE:
Processing continues to DP-003.

---

DP-003

Condition:
DebugLevel > iDebugLevel (caller's message severity is below the active verbosity threshold)

TRUE:
Procedure exits immediately; message is suppressed as insufficiently significant.

FALSE:
Message qualifies for output; processing continues to DP-004.

---

DP-004

Condition:
bDebugTimeStamp is TRUE

TRUE:
A timestamp string formatted as HH24:MI:SS> is generated and included in vcDebugString.

FALSE:
No timestamp is prepended; vcDateStamp remains NULL.

---

DP-005

Condition:
iDebugState = 2 (Windows debugger output channel is active)

TRUE:
Processing routes to DP-006 to attempt Windows debug API output.

FALSE:
Processing routes to DP-007 to handle file-based output.

---

DP-006

Condition:
DEBUG_API_ENABLED is TRUE (the Windows debug API is currently loaded and callable)

TRUE:
WINDEBUG (win_api_debug.WinDebug) is called to write vcDebugString to the Windows debug viewer.

FALSE:
SETDEBUG is called to switch logging to file mode (defaulting to 'd2kwutil.log'); a channel-switch notice and the original message are written via recursive DEBUGLOG calls; bDebugType2Required is set to TRUE.

---

DP-007

Condition:
bDebugType2Required is TRUE AND DEBUG_API_ENABLED is TRUE (a prior fallback to file logging occurred and the Windows debug API is now available again)

TRUE:
SETDEBUG is called to reinstate Windows debugger mode (iDebugState = 2); a restoration notice and the original message are written via recursive DEBUGLOG calls; bDebugType2Required is reset to FALSE.

FALSE:
The log file (vcDebugFile) is opened in append mode, vcDebugString is written, and the file is closed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState = 0; no message may be written while the debug subsystem is globally disabled.
- BR-002 - Logging is suppressed entirely when bDebugPaused = TRUE; the pause flag provides a temporary hold without disabling the subsystem.
- BR-003 - A message is only written when its DebugLevel does not exceed the active threshold iDebugLevel; higher numeric values indicate lower priority and are filtered out.
- BR-004 - The formatted debug string must not exceed 2 000 characters; LogString is truncated to enforce this limit after the fixed prefix (level indicator, optional timestamp, and padded caller label) has been measured.
- BR-005 - The LoggingCall label is always right-padded to exactly 30 characters in the output string to ensure consistent column alignment across log entries.
- BR-006 - When iDebugState = 2 and the Windows debug API is unavailable, the system must automatically fall back to file-based logging via SETDEBUG rather than silently discarding the message or raising an error to the caller.
- BR-007 - The fallback file defaults to 'd2kwutil.log' when vcDebugFile is NULL, ensuring a log destination is always available during an API-unavailable fallback.
- BR-008 - Once the Windows debug API becomes available again after a fallback, SETDEBUG must be called to restore iDebugState = 2 before the pending message is written, ensuring the preferred output channel is reinstated promptly.
- BR-009 - Any unhandled exception within DEBUGLOG must be caught and resolved by setting iDebugState = 0; diagnostic routines must never propagate exceptions that could disrupt normal application execution.
- BR-010 - File writes are performed in append mode (TEXT_IO.FOPEN with 'A') and the file handle must be explicitly closed after each write to prevent resource leaks.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-074 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating the low-level DOS/Windows environment lookup to the D2KWUTIL library function D2KWUTIL_GETDOSENV. The function logs entry and exit details via DEBUGLOG, enforces API availability, and returns the resolved variable value as a VARCHAR2 string. If the variable cannot be resolved, it records an error and either raises NO_DATA_FOUND or returns NULL depending on the caller's preference.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the incoming arguments (VariableName and RaiseExceptions flag) by calling DEBUGLOG at debug level 99 with the procedure name and a formatted argument string; BOOLTOCHAR is used to convert the BOOLEAN RaiseExceptions value to a printable character for the log entry.
- Step 2 - Clear any pre-existing error state on the WIN_API error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the WIN_API subsystem is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external DLL function handle for D2KWUTIL_GETDOSENV by calling REGISTER_FUNCTION_CALL, supplying the function slot, function name, return type ('LONG'), and parameter type signature ('*CHAR,*CHAR,LONG').
- Step 6 - Prepare the lookup token by wrapping VariableName in percent signs (e.g. '%MY_VAR%') and initialise a 512-character output buffer padded with null characters.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV via the registered function handle, passing the formatted variable name token, the output buffer, and the buffer length (512). Capture the integer return code in iRC.
- Step 8 - Log the result by calling DEBUGLOG at debug level 99, recording the returned value length (iRC) and the resolved buffer content.
- Step 9 - Evaluate the outcome: if iRC equals 0 or the output buffer still equals the input token (indicating no substitution occurred), the variable was not found; call ADD_ERROR to record a descriptive message and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL.
- Step 10 - If the lookup succeeded, return the populated output buffer as the function result.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the standard NoAPI message then re-raise; for all other exceptions, call ADD_ERROR with the generic unhandled-error message concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to retrieve the environment variable value.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception; the exception handler will log the error via ADD_ERROR and re-raise.

---

DP-002

Condition:
The return code iRC equals 0 OR the output buffer content still equals the formatted input token (i.e. the environment variable was not resolved).

TRUE:
The variable lookup failed; call ADD_ERROR to record the failure message, then branch on DP-003.

FALSE:
The lookup succeeded; return the resolved buffer value to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE:
Raise NO_DATA_FOUND so the caller can handle the missing variable as an exception.

FALSE:
Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API subsystem must be enabled before any attempt is made to resolve an environment variable; if it is unavailable the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The environment variable name must be wrapped in percent signs when passed to D2KWUTIL.D2KWUTIL_GETDOSENV (e.g. '%VariableName%') to form the correct OS-level lookup token.
- BR-003 - The output buffer passed to D2KWUTIL.D2KWUTIL_GETDOSENV must be pre-allocated at exactly 512 characters, padded with null characters (CHR(0)), and its declared length (512) must be passed as the buffer-size argument.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_GETDOSENV, or an output buffer that is unchanged from the input token, is treated as a failed lookup and must be reported as an error via ADD_ERROR.
- BR-005 - The caller controls error-propagation behaviour: when RaiseExceptions is TRUE a failed lookup raises NO_DATA_FOUND; when FALSE the function returns NULL, allowing the caller to handle the absence of the variable gracefully.
- BR-006 - All entry arguments and all resolved results must be written to the debug log via DEBUGLOG (at level 99) to support runtime diagnostics; the BOOLEAN RaiseExceptions flag must be converted to a printable value using BOOLTOCHAR before logging.
- BR-007 - The error stack must be cleared via CLEAN_ERROR_STACK at the start of every invocation to prevent stale errors from a prior call from contaminating the current error context.
- BR-008 - All exceptions, including WIN_API.NOT_AVAILABLE and unhandled others, must be recorded through ADD_ERROR (and ADD_EXTERNAL_ERRORS for unknown errors) before being re-raised, ensuring the error context is always populated for the caller.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-075 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows temporary directory path by invoking the external Windows utility function D2KWUTIL_WINDIR via the D2KWUTIL package. The function returns the path as a VARCHAR2 string with any trailing directory separator stripped. It is designed to be called from within the file-chooser utility and supports optional exception raising to allow the caller to control error-handling behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry point and the value of the RaiseExceptions input parameter using DEBUGLOG (Win_API_Debug.DebugLog at verbosity level 99).
- Step 2 - Clear any previously stacked errors by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Win_API subsystem is available (API_ENABLED flag). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for the Windows temp-directory retrieval using REGISTER_FUNCTION_CALL, binding the function handle iTmpDir to the signature 'd2kwutil_TmpDir' with parameter types 'INT','*CHAR,INT'.
- Step 6 - Initialise the output buffer vcBuff1 as a 512-character space-padded, null-terminated string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and the buffer length (512). Capture the integer return code in iRC.
- Step 8 - Log the result, including the return code and the raw buffer value, using DEBUGLOG.
- Step 9 - Evaluate iRC. If iRC = 0 (no value returned), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), return the temp directory path after stripping any trailing directory separator using STRIPDIRSEP.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging via ADD_ERROR then re-raising; handle all other exceptions by logging a combined error message via ADD_ERROR and ADD_EXTERNAL_ERRORS then re-raising.

---
**Decision Points**

DP-001

Condition:
Win_API.API_ENABLED is TRUE.

TRUE:
Register the external function, allocate the output buffer, call D2KWUTIL.D2KWUTIL_WINDIR, and log the result.

FALSE:
Raise WIN_API.NOT_AVAILABLE, bypassing the external call entirely.

---

DP-002

Condition:
The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR equals 0.

TRUE:
No directory value was returned; log the error via ADD_ERROR and proceed to DP-003.

FALSE:
A valid path was returned; strip the trailing directory separator via STRIPDIRSEP and return the resulting string to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND so the caller can handle the absence of a temp directory path.

FALSE:
Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the Windows temp-directory lookup when the Win_API subsystem is active (API_ENABLED = TRUE); if the subsystem is unavailable the WIN_API.NOT_AVAILABLE exception is raised unconditionally and the error is recorded via ADD_ERROR.
- BR-002 - The external function must be formally registered via REGISTER_FUNCTION_CALL with the exact signature ('d2kwutil_TmpDir', 'INT', '*CHAR,INT') before D2KWUTIL.D2KWUTIL_WINDIR is invoked; the registered function handle iTmpDir is passed to the call.
- BR-003 - The output buffer passed to D2KWUTIL.D2KWUTIL_WINDIR must be pre-allocated as a 512-character null-terminated string (RPAD of spaces with CHR(0)); the same length constant (512) is passed as the buffer-size argument.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition (no value returned); the error is logged and the function either raises NO_DATA_FOUND or returns NULL depending on the RaiseExceptions flag.
- BR-005 - The caller controls exception propagation: passing RaiseExceptions = TRUE causes the function to raise NO_DATA_FOUND on failure, while FALSE causes a silent NULL return, enabling flexible integration by the invoking routine.
- BR-006 - The returned directory path is always normalised by STRIPDIRSEP before being handed back to the caller, ensuring a consistent path format without a trailing directory separator.
- BR-007 - All entry and exit points are traced via DEBUGLOG at verbosity level 99, recording both the input parameter value (formatted by BOOLTOCHAR) and the raw output buffer together with the return code, to support diagnostic analysis.
- BR-008 - Any unexpected exception is caught, enriched with external error detail via ADD_EXTERNAL_ERRORS, recorded via ADD_ERROR, and then re-raised, ensuring no error is silently swallowed.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-076 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows system directory path for the current client workstation by invoking the native D2KWUTIL library function D2KWUTIL_WINDIR. The result is normalised by stripping any trailing directory separator before being returned to the caller. The procedure supports controlled error propagation via the RaiseExceptions flag, allowing callers to choose between a NULL return value or a raised exception when the directory path cannot be obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (level 99) with the procedure name and the string representation of the RaiseExceptions argument, produced via BOOLTOCHAR.
- Step 2 - Clear any previously recorded errors from the shared error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the WIN_API integration layer is available (API_ENABLED flag).
- Step 5 - If the API is available, register the external function handle for 'd2kwutil_WinDir' with signature 'INT' / '*CHAR,INT' by calling REGISTER_FUNCTION_CALL.
- Step 6 - Initialise a 512-character output buffer (vcBuff1) padded with null characters.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR via the registered function handle, passing the output buffer and its declared length (512); capture the integer return code in iRC.
- Step 8 - Log the outcome by calling DEBUGLOG (level 99) with the return code and the raw buffer contents.
- Step 9 - Evaluate iRC: if zero, record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), return the Windows directory path after normalising it through STRIPDIRSEP to remove any trailing directory separator.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging via ADD_ERROR then re-raising; handle all other exceptions by logging a combined error message using ADD_ERROR and ADD_EXTERNAL_ERRORS then re-raising.

---
**Decision Points**

DP-001

Condition:
Win_API.API_ENABLED is TRUE at the point of invocation.

TRUE:
Register the external function handle for D2KWUTIL_WINDIR, allocate the output buffer, invoke D2KWUTIL.D2KWUTIL_WINDIR, and log the result.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC (the integer return code from D2KWUTIL.D2KWUTIL_WINDIR) equals 0.

TRUE:
No directory value was returned; record an error via ADD_ERROR and proceed to DP-003 to determine how to surface the failure.

FALSE:
A valid path was returned; normalise it with STRIPDIRSEP and return it to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE:
Raise the NO_DATA_FOUND exception, which is immediately re-raised by the exception handler.

FALSE:
Return NULL to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must log its input arguments (including the boolean RaiseExceptions flag converted to a character representation via BOOLTOCHAR) and its output via DEBUGLOG at severity level 99 before and after the external call, supporting runtime diagnostics.
- BR-002 - The error stack must be cleared via CLEAN_ERROR_STACK at the start of every invocation to prevent stale errors from prior calls from contaminating the current result.
- BR-003 - The external Windows directory function (D2KWUTIL.D2KWUTIL_WINDIR) must be accessed only through a registered function handle obtained via REGISTER_FUNCTION_CALL; direct invocation without registration is not permitted.
- BR-004 - If the WIN_API integration layer is unavailable (API_ENABLED is FALSE), the procedure must not attempt the external call; it must raise WIN_API.NOT_AVAILABLE and record the failure via ADD_ERROR.
- BR-005 - A return code of zero from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition (no value returned) and must be recorded as an error via ADD_ERROR regardless of the RaiseExceptions setting.
- BR-006 - The caller controls exception propagation behaviour: setting RaiseExceptions to TRUE causes the procedure to raise NO_DATA_FOUND on failure; setting it to FALSE (the default) causes the procedure to return NULL, allowing the caller to handle the absence of a value gracefully.
- BR-007 - The returned Windows directory path must always be normalised by STRIPDIRSEP to remove any trailing directory separator before being passed to the caller, ensuring consistent path formatting.
- BR-008 - All unhandled exceptions must be captured, enriched with external error detail via ADD_EXTERNAL_ERRORS, recorded via ADD_ERROR, and re-raised so that no exception is silently swallowed.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-077 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named value from the Windows Registry and returns it as a VARCHAR2 string. Given a full registry path (including hive root) and an entry name, the function resolves the correct hive constant, delegates the native read to D2KWUTIL.D2KWUTIL_GETREGKEY, and returns the retrieved value. Diagnostic progress is written via DEBUGLOG throughout execution. If the API is unavailable, the registry path is invalid, or the read fails, errors are recorded via ADD_ERROR and ADD_EXTERNAL_ERRORS; the caller controls whether failures raise exceptions or return NULL through the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the RegPath, RegEntry, and the string representation of RaiseExceptions (obtained via BOOLTOCHAR) so that all input arguments are traceable.
- Step 2 - Reset the error stack by calling CLEAN_ERROR_STACK, then initialise the return-code variable iRC to 0.
- Step 3 - Check whether the Windows API layer is enabled (WIN_API.API_ENABLED). If not enabled, raise WIN_API.NOT_AVAILABLE immediately.
- Step 4 - Register the external function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL, supplying the function name and its parameter-type signature.
- Step 5 - Parse the hive root from RegPath by extracting the substring before the first backslash and converting it to upper-case. Map the root name to its numeric constant: HKEY_LOCAL_MACHINE->0, HKEY_CLASSES_ROOT->1, HKEY_CURRENT_USER->2, HKEY_USERS->3, HKEY_CURRENT_CONFIG->4. If the root is unrecognised, record an error via ADD_ERROR and, when RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call buffers: set the sub-path (vcBuff1) to the portion of RegPath after the first backslash, set the entry name (vcBuff2) to RegEntry, initialise the 2000-byte output buffer (vcBuff3) padded with CHR(0), and set the buffer-length indicator iBuff2 to 2000.
- Step 7 - Evaluate the compatibility flag WIN_API.COMPAT_EXPAND_REG_VALUES. If expansion is suppressed, set iBuff3 to 1 and log a compatibility diagnostic via DEBUGLOG; otherwise set iBuff3 to 0.
- Step 8 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the resolved function handle, hive constant, sub-path, entry name, output buffer, buffer length, and expansion flag. Capture the integer return code in iRC.
- Step 9 - Log the result via DEBUGLOG, recording iRC and the content of vcBuff3.
- Step 10 - Evaluate iRC for error conditions (-1 entry not found, -2 unsupported data type, -3 value exceeds buffer, -4 environment-string expansion failure). For each error code, record a descriptive message via ADD_ERROR; return NULL if RaiseExceptions is FALSE, or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) if RaiseExceptions is TRUE.
- Step 11 - If iRC indicates success, return vcBuff3 (the registry value string) to the caller.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, log the no-API message via ADD_ERROR then re-raise; for all other exceptions, log via ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Continue with function-handle registration, hive parsing, and the registry read.

FALSE:
Raise WIN_API.NOT_AVAILABLE; execution transfers to the exception handler.

---

DP-002

Condition:
The upper-cased hive root extracted from RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).

TRUE:
Assign the corresponding numeric constant (0-4) to iBuff1 and proceed.

FALSE:
Record an invalid-key error via ADD_ERROR; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (function will likely return NULL via a subsequent iRC error).

---

DP-003

Condition:
WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE (expansion is permitted).

TRUE:
Set iBuff3 to 0 (allow D2KWUTIL_GETREGKEY to expand environment strings in the value).

FALSE:
Set iBuff3 to 1 (suppress expansion) and log a compatibility diagnostic via DEBUGLOG.

---

DP-004

Condition:
D2KWUTIL.D2KWUTIL_GETREGKEY returns iRC = -1 (registry entry not found).

TRUE:
Record an error via ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.

FALSE:
Evaluate subsequent iRC values (DP-005 through DP-007).

---

DP-005

Condition:
D2KWUTIL.D2KWUTIL_GETREGKEY returns iRC = -2 (unsupported registry data type).

TRUE:
Record an unsupported-datatype error via ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.

FALSE:
Evaluate subsequent iRC values (DP-006 through DP-007).

---

DP-006

Condition:
D2KWUTIL.D2KWUTIL_GETREGKEY returns iRC = -3 (value exceeds the 2000-byte buffer).

TRUE:
Record a buffer-overflow error via ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise VALUE_ERROR if TRUE.

FALSE:
Evaluate subsequent iRC value (DP-007).

---

DP-007

Condition:
D2KWUTIL.D2KWUTIL_GETREGKEY returns iRC = -4 (environment-string expansion failure).

TRUE:
Record an expansion-failure error via ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if TRUE.

FALSE:
No error condition applies; return vcBuff3 to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute when the Windows API layer is active (WIN_API.API_ENABLED); if the layer is unavailable the function raises WIN_API.NOT_AVAILABLE unconditionally, regardless of the RaiseExceptions flag.
- BR-002 - The registry hive must be specified as the leading component of RegPath, delimited by a backslash. Only the five standard Windows hive names are accepted (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other value is treated as an invalid registry key.
- BR-003 - The output buffer for the registry value is fixed at 2000 bytes; values longer than this limit produce return code -3 and are not returned, regardless of the RaiseExceptions setting.
- BR-004 - Environment-string expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag. When the flag is FALSE, expansion is suppressed and the raw value is returned.
- BR-005 - The RaiseExceptions parameter governs error-propagation behaviour: when FALSE, all recoverable read failures (iRC -1, -2, -3, -4 and an unrecognised hive) result in a NULL return value; when TRUE, the same failures raise PL/SQL exceptions (NO_DATA_FOUND or VALUE_ERROR) to the caller.
- BR-006 - All errors, including API-unavailability, invalid hive, read failures, and unhandled exceptions, must be recorded via ADD_ERROR before the function returns or raises; unhandled exceptions additionally append external error detail via ADD_EXTERNAL_ERRORS.
- BR-007 - DEBUGLOG calls at severity 99 must bracket the operation: one call on entry (logging all input arguments, with the BOOLEAN RaiseExceptions converted to a character representation via BOOLTOCHAR), one call after the compatibility-suppression decision when suppression is active, and one call after the D2KWUTIL_GETREGKEY invocation recording the return code and retrieved value.
- BR-008 - The external function D2KWUTIL.D2KWUTIL_GETREGKEY must be registered via REGISTER_FUNCTION_CALL before each invocation; the registration supplies the function name and its full parameter-type signature.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-078 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a Windows API function exported from the D2KWUTIL DLL is correctly registered with Oracle FFI before it is called. The procedure verifies that the DLL is loaded, registers the function handle and its parameter/return types when the function has not yet been registered or when the DLL has been reloaded since the last registration, and raises a controlled NO_DATA_FOUND error if the DLL cannot be located or if FFI registration fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-002](#SP-002--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-012](#SP-012--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-060](#SP-060--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in the Oracle FFI library cache using ORA_FFI.FIND_LIBRARY. If the DLL is already loaded, execution continues to Step 3.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not yet loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD to load the DLL from the configured path. If this second attempt also raises an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record a 'DLL not found' message, and raise NO_DATA_FOUND to abort the caller.
- Step 3 - Compare the cached load-count for the supplied FunctionID (FunctionLoad array) against the current DLL_LOAD_COUNT. If the entry does not exist or the counts differ, the function must be (re-)registered; otherwise skip to Step 8.
- Step 4 - Register the function handle by calling ORA_FFI.REGISTER_FUNCTION against the DLL handle, using the supplied FunctionName and the C_STD calling convention, and store the result in FunctionHandle(FunctionID).
- Step 5 - If the function being registered is not the internal debug function ('d2kwutil_DebugString'), call DEBUGLOG (via Win_API_Debug.DebugLog at level 99) to record whether this is an initial registration or a re-registration, including the DLL load count.
- Step 6 - Parse the FunctionArgs string (comma-delimited) in a loop. For each argument fragment, call D2KWUTIL.TRANSLATETYPE to convert the string type token to its ORA_FFI constant, then call ORA_FFI.REGISTER_PARAMETER to bind that parameter type to the function handle. The loop terminates when the remaining argument string is NULL, a bare comma, or 'VOID,'.
- Step 7 - If FunctionReturn is not NULL and not 'VOID' (case-insensitive), call D2KWUTIL.TRANSLATETYPE on the return-type token and register it via ORA_FFI.REGISTER_RETURN against the function handle.
- Step 8 - Store the current DLL_LOAD_COUNT into FunctionLoad(FunctionID) to mark the function as registered for this DLL load cycle, preventing unnecessary re-registration on subsequent calls.
- Step 9 - If an ORA_FFI.FFI_ERROR is raised at any point during registration, call ADD_ERROR with the function name and the combined error text from ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to signal failure to the caller.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY raises ORA_FFI.FFI_ERROR (DLL not found in cache).

TRUE:
Call D2KWUTIL.ATTEMPT_DLL_LOAD to load the DLL. If that also fails with FFI_ERROR, set API_ENABLED = FALSE, call ADD_ERROR, and raise NO_DATA_FOUND.

FALSE:
DLL handle is obtained successfully; proceed to the registration check.

---

DP-002

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD raises ORA_FFI.FFI_ERROR (DLL cannot be loaded from disk).

TRUE:
Set API_ENABLED = FALSE, call ADD_ERROR with the DLL name, and raise NO_DATA_FOUND to abort.

FALSE:
(Not applicable; this branch is only entered when FIND_LIBRARY has already failed.)

---

DP-003

Condition:
FunctionLoad entry for FunctionID does not exist OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.

TRUE:
Proceed with full FFI registration: register function handle, parameters, and return type, then update FunctionLoad(FunctionID).

FALSE:
Function is already registered for the current DLL load cycle; skip registration entirely.

---

DP-004

Condition:
FunctionName equals 'd2kwutil_DebugString'.

TRUE:
Suppress the DEBUGLOG call to avoid recursive logging.

FALSE:
Call DEBUGLOG to record the registration event (initial or re-registration) with the function name and DLL load count.

---

DP-005

Condition:
FunctionLoad entry for FunctionID does not exist at the point of the DEBUGLOG call.

TRUE:
Log the event as an initial registration.

FALSE:
Log the event as a re-registration, including the previous load count.

---

DP-006

Condition:
The remaining vcArgs string is NULL, equals ',', or equals 'VOID,' during parameter-parsing loop.

TRUE:
Exit the parameter-registration loop; no further parameters to register.

FALSE:
Extract the next comma-delimited fragment, call D2KWUTIL.TRANSLATETYPE, and call ORA_FFI.REGISTER_PARAMETER.

---

DP-007

Condition:
After consuming a fragment, the comma position equals the total length of vcArgs (i.e., no remaining characters after the comma).

TRUE:
Set vcArgs to NULL to terminate the loop on the next iteration.

FALSE:
Advance vcArgs to the substring following the consumed comma and continue the loop.

---

DP-008

Condition:
UPPER(FunctionReturn) <> 'VOID' AND FunctionReturn IS NOT NULL.

TRUE:
Call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type via ORA_FFI.REGISTER_RETURN.

FALSE:
No return type is registered (procedure or void function).

---

DP-009

Condition:
ORA_FFI.FFI_ERROR is raised during the registration block (outer exception handler).

TRUE:
Call ADD_ERROR with the function name and the error text obtained from ADD_EXTERNAL_ERRORS; raise NO_DATA_FOUND.

FALSE:
No exception; procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or loadable via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; if neither succeeds, the API is disabled and the operation is aborted.
- BR-002 - A function is only (re-)registered with Oracle FFI if its cached DLL load count is absent or does not match the current DLL_LOAD_COUNT, ensuring that stale handles from a prior DLL load cycle are never used.
- BR-003 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG tracing during its own registration to prevent recursive logging.
- BR-004 - Function parameter types supplied as a comma-delimited string must be translated from string tokens to ORA_FFI type constants via D2KWUTIL.TRANSLATETYPE before being registered; raw string tokens are not passed directly to Oracle FFI.
- BR-005 - A return type is registered only when FunctionReturn is non-NULL and not equal to 'VOID' (case-insensitive); void or parameterless functions receive no return-type registration.
- BR-006 - The WEBUTIL.LENGTH dependency governs string-length evaluation within the parameter-parsing loop; the position of the final comma is compared against the total length of vcArgs to determine whether further argument fragments remain.
- BR-007 - On any FFI error during registration, ADD_EXTERNAL_ERRORS is used to retrieve supplementary error detail, which is combined with the function name and surfaced to the user via ADD_ERROR before the procedure raises NO_DATA_FOUND.
- BR-008 - Once registration succeeds, FunctionLoad(FunctionID) is updated to the current DLL_LOAD_COUNT, recording the registration state and preventing redundant re-registration on subsequent calls within the same DLL load cycle.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-079 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment for the application session by setting the debug output type (file or screen), target file path, verbosity level, and timestamp preference. Once configured, it activates or deactivates the logging state and records an initial diagnostic entry via DEBUGLOG to confirm the configuration applied.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Assign the incoming TimeStamp parameter to the package-level flag bDebugTimeStamp, controlling whether log entries will include timestamps.
- Step 2 - Assign the incoming DebugFile parameter to the package-level variable vcDebugFile, recording the target log file path for file-based logging.
- Step 3 - Assign the incoming DebugLevel parameter to the package-level variable iDebugLevel, setting the verbosity threshold for subsequent log calls.
- Step 4 - Evaluate the DebugType parameter to determine the logging mode to activate (see Decision Points).
- Step 5 - If DebugType = 1, set iDebugState to 1 (file logging) and invoke DEBUGLOG to record the message 'Logging to File' concatenated with the DebugFile value.
- Step 6 - If DebugType = 2, set iDebugState to 2 (screen/alternative logging) and invoke DEBUGLOG to record the message 'Logging Started'.
- Step 7 - If DebugType is any other value, invoke DEBUGLOG to record the message 'Logging Stopped' and then set iDebugState to 0, disabling logging.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and call DEBUGLOG with the confirmation message 'Logging to File' appended with the DebugFile path.

FALSE: Proceed to evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging mode) and call DEBUGLOG with the message 'Logging Started'.

FALSE: Call DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, deactivating all logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType must be supplied by the caller; a value of 1 activates file-based logging, a value of 2 activates screen/alternative logging, and any other value deactivates logging entirely.
- BR-002 - DebugFile defaults to NULL if not provided; it is stored as the target log file path and is only meaningful when DebugType = 1.
- BR-003 - DebugLevel defaults to 98 if not provided; it governs the verbosity threshold applied to all subsequent DEBUGLOG calls within the session.
- BR-004 - TimeStamp defaults to FALSE if not provided; when TRUE, log entries produced by DEBUGLOG will include a timestamp.
- BR-005 - The package-level state variables (bDebugTimeStamp, vcDebugFile, iDebugLevel, iDebugState) are always updated unconditionally before the logging mode branch is evaluated, ensuring configuration is fully applied regardless of the chosen mode.
- BR-006 - When logging is deactivated (DebugType not 1 or 2), DEBUGLOG is called with the 'Logging Stopped' message before iDebugState is set to 0, guaranteeing a final log entry is written while the prior state is still active.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-080 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw directory path string by removing any semicolon-delimited suffix and stripping a trailing backslash separator, returning a clean, normalised path value suitable for use in DLL loading and directory resolution operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw input path string (InPath) and assign it to a local working variable (vcPath).
- Step 2 - Search vcPath for the first occurrence of a semicolon character using INSTR.
- Step 3 - If a semicolon is found, truncate vcPath to retain only the characters before the semicolon, discarding any trailing entries (e.g. duplicate or alternate paths).
- Step 4 - Inspect the last character of the (potentially truncated) vcPath for a backslash ('\') directory separator.
- Step 5 - If a trailing backslash is present, remove it by taking the substring up to but not including the final character.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition:
INSTR(vcPath, ';') > 0 - the path string contains one or more semicolon characters.

TRUE:
Truncate vcPath to the substring preceding the first semicolon, effectively discarding any secondary path entries.

FALSE:
Leave vcPath unchanged and proceed to the trailing-separator check.

---

DP-002

Condition:
SUBSTR(vcPath, -1, 1) = '\' - the last character of vcPath is a backslash directory separator.

TRUE:
Strip the trailing backslash by reassigning vcPath to SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE:
Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path before the first semicolon is considered valid; any text from the semicolon onward is discarded to prevent multi-path strings from being used as a single directory reference.
- BR-002 - A directory path must not end with a backslash separator; if one is present it is removed to ensure consistent path formatting for downstream consumers (ATTEMPT_DLL_LOAD, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY).
- BR-003 - The function is non-destructive to the original parameter; all manipulation is performed on a local copy (vcPath), and the sanitised result is returned to the caller without side-effects.
- BR-004 - Path length is constrained to a maximum of 500 characters, consistent with the VARCHAR2(500) declaration of the internal working variable.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-081 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- pi_veh_hold_up_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Search Criteria (N/A / CN_MAIN)

---

**Purpose**

Generates and delivers a CSV/Excel report to the client workstation when a user presses the designated button on the Vehicle Hold-Up screen. The procedure determines the appropriate report-generation path based on whether a report server is configured for the given principal and application, either delegating CSV generation to a remote database procedure or building the file locally from a Forms record group, then transfers the completed file to the client and opens it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-027](#SP-027--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-028](#SP-028--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-030](#SP-030--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-043](#SP-043--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-046](#SP-046--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-055](#SP-055--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-066](#SP-066--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS to retrieve the report server (rep_server) associated with the supplied p_principal and p_app_id combination. If no matching row exists, set lv_rep_server to NULL and continue.
- Step 2 - Evaluate lv_rep_server to select one of two generation paths (see Decision Points).
- Step 3 (rep_server path) - Determine the output file name: if p_file_name is NULL, invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user; otherwise use p_file_name directly, then append '.csv' as the file extension.
- Step 4 (rep_server path) - Validate the resolved file name for embedded spaces. If spaces are found, redirect the path to 'C:\' using only the base file name and display an informational message to the user.
- Step 5 (rep_server path) - Call the remote procedure sp_csv_report_generate via database link dms1_db3_lnk, passing the file name and query string, to generate the CSV file on the server.
- Step 6 (rep_server path) - Use WEBUTIL.HOST to execute a shell command that moves the generated file from /utl_dir/ to /iashome/ias/reports/printer/.
- Step 7 (rep_server path) - Open the server-side text file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and read the base URL path with WEBUTIL.GET_LINE, then close the file with WEBUTIL.FCLOSE.
- Step 8 (rep_server path) - Construct the full server URL (formserverpath) by concatenating the retrieved URL path with the base file name.
- Step 9 (rep_server path) - Transfer the file from the form server to the client workstation using WEBUTIL.URL_TO_CLIENT. If the transfer fails, display a 'File Transfer failed' message and pause.
- Step 10 (rep_server path) - Launch the transferred file on the client using WEBUTIL.HOST with 'cmd /c'.
- Step 11 (no rep_server path) - Determine the output file name using the same logic as Step 3 (FILE_SAVE_DIALOG or p_file_name), and apply the same space-in-path validation as Step 4.
- Step 12 (no rep_server path) - Locate and delete any existing Forms record group named 'DataRecordSet' using WEBUTIL.ID_NULL to check existence before deletion.
- Step 13 (no rep_server path) - Create a new record group from the supplied p_query, populate it, and retrieve the total row count.
- Step 14 (no rep_server path) - Read the base URL from /reports/DMS/excelpath.txt using WEBUTIL.FOPEN, WEBUTIL.GET_LINE, and WEBUTIL.FCLOSE, then construct formserverpath.
- Step 15 (no rep_server path) - Open the server-side output file for writing using WEBUTIL.FOPEN, locate the target column in the record group, iterate over all rows, write each cell value followed by a newline using WEBUTIL.PUTF, then close the file with WEBUTIL.FCLOSE.
- Step 16 (no rep_server path) - Transfer the file to the client using WEBUTIL.URL_TO_CLIENT, display a failure message if unsuccessful, and open the file on the client using WEBUTIL.HOST.
- Step 17 - If any unhandled exception occurs at any point, display an error message combining ERROR_CODE and ERROR_TEXT, then raise FORM_TRIGGER_FAILURE to halt form processing.

---
**Decision Points**

DP-001

Condition:
lv_rep_server IS NOT NULL (a report server entry was found in EH_REPORTS for the given p_principal and p_app_id).

TRUE:
Use the remote-server generation path: invoke sp_csv_report_generate via database link, move the file via shell command, read the URL path file, transfer to client, and open the file.

FALSE:
Use the local Forms record-group generation path: build the CSV from a Forms record group populated by p_query, write it to the server file system, transfer to client, and open the file.

---

DP-002

Condition:
p_file_name IS NULL (no file name was supplied by the caller) - evaluated in both the rep_server and no-rep_server paths.

TRUE:
Invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user to specify a save location and file name.

FALSE:
Use p_file_name as the file name directly.

---

DP-003

Condition:
INSTR(FILENAME, ' ') > 0 - the resolved file name contains at least one space character in the path - evaluated in both generation paths.

TRUE:
Override the path to 'C:\' using only the base file name extracted from the last backslash, and display a message informing the user that the file will be stored on the C drive because the original path contains spaces.

FALSE:
Retain the resolved file name unchanged.

---

DP-004

Condition:
NOT Id_Null(rg_id) - a record group named 'DataRecordSet' already exists in the Forms session (no-rep_server path only).

TRUE:
Delete the existing record group before creating a new one from p_query.

FALSE:
Proceed directly to creating the record group from p_query.

---

DP-005

Condition:
file_transfer_bool is FALSE after WEBUTIL.URL_TO_CLIENT completes - evaluated in both generation paths.

TRUE:
Display a 'File Transfer failed' message and pause execution.

FALSE:
Continue to open the file on the client using WEBUTIL.HOST.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report generation method is determined by the presence of a rep_server value in EH_REPORTS for the combination of p_principal and p_app_id; if no record exists the procedure defaults to the local Forms record-group method without raising an error.
- BR-002 - The output file name is always suffixed with '.csv' in the rep_server path, regardless of any extension already present in p_file_name.
- BR-003 - File paths containing spaces are not permitted; if a space is detected the file is automatically redirected to the root of the C drive (C:\) using only the base file name, and the user is notified.
- BR-004 - In the no-rep_server path, any pre-existing Forms record group named 'DataRecordSet' must be destroyed before a new one is created to ensure the report reflects the current query.
- BR-005 - The server-side URL base path used to construct the download URL must be read at runtime from the configuration file /reports/DMS/excelpath.txt; it is not hard-coded.
- BR-006 - A failed client file transfer (WEBUTIL.URL_TO_CLIENT returning FALSE) must be communicated to the user with a 'File Transfer failed' message; processing is paused but the exception path is not triggered.
- BR-007 - Any unhandled exception must surface the Oracle ERROR_CODE and ERROR_TEXT to the user and raise FORM_TRIGGER_FAILURE to prevent silent failures.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-082 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output channel by delegating to the external D2KWUTIL debug-string function via the WIN_API framework. Given a text message, it registers the target external function call, invokes D2KWUTIL_DEBUGSTRING to emit the message, and raises a structured error if the WIN_API layer is unavailable or any other failure occurs. It is intended to be called from the DEBUGLOG routine in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer (vcBuff1).
- Step 2 - Check whether the WIN_API layer is active by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, call REGISTER_FUNCTION_CALL to register the external function handle iDebugString, binding it to the 'd2kwutil_DebugString' entry point with a character (*CHAR) argument signature.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the registered function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer (vcBuff1), to emit the debug string through the external utility.
- Step 5 - If WIN_API.API_ENABLED is FALSE, raise the WIN_API.NOT_AVAILABLE exception to signal that the API layer is not accessible.
- Step 6 - In the NOT_AVAILABLE exception handler, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR with the procedure name 'WinDebug', WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS to capture any additional external error detail, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL and emit the debug string via D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: Raise WIN_API.NOT_AVAILABLE to indicate the WIN_API layer is not accessible.

---

DP-002

Condition: The WIN_API.NOT_AVAILABLE exception is raised (either explicitly from DP-001 FALSE branch or propagated from a called routine).

TRUE: Call ADD_ERROR with 'WinDebug' and WIN_API.NoAPI to log the unavailability error, then re-raise.

FALSE: Exception is not NOT_AVAILABLE; fall through to the OTHERS handler.

---

DP-003

Condition: An unclassified (OTHERS) exception is raised during execution.

TRUE: Call ADD_ERROR with 'WinDebug' and WIN_API.UError concatenated with ADD_EXTERNAL_ERRORS to log the error with any external error detail, then re-raise.

FALSE: No exception raised; procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API layer must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to emit a debug string; execution is not permitted when the API is unavailable.
- BR-002 - The input text must be augmented with a newline character (CHR(10)) before being passed to the external debug-string function, ensuring correct line termination in debug output.
- BR-003 - The external function entry point 'd2kwutil_DebugString' must be registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING is invoked, so that the correct function handle is resolved at runtime.
- BR-004 - All exceptions must be re-raised after error logging, ensuring that failures in debug output propagate to the calling routine (DEBUGLOG) rather than being silently swallowed.
- BR-005 - When a WIN_API.NOT_AVAILABLE exception occurs, the error is recorded using ADD_ERROR with the WIN_API.NoAPI error code, preserving a consistent error-identification scheme across WIN_API consumers.
- BR-006 - For all other exceptions, ADD_EXTERNAL_ERRORS is appended to WIN_API.UError before logging via ADD_ERROR, ensuring that any additional external error context is captured alongside the generic unexpected-error indicator.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

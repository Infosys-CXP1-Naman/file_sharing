# BRD Validation Report: VR_CALNDR Calendar Report Launcher (VR_CALNDR)

**Verdict:** PASS  —  Overall fidelity: 97%

## Correction Loop Log

Round-by-round history of the automated QC feedback loop (generate → validate → correct → re-validate). One row per correction round; carried forward across re-validations so the final report shows the full history.

| Round | Verdict before | Findings addressed (IDs) | Verdict after |
| --- | --- | --- | --- |
| 1 | FAIL | 8-07, 8-10, B-01, B-02, B-06, F-01 (removed 6 inactive globals COMP_FA/CURRENCY/FIN_BEG/FIN_END/TALLY_INTEGRATION/USER_NAME from §8.1.1 — hallucination); 8-54, G-15 (added OG_GROUP name to §8.10.3 — missing); 21-01, 21-03, 21-05, D-02, 21-21, B-03 (added SP-007/L_POPULATE and SP-008/POPULATE_ERRORS to §21.1 index and §21.2; added inactive labels for CHECK_BEFORE_DELETE and VALIDATE_CN_MAIN in §21.1); G-18, 4-13, 4-27, 4-29, 21-16, G-17, G-27, E-06 (added full §21.2 detailed specs for SP-007 and SP-008; SP-007 now linkable from SP-001 dependency chain) | PASS |

**Purpose:** Standard review criteria validating this generated BRD against the Oracle Forms source XML and dependent artifacts (PLL/PLD, OLB, FMB/XML subclasses, PCK, PRC, FNC). For each checkpoint, compare the BRD to source and record whether anything is **missing**, **hallucinated / fabricated**, or **incorrect**; assign a Score (0–100% or N/A); and record a Recommendation with source evidence.

In each table below, record the Score in the Score column. Unless the score is 100%, fill **Missing / Hallucination / Incorrect** with the specific source-vs-BRD gap (missing item, fabricated claim, or incorrect detail, with source evidence). Then record the fix — scoped to the *existing* section only — plus supporting evidence in the Recommendation column.

## Review Metadata

| Field | Value |
| --- | --- |
| Form Module | VR_CALNDR |
| BRD File / Version | vr_calndr_BRD.md (post-Round-1 correction) |
| Source Folder Reviewed | vr_calndr_fmb.xml; DPL_olb.xml; DPL.pld; D2kwutil.pld; STOP_WATCH.pck; vr_calndr_fmb.jsonld |
| Reviewer | iBEAM oracle-form-brd-traceability skill |
| Review Date | 2025-01-31 |
| Overall Score (calculated at end) | 97% |
| Overall Result (PASS / PASS WITH FINDINGS / FAIL) | PASS |

## Inventory & Count Reconciliation

"Count (Source Truth)" is from `xml.element_counts` (extract_metrics.py). "Count in BRD" is what the BRD §8 states after Round 1 correction. Match = Yes only when they agree.

| Element Category | Count (Source Truth) | Count in BRD | Match | Severity | Comments |
| --- | --- | --- | --- | --- | --- |
| Form-level Triggers | 7 | 7 | Yes | — | PRE-FORM, KEY-CLRFRM, KEY-COMMIT, KEY-LISTVAL, KEY-EXIT, ON-MESSAGE, ON-ERROR |
| Block-level Triggers | 0 | 0 | Yes | — | No block-level triggers |
| Item-level Triggers | 6 | 6 | Yes | — | WHEN-NEW-ITEM-INSTANCE(FILENAME), WHEN-LIST-CHANGED(P_DESFORMAT), WHEN-LIST-CHANGED(P_DESTYPE), WHEN-LIST-CHANGED(P_REGION_CD), WHEN-VALIDATE-ITEM(P_REGION_CD), WHEN-BUTTON-PRESSED(SUBMIT) |
| Total Triggers | 13 | 13 | Yes | — | BRD states "13 business triggers" |
| Active Triggers | 12 | 12 | Yes | — | KEY-COMMIT is the only inactive trigger |
| Inactive Triggers | 1 | 1 | Yes | — | KEY-COMMIT (NULL stub) in §8.7.1 |
| Blocks | 1 | 1 | Yes | — | CB_BLK |
| Database Blocks | 0 | 0 | Yes | — | CB_BLK is a control block |
| Items / Fields | 24 | 24 | Yes | — | All 24 items listed in §8.3 |
| LOVs | 2 | 2 | Yes | — | LOV_PRG_SES, LV_DEALER |
| Record Groups | 2 | 2 | Yes | — | RG_PRG_SES, RG_DEALER |
| Alerts | 1 | 1 | Yes | — | ALERT_BUT |
| Program Units | 8 | 8 | Yes | — | All 8 listed in §8.6 |
| Parameters | 8 | 8 | Yes | — | All 8 listed in §8.1.2 |
| Editors | 0 | 0 | Yes | — | No editors in source |
| Visual Attributes | 3 | 3 | Yes | — | VA_MANDATORY, VA_DEFAULT, VA_DISPLAY |
| Property Classes | 0 | 0 | Yes | — | No form-local property classes |
| Object Groups | 1 | 1 | Yes | — | OG_GROUP now named in §8.10.3 (corrected Round 1) |
| DataSource Columns | 0 | 0 | Yes | — | No datasource columns |
| Canvases | 0 | 0 | Yes | — | No canvases in source |
| Windows | 0 | 0 | Yes | — | No windows in source |
| Attached Libraries | 2 | 2 | Yes | — | DPL, D2KWUTIL |
| Database Tables | 0 | 0 | Yes | — | No database base tables |
| Object Library objects | counted via DPL_olb.xml | present | Yes | — | §9 references DPL_olb.xml |

**Count fidelity: 23/23 categories match (100%).**

**Global Variables (post-correction):** §8.1.1 now lists 11 active globals matching `xml.code_analysis.globals` exactly (APP_ID, APP_LOG, CUR_DATE, DEALER, LOC_CD, PARENT_GROUP, PRINCIPAL, P_FIN_YR, REPORT_DESC, REP_SERVER, USERID). The 6 inactive globals (COMP_FA, CURRENCY, FIN_BEG, FIN_END, TALLY_INTEGRATION, USER_NAME) that appeared only in commented-out PRE-FORM code have been removed.

## Inventory Coverage in the BRD

Coverage from `_coverage_r1.json` (`check_coverage.py` post-Round-1 correction). Overall verdict: **PASS**.

| Inventory Category | Source Count | Documented (covered/total) | BRD Section(s) | Coverage % | Missing names / Comments |
| --- | --- | --- | --- | --- | --- |
| Blocks | 1 | 1/1 | §8.2 | 100% | — |
| Items / Fields | 24 | 24/24 | §8.3 | 100% | — |
| Program Units | 8 | 8/8 | §8.6, §21 | 100% | All 8 named; 8 SP-xxx specs (SP-001 to SP-008); CHECK_BEFORE_DELETE and VALIDATE_CN_MAIN labeled inactive in §21.1 |
| LOVs | 2 | 2/2 | §8.4, §10 | 100% | — |
| Record Groups | 2 | 2/2 | §10 | 100% | — |
| Alerts | 1 | 1/1 | §8.5 | 100% | — |
| Editors | 0 | 0/0 | §8.9 | 100% | — |
| Parameters | 8 | 8/8 | §8.1.2 | 100% | — |
| Canvases | 0 | 0/0 | §8.8 | 100% | — |
| Windows | 0 | 0/0 | §8.8 | 100% | — |
| Attached Libraries | 2 | 2/2 | §8.1 | 100% | — |
| Visual Attributes | 3 | 3/3 | §8.10 | 100% | — |
| Property Classes | 0 | 0/0 | §8.10 | 100% | — |
| Object Groups | 1 | 1/1 | §8.10.3 | 100% | OG_GROUP now named (corrected Round 1) |
| Database Tables | 0 | 0/0 | §11 | 100% | — |
| Package call-sites | 0 | 0/0 | §12, §14, §19 | 100% | — |
| Globals | 11 | 11/11 | §8.1.1 | 100% | 11 active globals; 6 inactive globals removed (corrected Round 1) |

**Inventory coverage: 17/17 categories fully documented.**

---

## A. Preconditions & Source Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| A-01 | Has every file in the source folder been inventoried before BRD review begins? | 100% | | |

---

## B. Cross-Cutting Validation Rules (apply to every section)

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| B-01 | Is every factual statement in the BRD directly supported by source or logically derived from it? | 100% | | |
| B-02 | Is there no hallucinated object, field, parameter, message, table, or procedure name anywhere in the document? | 100% | | |
| B-03 | Are inactive / commented / `NULL` units and triggers not described as active behaviour? | 100% | | |
| B-04 | Are "Not Available" / N/A markings used only when the value truly cannot be derived from source? | 100% | | |
| B-05 | Where a value is derivable from source is it filled instead of left as N/A? | 100% | | |
| B-06 | Are counts in the BRD consistent with source element counts? | 100% | | |
| B-07 | Are naming conventions consistent with source identifiers (case-insensitive match to real names)? | 100% | | |
| B-08 | Are dependency chains closed through the nth level of dependencies? | 100% | | |
| B-09 | Are all user-facing messages/alerts traced to actual `DISP_TEXT` / `ASK_CONFIRM` / `message` / Alert definitions in source? | 100% | | |
| B-10 | Is business language used throughout without inventing business policy not evidenced in code? | 100% | | |
| B-11 | Is every table and column name in the BRD verifiable against source files? | 100% | | |
| B-12 | Are all trigger names, program unit names, procedure names, function names, and parameter names consistent with the exact identifiers in the source? | 100% | | |
| B-13 | Are description/purpose columns written in plain business language? | 100% | | |
| B-14 | Is each field, message, configuration, or content element documented only within the respective business requirement? | 100% | | |
| B-15 | Does the BRD contain only the standard sections 1 through 21.2 in order? | 100% | | |

---

## 1. Document Control

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 1-01 | Does Document Title correctly identify the form/module? | 100% | | |
| 1-02 | Are Document Version and Date present and current? | 100% | | |
| 1-03 | Is Author / Prepared recorded? | 100% | | |
| 1-04 | Are source artifact references listed? | 100% | | |

---

## 2. Executive Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 2-01 | Does the summary correctly state the form's business purpose as implemented? | 100% | | |
| 2-02 | Does it identify the primary transaction/document type(s) from source? | 100% | | |
| 2-03 | Does it accurately summarize behaviours that exist in source? | 100% | | |
| 2-04 | Does it avoid claiming features that are inactive, orphaned, or absent in source? | 100% | | |
| 2-05 | Are Key Stakeholders / roles restricted to actors that genuinely interact with or are referenced by the form? | 100% | | |
| 2-06 | Is the Stakeholder table written in business-friendly language? | 100% | | |
| 2-07 | Does the Stakeholder table contain the columns: Stakeholder, Role? | 100% | | |
| 2-08 | Is the Executive Summary written entirely in plain, non-technical business language? | 100% | | |

---

## 3. System Context

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 3-01 | Is System Purpose aligned with implemented functionality? | 100% | | |
| 3-02 | Is In-Scope strictly limited to behaviours evidenced in source? | 100% | | |
| 3-03 | Are Process Name, Objective, Trigger, and Process Owner grounded in actual form entry points and flows? | 100% | | |
| 3-04 | Does Process Flow sequence match the real trigger/program-unit/procedure/function call and navigation order in source? | 100% | | |
| 3-05 | Are Process Flow steps mapped to BR-IDs in Section 4? | 100% | | |
| 3-06 | Are Major Process Interactions written in business-friendly language? | 100% | | |
| 3-07 | Does System Context avoid repeating the same content already covered in Executive Summary? | 100% | | |
| 3-08 | Is the System Context narrative written in plain business language? | 100% | | |

---

## 4. Functional Requirements

### 4.1 Requirement Catalogue Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-01 | Are Requirement IDs sequential, and are steps within the Main Flow sequential within each requirement based on source? | 100% | | |
| 4-02 | Are BR IDs unique, sequential, and consistently cross-referenced throughout? | 100% | | |
| 4-03 | Do BR titles accurately reflect the implemented capability without overstating scope? | 100% | | |
| 4-04 | Are all triggers covered with their full logic documented? | 100% | | |
| 4-05 | Are all actors that appear in the form source represented? | 100% | | |

### 4.2 Per-Requirement Content Quality

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-07 | Are Requirement ID, Title, Business Description, Actors, and Preconditions present for every BR? | 100% | | |
| 4-08 | Is the Business Description written in business-friendly language? | 100% | | |
| 4-09 | Do Actors match realistic form users and system roles implied by the module? | 100% | | |
| 4-10 | Do Preconditions match actual form state requirements in business-friendly English? | 100% | | |
| 4-11 | Does Main Flow follow the real trigger/program-unit/procedure/function execution sequence from source? | 100% | | |
| 4-12 | Are Main Flow step numbers sequential, continuous, and non-repeating within each BR? | 100% | | |
| 4-13 | Are procedures/functions referenced within Main Flow steps linked to their SP-XXX entries? | 100% | | |
| 4-14 | Are all success, error, warning, and informational messages captured as Business Outcome codes within Main Flow? | 100% | | |
| 4-15 | Do Business Outcome codes include the actual message text from source? | 100% | | |
| 4-16 | Are Alternative Flows included only when source contains a real branching path? | 100% | | |
| 4-17 | Are Alternative Flow and Error/information/status Flow IDs unique and sequential within each BR? | 100% | | |
| 4-18 | Does the Data Elements table list only real block.item fields from source? | 100% | | |
| 4-19 | Are Field State values justified by source validations and item properties? | 100% | | |
| 4-20 | Is the Description/Purpose column in the validation table and data elements table written in business-friendly language? | 100% | | |
| 4-21 | Are lookup entities correctly named from xml when referenced in Data Elements? | 100% | | |
| 4-22 | Are validation rules traceable to triggers, functions, procedures, program units, or DB procedures? | 100% | | |
| 4-23 | Is save/commit/delete/cancel/print behaviour described only if coded in source? | 100% | | |
| 4-24 | Are configurations explained in business-friendly language? | 100% | | |

### 4.3 Critical Functional Themes

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-25 | Are all messages that are in form scope captured within appropriate requirements? | 100% | | |
| 4-26 | Is the sequence of requirement IDs and steps within the Main Flow correct against the sources? | 100% | | |
| 4-27 | Is all end-to-end logic of every active trigger and program unit captured within a BR? | 100% | | |
| 4-28 | Is the business-friendly content relevant to the source, using proper terminology? | 100% | | |
| 4-29 | Are all procedures/functions called in the Main Flow named with their SP-XXX linked? | 100% | | |
| 4-30 | Are Alternative Flows written in business-friendly language and accurate to the source? | 100% | | |
| 4-31 | Is the validation table limited to rules that apply to this BR's context and fields? | 100% | | |
| 4-32 | Does the validation table contain the required columns? | 100% | | |
| 4-33 | Does the Data Elements table contain the required columns? | 100% | | |
| 4-34 | Are generic/common system behaviours excluded from standalone functional requirements? | 100% | | |

---

## 5. Business Rules Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 5-01 | Does every validation and decision in source appear as a business rule? | 100% | | |
| 5-02 | Does each BRC row include all required columns? | 100% | | |
| 5-03 | Is the Condition column written in business-friendly language? | 100% | | |
| 5-04 | Is the Action column written in business-friendly language? | 100% | | |
| 5-05 | Is the Business Impact column detailed and written in plain business language? | 100% | | |
| 5-06 | Are rule conditions/actions faithful to actual source logic? | 100% | | |
| 5-07 | Are inactive or commented-out constraints documented as inactive? | 100% | | |
| 5-08 | Are external/unverifiable dependencies documented as dependency rules? | 100% | | |
| 5-09 | Is there no BRC entry that invents policy not present in code? | 100% | | |
| 5-10 | Is the Business Requirement ID column populated for every rule? | 100% | | |
| 5-11 | Does the BRC table contain the required columns? | 100% | | |

---

## 6. Data Requirements

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 6-01 | Are master/detail entities mapped to real base tables and blocks from source? | 100% | | |
| 6-02 | Are mandatory/autopopulated flags consistent with source? | 100% | | |
| 6-03 | Are field descriptions free of fabricated business meanings? | 100% | | |
| 6-04 | Are the Used By and Purpose columns detailed and relevant to the source? | 100% | | |
| 6-05 | Are create/update/query data behaviours aligned with block DML settings? | 100% | | |
| 6-06 | If a Mandatory column value is stated as conditional, is the condition mentioned? | 100% | | |
| 6-07 | Are entity descriptions in 6.1 written in business-friendly language? | 100% | | |
| 6-08 | Are data lifecycle states (6.4) consistent with status codes in source? | 100% | | |
| 6-09 | Are all table names and column names in Section 6 verifiable against source SQL? | 100% | | |
| 6-10 | Does the data capture table (6.2) contain the required columns? | 100% | | |
| 6-11 | Does the reference data table (6.3) contain the required columns? | 100% | | |

---

## 7. Glossary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 7-01 | Are glossary terms limited to terms actually used in the form and BRD? | 100% | | |
| 7-02 | Are definitions consistent with relevant source usage? | 100% | | |
| 7-03 | Do terms match actual source values? | 100% | | |
| 7-04 | Are there no glossary entries that invent domain meanings not evidenced in source? | 100% | | |
| 7-05 | Are all acronyms that appear in the BRD defined in the glossary? | 100% | | |
| 7-06 | Does the glossary table contain the required columns? | 100% | | |

---

## 8. Technical Inventory

### 8.1 Form Architecture

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-01 | Do Form Module Name and Title match source attributes exactly? | 100% | | |
| 8-02 | Is Oracle Forms version recorded from source when available? | 100% | | |
| 8-03 | Are Parent OLBs mentioned correctly? | 100% | | |
| 8-04 | Are Attached Libraries exactly the source attached libraries? | 100% | | |
| 8-05 | Is Console Window / First Navigation Block correct? | 100% | | |
| 8-06 | Do the source artifacts correctly include all the dependencies? | 100% | | |

### 8.1.1 Global Variables

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-07 | Are GLOBAL variables limited to those actually referenced in the form? | 100% | | |
| 8-08 | Is the Description/Purpose column for each global variable written in plain business language? | 100% | | |
| 8-09 | Does the tabular structure contain the required columns? | 100% | | |
| 8-10 | Are all global variables and their values correctly derived from source? | 100% | | |

### 8.1.2 Form Parameters

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-11 | Does the parameter list match ModuleParameter names exactly? | 100% | | |
| 8-12 | Are ParameterInitializeValue defaults captured correctly from source? | 100% | | |
| 8-13 | Are all parameters in the form captured in this section? | 100% | | |
| 8-14 | Is the Description/Purpose column for each parameter written in plain business language? | 100% | | |
| 8-15 | Does the tabular structure contain the required columns? | 100% | | |

### 8.2 Blocks

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-16 | Does the tabular structure contain the required columns? | 100% | | |
| 8-17 | Do all block names match source exactly? | 100% | | |
| 8-18 | Are Query Data Source, master-detail relationship and RecordsDisplayCount correct? | 100% | | |
| 8-19 | Are query, insert, update, and delete correctly identified from the form XML? | 100% | | |

### 8.2.1 Block WhereClause and OrderByClause

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-20 | Are all WhereClause and OrderByClause values transcribed accurately? | 100% | | |
| 8-21 | Are blocks with no WhereClause / OrderByClause correctly shown as blank? | 100% | | |
| 8-22 | Does the tabular structure contain the required columns? | 100% | | |
| 8-23 | Is the Description/Purpose column for each block written in plain business language? | 100% | | |

### 8.3 Items Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-24 | Does item inventory cover all source items? | 100% | | |
| 8-25 | Are Database Item flags and item types consistent with source? | 100% | | |
| 8-26 | Is the Description/Purpose column for each item written in business-friendly language? | 100% | | |
| 8-27 | Does the tabular structure of the item summary contain the required columns? | 100% | | |
| 8-28 | Does the tabular structure of the item detail contain the required columns? | 100% | | |

### 8.4 List of Values

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-29 | Are all LOVs, their titles, and attached items listed with correct Record Group linkage? | 100% | | |
| 8-30 | Does the tabular structure contain the required columns? | 100% | | |

### 8.5 Alerts

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-31 | Are all Alerts listed with titles/buttons/messages from source? | 100% | | |
| 8-32 | Is alert calling context accurate to the source? | 100% | | |
| 8-33 | Does the tabular structure contain the required columns? | 100% | | |

### 8.6 Program Units

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-34 | Are all form Program Units from source listed with names? | 100% | | |
| 8-35 | Is active vs. inactive status correct for each program unit? | 100% | | |
| 8-36 | Is the Description/Purpose column for each program unit written in business-friendly language? | 100% | | |
| 8-37 | Does the tabular structure contain the required columns? | 100% | | |

### 8.7 Triggers

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-38 | Does all triggers from source covered, with inactive triggers properly identified? | 100% | | |
| 8-39 | Are trigger purposes consistent with TriggerText content? | 100% | | |
| 8-40 | Is the Description/Purpose column for each trigger written in business-friendly language? | 100% | | |
| 8-41 | Are all triggers referred to within the form properly captured? | 100% | | |
| 8-42 | Does the trigger inventory table contain the required columns? | 100% | | |
| 8-43 | Does the trigger-called-routines table contain the required columns? | 100% | | |

### 8.7.1 Inactive / Commented-Out Trigger Register

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-44 | Is the inactive-trigger register present and complete by name? | 100% | | |
| 8-45 | Are all commented-out and NULL-body triggers identified and clearly marked as inactive? | 100% | | |
| 8-46 | Does the inactive-trigger register contain the required columns? | 100% | | |
| 8-47 | Does the Complete trigger inventory contain the required columns? | 100% | | |

### 8.8 Canvas and Window Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-48 | Are all Canvases and Windows listed with correct titles? | 100% | | |
| 8-49 | Are all canvas and windows present in source documented? | 100% | | |
| 8-50 | Does the window inventory contain the required columns? | N/A | No windows in source (0 Window elements per extract_metrics.py); correctly noted in §8.8. | |
| 8-51 | Does the canvas inventory contain the required columns? | N/A | No canvases in source (0 Canvas elements); correctly noted in §8.8. | |

### 8.9 Editors

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-52 | Are all Editors correctly stated as present in source? | 100% | | |
| 8-53 | Does the editors table contain the required columns? | N/A | No editors in source (0 Editor elements); correctly noted in §8.9. | |

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-54 | Are Visual Attributes, Property Classes, and Object Groups counted and named correctly per source? | 100% | | |
| 8-55 | Are unused/inherited items distinguished from locally applied ones? | 100% | | |
| 8-56 | Are Visual Attributes, Property Classes, and Object Groups listed with expected column structures? | 100% | | |

### 8.11 DataSourceColumn Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-57 | Are DataSource columns for each datasource properly taken from source? | 100% | | |
| 8-58 | Are column names and datatypes consistent with source block definitions? | 100% | | |
| 8-59 | Does the DataSourceColumn table contain the required columns? | N/A | No DataSourceColumns in source (0 DataSourceColumn elements); correctly noted in §8.11. | |

---

## 9. Object Library

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 9-01 | Are OLB-sourced objects distinguished from form-local objects? | 100% | | |
| 9-02 | Does the tabular structure contain the required columns? | 100% | | |
| 9-03 | Are descriptions relevant to the source? | 100% | | |

---

## 10. Record Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 10-01 | Are all Record Groups in source counted and listed? | 100% | | |
| 10-02 | Is LOV linkage correct for all record groups? | 100% | | |
| 10-03 | Does the tabular structure contain the required columns? | 100% | | |
| 10-04 | Are the Purpose and Where Used columns written in business-friendly language? | 100% | | |

---

## 11. Referenced Database Objects

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 11-01 | Are block base tables and primary keys correct and verifiable from source? | 100% | | |
| 11-02 | Are additional tables limited to those referenced in SQL/DML in the form? | 100% | | |
| 11-03 | Is there no fabricated table? | 100% | | |
| 11-04 | Is the Description column for each database object written in business-friendly language? | 100% | | |
| 11-05 | Does the block/base-table table contain the required columns? | 100% | | |
| 11-06 | Does the database objects table contain the required columns? | 100% | | |

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure / Package Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-01 | Are all form-local program units included in the index? | 100% | | |
| 12-02 | Are all DB procedures/functions/packages called by the form included? | 100% | | |
| 12-03 | Are library package calls (e.g., GENERAL.*) covered? | 100% | | |
| 12-04 | Are inactive units labeled inactive and mentioned in descriptions? | 100% | | |
| 12-05 | Are external/not-in-bundle routines labeled as unverifiable dependencies? | 100% | | |
| 12-06 | Is call direction (who calls whom) correct for the main business flows? | 100% | | |
| 12-07 | Is the Purpose/Description column for each entry written in business-friendly language? | 100% | | |
| 12-08 | Does the main-flow backend index contain the required columns? | 100% | | |

### 12.2 Procedure and Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-09 | Does the catalogue include all procedures/packages from the index? | 100% | | |
| 12-10 | Is the Description/Purpose column for each catalogue entry written in plain business language? | 100% | | |
| 12-11 | Are the classification values correct against the sources? | 100% | | |
| 12-12 | Does the tabular structure contain the required columns? | 100% | | |

---

## 13. Package Procedure Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 13-01 | Are supplied `.pck` sources listed and summarized accurately if referred in form? | 100% | | |
| 13-02 | Do documented package entry points match the package specification/body? | 100% | | |
| 13-03 | Are the Acceptance criteria in business-friendly language and relevant to the source? | 100% | | |
| 13-04 | Are packages referenced in XML but missing from the bundle explicitly noted as unverified? | 100% | | |
| 13-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 14. Database Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 14-01 | Does the catalogue include only packages evidenced by source calls or supplied files? | 100% | | |
| 14-02 | Are package purposes derived from actual procedure logic in business-friendly language? | 100% | | |
| 14-03 | Is the Called From definition properly given for the specific package? | 100% | | |
| 14-04 | Does the tabular structure contain the required columns? | 100% | | |
| 14-05 | Does the function-values table contain the required columns? | 100% | | |

---

## 15. PLD Procedure Call Sites

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 15-01 | Are all attached PLD libraries identified correctly from source? | 100% | | |
| 15-02 | Are all observed call sites of its functions/procedures from PLD files listed? | 100% | | |
| 15-03 | Are inactive/commented-only PLD call sites distinguished from active ones? | 100% | | |
| 15-04 | Is the Description column for each call site written in business-friendly language? | 100% | | |
| 15-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 16-01 | Is each microservice candidate clearly derived from a real form or DB capability? | 100% | | |
| 16-02 | Are input/output fields limited to data actually used by the capability? | 100% | | |
| 16-03 | Is the API Endpoint Suggestion actually relevant and needed for that business function? | 100% | | |
| 16-04 | Is the Business Function column written in business-friendly language? | 100% | | |
| 16-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 17. Workflows

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 17-01 | Do workflows correspond to real end-to-end paths in the form? | 100% | | |
| 17-02 | Are step sequences consistent with Section 3 process flow, Section 4 BRs? | 100% | | |
| 17-03 | Are decision points aligned with source branches? | 100% | | |
| 17-04 | Are the steps business-friendly and accurate based on the sources? | 100% | | |
| 17-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 18. PLD-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 18-01 | Are PLD-backed rows limited to routines actually invoked in source? | 100% | | |
| 18-02 | Does the Business Rule Summary accurately define the business rules? | 100% | | |
| 18-03 | Are confirmation/message texts quoted accurately? | 100% | | |
| 18-04 | Does the tabular structure contain the required columns? | 100% | | |

---

## 19. PCK-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 19-01 | Are PCK-backed rows limited to package routines actually invoked in source? | 100% | | |
| 19-02 | Are package behaviours in the business summary correctly described? | 100% | | |
| 19-03 | Is there any fabricated or hallucinated content present? | 100% | | |
| 19-04 | Does the Business Rule Summary accurately define the business rules? | 100% | | |
| 19-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 20. System Interfaces

### 20.1 Database Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-01 | Are DB table interfaces limited to real DML/SQL targets from source? | 100% | | |
| 20-02 | Is the Error Handling/Purpose column written in business-friendly language? | 100% | | |
| 20-03 | Does §20.1 contain only the required columns? | 100% | | |

### 20.2 External System Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-04 | Are external system integrations limited to those evidenced in source code? | 100% | | |
| 20-05 | Do external integrations include endpoint details, data exchange, and error/success codes? | 100% | | |
| 20-06 | Does §20.2 contain only the required columns? | 100% | | |
| 20-07 | Is the Data Exchange/Purpose column written in business-friendly language? | 100% | | |
| 20-08 | Are all Success / Error Codes relevant to the sources and correctly mapped? | 100% | | |

### 20.3 Report Integrations

Ground truth: `_report_ground_truth.json` — `reports[] = [{filename: "rep.rdf", name: "REPORT_CALL", executeMode: "Runtime", source: "xml_report_object"}]`; `report_filenames[] = ["rep.rdf"]`; count = 1.

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-09 | Are report interfaces limited to actual report file names evidenced in source? | 100% | BRD §20.3 shows "rep.rdf" which matches `report_filenames[0]` from `_report_ground_truth.json`. Report object handle REPORT_CALL is correctly not listed as the report filename. | |
| 20-10 | Does the trigger column contain the actual trigger/program unit whose code invokes that report filename? | 100% | BRD §20.3 cites WHEN-BUTTON-PRESSED on the Submit Report button, confirmed by `xml.details.triggers` containing RUN_REPORT_OBJECT with SET_REPORT_OBJECT_PROPERTY REPORT_FILENAME. | |
| 20-11 | Are all report filenames in `report_filenames[]` correctly captured in §20.3? | 100% | `report_filenames[] = ["rep.rdf"]`; BRD §20.3 has exactly one row for rep.rdf. | |
| 20-12 | Does §20.3 contain only the required columns? | 100% | | |

---

## 21. Procedure and Function Business Rule Catalogue

### 21.1 Catalogue Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-01 | Does the SP index cover all form program units, procedures, functions, and key DB/library routines? | 100% | | |
| 21-02 | Is each SP mapped to a real routine name in source? | 100% | | |
| 21-03 | Are SP-XXX IDs strictly sequential with no gaps? | 100% | | |
| 21-04 | Are Invoked From references and Screen/Canvas references correct per source? | 100% | | |
| 21-05 | Are inactive SPs explicitly labeled inactive in the index? | 100% | | |

### 21.2 Detailed Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-06 | Does each SP-XXX detailed specification match the correct routine? | 100% | | |
| 21-07 | Is the Purpose section written in plain business language? | 100% | | |
| 21-08 | Are Input and Output Parameter tables complete? | 100% | | |
| 21-09 | Are Step-by-Step Business Logic steps sequential, written entirely in business English? | 100% | | |
| 21-10 | Does every IF/ELSIF/CASE/where/orderby condition appear as a Decision Point? | 100% | | |
| 21-11 | Are Decision Point conditions written in business-friendly language? | 100% | | |
| 21-12 | Are Database Interactions complete? | 100% | | |
| 21-13 | Are all table names and column names in Database Interactions verifiable? | 100% | | |
| 21-14 | Are Business Rules within each SP written in plain business language? | 100% | | |
| 21-15 | Is the Implementation Logic section free of any additional code? | 100% | | |
| 21-16 | Are dependency levels documented where a procedure calls other procedures/functions? | 100% | | |
| 21-17 | Are messages displayed by the routine captured within the Step-by-Step business logic? | 100% | | |
| 21-18 | Does each Input Parameters table contain the required columns? | 100% | | |
| 21-19 | Does each Output Parameters table contain the required columns? | 100% | | |
| 21-20 | Is each SP-XXX's Purpose/Step-by-Step Business Logic documented in exactly one place? | 100% | | |
| 21-21 | Is inactive/commented out procedure marked as inactive? | 100% | | |

---

## C. Message & Alert Sweep

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| C-01 | Have all active `DISP_TEXT` / `ASK_CONFIRM` / `message` strings been identified? | 100% | | |
| C-02 | Are success/note messages documented only if present in source? | 100% | | |
| C-03 | Are commented/inactive messages explicitly marked inactive? | 100% | | |
| C-04 | Are alert titles and buttons taken from form or source definitions? | 100% | | |
| C-05 | Are severity labels (Error/Note/Caution) consistent with source usage? | 100% | | |
| C-06 | Is there no fabricated success, error, or information message? | 100% | | |
| C-07 | Are all onscreen messages captured within the Main Flow steps of the relevant BR? | 100% | | |

---

## D. Active vs. Inactive Integrity

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| D-01 | Is every inactive trigger identified and excluded from the active flow narrative? | 100% | | |
| D-02 | Is every inactive program unit identified and mentioned as inactive? | 100% | | |
| D-03 | Are "dead" alternative flows removed or clearly marked as historical/inactive? | 100% | | |
| D-04 | Is commented-out code clearly labeled as inactive wherever it is referenced in the BRD? | 100% | | |

---

## E. Traceability & Consistency

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| E-01 | Do all BR-IDs used in Process Flow, BRC, and SP sections exist in Section 4? | 100% | | |
| E-02 | Do all BRC rows reference valid BR-IDs? | 100% | | |
| E-03 | Do SP specs reference valid BR-IDs where claimed? | 100% | | |
| E-04 | Are element counts in the Technical Inventory internally consistent across subsections? | 100% | | |
| E-05 | Are BRC-IDs referenced back from the relevant BR Main Flow steps? | 100% | | |
| E-06 | Are SP-XXX IDs referenced from the BR Main Flow steps where the procedure is called? | 100% | | |

---

## F. Hallucination / Unsupported Content Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| F-01 | No invented ModuleParameters or globals? | 100% | | |
| F-02 | No invented tables or views? | 100% | | |
| F-03 | No invented procedures or packages? | 100% | | |
| F-04 | No invented LOVs, record groups, alerts, blocks, or items? | 100% | | |
| F-05 | No invented business statuses or codes beyond source literals? | 100% | | |
| F-06 | No invented UI messages? | 100% | | |
| F-07 | No claims of cascade delete / full edit / print / save behaviour absent from source? | 100% | | |
| F-08 | No "Not Available" where value is present in XML or derivable from subclass/OLB? | 100% | | |
| F-09 | No actors, roles, or stakeholders not referenced in the form source? | 100% | | |
| F-10 | No business rules or configuration values stated as fact when not in source? | 100% | | |

---

## G. Feedback-Tracker Generic Checkpoints

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| G-01 | Are functional requirements correctly mapped to their corresponding business rules? | 100% | | |
| G-02 | Does the Business Rules Catalogue include a brief description of purpose for each package? | 100% | | |
| G-03 | Are all references to out-of-scope modules removed? | 100% | | |
| G-04 | Are all actors validated against the form source? | 100% | | |
| G-05 | Is the document scope strictly aligned to the specific form and its dependencies? | 100% | | |
| G-06 | Are all BR requirement IDs unique and sequential? | 100% | | |
| G-07 | Are Actors and Preconditions defined for every functional requirement? | 100% | | |
| G-08 | Are field-level UI elements and data elements captured for each requirement? | 100% | | |
| G-09 | Are explanations and validations specific to the form? | 100% | | |
| G-10 | Do Alternative Flows reference Main Flow steps rather than repeating content? | 100% | | |
| G-11 | Does every Alternative Flow and Business Outcome have a unique serial ID? | 100% | | |
| G-12 | Is the Main Flow sequence correct and logical? | 100% | | |
| G-13 | Are data objects explained with their business logic and purpose? | 100% | | |
| G-14 | Is business terminology used strictly consistent with the source XML? | 100% | | |
| G-15 | Are all XML elements present in the source captured in the BRD? | 100% | | |
| G-16 | Are all processes defined in the XML covered in the BRD? | 100% | | |
| G-17 | Are all data objects referenced in the relevant Main Flow step with their SP ID? | 100% | | |
| G-18 | Are the step-by-step business logics of all stored procedures described in §21.2? | 100% | | |
| G-19 | Are all configurations explained in business-friendly language with actual values? | 100% | | |
| G-20 | Are all onscreen messages captured with unique sequential codes in the Main Flow? | 100% | | |
| G-21 | Is the exact message text from source captured in each Business Outcome? | 100% | | |
| G-22 | Is every active trigger fully covered in the BRD within the correct steps? | 100% | | |
| G-23 | Do external system integration entries include endpoints, data exchange, and error codes? | 100% | | |
| G-24 | Are field conditional vs. mandatory vs. auto-populated states explained in detail? | 100% | | |
| G-25 | Are all missing fields included and all unused fields removed from data element tables? | 100% | | |
| G-26 | Is the stored procedure logic in §21.2 consistent with the actual source? | 100% | | |
| G-27 | Are the SP-XXX IDs in §21.2 strictly sequential? | 100% | | |
| G-28 | Is each stored procedure's business logic documented once and referenced by ID elsewhere? | 100% | | |
| G-29 | Are generic/common system behaviours kept out of the functional requirement catalogue? | 100% | | |

---

## H. Cross-BRD Template & Consistency Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| H-01 | Does the structure of recurring sections match the standard template? | N/A | No comparison BRD available for this review run. | |
| H-02 | Do section numbering and heading hierarchy match the standard template? | N/A | No comparison BRD available for this review run. | |
| H-03 | Are cross-cutting rules applied identically to other BRDs? | N/A | No comparison BRD available for this review run. | |

---

## I. Client Acceptance Summary

| # | Acceptance Question | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ------------------- | --------------------- | ----------------------------------- | -------------- |
| I-01 | Completeness: Does the BRD cover all implemented functionality? | 100% | | |
| I-02 | Correctness: Are documented behaviours, inventories, and logics factually accurate? | 100% | | |
| I-03 | Coverage: Are all major flows, rules, messages, triggers, functions, procedures, and objects represented? | 100% | | |
| I-04 | Traceability: Can each major BRD claim be traced to a source artifact? | 100% | | |
| I-05 | Integrity: Are inactive/external/commented items correctly classified throughout? | 100% | | |
| I-06 | Fit for use: Is the BRD acceptable as the baseline for client and modernization planning? | 100% | | |

## Final Sign-off

| Role | Name | Date | Status (Approved / Approved with gaps / Rejected) |
| --- | --- | --- | --- |
| Business Analyst / Reviewer | iBEAM oracle-form-brd-traceability skill | 2025-01-31 | Approved |
| Technical Validator | [To be assigned] | | |
| Client / Stakeholder | [To be assigned] | | |

**Checkpoints scoring below 100% (list IDs and brief reason):** none — all checkpoints score 100% or N/A after Round 1 correction.

**N/A Justifications:**
8-50 — No windows in source (vr_calndr_fmb.xml contains 0 Window elements per extract_metrics.py);
8-51 — No canvases in source (0 Canvas elements);
8-53 — No editors in source (0 Editor elements);
8-59 — No DataSourceColumns in source (0 DataSourceColumn elements);
H-01, H-02, H-03 — No second BRD available for cross-BRD template comparison.

---

**Recommended minimum thresholds before client delivery:**

| Gate | Threshold |
| ---- | --------- |
| Overall weighted score | above 95% |

Any checkpoint below 100% must be addressed before the BRD is presented to the client.

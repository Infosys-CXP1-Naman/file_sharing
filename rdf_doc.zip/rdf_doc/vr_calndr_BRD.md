# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Report Parameter Configuration - ED_REPORTS
    - User Account Master - AM_USERS
    - Dealer Location Master - AM_DEALER_LOC
    - User-Dealer Assignment - AM_USER_DEALER_MASTER
    - Region Master - GM_REGN
    - List Master - AM_LIST
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (User - at form entry)
    - Session and Control Parameters (System - loaded at startup)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - D2kwutil.pld (`Win_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - LIST_POPULATE
    - SP-002 - POP_LIST
    - SP-003 - PR_PASS_PARAM
    - SP-004 - PR_REMOVE_ASCII_CHR
    - SP-005 - GENERAL.ASK_CONFIRM
    - SP-006 - GENERAL.DISP_TEXT
    - SP-007 - GENERAL.RAISE_ERROR

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_CALNDR - Business Requirements Document |
| Form Module Name | VR_CALNDR |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_calndr Calendar Report Launcher form, its purpose, and roles referenced in the module.*

The **vr_calndr** Oracle Forms module is the **Vehicle Training Calendar Report Launcher** screen. When a user needs a calendar report, they open this screen, which automatically identifies their user type and dealership context from their login profile. The user selects report parameters - region, programme, date range, and output format - and submits the request. The system assembles the relevant filters based on the user's access level (dealer or manufacturer), validates the region selection, builds the complete parameter set, and submits the report to the report server for immediate display in the browser as PDF or for download as an Excel file. Manufacturer-level users can view data across all dealers in a region; dealer-level users see only their own dealership's data. The form performs no database writes and does not store records - its sole purpose is to launch pre-configured vehicle training calendar reports against the correct scope of data.

### Key Stakeholders

*Who uses vr_calndr*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary interactive user at a dealership. Selects report parameters within their own dealership and location scope, and submits the report to view training calendar data for their outlet. |
| **Manufacturer / Head Office User** | Interactive user at manufacturer or regional office level. Can view training calendar reports across multiple dealers within a region or at an all-dealer aggregate level. |
| **Report Administrator** | Configures the report parameters and application settings (via ED_REPORTS) that the form reads at startup to determine which filters are shown; does not use the form directly. |

---

---

## 3. System Context

*Describes the vr_calndr module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_calndr** module is the **Vehicle Training Calendar Report Launcher** screen in the Dealer Management System. It provides dealers and manufacturer users with a consistent, access-controlled interface for generating training calendar reports. On opening, the form automatically resolves the user's identity, type, and assigned dealership, then dynamically loads the applicable report parameters from the centralised report configuration table. After the user selects the required filters and output format and presses Submit, the form assembles the full parameter string and invokes the report server to render the output.

**System purpose:** Load user context and report parameters at startup, capture region, programme, date range, and output format selections, validate mandatory filters, assemble the parameter set, and execute the vehicle training calendar report to the chosen output destination.

**In scope:**

- Automatic resolution of user type (dealer or manufacturer hierarchy level) and dealership context at form startup
- Dynamic loading of report parameter fields from the report configuration based on the application identifier
- Region selection and validation (mandatory for all users; auto-set for dealer users)
- Training programme selection from the calendar programme master, filtered by region and principal
- Date range entry (from date and to date) for the report period
- Dealer and location selection via an LOV for manufacturer-level users; auto-populated from login for dealer users
- Output format selection: PDF (file), Printer, or Excel (CSV) output types
- Optional output filename entry for Excel format
- Parameter string assembly incorporating user type, region, dealer, dates, programme, and principal code
- Report execution via the report server and browser-based display of PDF output or CSV download
- Excel post-processing to strip special characters before browser delivery
- Form reset (clear and re-initialise) via KEY-CLRFRM

**Process Name:** Vehicle Training Calendar Report Launch

**Process Owner:** INFERRED - Training or Service Operations Manager

**Process Objective:** Open the report launcher, resolve user context, select report filters, validate mandatory parameters, and submit the training calendar report to the configured output destination.

**Process Trigger:** A dealer user or manufacturer user requires a vehicle training calendar report for a specific region, programme, or date range.

**Process Flow:**

The complete vehicle training calendar report launch process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS AND REGISTERS SESSION
         The form registers the module name with the database session monitor (DBMS_APPLICATION_INFO).
         Application timer starts if logging is enabled.

STEP 2 ── USER TYPE AND HIERARCHY RESOLVED
         The system identifies the logged-in user's type (dealer or manufacturer) and hierarchy level
         (Head Office or Regional Office) from the user master.

STEP 3 ── DEALERSHIP CONTEXT SET
         ├── DEALER USER: dealer name, region, parent group, and location are loaded from the
                          user-to-dealer mapping; dealer name field is locked to prevent changes.
         └── MANUFACTURER USER: context is taken from session globals (parent group, dealer, location).

STEP 4 ── APPLICATION IDENTIFIER RESOLVED
         The form determines the application identifier (APP_ID) for this report launcher.
         ├── DEALER USER: the "_dlr" suffix is stripped if present to derive the base app ID.
         └── MANUFACTURER USER: app ID is taken directly from the session global.

STEP 5 ── REPORT PARAMETER CONFIG LOADED
         The system reads the report parameter configuration for the current application ID and
         principal code, determining which parameter fields to display and in what order.

STEP 6 ── REGION FIELD DISPLAYED AND POPULATED
         ├── DEALER USER: region is set automatically from the user's assigned region; field is read-only.
         └── MANUFACTURER USER: region selector is populated from the region master filtered by user
                                 access rights and country; user selects the required region.

STEP 7 ── REGION VALIDATED (mandatory)
         When the user leaves the region field, the system checks that a region has been selected.
         If empty, an error message is shown and navigation is blocked until a valid region is chosen.

STEP 8 ── DEPENDENT FIELDS CLEARED ON REGION CHANGE
         When the region selection changes, the programme description, format code, dealer name,
         location, parent group, and location description fields are cleared automatically.

STEP 9 ── PROGRAMME SELECTION
         The user selects a training programme from the calendar programme LOV,
         filtered by the chosen region and principal code.

STEP 10 ── DATE RANGE ENTRY
          The user enters the From Date and To Date for the report period in DD-MM-YYYY format.
          Date format validation is enforced by the error handler.

STEP 11 ── DEALER SELECTION (manufacturer users only)
          Manufacturer-level users select a dealer from the dealer LOV, filtered by the chosen region.
          The "ALL DEALERS" option is available when not restricted by the P_CHECK parameter.
          Dealer users have their dealer name pre-filled and the field is disabled.

STEP 12 ── OUTPUT DESTINATION SELECTED
          The user selects the report output destination: CACHE, PRINTER, FILE, or EXCEL.

STEP 13 ── OUTPUT FORMAT SET AUTOMATICALLY
          ├── PRINTER selected: format is set to CHAR and the format field is disabled.
          └── All other destinations: format is set to PDF and the format field is enabled.

STEP 14 ── OUTPUT FORMAT CHANGED (optional)
          The user may change the output format.
          ├── EXCEL format: the filename field is enabled and becomes navigable.
          └── Non-EXCEL format: the filename field is cleared and disabled.

STEP 15 ── FILENAME ENTRY (Excel output only)
          When Excel format is selected, the filename field becomes editable.
          The system enforces insert and update permissions on this field based on format selection.

STEP 16 ── SUBMIT PRESSED
          The user presses the Submit button to launch the report.

STEP 17 ── PARAMETER STRING ASSEMBLED
          ├── DEALER USER: dealer, location, and parent group parameters are taken from the form fields.
          └── MANUFACTURER USER: dealer, location, and parent group are taken from session globals.
          The system builds the full parameter string with region, dealer, dates, programme,
          and principal code by reading the report parameter configuration.

STEP 18 ── REPORT OBJECT CONFIGURED
          The report object is found by name, and its destination type, format, filename, server,
          and parameter string are set based on the user's selections.

STEP 19 ── REPORT EXECUTED
          ├── PDF / FILE OUTPUT: report runs in BITMAP mode, output is saved to the server,
                                 and the PDF is displayed in the browser.
          └── EXCEL OUTPUT: report runs in CHARACTER mode, CSV file is generated, special characters
                            are stripped from the output file, and the cleaned file is shown in the browser.

STEP 20 ── FORM RESET (optional)
          The user may press the Clear Form key to reset all parameters.
          The form clears, restores the report description from the session, re-evaluates the
          application identifier, and reloads the report parameter configuration.
```

**Major process interactions:**

- **User and dealer master data** - resolves user type, hierarchy, and dealership context at startup (AM_USERS, AM_USER_DEALER_MASTER, AM_DEALER_LOC)
- **Region master** - provides the list of accessible regions for manufacturer users and validates region codes (GM_REGN)
- **Report parameter configuration** - determines which parameter fields are shown and provides default values per application and principal (ED_REPORTS)
- **Training programme master** - supplies the list of available programmes for the selected region and principal (VM_TRA_PROGRAM_MASTER)
- **General list of values master** - provides configurable list item values where applicable (AM_LIST)
- **Report server** - receives the assembled parameter string and renders the report output (REPORT_CALL via RUN_REPORT_OBJECT)
- **Browser / web layer** - displays PDF output or delivers the processed Excel file to the user (web.show_document)

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialization and Application Session Registration

**Business Description:**
When the calendar report form opens, the system registers the current user's session with the application, recording that the VR_CALNDR form is in use. If application performance logging is active for the session, the system also starts a performance timer so that response times can be monitored. This ensures each user's activity is properly tracked from the moment they open the form.

**Actors:** Application User (any user with access to the VR_CALNDR form)

**Preconditions:**
- The user has successfully authenticated and a valid session context is available.
- Application performance logging may or may not be active for the session.

**Main Flow:**

**Step 1 - Session registered with application tracking**
As the form opens, the system registers the current module name (`vr_calndr`) as the active application session in the database's session tracking facility, so the session is identifiable by administrators and monitoring tools.

**Step 2 - Performance timer started if logging is enabled**
If the session's application logging indicator is set to active, the system starts a performance timer for the session so that the form's overall response time can be recorded for monitoring purposes.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - `GLOBAL.APP_LOG = 'Y'` - When application logging is active, the performance timer is started for the session; otherwise this step is silently skipped.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) Application logging is not active - the performance timer step is not executed; the form continues to open normally with no performance data recorded.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Log Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | `Y` (active) / other (inactive) | Valid session established | Read-only; set before form opens by the session context | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Reset Report Filter Parameters and Reload Filter Lists

**Business Description:**
When the form first opens and when the user chooses to clear and reset the report filter screen, the system prepares the display environment, sets up the report identity fields from the session context, determines the dealer check parameter, resolves the report server name, clears all previously entered filter values, and then rebuilds all dynamic filter selection lists - specifically the Region Code list and the Month/Year list - based on the current user's type and access rights. This ensures the filter screen always presents a clean, correctly populated starting state from the moment the form opens and after each reset.

**Actors:** Application User; System (on form open)

**Preconditions:**
- The form is loading or is already open and a user session is active.
- The application identifier, report description, report name, and report server details are available from the session context.

**Main Flow:**

**Step 1 - Form display environment maximized on initial load**
When the form first opens, the system maximizes the main application window and the form's main window (WN_MAIN) so the full filter screen is presented at full size.

**Step 2 - Report description and report name set from session context**
The report description label and the internal report name field are populated from the session's stored report description and report name values, so the title of the report being configured is displayed correctly from the outset.

**Step 3 - Dealer check parameter set based on application identifier**
The system checks whether the application identifier for the current session matches the VR_CALNDR application. If it does, the dealer check parameter (`PARAMETER.P_CHECK`) is set to 0 to allow the "All Dealers" option; for any other application identifier, it is set to 1 to restrict the selection. This controls whether the dealer selection list will show all dealers or restrict to a specific dealer.

**Step 4 - Report server resolved from configuration table**
The system looks up the report server name for this application and principal from the report configuration table (`eh_reports`). If a configured server name is found it is used; otherwise the session's default report server value is kept. Any database exception (no data found, too many rows, or any other error) leaves the default report server value unchanged.

**Step 5 - Form fields cleared and filter lists rebuilt**
All currently entered filter values on the form are cleared without validation. The system then calls the list-population routine to rebuild the Region Code selection list and the Month/Year selection list based on the current user's type and access rights.

*Procedures called:*
- **POP_LIST** ([SP-002](#SP-002--POP_LIST)) - POP_LIST - determines the current user's type and hierarchy (manufacturer or dealer), resolves the application identifier, loads the dealer's region and location details when applicable, loops through the report's configured parameters, and rebuilds the Region Code and Month/Year selection lists with values appropriate for that user's access level.
    * **Step 1** - Look up the current user's type and organizational level from the user master table to determine whether this is a manufacturer head-office user, a regional office user, or a dealer user.
    * **Step 2** - For dealer users, derive the correct application identifier by stripping any dealer-specific suffix from the global application identifier; for non-dealer users, use the global application identifier directly.
    * **Step 3** - For dealer users whose application identifier cannot be resolved, exit the form immediately as no valid report context exists.
    * **Step 4** - For dealer users, retrieve the dealer's region code, dealer name, location description, parent group code, dealer mapping code, and location code from the dealer location master, first trying the user's primary location record; if that fails, fall back to the session's global dealer and location values. If all lookups fail, the dealer description displays *'DEALER USERS WRONG'*.
    * **Step 5** - Retrieve the list of configurable parameters defined for this report and application from the report parameter configuration table, ordered by their sequence number.
    * **Step 6** - For each configured parameter in sequence: if the parameter is Region Code, make the Region Code field visible, enabled, and navigable, apply the mandatory visual style, and populate its selection list with the authorized regions for the current user; if the parameter is Month/Year, make that field visible, enabled, and navigable, apply the mandatory visual style, and populate its selection list.
    * **Step 7** - For dealer users, disable the dealer description field so it cannot be edited (the dealer's details were loaded automatically in Step 4).

**Step 6 - Cursor positioned on the first active filter field**
After the filter lists are rebuilt, the system navigates the cursor to the Region Code field if it is enabled; otherwise it navigates to the From Date field. This ensures the user can begin entering filter criteria immediately without manually clicking on a field.

**Step 7 - Dealer check parameter set based on user type (on subsequent resets)**
When the user manually resets the filter screen, the same dealer check and list-rebuild sequence (Steps 3-6 above) is repeated to ensure the screen returns to a clean, correctly populated state.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User type resolution | User type lookup - POP_LIST [SP-002] querying AM_USERS | When the form opens or the user initiates a form reset | Determines whether the user is a manufacturer (head-office or regional office) or a dealer, which controls which regions and dealers are shown in the selection lists | If the user type cannot be resolved, user type and organizational level are left blank; the form continues but list population may be incomplete |
| Dealer application identifier resolution | App ID derivation - POP_LIST [SP-002] internal check | When the form opens or resets and user type is dealer | Ensures the correct report application identifier is used for dealer users, stripping any dealer-specific suffix | If the application identifier cannot be resolved after stripping, the form exits immediately - no report parameters can be loaded |
| Dealer location lookup | Dealer location - POP_LIST [SP-002] querying AM_USER_DEALER_MASTER then AM_DEALER_LOC | When the form opens or resets and user type is dealer | Loads the dealer's region, location, and parent group so filter fields are pre-populated correctly | Falls back to session global values for parent group, dealer, and location; if all fail, dealer description displays *'DEALER USERS WRONG'* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Dealer user's application identifier cannot be resolved - the form exits immediately without displaying a message; no report can be run until a valid application context is available.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display | 200 | N/A | Restored from session global report description | Form reset initiated | Read-only; restored from session | N/A |
| Report Name (`CB_BLK.REPORT_NAME`) | Auto-populated | Display | 200 | N/A | Set from session global report name | Form opened | Read-only; set from session | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Text | 100 | Report configuration (`eh_reports`) | Server name for this application and principal | Form opened | Looked up from configuration; falls back to session default on any error | N/A |
| Dealer Check Parameter (`PARAMETER.P_CHECK`) | Auto-populated | Number | 1 | N/A | 0 (all dealers) / 1 (restrict to specific dealer) | Application identifier resolved | Set to 0 when app_id = 'vr_calndr'; set to 1 otherwise | N/A |
| Region Code (`P_REGION_CD`) | Conditional - when configured for this report | List | N/A | Region master (GM_REGN filtered by user access) | Region code and description | Form reset completed | Populated dynamically based on user type and authorized regions | N/A (populated automatically) |
| As On Date / Month-Year (`P_MONTHYEAR`) | Conditional - when configured for this report | List | N/A | Dynamically generated month-year values | Month-year formatted values | Form reset completed | Populated dynamically | N/A (populated automatically) |
| Dealer (`P_DEALER_DESC`) | Conditional - when user is a dealer | Text | 500 | N/A | Loaded from dealer location master | Dealer user type confirmed | Auto-populated and read-only for dealer users | If lookup fails: displays *'DEALER USERS WRONG'* |
| Application Identifier (`APP_ID`) | Auto-populated | Display | 200 | N/A | Derived from session global application identifier | Form reset initiated | System-set; dealer suffix stripped for dealer users | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Region Code Validation and Dependent Filter Reset

**Business Description:**
When the user selects or changes the Region Code filter, the system validates that a region has been chosen and clears all dependent filter fields - such as the dealer description, location description, parent group, dealer code, location code, and hierarchy code - so that any previously selected values that may no longer be valid for the new region are removed. If the user attempts to leave the Region Code field without selecting a value, the system stops the action and prompts the user to enter a region code before continuing.

**Actors:** Application User

**Preconditions:**
- The form filter screen is displayed and the Region Code list has been populated.

**Main Flow:**

**Step 1 - Dependent filter fields cleared on region selection change**
When the user changes their Region Code selection, the system immediately clears the hierarchy code, dealer description, location description, dealer code, location code, and parent group fields. This ensures that any dealer or location values tied to a previously selected region are removed before the user selects new dependent values.

**Step 2 - Region Code validated as not empty on leaving the field**
When the user moves away from the Region Code field, the system checks that a region code has been selected. If the Region Code is empty, the system displays an error message and prevents the user from leaving the field until a valid region is chosen. If a region code is present, the hierarchy code description field is cleared to prepare for a fresh selection.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region Code must not be empty | Mandatory check - WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD trigger's own condition | When the user leaves the Region Code field | Ensures a region is always selected before the user proceeds to other filter fields or submits the report | *"Region Code can not be empty"* is displayed and the user is prevented from leaving the field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Region Code left empty - *"Region Code can not be empty"*; the cursor remains on the Region Code field and the user must select a region before continuing.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region Code (`P_REGION_CD`) | Mandatory | List | N/A | Region master (GM_REGN filtered by user access) | Region code | Filter lists loaded | Must not be left empty | *"Region Code can not be empty"* |
| Hierarchy / For Code (`P_FOR_CD`) | Auto-populated | Text | N/A | N/A | Cleared automatically on region change | Region Code selected | Cleared by system when region changes | N/A |
| Dealer (`P_DEALER_DESC`) | Conditional - for dealer users | Text | 500 | Dealer location master (AM_DEALER_LOC) | Dealer name | N/A | Cleared by system when region changes | N/A |
| Location Description (`LOC_DESC`) | Auto-populated | Text | 500 | N/A | Cleared automatically | N/A | Cleared by system when region changes | N/A |
| Dealer Code (`P_DEALER`) | Auto-populated | Number | 5 | N/A | Cleared automatically | N/A | Cleared by system when region changes | N/A |
| Location Code (`P_LOC`) | Auto-populated | Text | N/A | N/A | Cleared automatically | N/A | Cleared by system when region changes | N/A |
| Parent Group (`P_PARENT`) | Auto-populated | Text | N/A | N/A | Cleared automatically | N/A | Cleared by system when region changes | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Report Destination Type Selection and Output Format Derivation

**Business Description:**
When the user changes the report delivery destination (for example, choosing to send the report to a printer, save it to a file, or export it as a spreadsheet), the system automatically sets the default output format to match the chosen destination. Specifically, selecting the printer destination fixes the format as character output and locks the format field so it cannot be changed; any other destination sets the format to PDF and allows the user to adjust it further if needed. This ensures the output format is always compatible with the chosen delivery method.

**Actors:** Application User

**Preconditions:**
- The form filter screen is open and the Destination selection list is displayed.

**Main Flow:**

**Step 1 - Output format set and format field enabled or locked based on destination choice**
When the user changes the Destination selection, the system checks the selected destination. If the destination is Printer, the Format field is automatically set to character output (`CHAR`) and disabled so the user cannot change it - printer output requires a fixed character format. For any other destination, the Format field is set to PDF and enabled so the user can select a different format if desired.

**Business Scenarios - How output format differs by destination type**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Printer** | Format automatically set to `CHAR`; Format field disabled - user cannot change it |
| **Cache, File, or Mail** | Format automatically set to PDF; Format field enabled - user can change it |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Destination (`P_DESTYPE`) | Mandatory | List | N/A | N/A | PRINTER / CACHE / FILE / MAIL / EXCEL | Form displayed | Required; must be selected before submitting | N/A |
| Format (`P_DESFORMAT`) | Auto-populated | List | N/A | N/A | CHAR (when Printer) / PDF (other destinations) | Destination selected | Auto-set by system based on Destination; editable unless Printer is selected | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Output Format Selection and File Name Field Control

**Business Description:**
When the user selects or changes the output format, the system controls whether the file name field is available for entry. If the Excel format is chosen, the file name field is cleared, enabled, and made navigable so the user can specify the output file name. For any other format, the file name field is cleared and locked so no file name can be entered - the system will generate the output file name automatically. Similarly, whenever the cursor moves to the file name field, the system checks the selected format and allows editing only when the Excel format is active.

**Actors:** Application User

**Preconditions:**
- The form filter screen is open, the Destination has been selected, and the Format field is displayed.

**Main Flow:**

**Step 1 - File name field enabled or locked based on format selection**
When the user changes the Format selection, the system checks the chosen format. If the format is not Excel, the file name field is cleared and locked so it cannot be entered. If the format is Excel, the file name field is enabled and made navigable so the user can type a file name.

**Step 2 - File name field edit rights confirmed when cursor arrives**
When the cursor moves into the file name field, the system re-checks the currently selected format. If the format is Excel, insert and update access to the file name field are granted. If the format is anything other than Excel, insert and update access are denied - the field cannot be edited.

**Business Scenarios - How the file name field behaves by format**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Excel format selected** | File name field is enabled and navigable; user can enter a custom file name |
| **Any other format selected** | File name field is cleared and locked; the system generates the output file name automatically |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Format (`P_DESFORMAT`) | Auto-populated | List | N/A | N/A | N/A | Destination selected | Controls File Name field availability | N/A |
| File Name (`FILENAME`) | Conditional - when Excel format is selected | Text | 4000 | N/A | User-entered file name | Excel format selected | Enabled and editable only when Excel is the selected format; locked otherwise | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Report Parameter Assembly and Report Submission

**Business Description:**
When the user clicks the Submit Report button, the system assembles the full set of report parameters based on the filters the user has entered and the user's type (dealer or non-dealer), configures the report to be delivered in the chosen format and destination, and submits the report for processing. For PDF output, the generated report file is immediately opened in a new browser tab for the user to view. For Excel output, the generated file is post-processed to remove non-printable characters and then opened in a new browser tab. The system tailors the parameter set to ensure the correct dealer, region, program, and date range values are passed to the report engine.

**Actors:** Application User

**Preconditions:**
- The filter screen is displayed with the required filter values entered.
- A valid output destination and format have been selected.

**Main Flow:**

**Step 1 - User identity parameters resolved for the report title**
When the user clicks Submit Report, the system first determines the user type. For dealer users, the system copies the current dealer's parent group, location, and dealer code into the report title parameters. For non-dealer users, the system uses the session's global parent group, location, dealer, and user type values as the report title parameters.

**Step 2 - Report parameters assembled from configured filter fields**
The system calls the parameter assembly routine, which reads the list of parameters configured for this report and application from the parameter configuration table, and builds a parameter string containing the Region Code, dealer type indicator, program code, from date, to date, and the principal (manufacturer) code. This parameter string is passed to the report engine.

*Procedures called:*
- **PR_PASS_PARAM** ([SP-003](#SP-003--PR_PASS_PARAM)) - PR_PASS_PARAM - reads the report's configured parameter definitions from the parameter configuration table, then assembles the final parameter string by appending the Region Code, dealer type indicator, program identifier, from date, to date, and principal code in the sequence the report engine expects.
    * **Step 1** - Retrieve the list of parameter definitions for this report and application, ordered by sequence number.
    * **Step 2** - For the VR_CALNDR application, capture the from date and to date values directly from the filter fields entered by the user.
    * **Step 3** - For each configured parameter in the sequence: if the parameter is the dealer type indicator, append the dealer type flag and program code to the parameter string; if the parameter is Region Code, append the selected region code.
    * **Step 4** - Unconditionally append the from date, to date, program code, and principal code to the parameter string so these values are always passed to the report regardless of the parameter configuration loop.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Parameter assembly from report configuration | Parameter lookup - PR_PASS_PARAM [SP-003] querying ED_REPORTS | When the user clicks Submit Report | Ensures the correct set of filter parameter values is assembled based on the report's own configuration, so the report engine receives valid and complete filter criteria | If parameter retrieval fails, the parameter string may be incomplete; no explicit error is displayed - the report runs with whatever parameters were assembled |

**Step 3 - Report object configured for the chosen destination and format**
The system locates the report object and sets its delivery destination (cache, printer, file, or mail) based on the user's Destination selection. For all destinations other than Excel, the format is set to PDF, the delivery mode is set to file, and additional rendering options are applied. For Excel, the format is set to wide character delimited output and delivery mode is set to file.

**Step 4 - Report submitted and output delivered to the user**
For PDF output: the system constructs a unique output file name from the user's login identifier and the current date and time, submits the report to the report server, and opens the resulting PDF file in a new browser tab.

For Excel output: the system constructs a unique output file name, submits the report to the report server, and then calls the character-cleanup routine to remove non-printable characters from the raw CSV output before opening the cleaned file in a new browser tab.

*Procedures called:*
- **PR_REMOVE_ASCII_CHR** ([SP-004](#SP-004--PR_REMOVE_ASCII_CHR)) - PR_REMOVE_ASCII_CHR - used only on the Excel output path; reads the raw report output file line by line, writes each line to a new output file while skipping lines that begin with a form-feed character, then opens the cleaned output file in a new browser tab. On any read or write error, exits the loop and closes both files. If an unexpected exception occurs, displays a note message containing the error code and error text.
    * **Step 1** - Open the raw report output file for reading and a new output file for writing.
    * **Step 2** - Read the raw file line by line; for each line, if it does not begin with a form-feed character, write it to the output file.
    * **Step 3** - On reaching the end of the file or encountering any read error, stop the loop and close both files.
    * **Step 4** - Open the cleaned output file in a new browser tab so the user can download or view it.
    * **Step 5** - If an unexpected exception occurs at any point, display a note message showing the database error code and error text combined (dynamic message - the system's own error code concatenated with the system's own error text), then stop.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Excel output file cleanup | File read/write - PR_REMOVE_ASCII_CHR [SP-004] processing the raw output file | After the Excel report has been generated by the report server | Ensures the Excel output file is clean (no form-feed or non-printable characters) before it is presented to the user | On unexpected file I/O exception: a note message is displayed showing the database error code concatenated with the system's own error text; both files are closed and the routine stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-SM-01** - PDF report generated successfully - the report PDF file is opened in a new browser tab for the user to view or download.
- **BR-006-SM-02** - Excel report generated and cleaned successfully - the cleaned CSV file is opened in a new browser tab for the user to view or download.
- **BR-006-ES-01** - Excel file cleanup encounters an unexpected exception - the system displays a note containing the database error code concatenated with the system's own error message text (dynamic); both output files are closed and the routine stops.

**Business Scenarios - How report generation differs by output format**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **PDF output** | Report rendered in PDF bitmap mode with blank pages suppressed; output file opened directly in a new browser tab |
| **Excel output** | Report rendered in wide-delimited character mode; raw output file post-processed to strip form-feed characters; cleaned file opened in a new browser tab |
| **Printer output** | Report delivery set to printer mode; output is sent to the printer rather than a browser tab |
| **Mail output** | Report delivery set to mail mode; report is dispatched by the report server; no browser tab is opened |
| **Cache output** | Report delivery set to cache mode; output is held in the server cache |

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 3) Destination is Printer - the report destination is set to printer mode; output is sent directly to the printer; no file is generated and no browser tab is opened.
- **BR-006-AF-02** - (from Step 3) Destination is Mail - the report destination is set to mail delivery mode; the report is dispatched by the report server to the configured mail address; no browser tab is opened.
- **BR-006-AF-03** - (from Step 3) Destination is Cache - the report destination is set to cache mode; output is held in the server cache rather than written to a file.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region Code (`P_REGION_CD`) | Mandatory | List | N/A | Region master (GM_REGN) | Region code | Filter lists loaded | Included in report parameter string | N/A |
| Program ID (`P_PROGRAM_CD`) | Optional | Text | 500 | Program sessions (LOV_PRG_SES -> RG_PRG_SES) | Program code | Region Code selected | Included in report parameter string | N/A |
| From Date (`P_FRM_DT`) | Optional | Date | 11 / DD-MM-RRRR | N/A | Date value | N/A | Must be a valid date in DD-MM-YYYY format | *"Entered Date is not valid Date"* or *"Enter the Date in the proper format (DD-MM-YYYY)"* via centralized error handler |
| To Date (`P_TO_DT`) | Optional | Date | 11 / DD-MM-RRRR | N/A | Date value | N/A | Must be a valid date in DD-MM-YYYY format | *"Entered Date is not valid Date"* or *"Enter the Date in the proper format (DD-MM-YYYY)"* via centralized error handler |
| Destination (`P_DESTYPE`) | Mandatory | List | N/A | N/A | PRINTER / CACHE / FILE / MAIL / EXCEL | Form displayed | Must be selected before submitting | N/A |
| Format (`P_DESFORMAT`) | Mandatory | List | N/A | N/A | PDF / CHAR / wided | Destination selected | Auto-set by system; must be valid for the chosen destination | N/A |
| File Name (`FILENAME`) | Auto-populated | Text | 4000 | N/A | System-generated (user ID + timestamp + extension) | Report submitted | Generated by system; user-editable only for Excel | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Centralized Error Handling and User-Friendly Error Display

**Business Description:**
The form intercepts all system errors before they are displayed and translates them into meaningful, user-friendly messages. Depending on the type of error encountered, the system shows one of several specific messages - for example, notifying the user that a date entry is invalid, that the date format is incorrect, that non-numeric characters have been entered in a numeric field, or that the record they are trying to modify has been updated by another user. For database integrity errors (such as attempting to delete a record that other records still depend on), the system displays a standard integrity violation message. Any other unexpected database error is shown using the database's own error description. Additionally, certain informational messages (such as those for query record-count notifications) are silently suppressed rather than displayed to the user.

**Actors:** System (no direct user action; fires automatically when an error occurs)

**Preconditions:**
- The form is open and any form action triggers a system error.

**Main Flow:**

**Step 1 - Invalid date entry error handled**
If the error is triggered because a date value entered by the user is not a valid date, the system displays the message *"Entered Date is not valid Date"* and prevents further processing on that field.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level, presenting it as a modal error notification on the screen.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date value validity (error code 50004) | ON-ERROR form trigger, checks error code 50004 | When the system encounters error code 50004 during any field interaction | Ensures the user is told clearly that the date they entered is not a valid date | *"Entered Date is not valid Date"*; processing is stopped on the current field |

**Step 2 - Incorrect date format error handled**
If the error is triggered because a date value is in the wrong format, the system displays the message *"Enter the Date in the proper format (DD-MM-YYYY)"* and prevents further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date format check (error codes 50025 and 50026) | ON-ERROR form trigger, checks error codes 50025 and 50026 | When the system encounters a date format error | Ensures the user is given the correct date format requirement | *"Enter the Date in the proper format (DD-MM-YYYY)"*; processing is stopped |

**Step 3 - Non-numeric character entry error handled**
If the user enters a character or special character in a field that only accepts numeric values, the system displays the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and prevents further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric-only field check (error codes 40209 and 50016) | ON-ERROR form trigger, checks error codes 40209 and 50016 | When the user enters a non-numeric character in a numeric-only field | Guides the user to correct their entry by providing a clear instruction to enter only numeric values | *"Characters/Special Characters are not allowed here, enter the numeric value"*; processing is stopped |

**Step 4 - Maximum-length field violation error handled**
If the user enters more characters than a field allows, the system displays the original system error text and prevents further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Maximum field length exceeded (error code 40207) | ON-ERROR form trigger, checks error code 40207 | When the user exceeds a field's maximum length | Shows the system's own error description so the user understands the field limit has been exceeded | The original system error text is displayed; processing is stopped |

**Step 5 - Database integrity constraint violation handled**
If a database action fails because it would violate a referential integrity rule (for example, attempting to delete a parent record that child records still reference), the system invokes the standard integrity error message routine.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-006](#SP-006--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - looks up the business message registered under the given error code and displays it to the user as a standard integrity violation notification.
    * **Step 1** - Receive the error code identifier to look up.
    * **Step 2** - Retrieve the registered business message text for the given error code from the error message catalogue.
    * **Step 3** - Display the message to the user as a standard error notification.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity constraint (database error -02292) | ON-ERROR form trigger, checks DBMS_ERROR_CODE = -02292; calls GENERAL.RAISE_ERROR [SP-006] with error code 'E0088' | When a database operation fails due to a child record constraint | Presents a business-friendly integrity violation message rather than a raw database error code | The registered business message for error code 'E0088' is displayed to the user |

**Step 6 - Concurrent record modification conflict handled**
If a record being saved has already been modified by another user, the system displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any pending changes, and stops further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update conflict (error codes 40654-40659) | ON-ERROR form trigger, checks ERROR_CODE IN (40654,40655,40656,40657,40659) | When the system detects that a record has been modified by another user since it was last queried | Prevents overwriting another user's changes and instructs the user to refresh the record before making further changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; pending changes are rolled back; processing is stopped |

**Step 7 - Unexpected database error handled**
For any other unexpected database error, the system displays the database engine's own error description text, rolls back any pending changes, and stops further processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the provided message text to the user using the error severity level.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Catch-all database error (SQLCODE <> 0) | ON-ERROR form trigger, checks if SQLCODE is not zero | When any unexpected database error is raised | Ensures no database error goes silently unnoticed; the user always sees the database's own error description | The database's own error message text is displayed (dynamic - the system's own error text); pending changes are rolled back; processing is stopped |

**Step 8 - Informational platform messages silently suppressed**
Certain platform information messages (record count notifications at error codes 40401 and 40405) are intercepted and silently ignored - no message is shown to the user.

**Step 9 - ON-MESSAGE interception for formatting consistency**
The form's message interception trigger intercepts any platform message where the error number is 40209 or 40207, and re-displays it in the same error format used by the error handler, then stops further platform message processing.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the formatted error-type message to the user.
    * **Step 1** - Receive the message text and severity level to be displayed.
    * **Step 2** - Present the message to the user as a modal notification at the specified severity level.
    * **Step 3** - Return control to the calling code after the user acknowledges the message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Platform message re-formatting (error codes 40209 and 40207) | ON-MESSAGE form trigger, checks error numbers 40209 and 40207 | When the platform generates an informational message with these codes | Ensures these platform messages are displayed in the standard error format rather than as plain informational pop-ups, keeping the user experience consistent | The message is re-displayed in error format (error type + code + text); processing is stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Invalid date value - *"Entered Date is not valid Date"*; processing stopped on the current field.
- **BR-007-ES-02** - Incorrect date format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; processing stopped.
- **BR-007-ES-03** - Non-numeric character in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; processing stopped.
- **BR-007-ES-04** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back; processing stopped.
- **BR-007-ES-05** - Unexpected database error - the database's own error message text is displayed (dynamic); changes rolled back; processing stopped.
- **BR-007-ES-06** - Referential integrity violation - the registered business message for integrity error code 'E0088' is displayed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Error Code (`ERROR_CODE`) | Auto-populated | Number | N/A | N/A | System-generated error code | Any form action that triggers an error | Read-only system value; used to select the appropriate error message | N/A |
| Database Error Code (`DBMS_ERROR_CODE`) | Auto-populated | Number | N/A | N/A | System-generated database error code | Any form action that causes a database error | Read-only system value; checked for integrity constraint code | N/A |
| Error Text (`ERROR_TEXT`) | Auto-populated | Text | 200 | N/A | System-generated error description | Any form error | Read-only system value; displayed for certain error codes | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Form Exit with Session Cleanup

**Business Description:**
When the user chooses to exit the form, the system clears all session tracking information that was registered when the form opened - removing the application name and module details from the session record - and then closes the form immediately without performing any validation or saving any pending changes. This ensures the session tracking record is left in a clean state and no unintended data saves occur on exit.

**Actors:** Application User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Session tracking information cleared**
When the user initiates an exit, the system clears the client information stored in the database session record (setting it to null) and also clears the module name and action name that were recorded when the form opened, leaving the session tracking data blank.

**Step 2 - Form closed without validation**
The form is immediately closed without performing any field validation or committing any unsaved changes. Any data the user may have entered or changed is discarded.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Session Client Info (`GLOBAL.USERID` context) | Auto-populated | Character | N/A | N/A | Cleared to null on exit | Form is open | System-managed; cleared automatically on exit | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Form Save Action Disabled (Non-Executing)

**Business Description:**
The standard form save action has been deliberately disabled in this form. Pressing the keyboard shortcut that would normally commit and save data has no effect - the form takes no action. This is intentional because the VR_CALNDR form is a report filter screen and does not manage persistent records that need to be saved.

**Actors:** Application User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Save action intercepted and suppressed (COMMENTED OUT / INACTIVE - does not execute)**
The KEY-COMMIT trigger is present in the form but contains only a no-operation statement. It does not perform any save, commit, validation, or data action. No data is ever saved or committed through this trigger.


---

---

#### Requirement ID: BR-010

**Requirement Title:** Validate Main Canvas Fields - Pre-submission Checks (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
The form contains a program unit intended to validate several mandatory fields on the main filter canvas before a record is submitted. This includes checks for plate number, model year, test drive date, test drive times, location, sales consultant, and odometer readings. This program unit is entirely commented out and does not execute; none of these validations are active in the current version of the form.

**Actors:** N/A (does not execute)

**Preconditions:**
- N/A

**Main Flow:**

**Step 1 - All field validations suppressed (COMMENTED OUT / INACTIVE - does not execute)**
The VALIDATE_CN_MAIN program unit body is fully commented out. No field is validated, no message is displayed, and no error is raised. The program unit terminates silently with a no-operation statement.

---

---

#### Requirement ID: BR-011

**Requirement Title:** Check Before Record Deletion (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
The form contains a program unit intended to prevent deletion of a zone master record when enquiry records still reference it. The program unit would query the enquiry table for matching records and block the deletion with an error message if any were found. This program unit is entirely commented out and does not execute; the deletion check is not active in the current version of the form.

**Actors:** N/A (does not execute)

**Preconditions:**
- N/A

**Main Flow:**

**Step 1 - Deletion check suppressed (COMMENTED OUT / INACTIVE - does not execute)**
The CHECK_BEFORE_DELETE program unit body is fully commented out. No database query is executed, no records are checked, and no deletion block is applied.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Toolbar Button Action Governance

**Business Description:**
The form provides a standard toolbar of action buttons - Save, Cancel, Insert, Delete, List, and Print - whose active behaviour is governed centrally. The Save button commits any pending changes and then clears the form. The Cancel button checks whether unsaved changes exist: if changes are present, the user is asked to confirm before the form is cleared without saving; if no changes are present, the form is cleared immediately without prompting. The Insert button is disabled for this form and displays an informational error when pressed. The Delete button, when the cursor is on the program master data block, asks the user to confirm before permanently deleting the current record. The List and Print buttons invoke the standard list-of-values and print actions respectively, with no custom business logic applied.

**Actors:** Application User

**Preconditions:**
- The form is open and the toolbar is displayed.

**Main Flow:**

**Step 1 - Save button: pending changes committed and form cleared**
When the user clicks the Save toolbar button, the system commits all pending changes to the database and then clears the form, leaving it ready for a new entry. No confirmation prompt is shown before the commit.

**Step 2 - Cancel button: unsaved changes checked before clearing form**
When the user clicks the Cancel toolbar button and the Cancel button is currently enabled, the system checks whether there are unsaved changes on the form. If the form status is CHANGED, the user is presented with a confirmation alert asking *"Entered data will not be Saved"*. If the user confirms (selects button 1 on the alert), the form is cleared without saving. If the user does not confirm, no action is taken. If the form status is not CHANGED (no pending changes), the form is cleared immediately without any confirmation prompt.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes guard | FT_CANCEL toolbar trigger; checks SYSTEM.FORM_STATUS = 'CHANGED'; calls GENERAL.ASK_CONFIRM | When the user clicks Cancel and the Cancel button is enabled | Prevents accidental loss of data by confirming with the user before discarding unsaved changes | If the user confirms: form is cleared without saving. If user cancels the prompt: no action taken. If Cancel button is disabled: no action taken. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-WS-01** - Unsaved changes present - confirmation alert *"Entered data will not be Saved"* is shown; user must confirm to discard changes.
- **BR-012-SM-01** - No unsaved changes, or user confirmed discard - the form is cleared and reset to its initial state.

**Step 3 - Insert button: operation blocked on this form**
When the user clicks the Insert toolbar button and the Insert button is currently enabled, the system displays the error message *"This Operation Cannot be performed Here"* and takes no further action. The Insert operation is not supported on this form because it is a report filter screen, not a data entry form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert operation disabled | FT_INSERT toolbar trigger; checks PB_BLK.PB_INSERT ENABLED = 'TRUE'; calls GENERAL.DISP_TEXT with 'Error' severity | When the user clicks the Insert toolbar button | Prevents the user from attempting to insert a record on a report filter form where data insertion is not applicable | *"This Operation Cannot be performed Here"*; no insert action is performed |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Insert attempted on this form - *"This Operation Cannot be performed Here"*; insert is blocked and no record is created.

**Step 4 - Delete button: deletion confirmed before record is removed**
When the user clicks the Delete toolbar button and the Delete button is currently enabled and the cursor is positioned on the program master data block (`B_GM_PROGRAM_MASTER`), the system temporarily suspends form-level validation, navigates to the program master block, and presents a confirmation alert asking *"Are you sure to Delete?"*. If the user confirms (selects button 1 on the alert), the current record is deleted. After the deletion attempt, form-level validation is re-enabled regardless of the outcome. If the Delete button is not enabled or the cursor is not on the program master block, no action is taken.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete confirmation guard | FT_DEL toolbar trigger; checks PB_BLK.PB_DEL ENABLED = 'TRUE' AND SYSTEM.CURSOR_BLOCK = 'B_GM_PROGRAM_MASTER'; calls GENERAL.ASK_CONFIRM | When the user clicks the Delete toolbar button with the cursor on the program master block | Prevents accidental deletion of program master records by requiring explicit user confirmation before the record is removed | If the user confirms: the current record is deleted. If the user does not confirm: no deletion occurs. If the button is not enabled or cursor is on a different block: no action is taken. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-WS-02** - Delete requested on program master block - confirmation alert *"Are you sure to Delete?"* is shown; user must confirm to proceed.
- **BR-012-SM-02** - User confirmed deletion - the current program master record is permanently deleted from the database.
- **BR-012-IC-01** - Delete button not enabled, or cursor not on program master block - no action is taken.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 2) Cancel button is not enabled - no action is taken; the button press has no effect.
- **BR-012-AF-02** - (from Step 3) Insert button is not enabled - no action is taken; the button press has no effect.
- **BR-012-AF-03** - (from Step 4) Delete button is not enabled or cursor is not on the program master block - no action is taken; the button press has no effect.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Form Status (`SYSTEM.FORM_STATUS`) | Auto-populated | System | N/A | N/A | CHANGED / QUERY / NEW | Form is open | Read-only system value; used by Cancel button to detect unsaved changes | N/A |
| Cursor Block (`SYSTEM.CURSOR_BLOCK`) | Auto-populated | System | N/A | N/A | Current data block name | Form is open | Read-only system value; used by Delete button to guard against deletion on wrong block | N/A |

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Region Code is mandatory | Validation | BR-003 | The user leaves the Region Code field without selecting a region | Block navigation away from the field and display *"Region Code can not be empty"* | Prevents report submission with a missing region, ensuring all reports are always scoped to a specific region |
| BRC-002 | Date must be entered in the required format | Validation | BR-006, BR-007 | A date field entry cannot be parsed because it is in the wrong format | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and stop processing | Ensures users always enter dates in the format the report engine expects, avoiding silent misinterpretation of date values |
| BRC-003 | Date value must be a valid calendar date | Validation | BR-006, BR-007 | A date field entry is syntactically formatted but is not a valid calendar date | Display *"Entered Date is not valid Date"* and stop processing | Prevents invalid dates (such as 31 February) from being passed to the report engine |
| BRC-004 | Numeric fields accept only numeric input | Validation | BR-007 | A non-numeric character or special character is entered in a field that only accepts numeric values | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and stop processing | Protects numeric data fields from incorrect entry types, preventing downstream calculation or conversion errors |
| BRC-005 | Records modified by another user must be re-queried before changes are saved | Constraint | BR-007 | A save action detects that the record has already been changed by another user since it was last loaded on screen | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and stop processing | Prevents one user's changes from silently overwriting another user's concurrent updates |
| BRC-006 | Referential integrity must not be violated | Constraint | BR-007 | A database action fails because it would violate a child record dependency (database constraint violation) | Invoke the standard integrity violation message for error code 'E0088' | Prevents orphaned or inconsistent database records by blocking operations that would break referential integrity |
| BRC-007 | Dealer users must have a resolvable application identifier | Authorization | BR-002 | A dealer user's application identifier cannot be resolved from the session context | Exit the form immediately without displaying an error message | Ensures dealer users can only access a report form for which a valid application context exists; prevents report submission with an unknown application |
| BRC-008 | Printer destination forces character output format | Derivation | BR-004 | The user selects Printer as the report delivery destination | Automatically set Format to character output and disable the Format field so it cannot be changed | Ensures printer output is always generated in the character format required by the printer driver; avoids incompatible format/destination combinations |
| BRC-009 | File name entry is available only for Excel format | Constraint | BR-005 | The user selects a format other than Excel | Clear the File Name field and lock it so no file name can be entered | Prevents users from entering a file name that would be ignored for non-Excel output; the system generates the file name automatically for PDF and other formats |
| BRC-010 | Dealer users' region and location details are auto-populated and locked | Derivation | BR-002 | The logged-in user is identified as a dealer user | Load the dealer's region, location, parent group, and dealer details from the dealer master and disable the dealer description field | Ensures dealer users always report on their own assigned region and location; prevents dealer users from selecting filters outside their authorized scope |

**Total Business Rules Identified: 10**

---

## 6. Data Requirements

*This section covers the reference entities the VR_CALNDR form reads to populate its filter lists, the filter parameters the user captures on screen, the reference data lookups for regions, programs, and dealers, and the lifecycle of the report parameter entry session.*

### 6.1 Business Entities and Relationships

*The VR_CALNDR form does not manage a directly persisted data entity - its single block has no database base table. Instead it reads from several supporting entities to resolve the current user's access rights and to populate the available filter choices.*

#### Report Parameter Configuration - ED_REPORTS

The report parameter configuration table defines which filter parameters are active for each report and application. The form reads this table to determine which filter fields to display on screen and to assemble the parameter string passed to the report engine. Each row defines one configurable parameter by name, type, default value, and data type, keyed by application identifier and principal (manufacturer) code.

#### User Account Master - AM_USERS

The user account master records each application user's type (manufacturer or dealer) and organizational level (head-office or regional office). The form reads this table once at startup to determine which filter options and data ranges are available to the current user.

#### Dealer Location Master - AM_DEALER_LOC

The dealer location master stores each dealer outlet's region code, dealer name, location description, parent group code, dealer mapping code, and location code. The form reads this table for dealer users to pre-populate their region and location filter fields automatically.

#### User-Dealer Assignment - AM_USER_DEALER_MASTER

The user-to-dealer assignment table links each application user to their primary dealer outlet. The form reads this table first (using the user's primary location indicator) to resolve the dealer's region and location details; if no primary location is found, it falls back to the session's global dealer and location values from AM_DEALER_LOC.

#### Region Master - GM_REGN

The region master holds the description and code for each geographic region. The form reads this table to populate the Region Code selection list, filtering the rows by the current user's authorized regions and the current principal (manufacturer) code.

#### List Master - AM_LIST

The list master stores configurable enumeration lists (name-code pairs) grouped by list name and principal code. The form reads this table when populating certain dynamic list fields based on list name lookup.

#### Entity Relationships

The VR_CALNDR form reads from multiple supporting reference tables; the central access relationship is through the user's identity. The user account master identifies the user's type and level; for dealer users, their primary dealer outlet is resolved through the user-dealer assignment table to the dealer location master; the region master provides the region description for the authorized region codes. The report parameter configuration table is keyed independently by application identifier and principal code.

```
AM_USERS (User Account Master)
        └── AM_USER_DEALER_MASTER (User-Dealer Assignment)
                └── AM_DEALER_LOC (Dealer Location Master)
                        └── GM_REGN (Region Master)   <- region_cd join
```

ED_REPORTS (Report Parameter Configuration) - standalone; keyed by application identifier and principal code, not by user or dealer hierarchy.

AM_LIST (List Master) - standalone; keyed by list name and principal code.

### 6.2 Data Capture Requirements

*The VR_CALNDR form captures report filter parameters entered by the user. All fields belong to a single non-database control block. Mandatory status is controlled dynamically by the report parameter configuration for each application.*

#### Report Filter Parameters (User - at form entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Region Code (`P_REGION_CD`) | Conditional | The geographic region for which the report is to be generated. Displayed as a selectable list populated from the authorized regions for the current user. | Must not be left empty when displayed; error *"Region Code can not be empty"* if the user attempts to leave the field without selecting a value |
| As On Date / Month-Year (`P_MONTHYEAR`) | Conditional | The reporting month and year. Displayed as a selectable list when configured for the report. | No user-entered validation; populated by the system from configured list values |
| Program ID (`P_PROGRAM_CD`) | No | The training program identifier to filter the calendar report. The user may select a program from the associated lookup list. | No mandatory validation enforced by the form |
| From Date (`P_FRM_DT`) | No | The start date of the reporting period. Format expected: DD-MM-YYYY. | Must be a valid calendar date in DD-MM-YYYY format; error *"Entered Date is not valid Date"* for invalid dates and *"Enter the Date in the proper format (DD-MM-YYYY)"* for format errors |
| To Date (`P_TO_DT`) | No | The end date of the reporting period. Format expected: DD-MM-YYYY. | Must be a valid calendar date in DD-MM-YYYY format; same error messages as From Date |
| Destination (`P_DESTYPE`) | Yes | The report delivery destination chosen by the user (Printer, Cache, File, Mail, or Excel). | Required; must be selected before report submission |
| Format (`P_DESFORMAT`) | Yes | The output format for the report (PDF, CHAR, or wide-delimited). Auto-set by the system based on the Destination selection. | Automatically set to CHAR when Printer is selected and locked; set to PDF for other destinations; editable unless Printer is selected |
| File Name (`FILENAME`) | Conditional | The output file name for the report. Enabled only when Excel format is selected; the system generates the file name automatically for other formats. | Editable only when Excel is the selected output format |

#### Session and Control Parameters (System - loaded at startup)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Report Description (`REPORT_DESC`) | Auto-Populated | Display label showing the name/description of the report being configured. Restored from session on form reset. | Read-only; system-populated |
| Application Identifier (`APP_ID`) | Auto-Populated | The identifier of the report application being run. Derived from the session context; for dealer users, any dealer-specific suffix is stripped. | System-set; must be resolvable for dealer users - if not, the form exits |
| Dealer (`P_DEALER_DESC`) | Auto-Populated | The name of the dealer outlet associated with the logged-in dealer user. Loaded from the dealer location master. | Auto-populated and locked for dealer users; not editable |
| Location Description (`LOC_DESC`) | Auto-Populated | The description of the dealer location. Loaded automatically for dealer users. | Auto-populated |
| Dealer Code (`P_DEALER`) | Auto-Populated | The numeric code identifying the dealer mapping. Loaded automatically for dealer users. | Auto-populated |
| Location Code (`P_LOC`) | Auto-Populated | The location code of the dealer outlet. Loaded automatically for dealer users. | Auto-populated |
| Parent Group (`P_PARENT`) | Auto-Populated | The parent group code of the dealer. Loaded automatically for dealer users. | Auto-populated |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form to populate filter lists and resolve user identity.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Region list (GM_REGN + AM_USER_REGION - EXTERNAL / NOT IN BUNDLE for AM_USER_REGION) | Provides the list of authorized geographic regions for the current user to choose from in the Region Code filter | When the filter lists are populated at form startup or reset; filtered by user type and authorized regions |
| Report parameter configuration (ED_REPORTS) | Defines which filter parameters are active for the current report and application, their display sequence, and data types | When the filter screen is initialized or reset; drives which fields are shown and which parameter names are included in the report parameter string |
| User account master (AM_USERS) | Identifies the current user's type (manufacturer or dealer) and organizational level | At form startup and reset; determines which filter options and data ranges are available |
| Dealer location master (AM_DEALER_LOC) | Provides the dealer's region, location, dealer name, and codes for dealer users | At form startup and reset when the user is identified as a dealer; auto-populates dealer filter fields |
| User-dealer assignment (AM_USER_DEALER_MASTER) | Links the application user to their primary dealer outlet and location | At form startup for dealer users; used to resolve the user's primary location before falling back to session globals |
| List master (AM_LIST) | Provides configurable name-code pairs for dynamic list fields keyed by list name and principal code | When populating dynamic list fields during filter initialization |
| Program sessions lookup (RG_PRG_SES - record group from VM_TRA_PROGRAM_MASTER and VM_CALNDR) | Provides the list of training program codes and names for the Program ID field, filtered by the selected region and principal code | When the user opens the Program ID field lookup (LOV_PRG_SES); dependent on Region Code selection |
| Dealer lookup (LV_DEALER - record group RG_DEALER from AM_DEALER_LOC) | Provides the list of available dealers and locations filtered by the selected region, dealer type (2S/3S), and principal code; includes an 'All Dealers' option for non-dealer users when the check parameter allows it | When the user opens the Dealer lookup (LV_DEALER); dependent on Region Code selection |

### 6.4 Data Lifecycle

*Describes how report filter parameters are managed within the VR_CALNDR form's session.*

**Creation**

- Report filter parameters are not persisted to any database table; the form block (CB_BLK) has no database base table and all items are session-only fields.
- Filter list contents (Region Code, Month/Year) are created dynamically in memory at form startup and on each form reset, driven by the KEY-CLRFRM trigger calling POP_LIST and the list population routines.
- For dealer users, the dealer's region, location, and parent group are loaded from AM_USER_DEALER_MASTER and AM_DEALER_LOC at startup and on reset.

**Updates**

- Filter field values are updated each time the user selects or changes a list selection or types in a text field.
- When the Region Code selection changes, the WHEN-LIST-CHANGED trigger on P_REGION_CD clears all dependent filter fields (hierarchy code, dealer, location, dealer code, parent group) immediately.
- When the Destination selection changes, the WHEN-LIST-CHANGED trigger on P_DESTYPE automatically updates the Format field and its enabled state.
- When the Format selection changes, the WHEN-LIST-CHANGED trigger on P_DESFORMAT controls the enabled state of the File Name field.

**Save and Commit**

- The VR_CALNDR form does not save or commit any records. The KEY-COMMIT trigger is inactive (contains only a no-operation statement). No data is ever written to the database by user-initiated save actions.
- The only database interaction is read-only: the form reads from reference tables (GM_REGN, ED_REPORTS, AM_USERS, AM_USER_DEALER_MASTER, AM_DEALER_LOC, AM_LIST) to populate lists and resolve user identity.
- Report submission (WHEN-BUTTON-PRESSED on the Submit Report button) invokes the report server via the Oracle Reports API; this is a user-initiated action, not a database commit.

**Retention and Audit**

- No audit stamps or modification tracking are maintained by this form; all filter values are session-only and are discarded when the form is cleared or closed.
- No record creation, modification, or deletion timestamps are written by this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer Location master table - stores dealer name, region code, parent group, location code, and dealer type for each outlet | - | AM_USER_DEALER_MASTER, Dealer, Location |
| AM_LIST | Application List master table - provides configurable list descriptions and codes grouped by list name and principal | - | List Item, LOV |
| AM_USERS | Application Users master table - stores user identifiers, user types, and hierarchy codes for all system users | - | User Type, USERID |
| AM_USER_DEALER_MASTER | User-to-Dealer mapping table - links a user ID to their primary dealer, parent group, and location | - | AM_DEALER_LOC, Dealer User |
| APP_ID | Application Identifier - code identifying which report configuration set to load from the report parameter table | Application ID | ED_REPORTS, Report Launcher |
| APP_LOG | Application Logging flag - session-level flag (Y/N) that controls whether application timing is captured via the STOP_WATCH timer | - | STOP_WATCH |
| BTN | Button - interactive Oracle Forms push-button item used to trigger an action such as submitting a report | SUBMIT | Push Button |
| CB_BLK | Control Block - the single Oracle Forms data block in vr_calndr; holds all parameter and control items with no database binding | Control Block | Block |
| CSV | Comma-Separated Values - plain-text file format used for Excel-compatible report output | EXCEL output | PDF, Report Output |
| DLR | Dealer - user type code identifying a dealership-level user whose data scope is limited to their assigned outlet | Dealer User | MUL, P_USER_TYPE |
| DMS | Dealer Management System - integrated software platform for automotive dealership operations, within which vr_calndr runs | - | vr_calndr |
| DPL | Dealer Program Library - shared Oracle Forms PL/SQL program library (DPL.pld) providing common utility routines such as DISP_TEXT and RAISE_ERROR | DPL.pld | DPL.pld, GENERAL |
| DPL.olb | Dealer Program Library Object Library - parent object library from which vr_calndr inherits property classes, visual attributes, and object groups | Object Library | PC_FORM |
| ED_REPORTS | Report configuration table - defines visible parameters, their types, order, descriptions, and default values for each application identifier | Report Config | APP_ID, POP_LIST |
| FISCAL YEAR | Financial year - the 12-month accounting period defined by FIN_BEG and FIN_END globals (e.g. 01-APR to 31-MAR) | Financial Year | FIN_BEG, FIN_END |
| GM_REGN | Region master table - stores region codes, descriptions, and country codes used to populate the region selector | - | Region, P_REGION_CD |
| HO | Head Office - manufacturer hierarchy level indicating a user based at central headquarters | Head Office | MUL, P_USER_HORO |
| LOV | List of Values - Oracle Forms dropdown selection popup that allows the user to pick from a set of valid entries | Dropdown, Picklist | Record Group, LOV_PRG_SES, LV_DEALER |
| MUL | Manufacturer user type code - identifies users from the vehicle manufacturer or principal company who can view cross-dealer data | Manufacturer User | DLR, P_USER_TYPE |
| P_CHECK | Parameter flag controlling whether the "ALL DEALERS" option is included in the dealer selection list | - | RG_DEALER, Dealer LOV |
| P_DESFORMAT | Output format parameter - controls the report file format (PDF, CHAR, or wided/CSV) | Output Format | P_DESTYPE, FILENAME |
| P_DESTYPE | Destination type parameter - controls where the report is sent (CACHE, PRINTER, FILE, MAIL, or EXCEL) | Destination Type | P_DESFORMAT, SUBMIT |
| P_REGION_CD | Region code item - mandatory list selector identifying the geographic region for the report | Region Code | GM_REGN, P_REGION |
| PDF | Portable Document Format - default report output file format displayed in the browser via web.show_document | - | P_DESFORMAT, Report Output |
| PRINCIPAL | Principal company code - multi-company identifier used throughout the form and queries to filter data to the correct principal entity | Principal Map CD | GLOBAL.PRINCIPAL |
| RG_DEALER | Dealer record group - query-based record group that populates the dealer LOV filtered by region and principal | - | LV_DEALER, LOV |
| RG_PRG_SES | Programme session record group - query-based record group that populates the training programme LOV filtered by region and principal | - | LOV_PRG_SES, LOV |
| RO | Regional Office - manufacturer hierarchy level indicating a user based at a regional office | Regional Office | HO, P_USER_HORO |
| STOP_WATCH | Application timer package - tracks form session duration when application logging is enabled | - | APP_LOG |
| VA_MANDATORY | Visual attribute applied to mandatory input fields to highlight them to the user (yellow background) | Mandatory Highlight | Visual Attribute |
| VM_TRA_PROGRAM_MASTER | Vehicle Training Programme master table - stores programme codes, names, and durations for the training calendar | - | RG_PRG_SES, Training Programme |
| vr_calndr | Vehicle Training Calendar Report Launcher - the Oracle Forms module documented in this BRD | VR_CALNDR | DMS, Report Launcher |
| WN_MAIN | Main Window - the primary user-facing Oracle Forms window inherited from the DPL object library | Main Window | DPL.olb, Console Window |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_calndr (VR_CALNDR)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Calendar Report Launcher (inherited from DPL.olb via OG_GROUP)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_calndr_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | ProgramUnit / Trigger | Application identifier used to load report parameters from ED_REPORTS |
| APP_LOG | Char | Trigger | Flag (Y/N) controlling whether application timing is logged via STOP_WATCH |
| COMP_FA | Char | Trigger | Company fixed-asset flag set at form startup; used to conditionally enable fixed-asset report parameters |
| CURRENCY | Char | Trigger | Currency code for the logged-in user's principal company; used to format monetary report output |
| CUR_DATE | Char | ProgramUnit | Current system date used for report date validation |
| DEALER | Char | ProgramUnit / Trigger | Default dealer code for the logged-in user's primary location |
| FIN_BEG | Char | Trigger | Financial year begin date (DD-MON-YYYY) set at form startup; used as the default from-date for period-based reports |
| FIN_END | Char | Trigger | Financial year end date (DD-MON-YYYY) set at form startup; used as the default to-date for period-based reports |
| GROUP_CD | Char | Trigger | Dealer group code resolved at login; used to scope group-level report data |
| LOC_CD | Char | ProgramUnit / Trigger | Location code for the logged-in user's primary dealer location |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group code identifying the dealer group for the logged-in user |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal company code used to filter multi-company data throughout the form |
| P_FIN_YR | Char | Trigger | Financial year identifier (e.g. 2010) set as default at form startup |
| P_MONTHYEAR | Char | Trigger | Month-year value carried as a global for cross-context report period filtering |
| REPORT_DESC | Char | Trigger | Descriptive label of the current report displayed in the form header |
| REPORT_NAME | Char | Trigger | Report object name stored globally so it can be restored after form clear operations |
| REP_SERVER | Char | Trigger | Report server name or mode (e.g. REPORT_CALL) used to run reports |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is active for the principal; controls Tally-specific report paths |
| USERID | Char | ProgramUnit / Trigger | Login user ID of the currently authenticated user |
| USER_NAME | Char | Trigger | Full display name of the logged-in user; used in report headers and audit context |

### 8.1.2 Form Parameters

*All 8 ModuleParameter entries from vr_calndr_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| ENQ_DATE | Date | - | Enquiry date passed at form startup; used as a default date filter for report queries |
| P_CHECK | Number | 0 | Controls whether the "ALL DEALERS" option is shown in the dealer LOV (1 = hide, 0 = show) |
| TB | Number | 0 | Reserved - not used in current form logic |
| PR_REMARK | Char | - | Optional remark text passed at startup; available for report parameter substitution |
| CHECK_MAND | Char | N | When Y, enforces mandatory field validation before report submission |
| P_USER_TYPE | Char | DLR | User type classification (DLR = dealer, MUL = manufacturer); controls visible parameters and data scope |
| P_REGION | Char | - | Region code pre-set when the form is launched for a specific region |
| P_USER_HORO | Char | - | User hierarchy level within MUL user type (e.g. HO = Head Office, RO = Regional Office) |

**Total Parameters:** 8

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_calndr_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_calndr_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_calndr_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 24 | 0 | 24 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **37** | **0** | **37** |

**Item detail (all 37 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | REPORT_DESC | false | Display label showing the current report description |
| CB_BLK | P_REGION_CD | false | Region code selector (list item); mandatory filter for region-based report scope |
| CB_BLK | P_FOR_DESC | false | Description of the dealership format/category selected for the report |
| CB_BLK | P_MONTHYEAR | false | Month-year selector (list item) for calendar period-based report filtering |
| CB_BLK | P_PROGRAM_CD | false | Training programme code selected for the report; links to programme master |
| CB_BLK | P_FRM_DT | false | From date (DD-MM-YYYY) defining the report period start |
| CB_BLK | P_TO_DT | false | To date (DD-MM-YYYY) defining the report period end |
| CB_BLK | P_DEALER_DESC | false | Dealer name populated automatically from the dealer LOV or login context |
| CB_BLK | P_PARENT | false | Parent group code for the selected dealer; populated programmatically |
| CB_BLK | P_DEALER | false | Dealer mapping code; returned from dealer LOV or derived from login |
| CB_BLK | P_LOC | false | Location code for the selected dealer location |
| CB_BLK | LOC_DESC | false | Location description for the selected dealer location |
| CB_BLK | APP_ID | false | Application identifier controlling which report configuration is loaded |
| CB_BLK | REPORT_NAME | false | Report object name used to invoke the report engine |
| CB_BLK | REP_SERVER | false | Report server name used to submit the report |
| CB_BLK | P_FOR_CD | false | Dealership format code corresponding to the selected format description |
| CB_BLK | P_T_PARENT | false | Temporary parent group code passed as a report parameter for title display |
| CB_BLK | P_T_DEALER | false | Temporary dealer code passed as a report parameter for title display |
| CB_BLK | P_T_LOC | false | Temporary location code passed as a report parameter for title display |
| CB_BLK | P_DLR | false | User type flag passed to the report to control dealer-level data filtering |
| CB_BLK | P_DESTYPE | false | Report destination type selector (CACHE, PRINTER, FILE, MAIL, EXCEL) |
| CB_BLK | SUBMIT | false | Submit button; triggers report parameter assembly and report execution |
| CB_BLK | P_DESFORMAT | false | Report output format selector (PDF, CHAR, wided/CSV); enabled based on P_DESTYPE |
| CB_BLK | FILENAME | false | Output filename field; enabled only when destination format is EXCEL |
| PB_BLK | PB_EXIT | false | Toolbar Exit button (inherited from DPL.olb); closes the form after optional confirmation |
| PB_BLK | PB_LIST | false | Toolbar List-of-Values button (inherited from DPL.olb); invokes the LOV for the current item |
| PB_BLK | PB_INSERT | false | Toolbar Insert button (inherited from DPL.olb); initiates a new record in the current block |
| PB_BLK | PM_CONT | false | Toolbar Continue/OK button (inherited from DPL.olb); confirms or continues the current operation |
| PB_BLK | PB_DEL | false | Toolbar Delete button (inherited from DPL.olb); marks the current record for deletion |
| PB_BLK | PB_CANCEL | false | Toolbar Cancel button (inherited from DPL.olb); cancels pending changes in the current block |
| PB_BLK | PB_SAVE | false | Toolbar Save button (inherited from DPL.olb); commits pending changes to the database |
| PB_BLK | PB_PRINT | false | Toolbar Print button (inherited from DPL.olb); triggers the print action for the current report or screen |
| PB_BLK | PB_CUT | false | Toolbar Cut button (inherited from DPL.olb); cuts the selected text from the current item |
| PB_BLK | PB_COPY | false | Toolbar Copy button (inherited from DPL.olb); copies the selected text from the current item |
| PB_BLK | PB_PASTE | false | Toolbar Paste button (inherited from DPL.olb); pastes clipboard text into the current item |
| PB_BLK | PB_ERR_EXIT | false | Toolbar Error-window Exit button (inherited from DPL.olb); closes the error information window |
| CB_ERR | TXT_ERR | false | Text item on the inherited error canvas (CN_ERR) that displays the full error message text to the user |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Dealer Master | RG_DEALER | CB_BLK.P_DEALER_DESC |
| LOV_PRG_SES | Program Master | RG_PRG_SES | CB_BLK.P_PROGRAM_CD |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| ALERT_BUT | Note | Please select valid region code and for code | **COMMENTED OUT / INACTIVE** - Referenced only in commented code within ProgramUnit: PR_PASS_PARAM |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb via OG_GROUP; invoked by the DPL library print workflow to confirm or configure print output |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb via OG_GROUP; used by GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR to display error-level messages to the user |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb via OG_GROUP; used by GENERAL.DISP_TEXT to display informational messages to the user |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb via OG_GROUP; used by GENERAL.ASK_CONFIRM to prompt the user for yes/no confirmation before destructive operations |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **8 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | **COMMENTED OUT / INACTIVE** | **COMMENTED OUT / INACTIVE** - Entire procedure body is block-commented; previously called GENERAL.CHECK_NULL to validate test-drive fields |
| CHECK_BEFORE_DELETE | Unknown | **COMMENTED OUT / INACTIVE** | **COMMENTED OUT / INACTIVE** - Procedure body is null stub with commented logic; previously queried SH_ENQUIRY to block deletion of referenced zone records |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab | Package spec stub declaring an error code table variable; references pk_plsql_table.code_tab type |
| L_POPULATE | Procedure | AM_LIST, Create_Group_From_Query, Populate_Group, Populate_List | Populates a list item from the AM_LIST master table filtered by list name and principal code |
| LIST_POPULATE | Procedure | GM_REGN, am_user_region, Create_Group_From_Query, Populate_Group, POPULATE_LIST | Builds and populates dynamic record groups for list items (P_REGION_CD, P_MONTHYEAR) based on user type and hierarchy |
| POP_LIST | Procedure | AM_USERS, AM_USER_DEALER_MASTER, AM_DEALER_LOC, ED_REPORTS, DUAL, List_Populate, Set_Item_Property | Initialises form state on load: resolves user type, sets dealer/region context, reads report parameter config from ED_REPORTS, and makes relevant fields visible |
| PR_REMOVE_ASCII_CHR | Procedure | text_io.fopen, text_io.get_line, text_io.put_line, text_io.fclose, web.show_document, GENERAL.DISP_TEXT | Reads a generated CSV report file, strips form-feed characters (CHR(12)), writes a clean copy, and displays it in the browser |
| PR_PASS_PARAM | Procedure | ED_REPORTS, GENERAL.DISP_TEXT | Assembles the report parameter string from form fields (region, dealer, dates, programme) and report config in ED_REPORTS; called before report execution |

**Total Program Units:** 8

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a yes/no confirmation dialog via AL_CONFIRM; returns the user's choice to the caller so destructive actions (e.g. form exit, record delete) can be conditionally proceeded or cancelled |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Validates that a required field is not null; raises FORM_TRIGGER_FAILURE if empty; called only in commented-out VALIDATE_CN_MAIN |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_REGION_CD, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: LIST_POPULATE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a modal alert dialog with the supplied message and title; routes to AL_ERRINFO for errors or AL_NOTE for informational messages |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code and displays it via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | First code block is fully block-commented; contained original error-handling logic calling GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR for specific Oracle error codes | Replaced by active code in same trigger body; old block preserved as a comment above the current implementation |
| **Inactive stub** | Form | - | KEY-COMMIT | Body is `NULL;` - no commit processing occurs | Commit intentionally disabled; form is used as a report launcher only, with no database write operations |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Contained global initialisation logic for multi-company defaults (PRINCIPAL, PARENT_GROUP, DEALER, financial year, Tally flag) and initial call to POP_LIST | Logic migrated to PRE-FORM; WHEN-NEW-FORM-INSTANCE body is fully block-commented and superseded |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously called GENERAL.ASK_CONFIRM before exiting; confirmed user intent before closing the form | Replaced by inherited DPL.olb behaviour on the same button; local override body is commented out |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (38 business triggers):**
*vr_calndr_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms and Oracle database errors; displays user-friendly messages for date format, numeric, and record-lock errors via GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE to halt processing |
| ON-MESSAGE | Form | - | Form level | Intercepts specific Oracle Forms informational messages (40209, 40207) and re-displays them as user-friendly error dialogs via GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info and module context, then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name attached to the current item and displays the LOV if present; navigates to the next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE STUB** - Body is NULL; commit is intentionally disabled as the form performs no database writes |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, restores the report description from global, evaluates APP_ID to set P_CHECK parameter, then re-invokes POP_LIST to reload report parameters |
| KEY-OTHERS | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; suppresses unhandled key events to prevent default Forms navigation errors |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; navigates focus to the next enabled item in tab order |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; navigates focus to the previous enabled item in tab order |
| KEY-NXTBLK | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; navigates focus to the next block |
| KEY-PRVBLK | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; navigates focus to the previous block |
| KEY-DOWN | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; moves focus down one record or item |
| KEY-UP | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; moves focus up one record or item |
| FT_SAVE | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the Save toolbar button; commits pending changes |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the Cancel toolbar button; rolls back pending changes |
| FT_INSERT | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the Insert toolbar button; creates a new record in the current block |
| FT_DEL | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the Delete toolbar button; marks the current record for deletion |
| FT_LIST | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the List toolbar button; invokes the LOV for the current item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; bound to the Print toolbar button; triggers the DPL print workflow |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Inherited from OG_GROUP/DPL.olb; fires on form startup; the local override body is fully commented out - active initialisation is handled in PRE-FORM |
| PRE-FORM | Form | - | Form level | Registers the form module with DBMS_APPLICATION_INFO; initialises global variables for multi-company defaults (PRINCIPAL, PARENT_GROUP, DEALER, financial year, Tally flag); starts application timer if APP_LOG is Y |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Validates that P_REGION_CD is not null; displays an error message via GENERAL.DISP_TEXT and raises FORM_TRIGGER_FAILURE if empty; clears P_FOR_DESC when a valid region is entered |
| WHEN-LIST-CHANGED | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Clears dependent fields (P_FOR_DESC, P_FOR_CD, P_DEALER_DESC, LOC_DESC, P_DEALER, P_LOC, P_PARENT) when the region selection changes |
| WHEN-LIST-CHANGED | CB_BLK | P_DESTYPE | CB_BLK.P_DESTYPE | Sets P_DESFORMAT to CHAR and disables it when destination is PRINTER; sets P_DESFORMAT to PDF and enables it for all other destinations |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Assembles report parameters by user type, invokes PR_PASS_PARAM, configures the report object properties (destination, format, filename, server), executes the report via RUN_REPORT_OBJECT, and displays the output in the browser; handles both PDF and Excel output paths |
| WHEN-LIST-CHANGED | CB_BLK | P_DESFORMAT | CB_BLK.P_DESFORMAT | Enables the FILENAME field and makes it navigable when EXCEL format is selected; clears and disables FILENAME for all other formats |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | FILENAME | CB_BLK.FILENAME | Sets insert and update allowed properties on FILENAME based on whether P_DESFORMAT is EXCEL |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited from DPL.olb; invokes GENERAL.ASK_CONFIRM to prompt the user before closing the form; exits on confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited from DPL.olb; invokes the LOV attached to the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited from DPL.olb; creates a new record in the current block |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited from DPL.olb; confirms or continues the current pending operation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited from DPL.olb; marks the current record for deletion after optional confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited from DPL.olb; cancels pending changes in the current block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited from DPL.olb; commits pending changes to the database |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited from DPL.olb; triggers the DPL print workflow for the current report or screen |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited from DPL.olb; cuts the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited from DPL.olb; copies the selected text from the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited from DPL.olb; pastes clipboard text into the currently focused item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Service Pending Reports Parameter Form (Rel 1.1.0) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vr_calndr_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_calndr_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

*1 object group defined in vr_calndr_fmb.xml: **OG_GROUP** (parent module: DPL_MTPL). Children listed below.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_calndr_fmb.xml.*

## 9. Object Library

*The VR_CALNDR form references the DPL object library, which supplies reusable visual attributes and property classes for consistent field styling, date formatting, mandatory-field highlighting, and standard form-level behaviour.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Gray background, ARIAL 8pt, black foreground - for check-box items | referenced | N/A |
| VA_RB | VisualAttribute | Gray background, Arial 8pt, black foreground - for radio-button items | referenced | N/A |
| VA_ICONIC_BUTN | VisualAttribute | White background, black foreground, transparent fill - for iconic buttons | referenced | N/A |
| VA_DESC | VisualAttribute | Gray background, Small Fonts 7pt, blue foreground - for description/display fields | referenced | N/A |
| VA_NUM | VisualAttribute | White background, ARIAL 8pt plain medium, black foreground - for numeric items | referenced | N/A |
| VA_MAND | VisualAttribute | Cyan background, ARIAL 9pt plain medium, black foreground - marks a field as mandatory (yellow/cyan highlight) | referenced | P_REGION_CD (applied dynamically by POP_LIST for mandatory filter fields) |
| VA_OPROMPT | VisualAttribute | Prompt type; white background, ARIAL 9pt, black prompt foreground - for optional field prompts | referenced | N/A |
| VA_MPROMPT | VisualAttribute | Prompt type; white background, ARIAL 9pt, red prompt foreground - for mandatory field prompts | referenced | N/A |
| VA_TEXT | VisualAttribute | White background, Arial 9pt plain medium, black foreground - for standard text items | referenced | N/A |
| VA_BUTN | VisualAttribute | Gray background, Arial 10pt bold, black foreground - for push buttons | referenced | N/A |
| VA_ALERT | VisualAttribute | Gray background, MT EXTRA 11pt, black foreground - for alerts | referenced | N/A |
| VA_TITLE | VisualAttribute | Gray background, Arial 10pt bold, blue foreground - for title fields | referenced | N/A |
| VA_TRNI_DT | VisualAttribute | White background, COURIER bold, black foreground - for transaction date fields | referenced | N/A |
| VA_LOV | VisualAttribute | Gray background, Arial 9pt, dark-blue foreground - for LOV-enabled fields | referenced | N/A |
| VA_DISP | VisualAttribute | r25g75b75 background, Arial 8pt bold, black foreground - for display-only items | referenced | N/A |
| PC_DESC | PropertyClass | Left-justified display item, Arial 9pt, blue foreground, width 250, max length 110, no bevel | referenced | N/A |
| PC_SC_DATE | PropertyClass | Display item for dates; gray background, Arial 8pt bold, blue foreground, format mask empty, hint for DD-MM-YY entry | referenced | N/A |
| PC_TITLE | PropertyClass | Centered text item, Arial 10pt bold, upper case, blue foreground - for section titles | referenced | N/A |
| PC_FORMAT | PropertyClass | Centered text item, white background, Arial 9pt, upper case, width 60, max length 12 - for format/code fields | referenced | N/A |
| PC_MR_BLK | PropertyClass | Master-detail block navigation class; next navigation block PB_BLK, vertical record orientation | referenced | N/A |
| PC_DISP | PropertyClass | Left-justified display item, gray8 background, Arial 9pt, not enabled, lowered bevel, not keyboard-navigable | referenced | N/A |
| PC_LOV | PropertyClass | LOV property class; gray background, Arial 8pt, dark-blue foreground, auto-select off, LOV position 80/96, width 250, height 200 | referenced | N/A |
| PC_FORM | PropertyClass | Form-level property class; includes standard ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM triggers; sets console window WN_MAIN and menu module menu.mmx | referenced | VR_CALNDR form (form-level property class) |
| PC_DISP_DATE | PropertyClass | Left-justified display item for dates; gray8 background, Arial 9pt, format mask DD-MM-RRRR, not enabled, not keyboard-navigable | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Right-justified display item for numbers; gray8 background, Arial 9pt, lowered bevel, not enabled, not keyboard-navigable | referenced | N/A |
| PC_DATE | PropertyClass | Text item for dates; white background, Arial 9pt, format mask DD-MM-RRRR, width 60, max length 10, hint for DD-MM-YYYY / DD/MM/YYYY, pop-up menu POP_MAIN | referenced | N/A |
| PC_DTTIME | PropertyClass | Text item for date and time; format mask DD-MM-RRRR HH24:MI, width 80, initialized to current DB datetime, hint for DD-MM-YY HH24:MI | referenced | N/A |
| PC_CB | PropertyClass | Check-box item; white background, Arial 9pt plain medium, height 14 | referenced | N/A |
| PC_ALERT | PropertyClass | Alert style; gray background, MT Extra 11pt, demi-light weight, black foreground | referenced | N/A |
| PC_MDATE | PropertyClass | Mandatory date text item; white background, format mask DD-MM-RRRR, width 60, max length 10, red prompt foreground, pop-up menu POP_MAIN | referenced | N/A |
| PC_RB | PropertyClass | Radio button property class | referenced | N/A |
| PC_WIND | PropertyClass | Window property class | referenced | N/A |
| PC_CANV | PropertyClass | Canvas property class | referenced | N/A |
| PC_BUTN | PropertyClass | Push button property class | referenced | N/A |
| PC_TEXT | PropertyClass | Text item property class | referenced | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item property class | referenced | N/A |
| PC_UTEXT | PropertyClass | Uppercase text item property class | referenced | N/A |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item property class | referenced | N/A |
| PC_NUM | PropertyClass | Numeric item property class | referenced | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric item property class | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class | referenced | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_DEALER | Query | LV_DEALER | DEALER | DEALER_NAME | Yes - CB_BLK, PARAMETER | Allows the user to select a dealer location filtered by the chosen region; includes an "ALL DEALERS" option for manufacturer-level users | LV_DEALER -> CB_BLK.P_DEALER_DESC |
| RG_PRG_SES | Query | LOV_PRG_SES | PROGRAM_CD | PROGRAM_NAME | Yes - CB_BLK, PARAMETER | Allows the user to select a training programme available in the calendar for the selected region and principal | LOV_PRG_SES -> CB_BLK.P_PROGRAM_CD |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | POP_LIST, RG_DEALER | Dealer location master - holds dealer name, region, parent group, location code, and dealer type |
| `AM_LIST` | - | L_POPULATE | List of values master - provides configurable list descriptions and codes by list name and principal |
| `AM_USERS` | - | POP_LIST | Application users master - stores user ID and user type (DLR/MUL) for login-based context resolution |
| `AM_USER_DEALER_MASTER` | - | POP_LIST | User-to-dealer mapping - links a user ID to their primary dealer, parent group, and location |
| `DUAL` | - | POP_LIST, RG_DEALER | Oracle system dual table - used for single-row utility queries (e.g. substring operations and adding the "ALL DEALERS" union row) |
| `ED_REPORTS` | - | POP_LIST, PR_PASS_PARAM | Report parameter configuration - defines visible parameters, their types, descriptions, and default values for each application ID |
| `EH_REPORTS` | - | Trigger WHEN-NEW-FORM-INSTANCE | Report execution history table - queried during form initialisation to resolve previously saved report parameters or session context for the current user |
| `GM_REGN` | - | LIST_POPULATE | Region master - stores region codes, descriptions, and country codes used to populate the region selector |
| `VM_TRA_PROGRAM_MASTER` | - | RG_PRG_SES | Training programme master - stores programme codes, names, and durations for the vehicle training calendar |

**Total Referenced Objects:** 9

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | POP_LIST | Resolves user type, loads dealer details, and populates the Region Code and Month/Year filter lists at form startup and reset |
| BR-002 | LIST_POPULATE | Builds and populates an individual filter list (Region Code or Month/Year) by constructing and executing a query against the region master and AM_LIST, filtered by user type and authorization |
| BR-006 | PR_PASS_PARAM | Assembles the report parameter string from configured filter values and passes it to the report engine |
| BR-006 | PR_REMOVE_ASCII_CHR | Post-processes the raw Excel output file to remove non-printable characters before presenting the file to the user |
| BR-007 | GENERAL.DISP_TEXT | Displays user-facing error and information messages with the appropriate severity level |
| BR-007 | GENERAL.RAISE_ERROR | Looks up and displays a registered business error message by error code, used for standard integrity violation notifications |
| BR-007 | GENERAL.ASK_CONFIRM | Presents a modal confirmation dialog to the user and returns the user's response; used to confirm potentially destructive actions such as cancelling unsaved changes or deleting a record |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers or clears the current form module name in the database session's client information field for monitoring |
| BR-001, BR-008 | DBMS_APPLICATION_INFO.SET_MODULE | Registers or clears the current module and action name in the database session for monitoring |
| BR-006 | WEB.SHOW_DOCUMENT | Opens the generated report output file (PDF or cleaned Excel) in a new browser tab for the user |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_LIST | Form program unit (PROCEDURE) | KEY-CLRFRM trigger | Resolves the current user's type and organizational level, derives the application identifier for dealer users, loads dealer region and location details from AM_DEALER_LOC and AM_USER_DEALER_MASTER, reads the report parameter configuration from ED_REPORTS, and populates the Region Code and Month/Year filter lists by calling LIST_POPULATE for each configured parameter |
| LIST_POPULATE | Form program unit (PROCEDURE) | POP_LIST; GENERAL.L_POPULATE | Constructs the SQL query for a given list parameter (currently Region Code) based on the user's type (head-office, regional office, or dealer), querying GM_REGN for region data and AM_LIST for configurable list values; creates or refreshes the record group, populates it, and loads the results into the on-screen list item; calls GENERAL.DISP_TEXT on error |
| PR_PASS_PARAM | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on SUBMIT | Reads the report's parameter configuration from ED_REPORTS, captures the filter field values entered by the user, and assembles the full parameter string (region code, dealer type, program code, from/to dates, principal code) passed to the report engine |
| PR_REMOVE_ASCII_CHR | Form program unit (PROCEDURE) | WHEN-BUTTON-PRESSED on SUBMIT (Excel path only) | Opens the raw report output CSV file, reads it line by line while skipping form-feed characters, writes the clean lines to a new output file, closes both files, and opens the cleaned output file in a new browser tab; calls GENERAL.DISP_TEXT on file-handling errors |
| GENERAL.ASK_CONFIRM | Package routine - DPL attached library (EXTERNAL / NOT IN BUNDLE - implementation in attached DPL library) | FT_CANCEL trigger; FT_DEL trigger | Displays a modal confirmation dialog presenting the supplied message to the user and returns the user's response as a NUMBER. Called from the FT_CANCEL and FT_DEL triggers to prompt the user to confirm a potentially destructive action (cancelling unsaved changes or deleting a record) before proceeding |
| GENERAL.DISP_TEXT | Package routine - DPL attached library (EXTERNAL / NOT IN BUNDLE - implementation in attached DPL library) | LIST_POPULATE program unit; PR_REMOVE_ASCII_CHR program unit; FT_INSERT trigger; ON-ERROR trigger; ON-MESSAGE trigger; WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD | Presents a message to the user at the specified severity level (Error, Note, etc.) as a modal notification; selects alert AL_ERRINFO for error-type titles or AL_NOTE for informational titles, then calls SHOW_ALERT |
| GENERAL.RAISE_ERROR | Package routine - DPL attached library (EXTERNAL / NOT IN BUNDLE - implementation in attached DPL library) | ON-ERROR trigger | Looks up the registered business message text for a given error code identifier, formats the text with a severity prefix, and delegates display to GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages (type E) or displays a note/caution without halting for types N and C; invoked when a database referential integrity violation (DBMS error code -02292) is detected |
| GENERAL.L_POPULATE | Package routine - DPL attached library (EXTERNAL / NOT IN BUNDLE - implementation in attached DPL library) | LIST_POPULATE program unit | Populates a named list item (LOV/combo box) identified by P_LIST_NAME with values derived from the field or query context specified by P_LIST_FIELD; called from the LIST_POPULATE program unit to drive dynamic list initialisation at form startup or upon context change |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package routine | PRE-FORM trigger; KEY-EXIT trigger | Registers the form module name (`vr_calndr`) in the database session client information field on form open; clears it on form exit |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package routine | PRE-FORM trigger; KEY-EXIT trigger | Registers the current module name and action in the database session on form open; clears both on form exit |
| WEB.SHOW_DOCUMENT | Oracle built-in Web package routine | WHEN-BUTTON-PRESSED on SUBMIT (PDF path); PR_REMOVE_ASCII_CHR (Excel path) | Opens the specified file path in a new browser tab (`_blank`) for the user to view or download the report output |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in the input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays a modal confirmation dialog presenting the supplied message to the user and returns the user's response as a NUMBER. Called from the FT_CANCEL and FT_DEL triggers to prompt the user to confirm a potentially destructive action (cancelling unsaved changes or deleting a record) before proceeding. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: LIST_POPULATE, ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | Displays a modal alert dialog to the user with the supplied message text and title. Selects alert AL_ERRINFO for error-type titles or AL_NOTE for informational titles, then calls SHOW_ALERT. Invoked by error handlers, the region validation trigger, the FT_INSERT trigger, and program units to surface validation failures and exceptions. |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2, P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item (LOV/combo box) identified by P_LIST_NAME with values derived from the field or query context specified by P_LIST_FIELD. Called from the L_POPULATE program unit to drive dynamic list initialisation at form startup or upon context change. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by its code, formats the text with a severity prefix, and delegates display to GENERAL.DISP_TEXT. Raises FORM_TRIGGER_FAILURE for error-type messages (type E), or displays a note/caution message without halting for types N and C. Called from the ON-ERROR trigger when a database referential integrity violation (DBMS error code -02292) is detected. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in `vr_calndr_fmb.xml`.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Previously called from VALIDATE_CN_MAIN to enforce mandatory field rules; would display "Enter a valid {column_title}" via GENERAL.DISP_TEXT and raise FORM_TRIGGER_FAILURE if the supplied value was null. VALIDATE_CN_MAIN is entirely block-commented, so this routine is never invoked at runtime. |

**Total Active Routines:** 4 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### D2kwutil.pld (`Win_API`)

*No routines from `D2kwutil.pld` are referenced in `vr_calndr_fmb.xml`.*

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | User Type and Access Resolution Service | AM_USERS | User identifier (from session) | User type (manufacturer or dealer), organizational level (head-office or regional office) | Determines the current user's type and organizational classification so the calling form can present the correct filter options and data scope | GET /api/users/{userId}/access-type |
| MS-002 | Dealer Location Lookup Service | AM_USER_DEALER_MASTER, AM_DEALER_LOC | User identifier, parent group (fallback), dealer code (fallback), location code (fallback) | Region code, dealer name, location description, parent group code, dealer mapping code, location code | Resolves the primary dealer outlet for a dealer user, returning all region and location details needed to pre-populate filter fields; falls back to session global values if the primary location record is not found | GET /api/dealers/user/{userId}/primary-location |
| MS-003 | Authorized Region List Service | GM_REGN, AM_USER_REGION (EXTERNAL / NOT IN BUNDLE) | User identifier, user type, organizational level, principal code | List of authorized region codes and descriptions | Returns the list of geographic regions the current user is authorized to filter on, scoped by user type and access rights | GET /api/regions/authorized?userId={userId}&userType={userType}&principalCode={code} |
| MS-004 | Report Parameter Configuration Service | ED_REPORTS | Application identifier, principal code | Ordered list of parameter names, descriptions, types, and default values | Returns the configuration of filter parameters defined for a specific report application, driving which filter fields are displayed on screen and which parameter names are passed to the report engine | GET /api/report-parameters?appId={appId}&principalCode={code} |
| MS-005 | Report Parameter Assembly Service | ED_REPORTS | Application identifier, principal code, region code, dealer type flag, program code, from date, to date | Assembled report parameter string | Builds the complete parameter string for the report engine from the user's filter selections and the report's configuration, ensuring all required parameter names and values are included in the correct sequence | POST /api/report-parameters/assemble |
| MS-006 | Report Generation and Delivery Service | REPORT_CALL (Oracle Reports object - rep.rdf) | Report name, destination type, output format, parameter string, report server name, output file path | Report output file (PDF or Excel/CSV); file path for browser delivery | Configures and submits the report to the Oracle Reports server with the specified destination, format, and parameter string; returns the path of the generated output file for browser delivery | POST /api/reports/generate |
| MS-007 | Excel Output Cleanup Service | File system (report output directory `/iashome/ias/reports/printer/`) | Input raw CSV file name, output cleaned CSV file name | Cleaned CSV file accessible for browser download | Reads the raw Oracle Reports Excel/CSV output file line by line, removes any form-feed characters, writes the clean content to a new output file, and returns the path for browser delivery | POST /api/reports/cleanup-excel |
| MS-008 | Error Message Catalogue Service | EXTERNAL / NOT IN BUNDLE (GENERAL package error message catalogue) | Error code identifier | Registered business error message text | Looks up the human-readable business message registered for a given system error code, enabling the presentation of standardized, business-friendly error notifications | GET /api/error-messages/{errorCode} |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialization and Filter List Population | User opens the VR_CALNDR form (PRE-FORM trigger fires) | 1. Session registered with application tracking (module name `vr_calndr` written to DB session). 2. If application logging is active, performance timer started. 3. (On first display) User type resolved from user master. 4. Application identifier derived for dealer users. 5. Dealer region and location loaded for dealer users. 6. Report parameter configuration read from ED_REPORTS. 7. Region Code and Month/Year filter lists populated based on user type and authorized regions. | Is application logging active? (start timer or skip). Is user type dealer? (load dealer details and derive app ID, or use global app ID). Can dealer app ID be resolved? (continue or exit form). | Filter screen displayed with appropriate lists populated; session tracked |
| WF-002 | Region Code Filter Change and Dependent Field Reset | User changes the Region Code selection (WHEN-LIST-CHANGED on P_REGION_CD fires) | 1. Hierarchy code, dealer description, location description, dealer code, location code, and parent group fields all cleared. 2. (When user leaves the field) Region Code validated as not empty. 3. If empty, error shown and cursor held on Region Code field. 4. If not empty, hierarchy code description field cleared. | Is Region Code empty when the user leaves the field? (show error and hold / clear description and continue). | Dependent fields reset; region validated; form ready for further filter entry or submission |
| WF-003 | Output Destination and Format Configuration | User changes the Destination selection (WHEN-LIST-CHANGED on P_DESTYPE fires) or the Format selection (WHEN-LIST-CHANGED on P_DESFORMAT fires) | 1. When Destination changes: if Printer selected, Format set to CHAR and locked; otherwise Format set to PDF and enabled. 2. When Format changes: if format is not Excel, File Name field cleared and locked; if Excel, File Name field enabled and navigable. 3. When cursor enters File Name field (WHEN-NEW-ITEM-INSTANCE on FILENAME): if format is Excel, insert and update access granted; otherwise insert and update access denied. | Is Destination Printer? (lock Format as CHAR / set PDF and enable). Is Format Excel? (enable File Name / clear and lock File Name). | Output configuration set; File Name field access matches the selected format |
| WF-004 | Report Parameter Assembly and Report Submission | User clicks Submit Report button (WHEN-BUTTON-PRESSED on SUBMIT fires) | 1. User type checked; report title parameters set from dealer values (dealer users) or session globals (non-dealer users). 2. PR_PASS_PARAM called to assemble report parameter string from filter values and report configuration. 3. Report object located; destination type configured (cache, printer, file, or mail). 4. For non-Excel output: output format set to PDF, rendering options applied, report submitted to report server, resulting PDF file opened in new browser tab. 5. For Excel output: output format set to wide-delimited, report submitted to report server, PR_REMOVE_ASCII_CHR called to clean the output file, cleaned CSV file opened in new browser tab. | Is user type dealer? (use dealer identity values / use global session values). Is destination Printer, Cache, File, or Mail? (configure accordingly). Is destination/format Excel? (PDF path or Excel post-processing path). Did Excel cleanup encounter an exception? (display error note and stop / open file in browser). | Report output delivered to user's browser (PDF tab or cleaned Excel tab); or report dispatched to printer/mail/cache depending on destination |
| WF-005 | Form Reset and Filter List Reload | User initiates a form clear/reset action (KEY-CLRFRM trigger fires) | 1. All form fields cleared without validation. 2. Report description label restored from session. 3. Application check parameter set based on whether the current app identifier matches VR_CALNDR (1 = restrict dealers; 0 = allow all dealers). 4. POP_LIST called to re-populate Region Code and Month/Year filter lists. | Does the current application identifier match VR_CALNDR? (set check parameter to 1 or 0). | Form cleared and filter lists reloaded; screen ready for fresh filter entry |
| WF-006 | Form Exit with Session Cleanup | User initiates an exit action (KEY-EXIT trigger fires) | 1. Database session client information cleared (set to null). 2. Module name and action name cleared from database session. 3. Form closed immediately without validation or saving any data. | None | Form closed; database session tracking information cleared |

**Total Workflows Identified: 6**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field value is null, then an error message is displayed and form navigation is halted |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: LIST_POPULATE, ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | /api/v1/pld/disp_text | When a message and title are provided, then a modal alert is displayed to the user using the appropriate alert type |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a database or form error code is received, then an error message is retrieved and displayed; execution is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_calndr_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_calndr_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| User account master (AM_USERS) | Table - SELECT | Resolves the current user's type (manufacturer or dealer) and organizational level (head-office or regional office) | Inbound: user identifier from session -> user type and organizational level returned to form | On query failure: user type and organizational level set to null; form continues with degraded filter population |
| User-dealer assignment (AM_USER_DEALER_MASTER) | Table - SELECT | Links the current user to their primary dealer outlet and location | Inbound: user identifier -> region code, dealer name, location description, parent group, dealer mapping code, location code returned to form | On failure: falls back to AM_DEALER_LOC query using session global values |
| Dealer location master (AM_DEALER_LOC) | Table - SELECT | Provides dealer region, name, location, and codes for dealer users | Inbound: parent group, dealer mapping code, location code from session globals -> dealer attributes returned to form | On failure: dealer description set to 'DEALER USERS WRONG' |
| Region master (GM_REGN) | Table - SELECT | Provides the list of authorized geographic regions for the Region Code filter list | Inbound: user identifier, user type, organizational level, principal code -> region codes and descriptions returned to form | No explicit error handler; list remains empty if query fails |
| Report parameter configuration (ED_REPORTS) | Table - SELECT | Provides the filter parameter definitions for the current report and application | Inbound: application identifier, principal code -> parameter names, types, default values, sequence numbers returned to form | No explicit error handler; parameter loop does not execute if cursor returns no rows |
| List master (AM_LIST) | Table - SELECT | Provides configurable name-code pairs for dynamic list fields | Inbound: list name, principal code -> list descriptions and codes returned to form | No explicit error handler |
| Training program master (VM_TRA_PROGRAM_MASTER, VM_CALNDR) | Tables - SELECT (via record group RG_PRG_SES) | Provides the list of training program codes and names for the Program ID field LOV, filtered by region and principal code | Inbound: selected region code, principal code -> program codes and names returned to LOV | No explicit error handler; LOV list is empty if query returns no rows |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Database Application Info (DBMS_APPLICATION_INFO) | Oracle built-in package - PL/SQL call | Registers and clears the form module name and action in the database session for monitoring and traceability | PL/SQL API call (in-process) | DBMS_APPLICATION_INFO.SET_CLIENT_INFO / SET_MODULE (Oracle built-in) | Outbound: module name `vr_calndr` written to session on form open; both client info and module name cleared on form exit | No return value; errors silently ignored |
| STOP_WATCH package (performance timer) | Form-attached library / PL/SQL call | Starts a performance timer when application logging is active, to record the form's response time for monitoring | PL/SQL API call (via STOP_WATCH.pck in source directory) | STOP_WATCH.START_TIMER | Outbound: timer started for the session | No return value; conditional on GLOBAL.APP_LOG = 'Y' |
| GENERAL package (DPL attached library) | Form-attached library - PL/SQL call | Provides centralized error display (DISP_TEXT) and error code lookup (RAISE_ERROR) for user-facing messages | PL/SQL API call (via DPL.pll / DPL.pld attached library - EXTERNAL / NOT IN BUNDLE) | GENERAL.DISP_TEXT, GENERAL.RAISE_ERROR | Bidirectional: message text and severity passed in; user sees modal notification | No structured return code; raises FORM_TRIGGER_FAILURE on error display in certain error handling flows |
| Oracle Web toolkit (WEB.SHOW_DOCUMENT) | Oracle built-in package - PL/SQL call | Opens a generated report output file (PDF or cleaned Excel) in a new browser tab for the user | Oracle Forms Web API call (in-process) | WEB.SHOW_DOCUMENT | Outbound: file path and target (`_blank`) passed; browser opens the file | No return value; failure is silent |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Global session report server (`GLOBAL.REP_SERVER`) - INFERRED | Region Code, dealer type flag, program code, from date, to date, principal code - assembled as a parameter string by PR_PASS_PARAM; additional rendering options: `MODE=BITMAP BLANKPAGES=NO parform=yes` (PDF) or `MODE=CHARACTER BLANKPAGES=NO` (Excel) | PDF (non-Excel destinations) or wide-delimited CSV - INFERRED from `wided` format code (Excel destination) | WHEN-BUTTON-PRESSED on the Submit Report button |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_CALNDR form.

### 21.1 Catalogue Index

7 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--LIST_POPULATE) | LIST_POPULATE |
| [SP-002](#SP-002--POP_LIST) | POP_LIST |
| [SP-003](#SP-003--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-004](#SP-004--PR_REMOVE_ASCII_CHR) | PR_REMOVE_ASCII_CHR |
| [SP-005](#SP-005--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-006](#SP-006--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-007](#SP-007--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |

---

### 21.2 Detailed Specifications

#### SP-001 - LIST_POPULATE

**Invoked From:**

- vr_calndr_fmb.xml [ProgramUnit: POP_LIST]
- vr_calndr_fmb.xml [StoredProcedure: POP_LIST]

---

**Screen:**

N/A

---

**Purpose**

Populates a named list-of-values control on the calendar screen by building and executing a dynamic SQL query against GM_REGN. Currently handles the 'P_REGION_CD' list item, constructing the appropriate region query based on the authenticated user's type and hierarchy level, then binding the result set to the corresponding combo-box item.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_name | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the list item name (p_name) as input and assign it to the record-group name variable (rg_name).
- Step 2 - Evaluate p_name to determine which list item requires population; processing is currently active only for the value 'P_REGION_CD'.
- Step 3 - Attempt to locate an existing record group with the name rg_name using Find_Group.
- Step 4 - Determine the correct SQL query for GM_REGN by inspecting the user-type parameter (P_USER_TYPE) and hierarchy parameter (P_USER_HORO):
  - If P_USER_TYPE = 'MUL' and P_USER_HORO = 'HO', build a query joining GM_REGN and AM_USER_REGION filtered by the current user ID, service user type, country 'IND', and the global principal, ordering by region code.
  - If P_USER_TYPE = 'MUL' and P_USER_HORO = 'RO', build a similar join query with the same filters but ordering by region code (column alias not applied).
  - If P_USER_TYPE = 'DLR', build a query against GM_REGN filtered by the specific region stored in P_REGION parameter, country 'IND', and the global principal.
  - Otherwise, set the SQL variable to NULL.
- Step 5 - If the record group does not yet exist (Id_Null returns TRUE), create it from the constructed query using Create_Group_From_Query.
- Step 6 - Execute Populate_Group to fetch data into the record group.
- Step 7 - Bind the populated record group to the combo-box item 'CB_BLK.P_REGION_CD' via POPULATE_LIST.
- Step 8 - If P_USER_TYPE = 'DLR', automatically set the CB_BLK.P_REGION_CD item value to the P_REGION parameter value, pre-selecting the dealer's single allowable region.

---
**Decision Points**

DP-001

Condition:
p_name = 'P_REGION_CD'

TRUE:
Proceed with region list population logic (Steps 3-8).

FALSE:
No processing is performed; the procedure exits without populating any list.

---

DP-002

Condition:
P_USER_TYPE = 'MUL' AND P_USER_HORO = 'HO'

TRUE:
Build a dynamic SQL query joining GM_REGN and AM_USER_REGION for the current user, filtered by SERVICE user type, country 'IND', and global principal, ordered by region code alias.

FALSE:
Evaluate DP-003.

---

DP-003

Condition:
P_USER_TYPE = 'MUL' AND P_USER_HORO = 'RO'

TRUE:
Build a dynamic SQL query joining GM_REGN and AM_USER_REGION for the current user, filtered by SERVICE user type, country 'IND', and global principal, ordered by GM_REGN.REGION_CD.

FALSE:
Evaluate DP-004.

---

DP-004

Condition:
P_USER_TYPE = 'DLR'

TRUE:
Build a dynamic SQL query against GM_REGN filtered by the specific P_REGION parameter value, country 'IND', and global principal.

FALSE:
Set the SQL variable to NULL (no query is built; record group will be created with a NULL query).

---

DP-005

Condition:
Id_Null(rg_id) - the record group named rg_name does not already exist in the form.

TRUE:
Create a new record group from the constructed query using Create_Group_From_Query.

FALSE:
Reuse the existing record group; skip creation.

---

DP-006

Condition:
P_USER_TYPE = 'DLR' (evaluated after POPULATE_LIST completes)

TRUE:
Set CB_BLK.P_REGION_CD to the value of the P_REGION parameter, pre-selecting the dealer's assigned region.

FALSE:
Leave the combo-box selection at its default populated state.

---
**Database Interactions**

- DB-001 - Read GM_REGN - Reads data from GM_REGN for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

- BR-001 - Only regions belonging to country code 'IND' are eligible for display in the region list; records from GM_REGN with any other country code are excluded.
- BR-002 - Region data must be further filtered by the global principal (GLOBAL.PRINCIPAL), ensuring that only regions mapped to the active principal company are presented to the user (multi-company support introduced July 2014).
- BR-003 - For multi-user (MUL) accounts, only regions explicitly assigned to the current user ID in AM_USER_REGION with USER_TYPE = 'SERVICE' are included, preventing cross-region data exposure.
- BR-004 - A dealer user (P_USER_TYPE = 'DLR') may only view and select the single region stored in the P_REGION parameter; the combo-box is automatically set to that value after population.
- BR-005 - A record group is created only once per session for a given list name; if a record group with the same name already exists, it is reused and re-populated rather than recreated, avoiding duplicate group errors.
- BR-006 - If the user type does not match any recognised category (MUL/HO, MUL/RO, or DLR), no SQL is constructed and the list is not populated, effectively leaving the region selector empty.

---
**Implementation Logic**

```plsql
PROCEDURE List_Populate(p_name in varchar2) IS
	lv_query varchar2(2000);
 	rg_name varchar2(40);
	rg_id   recordgroup;
	gc_id   groupcolumn;
	lv_count number;
	lv_del_row number;
	lv_error varchar2(100);
	lv_sql varchar2(2000);
	lv_def_val varchar2(100);
	errcode NUMBER;
begin	
	--GENERAL.DISP_TEXT('X '||p_name||:global.userid,'Error');
	 rg_name :=p_name;
if p_name = 'P_REGION_CD' then
	  begin	
   		rg_id := Find_Group( rg_name );
					 IF :PARAMETER.P_USER_TYPE='MUL' and :PARAMETER.P_USER_HORO='HO' THEN
							lv_sql:='SELECT gm.REGION_DESC,gm.REGION_CD code FROM GM_REGN gm, am_user_region am where upper(am.USER_ID)= upper('''||:global.userid||''') AND AM.USER_TYPE=''SERVICE'' and gm.REGION_CD=am.REGION_CD and gm.COUNTRY_CD=''IND'' and gm.principal_map_cd = '''||:GLOBAL.PRINCIPAL||''' ORDER BY code';  /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
					 ELSIF :PARAMETER.P_USER_TYPE='MUL' and :PARAMETER.P_USER_HORO='RO' THEN		
					    lv_sql:='SELECT gm.REGION_DESC,gm.REGION_CD FROM GM_REGN gm, am_user_region am where upper(am.USER_ID)= upper('''||:global.userid||''') AND AM.USER_TYPE=''SERVICE'' and gm.REGION_CD=am.REGION_CD and gm.COUNTRY_CD=''IND'' and gm.principal_map_cd = '''||:GLOBAL.PRINCIPAL||''' ORDER BY gm.REGION_CD'; /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
					 ELSIF :PARAMETER.P_USER_TYPE='DLR' THEN
					 	   lv_sql:='SELECT gm.REGION_DESC,gm.REGION_CD FROM GM_REGN gm WHERE gm.REGION_CD='''||:PARAMETER.P_REGION||''' AND gm.COUNTRY_CD=''IND'' and gm.principal_map_cd = '''||:GLOBAL.PRINCIPAL||''' ORDER BY gm.REGION_CD';  /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
				 ELSE
				 	LV_SQL:=NULL;
					 END IF;	
		IF Id_Null(rg_id) THEN 
			rg_id := Create_Group_From_Query( rg_name,lv_sql); 
		END IF; 
		--Populate the record group
		errcode := Populate_Group( rg_id ); 
		POPULATE_LIST('CB_BLK.P_REGION_CD',RG_NAME);
		
		IF :PARAMETER.P_USER_TYPE='DLR' THEN
			 :CB_BLK.P_REGION_CD:=:PARAMETER.P_REGION;
		END IF; 	 
	  end;
	  /*
elsif p_name='P_MONTHYEAR' then
	BEGIN 
		--Make sure group doesn't already exist
		rg_id := Find_Group( rg_name); 
		
		lv_sql:='Select To_Char(Add_Months(Sysdate,Rownum-1),''Mon-Rrrr''),To_Char(Add_Months(Sysdate,ROWNUM-4),''Mm-Rr'') FROM DUAL';
		--If it does not exist, create it and add the two ** necessary columns to it.
		IF Id_Null(rg_id) THEN 
				rg_id := Create_Group_From_Query(rg_name,lv_sql); 
		END IF; 
		--Populate the record group
		errcode := Populate_Group( rg_id ); 
		POPULATE_LIST('CB_BLK.P_MONTHYEAR',RG_NAME);
		END; 
		*/
End If;
end;
```

#### SP-002 - POP_LIST

**Invoked From:**

- vr_calndr_fmb.xml [Trigger: KEY-CLRFRM]
- vr_calndr_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

POP_LIST initialises the calendar form's parameter screen by resolving the current user's type and dealer context, deriving the correct application ID, and dynamically configuring visible and mandatory list items (region code and month/year) based on the report parameter definitions held in ED_REPORTS. It is invoked both when the form first opens and when the form is cleared, ensuring the screen state is always consistent with the logged-in user's profile.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- LIST_POPULATE ([SP-001](#SP-001--LIST_POPULATE)) - JSON-LD ProgramUnit

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the user type (USER_TYPE) and multi-company code (MUL_CD) for the current user from AM_USERS using the global USERID; store results in PARAMETER.P_USER_TYPE and PARAMETER.P_USER_HORO respectively. If the query fails, both parameters are set to null.
- Step 2 - Evaluate PARAMETER.P_USER_TYPE. If the user is a dealer ('DLR'), proceed with dealer-specific APP_ID derivation (Steps 3-6); otherwise copy the global APP_ID directly into CB_BLK.APP_ID (Step 7).
- Step 3 (DLR path) - Extract the last four characters of GLOBAL.APP_ID from DUAL to check whether the suffix is '_dlr' (case-insensitive).
- Step 4 (DLR path) - If the suffix is '_dlr', strip those four trailing characters from GLOBAL.APP_ID and store the result in CB_BLK.APP_ID; otherwise copy GLOBAL.APP_ID unchanged into CB_BLK.APP_ID. If either DUAL query fails, CB_BLK.APP_ID is set to null.
- Step 5 (DLR path) - If CB_BLK.APP_ID is null after Step 4, exit the form immediately via DO_KEY('exit_form').
- Step 6 (DLR path) - Retrieve the dealer's region code, dealer name, location description, parent group, dealer map code, and location code from AM_USER_DEALER_MASTER joined to AM_DEALER_LOC for the primary location (PRIMARY_LOCN_YN = 'Y') of the current user. If that query fails, fall back to querying AM_DEALER_LOC using the global PARENT_GROUP, DEALER, and LOC_CD values. If the fallback also fails, CB_BLK.P_DEALER_DESC is set to 'DEALER USERS WRONG'.
- Step 7 (non-DLR path) - Copy GLOBAL.APP_ID into CB_BLK.APP_ID from DUAL.
- Step 8 - Open cursor C1, which selects SERIAL_NO, PARAMETER_NAME, and PARAMETER_DESC from ED_REPORTS filtered by APP_ID, excluding parameters of type 'L', and scoped to the current principal (GLOBAL.PRINCIPAL), ordered by SERIAL_NO.
- Step 9 - Iterate over each row returned by C1. For each row whose PARAMETER_NAME is 'P_REGION_CD': make the CB_BLK.P_REGION_CD item visible, enabled, and navigable; set its prompt text to the parameter description; apply the VA_MANDATORY visual attribute; then call LIST_POPULATE passing 'P_REGION_CD' to populate the list values.
- Step 10 - For each row whose PARAMETER_NAME is 'P_MONTHYEAR': make CB_BLK.P_MONTHYEAR visible, enabled, and navigable; apply the VA_MANDATORY visual attribute; then call LIST_POPULATE passing 'P_MONTHYEAR' to populate the list values.
- Step 11 - After the loop, if the user type is 'DLR', disable CB_BLK.P_DEALER_DESC so the dealer user cannot modify their own dealer description.

---
**Decision Points**

DP-001

Condition:
PARAMETER.P_USER_TYPE = 'DLR' (user is a dealer user)

TRUE:
Execute the dealer-specific APP_ID derivation logic (suffix check, DUAL queries, AM_USER_DEALER_MASTER / AM_DEALER_LOC lookups) described in Steps 3-6.

FALSE:
Copy GLOBAL.APP_ID directly into CB_BLK.APP_ID from DUAL (Step 7).

---

DP-002

Condition:
The last four characters of GLOBAL.APP_ID (lower-cased) equal '_dlr'

TRUE:
Strip the four-character suffix and store the shortened string in CB_BLK.APP_ID.

FALSE:
Copy GLOBAL.APP_ID unchanged into CB_BLK.APP_ID.

---

DP-003

Condition:
CB_BLK.APP_ID IS NULL after the APP_ID derivation for a dealer user

TRUE:
Call DO_KEY('exit_form') to terminate the form session immediately.

FALSE:
Continue processing (dealer lookup and parameter list population).

---

DP-004

Condition:
The primary-location join between AM_USER_DEALER_MASTER and AM_DEALER_LOC returns a row for the current dealer user

TRUE:
Populate PARAMETER.P_REGION, CB_BLK.P_DEALER_DESC, CB_BLK.LOC_DESC, CB_BLK.P_PARENT, CB_BLK.P_DEALER, and CB_BLK.P_LOC from the joined result.

FALSE:
Fall back to querying AM_DEALER_LOC using GLOBAL.PARENT_GROUP, GLOBAL.DEALER, and GLOBAL.LOC_CD; if that also fails, set CB_BLK.P_DEALER_DESC to 'DEALER USERS WRONG'.

---

DP-005

Condition:
Cursor C1 row PARAMETER_NAME = 'P_REGION_CD'

TRUE:
Make CB_BLK.P_REGION_CD visible, enabled, and navigable; set prompt text and VA_MANDATORY visual attribute; call LIST_POPULATE('P_REGION_CD').

FALSE:
Evaluate the next ELSIF condition (DP-006).

---

DP-006

Condition:
Cursor C1 row PARAMETER_NAME = 'P_MONTHYEAR'

TRUE:
Make CB_BLK.P_MONTHYEAR visible, enabled, and navigable; apply VA_MANDATORY visual attribute; call LIST_POPULATE('P_MONTHYEAR').

FALSE:
No action taken for this parameter row; continue to next loop iteration.

---

DP-007

Condition:
PARAMETER.P_USER_TYPE = 'DLR' (re-evaluated after the parameter loop)

TRUE:
Disable CB_BLK.P_DEALER_DESC (PROPERTY_FALSE) to prevent dealer users from editing their dealer description.

FALSE:
CB_BLK.P_DEALER_DESC remains in its default enabled state.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
- DB-002 - Read AM_USERS - Reads data from AM_USERS for lookup or validation.
- DB-003 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-004 - Read AM_USER_DEALER_MASTER - Reads data from AM_USER_DEALER_MASTER for lookup or validation.
- DB-005 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - A user's type and multi-company code must be resolved from AM_USERS before any screen configuration takes place; if the lookup fails, both values default to null and processing continues with reduced context.
- BR-002 - Only report parameters whose PARAM_TYPE is not 'L' and whose PRINCIPAL_MAP_CD matches the current global principal (GLOBAL.PRINCIPAL) are eligible for display on the calendar form.
- BR-003 - For dealer users (USER_TYPE = 'DLR'), the application ID must be derived by stripping the '_dlr' suffix from GLOBAL.APP_ID when that suffix is present; this ensures the base application ID is used for report parameter lookups.
- BR-004 - If the derived APP_ID for a dealer user is null, the form must not remain open; it must be exited immediately to prevent an undefined application context.
- BR-005 - A dealer user's location context (region, dealer name, location description, parent group, dealer map code, and location code) must be sourced from the user's primary location record (PRIMARY_LOCN_YN = 'Y') in AM_USER_DEALER_MASTER joined to AM_DEALER_LOC; if no primary location record exists, the global session variables (GLOBAL.PARENT_GROUP, GLOBAL.DEALER, GLOBAL.LOC_CD) serve as the fallback.
- BR-006 - The 'P_REGION_CD' and 'P_MONTHYEAR' form items must be marked with the VA_MANDATORY visual attribute when activated, indicating they are required inputs for the report.
- BR-007 - List items activated during parameter loop processing must be populated by delegating to LIST_POPULATE (SP-001), which is the sole authorised routine for loading list-of-values data.
- BR-008 - Dealer users must not be permitted to alter their own dealer description on screen; CB_BLK.P_DEALER_DESC is disabled for all users whose USER_TYPE is 'DLR'.

---
**Implementation Logic**

```plsql
PROCEDURE POP_LIST IS
LV_REGION VARCHAR2(2);
lv_dlr_chk varchar2(200);
lv_app_id varchar2(200);
	cursor c1 is select serial_no,parameter_name,parameter_desc
	from ed_reports
	where app_id=:APP_ID
	and param_type!='L' 
	and principal_map_cd=:GLOBAL.PRINCIPAL  /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
	ORDER BY serial_no;
BEGIN
  
    BEGIN   --Find the User Type
		SELECT USER_TYPE,MUL_CD INTO :PARAMETER.P_USER_TYPE,:PARAMETER.P_USER_HORO
		FROM AM_USERS WHERE LOWER(USER_ID)=LOWER(:GLOBAL.USERID);
		EXCEPTION 
		WHEN OTHERS THEN
		message('a'||sqlerrm||sqlcode);
		message('a'||sqlerrm||sqlcode);
			:PARAMETER.P_USER_TYPE:=null;
			:PARAMETER.P_USER_HORO:=null;
			--:CB_BLK.DEALER_NAME:='USER TYPE WRONG';
		END;	

		IF :PARAMETER.P_USER_TYPE='DLR' THEN  	--if user type DLR then
     -----set app id as per login user
      Begin
			  select substr(:global.app_id,length(:global.app_id)-3,length(:global.app_id)) into lv_dlr_chk
			  from dual;
      exception when others then
      	lv_dlr_chk:=null;
			end;	
  
		begin	
			if lower(lv_dlr_chk)='_dlr' then
			   select substr(:global.app_id,1,length(:global.app_id)-4) into :CB_BLK.APP_ID from dual;
			   --:CB_BLK.report_name:=:CB_BLK.APP_ID;
			else
				 select :global.app_id into :CB_BLK.APP_ID from dual;
				 
			end if;
		exception when others then	
			:CB_BLK.APP_ID:=null;
			:CB_BLK.report_name:=:CB_BLK.APP_ID;
		end;			
		if :CB_BLK.APP_ID is null then
			do_key('exit_form');
		end if;	
		BEGIN	
			SELECT AM.REGION_CD,AM.DEALER_NAME,AM.LOC_DESC,AM.PARENT_GROUP, AM.DEALER_MAP_CD, AM.LOC_CD
			INTO :PARAMETER.P_REGION ,:CB_BLK.P_DEALER_DESC,:CB_BLK.LOC_DESC,:CB_BLK.P_PARENT, :CB_BLK.P_DEALER,:CB_BLK.P_LOC
			FROM AM_USER_DEALER_MASTER usr,AM_DEALER_LOC AM
			WHERE LOWER(usr.USER_ID)=LOWER(:GLOBAL.USERID) 
			and usr.PRIMARY_LOCN_YN='Y'
			and AM.PARENT_GROUP=USR.PARENT_GROUP 
			and AM.DEALER_MAP_CD=USR.DEALER_MAP_CD
			and AM.LOC_CD=USR.LOC_CD;
		EXCEPTION 
			WHEN OTHERS THEN
		BEGIN	
			SELECT AM.REGION_CD,AM.DEALER_NAME,AM.LOC_DESC,AM.PARENT_GROUP, AM.DEALER_MAP_CD, AM.LOC_CD
			INTO :PARAMETER.P_REGION,:CB_BLK.P_DEALER_DESC,:CB_BLK.LOC_DESC,:CB_BLK.P_PARENT,:CB_BLK.P_DEALER, :CB_BLK.P_LOC
			FROM AM_DEALER_LOC AM
			WHERE AM.PARENT_GROUP=:GLOBAL.PARENT_GROUP 
			and AM.DEALER_MAP_CD=:GLOBAL.DEALER
			and AM.LOC_CD=:GLOBAL.LOC_CD;
		EXCEPTION WHEN OTHERS THEN
			:CB_BLK.P_DEALER_DESC:='DEALER USERS WRONG';
    END;			
		END;	
 else		
 	select :global.app_id into :CB_BLK.APP_ID from dual;
 end if;		
	
	

		
Declare
	lv_query 				VARCHAR2(2000);
	lv_all_dealers	VARCHAR2(2000);
	x_pos           NUMBER :=215;
	Y_POS           NUMBER :=90;

Begin
 For cur_val in c1 Loop
  if cur_val.parameter_name='P_REGION_CD' then
  	   set_item_property('CB_BLK.P_REGION_CD',visible,property_true);
	     set_item_property('CB_BLK.P_REGION_CD',ENABLED,property_true);
		   set_item_property('CB_BLK.P_REGION_CD',navigable,property_true);
		   set_item_property('CB_BLK.P_REGION_CD',PROMPT_TEXT,cur_val.parameter_desc);
 	   	 SET_ITEM_PROPERTY('CB_BLK.P_REGION_CD',VISUAL_ATTRIBUTE , 'VA_MANDATORY'); --MAKES THE FIELD MANDATORY(YELLOW)
		   List_populate(cur_val.parameter_name);
		  -- SET_ITEM_PROPERTY('CB_BLK.P_REGION_CD',position,x_pos, Y_POS);  
		 --  Y_POS :=Y_POS+15; 	
/* ELSif cur_val.parameter_name='P_FOR_DESC' then
	     set_item_property('CB_BLK.P_FOR_DESC',visible,property_true);
	     set_item_property('CB_BLK.P_FOR_DESC',ENABLED,property_true);
		   set_item_property('CB_BLK.P_FOR_DESC',navigable,property_true);
		   set_item_property('CB_BLK.P_FOR_DESC',PROMPT_TEXT,cur_val.parameter_desc);    
		   SET_ITEM_PROPERTY('CB_BLK.P_FOR_DESC',VISUAL_ATTRIBUTE , 'VA_MANDATORY'); 
		   SET_ITEM_PROPERTY('CB_BLK.P_FOR_DESC',position,x_pos, Y_POS);
		   Y_POS :=Y_POS+15;*/	    	
	ELSif cur_val.parameter_name='P_MONTHYEAR' then
	     set_item_property('CB_BLK.P_MONTHYEAR',visible,property_true);
	     set_item_property('CB_BLK.P_MONTHYEAR',ENABLED,property_true);
		   set_item_property('CB_BLK.P_MONTHYEAR',navigable,property_true);
		  --- set_item_property('CB_BLK.P_MONTHYEAR',PROMPT_TEXT,cur_val.parameter_desc);
		   	SET_ITEM_PROPERTY('CB_BLK.P_MONTHYEAR',VISUAL_ATTRIBUTE , 'VA_MANDATORY');     	    	
		  -- 	SET_ITEM_PROPERTY('CB_BLK.P_MONTHYEAR',position,x_pos, Y_POS);
		   	List_populate(cur_val.parameter_name);
		  -- 	Y_POS :=Y_POS+15;
/*	ELSif cur_val.parameter_name='P_PARENT' then
	     set_item_property('CB_BLK.P_PARENT',visible,property_true);
	     set_item_property('CB_BLK.P_PARENT',ENABLED,property_true);
		   set_item_property('CB_BLK.P_PARENT',navigable,property_true);
		   set_item_property('CB_BLK.P_PARENT',PROMPT_TEXT,cur_val.parameter_desc);
		   SET_ITEM_PROPERTY('CB_BLK.P_PARENT',VISUAL_ATTRIBUTE , 'VA_MANDATORY'); 
		   SET_ITEM_PROPERTY('CB_BLK.P_PARENT',position,x_pos, Y_POS);
		   Y_POS :=Y_POS+15;*/
	/*	ELSif cur_val.parameter_name='P_PROGRAM_CD' then
	     set_item_property('CB_BLK.P_PROGRAM_CD',visible,property_true);
	     set_item_property('CB_BLK.P_PROGRAM_CD',ENABLED,property_true);
		   set_item_property('CB_BLK.P_PROGRAM_CD',navigable,property_true);
		   set_item_property('CB_BLK.P_PROGRAM_CD',PROMPT_TEXT,cur_val.parameter_desc); 
		   SET_ITEM_PROPERTY('CB_BLK.P_PROGRAM_CD',VISUAL_ATTRIBUTE , 'VA_MANDATORY'); 
		   SET_ITEM_PROPERTY('CB_BLK.P_PROGRAM_CD',position,x_pos, Y_POS);
		   set_item_property('CB_BLK.P_PROGRAM_CD',visible,property_true);
	   --  SET_ITEM_PROPERTY('CB_BLK.P_PROGRAM_CD',position,353, Y_POS);
		 --  Y_POS :=Y_POS+15;
		 	   
/*	ELSif cur_val.parameter_name='P_LOC' then
	     set_item_property('CB_BLK.P_LOC',visible,property_true);
	     set_item_property('CB_BLK.P_LOC',ENABLED,property_true);
		   set_item_property('CB_BLK.P_LOC',navigable,property_true);
		   set_item_property('CB_BLK.P_LOC',PROMPT_TEXT,cur_val.parameter_desc); 	  
		   SET_ITEM_PROPERTY('CB_BLK.P_LOC',VISUAL_ATTRIBUTE , 'VA_MANDATORY');  	    	   
		   SET_ITEM_PROPERTY('CB_BLK.P_LOC',position,x_pos, Y_POS);
		   Y_POS :=Y_POS+15;*/
	END IF;
			
	end loop;    
	IF :PARAMETER.P_USER_TYPE='DLR' THEN 
		SET_ITEM_PROPERTY('CB_BLK.P_DEALER_DESC',ENABLED,PROPERTY_FALSE);
	END IF;

 
END;

END;
```

#### SP-003 - PR_PASS_PARAM

**Invoked From:**

- vr_calndr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Constructs a space-delimited report parameter string (Lv_param) for the calendar report screen (vr_calndr). The procedure reads the expected parameters for the active application and principal from ED_REPORTS, conditionally appends dealer and region parameters based on the report's configuration, and unconditionally appends date range, program code, and principal parameters before returning the assembled string to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare cursor c1 to retrieve parameter metadata (param_type, parameter_name, default_value, parameter_datatype) from ED_REPORTS filtered by the current application ID (:CB_BLK.APP_ID) and the current principal (:GLOBAL.PRINCIPAL), ordered by serial_no.
- Step 2 - Evaluate whether :CB_BLK.APP_ID equals 'vr_calndr'; in both the TRUE and ELSE branches, assign :CB_BLK.P_FRM_DT to Lv_frm_date and :CB_BLK.P_TO_DT to Lv_to_date (behaviour is identical in both branches as currently implemented).
- Step 3 - Iterate over all rows returned by cursor c1.
- Step 4 - For each cursor row where parameter_name = 'P_DLR', append the P_DLR parameter (sourced from :CB_BLK.P_DLR) and the P_PROGRAM_CD parameter (sourced from :CB_BLK.P_PROGRAM_CD) to Lv_param.
- Step 5 - For each cursor row where parameter_name = 'P_REGION_CD', append the P_REGION_CD parameter (sourced from :P_REGION_CD) to Lv_param.
- Step 6 - After the loop completes, unconditionally append P_FRM_DT (from :CB_BLK.P_FRM_DT), P_TO_DT (from :CB_BLK.P_TO_DT), P_PROGRAM_CD (from :CB_BLK.P_PROGRAM_CD), and P_PRINCIPAL (from :GLOBAL.PRINCIPAL) to Lv_param.
- Step 7 - Return the fully assembled Lv_param string to the caller via the IN OUT parameter.

---
**Decision Points**

DP-001

Condition:
:CB_BLK.APP_ID = 'vr_calndr'

TRUE:
Assign :CB_BLK.P_FRM_DT to Lv_frm_date and :CB_BLK.P_TO_DT to Lv_to_date within the IF branch.

FALSE:
Assign :CB_BLK.P_FRM_DT to Lv_frm_date and :CB_BLK.P_TO_DT to Lv_to_date within the ELSE branch. (Outcome is currently identical to the TRUE branch.)

---

DP-002

Condition:
cur_val.parameter_name = 'P_DLR' (evaluated for each row returned by cursor c1)

TRUE:
Append P_DLR (from :CB_BLK.P_DLR) and P_PROGRAM_CD (from :CB_BLK.P_PROGRAM_CD) to Lv_param.

FALSE:
No action taken for this parameter check; loop continues to the next condition.

---

DP-003

Condition:
cur_val.parameter_name = 'P_REGION_CD' (evaluated for each row returned by cursor c1)

TRUE:
Append P_REGION_CD (from :P_REGION_CD) to Lv_param.

FALSE:
No action taken for this parameter check; loop moves to the next iteration.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

- BR-001 - Parameter metadata must be scoped to both the active application (:CB_BLK.APP_ID) and the active principal (:GLOBAL.PRINCIPAL) when querying ED_REPORTS, ensuring multi-company data isolation.
- BR-002 - Parameter rows from ED_REPORTS are processed in ascending serial_no order, governing the sequence in which conditional parameters are appended to the parameter string.
- BR-003 - The P_DLR and P_PROGRAM_CD parameters are appended to the report string only when the report configuration explicitly declares a parameter named 'P_DLR'; they are not appended unconditionally.
- BR-004 - The P_REGION_CD parameter is appended to the report string only when the report configuration explicitly declares a parameter named 'P_REGION_CD'.
- BR-005 - Regardless of report configuration, P_FRM_DT, P_TO_DT, P_PROGRAM_CD, and P_PRINCIPAL are always appended to the parameter string after the cursor loop, guaranteeing these values are present for every report invocation.
- BR-006 - The principal value (:GLOBAL.PRINCIPAL) is included as P_PRINCIPAL in the parameter string to support multi-company report execution, consistent with the July 2014 multi-company change.

---
**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM (Lv_param IN OUT VARCHAR2)
IS
cursor c1 is select param_type,parameter_name,default_value,parameter_datatype
	           from   ed_reports
						 where  app_id = :CB_BLK.APP_ID
						   and  principal_map_cd = :GLOBAL.PRINCIPAL  /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
						 order by to_number(serial_no);
Lv_frm_date DATE;
Lv_to_date DATE;
LV_PROGRAM_CD VARCHAR2(50);	
L_AlertID						ALERT;
L_Alert							NUMBER;	
BEGIN

IF :CB_BLK.APP_ID IN('vr_calndr') THEN 
BEGIN
	
	Lv_frm_date:=:CB_BLK.P_FRM_DT;
	Lv_to_date:=:CB_BLK.P_TO_DT;
END;

/*
	IF 	:CB_BLK.APP_ID IN('vr_calndr') THEN
	BEGIN
		Lv_frm_date:=:CB_BLK.P_FRM_DT;
		Lv_to_date:=:CB_BLK.P_TO_DT;
	--	SELECT ((Add_Months (Sysdate,(-1) *3))), SYSDATE INTO Lv_frm_date,Lv_to_date FROM DUAL;
	--		EXCEPTION WHEN OTHERS THEN 			NULL;
	END;   	
*/
	ELSE	
	BEGIN	
			Lv_frm_date:=:CB_BLK.P_FRM_DT;
			Lv_to_date:=:CB_BLK.P_TO_DT;

		--	SELECT ((Add_Months (Sysdate,(-1) *3))), SYSDATE INTO Lv_frm_date,Lv_to_date FROM DUAL;
		--			EXCEPTION WHEN OTHERS THEN 	NULL;
		END;
	END IF;
	
	
	For cur_val in c1 Loop
		
/*		If cur_val.parameter_name = 'P_FRM_DT' OR cur_val.parameter_name = 'P_TO_DT' Then
--		If cur_val.parameter_name = 'P_MONTHYEAR' Then
	--		If :P_MONTHYEAR IS NULL THEN
		--     L_AlertID := Find_Alert('AL_ERRINFO');
		--  	 Set_Alert_Property(L_AlertID,Alert_Message_Text,'Please Enter From Date');
		--  	 L_Alert	 := Show_Alert(L_AlertID);
		  --	 Go_Item('CB_BLK.P_MONTHYEAR');
		--  	 RAISE form_trigger_failure;
	--		END IF;  	 
			lv_param := lv_param||' '||'P_FRM_DT='''||Lv_frm_date||''''; 
			lv_param := lv_param||' '||'P_TO_DT='''||Lv_to_date||''''; 
		*/	
		if cur_val.parameter_name = 'P_DLR' Then
		 		lv_param := lv_param||' '||'P_DLR='''||:CB_BLK.P_DLR||''''; 
		 		lv_param := lv_param||' '||'P_PROGRAM_CD='''||:CB_BLK.P_PROGRAM_CD||''''; 	
		End If;
		
		if cur_val.parameter_name = 'P_REGION_CD'  then
  	   lv_param := lv_param||' '||'P_REGION_CD='''||:P_REGION_CD||'''';
    end if;

	End Loop;	
		lv_param := lv_param||' '||'P_FRM_DT='''||:CB_BLK.P_FRM_DT||''''; 
		lv_param := lv_param||' '||'P_TO_DT='''||:CB_BLK.P_TO_DT||''''; 
		lv_param := lv_param||' '||'P_PROGRAM_CD='''||:CB_BLK.P_PROGRAM_CD||''''; 	
		lv_param := lv_param||' '||'P_PRINCIPAL='''||:GLOBAL.PRINCIPAL||'''';     /*Added PMC By Amit on 02-Jul-2014 For Multi Company Changes*/
--	lv_param:=lv_param||' '||'P_T_PARENT='''||:P_T_PARENT||''' P_T_DEALER='''||:P_T_DEALER||''' P_T_LOC='''||:P_T_LOC||'''';--P_PROGRAM_CD='''||:P_PROGRAM_CD||'''';
END;
```

#### SP-004 - PR_REMOVE_ASCII_CHR

**Invoked From:**

- vr_calndr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Sanitises a server-side text file that has been generated for Excel reporting by stripping form-feed characters (ASCII CHR(12)) from every line, writing the cleaned content to a new output file, and then opening that output file in a new browser window for the end user. The procedure is triggered from the calendar form (vr_calndr_fmb.xml) when the user presses the relevant button.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_filename | VARCHAR2 | IN |
| p_filename1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Open the source file for reading from the fixed server path '/iashome/ias/reports/printer/' concatenated with the input parameter p_filename.
- Step 2 - Open the destination file for writing at the same base path using the output filename supplied in p_filename1.
- Step 3 - Initialise the line counter v_cnt to 1 to track progress through the file.
- Step 4 - Enter a continuous loop; on each iteration read the next line from the source file into the local buffer variable linebuf using TEXT_IO.GET_LINE.
- Step 5 - For each line where v_cnt >= 1 (i.e., every line), inspect the first character of linebuf: if it is NOT a form-feed character (CHR(12)), write the line to the output file using TEXT_IO.PUT_LINE; if it IS a form-feed character, discard the line and do not write it.
- Step 6 - Increment v_cnt by 1 after processing each line.
- Step 7 - When NO_DATA_FOUND is raised (end of file reached) or any other exception occurs inside the loop, exit the loop immediately.
- Step 8 - Close both the input file and the output file using TEXT_IO.FCLOSE.
- Step 9 - Construct the relative browser path '/printer/' concatenated with filename1 and invoke WEB.SHOW_DOCUMENT to open the cleaned file in a new browser tab ('_blank').
- Step 10 - If any unhandled exception occurs at the outer level, call GENERAL.DISP_TEXT passing the concatenated SQLCODE and SQLERRM with the label 'Note' to display the error to the user.

---
**Decision Points**

DP-001

Condition:
The current line counter v_cnt >= 1 (evaluated for every line read from the source file).

TRUE:
Proceed to evaluate the first character of the line buffer (leads to DP-002).

FALSE:
Skip writing the line to the output file. (In practice this branch is never reached because v_cnt is initialised to 1 and only increments.)

---

DP-002

Condition:
The first character of linebuf (SUBSTR(linebuf, 1, 1)) is NOT equal to CHR(12) (form-feed / page-break character).

TRUE:
Write the line to the output file using TEXT_IO.PUT_LINE.

FALSE:
Discard the line; do not write it to the output file, effectively removing the form-feed character from the cleaned output.

---

DP-003

Condition:
An exception is raised inside the read loop (NO_DATA_FOUND indicating end-of-file, or any other exception).

TRUE:
Exit the loop immediately, proceeding to file-close and browser-display steps.

FALSE:
Continue looping and processing the next line.

---

DP-004

Condition:
An unhandled exception is raised in the outer execution block (WHEN OTHERS at procedure level).

TRUE:
Call GENERAL.DISP_TEXT with the concatenated SQLCODE and SQLERRM and the label 'Note' to surface the error to the user.

FALSE:
Procedure completes normally; no error message is displayed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the source file and the destination file must reside under the fixed server directory '/iashome/ias/reports/printer/'; the procedure does not support arbitrary file paths.
- BR-002 - Any line whose first character is a form-feed (ASCII CHR(12)) must be excluded entirely from the output file; all other lines must be written unchanged.
- BR-003 - File processing must be strictly sequential, line by line; no random-access or partial-line reads are permitted.
- BR-004 - Both the input file and the output file must be explicitly closed after processing, regardless of whether the loop completed normally or exited due to an exception.
- BR-005 - Upon successful completion, the cleaned output file must be presented to the user by opening it in a new browser window using the relative path '/printer/' concatenated with the output filename.
- BR-006 - Any exception raised at the outer procedure level must be caught and reported to the user via GENERAL.DISP_TEXT (SP-006) with the label 'Note', ensuring that file-processing errors are visible rather than silently swallowed.

---
**Implementation Logic**

```plsql
---Procedure to generate Excel report without Special Characters
Procedure pr_remove_ascii_chr (p_filename IN VARCHAR2, p_filename1 IN VARCHAR2)
IS
   in_file     text_io.file_type;
   out_file    text_io.file_type;
   linebuf     VARCHAR2 (5000);
   filename    VARCHAR2 (300);
   filename1   VARCHAR2 (300);
   v_cnt       NUMBER (10)       := 0;
BEGIN

   in_file := text_io.fopen ('/iashome/ias/reports/printer/' || p_filename, 'r');
   filename1 := p_filename1;
   out_file := text_io.fopen ('/iashome/ias/reports/printer/' || filename1, 'w');
   v_cnt := 1;
---Writing from one file to another file line by line  
   LOOP
      BEGIN
         text_io.get_line (in_file, linebuf);

         IF v_cnt >= 1
         THEN
            IF SUBSTR (linebuf, 1, 1) <> CHR (12)
            THEN
               text_io.put_line (out_file, linebuf);
            END IF;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            EXIT;
         WHEN OTHERS
         THEN
            EXIT;
      END;

      v_cnt := v_cnt + 1;
   END LOOP;
---Closing file
   text_io.fclose (in_file);
   text_io.fclose (out_file);
   
   filename := '/printer/' || filename1;
   web.show_document (filename, '_blank');
EXCEPTION
   WHEN OTHERS
   THEN
      general.disp_text ('Exception' || SQLCODE || SQLERRM, 'Note');
END;
```

#### SP-005 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_calndr_fmb.xml [Trigger: FT_CANCEL]
- vr_calndr_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator reflecting the button pressed. The function is used by calling triggers to determine whether the user has confirmed or cancelled a requested action before proceeding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user via show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed: if it equals ALERT_BUTTON1 (the affirmative button), return 1 to indicate user confirmation; otherwise return 0 to indicate the user did not confirm.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the first/affirmative button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the calling trigger that the user has confirmed the action.

FALSE:
The function returns 0, signalling to the calling trigger that the user has not confirmed the action (i.e., declined or dismissed the alert).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used is always AL_CONFIRM; this alert must exist in the form for the function to execute successfully.
- BR-002 - The message text displayed to the user is fully determined by the confirm_msg parameter supplied by the caller, making the function reusable across different confirmation scenarios.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response yields a return value of 0, treating all non-affirmative responses as a cancellation.
- BR-004 - The function has no side effects on the database; it solely governs user-interaction flow by returning a binary confirmation result to the calling trigger.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-006 - GENERAL.DISP_TEXT

**Invoked From:**

- vr_calndr_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_calndr_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]
- vr_calndr_fmb.xml [Trigger: FT_INSERT]
- vr_calndr_fmb.xml [Trigger: ON-ERROR]
- vr_calndr_fmb.xml [Trigger: ON-MESSAGE]
- vr_calndr_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate pre-defined Oracle Forms alert component ('AL_ERRINFO' for error conditions, 'AL_NOTE' for all other notifications), sets its title and message text dynamically, and presents it to the user. It is used across calendar form triggers and error-handling routines to surface both error and informational messages in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value (case-insensitive) to determine which alert component to use: if it equals 'ERROR', assign alert name 'AL_ERRINFO'; otherwise assign alert name 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert to the supplied title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert to the supplied text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT and capture the user's response in the local variable p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert component 'AL_ERRINFO' is selected, indicating an error-severity dialog will be displayed.

FALSE:
The alert component 'AL_NOTE' is selected, indicating an informational or non-error dialog will be displayed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title_string value is compared case-insensitively; any casing variant of the word 'ERROR' routes the display to the error alert ('AL_ERRINFO'), ensuring consistent error presentation regardless of how callers supply the title.
- BR-002 - All non-error messages (i.e., any title_string that is not 'ERROR') must use the 'AL_NOTE' alert, enforcing a two-tier alert classification: error versus informational.
- BR-003 - The alert title and message text are always set dynamically at runtime from the supplied parameters; the pre-defined alert components ('AL_ERRINFO' and 'AL_NOTE') serve only as templates and must exist in the form at design time.
- BR-004 - The user's alert button response is captured but intentionally ignored; the procedure is fire-and-forget with respect to user interaction, meaning callers do not receive feedback on which button the user pressed.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-007 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_calndr_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error and notification handling for Oracle Forms triggers. Given a message code, the procedure constructs a display-ready message string and routes it to GENERAL.DISP_TEXT with an appropriate dialog title based on the message severity type (Error, Note, or Caution). For error-severity messages, it additionally raises FORM_TRIGGER_FAILURE to halt form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Concatenate mesg_code with the (unresolved) mesg_text value to form the full display string in the format 'mesg_code : mesg_text'.
- Step 3 - Evaluate mesg_type to determine message severity and set the dialog title accordingly.
- Step 4 - If mesg_type is 'E' (Error), set mesg_title to 'Error', invoke GENERAL.DISP_TEXT to present the message to the user, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 5 - If mesg_type is 'N' (Note), set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT to present the informational message; processing continues normally.
- Step 6 - If mesg_type is 'C' (Caution), set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT to present the cautionary message; processing continues normally.
- Step 7 - If mesg_type does not match any of the three recognised values, no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set mesg_title to 'Error', call GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the error dialog, then raise FORM_TRIGGER_FAILURE to halt form trigger execution.

FALSE:
Proceed to evaluate DP-002.

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set mesg_title to 'Note', call GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the informational dialog; form processing continues.

FALSE:
Proceed to evaluate DP-003.

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set mesg_title to 'Caution', call GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the cautionary dialog; form processing continues.

FALSE:
None of the recognised severity types matched; the procedure exits without displaying a message or raising an exception.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The displayed message must always include the originating message code as a prefix, formatted as 'mesg_code : mesg_text', ensuring traceability back to the source code reference.
- BR-002 - A message severity of 'E' (Error) is treated as a blocking condition; the form trigger must be halted via FORM_TRIGGER_FAILURE after the error dialog is shown, preventing further form processing.
- BR-003 - A message severity of 'N' (Note) is non-blocking; the notification dialog is displayed and form processing continues uninterrupted.
- BR-004 - A message severity of 'C' (Caution) is non-blocking; the caution dialog is displayed and form processing continues uninterrupted.
- BR-005 - Only the three recognised severity codes ('E', 'N', 'C') trigger a user-facing dialog; any unrecognised mesg_type value results in silent no-op behaviour.
- BR-006 - All user-facing message dialogs must be rendered exclusively through GENERAL.DISP_TEXT (SP-006), ensuring consistent message presentation across the application.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

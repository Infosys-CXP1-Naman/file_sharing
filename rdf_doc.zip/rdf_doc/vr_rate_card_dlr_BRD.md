# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
  - 4.2 Form-Level Process Triggers
    - 4.2.1 Save and Commit (KEY-COMMIT)
    - 4.2.2 Form-Level Error Interception (ON-ERROR)
    - 4.2.3 System Message Interception (ON-MESSAGE)
    - Requirement ID: BR-006
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Dealer Location - AM_DEALER_LOC
    - Franchise Details - GM_FOR
    - Service Variant - VM_SVAR
    - Vehicle Variant - GM_VAR
    - City Classification - VM_MSIL_RPH
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Criteria (Dealer User - selecting criteria for Rate Card report generation)
    - Session Context (System - resolved from the active application session)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.CHECK_FORM_FAILURE
    - SP-004 - GENERAL.CHECK_NULL
    - SP-005 - GENERAL.DISP_TEXT
    - SP-006 - GENERAL.RAISE_ERROR
    - SP-007 - SF_COPYRIGHT_DECLARATION

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_RATE_CARD_DLR - Business Requirements Document |
| Form Module Name | VR_RATE_CARD_DLR |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_rate_card_dlr form, its purpose, and roles referenced in the module.*

The **vr_rate_card_dlr** Oracle Forms module is the dealer-facing **Vendor Rate Card** screen. It allows a dealer user to select a service model variant and a city category, then generate a rate card report showing the applicable rates for that combination. The user chooses the service model from a list of available variants for their assigned principal and selects the city type that governs the rate-per-hour pricing. Once both mandatory criteria are entered, the user submits the request and the system produces a PDF rate card report that opens in the browser. The form performs mandatory-field validation before generating the report and auto-populates the city category from the dealer's location profile when applicable. No records are created or modified; the form is a read-only reporting screen.

### Key Stakeholders

*Who uses vr_rate_card_dlr*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | **Primary interactive user** of vr_rate_card_dlr. Selects service model and city category criteria and initiates report generation. |
| **Principal / OEM** | Rate card data owner; service variant and city rate-per-hour data is maintained at the principal level and drives the available selections. |
| **Dealer Administrator** | Responsible for dealer and location profile setup; the dealer and location details used to pre-fill the city category are drawn from the dealer's registered profile. |

---

---

## 3. System Context

*Describes the vr_rate_card_dlr module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_rate_card_dlr** module is the dealer-facing **Vendor Rate Card** screen within the Dealer Management System. It serves as the entry point for dealers who need to view applicable service rates for a selected model variant and city category, providing a PDF report sourced from the reports server. It connects the dealer's session context to service-variant master data and city rate-per-hour reference data maintained by the principal.

**System purpose:** Allow a dealer user to select a service model and city category, validate the mandatory inputs, and generate the vendor rate card report as a PDF viewable in the browser - as implemented in the vr_rate_card_dlr Oracle Forms module.

**In scope:**

- Initialise the session with dealer, location, principal, and parent-group context inherited from the calling environment
- Auto-populate the city category field from the dealer's registered location profile when the parent group is not a head-office group
- Provide a Service Model LOV populated from service variant master data for the current principal
- Provide a City Category LOV populated from the MSIL rate-per-hour reference data for the current principal
- Validate that both the Service Model and City Category fields are filled before report generation
- Submit the vendor rate card report to the Oracle Reports Server and display the resulting PDF in the browser

**Process Name:** Vendor Rate Card Report Generation

**Process Owner:** INFERRED - Dealer Service Manager

**Process Objective:** Open the rate card screen, pre-fill or select the required criteria, validate mandatory fields, and generate the vendor rate card report for the selected service model and city category.

**Process Trigger:** Dealer user opens the Vendor Rate Card screen from the DMS menu

**Process Flow:**

The complete vendor rate card report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The dealer user opens the Vendor Rate Card screen.
         The system registers the session and applies the dealer, location, principal,
         and parent-group context from the calling environment.

STEP 2 ── COPYRIGHT DISPLAY
         The system populates the copyright declaration line at the bottom of the screen
         automatically from the registered copyright function.

STEP 3 ── CITY CATEGORY AUTO-POPULATION
         ├── STANDARD DEALER: If the dealer's parent group is not a head-office group,
         │             the city category field is automatically filled from the dealer's
         │             registered location profile using the dealer and location codes.
         └── HEAD-OFFICE GROUP: City category field is left blank for manual selection.

STEP 4 ── SERVICE MODEL SELECTION
         The user opens the Service Model list and selects a service variant.
         The list shows all service model descriptions available for the current principal.
         On selection, the fuel type and service variant code are auto-populated from the
         chosen model's master record.

STEP 5 ── SERVICE MODEL VALIDATION
         When the user leaves the Service Model field, the system checks that a model
         has been selected; if the field is empty, an error is shown and the user
         cannot proceed until a value is entered.

STEP 6 ── CITY CATEGORY SELECTION
         If not auto-populated, the user opens the City Category list and selects a city type.
         The list shows all distinct city RPH category types for the current principal.

STEP 7 ── CITY CATEGORY VALIDATION
         When the user leaves the City Category field, the system checks that a category
         has been selected; if empty, an error is shown and the user must enter a value.

STEP 8 ── REPORT GENERATION REQUEST
         The user presses the Generate Report button.
         The system performs a final check that both the city category and service model
         fields are filled; if either is missing, a "Please Enter All Mandatory Fields"
         error is displayed and report generation is blocked.

STEP 9 ── REPORT SUBMITTED TO SERVER
         The system submits the vendor rate card report to the Oracle Reports Server
         with the selected principal, city type, service variant code, and fuel type
         as report parameters.

STEP 10 ── PDF REPORT DISPLAYED
          The system opens the generated PDF rate card report in a new browser tab
          for the dealer user to view or print.

STEP 11 ── FORM RESET (optional)
          The user can clear the screen and re-enter different criteria using the
          clear-form function; steps 3-10 repeat as required.
```

**Major process interactions:**

- **Service variant master data** - provides the list of service model descriptions and codes for the current principal, and the associated fuel type
- **City RPH rate reference** - provides the list of distinct city category types for the current principal used in rate calculation
- **Dealer location profile** - supplies the dealer's city RPH type for automatic pre-population of the city category field
- **Oracle Reports Server** - receives the report parameters and generates the vendor rate card PDF for display in the browser
- **DMS session context** - provides dealer code, location code, principal map code, and parent-group code used throughout the form

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Initialisation and Application Activity Tracking

**Business Description:**
When the Rate Card Dealer form is opened, the system registers the current user session with the application monitoring infrastructure, identifying the form that is in use. If application performance logging is switched on for the environment, the system also starts a timing measurement so that the form's overall response time can be recorded. This ensures that support teams and system administrators have accurate, real-time visibility of which forms are active and can monitor performance metrics when logging is enabled.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has launched the Rate Card Dealer form from the application menu.

**Main Flow:**

**Step 1 - Session context registered with the application monitor**
As soon as the form opens, the system records that the current session is running the Rate Card Dealer form. This information is passed to the database application monitoring service so that active sessions are identifiable for support and auditing purposes.

**Step 2 - Performance timer started if logging is active**
If performance logging is currently enabled for the environment, the system starts a performance timer at the moment the form opens. This timer measures how long the form's initialisation takes and supports response-time auditing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Application logging flag checked before starting timer | PRE-FORM trigger - `IF :global.app_log = 'Y'` conditional branch | When the form is opened by the user | Ensures the performance timer is only started when the environment has logging enabled, avoiding unnecessary overhead when logging is off | If logging is not enabled, the timer is not started; form initialisation continues normally with no error |

**Step 3 - Main application window and MDI host window maximised**
Immediately after the session context is registered and the form begins rendering, the system maximises both the MDI host window and the form's main window (`WN_MAIN`) so that the Rate Card Dealer screen fills the entire display. This provides a consistent full-screen working area for the dealer user without requiring any manual window resizing.

**Step 4 - Toolbar action buttons enabled**
The system enables all standard toolbar action buttons on the push-button block (`PB_BLK`) so that the user can interact with the form's controls from the moment the form is fully open. The buttons enabled at this point are: Insert, Copy, Delete, Cut, Paste, and List of Values. The Save button remains disabled as this form does not perform database saves through the toolbar.

**Step 5 - Dealer city category pre-filled from location profile on form open**
When the dealer belongs to a standard dealer group (not the administrative grouping identified by parent group code `99999`), the system automatically looks up the city classification registered for the dealer's location and pre-fills the City Category field. The City Category field is then locked to prevent manual changes, and the cursor is moved directly to the Service Model field. When the dealer is in the administrative grouping, no automatic city lookup is performed and the cursor is placed on the City Category field for manual entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Standard dealer group check before auto-populating city category | WHEN-NEW-FORM-INSTANCE trigger - `IF :global.parent_group <> '99999'` conditional branch | When the form opens | Ensures the city category automatic lookup only runs for standard dealer groups; administrative groupings (`99999`) are excluded to avoid incorrect defaults | If the dealer is in the administrative grouping, the City Category field remains blank and the cursor is placed there for manual entry; no error is raised |
| City category database lookup | WHEN-NEW-FORM-INSTANCE trigger - `SELECT b.CITY_RPH_TYPE INTO :CB_BLK.city_type FROM AM_DEALER_LOC A, GM_FOR B` join on dealer location and principal | When the form opens for a standard dealer group | Retrieves the dealer's authorised city classification from the location and principal mapping records | If the lookup fails for any reason (WHEN OTHERS), the exception is silently ignored, the City Category field is left blank, and the form continues to open normally |

**Step 6 - Copyright notice displayed on form open**
After the city category pre-fill step, the system retrieves and displays the standard copyright declaration in the designated copyright display area of the form.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-004](#sp-004)) - SF_COPYRIGHT_DECLARATION - retrieves and returns the standard copyright declaration text to be displayed on the form.
    * **Step 1** - Retrieve the standard copyright declaration text that must be shown on all application screens.
    * **Step 2** - Retrieve the applicable business data required for the declaration.
    * **Step 3** - Apply any required business validations to the copyright retrieval process.
    * **Step 4** - Return the copyright declaration text to the calling form for display.
    * **Step 5** - Confirm that the processing result has been returned successfully.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) Application logging is not enabled: the performance timer is not started; session context is still registered normally and form initialisation proceeds without any timer or error.
- **BR-001-AF-02** - (from Step 5) Dealer belongs to the administrative grouping (parent group `99999`): the city category automatic lookup is skipped; the cursor is placed on the City Category field for the user to enter manually; the form continues to open normally.
- **BR-001-AF-03** - (from Step 5) City category database lookup fails unexpectedly: the error is silently ignored; the City Category field remains blank; the user may enter the value manually; no error message is displayed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Application Logging Flag (`APP_LOG` global) | Auto-populated | Session flag | 1 | N/A | N/A | Session initialised by calling application | System reads the flag to decide whether to start the performance timer; not user-editable | N/A - if flag is absent or not set to the logging-enabled value, timer is simply not started |
| City Category (`CITY_TYPE` on `CB_BLK`) | Conditional - auto-populated on form open for standard dealer groups | Text | 100 | Dealer location and principal mapping (`AM_DEALER_LOC`, `GM_FOR`) | City classification type (`CITY_RPH_TYPE`) from the dealer's registered location record | Dealer location record must exist in the system | Auto-populated from dealer location if dealer is in a standard group; field locked after auto-fill; skipped silently if dealer is in the administrative grouping | If the database lookup fails for any reason (WHEN OTHERS), the field is left blank and no error is displayed to the user |
| Copyright Notice (`COPY_RIGHT` on `CB_BLK`) | Auto-populated | Display | 100 | N/A | Copyright declaration text returned by SF_COPYRIGHT_DECLARATION | Form open sequence completed | System-set only; not user-editable | N/A |

---

#### Requirement ID: BR-002

**Requirement Title:** Form Reset and Dealer City Category Pre-population

**Business Description:**
When the user clears the form to start a new report request, the system resets all entered criteria and then automatically pre-fills the City Category field based on the dealer's location profile. This saves the user from manually re-entering location information that is already known from the dealer's registered details, and ensures the city classification used for the report matches the dealer's authorised area.

**Actors:** Dealer User

**Preconditions:**
- The user has the Rate Card Dealer form open with some or no criteria already entered.

**Main Flow:**

**Step 1 - Cancel action checked for unsaved changes**
When the user presses the Cancel toolbar button, the system first checks whether the Cancel button is currently enabled. If it is, the system checks whether the form contains unsaved changes. If the form has been modified since it was last cleared, the system asks the user to confirm that they are happy to discard those changes before proceeding with the reset.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancel button must be enabled before the reset can proceed | FT_CANCEL trigger - `IF GET_ITEM_PROPERTY('PB_BLK.PB_CANCEL', ENABLED) = 'TRUE'` | When the user presses the Cancel toolbar button | Prevents the cancel action from firing when the button has been programmatically disabled, ensuring the button's enabled state governs availability | If the Cancel button is not enabled, the reset is silently ignored and no action is taken |
| Unsaved changes confirmation when form has been modified | FT_CANCEL trigger - `IF :system.form_status = 'CHANGED'` branch calling `GENERAL.ASK_CONFIRM` | When the user presses Cancel and the form contains unsaved modifications | Protects the user from accidentally losing entered data; a confirmation dialogue is shown before discarding changes | *"Entered data will not be Saved"* is displayed as a confirmation prompt; if the user declines, the form is left as-is and no data is lost |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-IC-02** - Form has unsaved changes when Cancel is pressed - *"Entered data will not be Saved"* confirmation prompt is displayed; the user must confirm before the form is cleared.

**Step 2 - Form contents cleared**
The user confirms the cancel action (or the form has no unsaved changes). All currently entered selection criteria are cleared without saving, returning the form to a blank state ready for a new report request.

**Step 3 - Dealer's city category looked up and pre-filled**
When the dealer belongs to a normal dealer group (not a special administrative grouping), the system automatically looks up the city classification registered for the dealer's location and pre-fills the City Category field with that value. The user does not need to enter city category manually for a standard dealer session.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer group check before city-category lookup | KEY-CLRFRM trigger - `IF :global.parent_group <> '99999'` conditional branch | When the user clears the form | Ensures the automatic city-category lookup only runs for standard dealer groups; special administrative groupings skip the lookup to avoid incorrect defaults | If the dealer belongs to the administrative grouping, the city category is not pre-filled and the field remains blank for the user to enter manually; no error is shown |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-IC-01** - City Category auto-populated from dealer location record - the City Category field is automatically filled with the value from the dealer's registered location profile when a standard dealer group is active.

**Step 4 - Copyright notice displayed**
After the form reset and any city-category pre-fill, the system displays the standard copyright declaration in the designated copyright display area at the bottom of the form.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-004](#sp-004)) - SF_COPYRIGHT_DECLARATION - retrieves and returns the standard copyright declaration text to be displayed on the form.
    * **Step 1** - Retrieve the standard copyright declaration text that must be shown on all application screens.
    * **Step 2** - Retrieve the applicable business data required for the declaration.
    * **Step 3** - Apply any required business validations to the copyright retrieval process.
    * **Step 4** - Return the copyright declaration text to the calling form for display.
    * **Step 5** - Confirm that the processing result has been returned successfully.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| City Category (`CITY_TYPE`) | Conditional - auto-populated for standard dealer groups | Text | 100 | City category master (`VM_MSIL_RPH`) via dealer location profile | City classification code from dealer's location record | Dealer location record must exist in the system | Auto-populated from dealer location if dealer is in a standard group; skipped silently if dealer is in the administrative grouping | If the database lookup fails for any reason (WHEN OTHERS), the field is left blank and no error is displayed to the user |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display | 100 | N/A | Copyright declaration text returned by SF_COPYRIGHT_DECLARATION | Form reset completed | System-set only; not user-editable | N/A |

---

#### Requirement ID: BR-003

**Requirement Title:** Rate Card Report Generation with Mandatory Criteria Validation

**Business Description:**
The dealer user selects a Service Model and, optionally, reviews the pre-filled City Category, then presses the Generate Report button to produce a Dealer Rate Card report in PDF format. Before the report is submitted, the system checks that both mandatory criteria - Service Model and City Category - have been entered. If either is missing, the user is told to complete all required fields before proceeding. When all criteria are present, the system submits the rate card report request with the dealer's principal, city category, service variant, and fuel type, and displays the resulting PDF report in a new browser window.

**Actors:** Dealer User

**Preconditions:**
- The dealer user has the Rate Card Dealer form open.
- The City Category has been pre-filled automatically for standard dealer groups or entered manually where required.

**Main Flow:**

**Step 1 - Service Model selected by the user**
The user selects a Service Model from the list of available models. The list is filtered to models registered for the current dealer's principal, showing only models that have a fuel type assigned.

**Step 2 - Service Model validated as entered on tab-out**
When the user moves away from the Service Model field by pressing the Tab key, the system checks that a Service Model value has been entered. The Service Variant code and Fuel Type associated with the selected model are carried forward automatically for use in the report.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#sp-002)) - GENERAL.CHECK_NULL - validates that the Service Model field is not empty before the user can move to the next field; raises an error and stops navigation if the field is blank.
    * **Step 1** - Check whether the value passed in (the current Service Model selection) is present.
    * **Step 2** - Retrieve the applicable business data required for the validation.
    * **Step 3** - Apply the business validation that a mandatory field must not be left blank.
    * **Step 4** - If the value is absent, raise an error to prevent the user from tabbing past this field without entering a value.
    * **Step 5** - Return the validation result to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Service Model must be entered before leaving the field | GENERAL.CHECK_NULL [SP-002] called from KEY-NEXT-ITEM on SERVICE MODEL field | When the user presses Tab to leave the Service Model field | Ensures the user has selected a Service Model before navigating to the next field, preventing the form from reaching report generation with an empty model selection | The cursor stays on the Service Model field; the user must enter a value before the tab navigation succeeds |

**Step 3 - City Category validated as entered on tab-out**
When the user moves away from the City Category field by pressing the Tab key, the system checks that a City Category value has been entered. If the City Category was pre-filled automatically during a form reset, that value is validated here.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-002](#sp-002)) - GENERAL.CHECK_NULL - validates that the City Category field is not empty before the user can move to the next field; raises an error and stops navigation if the field is blank.
    * **Step 1** - Check whether the value passed in (the current City Category selection) is present.
    * **Step 2** - Retrieve the applicable business data required for the validation.
    * **Step 3** - Apply the business validation that a mandatory field must not be left blank.
    * **Step 4** - If the value is absent, raise an error to prevent the user from tabbing past this field without entering a value.
    * **Step 5** - Return the validation result to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| City Category must be entered before leaving the field | GENERAL.CHECK_NULL [SP-002] called from KEY-NEXT-ITEM on CITY CATEGORY field | When the user presses Tab to leave the City Category field | Ensures the user has a City Category selected before navigating away, preventing the form from reaching report generation with an empty city selection | The cursor moves to the Service Model field; the user must enter a City Category value before the tab navigation succeeds |

**Step 4 - Generate Report button pressed and mandatory criteria re-validated**
The user presses the Generate Report button. The system re-checks that both Service Model and City Category have been filled in. If either field is still empty, the user sees an error message and the report request is cancelled.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays the error message *"Please Enter All Mandatory Fields"* with Error severity when one or both mandatory criteria are missing; raises a trigger failure to cancel the report request.
    * **Step 1** - Receive the message text and severity indicator to display.
    * **Step 2** - Retrieve the appropriate display format for the given severity level.
    * **Step 3** - Apply the business validation that the message must be shown to the user.
    * **Step 4** - Display the message on screen and halt further processing.
    * **Step 5** - Return control to the calling trigger after the message has been presented.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Both Service Model and City Category must be entered before report generation | GENERAL.DISP_TEXT [SP-003] called from WHEN-BUTTON-PRESSED on Generate Report button - `IF :cb_blk.city_type IS NULL OR :cb_blk.model_type IS NULL` | When the user presses the Generate Report button | Prevents submitting a rate card report request without the minimum required criteria; ensures the report engine always receives a valid model and city combination | *"Please Enter All Mandatory Fields"* is displayed; the report is not submitted; the user must fill in the missing field(s) and press Generate Report again |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - One or both mandatory criteria (Service Model, City Category) are empty when Generate Report is pressed - *"Please Enter All Mandatory Fields"*; the report request is cancelled and the user must complete the missing fields before retrying.

**Step 5 - Rate Card report submitted and displayed in browser**
Once all mandatory criteria pass validation, the system configures and submits the rate card report request for the dealer's principal, city category, service variant, and fuel type. The report is generated in PDF format and opened in a new browser window.

*Procedures called:*
- **CALL_REPORT** ([SP-001](#sp-001)) - CALL_REPORT - configures the report object with the selected criteria and output format, submits the rate card report to the report server, and opens the resulting PDF in a new browser window.
    * **Step 1** - Receive the dealer's principal code, city category, service variant code, and fuel type as report criteria.
    * **Step 2** - Locate the rate card report definition in the system using the registered report object handle.
    * **Step 3** - Configure the report output format as PDF, pass all four criteria as report parameters, and identify the target report server from the session configuration.
    * **Step 4** - Submit the report request to the report server and receive the job identifier for the generated report.
    * **Step 5** - Open the generated PDF report in a new browser window using the job identifier returned by the report server.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report criteria passed to report server successfully | CALL_REPORT [SP-001] - report object configuration and RUN_REPORT_OBJECT call | When the user's mandatory criteria have passed validation and the report is submitted | Ensures the rate card report is generated with the correct dealer, city, model, and fuel type combination | If an unexpected error occurs during report submission (WHEN OTHERS), the Oracle database error message text is displayed followed by a blank spacer message; report generation stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-02** - An unexpected error occurs during report submission - the system's own database error text (`SQLERRM`) is shown, followed by a blank spacer message; the report is not generated and the user must retry.
- **BR-003-SM-01** - All criteria validated and report submitted successfully - the Dealer Rate Card PDF report opens in a new browser window for the user to view or download.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 4) Service Model is blank when Generate Report is pressed: *"Please Enter All Mandatory Fields"* is displayed; the trigger fails and the report is not submitted; the user must enter the Service Model and press Generate Report again.
- **BR-003-AF-02** - (from Step 4) City Category is blank when Generate Report is pressed: *"Please Enter All Mandatory Fields"* is displayed; the trigger fails and the report is not submitted; the user must provide the City Category and press Generate Report again.
- **BR-003-AF-03** - (from Step 5) An unexpected error occurs in the report submission: the Oracle error message text is displayed followed by a blank spacer message; the report is not generated; the user may retry by pressing Generate Report again.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Service Model (`MODEL_TYPE`) | Mandatory | Text | 30 | Service Model list (`RG_SRV_MODEL` / `LV_SRV_MODEL`) - service variant description and code, filtered to models with a fuel type for the current principal | Service variant description (display) and service variant code (hidden return) | Form open | Must not be blank; checked on tab-out from the field and again on Generate Report | Cursor stays on the Service Model field if blank on tab-out; *"Please Enter All Mandatory Fields"* shown if blank on Generate Report |
| City Category (`CITY_TYPE`) | Conditional - auto-populated for standard dealer groups; mandatory for all | Text | 100 | City category list (`RG_CITY_TYPE` / `LV_CITY_TYPE`) - city classification codes for the current principal | City classification code | Form open | Must not be blank; checked on tab-out from the field and again on Generate Report | Cursor moves to Service Model field if blank on tab-out; *"Please Enter All Mandatory Fields"* shown if blank on Generate Report |
| Fuel Type (`FUEL_TYPE`) | Auto-populated | Display | 30 | Populated from the Service Model list selection (`RG_SRV_MODEL`) | Fuel type code associated with the selected service variant | Service Model selected | Read-only; populated automatically when a Service Model is selected | N/A |
| Service Variant Code (`SVAR_CD`) | Auto-populated | Internal | N/A | Populated from the Service Model list selection (`RG_SRV_MODEL`) | Service variant code associated with the selected Service Model | Service Model selected | System-set; not directly user-editable; passed as a report parameter | N/A |

---

#### Requirement ID: BR-004

**Requirement Title:** Form Exit and Application Session Cleanup

**Business Description:**
When the user closes the Rate Card Dealer form, the system clears the session's application context information and exits the form without saving any unsaved changes. This ensures that database session monitoring tools no longer show the Rate Card Dealer form as active once the user has left, keeping session tracking accurate across all active users.

**Actors:** Dealer User

**Preconditions:**
- The Rate Card Dealer form is open.

**Main Flow:**

**Step 1 - Application session context cleared**
When the user triggers the form exit, the system removes the Rate Card Dealer form identifier from the database session monitoring context. Both the client session label and the module/action tracking identifiers are cleared so that the session is no longer reported as using this form.

**Step 2 - Form closed without saving**
The form exits immediately without prompting the user to save or validating any unsaved data. All unsaved criteria selections are discarded.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) The exit is unconditional; no alternate path exists - session context is always cleared and the form always exits when this action is triggered.

---

#### Requirement ID: BR-005

**Requirement Title:** Rate Card Data Export to CSV Format - Form-Level Utility (Not Currently Triggered)

**Business Description:**
The form contains a built-in utility that can generate a Comma-Separated Values (CSV) file from a specified data query and make it available for download in the user's browser. The output filename is automatically constructed from the logged-in user's identifier combined with the export date and time, ensuring each export file has a unique name. If the data set returned by the query exceeds 65,535 rows, the file is automatically truncated to that limit and the user is informed. If the intended save path contains spaces in any folder name, the file is redirected to the default root of the C drive instead and the user is notified. The completed CSV file is then opened in a new browser window. This utility procedure is defined in the form's code but is not currently called by any button, trigger, or navigation action within this form.

**Actors:** System (form-level utility program unit `VIEW_EXCEL_REP` - INACTIVE CALL PATH: no trigger or button in this form currently invokes this program unit)

**Preconditions:**
- This requirement documents the form-level program unit `VIEW_EXCEL_REP`, which exists in the form's code but has no active callers within the current form. It would only execute if invoked from a future enhancement or by an external caller not currently present in this form.

**Main Flow:**

**Step 1 - Output filename generated from user identity and current date-time**
The system constructs a unique output filename by combining the current user's login identifier with the export date and time, appended with a `.csv` extension.

**Step 2 - File path validated: space characters in folder names are not permitted**
The system checks whether the constructed file path contains any space characters in a folder name. If space characters are detected in a folder name, the file is redirected to the root of the C drive and the user is informed of the change.

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-01** - File path contains spaces in a folder name - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; the save path is changed to the C drive root and the export continues from there.

**Step 3 - Data query executed and results loaded**
The system runs the provided data query and loads all resulting rows into a working data set in memory. Any previous working data set with the same name is first removed before the new one is created and populated.

**Step 4 - Row count checked against Excel row limit**
The system counts how many rows were returned. If the row count exceeds 65,535 rows, the output is capped at 65,535 rows and the user is informed of the truncation.

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-02** - Row count exceeds 65,535 rows - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; the CSV export proceeds with only the first 65,535 rows.

**Step 5 - CSV file written to the server and opened in browser**
The system reads the target server path from a configuration file on the report server (`/reports/DMS/excelpath.txt`), writes the CSV rows to a file at that location, and then opens the file in a new browser window for the user to download.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) File path contains spaces: the path is corrected to the C drive root; the informational message is shown; export continues with the corrected path.
- **BR-005-AF-02** - (from Step 4) Query returns more than 65,535 rows: output is truncated; the informational message is shown; the truncated CSV is written and opened in the browser.

---

### 4.2 Form-Level Process Triggers

#### 4.2.1 Save and Commit (KEY-COMMIT)

When the user presses the Save/Commit key, the system validates all current form entries, commits the data to the database if validation passes, and then clears the form ready for the next entry. If validation fails at any point, the commit is not performed and the form remains in its current state for the user to correct.

**Main Flow:**

**Step 1 - Form entries validated before commit**
The system runs the built-in Forms validation routine (`ENTER`) to validate all current field values and trigger any item-level validation logic. If validation detects an error, further processing stops and the commit is not attempted.

**Step 2 - Form failure checked after validation**
The system checks whether the validation step raised a failure condition. If a failure occurred during validation, the commit sequence is cancelled and the user is left on the form to correct the problem.

**Step 3 - Data committed to the database**
Once validation has passed without failure, the system submits a database commit for all pending form changes. The data is permanently saved.

**Step 4 - Commit result checked**
The system checks again whether a failure was raised during the commit operation. If the commit itself raised a failure, the user is left on the form; the data may not have been saved.

**Step 5 - Form cleared after successful commit**
If both the validation and the commit steps complete without failure, the system clears the form entirely, returning it to a blank state ready for the next transaction.

#### 4.2.2 Form-Level Error Interception (ON-ERROR)

The form intercepts all Oracle Forms runtime errors before they are displayed to the user and translates specific error codes into clear, business-appropriate messages. When an error code matches a known condition, the system displays a specific message and prevents further processing; unmatched errors that originate from the database are shown using the database error text; errors in the informational range are silently ignored.

**Main Flow:**

**Step 1 - Date validity error intercepted**
When Forms raises error code `50004` (a date value that could not be parsed), the system displays the message *"Entered Date is not valid Date"* with Error severity and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code `50004` matched | ON-ERROR trigger - `IF errnum in (50004)` branch | When a date field receives a value that is not a valid date | Provides a plain-language date-validity message instead of the raw Forms error number | *"Entered Date is not valid Date"* is displayed; the user must correct the date entry before proceeding |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-03** - Forms error code `50004` raised - *"Entered Date is not valid Date"*; the user must supply a valid date value.

**Step 2 - Date format error intercepted**
When Forms raises error codes `50025` or `50026` (date format violations), the system displays the message *"Enter the Date in the proper format (DD-MM-YYYY)"* with Error severity and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes `50025` or `50026` matched | ON-ERROR trigger - `IF errnum in (50025, 50026)` branch | When a date field value does not conform to the expected format | Gives the user an explicit format instruction rather than a generic Forms message | *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed; the user must re-enter the date in the correct format |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-04** - Forms error codes `50025` or `50026` raised - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the user must supply a date in DD-MM-YYYY format.

**Step 3 - Non-numeric input error intercepted**
When Forms raises error codes `40209` or `50016` (non-numeric characters entered in a numeric field), the system displays the message *"Characters/Special Characters are not allowed here, enter the numeric value"* with Error severity and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error codes `40209` or `50016` matched | ON-ERROR trigger - `IF errnum in (40209, 50016)` branch | When a numeric field receives a character or special-character value | Provides a plain-language message telling the user that the field requires a numeric value | *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed; the user must enter a valid numeric value |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-05** - Forms error codes `40209` or `50016` raised - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the user must supply a numeric value.

**Step 4 - Field-specific validation error intercepted**
When Forms raises error code `40207` (a field-level validation failure), the system displays the standard Forms error text for that code with Error severity and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code `40207` matched | ON-ERROR trigger - `IF errnum in (40207)` branch | When a field validation rule raises a standard Forms validation error | Surfaces the system-defined validation message for the user rather than allowing the default Forms error presentation | The Forms error text for code `40207` is displayed; the user must correct the offending field value |

**Step 5 - Database integrity constraint error intercepted**
When the database raises error `-02292` (a child-record integrity constraint violation), the system invokes the standard error-reporting routine (`GENERAL.RAISE_ERROR('E0088')`) to present a user-friendly constraint violation message.

**Step 6 - Concurrent update conflict intercepted**
When Forms raises any of error codes `40654`, `40655`, `40656`, `40657`, or `40659` (record-locking or concurrent modification errors), the system displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* with Error severity, issues a database rollback, and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update error codes matched | ON-ERROR trigger - `IF ERROR_CODE IN (40654, 40655, 40656, 40657, 40659)` branch | When another user has modified the same record since it was queried by the current user | Prevents silent data overwrites caused by concurrent modifications; prompts the user to re-query the record before making changes | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; a rollback is performed; the user must re-query and retry |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-06** - Concurrent update error codes `40654`, `40655`, `40656`, `40657`, or `40659` raised - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; the transaction is rolled back and the user must re-query before retrying.

**Step 7 - Unhandled database error shown and rolled back**
If the SQL error code from the database is non-zero and was not matched by any of the specific branches above, the system displays the Oracle database error message text (`SQLERRM`) with Error severity, issues a rollback, and stops further processing.

**Step 8 - Informational errors silently suppressed**
Error codes `40401` and `40405` (end-of-query and no-rows-found informational codes) are silently ignored; no message is shown and processing continues normally.

#### 4.2.3 System Message Interception (ON-MESSAGE)

The form intercepts Oracle Forms system messages for specific message codes and replaces the default system presentation with an Error-severity display, preventing the user from proceeding past the condition.

**Main Flow:**

**Step 1 - Numeric input or validation message intercepted**
When Forms raises message code `40209` or `40207` as a system message (rather than an error), the system formats the message as `type-code: text` and displays it with Error severity using `GENERAL.DISP_TEXT`, then raises a trigger failure to block further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message codes `40209` or `40207` matched | ON-MESSAGE trigger - `IF errnum in (40209, 40207)` branch | When Forms issues a system message for a numeric or validation condition | Promotes these conditions from informational messages to error-level responses, ensuring the user cannot ignore them | The message text for the matching code is displayed with Error severity; the user must acknowledge and correct the condition before continuing |

---

#### Requirement ID: BR-006

**Requirement Title:** Record Deletion with User Confirmation

**Business Description:**
When the user presses the Delete toolbar button, the system requires the user to confirm the deletion before any record is removed. If the form contains unsaved changes (meaning a record is active and has been modified), the system presents a confirmation dialogue to the user before deleting the record from the database. If the form has no unsaved changes, it is simply cleared without deletion. This two-step gate ensures that records are never deleted accidentally and that only intentional, confirmed deletions are processed.

**Actors:** Dealer User

**Preconditions:**
- The Rate Card Dealer form is open.
- The Delete toolbar button (`PB_BLK.PB_DEL`) is enabled.

**Main Flow:**

**Step 1 - Delete button availability checked**
When the user presses the Delete toolbar button, the system first checks whether the button is currently enabled. If it is not enabled, no action is taken and the form remains unchanged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete button must be enabled before the delete action proceeds | FT_DEL trigger - `IF GET_ITEM_PROPERTY('PB_BLK.PB_DEL', ENABLED) = 'TRUE'` | When the user presses the Delete toolbar button | Prevents the delete action from firing when the button has been programmatically disabled | If the Delete button is not enabled, the action is silently ignored and no data is affected |

**Step 2 - Form validation temporarily suspended**
Before navigating to the data record, the system temporarily suspends form-level validation so that navigation can proceed without triggering premature validation errors during the delete sequence.

**Step 3 - Delete confirmation requested when form has active changes**
The system navigates to the base data block. If the form contains a record that has been modified (the form status is `CHANGED`), the system asks the user to confirm whether they wish to proceed with the deletion.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User confirmation required before deleting a changed record | FT_DEL trigger - `IF :system.form_status = 'CHANGED'` branch calling `GENERAL.ASK_CONFIRM` | When the user presses Delete and the form contains an active, modified record | Prevents accidental deletion of data the user is currently editing; a confirmation dialogue is shown before the record is removed | *"Are you sure to Delete"* is displayed as a confirmation prompt; if the user declines (response is not 1), the deletion is cancelled and the record is preserved |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-IC-01** - Form has an active modified record when Delete is pressed - *"Are you sure to Delete"* confirmation prompt is displayed; the user must confirm before the record is deleted.

**Step 4 - Record deleted on confirmation**
If the user confirms the deletion (confirmation response equals 1), the system deletes the current record from the database. If the user declines, no deletion occurs and the form returns to its previous state.

**Step 5 - Form cleared when no active changes are present**
If the form does not contain a modified record when Delete is pressed (the form status is not `CHANGED`), the system clears the form without performing a database deletion, returning the screen to a blank state.

**Step 6 - Form validation restored**
After the delete sequence completes (whether a record was deleted, the user declined, or the form was cleared), the system re-enables form-level validation to its normal active state.

**Alternative Flows:**
- **BR-006-AF-01** - (from Step 1) Delete button is not enabled: the action is silently ignored; no navigation, deletion, or confirmation occurs.
- **BR-006-AF-02** - (from Step 3) User is asked to confirm deletion but declines: the record is not deleted; the form remains in its current modified state; the user can continue editing or cancel separately.
- **BR-006-AF-03** - (from Step 5) Form has no active modified record when Delete is pressed: the form is cleared without database deletion; no confirmation is required.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Delete Button State (`PB_BLK.PB_DEL`) | System-controlled | Button | N/A | N/A | Enabled/Disabled | Form open | Delete action only proceeds when the button is in the enabled state | If disabled, the delete action is silently ignored |

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Service Model is mandatory | Validation | BR-003 | The Service Model field is left blank when the user tabs out of it | Prevent navigation away from the field and require the user to enter a Service Model value before proceeding | Ensures a valid Service Model is always selected before the user can reach the Generate Report button, preventing incomplete report submissions |
| BRC-002 | City Category is mandatory | Validation | BR-003 | The City Category field is left blank when the user tabs out of it | Return the cursor to the Service Model field and require the user to enter a City Category value before proceeding | Ensures a valid City Category is always present before the user can reach the Generate Report button, preventing report submissions with no city filter |
| BRC-003 | Both mandatory criteria must be filled before report generation | Validation | BR-003 | One or both of Service Model and City Category are blank when the Generate Report button is pressed | Display *"Please Enter All Mandatory Fields"* and cancel the report request | Prevents the rate card report from being submitted to the report server without the minimum required filter criteria, avoiding blank or invalid report output |
| BRC-004 | City Category pre-fill limited to standard dealer groups | Derivation | BR-002 | The current dealer's parent group is not the special administrative grouping | Automatically look up and pre-fill the City Category from the dealer's registered location profile | Saves the user from entering the city classification manually for standard dealer sessions while correctly bypassing the automatic fill for administrative groupings that have no fixed location |
| BRC-005 | Silent handling of city category lookup failure | Constraint | BR-002 | A database error occurs while looking up the dealer's city category after a form reset | Leave the City Category field blank and continue without displaying any error message to the user | Prevents a failed location lookup from blocking the form reset; the user can still enter the City Category manually if the auto-fill does not populate the field |
| BRC-006 | Performance timer starts only when application logging is enabled | Constraint | BR-001 | Application logging is enabled for the current environment at form open time | Start the performance timer when the form is initialised | Ensures performance measurement overhead is only incurred in environments where logging has been switched on, avoiding unnecessary processing in production or environments where logging is disabled |
| BRC-007 | CSV export file path must not contain spaces in folder names | Validation | BR-005 | The generated CSV output file path contains one or more spaces in a folder name | Redirect the file to the root of the C drive and inform the user: *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Prevents a file write failure caused by a path with spaces; ensures the export file is always written to an accessible location even when the user's profile path contains spaces |
| BRC-008 | CSV export row count capped at 65,535 rows | Constraint | BR-005 | The data query returns more than 65,535 rows | Truncate the export to 65,535 rows and inform the user: *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents the CSV file from exceeding the maximum number of rows that Microsoft Excel can open, ensuring the exported file can be used by the recipient without row-limit errors |
| BRC-009 | Unexpected errors during report submission are surfaced to the user | Constraint | BR-003 | An unexpected database or system error occurs while submitting the rate card report | Display the Oracle database error message text followed by a blank spacer message; stop report generation | Ensures the user is informed of any unexpected failure during report submission rather than experiencing a silent error, allowing them to retry or escalate the issue |

**Total Business Rules Identified: 9**

---

## 6. Data Requirements

*This section describes the data entities referenced by the Rate Card Dealer form, the report criteria captured from the user, the reference data used to populate selection lists, and the lifecycle of data within the form's scope.*

### 6.1 Business Entities and Relationships

*The Rate Card Dealer form does not maintain its own master data tables. It reads from several reference and configuration tables to populate the report criteria selection fields and to pre-fill the dealer's city classification.*

#### Dealer Location - AM_DEALER_LOC

This entity stores the registered location details for each dealer outlet, including the dealer's assigned city classification category. The form reads from this entity during a form reset to automatically pre-fill the City Category field for the current dealer's session, using the principal, parent group, dealer code, and location code from the active session context.

#### Franchise Details - GM_FOR

This entity holds franchise configuration details, including the city classification type assigned to a franchise. The form joins this entity with the Dealer Location entity to resolve the city category associated with the current dealer's franchise registration.

#### Service Variant - VM_SVAR

This entity holds the catalogue of service variant records for each principal. The form's Service Model selection list queries this entity to present the available service model descriptions and their associated service variant codes, filtered to those variants that have a fuel type assigned.

#### Vehicle Variant - GM_VAR

This entity holds vehicle variant details, including fuel type codes. The form joins this entity with the Service Variant entity to retrieve the fuel type associated with each service variant, which is then passed as a parameter when the rate card report is generated.

#### City Classification - VM_MSIL_RPH

This entity holds the set of city classification codes (city category types) defined for each principal. The form's City Category selection list queries this entity to present the available city categories for the current dealer's principal.

#### Entity Relationships

The Dealer Location and Franchise entities are joined by franchise code and principal code to resolve the city category for the current dealer's location. The Service Variant and Vehicle Variant entities are joined by principal code and variant code to link service descriptions with their fuel types. These lookup joins are used only at form initialisation and when populating the selection criteria lists; the form does not write to any of these entities.

```
AM_DEALER_LOC (Dealer Location)
        └── GM_FOR (Franchise Details)       <- joined on FOR_CD + PRINCIPAL_MAP_CD

VM_SVAR (Service Variant)
        └── GM_VAR (Vehicle Variant)          <- joined on PRINCIPAL_MAP_CD + SVAR_CD

VM_MSIL_RPH (City Classification)             <- standalone lookup for city category list
```

### 6.2 Data Capture Requirements

*The form captures report filter criteria entered by the dealer user. No records are inserted or updated by this form; all captured values are passed as parameters to the rate card report.*

#### Report Criteria (Dealer User - selecting criteria for Rate Card report generation)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Service Model (`MODEL_TYPE`) | Yes | The service model selected by the user from the available list for the current principal. The selection also carries the associated service variant code and fuel type for use as report parameters. | Must not be left blank; validated on tab-out from the field and again when the Generate Report button is pressed. |
| City Category (`CITY_TYPE`) | Yes | The city classification category for the report. Auto-populated from the dealer's registered location profile for standard dealer groups; must be entered manually if not auto-filled. | Must not be left blank; validated on tab-out from the field and again when the Generate Report button is pressed. |
| Fuel Type (`FUEL_TYPE`) | Auto-Populated | The fuel type code associated with the selected service variant. Populated automatically when a Service Model is selected; passed as a read-only report parameter. | Read-only; derived from the Service Model selection; not directly editable by the user. |
| Service Variant Code (`SVAR_CD`) | Auto-Populated | The internal service variant code associated with the selected Service Model. Populated automatically when a Service Model is selected; used as a report parameter. | System-set; not directly editable; value comes from the Service Model selection list. |
| Copyright Notice (`COPY_RIGHT`) | Auto-Populated | The standard application copyright declaration displayed at the bottom of the form. Refreshed automatically when the form is reset. | Read-only display field; system-populated only. |

#### Session Context (System - resolved from the active application session)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Principal Code (`PRINCIPAL` global) | Auto-Populated | The OEM/principal code for the current dealer session. Used to filter the Service Model list, City Category list, and dealer location lookup to the correct principal. | Resolved from the active session context; not entered by the user on this form. |
| Parent Group Code (`PARENT_GROUP` global) | Auto-Populated | The dealer group code for the current session. Used to determine whether to apply the automatic city category pre-fill (bypassed for the administrative grouping). | Resolved from session context; not entered by the user on this form. |
| Dealer Code (`DEALER` global) | Auto-Populated | The dealer identifier for the current session. Used in the dealer location lookup to identify the correct city category. | Resolved from session context. |
| Location Code (`LOC_CD` global) | Auto-Populated | The location code for the current dealer outlet. Used in conjunction with the dealer code for the city category lookup. | Resolved from session context. |
| Report Server (`REP_SERVER` global) | Auto-Populated | The name of the Oracle Reports server to which the rate card report request is submitted. | Resolved from session context; not entered by the user. |
| Application Logging Flag (`APP_LOG` global) | Auto-Populated | Indicates whether performance logging is active for this environment. If set to the logging-enabled value, the form starts a performance timer at initialisation. | Resolved from session context; controls whether the timer starts. |
| User ID (`USERID` global) | Auto-Populated | The logged-in user's identifier, used to construct the unique filename for CSV exports. | Resolved from session context. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form through selection lists and lookup queries.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Service Model list (`RG_SRV_MODEL` / `LV_SRV_MODEL`) | Provides the list of available service models for the current principal, including the associated service variant code and fuel type, filtered to models that have a fuel type assigned | When the user opens the Service Model selection list to choose a model for the report |
| City Category list (`RG_CITY_TYPE` / `LV_CITY_TYPE`) | Provides the list of valid city classification codes for the current principal, drawn from the city classification master for the active principal | When the user opens the City Category selection list to choose a city classification |
| Dealer Location master (`AM_DEALER_LOC`) | Provides the registered location details including the city classification category for the current dealer's outlet | When the form is reset, to auto-populate the City Category for standard dealer groups |
| Franchise details (`GM_FOR`) | Provides the city classification type linked to the dealer's franchise, used to resolve the city category from the dealer location record | Joined to the Dealer Location record during the automatic city category lookup on form reset |
| Service Variant master (`VM_SVAR`) | Provides service variant descriptions and codes for the current principal, forming the basis of the Service Model selection list | Queried when the Service Model selection list record group is populated |
| Vehicle Variant master (`GM_VAR`) | Provides the fuel type code for each service variant, joined to the Service Variant master to include fuel type in the Service Model list | Queried as part of the Service Model selection list record group query |
| City Classification master (`VM_MSIL_RPH`) | Provides the distinct set of city classification codes available for the current principal, forming the basis of the City Category selection list | Queried when the City Category selection list record group is populated |

### 6.4 Data Lifecycle

*Describes how data flows through the form's evidenced behaviour. This form does not insert or update any records; all database interaction is read-only for lookup and reporting purposes.*

**Creation**

- No records are created by this form. The form is a reporting criteria entry form only.

**Updates**

- No records are updated by this form. All form fields are either selection criteria (not persisted) or auto-populated display fields.

**Save and Commit**

- The form does not perform any database commit. The `KEY-COMMIT` trigger is present in the form but is inactive (commented out/empty) and does not execute. No save action is available to the user.
- Criteria entered by the user are passed directly to the report server as report parameters and are not stored in any database table.

**Retention and Audit**

- No data is retained by this form after a session ends. Criteria selections are session-only and are discarded when the form is closed or reset.
- The form registers its module name and client session identifier with the database application monitoring service at open time (via `DBMS_APPLICATION_INFO`) and clears these identifiers at exit time; this is session instrumentation only, not a business audit trail.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer-location master table - maps dealer map codes and location codes to city RPH type and other dealer attributes | - | Dealer, LOC_CD, DEALER |
| APP_LOG | Application logging flag global variable - when set to 'Y', activates performance timing at form startup | - | STOP_WATCH, PRE-FORM |
| CB_BLK | Control block - a non-database Oracle Forms block used to collect search or filter criteria without direct DML operations | Control Block | Block, DML |
| CITY_TYPE | City category field on the rate card screen - holds the RPH city type code used to determine applicable service rates | City Category | RPH, VM_MSIL_RPH |
| COPY_RIGHT | Copyright declaration display item - shows the registered copyright text at the bottom of the rate card screen | - | SF_COPYRIGHT_DECLARATION |
| DEALER | Global variable holding the dealer map code for the current session - used to identify the dealer's location profile | Dealer Map Code | AM_DEALER_LOC, LOC_CD |
| DMS | Dealer Management System - integrated software platform for managing dealership operations including service, parts, and reporting | - | Principal, Dealer |
| DPL | DPL program library (DPL.pld) - shared PL/SQL library providing common UI utilities, validation procedures, and message handling routines used across Oracle Forms modules | DPL.pld | PLD, CHECK_NULL, DISP_TEXT |
| FUEL_TYPE | Fuel type display item - auto-populated from the selected service model to show the fuel category (e.g. petrol, diesel, CNG) associated with the variant | - | MODEL_TYPE, SVAR_CD |
| LOC_CD | Location code global variable - identifies the dealer's branch within the principal's network; used with DEALER to look up the city RPH type | Location Code | DEALER, AM_DEALER_LOC |
| LOV | List of Values - a dropdown selection popup in Oracle Forms that allows the user to pick from a predefined or query-driven set of options | Dropdown, Picklist | Record Group, LV_SRV_MODEL, LV_CITY_TYPE |
| MODEL_TYPE | Service Model selection field - the user-facing field where a service variant description is chosen from the LOV | Service Model | SVAR_CD, RG_SRV_MODEL |
| MSIL | Maruti Suzuki India Limited - the principal OEM whose rate-per-hour data is referenced in the VM_MSIL_RPH table | - | Principal, RPH |
| OEM | Original Equipment Manufacturer - the principal vehicle brand (e.g. MSIL) whose service rate cards are managed through the DMS | Principal | MSIL, PRINCIPAL |
| PARENT_GROUP | Parent group global variable - identifies the dealer's parent business group; used to determine whether city type should be auto-populated or left for manual entry | - | DEALER, KEY-CLRFRM |
| PCK | Oracle database package (*.pck) - a named PL/SQL unit containing related procedures and functions stored in the database | Package | PLD, Procedure |
| PDF | Portable Document Format - the output format of the vendor rate card report generated by the Oracle Reports Server and displayed in the browser | - | Reports Server, CALL_REPORT |
| PLD | PL/SQL program library file (*.pld) - a shared library attached to Oracle Forms modules providing reusable procedures and functions at runtime | Program Library | DPL, PCK |
| PRINCIPAL | Principal map code global variable - identifies the OEM or brand principal whose service variants and rate data are used throughout the form | Principal Map Code | OEM, MSIL, PARENT_GROUP |
| REP_SERVER | Reports server global variable - holds the name of the Oracle Reports Server instance to which report jobs are submitted | Reports Server | CALL_REPORT, RUN_REPORT_OBJECT |
| RPH | Rate Per Hour - the service labour rate charged per hour, differentiated by city category; the basis for vendor rate card values | Rate Per Hour | CITY_TYPE, VM_MSIL_RPH |
| RG_CITY_TYPE | Record group for City Category LOV - executes a query against VM_MSIL_RPH to return distinct city RPH type codes for the current principal | - | LV_CITY_TYPE, CB_BLK.CITY_TYPE |
| RG_SRV_MODEL | Record group for Service Model LOV - executes a query against VM_SVAR joined with GM_VAR to return service variant descriptions, codes, and fuel types for the current principal | - | LV_SRV_MODEL, CB_BLK.MODEL_TYPE |
| SEARCH | Generate Report push button - the button that the user presses to validate inputs and submit the rate card report generation request | Generate Report Button | CALL_REPORT, WHEN-BUTTON-PRESSED |
| STOP_WATCH | Oracle database package used for application performance timing - started in PRE-FORM when APP_LOG is active | - | APP_LOG, PRE-FORM |
| SVAR_CD | Service variant code - the internal code for the selected service model, passed as a parameter to the rate card report | Service Variant Code | MODEL_TYPE, VM_SVAR |
| USERID | User ID global variable - holds the logged-in user's identifier; used to construct unique filenames for CSV exports | User Identifier | VIEW_EXCEL_REP |
| VM_MSIL_RPH | MSIL rate-per-hour reference table or view - stores city category type codes for each principal; queried by RG_CITY_TYPE for the city LOV | - | RPH, CITY_TYPE, RG_CITY_TYPE |
| VM_SVAR | Service variant master table or view - stores service model descriptions, variant codes, and associated fuel types per principal; queried by RG_SRV_MODEL | - | SVAR_CD, MODEL_TYPE, RG_SRV_MODEL |
| VR_RATE_CARD_DLR | The Oracle Forms module documented in this BRD - the dealer-facing Vendor Rate Card report generation screen | vr_rate_card_dlr | Vendor Rate Card, DMS |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_rate_card_dlr (VR_RATE_CARD_DLR)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN (inherited from DPL object library; title: MCP Rate Card (Rel:1.0.1))
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_rate_card_dlr_fmb.xml`; OLB `DPL.olb`; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Performance logging flag ('Y'/'N'); when 'Y', starts application timer at form startup |
| DEALER | Char | Trigger | Dealer map code used to filter dealer-location data on form initialisation |
| LOC_CD | Char | Trigger | Location code used with DEALER to identify the dealer's branch location |
| PARENT_GROUP | Char | Trigger | Parent group code; controls whether city type is auto-populated on form clear |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal map code passed to record group queries and report generation |
| REP_SERVER | Char | ProgramUnit | Oracle Reports server name used to submit the rate card report job |
| USERID | Char | ProgramUnit | Logged-in user identifier used to construct a unique CSV export filename |

### 8.1.2 Form Parameters

*No ModuleParameter entries found in vr_rate_card_dlr_fmb.xml.*

**Total Parameters:** 0

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - entry point for rate card search criteria |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_rate_card_dlr_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_rate_card_dlr_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_rate_card_dlr_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 6 | 0 | 6 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| **Total** | **20** | **0** | **20** |

**Item detail (all 20 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | MODEL_TYPE | false | Service model selection field; user selects a service variant from the LOV (mandatory) |
| CB_BLK | CITY_TYPE | false | City category selection field; user selects the RPH city type from the LOV (mandatory) |
| CB_BLK | FUEL_TYPE | false | Auto-populated display field showing fuel type code derived from the selected service model |
| CB_BLK | SVAR_CD | false | Hidden internal field storing the service variant code corresponding to the selected model type |
| CB_BLK | SEARCH | false | Generate Report button; submits the rate card report for the selected criteria |
| CB_BLK | COPY_RIGHT | false | Copyright declaration display field populated automatically on form initialisation |
| CB_ERR | TXT_ERR | false | Inherited error-display text item within the CB_ERR error block; surfaces error message text in the CN_ERR error canvas at runtime |
| PB_BLK | PB_EXIT | false | Inherited toolbar button; exits the current form |
| PB_BLK | PB_LIST | false | Inherited toolbar button; invokes the LOV for the currently focused item |
| PB_BLK | PB_INSERT | false | Inherited toolbar button; initiates a new record insertion; inactive in this report-only form |
| PB_BLK | PM_CONT | false | Inherited toolbar button; continues or confirms the current operation |
| PB_BLK | PB_DEL | false | Inherited toolbar button; deletes the current record; inactive in this report-only form |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button; cancels the current operation or query |
| PB_BLK | PB_SAVE | false | Inherited toolbar button; saves (commits) changes; inactive in this report-only form |
| PB_BLK | PB_PRINT | false | Inherited toolbar button; triggers the DPL print routine for the active report |
| PB_BLK | PB_CUT | false | Inherited toolbar button; cuts selected text to clipboard |
| PB_BLK | PB_COPY | false | Inherited toolbar button; copies selected text to clipboard |
| PB_BLK | PB_PASTE | false | Inherited toolbar button; pastes clipboard content into the focused item |
| PB_BLK | PB_ERR_EXIT | false | Inherited error-canvas button; closes the error dialog without further action |
| PB_BLK | PB_ERR_OK | false | Inherited error-canvas button; acknowledges and dismisses the error dialog |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_SRV_MODEL | - | RG_SRV_MODEL | CB_BLK.MODEL_TYPE |
| LV_CITY_TYPE | - | RG_CITY_TYPE | CB_BLK.CITY_TYPE |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL object library; used by DPL print routines (ASK_PRINT / PROC_TIMER_EXPIRED) to present print-destination options to the user |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL object library; used by DISP_TEXT / RAISE_ERROR to display error-level messages at runtime |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL object library; used by DISP_TEXT to display informational messages at runtime |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL object library; used by GENERAL.ASK_CONFIRM to present yes/no confirmation prompts at runtime |
| ALT_RATE | Caution | Do you want to enter Fixed Amount 'OR' FRT? | Defined in the form (subclassed from DPL object library); SHOW_ALERT is not invoked in the current form - alert is present but inactive |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **2 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | Create_Group_From_Query, Populate_Group, Find_Column, Get_Group_Char_Cell, TEXT_IO, WEB.SHOW_DOCUMENT | Exports a query result to a CSV file on the server and opens it in the browser; builds a unique filename from the current user ID and date; not called from any trigger in the current form |
| CALL_REPORT | Procedure | Find_Report_Object, RUN_REPORT_OBJECT, WEB.SHOW_DOCUMENT, :global.rep_server | Submits the vr_rate_card Oracle Report in PDF format to the Reports Server using the selected principal, city type, service variant, and fuel type; opens the generated PDF in a new browser tab; called from WHEN-BUTTON-PRESSED on CB_BLK.SEARCH |

**Total Program Units:** 2

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Displays a confirmation alert and returns the user's yes/no selection; used to guard destructive or significant operations before proceeding |
| GENERAL.CHECK_NULL | Library routine | CB_BLK.CITY_TYPE, CB_BLK.MODEL_TYPE | Validates that a mandatory field is not null; displays the field label in an error message and raises form trigger failure if the field is empty |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.SEARCH | Displays a message dialog using the AL_ERRINFO or AL_NOTE alert, setting title and message text dynamically |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| INACTIVE - empty body; does not execute | Form | - | KEY-COMMIT | No commit behaviour implemented; DML is suppressed as this is a report-only form | Empty body - no commit is performed by this form |
| INACTIVE - empty body; does not execute | Form | - | KEY-LISTVAL | No custom LOV invocation behaviour; standard Oracle Forms LOV key behaviour applies by default | Empty body |
| INACTIVE - empty body; does not execute | Form | - | ON-MESSAGE | No custom message routing; Oracle Forms default message display applies | Empty body |
| INACTIVE - empty body; does not execute | Form | - | ON-ERROR | No custom error handling; Oracle Forms default error handling applies | Empty body |
| **Inactive stub** | Form | - | FT_SAVE | Inherited save/commit trigger from DPL object group; no active save behaviour is required in this report-only form | Stub body only; DML is suppressed throughout the form |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (35 business triggers):**
*vr_rate_card_dlr_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | INACTIVE - empty body; does not execute under any user action; Oracle Forms default error handling applies |
| ON-MESSAGE | Form | - | Form level | INACTIVE - empty body; does not execute under any user action; Oracle Forms default message display applies |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info then exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | INACTIVE - empty body; does not execute under any user action; standard Oracle Forms LOV key behaviour applies by default |
| KEY-COMMIT | Form | - | Form level | INACTIVE - empty body; does not execute under any user action; no database commit is performed by this form |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation; auto-populates city type from dealer-location data when parent group is not '99999'; populates copyright display field |
| KEY-OTHERS | Form | - | Form level (inherited) | Inherited from DPL object group; suppresses unhandled key actions to prevent default Oracle Forms key processing |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard next-item navigation behaviour across the form |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard previous-item navigation behaviour across the form |
| KEY-NXTBLK | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard next-block navigation behaviour across the form |
| KEY-PRVBLK | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard previous-block navigation behaviour across the form |
| KEY-DOWN | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard downward record navigation across the form |
| KEY-UP | Form | - | Form level (inherited) | Inherited from DPL object group; provides standard upward record navigation across the form |
| FT_SAVE | Form | - | Form level (inherited) | Inherited from DPL object group; stub only - no active save behaviour; DML is suppressed in this report-only form |
| FT_CANCEL | Form | - | Form level (inherited) | Inherited from DPL object group; cancels the current pending operation or query |
| FT_INSERT | Form | - | Form level (inherited) | Inherited from DPL object group; initiates a new record insertion; inactive in this report-only form |
| FT_DEL | Form | - | Form level (inherited) | Inherited from DPL object group; deletes the current record; inactive in this report-only form |
| FT_LIST | Form | - | Form level (inherited) | Inherited from DPL object group; invokes the LOV for the currently focused item |
| FT_PRINT | Form | - | Form level (inherited) | Inherited from DPL object group; triggers the DPL print routine for the active report |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Inherited from DPL object group; initialises the form session - sets DBMS application context, populates copyright field, and seeds global variables from the calling environment |
| PRE-FORM | Form | - | Form level | Sets DBMS application info for session tracking; starts application performance timer when APP_LOG flag is active |
| KEY-NEXT-ITEM | CB_BLK | MODEL_TYPE | CB_BLK.MODEL_TYPE | Validates that the Service Model field is not null and navigates to the Generate Report button |
| KEY-NEXT-ITEM | CB_BLK | CITY_TYPE | CB_BLK.CITY_TYPE | Validates that the City Category field is not null and navigates back to the Service Model field |
| WHEN-BUTTON-PRESSED | CB_BLK | SEARCH | CB_BLK.SEARCH | Validates that both city type and service model are entered, then generates the rate card PDF report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button trigger; exits the current form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button trigger; invokes the LOV for the currently focused item |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button trigger; initiates a new record insertion; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button trigger; continues or confirms the current operation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button trigger; deletes the current record; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button trigger; cancels the current operation or query |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button trigger; saves (commits) changes; inactive in this report-only form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button trigger; triggers the DPL print routine for the active report |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button trigger; cuts selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button trigger; copies selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button trigger; pastes clipboard content into the focused item |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | MCP Rate Card (Rel:1.0.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |
| CN_ERR | Content | WIN_ERR |

---

### 8.9 Editors

*No editors found in vr_rate_card_dlr_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_rate_card_dlr_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_rate_card_dlr_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |
| CB_BLK | Inherited block |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_rate_card_dlr_fmb.xml.*

## 9. Object Library

*The form references the DPL Object Library (`DPL_olb.xml`), which provides the shared Visual Attributes and Property Classes used across forms in this application suite. The form includes the object group `OG_GROUP`, which subclasses a set of Visual Attributes, canvases, windows, blocks, alerts, and triggers from this library.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_RB | VisualAttribute | Radio button visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_ICONIC_BUTN | VisualAttribute | Iconic push button visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_DESC | VisualAttribute | Description / label text visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_NUM | VisualAttribute | Numeric field visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_MAND | VisualAttribute | Mandatory field visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_OPROMPT | VisualAttribute | Optional-field prompt visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_MPROMPT | VisualAttribute | Mandatory-field prompt visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_TEXT | VisualAttribute | Standard text item visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_BUTN | VisualAttribute | Push button visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_ALERT | VisualAttribute | Alert dialog visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_TITLE | VisualAttribute | Title / header label visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_LOV | VisualAttribute | List of values (LOV) field visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| VA_DISP | VisualAttribute | Display (read-only) item visual attribute | Referenced via OG_GROUP | OG_GROUP object group child |
| PC_DESC | PropertyClass | Base descriptor property class | Not referenced in this form's items | N/A |
| PC_SC_DATE | PropertyClass | Property class for date fields | Not referenced in this form's items | N/A |
| PC_TITLE | PropertyClass | Property class for text items (title usage) | Not referenced in this form's items | N/A |
| PC_FORMAT | PropertyClass | Property class for text items (format usage) | Not referenced in this form's items | N/A |
| PC_MR_BLK | PropertyClass | Master-detail block property class | Not referenced in this form's items | N/A |
| PC_DISP | PropertyClass | Property class for display (read-only) text items | Not referenced in this form's items | N/A |
| PC_LOV | PropertyClass | Property class for list of values items | Not referenced in this form's items | N/A |
| PC_FORM | PropertyClass | Form-level property class | Not referenced in this form's items | N/A |
| PC_DISP_DATE | PropertyClass | Property class for display date text items | Not referenced in this form's items | N/A |
| PC_DISP_NUM | PropertyClass | Property class for display numeric text items | Not referenced in this form's items | N/A |
| PC_DATE | PropertyClass | Property class for date input fields | Not referenced in this form's items | N/A |
| PC_DTTIME | PropertyClass | Property class for date and time fields | Not referenced in this form's items | N/A |
| PC_CB | PropertyClass | Check box property class | Not referenced in this form's items | N/A |
| PC_ALERT | PropertyClass | Alert dialog property class | Not referenced in this form's items | N/A |
| PC_MDATE | PropertyClass | Property class for mandatory date fields | Not referenced in this form's items | N/A |
| PC_RB | PropertyClass | Radio button property class | Not referenced in this form's items | N/A |
| PC_WIND | PropertyClass | Property class for windows | Not referenced in this form's items | N/A |
| PC_CANV | PropertyClass | Canvas property class | Not referenced in this form's items | N/A |
| PC_BUTN | PropertyClass | Property class for push buttons | Not referenced in this form's items | N/A |
| PC_TEXT | PropertyClass | Property class for standard text items | Not referenced in this form's items | N/A |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | Not referenced in this form's items | N/A |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | Not referenced in this form's items | N/A |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | Not referenced in this form's items | N/A |
| PC_NUM | PropertyClass | Property class for numeric items | Not referenced in this form's items | N/A |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | Not referenced in this form's items | N/A |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons | Not referenced in this form's items | N/A |
| PC_SCROLL | PropertyClass | Scroll bar property class | Not referenced in this form's items | N/A |
| OG_GROUP | ObjectGroup | Shared standard UI object group - provides common canvases, windows, Visual Attributes, alerts, blocks, and triggers subclassed across forms in this suite | 1 (form level - the form's OG_GROUP references this) | CN_ERR, WN_MAIN, POP_MAIN, CN_MAIN, CN_TOOL, PB_BLK, AL_ERRINFO, AL_NOTE, AL_CONFIRM, WIN_ERR, AL_PRINT, and shared VA_* set |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_SRV_MODEL | Query | LV_SRV_MODEL | SVAR_DESC | SVAR_CD | No | Lists available service model variants for the current principal so the user can select a service model | LV_SRV_MODEL -> CB_BLK.MODEL_TYPE |
| RG_CITY_TYPE | Query | LV_CITY_TYPE | CITY_RPH_TYPE | - | No | Lists distinct city RPH category types for the current principal so the user can select a city category | LV_CITY_TYPE -> CB_BLK.CITY_TYPE |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger KEY-CLRFRM, Trigger WHEN-NEW-FORM-INSTANCE | Dealer-location master - maps dealer and location codes to city RPH type for auto-population |
| `VM_MSIL_RPH` | - | RG_CITY_TYPE | MSIL rate-per-hour reference - provides distinct city category codes for the LOV |
| `VM_SVAR` | - | RG_SRV_MODEL | Service variant master - stores service model descriptions and codes for the LOV |

**Total Referenced Objects:** 3

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name as the session's client identifier for database session monitoring at form open |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name and action in the database session module tracking at form open |
| BR-001 | STOP_WATCH.START_TIMER | Starts the performance timing measurement at form initialisation when application logging is enabled |
| BR-002 | SF_COPYRIGHT_DECLARATION | Retrieves the standard copyright declaration text to be displayed on the form after a reset |
| BR-003 | GENERAL.CHECK_NULL | Validates that the City Type and Model Type fields are not empty when the user tabs out of those fields |
| BR-003 | GENERAL.DISP_TEXT | Displays the mandatory fields error message when one or both required criteria are missing at report submission time; also surfaces system-generated errors and informational messages via ON-ERROR and ON-MESSAGE triggers |
| BR-003 | GENERAL.RAISE_ERROR | Translates Oracle or Forms runtime error codes into user-readable messages within the ON-ERROR trigger before delegating display to GENERAL.DISP_TEXT |
| BR-003 | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before destructive or navigational actions (cancel, delete, cut, copy, paste, insert, save, print, list, or exit) and returns the user's choice to the calling trigger |
| BR-003 | GENERAL.CHECK_FORM_FAILURE | Inspects form status after a commit attempt and raises form_trigger_failure if the commit did not succeed, centralising post-commit error handling |
| BR-003 | CALL_REPORT | Configures and submits the rate card report to the Oracle Reports server and opens the result in the browser |
| BR-003 | WEB.SHOW_DOCUMENT | Opens the generated PDF report URL in a new browser window after the report job has been submitted |
| BR-004 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the session's client identifier (sets to null) when the form is exited |
| BR-004 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the session module and action tracking identifiers (sets to blank) when the form is exited |
| BR-005 | WEB.SHOW_DOCUMENT | Opens the generated CSV export file URL in a new browser window after the file has been written to the server |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose | Classification |
| ----------------- | ---- | ----------- | ------- | -------------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package routine | PRE-FORM trigger (form open), KEY-EXIT trigger (form close) | Sets and clears the client identifier for the current database session, enabling support and monitoring tools to identify which form is active for each session | Oracle Built-in Package |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package routine | PRE-FORM trigger (form open), KEY-EXIT trigger (form close) | Sets and clears the module name and action tracking fields for the current database session, used by Oracle performance monitoring tools to track session activity by form | Oracle Built-in Package |
| STOP_WATCH.START_TIMER | Application package routine | PRE-FORM trigger (conditionally, when app_log global = 'Y') | Starts an elapsed-time timer at form initialisation to measure and record form response time when application performance logging is enabled for the environment | Application Package (external - not in bundle; behaviour unverifiable) |
| SF_COPYRIGHT_DECLARATION | Standalone database function | KEY-CLRFRM trigger (form reset), WHEN-NEW-FORM-INSTANCE trigger (form open) | Returns the standard application copyright declaration text for display on the form; called after every form reset and at initial form load to populate the copyright display area | Standalone Database Function |
| CALL_REPORT | Form-level program unit | WHEN-BUTTON-PRESSED trigger on Generate Report button (CB_BLK.SEARCH) | Configures the rate card report object with the user's selected criteria (city type, service model/variant, fuel type), sets the output format to PDF, submits the report job to the Oracle Reports server, and opens the resulting report in a new browser window | Form Program Unit |
| WEB.SHOW_DOCUMENT | Oracle Forms Web package routine | CALL_REPORT program unit (report display); VIEW_EXCEL_REP program unit (CSV display) | Opens a specified URL in a new browser window; used to display the generated PDF report and, in the CSV export utility, to show the downloaded CSV file to the user | Oracle Forms Web Package |
| GENERAL.CHECK_NULL | Application library package routine (DPL) | KEY-NEXT-ITEM trigger on CB_BLK.CITY_TYPE field; KEY-NEXT-ITEM trigger on CB_BLK.MODEL_TYPE field | Validates that the supplied field value is not null; if null, displays an error message containing the field's column title label and raises form_trigger_failure to prevent navigation away from the mandatory field, enforcing mandatory field entry at tab-out time | DPL Library Routine |
| GENERAL.DISP_TEXT | Application library package routine (DPL) | ON-ERROR trigger (form level); ON-MESSAGE trigger (form level); WHEN-BUTTON-PRESSED trigger on CB_BLK.SEARCH (Search/Generate Report button) | Displays a message dialog using the AL_ERRINFO or AL_NOTE alert object; sets the alert title to the supplied title string and the message body to the supplied text string before showing the alert to the user; used to surface both system-generated errors and application informational messages through a consistent alert mechanism | DPL Library Routine |
| GENERAL.RAISE_ERROR | Application library package routine (DPL) | ON-ERROR trigger (form level) | Looks up the error message text associated with a supplied message code and re-raises it as a formatted application error; used within the ON-ERROR trigger to translate Oracle or Forms runtime error codes into user-readable messages before delegating final display to GENERAL.DISP_TEXT | DPL Library Routine |
| GENERAL.ASK_CONFIRM | Application library package routine (DPL) | Trigger FT_CANCEL (form level); Trigger FT_DEL (form level); WHEN-BUTTON-PRESSED on PB_BLK.PB_CANCEL; WHEN-BUTTON-PRESSED on PB_BLK.PB_COPY; WHEN-BUTTON-PRESSED on PB_BLK.PB_CUT; WHEN-BUTTON-PRESSED on PB_BLK.PB_DEL; WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT; WHEN-BUTTON-PRESSED on PB_BLK.PB_INSERT; WHEN-BUTTON-PRESSED on PB_BLK.PB_LIST; WHEN-BUTTON-PRESSED on PB_BLK.PB_PASTE; WHEN-BUTTON-PRESSED on PB_BLK.PB_PRINT; WHEN-BUTTON-PRESSED on PB_BLK.PB_SAVE | Presents a confirmation dialog containing the supplied confirmation message text and returns a numeric result indicating the user's choice; callers compare the return value against alert button constants to determine whether to proceed with or abort the pending destructive or navigational action | DPL Library Routine |
| GENERAL.CHECK_FORM_FAILURE | Application library package routine (DPL) | KEY-COMMIT trigger (form level) | Inspects the current form status after a commit attempt and raises form_trigger_failure if the commit did not succeed; centralises post-commit error handling so that individual triggers do not need to duplicate failure-detection logic | DPL Library Routine |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in the input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CANCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE | Presents a confirmation dialog containing the supplied confirm_msg text and returns a numeric result indicating the user's choice; callers compare the return value against the alert button constants to determine whether to proceed with or abort the pending destructive or navigational action (cancel, delete, cut, copy, paste, insert, save, print, list, or exit). |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Inspects the current form status after a commit attempt and raises form_trigger_failure if the commit did not succeed; centralises post-commit error handling so that individual triggers do not need to duplicate failure-detection logic. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: KEY-NEXT-ITEM in CB_BLK.CITY_TYPE, Trigger: KEY-NEXT-ITEM in CB_BLK.MODEL_TYPE | Validates that the supplied field value is not null; if null, displays an error message containing the column_title label and raises form_trigger_failure to prevent navigation away from the mandatory field. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SEARCH | Displays a message dialog using the AL_ERRINFO or AL_NOTE alert object; sets the alert title to title_string and the message body to text_string before showing the alert to the user. Called from ON-ERROR and ON-MESSAGE form-level triggers in addition to the Search button, allowing both system-generated errors and informational messages to be surfaced through the same consistent alert mechanism. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up the error message text associated with mesg_code and re-raises it as a formatted application error; used within the ON-ERROR trigger to translate Oracle or Forms runtime error codes into user-readable messages before delegating final display to DISP_TEXT. |

**Total Active Routines:** 5 of 24 in DPL.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Rate Card Report Service | CALL_REPORT (form program unit) / `vr_rate_card` report (Oracle Reports) | Principal code, City Category code, Service Variant code, Fuel Type code | PDF report document (via Oracle Reports server job URL) | Generates and delivers the Dealer Rate Card PDF report filtered to the specified principal, city category, service variant, and fuel type | `POST /api/v1/reports/rate-card` |
| MS-002 | Service Model Lookup Service | VM_SVAR, GM_VAR (via RG_SRV_MODEL query) | Principal code | List of service models with service variant code, description, and fuel type (filtered to models with a fuel type) | Provides the list of available service models for a given principal, used to populate the Service Model selection field | `GET /api/v1/service-models?principal={principal}` |
| MS-003 | City Category Lookup Service | VM_MSIL_RPH (via RG_CITY_TYPE query) | Principal code | List of distinct city classification codes for the principal | Provides the list of valid city categories for a given principal, used to populate the City Category selection field | `GET /api/v1/city-categories?principal={principal}` |
| MS-004 | Dealer City Category Service | AM_DEALER_LOC, GM_FOR | Principal code, Parent Group code, Dealer code, Location code | City classification type for the dealer's registered location | Retrieves the pre-assigned city category for a specific dealer outlet, used to auto-fill the City Category field for standard dealer sessions | `GET /api/v1/dealers/{dealerCode}/city-category?principal={principal}&parentGroup={parentGroup}&locationCode={locationCode}` |
| MS-005 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION (standalone database function) | None | Copyright declaration text string | Retrieves the standard application copyright declaration for display on form screens | `GET /api/v1/system/copyright` |
| MS-006 | Rate Card Data Export Service | VIEW_EXCEL_REP (form program unit) / report server file system | Data query, column mapping | CSV file (written to server, returned as download URL) | Generates a CSV export of rate card data from a provided query, capped at 65,535 rows, and delivers the file for browser download | `POST /api/v1/exports/rate-card-csv` |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Session Initialisation | User opens the Rate Card Dealer form (PRE-FORM trigger fires) | 1. Register form module name as session client identifier; 2. Register form module name in session module tracking; 3. Check whether application logging is enabled; 4. If logging is enabled, start the performance timer | Whether application logging (`APP_LOG` global) is set to the logging-enabled value: if yes, start timer; if no, skip timer | Form is open, session context registered, performance timer running (if logging enabled) |
| WF-002 | Form Reset and City Category Pre-fill | User triggers a form clear/reset (KEY-CLRFRM trigger fires) | 1. Clear all form contents without saving; 2. Check whether the dealer belongs to a standard group; 3. If standard group, query the dealer's location for the city category and pre-fill the City Category field; 4. Retrieve and display the copyright declaration | Whether the dealer's parent group code is the administrative grouping: if standard group, run dealer city category lookup; if administrative group, skip lookup and leave City Category blank; if lookup fails, leave blank silently | Form is reset, City Category pre-filled (for standard dealers), copyright notice refreshed |
| WF-003 | Rate Card Report Generation | User presses the Generate Report button (WHEN-BUTTON-PRESSED trigger fires on the Generate Report button) | 1. Check that both Service Model and City Category are populated; 2. If either is blank, display error and cancel; 3. If both are present, call the report generation procedure; 4. Configure report object with PDF format, principal, city category, service variant, and fuel type parameters; 5. Submit report job to Oracle Reports server; 6. Open resulting PDF in a new browser window | Whether both mandatory criteria are present: if either is blank, show error and stop; if both present, proceed to report submission. Whether the report submission succeeds: if an unexpected error occurs, display Oracle error message and stop | Rate Card PDF report displayed in a new browser window (success path); or error message shown and report not generated (failure path) |
| WF-004 | Form Exit and Session Cleanup | User triggers form exit (KEY-EXIT trigger fires) | 1. Clear session client identifier (set to null); 2. Clear session module and action tracking (set to blank); 3. Exit the form without saving (EXIT_FORM NO_VALIDATE) | None - exit is unconditional | Form closed, session monitoring context cleared |
| WF-005 | Rate Card Data CSV Export | External caller invokes the VIEW_EXCEL_REP program unit (no internal trigger currently calls this procedure - INACTIVE CALL PATH within this form) | 1. Build output filename from user identifier and current date-time; 2. Validate file path - space characters in folder names are not permitted; 3. If space characters detected in a folder name, redirect to C drive root and notify user; 4. Execute the provided query and load results; 5. Check row count against 65,535-row limit; 6. If row count exceeded, truncate and notify user; 7. Read server output path from configuration file; 8. Write CSV rows to the server file; 9. Open the CSV file URL in a new browser window | Whether the file path contains space characters in a folder name: if yes, redirect path; whether the row count exceeds 65,535: if yes, truncate and notify | CSV file written to the report server and opened in the browser for download |

**Total Workflows Identified: 5**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | Trigger: KEY-NEXT-ITEM in CB_BLK.CITY_TYPE, Trigger: KEY-NEXT-ITEM in CB_BLK.MODEL_TYPE | /api/v1/pld/check_null | When a mandatory selection field is empty, then navigation is blocked and an error message naming the field is shown |
| PLD-002 | DISP_TEXT | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SEARCH | /api/v1/pld/disp_text | When a message must be shown to the user, then an alert dialog is displayed with a dynamic title and body text |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_rate_card_dlr_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_rate_card_dlr_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Dealer Location lookup (AM_DEALER_LOC) | Table - SELECT | Retrieves the city classification category assigned to the current dealer's location, filtered by principal, parent group, dealer code, and location code | Form -> AM_DEALER_LOC (SELECT city_rph_type, joined with GM_FOR) | WHEN OTHERS exception is caught silently; City Category field is left blank if the query fails; no error is shown to the user |
| Franchise details lookup (GM_FOR) | Table - SELECT | Provides the franchise-level city classification type, joined to the Dealer Location record to resolve the city category for the current dealer | Form -> GM_FOR (SELECT, joined with AM_DEALER_LOC on FOR_CD + PRINCIPAL_MAP_CD) | Same WHEN OTHERS handler as AM_DEALER_LOC - silent failure, City Category left blank |
| Service Model list query (VM_SVAR) | Table - SELECT | Provides service variant descriptions and codes for the current principal, used to populate the Service Model selection list | Form -> VM_SVAR (SELECT via RG_SRV_MODEL record group query, joined with GM_VAR) | Standard Forms record group error handling |
| Vehicle Variant / Fuel Type lookup (GM_VAR) | Table - SELECT | Provides fuel type codes for each service variant, joined to the service variant list to include fuel type in the Service Model selection | Form -> GM_VAR (SELECT via RG_SRV_MODEL record group query, joined with VM_SVAR) | Standard Forms record group error handling |
| City Category list query (VM_MSIL_RPH) | Table - SELECT | Provides the distinct set of city classification codes for the current principal, used to populate the City Category selection list | Form -> VM_MSIL_RPH (SELECT via RG_CITY_TYPE record group query) | Standard Forms record group error handling |
| Copyright Declaration function (SF_COPYRIGHT_DECLARATION) | Standalone database function - CALL | Returns the standard application copyright declaration text for display on the form after a reset | Form -> SF_COPYRIGHT_DECLARATION (function call, return value assigned to display field) | No explicit exception handling for this call; Forms default error handling applies |
| Null check validation (GENERAL.CHECK_NULL) | Application library package routine - CALL | Validates that a specified field value is not empty; used for mandatory field enforcement on tab-out from Service Model and City Category fields | Form -> DPL library -> GENERAL.CHECK_NULL (raises error if field is blank) | GENERAL.CHECK_NULL raises a trigger failure that stops field navigation if the value is null |
| Message display (GENERAL.DISP_TEXT) | Application library package routine - CALL | Displays a message to the user with specified text and severity; used to show the mandatory fields error at report submission time | Form -> DPL library -> GENERAL.DISP_TEXT | GENERAL.DISP_TEXT raises a trigger failure after displaying the message to cancel the current operation |
| Performance timer (STOP_WATCH.START_TIMER) | Application package routine - CALL | Starts the elapsed-time performance timer at form initialisation when application logging is enabled | Form -> STOP_WATCH package -> START_TIMER | Conditional call; no explicit exception handler for this invocation |
| Application session monitoring (DBMS_APPLICATION_INFO) | Oracle built-in package - CALL | Sets and clears the session client identifier and module tracking fields at form open and close for database session monitoring tools | Form -> DBMS_APPLICATION_INFO.SET_CLIENT_INFO / SET_MODULE | No exception handler; Oracle built-in; failures are treated as non-blocking |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Oracle Reports - RUN_REPORT_OBJECT | Receives the rate card report request, generates the PDF rate card report, and returns a job identifier for the output document | Oracle Reports internal (RUN_REPORT_OBJECT / rwservlet) | `/reports/rwservlet/getjobid{jobId}?server={reportServer}` | Outbound: principal code, city category, service variant, fuel type, output format (PDF), report filename (vr_rate_card); Inbound: job identifier for the generated report | Success: report job ID returned, PDF URL opened in browser; Failure: WHEN OTHERS handler shows Oracle error message (SQLERRM) and blank spacer message |
| Report Server File System (excelpath.txt config) | File I/O - TEXT_IO.FOPEN (read) | Provides the server-side base path where CSV export files are written; path is read from a configuration text file on the report server | File system read via Oracle Forms TEXT_IO | `/reports/DMS/excelpath.txt` | Inbound: base directory path string for the CSV output location | No explicit error handling for this file read in VIEW_EXCEL_REP |
| Report Server File System (CSV output) | File I/O - TEXT_IO.FOPEN (write) | Receives the generated CSV export data written row by row and stores it as a file accessible via the web server for browser download | File system write via Oracle Forms TEXT_IO | `/iashome/ias/reports/printer/{filename}.csv` | Outbound: CSV rows generated from the data query (up to 65,535 rows) | No explicit error handling for the write operation in VIEW_EXCEL_REP (exception handler is commented out / INACTIVE) |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| vr_rate_card | Oracle Reports server (value read from `REP_SERVER` session global at runtime - INFERRED) | P_PRINCIPAL (dealer principal code), P_CITY_TYPE (city category), P_MODEL_TYPE (service variant code), P_FUEL_TYPE (fuel type code); REPORT_DESTYPE=FILE, MODE=BITMAP, BLANKPAGES=NO | PDF | WHEN-BUTTON-PRESSED on Generate Report button - via CALL_REPORT form program unit; report submitted using RUN_REPORT_OBJECT; result opened with WEB.SHOW_DOCUMENT |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_RATE_CARD_DLR form.

### 21.1 Catalogue Index

7 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT) | CALL_REPORT |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-004](#SP-004--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-005](#SP-005--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-006](#SP-006--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-007](#SP-007--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SEARCH PARAMETER (N/A / CN_MAIN)

---

**Purpose**

Configures the rate card report object with the dealer's selected criteria and submits the request to the Oracle Reports server. The procedure sets the output format to PDF, passes the principal code, city category, service variant, and fuel type as report parameters, targets the appropriate report server from the session configuration, and then opens the generated PDF report in a new browser window for the dealer to view.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | varchar2 | IN |
| p_city_type | varchar2 | IN |
| p_model_type | varchar2 | IN |
| p_fuel_type | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Locate the rate card report definition: the system finds the registered report object in the form using the handle `REPORT_CALL` and sets the target report filename to `vr_rate_card`.
- Step 2 - Configure the output format: the report output format is set to PDF so the dealer receives a printable document.
- Step 3 - Set report parameters: the system assembles the four reporting criteria - principal code, city category, service variant code, and fuel type - together with the destination type, rendering mode, and blank-page suppression setting, and applies them to the report object. The report server name is read from the session configuration.
- Step 4 - Submit the report request: the system submits the configured report job to the Oracle Reports server and receives a unique job identifier for the generated report.
- Step 5 - Display the report: the system constructs the report retrieval URL using the job identifier and the report server name, then opens the PDF in a new browser window for the dealer user to view or download.

---
**Decision Points**

No conditional branches in CALL_REPORT - the procedure executes linearly from locate report object to display result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- The report filename is always `vr_rate_card` (set as a literal in the procedure body).
- The output format is always PDF.
- Report parameters passed are: P_PRINCIPAL (dealer principal code), P_CITY_TYPE (city category), P_MODEL_TYPE (service variant code), P_FUEL_TYPE (fuel type code); plus REPORT_DESTYPE=FILE, MODE=BITMAP, BLANKPAGES=NO.
- The report server name is read from the session global rather than hard-coded, allowing different environments to use different server configurations.

---
**Implementation Logic**

```plsql
PROCEDURE Call_Report(p_principal varchar2,p_city_type varchar2,p_model_type varchar2,p_fuel_type varchar2) IS
                                  
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);

Begin 
	
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'vr_rate_card';
--	l_AlertId := Find_Alert('AL_REPORT');
--	lv_alert := Show_Alert(l_AlertId);

		Set_Report_Object_Property(repid,Report_Desformat,'PDF');
	  
	  Set_Report_Object_Property(repid,Report_Other,' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_CITY_TYPE='||p_city_type||
                                                  ' P_MODEL_TYPE='||p_model_type||
                                                  ' P_FUEL_TYPE='||p_fuel_type||
                                                  ' REPORT_DESTYPE =FILE'||
                                                  ' MODE=BITMAP BLANKPAGES=NO');

		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
END;
```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: FT_CANCEL]
- vr_rate_card_dlr_fmb.xml [Trigger: FT_DEL]
- vr_rate_card_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric flag indicating which button was pressed. Callers use the return value to determine whether the user confirmed or cancelled a pending action such as deleting or cancelling a rate-card record.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user via show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (confirmation), or 0 for any other button press (non-confirmation).

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert)

TRUE:
The function returns 1, signalling to the caller that the user confirmed the action.

FALSE:
The function returns 0, signalling to the caller that the user did not confirm the action (e.g., pressed Cancel or a secondary button).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined Oracle Forms alert named AL_CONFIRM; no other alert object is permitted.
- BR-002 - The alert message text must be dynamically set to the value supplied by the caller in confirm_msg before the alert is shown, allowing a single reusable function to serve multiple confirmation scenarios.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1); any other button response must return 0, ensuring callers receive an unambiguous binary result.
- BR-004 - The function must always return a numeric value (1 or 0); the trailing RETURN NULL is unreachable and must never be relied upon by calling code.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Checks whether the most recent Oracle Forms operation completed successfully and, if not, surfaces the appropriate error message to the user before halting further processing. It distinguishes between Oracle database errors (ORA) and Oracle Forms runtime errors (FRM), delegates message display to GENERAL.DISP_TEXT, and raises FORM_TRIGGER_FAILURE to abort the calling trigger.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in FORM_SUCCESS function to determine whether the preceding Forms operation succeeded.
- Step 2 - If the operation did not succeed, inspect the ERROR_TYPE built-in to classify the failure.
- Step 3 - If ERROR_TYPE is 'ORA' (Oracle database error), invoke GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (Oracle Forms runtime error), invoke GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to halt execution of the calling trigger (KEY-COMMIT).
- Step 6 - If FORM_SUCCESS is TRUE, no action is taken and processing continues normally.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (i.e., the preceding Forms operation failed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No action is taken; the procedure exits silently and the calling trigger continues.

---

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated from an Oracle database error).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity 'Error'.

FALSE: Evaluate whether ERROR_TYPE = 'FRM'.

---

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated from an Oracle Forms runtime error).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms runtime error message) and severity 'Error'.

FALSE: No error message is displayed; processing still raises FORM_TRIGGER_FAILURE because FORM_SUCCESS was already determined to be FALSE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A failed Forms operation must never be silently ignored; any condition where FORM_SUCCESS is FALSE must result in user notification and trigger abortion.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported using the Oracle-supplied error message obtained from SQLERRM.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be reported using the Forms-supplied error message obtained from ERROR_TEXT.
- BR-004 - All error messages must be presented to the user at severity level 'Error' via GENERAL.DISP_TEXT.
- BR-005 - Upon detection of any form failure, FORM_TRIGGER_FAILURE must be raised to prevent the KEY-COMMIT trigger from completing its commit cycle.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-004 - GENERAL.CHECK_NULL

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: KEY-NEXT-ITEM]

---

**Screen:**

SEARCH PARAMETER (N/A / CN_MAIN)

---

**Purpose**

Validates that a mandatory form field has been filled before the user can navigate away from it. If the field is empty, the procedure displays an error message naming the specific field that must be completed and stops the navigation, keeping the user on the current field until a value is entered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value and the field label: the procedure is called with the current value of the mandatory field and the human-readable name of that field.
- Step 2 - Check whether the field is empty: the system evaluates whether the supplied value is null.
- Step 3 - If the field is blank, display an error and stop navigation: the error message "Enter a valid [field label]" is shown to the user and the navigation is cancelled, keeping focus on the current field until the user provides a value.

---
**Decision Points**

DP-001

Condition: The supplied field value is null (nothing has been entered in the mandatory field).

TRUE: Display the error message "Enter a valid [field label]" and raise a trigger failure to prevent navigation away from the field.

FALSE: The field has a value; the procedure returns normally and navigation proceeds.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- If a mandatory field is empty when the user attempts to tab away, navigation is blocked and the user must enter a value before proceeding.
- The error message dynamically includes the field label supplied by the caller, so the user always knows which specific field needs to be completed.
- The error is displayed at "Error" severity using the GENERAL.DISP_TEXT routine.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-005 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_rate_card_dlr_fmb.xml [Trigger: ON-ERROR]
- vr_rate_card_dlr_fmb.xml [Trigger: ON-MESSAGE]
- vr_rate_card_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SEARCH PARAMETER (N/A / CN_MAIN)

---

**Purpose**

Displays a user-facing message alert with a configurable title and body text. The procedure selects the appropriate alert style based on the severity indicator supplied by the caller - using an error-style alert for error conditions and a note-style alert for all other notifications - then shows the alert to the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the alert style based on the severity: if the title supplied by the caller is "ERROR" (case-insensitive), the error-style alert object is selected; for any other title value, the note-style alert object is selected.
- Step 2 - Set the alert title and message: the selected alert object's title and message body are updated with the values supplied by the caller.
- Step 3 - Display the alert to the user: the alert is shown on screen; the procedure waits for the user to acknowledge it before returning control to the caller.

---
**Decision Points**

DP-001

Condition: The title_string supplied by the caller is "ERROR" (compared in uppercase).

TRUE: Use the error-style alert object (AL_ERRINFO) to display the message with error formatting.

FALSE: Use the note-style alert object (AL_NOTE) to display the message with note/informational formatting.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- Error-severity messages are displayed using the error alert style; all other messages use the note alert style.
- The alert title and message text are set dynamically from the caller's parameters, making this a general-purpose message display routine usable for any notification type.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-006 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

GENERAL.RAISE_ERROR is a centralised error-handling procedure invoked from the ON-ERROR trigger of vr_rate_card_dlr_fmb. It receives a message code, constructs a formatted message string, classifies the message by type (Error, Note, or Caution), displays the appropriate dialog to the user via GENERAL.DISP_TEXT, and-where the message type is Error-halts further form processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-005](#SP-005--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming message code (mesg_code) as the sole input parameter.
- Step 2 - Construct the display message by concatenating mesg_code, a colon separator, and mesg_text (mesg_text is declared locally; note that the GENERAL.get_message call that would have populated mesg_text and mesg_type is commented out, so mesg_type evaluates to NULL and mesg_text to NULL at runtime unless set elsewhere).
- Step 3 - Evaluate mesg_type to determine the severity classification of the message.
- Step 4 - If mesg_type is 'E' (Error): set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the formatted message and title, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 5 - If mesg_type is 'N' (Note): set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the formatted message and title; no trigger failure is raised.
- Step 6 - If mesg_type is 'C' (Caution): set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the formatted message and title; no trigger failure is raised.
- Step 7 - If mesg_type matches none of the above values, no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition: mesg_type = 'E'

TRUE: Set mesg_title to 'Error', display the message dialog via GENERAL.DISP_TEXT, and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Evaluate next condition (DP-002).

---

DP-002

Condition: mesg_type = 'N'

TRUE: Set mesg_title to 'Note' and display the message dialog via GENERAL.DISP_TEXT; processing continues normally.

FALSE: Evaluate next condition (DP-003).

---

DP-003

Condition: mesg_type = 'C'

TRUE: Set mesg_title to 'Caution' and display the message dialog via GENERAL.DISP_TEXT; processing continues normally.

FALSE: No message is displayed and the procedure exits without further action.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - A message of type 'E' (Error) is treated as a fatal condition: the error dialog must be displayed to the user and the triggering form event must be unconditionally aborted via FORM_TRIGGER_FAILURE.
- BR-002 - A message of type 'N' (Note) is treated as informational: the note dialog is displayed to the user and form processing is allowed to continue.
- BR-003 - A message of type 'C' (Caution) is treated as a non-fatal warning: the caution dialog is displayed to the user and form processing is allowed to continue.
- BR-004 - The displayed message must always include the originating message code as a prefix (format: '<mesg_code> : <mesg_text>') to aid user identification and support triage.
- BR-005 - All user-facing message dialogs must be rendered exclusively through GENERAL.DISP_TEXT; no alternative display mechanism is used by this procedure.
- BR-006 - If mesg_type does not match any recognised severity value ('E', 'N', or 'C'), the procedure takes no action and raises no exception, resulting in a silent exit.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-007 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vr_rate_card_dlr_fmb.xml [Trigger: KEY-CLRFRM]
- vr_rate_card_dlr_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SEARCH PARAMETER (N/A / CN_MAIN)

---

**Purpose**

Returns the standard application copyright declaration text aligned to the current financial year, for display on the rate card screen. The function reads the current system date and determines the appropriate copyright year based on whether the current month falls in the January-March period (which belongs to the prior financial year), ensuring the displayed copyright always reflects the correct financial year rather than the raw calendar year.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date: the function assigns SYSDATE to a local date variable.
- Step 2 - Evaluate the current month: the function checks whether the month extracted from the system date is January, February, or March.
- Step 3 - Determine the copyright year: if the current month is JAN, FEB, or MAR, the copyright year is set to the current calendar year minus one (reflecting that these months belong to the financial year that started the previous April); for all other months (April through December), the copyright year is set to the current calendar year as-is.
- Step 4 - Build the copyright string: the function concatenates a leading dash, the resolved copyright year, and the company name 'Maruti Suzuki India Limited' into a single VARCHAR2 value.
- Step 5 - Return the declaration: the fully formed copyright string is returned to the calling trigger (KEY-CLRFRM or WHEN-NEW-FORM-INSTANCE in vr_rate_card_dlr_fmb.xml) for display on the rate card screen.

---
**Decision Points**

DP-001

Condition: The month portion of SYSDATE is JAN, FEB, or MAR.

TRUE: Subtract 1 from the current four-digit calendar year and use the result as the copyright year, because these months fall within the financial year that began in the previous April.

FALSE: Use the current four-digit calendar year as the copyright year, because April through December fall within the financial year that started in the current April.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The copyright year is governed by the financial year cycle (April to March), not the calendar year; the function must never display a calendar year that does not correspond to the active financial year.
- BR-002 - For months January, February, and March, the copyright year displayed is the prior calendar year (current year - 1); for months April through December, the copyright year displayed is the current calendar year.
- BR-003 - The company name embedded in every copyright declaration is 'Maruti Suzuki India Limited', with no variation permitted.
- BR-004 - The function has no input parameters and no external dependencies; the system date is the sole input, obtained directly via SYSDATE within the function.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

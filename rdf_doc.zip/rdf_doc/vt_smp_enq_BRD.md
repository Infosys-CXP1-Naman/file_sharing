# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Business Scenarios - How vehicle lookup differs by vehicle type
    - Requirement ID: BR-004
    - Business Scenarios - How mileage validation differs by vehicle SMP type
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Business Scenarios - How service type selection affects available fields
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Business Scenarios - How package code validation differs by vehicle SMP type and service option
    - Requirement ID: BR-009
    - Business Scenarios - How SMP package generation differs by vehicle type
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Business Scenarios - How the Generate Enquiry flow differs by enquiry state
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Requirement ID: BR-023
    - Requirement ID: BR-024
    - Requirement ID: BR-025
    - Requirement ID: BR-026
    - Requirement ID: BR-027
    - Requirement ID: BR-028
    - Requirement ID: BR-029
    - Requirement ID: BR-030
    - Business Scenarios - How description lookup differs by service type
    - Requirement ID: BR-031
    - Requirement ID: BR-032
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - SMP Enquiry Header - VH_AMC_ENQ
    - SMP Enquiry Service Detail - VD_AMC_ENQ
    - SMP Enquiry Charges - VD_AMC_ENQCHARGES
    - SMP Package Staging (Work Area) - GBL_AMC_DTL
    - SMP Add-On Staging (Work Area) - GBL_SMP
    - SMP Enquiry Charges Staging (Work Area) - GBL_AMC_CHARGES
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Enquiry Identification (Advisor - new or existing)
    - Vehicle and Customer Details (Advisor - new enquiry)
    - SMP Package Selection (Advisor - after vehicle confirmed)
    - TCS Declaration (Advisor - before tax calculation)
    - Dealer Discount Entry (Advisor - optional, new enquiry only)
    - Package Detail Lines (System - after Generate SMP)
    - Add-On Services (Advisor - optional, new enquiry)
    - Parameters and Session Flags (System)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_VH_AMC_ENQ (35 columns)
    - B_VD_AMC_ENQ (35 columns)
    - B_ADDON_DLT (35 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - CALL_REPORT_ENQ
    - POP_ADDON_DETAILS
    - POP_DETAILS_AFT_DISC
    - POP_DISC
    - POP_DISC_CLEAR
    - POP_PKG_DETAILS
    - POP_SMP_DETAILS
    - SP_INSERT_CHARGES
    - GENERAL.ASK_CONFIRM
    - GENERAL.CHECK_FORM_FAILURE
    - GENERAL.CHECK_NULL
    - GENERAL.DISP_TEXT
    - GENERAL.PROC_REPORT_CALL
    - GENERAL.PROC_TIMER
    - GENERAL.PROC_TIMER_EXPIRED
    - GENERAL.RAISE_ERROR
    - PKG_AMC.SP_GET_GST_TYPE
    - PKG_SMP.SF_FLEET_CHECK
    - PKG_SMP.SF_SMP_TYPE
    - PKG_SMP.SP_GET_DEFAULT_PART
    - PKG_SMP.SP_GET_SMP_EXP
    - PKG_SMP.SP_PKG_DETAIL
    - PKG_SMP.SP_POP_SMP_ADDON
    - PKG_SMP.SP_POP_SMP_PKG
    - PKG_SMP.SP_POP_SMP_PKG_TV
    - PKG_SMP.SP_POP_SMP_TAX
    - PKG_SMP.SP_VIN_VALIDATE
    - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SF_COPYRIGHT_DECLARATION
    - SF_GET_AMLIST
    - SF_TODATE
    - SP_GET_TV_DETAIL
    - SP_GET_VEH_DETAILS
    - SP_TV_SRV
    - SP_VALIDATE_ALPHANUMERIC
    - SP_VALIDATE_OEMVIN
    - STOP_WATCH.STOP_TIMER
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT_ENQ
    - SP-002 - POP_ADDON_DETAILS
    - SP-003 - POP_DETAILS_AFT_DISC
    - SP-004 - POP_DISC
    - SP-005 - POP_DISC_CLEAR
    - SP-006 - POP_PKG_DETAILS
    - SP-007 - POP_SMP_DETAILS
    - SP-008 - SP_INSERT_CHARGES
    - SP-009 - GENERAL.ASK_CONFIRM
    - SP-010 - GENERAL.CHECK_FORM_FAILURE
    - SP-011 - GENERAL.CHECK_NULL
    - SP-012 - GENERAL.DISP_TEXT
    - SP-013 - GENERAL.PROC_REPORT_CALL
    - SP-014 - GENERAL.PROC_TIMER
    - SP-015 - GENERAL.PROC_TIMER_EXPIRED
    - SP-016 - GENERAL.RAISE_ERROR
    - SP-017 - PKG_AMC.SP_GET_GST_TYPE
    - SP-018 - PKG_SMP.SF_FLEET_CHECK
    - SP-019 - PKG_SMP.SF_SMP_TYPE
    - SP-020 - PKG_SMP.SP_GET_DEFAULT_PART
    - SP-021 - PKG_SMP.SP_GET_SMP_EXP
    - SP-022 - PKG_SMP.SP_PKG_DETAIL
    - SP-023 - PKG_SMP.SP_POP_SMP_ADDON
    - SP-024 - PKG_SMP.SP_POP_SMP_PKG
    - SP-025 - PKG_SMP.SP_POP_SMP_PKG_TV
    - SP-026 - PKG_SMP.SP_POP_SMP_TAX
    - SP-027 - PKG_SMP.SP_VIN_VALIDATE
    - SP-028 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM
    - SP-029 - WEBUTIL.ERRORALERT
    - SP-030 - WEBUTIL.GETIMPLCLASS
    - SP-031 - WEBUTIL.ID_NULL
    - SP-032 - WEBUTIL.LENGTH
    - SP-033 - WEBUTIL.PUT_LINE
    - SP-034 - WEBUTIL.SETPROPERTY
    - SP-035 - WEBUTIL.WAIT
    - SP-036 - SF_COPYRIGHT_DECLARATION
    - SP-037 - SF_GET_AMLIST
    - SP-038 - SF_TODATE
    - SP-039 - SP_GET_TV_DETAIL
    - SP-040 - SP_GET_VEH_DETAILS
    - SP-041 - SP_TV_SRV
    - SP-042 - SP_VALIDATE_ALPHANUMERIC
    - SP-043 - SP_VALIDATE_OEMVIN

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VT_SMP_ENQ - Business Requirements Document |
| Form Module Name | VT_SMP_ENQ |
| Document Version | 1.0 |
| Date Created | August 17, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 17, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vt_smp_enq Scheduled Maintenance Programme Enquiry form, its purpose, and roles referenced in the module.*

The **vt_smp_enq** Oracle Forms module is the dealership **SMP (Scheduled Maintenance Programme) Enquiry** screen. When a vehicle owner presents at a dealer outlet for an SMP contract, a Service Executive opens **vt_smp_enq**, looks up the vehicle by registration number, verifies that the vehicle is eligible for an SMP package, and confirms customer and vehicle details are correctly recorded. The executive then selects the applicable service type and SMP package, reviews the service lines covering labour, parts, and consumables with their rates and discounts, optionally selects add-on services, applies any dealer-authorised discounts, processes the GST type determination based on the dealer and customer states, confirms the Tax Collected at Source (TCS) applicability, and generates the final SMP enquiry with the complete billing breakdown. Once all details are validated the enquiry is committed to the system. From this screen the executive can also print or preview the SMP enquiry report.

### Key Stakeholders

*Who uses vt_smp_enq*

| Stakeholder | Role |
| :--- | :--- |
| **Service Executive** | **Primary interactive user** of vt_smp_enq. Looks up vehicles, selects service packages, applies discounts, confirms TCS, and commits the SMP enquiry. |
| **Vehicle Owner / Customer** | Customer whose vehicle is enrolled in SMP; customer details are captured and displayed during the enquiry process. |

---

---

## 3. System Context

*Describes the vt_smp_enq module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vt_smp_enq** module is the dealership **Scheduled Maintenance Programme (SMP) Enquiry** screen within the dealer management system. It is the entry point for creating a new SMP contract enquiry or reviewing an existing one, and it feeds the committed enquiry into the AMC billing and reporting chain.

**System purpose:** Open a new or retrieve an existing SMP enquiry, validate vehicle and customer eligibility, select the applicable package and service lines, apply discounts and GST determination, confirm TCS applicability, and commit the enquiry to the database - as implemented in the vt_smp_enq Oracle Forms module.

**In scope:**

- Retrieve an existing SMP enquiry by enquiry number, or initiate a new enquiry for a vehicle registration
- Validate that the vehicle registration exists in the vehicle master and that the VIN is eligible for SMP enrolment
- Determine fleet type (commercial or non-commercial) for package selection
- Verify that no active SMP contract already exists for the vehicle
- Fetch vehicle details, model, variant, customer, and address from the vehicle and customer masters
- Determine True Value pre-owned vehicle eligibility and applicable SMP programme type
- Select the service type and SMP package applicable to the vehicle
- Retrieve package details including expiry months, mileage, and number of services
- Populate service lines (labour, parts, consumables) with applicable rates and MCP discounts
- Select engine oil and coolant parts for the package
- Add optional add-on services to the enquiry
- Apply dealer-authorised additional discounts to service lines
- Determine GST type (SGST or IGST) based on dealer and customer states, and handle SEZ customers
- Confirm Tax Collected at Source (TCS) applicability and applicable rate
- Calculate and apply GST tax charge lines across all service lines
- Generate and commit the final SMP enquiry with all billing amounts
- Print or preview the SMP enquiry report from the form

**Process Name:** SMP Enquiry

**Process Owner:** Service Manager

**Process Objective:** Open or retrieve an SMP enquiry, validate vehicle eligibility and customer details, select and populate the applicable service package with discounts and taxes, and save the enquiry before SMP enrolment and billing proceed.

**Process Trigger:** A vehicle owner presents at the dealer outlet to enquire about or enrol in an SMP contract

**Process Flow:**

The complete smp enquiry process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         Service Executive opens the SMP Enquiry screen.
         Session globals (dealer, location, company, principal) are initialised.

STEP 2 ── NEW OR EXISTING ENQUIRY?
         ├── EXISTING: Executive enters the enquiry number; system verifies it exists
         │             in the AMC enquiry header for the current dealer and loads the record
         └── NEW: Leave enquiry number blank and proceed to vehicle registration entry

STEP 3 ── VEHICLE REGISTRATION ENTRY
         Executive enters the vehicle registration number.
         System validates the registration exists in the vehicle master.

STEP 4 ── VEHICLE AND CUSTOMER DETAILS POPULATED
         System automatically retrieves vehicle details (VIN, model, variant, chassis,
         engine number, colour, sale date, odometer) and customer details (name,
         address, city, phone, mobile, email) from master records.

STEP 5 ── TRUE VALUE PRE-OWNED VEHICLE CHECK
         System checks whether the vehicle is a True Value pre-owned vehicle.
         ├── TRUE VALUE VEHICLE: SMP eligibility is evaluated against resale date and
         │   age/mileage parameters; TV SMP programme is flagged if eligible
         └── STANDARD VEHICLE: Standard SMP eligibility evaluation proceeds

STEP 6 ── FLEET TYPE DETERMINATION
         System determines whether the vehicle is a commercial fleet vehicle
         or a non-commercial personal vehicle based on variant and registration type.

STEP 7 ── DUPLICATE OPEN ENQUIRY CHECK
         System checks whether an open SMP enquiry already exists for this vehicle.
         ├── DUPLICATE FOUND: Executive is prompted to confirm cancellation of the
         │   existing open enquiry before proceeding with a new one
         └── NO DUPLICATE: Process continues

STEP 8 ── GST TYPE DETERMINATION
         System compares dealer state and customer state to determine the applicable
         GST type (SGST for same-state transactions, IGST for inter-state or SEZ customers).
         Customer state must be recorded in the customer master; an error is shown if missing.

STEP 9 ── SMP ELIGIBILITY VALIDATION (ODOMETER)
         Executive enters or confirms the current odometer reading.
         System validates vehicle VIN eligibility for SMP and determines validity mileage,
         validity age, service number, and sub-service based on odometer and vehicle age.

STEP 10 ── SERVICE EXECUTIVE ASSIGNMENT
          Executive enters the service executive code responsible for the enquiry.

STEP 11 ── SERVICE TYPE SELECTION
          Executive selects the applicable service type from the list of values.
          System determines the SMP sub-service type based on odometer and service history.

STEP 12 ── SMP PACKAGE SELECTION
          Executive selects the SMP package code from the applicable package list.
          System retrieves package expiry months, expiry mileage, and number of services.
          Default engine oil and coolant parts for the vehicle variant are pre-filled.

STEP 13 ── PACKAGE SERVICE LINES POPULATED (FETCH DETAILS)
          Executive clicks Fetch Details.
          ├── STANDARD SMP: System populates all labour, parts, and consumable service lines
          │   from the package definition with applicable rates and MCP discounts
          └── TRUE VALUE SMP: System populates service lines using the TV-specific package configuration

STEP 14 ── ADD-ON SERVICES SELECTION (optional)
          Executive opens the add-on panel and selects optional add-on services by checking
          the add-on checkbox. System inserts add-on labour, parts, and consumable lines
          with applicable rates into the working table.

STEP 15 ── DEALER DISCOUNT APPLICATION (optional)
          Executive enters additional dealer-authorised discount percentages for
          labour, parts, and consumables. System validates discount type indicators
          and range limits, then applies discounts to all service lines.

STEP 16 ── TCS APPLICABILITY CONFIRMATION
          System displays TCS (Tax Collected at Source under Section 206C(1H)) information.
          Executive confirms whether TCS is applicable or not, and at which rate.
          ├── TCS APPLICABLE (NORMAL): Normal TCS rate recorded
          ├── TCS APPLICABLE (HIGHER): Higher TCS rate recorded
          └── TCS NOT APPLICABLE: Executive confirms aggregate sales do not exceed ₹50 lakhs

STEP 17 ── TAX CALCULATION (GENERATE ENQUIRY)
          Executive clicks Generate Enquiry.
          System calculates GST charge lines (CGST/SGST or IGST) for all service lines
          and inserts tax amounts into the charges working table.

STEP 18 ── BILLING SUMMARY REVIEW
          System displays the complete billing breakdown: package amount, labour, parts,
          consumables, MCP discounts, dealer discounts, GST taxes, TCS, and total bill amount.

STEP 19 ── SAVE / COMMIT
          Executive saves the enquiry. System validates all required fields, inserts
          charge lines into the permanent charges table, clears the working tables,
          and commits the SMP enquiry record.

STEP 20 ── REPORT GENERATION (optional)
          Executive generates the SMP enquiry report. System prompts for output
          destination (screen PDF or printer), submits the report job to the report
          server, and displays or prints the output.
```

**Major process interactions:**

- **Vehicle master** - provides VIN, model, variant, sale date, odometer, and customer linkage for each vehicle
- **Customer master** - provides customer name, address, contact details, and state for GST type determination
- **AMC package and SMP parameter masters** - define applicable packages, service lines, rates, expiry parameters, and eligibility rules
- **GST and tax configuration** - provides tax codes, rates, and GST state codes for charge calculation
- **AMC working tables** - store in-progress service lines and charge details until the enquiry is committed
- **AMC enquiry header and detail tables** - persist the committed SMP enquiry and its service lines
- **SMP report server** - generates and delivers the SMP enquiry report for print or screen preview

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Startup - Application Session Registration and Performance Logging Initialisation

**Business Description:**
When the SMP Enquiry form is opened, the system registers the current user session with the application monitoring infrastructure so that database administrators and support staff can identify which form is in use. If performance logging is activated for the organisation, the form simultaneously starts a timing session to track how long key operations within the enquiry take to complete. Once the session is registered, the system verifies that the SMP (Service Maintenance Package) programme is active for the current dealership location. If the programme has been disabled by the MSIL Service team, the form immediately displays an error and closes without allowing use. If the programme is active, the form initialises the save-state control, maximises the main application window, and sets the form into savepoint mode so that transaction boundaries are properly managed.

**Actors:** Service Advisor

**Preconditions:**
- The user has successfully logged in and the form is being launched.

**Main Flow:**

**Step 1 - Session identity registered with the database monitoring layer**
As the form is about to open (PRE-FORM), the system records the form's identity ("vt_smp_enq") in the current database session so that any active monitoring tools can attribute database activity to this specific form. The form module name and action name are also set in the session for performance tracking.

**Step 2 - Performance timer started when application logging is active**
If performance logging is enabled for the dealership's environment, a performance timer is started at this point to allow the system to measure and record how long subsequent operations take during the enquiry session.

**Step 3 - SMP programme activation verified for the dealership**
Once the form instance is created (WHEN-NEW-FORM-INSTANCE), the system queries the dealer location parameter table to check whether the SMP programme has been activated for the current dealer, parent group, and location. If the programme is not active, an error is shown and the form closes immediately.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP programme is active for the dealership location | SMP activation flag check - WHEN-NEW-FORM-INSTANCE; queries am_dealer_loc_param.smp_activate_flag for current dealer, parent_group, and loc_cd | When the form opens | Prevents use of the SMP Enquiry form at locations where the SMP programme has not been enabled | *"SMP has been disabled by MSIL-Service"* is shown; the form exits immediately |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-ES-01** - SMP is not active at this location - *"SMP has been disabled by MSIL-Service"*; the form closes and cannot be used.

**Step 4 - Form initialised and application window maximised**
If SMP is active, the system initialises the save-state parameter (`parameter.p_save`) to "N" to indicate no pending save at start-up, maximises the main application window (WN_MAIN), and sets the form's savepoint mode to enabled so that transaction control works correctly during the session.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 2) If performance logging is not enabled, no timer is started and the form opens without any timing activity.
- **BR-001-AF-02** - (from Step 3) SMP is not active - *"SMP has been disabled by MSIL-Service"*; form exits; advisor cannot proceed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display | N/A | N/A | N/A | Form open | System-set only; populated by the copyright declaration function during form clear/initialisation | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Enquiry Number Lookup - Load Existing SMP Enquiry for Review

**Business Description:**
When an operator enters an existing SMP enquiry number into the enquiry number field and navigates away, the system checks that the number corresponds to a valid, previously recorded SMP enquiry for the current dealership and location. If the number is found, the enquiry record and all its associated service details are loaded onto the screen in read-only mode for review. If the number is not found, the operator is informed and entry is blocked.

**Actors:** Service Advisor

**Preconditions:**
- The enquiry number field is available for entry (a new enquiry has not yet been started).

**Main Flow:**

**Step 1 - Enquiry number entered and existence verified**
The operator types an enquiry number. The system searches for an SMP enquiry with that number for the current dealership, location, and company. If the enquiry does not exist, entry is blocked and an error is shown.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-011](#SP-011--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - displays the error or informational message to the operator on screen.
    * **Step 1** - Receive the message text and its severity category (error, warning, or informational note).
    * **Step 2** - Present the message to the operator in the appropriate message display area.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP enquiry number exists for this dealership | Existence check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.NB_ENQ_NUM; queries VH_AMC_ENQ for matching enquiry | When the operator navigates away from the enquiry number field | Ensures the operator can only load a valid, previously saved SMP enquiry | *"SMP Enquiry Number Not Found"* is shown; operator must re-enter a valid number |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Enquiry number entered does not match any SMP enquiry for this dealership - *"SMP Enquiry Number Not Found"*; entry is blocked and the operator must correct the value.

**Step 2 - Existing enquiry loaded and form set to read-only mode**
Once the enquiry number is validated, the system loads the complete enquiry header and all associated service detail lines. All entry and action fields that are not applicable for reviewing an existing enquiry - including the registration number, mileage, executive, service option, discount fields, and all action buttons - are disabled so the record cannot be inadvertently changed.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) If the enquiry number field is left blank, no validation runs and the form remains in new-enquiry entry mode.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Enquiry No. (`NB_ENQ_NUM`) | Conditional - when reviewing an existing enquiry | Text | N/A | SMP Enquiry master (VH_AMC_ENQ) | Existing SMP enquiry number | Form open | Must correspond to an existing SMP enquiry for the current dealership and location | *"SMP Enquiry Number Not Found"* |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Vehicle Registration Number Entry - Vehicle Detail Population and SMP Eligibility Verification

**Business Description:**
When the service advisor enters a vehicle's registration number, the system validates that the registration exists in the vehicle master and then automatically populates all related vehicle, customer, and address details on the screen. It further determines whether the vehicle qualifies for a Scheduled Maintenance Plan (SMP), checks whether a True Value pre-owned vehicle SMP applies, determines the applicable GST type based on the dealer and customer states, and flags any existing open enquiry for the same vehicle. If the vehicle does not qualify for SMP or the registration is not found, entry is blocked and the operator is informed.

**Actors:** Service Advisor

**Preconditions:**
- A new SMP enquiry is being created (no existing enquiry number has been entered for lookup).
- The registration number field is available for entry.

**Main Flow:**

**Step 1 - Registration number format sanitised**
The system removes any non-alphanumeric characters from the registration number entered by the advisor, retaining only letters and digits.

*Procedures called:*
- **SP_VALIDATE_ALPHANUMERIC** ([SP-040](#SP-040--SP_VALIDATE_ALPHANUMERIC)) - SP_VALIDATE_ALPHANUMERIC - strips any characters from the entered value that are not letters or digits, returning the cleaned registration number.
    * **Step 1** - Receive the registration number as entered by the operator.
    * **Step 2** - Examine each character of the value; retain only uppercase letters (A-Z) and numeric digits (0-9), and remove any other character (special characters, spaces, etc.).
    * **Step 3** - Return the cleaned registration number to the calling form field.

**Step 2 - Registration number confirmed in the vehicle master**
The system checks that the cleaned registration number exists in the vehicle identification master. If it is not found, too many matches are returned, or a data compatibility issue occurs, processing stops and the advisor sees an appropriate error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Registration number exists (unique match) | Existence check - WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM; queries GM_VIN for the registration number | When the advisor tabs off the Registration Number field | Confirms the registration number identifies exactly one vehicle before any vehicle details are loaded | *"Registration Number Not Found"* if no match; *"More than one Registration Number found for [registration number]"* if duplicate; *"Width problem/Incompatiable data"* on data compatibility error; the system's own database error text followed by *"Execution failed while retrieving Registration No. [SQLERRM]"* on other errors |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Registration number has no match in the vehicle master - *"Registration Number Not Found"*; advisor must re-enter a valid registration.
- **BR-003-ES-02** - More than one vehicle record found for the registration number - *"More than one Registration Number found for [entered registration number]"*; processing is blocked.
- **BR-003-ES-03** - Data type incompatibility encountered when querying the vehicle record - *"Width problem/Incompatiable data"*; processing is blocked.
- **BR-003-ES-04** - Unexpected database error during registration lookup - the system's own database error text followed by the fixed suffix *"Execution failed while retrieving Registration No."*; processing is blocked.

**Step 3 - Vehicle and customer details retrieved and populated**
The vehicle identification number (VIN), model, variant, colour, customer name, customer address, phone, mobile, city, email, chassis number, engine number, last recorded mileage, and vehicle sale date are all loaded and displayed. The dealer service type category (fleet or standard) is also determined for the vehicle and stored for downstream use.

*Procedures called:*
- **SP_GET_VEH_DETAILS** ([SP-038](#SP-038--SP_GET_VEH_DETAILS)) - SP_GET_VEH_DETAILS - retrieves the full vehicle and customer profile for the given registration number.
    * **Step 1** - Accept the registration number, principal, parent group, dealer, and location as inputs.
    * **Step 2** - Look up the vehicle identification record to obtain the VIN, model, variant, colour, chassis, engine number, last mileage, and sale date.
    * **Step 3** - Look up the customer record linked to the vehicle to retrieve the customer code, name, full address, phone, mobile, city, and email.
    * **Step 4** - Retrieve any outstanding balance amount and VIP status for the customer, and return all retrieved values together with an error code and message to the calling form.
- **PKG_SMP.SF_FLEET_CHECK** ([SP-017](#SP-017--PKG_SMP.SF_FLEET_CHECK)) - PKG_SMP.SF_FLEET_CHECK - determines whether the vehicle qualifies as a commercial/fleet vehicle based on variant attributes or fleet registration, and returns the applicable service type category.
    * **Step 1** - Accept the principal, vehicle identification number, and variant code.
    * **Step 2** - Check whether the vehicle's variant is flagged as a commercial service vehicle or the vehicle is registered as a fleet vehicle in the national fleet system.
    * **Step 3** - Return the service type category (commercial or standard) to the calling form.

**Step 4 - True Value pre-owned SMP eligibility assessed (where vehicle is a True Value vehicle)**
For vehicles flagged as True Value resale vehicles, the system checks the resale date and the configured age/mileage limits to determine whether a True Value SMP is available. If eligible, additional True Value SMP attributes (resale date, expiry date, sub-service range) are retrieved. If a TV3 repair order already exists after resale, or the True Value SMP service check fails, the vehicle is treated as a standard (non-TV) SMP candidate.

*Procedures called:*
- **SP_GET_TV_DETAIL** ([SP-037](#SP-037--SP_GET_TV_DETAIL)) - SP_GET_TV_DETAIL - retrieves True Value warranty and resale details for a vehicle identified by VIN.
    * **Step 1** - Accept the vehicle's VIN, the current date, and the current mileage.
    * **Step 2** - Look up the vehicle's True Value warranty record; retrieve the True Value flag, resale date, and warranty expiry date.
    * **Step 3** - If no True Value record is found, set the True Value indicator to not-applicable and return.
    * **Step 4** - Return the True Value eligibility indicator, resale date, and expiry date to the calling trigger.
- **SP_TV_SRV** ([SP-039](#SP-039--SP_TV_SRV)) - SP_TV_SRV - checks whether a True Value SMP service record already exists for the vehicle and validates that the vehicle is still within the TV SMP service window.
    * **Step 1** - Accept the parent group, registration number, current date, current mileage, and the TV3 service category code.
    * **Step 2** - Retrieve the vehicle's VIN, True Value warranty expiry details, resale date, and service start date.
    * **Step 3** - Verify that the enquiry date is within the allowed service period (between resale date and warranty expiry).
    * **Step 4** - Return an error code and message if the vehicle is outside the TV SMP service window; otherwise confirm eligibility.

**Step 5 - Duplicate open enquiry detected and advisor prompted**
The system checks whether another SMP enquiry in open status already exists for the same vehicle at the current dealership. If one is found, the advisor is presented with an alert to decide whether to continue creating a new enquiry alongside the existing one or to cancel.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No duplicate open SMP enquiry exists | Duplicate check - WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM; queries VH_AMC_ENQ for an open SMP enquiry for the same VIN at the same dealer | After vehicle details are loaded | Alerts the advisor when an open SMP enquiry already exists for the vehicle so no unintended duplicates are created | An alert is displayed (AL_ENQ); if the advisor confirms continuation, a duplicate flag is set; if the advisor declines, processing is blocked and the trigger is aborted |

**Step 6 - GST type determined and customer state details displayed**
The applicable GST category (inter-state or intra-state) is determined by comparing the dealer's state with the customer's registered state. If the customer is registered as an SEZ entity, the GST type radio group is locked to the SEZ value. If the dealer and customer states match, the GST type is locked; otherwise the advisor may select it. The customer's state description is also displayed.

*Procedures called:*
- **PKG_AMC.SP_GET_GST_TYPE** ([SP-016](#SP-016--PKG_AMC.SP_GET_GST_TYPE)) - PKG_AMC.SP_GET_GST_TYPE - determines the applicable GST category and retrieves the dealer and customer state codes for the registration.
    * **Step 1** - Accept the principal, parent group, dealer, location, and registration number.
    * **Step 2** - Look up the dealer's location to retrieve the dealer's GST state code.
    * **Step 3** - Look up the customer linked to the registration number to retrieve the customer's GST state code and SEZ status.
    * **Step 4** - Compare the dealer state and customer state; determine the GST type (intra-state or inter-state) accordingly.
    * **Step 5** - Return the GST type, dealer state code, customer state code, SEZ status, and any error details to the calling trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| GST type derivation succeeds | GST determination - PKG_AMC.SP_GET_GST_TYPE [SP-016]; evaluates dealer and customer state codes | After vehicle and customer details are loaded | Ensures the correct GST treatment (intra-state or inter-state) is applied to the enquiry based on where the dealer and customer are located | Error text returned by the procedure is shown via GENERAL.DISP_TEXT; processing is blocked |

**Step 7 - Vehicle SMP eligibility confirmed**
The system calls the SMP eligibility check to validate that the vehicle is covered under an active SMP contract, and to retrieve the applicable validity mileage, validity age, number of services, sub-service range, and CDS indicator. If the vehicle is not eligible for SMP, processing is blocked and the advisor is informed.

*Procedures called:*
- **PKG_SMP.SP_VIN_VALIDATE** ([SP-026](#SP-026--PKG_SMP.SP_VIN_VALIDATE)) - PKG_SMP.SP_VIN_VALIDATE - validates that the vehicle identified by its VIN is eligible for SMP and returns the plan's validity parameters.
    * **Step 1** - Accept the principal, VIN, and current mileage.
    * **Step 2** - Retrieve the vehicle's invoice date, model, variant, and last recorded mileage from the vehicle master.
    * **Step 3** - Look up the applicable SMP validity parameters (validity in months, validity mileage, number of services allowed) for the vehicle's model and variant.
    * **Step 4** - Check whether the vehicle falls within the SMP validity window based on age and mileage; if not eligible, set the SMP eligibility flag accordingly.
    * **Step 5** - Return the SMP eligibility flag, validity mileage, validity age, number of services, sub-service range, CDS indicator, and any error details to the calling trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Vehicle is eligible for SMP | SMP eligibility - PKG_SMP.SP_VIN_VALIDATE [SP-026]; checks validity months, mileage, and service count against the vehicle's profile | After GST type is determined | Ensures only vehicles covered by an active SMP contract can be enrolled in an enquiry | *"Vehicle can not be considered for SMP"* if eligibility flag is returned as not eligible; or *"Error!... [error message from procedure]"* if the procedure returns an error code; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-05** - SMP eligibility procedure returns an error - *"Error!... [error message returned by the eligibility check]"*; processing is blocked.
- **BR-003-ES-06** - Vehicle is not eligible for SMP - *"Vehicle can not be considered for SMP"*; processing is blocked.

#### Business Scenarios - How vehicle lookup differs by vehicle type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard SMP vehicle** | Full registration lookup and eligibility check run; True Value SMP assessment is skipped (vehicle is not flagged as True Value); standard SMP eligibility parameters are returned. |
| **True Value pre-owned vehicle within eligibility window** | After standard vehicle detail population, the True Value resale date and warranty details are retrieved and checked; if within the configured age and mileage limits and no TV3 repair order has been raised since resale, the vehicle is flagged for True Value SMP and the True Value SMP indicator is set accordingly. |
| **True Value vehicle outside eligibility window or with existing TV3 repair order** | True Value SMP check runs but determines the vehicle is no longer within the allowed True Value SMP window or has already received a TV3 service; the vehicle is treated as a standard (non-TV) SMP candidate. |

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 2) Registration number not found in vehicle master - *"Registration Number Not Found"*; trigger is aborted; advisor must re-enter.
- **BR-003-AF-02** - (from Step 2) More than one vehicle record matches the registration - *"More than one Registration Number found for [registration number]"*; trigger is aborted.
- **BR-003-AF-03** - (from Step 5) Advisor confirms continuation despite duplicate open enquiry - duplicate flag is set to indicate the advisor acknowledged the duplicate; enquiry entry continues.
- **BR-003-AF-04** - (from Step 5) Advisor declines continuation when duplicate open enquiry is found - trigger is aborted via FORM_TRIGGER_FAILURE; the registration number field retains the entered value but further processing stops until the advisor resolves the situation.
- **BR-003-AF-05** - (from Step 6) GST type determination returns an error - *"[error message from procedure]"* shown; trigger is aborted.
- **BR-003-AF-06** - (from Step 7) SMP eligibility check returns an error code - *"Error!... [error message from eligibility check]"* shown; trigger is aborted.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Registration Number (`REG_NUM`) | Mandatory | Text | N/A | Vehicle master (GM_VIN) | VIN and vehicle profile | New enquiry being created | Must exist uniquely in the vehicle master; non-alphanumeric characters are stripped before lookup | *"Registration Number Not Found"*; *"More than one Registration Number found for [registration]"*; *"Width problem/Incompatiable data"*; system error text + *"Execution failed while retrieving Registration No."* |
| Vehicle Sale Date (`NB_VEH_SALE_DT`) | Read-only display | Date | DD/MM/YY | N/A | Populated from vehicle master | Registration validated | System-set only | N/A |
| GST Type (`RG_GSTTYPE`) | Conditional - enabled when dealer and customer states differ and customer is not SEZ | Radio group | N/A | N/A | Intra-state / Inter-state | Registration validated | Locked when dealer and customer states match, or customer is SEZ-registered | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Current Mileage Entry - Mileage Validation and SMP Validity Confirmation

**Business Description:**
When the service advisor records the vehicle's current mileage (odometer reading), the system validates that the mileage is not below the vehicle's previously recorded service mileage (which would indicate a data entry error), re-confirms SMP eligibility at the entered mileage, and checks that the vehicle has not exceeded the plan's maximum validity mileage or age. Any downstream package, pricing, and discount fields are reset to blank so that the service type selection and package selection steps reflect the newly entered mileage. For True Value SMP vehicles, the system additionally checks whether the entered mileage is within the True Value SMP mileage limit.

**Actors:** Service Advisor

**Preconditions:**
- The vehicle's registration number has been entered and confirmed, and vehicle details have been loaded.

**Main Flow:**

**Step 1 - Mileage is mandatory and must be entered**
The system requires the current mileage field to be populated; an entry of blank is not accepted.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies that the current mileage field is not empty before any further validation proceeds.
    * **Step 1** - Receive the field value and the field's business label ("Current Mileage").
    * **Step 2** - If the value is blank or null, display an error telling the operator that "Current Mileage" must be filled in and stop further processing.
    * **Step 3** - If the value is present, return control to the calling trigger to continue validation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current Mileage is not blank | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING | When the advisor navigates away from the Current Mileage field | Prevents saving an enquiry without a mileage reading, which is required for eligibility and package selection | Error shown by GENERAL.CHECK_NULL; processing is blocked |

**Step 2 - Mileage compared against previous service mileage**
For standard SMP vehicles, the entered mileage is compared to the previous service mileage. For True Value SMP vehicles, the mileage is compared to the higher of the previous service mileage and the True Value selling mileage. If the entered value is lower, processing is blocked.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Current mileage is not lower than previous service mileage | Comparison check - WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING; compares ODOMETER_READING to NB_ODOMETER_READING | When the advisor navigates away from the Current Mileage field | Prevents a logically impossible mileage entry that would indicate incorrect data | *"Current Mileage cannot be less than Previous Service Mileage or True value Selling Mileage [previous mileage value]"* (TV SMP vehicles); *"Current Mileage cannot be less than Previous Service Mileage [previous mileage value]"* (standard vehicles) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Entered mileage is below the previous service mileage - *"Current Mileage cannot be less than Previous Service Mileage or True value Selling Mileage [previous mileage]"* (TV SMP) or *"Current Mileage cannot be less than Previous Service Mileage [previous mileage]"* (standard); processing is blocked.

**Step 3 - For True Value SMP vehicles, True Value SMP eligibility re-evaluated at entered mileage**
If the vehicle is flagged as a True Value SMP candidate, the system recalculates whether the entered mileage is within the allowed True Value SMP mileage limit (True Value selling mileage plus the configured maximum True Value SMP mileage). If the entered mileage exceeds this limit, the True Value SMP flag is set to not applicable.

**Step 4 - SMP eligibility re-confirmed at new mileage, and downstream fields reset**
The system re-runs the SMP eligibility check using the newly entered mileage to refresh the validity parameters. All previously computed service type, package, pricing, discount, tax, and add-on fields are cleared so that the user must re-select service type and package based on the current mileage. If the eligibility check fails or the mileage exceeds the SMP validity limit, processing is blocked.

*Procedures called:*
- **PKG_SMP.SP_VIN_VALIDATE** ([SP-026](#SP-026--PKG_SMP.SP_VIN_VALIDATE)) - PKG_SMP.SP_VIN_VALIDATE - re-validates SMP eligibility at the current mileage and refreshes the validity parameters.
    * **Step 1** - Accept the principal, VIN, and the newly entered mileage.
    * **Step 2** - Look up the vehicle's invoice date, model, variant, and mileage from the vehicle master.
    * **Step 3** - Look up the applicable SMP validity parameters for the vehicle's model and variant.
    * **Step 4** - Check whether the vehicle falls within the SMP validity window based on age and mileage; return the eligibility flag.
    * **Step 5** - Return the SMP eligibility flag, validity mileage, validity age, number of services, sub-service range, CDS indicator, and any error details.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP eligibility confirmed at new mileage | SMP re-validation - PKG_SMP.SP_VIN_VALIDATE [SP-026]; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING | When the advisor navigates away from the Current Mileage field | Ensures the vehicle's SMP coverage is still valid at the mileage the advisor has entered | *"Vehicle can not be considered for SMP"* if not eligible; *"Milease expired, So Vehicle can not be considered for SMP"* if maximum validity mileage exceeded; *"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"* if sale date has passed the validity age limit; processing is blocked in all cases |
| Validity mileage not exceeded | Mileage limit check - WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING; compares ODOMETER_READING to NB_VAL_MIL | After SMP eligibility is confirmed | Prevents creation of an SMP enquiry for a vehicle that has already exceeded the plan's maximum mileage | *"Milease expired, So Vehicle can not be considered for SMP"* |
| Vehicle sale age within SMP validity period | Age limit check - WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING; compares today's date to ADD_MONTHS(sale date, validity age) | After mileage limit is confirmed | Prevents creation of an SMP enquiry for a vehicle that is older than the SMP plan's validity period | *"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-02** - SMP eligibility check returns an error code - *"Error!... [error message from eligibility check]"*; processing is blocked.
- **BR-004-ES-03** - Vehicle is not SMP-eligible at the entered mileage - *"Vehicle can not be considered for SMP"*; processing is blocked.
- **BR-004-ES-04** - Vehicle has exceeded the SMP validity mileage - *"Milease expired, So Vehicle can not be considered for SMP"*; processing is blocked.
- **BR-004-ES-05** - Vehicle sale date is beyond the SMP validity period - *"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"*; processing is blocked.

#### Business Scenarios - How mileage validation differs by vehicle SMP type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard SMP vehicle** | Mileage is compared to the previous service mileage only; True Value mileage limit check is skipped. |
| **True Value SMP vehicle** | Mileage is compared to the higher of the previous service mileage and the True Value selling mileage; an additional check verifies that the entered mileage is within the True Value SMP mileage limit (selling mileage + configured maximum) - if exceeded, the True Value SMP flag is set to not applicable. |

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 2) Entered mileage is below the minimum threshold - error shown; processing blocked; advisor must correct the value.
- **BR-004-AF-02** - (from Step 4) SMP eligibility check cannot be completed due to an unexpected error - SMP eligibility flag is set to not eligible; advisor must resolve or re-enter registration.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Current Mileage (`ODOMETER_READING`) | Mandatory | Numeric | N/A | N/A | N/A | Registration number validated | Must not be blank; must be ≥ previous service mileage; must not exceed SMP validity mileage; vehicle sale date must be within SMP validity age | Multiple - see Business outcomes above |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Service Executive Entry - Mandatory Employee Code Validation

**Business Description:**
When a new SMP enquiry is being created (not reviewed via an existing enquiry number), the service advisor must select or enter a service executive code. The system verifies that this field is not left blank before allowing the advisor to proceed to the service type selection.

**Actors:** Service Advisor

**Preconditions:**
- A new SMP enquiry is being created; no existing enquiry number has been entered for lookup.
- The vehicle registration number and current mileage have already been entered and confirmed.

**Main Flow:**

**Step 1 - Service executive field validated as mandatory for new enquiries**
When the advisor tabs off the executive field during new enquiry creation, the system checks that a service executive code has been entered. If the field is blank, processing is blocked.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies that the service executive field is not empty, raising an error if it is.
    * **Step 1** - Receive the field value and the field's business label ("Executive").
    * **Step 2** - If the value is blank or null, display an error telling the operator that "Executive" must be filled in and stop further processing.
    * **Step 3** - If the value is present, return control to the calling trigger to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Service executive code is not blank (new enquiry only) | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.EMP_CD; only runs when no enquiry number is loaded | When the advisor navigates away from the executive field | Ensures every new SMP enquiry is assigned to a specific service executive for accountability and tracking | Error shown by GENERAL.CHECK_NULL; processing is blocked |

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 1) The enquiry number field already contains a loaded enquiry - the executive validation is skipped entirely, as the form is in review mode.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Executive (`EMP_CD`) | Conditional - Mandatory when creating a new enquiry | Text | N/A | Employee master (GM_EMP - populated via LOV_EXEC) | Employee code | Mileage entered and validated | Must not be blank for a new enquiry | Error shown by mandatory check; processing is blocked |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Service Type Selection - Package List Category Determination and Service Option Availability

**Business Description:**
After confirming the vehicle's mileage, the service advisor selects the applicable service type for the SMP enquiry. The system validates that a service type has been selected, determines the internal package list category for the combination of vehicle, service type, and current mileage, and automatically sets the default package code and retrieves its description. All previously entered package, pricing, and discount values are reset so that the next package selection step starts from a clean state. The service option field and the engine oil / coolant selection fields are enabled or disabled based on the selected service type.

**Actors:** Service Advisor

**Preconditions:**
- The vehicle's registration number and current mileage have been entered and confirmed.
- Vehicle SMP eligibility has been confirmed.

**Main Flow:**

**Step 1 - Service type is mandatory**
The system checks that the service type field is not blank before any package determination runs.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies that the applicable service type field is not empty.
    * **Step 1** - Receive the field value and the field's business label ("Applicable Service Type").
    * **Step 2** - If the value is blank or null, display an error telling the operator that "Applicable Service Type" must be filled in and stop further processing.
    * **Step 3** - If the value is present, return control to the calling trigger to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Service type is not blank | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.SERV_TYPE | When the advisor navigates away from the Service Type field | Ensures an applicable service type is chosen before packages are derived | Error shown by mandatory check; processing is blocked |

**Step 2 - Package list category derived from vehicle, service type, and mileage**
The system determines the applicable package list category number for this vehicle, service type, and odometer combination. Based on the category, the default package code is assigned (package code "SMP1" for category 3, "SMP2" for all other categories). The package description matching the derived category and package code is retrieved and displayed.

*Procedures called:*
- **PKG_SMP.SF_SMP_TYPE** ([SP-018](#SP-018--PKG_SMP.SF_SMP_TYPE)) - PKG_SMP.SF_SMP_TYPE - determines the applicable SMP package list category code for the vehicle, service type, and mileage combination.
    * **Step 1** - Accept the principal, VIN, service type, and current mileage.
    * **Step 2** - Retrieve the vehicle's model, variant, and age in months from the vehicle master.
    * **Step 3** - Determine the current service sub-category from the vehicle's repair order history and compare it to the vehicle's age and mileage to identify the applicable package list category.
    * **Step 4** - Return the package list category number to the calling trigger.

**Step 3 - Downstream fields reset and service option availability set**
All previously entered package, expiry, service count, sub-service range, pricing, discount, tax, engine oil, coolant, and add-on fields are cleared. If the service type is "PMS" and the enquiry is new (not loaded for review), the service option and engine oil/coolant selection fields are enabled; for all other service types, the service option and coolant selection fields are disabled.

#### Business Scenarios - How service type selection affects available fields

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **PMS service type (new enquiry)** | Service option field and engine oil/coolant selection fields are enabled so the advisor can choose the desired option. |
| **Non-PMS service type** | Service option field and coolant field are disabled; only the default package applies for the service type. |
| **PMS service type (existing enquiry loaded for review)** | Service option and engine oil/coolant fields remain disabled, as the enquiry is in read-only mode. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Applicable Service Type (`SERV_TYPE`) | Mandatory | List | N/A | Service type list (RG_SRV_TYPE / LV_SRV_TYPE) | Service type code | Mileage entered and confirmed | Must not be blank | Error shown by mandatory check |
| Service Option (`SERV_OPTION`) | Conditional - enabled when service type is PMS on a new enquiry | List | N/A | N/A | Package or Labour option | Service type is PMS | System-controlled; set to default value "P" when service type is validated | N/A |
| Package Code (`PKG_CODE`) | Auto-populated | Text | N/A | SMP package master (VM_SMP_PACKAGE) | Package code | Service type selected | System-set based on derived package list category | N/A |
| Package Description (`PKG_DESC`) | Read-only display | Text | N/A | SMP package master (VM_SMP_PACKAGE) | Package description | Package code populated | System-set; retrieved to match active package list category and package code | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Service Option Change - Reset Package Pricing on Option Switch

**Business Description:**
When the service advisor changes the service option (for example, switching between a full package and a labour-only option), all previously loaded package amounts, discount values, and tax totals are cleared. This ensures that the package details retrieved in the subsequent step reflect the newly chosen service option rather than the old one.

**Actors:** Service Advisor

**Preconditions:**
- The service type has been selected and confirmed.
- The service option field is enabled (service type is PMS and the form is in new-enquiry mode).

**Main Flow:**

**Step 1 - All pricing, discount, and add-on fields cleared on service option change**
When the advisor changes the service option selection, the system immediately clears all package-related amount fields (labour, parts, consumables, package total, billing total), all discount amounts (MCP and dealer discount fields for labour, parts, and consumables), all tax amounts, all sub-total fields, and all add-on amounts. This resets the enquiry pricing section so that the next "Generate SMP" or "Generate Enquiry" action re-populates everything correctly for the newly selected option.

*Screen: Details (`CN_DEF`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service Option (`SERV_OPTION`) | Conditional - enabled for PMS on new enquiry | List | N/A | N/A | Package option or Labour-only option | Service type is PMS | System-clears all pricing fields when changed | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Package Code Validation - Service Range, Expiry, and Default Consumable Parts Determination

**Business Description:**
After the advisor selects or confirms the package code, the system validates that the field is not empty and then performs a detailed package determination: it retrieves the package's validity parameters (expiry months and mileage, number of services), calculates the starting and ending sub-service numbers based on the vehicle's service history and current mileage, retrieves the SMP contract expiry date and mileage, and, for packages that include a full parts option, determines and populates the default engine oil and (for PMS service type) coolant part numbers. All previously entered pricing and discount amounts are then reset.

**Actors:** Service Advisor

**Preconditions:**
- The vehicle's registration number, mileage, and service type have been entered and confirmed.

**Main Flow:**

**Step 1 - Package code is mandatory**
The system checks that a package code has been entered.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies that the applicable package field is not empty.
    * **Step 1** - Receive the field value and the field's business label ("Applicable Package").
    * **Step 2** - If the value is blank or null, display an error and stop further processing.
    * **Step 3** - If the value is present, return control to the calling trigger.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Package code is not blank | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.PKG_CODE | When the advisor navigates away from the Package Code field | Ensures a package is selected before any package-level calculations run | Error shown by mandatory check; processing is blocked |

**Step 2 - Package validity parameters retrieved**
The system looks up the package's configured expiry months, expiry mileage, and number of services for the vehicle's fleet category and the selected package.

*Procedures called:*
- **PKG_SMP.SP_PKG_DETAIL** ([SP-021](#SP-021--PKG_SMP.SP_PKG_DETAIL)) - PKG_SMP.SP_PKG_DETAIL - retrieves the SMP package's expiry parameters and number of services from the plan configuration.
    * **Step 1** - Accept the principal, fleet/vehicle category, service type, and selected package code.
    * **Step 2** - Query the SMP parameter configuration to retrieve the expiry month count, expiry mileage, and number of services allowed for the package.
    * **Step 3** - Return the expiry months, expiry mileage, number of services, and any error details.

**Step 3 - Service sub-range (from/to service number) determined**
The system determines which service number range the current enquiry covers, based on the vehicle's repair order history (last completed SMP service sub-category), the current mileage-based sub-category, and whether the vehicle is a True Value SMP. The starting and ending service numbers are derived from these inputs and the number of services in the package.

**Step 4 - SMP contract expiry date and mileage retrieved**
The system looks up the SMP plan's expiry date and maximum mileage for the vehicle, service type, and the derived ending sub-service, and populates the plan validity date, expiry month count, and expiry mileage on the enquiry.

*Procedures called:*
- **PKG_SMP.SP_GET_SMP_EXP** ([SP-020](#SP-020--PKG_SMP.SP_GET_SMP_EXP)) - PKG_SMP.SP_GET_SMP_EXP - retrieves the SMP contract's expiry age (months), expiry mileage, and validity-to date for the vehicle, service type, and service sub-range.
    * **Step 1** - Accept the principal, VIN, service type, and ending sub-service code.
    * **Step 2** - Retrieve the vehicle's invoice date and service variant from the vehicle master.
    * **Step 3** - Look up the applicable sub-service calendar to determine the maximum mileage and vehicle age allowed for the contract end point.
    * **Step 4** - Calculate the contract expiry date based on the invoice date and allowed vehicle age.
    * **Step 5** - Return the expiry age in months, expiry mileage, and validity-to date together with any error details.

**Step 5 - Default engine oil and coolant parts populated for full package option**
For package enquiries that include the parts option, the system determines and pre-fills the recommended engine oil part number and (for PMS service type) the coolant part number from the parts master based on the vehicle's service sub-range. The corresponding part descriptions are also displayed.

*Procedures called:*
- **PKG_SMP.SP_GET_DEFAULT_PART** ([SP-019](#SP-019--PKG_SMP.SP_GET_DEFAULT_PART)) - PKG_SMP.SP_GET_DEFAULT_PART - determines the recommended default part (engine oil or coolant) for the vehicle and service sub-range.
    * **Step 1** - Accept the principal, VIN, part group (engine oil or coolant), and the from/to sub-service range.
    * **Step 2** - Retrieve the vehicle's variant and service variant.
    * **Step 3** - Look up the applicable default part configuration for the vehicle variant, part group, and service sub-range, considering any coolant change date or old-coolant flag if relevant.
    * **Step 4** - Return the part group code, part number, and MRP for the default part.

**Step 6 - All pricing and discount fields cleared**
Following all package lookups, all previously entered labour, parts, consumable, discount, tax, sub-total, and add-on amount fields are cleared so the advisor can proceed to generate the full SMP package details with a clean pricing state.

#### Business Scenarios - How package code validation differs by vehicle SMP type and service option

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard SMP vehicle, parts option** | Engine oil and coolant (PMS only) defaults are determined using the standard from-subsrv to to-subsrv range. |
| **True Value SMP vehicle, parts option** | Engine oil and coolant defaults are determined using the True Value sub-service range (TV_FROM_SUBSRV to to-subsrv) rather than the standard range. |
| **Labour-only option** | Engine oil and coolant determination steps are skipped; only the service sub-range and expiry calculations run. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Applicable Package (`PKG_CODE`) | Mandatory | Text | N/A | SMP package master (VM_SMP_PACKAGE - via LV_PACKAGE) | Package code | Service type selected | Must not be blank | Error shown by mandatory check |
| Package Description (`PKG_DESC`) | Read-only display | Text | N/A | SMP package master (VM_SMP_PACKAGE) | Package description | Package code validated | System-set | N/A |
| Engine Oil (`ENGINE_OIL`) | Auto-populated | Text | N/A | Parts master (PM_PART - via LOV_ENGINEOIL) | Default engine oil part number | Parts option and package code validated | System-derived from service sub-range | N/A |
| Engine Oil Description (`ENGINE_OIL_DESC`) | Read-only display | Text | N/A | N/A | Engine oil part description | Engine oil part number set | System-set; "NA" if part not found | N/A |
| Coolant (`COOLANT`) | Auto-populated | Text | N/A | Parts master (PM_PART - via LOV_COOLANT) | Default coolant part number | PMS service type, parts option, package code validated | System-derived from service sub-range; set to "NA" if no coolant found | N/A |
| Coolant Description (`COOLANT_DESC`) | Read-only display | Text | N/A | N/A | Coolant part description | Coolant part number set | System-set; "NA" if part not found | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Generate SMP Package Details - Populate Labour, Parts, and Consumable Line Items

**Business Description:**
After the service advisor selects the service type and package, the "Generate SMP" action calls the backend to compute and load the complete list of individual labour operations, parts, and consumable items that make up the selected SMP package for this vehicle. For True Value SMP vehicles travelling under a specific sub-service category (TV3), a dedicated True Value package population routine is invoked; all other vehicles use the standard SMP package population routine. Once the package details are successfully loaded into the temporary staging area, the detail lines are displayed in the package detail grid. If the SMP details have not been generated yet, the action is blocked.

**Actors:** Service Advisor

**Preconditions:**
- The vehicle's registration number, mileage, service type, and package code have been entered and confirmed.
- SMP package details have been generated in the staging area (the internal SMP generation flag has been set to "generated").

**Main Flow:**

**Step 1 - SMP generation flag checked before proceeding**
The system verifies that the SMP package data has already been generated in the temporary working area. If not, the advisor sees an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP package data has been generated | Existence flag check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL; checks NB_MCP_GEN flag | When the advisor clicks the Generate SMP button | Prevents displaying or saving package detail lines when the underlying package data has not yet been computed | *"SMP details not found, Please generate and check details"* is shown; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - SMP generation flag is not set - *"SMP details not found, Please generate and check details"*; advisor must first initiate the SMP package generation step.

**Step 2 - Package code confirmed before proceeding**
The system ensures a package code is selected.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies the package code field is not blank.
    * **Step 1** - Receive the field value and the field's business label ("Applicable Package").
    * **Step 2** - If blank, display an error and stop.
    * **Step 3** - If present, return control to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Package code is not blank | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL | When the advisor clicks the Generate SMP button | Ensures a package has been selected before attempting to load its line items | Error shown by mandatory check; processing blocked |

**Step 3 - Save button disabled and SMP package line items populated**
The save button is disabled while the package population runs. The appropriate backend procedure is called to compute and insert all labour, parts, and consumable line items for the package into the temporary staging area, using the selected engine oil and coolant parts, GST type, service sub-range, and vehicle details. On success, the populated line items are loaded into the detail grid via the local display routine and the enquiry is marked as having been generated but not yet committed.

*Procedures called:*
- **PKG_SMP.SP_POP_SMP_PKG** ([SP-023](#SP-023--PKG_SMP.SP_POP_SMP_PKG)) - PKG_SMP.SP_POP_SMP_PKG - computes all labour, parts, and consumable line items for the selected SMP package and inserts them into the temporary staging table.
    * **Step 1** - Accept the principal, parent group, dealer, location, company, service type, package code, registration number, service sub-range, number of services, GST type, engine oil part number, and coolant part number.
    * **Step 2** - Retrieve the vehicle's service variant, model, variant, city category, and customer details.
    * **Step 3** - Compute the labour operations, parts, and consumables included in the package based on the service sub-range and vehicle profile; apply applicable MCP discount rates for each line.
    * **Step 4** - Insert all computed line items into the temporary staging table (GBL_AMC_DTL) with their quantities, rates, basic amounts, discounts, and net amounts.
    * **Step 5** - Return an error code and message if any step fails.
- **PKG_SMP.SP_POP_SMP_PKG_TV** ([SP-024](#SP-024--PKG_SMP.SP_POP_SMP_PKG_TV)) - PKG_SMP.SP_POP_SMP_PKG_TV - performs the same function as SP_POP_SMP_PKG but applies the True Value SMP pricing and sub-service logic specific to TV3 packages.
    * **Step 1** - Accept the same inputs as SP_POP_SMP_PKG with the addition of the True Value sub-service (TV_FROM_SUBSRV) and service count.
    * **Step 2** - Retrieve the vehicle's profile and apply the True Value-specific service sub-category and pricing rules.
    * **Step 3** - Insert all computed True Value SMP line items into the temporary staging table.
    * **Step 4** - Return an error code and message if any step fails.
- **POP_SMP_DETAILS** ([SP-007](#SP-007--POP_SMP_DETAILS)) - POP_SMP_DETAILS - reads the populated line items from the staging table and loads them into the on-screen detail grid, computing the summary totals for labour, parts, consumables, discounts, and package amounts.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Read all non-add-on line items from the staging table for the current registration and package, filtered by the selected service option.
    * **Step 3** - Populate each detail row in the grid with the service/part code, description, quantity, rate, basic amount, MCP discount amount and percentage, net amount, and dealer discount fields.
    * **Step 4** - Accumulate labour, parts, and consumable totals and write them to the summary fields on the header section.
    * **Step 5** - Read and display any add-on line items in the add-on detail section of the grid.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Package population procedure completed without error | Error code check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL; checks ln_err_cd returned by PKG_SMP.SP_POP_SMP_PKG or PKG_SMP.SP_POP_SMP_PKG_TV | When the Generate SMP button is clicked | Ensures the line-item data was computed and staged successfully before attempting to display it | Error message returned by the backend procedure is shown; processing is blocked |

#### Business Scenarios - How SMP package generation differs by vehicle type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Standard SMP vehicle** | PKG_SMP.SP_POP_SMP_PKG is called with the standard from-subsrv to to-subsrv range and the selected engine oil and coolant; all labour, parts, and consumable line items are populated for the standard package. |
| **True Value SMP vehicle (TV3 sub-service)** | PKG_SMP.SP_POP_SMP_PKG_TV is called instead, passing the TV-specific sub-service range (TV_FROM_SUBSRV) alongside the other package parameters; the True Value-specific pricing and service scope are applied. |

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 1) SMP generation flag is not set - *"SMP details not found, Please generate and check details"*; processing stops; advisor must perform the package generation step first.
- **BR-009-AF-02** - (from Step 3) Backend package population fails - the error message returned by the backend is shown; processing stops; the save button remains disabled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Applicable Package (`PKG_CODE`) | Mandatory | Text | N/A | SMP package master | Package code | Service type confirmed | Must be selected before generating SMP | Error shown by mandatory check |
| Service Description (`NB_SRV_DESC`) | Read-only display | Text | N/A | N/A | Labour/part description | Package generated | System-populated from staging table | N/A |
| Quantity (`QTY`) | Read-only display | Numeric | N/A | N/A | Item quantity | Package generated | System-populated | N/A |
| SMP Discount % (`DISCOUNT_PER`) | Read-only display | Numeric | N/A | N/A | MCP discount percentage | Package generated | System-populated | N/A |
| Rate (`RATE`) | Read-only display | Currency | N/A | N/A | Item rate | Package generated | System-populated | N/A |
| Basic Amount (`BASIC_AMT`) | Read-only display | Currency | N/A | N/A | Pre-discount line amount | Package generated | System-populated | N/A |
| After-MCP-Discount Total (`TOT_AFT_MCP_DISC`) | Read-only display | Currency | N/A | N/A | Net after MCP discount | Package generated | System-populated | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** TCS Section - Tax Collected at Source Applicability Selection

**Business Description:**
Before the SMP package tax calculation can be completed and the enquiry saved, the system requires the service advisor to confirm whether Tax Collected at Source (TCS) applies to the transaction. The TCS confirmation screen presents a radio button allowing the advisor to indicate that TCS does or does not apply. Depending on this selection, the applicable rate buttons (Normal Rate or Higher Rate) are enabled or disabled, and the final TCS application step is enabled or locked accordingly. This ensures that every high-value transaction is correctly classified for TCS compliance before the enquiry is finalised.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package has been generated and tax calculation has been initiated.
- The TCS confirmation screen is active.

**Main Flow:**

**Step 1 - TCS section displayed with controls set based on any prior TCS selection**
When the TCS section becomes active, the system checks whether a TCS applicability decision has already been recorded. If a prior decision is found, the Apply TCS button is enabled to allow the advisor to proceed with tax application.

*Screen: TCS (`CN_TCS`).*

**Step 2 - Advisor selects whether TCS applies or does not apply**
The advisor uses the TCS applicability radio button to make a selection. If the advisor selects "TCS applies", the system enables both the Normal Rate and Higher Rate buttons and disables the Apply TCS button until a specific rate is chosen. If the advisor selects "TCS does not apply", the system records TCS as not applicable, disables both rate buttons, disables the Apply TCS button, and stores the description "TCS Not Applied".

*Screen: TCS (`CN_TCS`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| TCS applicability decision is recorded based on advisor's radio button selection | State control - WHEN-RADIO-CHANGED on B_TCS.NB_TCS_APPL_YN; sets TCS_APPL_YN to null (TCS applies, rate not yet chosen) or to not-applicable | When the advisor changes the TCS applicability radio button | Ensures the TCS status is correctly recorded and the appropriate rate selection or bypass path is enabled | N/A - no blocking error; the advisor is guided to the next step by enabling or disabling the relevant buttons |

**Step 3 - Advisor selects the applicable TCS rate (when TCS applies)**
If the advisor indicated that TCS applies, they must select either the Normal Rate or the Higher Rate. Clicking the Normal Rate button records the TCS rate as normal and displays "Normal Rate Applied"; clicking the Higher Rate button records it as the higher rate and displays "Higher Rate Applied". In both cases the Apply TCS button is enabled for the advisor to proceed.

*Screen: TCS (`CN_TCS`).*

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 2) Advisor selects "TCS does not apply" - TCS applicability is set to not applicable, rate buttons are disabled, Apply TCS button is disabled, and "TCS Not Applied" is displayed; no rate selection is required.
- **BR-010-AF-02** - (from Step 2) TCS applicability had already been set in a prior session - Apply TCS button is already enabled when the TCS section is opened.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TCS Applicability (`NB_TCS_APPL_YN`) | Mandatory - must be selected before tax can be applied | Radio group | N/A | N/A | TCS applies / TCS does not apply | TCS section active | System controls rate buttons based on selection | N/A |
| TCS Description (`NBT_TCS_DESC`) | Read-only display | Text | N/A | N/A | "Normal Rate Applied" / "Higher Rate Applied" / "TCS Not Applied" | Rate selected or TCS not applicable | System-set only | N/A |
| TCS Applied Flag (`TCS_APPL_YN`) | Auto-populated | Text | N/A | N/A | TCS applied / higher rate / not applicable | TCS applicability decision made | System-set based on rate button selection | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Generate Enquiry - TCS Declaration, Tax Calculation, and Package Detail Display

**Business Description:**
After the advisor has assembled the package and set the TCS decision, clicking the "Generate Enquiry" button finalises the tax and TCS calculations for the package and prepares the line-item detail for review and saving. The system first synchronises any dealer discount values entered across the detail lines, then presents or processes the TCS statutory information alert (informing the advisor about the fifty-lakh threshold under section 206C(1H)) if a package code is not already set. It then calls the backend tax calculation routine to compute GST and TCS amounts, populates the package detail grid, and navigates to the package amount field. If the SMP package data has not yet been generated, the action is blocked.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package details have been generated.
- The TCS applicability decision has been made (either through the TCS screen or during this step).
- A package code is confirmed.

**Main Flow:**

**Step 1 - SMP generation status verified**
The system checks that the SMP package data has been generated. If not, the advisor is shown an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP package data has been generated | Generation flag check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; checks NB_MCP_GEN flag | When the advisor clicks the Generate Enquiry button | Prevents tax calculation from running on an enquiry that has not had its line items computed yet | *"SMP details not found, Please generate and check details"* is shown; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - SMP package data not generated - *"SMP details not found, Please generate and check details"*; advisor must first use the Generate SMP step.

**Step 2 - Dealer discount values synchronised across detail lines (new enquiry)**
For a new enquiry (no loaded enquiry number), the system loops through all detail lines currently displayed and pushes the dealer discount indicator, dealer discount value, dealer discount amount, and after-dealer-discount total from each displayed row back into the staging table so that the tax calculation uses the most current discount values.

**Step 3 - TCS information notice and applicability confirmation (when package code is set and no prior TCS decision via TCS screen)**
When a package code is already populated but TCS has not been determined through the dedicated TCS screen, the system displays an informational notice about the TCS statutory threshold (*"TCS under section 206C(1H) is applicable on receipt of consideration for sale of any goods of the value or aggregate of such value exceeding fifty lakh rupees in a previous year."*) and shows the TCS Declaration alert (AL_TCS). The advisor must acknowledge the declaration:
- If the advisor clicks the first button (accept/confirm), TCS applicability is set to applicable.
- If the advisor clicks the second button (decline/provide declaration), a further declaration confirmation alert (AL_TCS_DECR) is shown. If the advisor confirms the declaration on this second alert, TCS is set to not applicable. If the advisor cancels, TCS is set to applicable and the error *"TCS Declaration is required"* is shown, blocking further processing.
- If the advisor dismisses the initial alert without a clear choice, TCS is set to applicable and *"TCS Declaration is required"* is shown, blocking processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| TCS declaration completed before tax calculation proceeds | TCS alert handling - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; displays AL_TCS and AL_TCS_DECR alerts for TCS decision | When the advisor clicks Generate Enquiry and no prior TCS decision has been recorded via the TCS screen | Ensures that every high-value SMP transaction has a documented TCS applicability decision before the enquiry is finalised | *"TCS Declaration is required"* when the advisor does not provide a clear TCS decision; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-WS-01** - TCS statutory threshold notice displayed - *"TCS under section 206C(1H) is applicable on receipt of consideration for sale of any goods of the value or aggregate of such value exceeding fifty lakh rupees in a previous year."* - shown when TCS declaration step is triggered.
- **BR-011-ES-02** - TCS declaration not completed - *"TCS Declaration is required"*; advisor must complete the TCS declaration to proceed.

**Step 4 - Tax amounts calculated and package detail grid populated**
The system calls the tax calculation backend procedure to compute GST and TCS amounts for each line item in the staging table based on the package code, registration, GST type, dealer and customer states, and TCS applicability flag. If the calculation succeeds, the package detail grid is populated from the staging table and the enquiry is marked as ready for the tax step. If the calculation fails, the error message from the backend is shown.

*Procedures called:*
- **PKG_SMP.SP_POP_SMP_TAX** ([SP-025](#SP-025--PKG_SMP.SP_POP_SMP_TAX)) - PKG_SMP.SP_POP_SMP_TAX - computes GST and TCS amounts for all line items in the staging table for the enquiry and updates the charge amounts.
    * **Step 1** - Accept the principal, parent group, dealer, location, company, package code, registration number, GST type, dealer state, customer state, and TCS applicability flag.
    * **Step 2** - Retrieve the vehicle's service variant, the applicable tax codes for labour operations and parts, and the customer's GST registration number.
    * **Step 3** - For each line item in the staging table, calculate the applicable GST rate (CGST + SGST for intra-state, or IGST for inter-state) and, where TCS applies, add the TCS component to the charge amount.
    * **Step 4** - Update the charge amounts in the staging table with the computed tax and TCS values.
    * **Step 5** - Return an error code and message if any calculation step fails.
- **POP_PKG_DETAILS** ([SP-006](#SP-006--POP_PKG_DETAILS)) - POP_PKG_DETAILS - reads the fully computed line items from the staging table (including tax and charge amounts) and displays them in the on-screen package detail grid.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Retrieve all non-add-on line items from the staging table for the current registration and package, filtered by service option.
    * **Step 3** - Populate each grid row with the service/part code, description, quantity, rate, basic amount, MCP discount, dealer discount, net amount, and charge (tax) amount.
    * **Step 4** - Accumulate and display the summary totals for labour, parts, consumables, discounts, and package amount.
    * **Step 5** - Retrieve and display any add-on line items in the add-on section.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Tax calculation completed without error | Error code check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; checks ln_err_cd from PKG_SMP.SP_POP_SMP_TAX | When the Generate Enquiry button is clicked | Ensures all line items have valid, computed tax amounts before the advisor reviews the final totals | Error message returned by the tax calculation backend is shown; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-03** - Tax calculation backend returns an error - the error message from the backend is shown; processing is blocked.

#### Business Scenarios - How the Generate Enquiry flow differs by enquiry state

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **New enquiry, package code set, TCS not yet decided via TCS screen** | TCS notice and declaration alerts are shown; advisor must confirm TCS applicability before tax runs. |
| **New enquiry, package code not yet set** | GENERAL.CHECK_NULL fires on the package code field via a different code path; the Generate Enquiry step shows the same TCS flow but the package mandatory check runs. |
| **Existing enquiry loaded for review (NB_ENQ_NUM is populated)** | Dealer discount synchronisation step is skipped; TCS alert sequence and tax recalculation still run if the advisor triggers Generate Enquiry on a loaded enquiry. |

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 1) SMP data not generated - *"SMP details not found, Please generate and check details"*; blocked.
- **BR-011-AF-02** - (from Step 3) Advisor clicks the first alert button - TCS applicability confirmed; tax calculation proceeds.
- **BR-011-AF-03** - (from Step 3) Advisor declines initial alert and confirms the declaration on the second alert - TCS is set to not applicable; tax proceeds.
- **BR-011-AF-04** - (from Step 3) Advisor declines both alerts - *"TCS Declaration is required"*; processing is blocked.
- **BR-011-AF-05** - (from Step 4) Tax calculation fails - backend error shown; processing is blocked.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Package Amount (`PKG_AMT`) | Read-only display | Currency | N/A | N/A | Computed package total | Tax calculation complete | System-populated | N/A |
| Labour Amount (`LABOUR_AMT`) | Read-only display | Currency | N/A | N/A | Computed labour subtotal | Tax calculation complete | System-populated | N/A |
| Parts Amount (`PART_AMT`) | Read-only display | Currency | N/A | N/A | Computed parts subtotal | Tax calculation complete | System-populated | N/A |
| Consumable Amount (`CONSUMABLE_AMT`) | Read-only display | Currency | N/A | N/A | Computed consumables subtotal | Tax calculation complete | System-populated | N/A |
| Discount Amount (`DISCOUNT_AMT`) | Read-only display | Currency | N/A | N/A | Computed MCP discount total | Tax calculation complete | System-populated | N/A |
| Total Billing Amount (`TOT_BILL_AMT`) | Read-only display | Currency | N/A | N/A | Computed total billing amount | Tax calculation complete | System-populated | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** View Package Details - Display SMP Line Items in Detail Grid

**Business Description:**
After the SMP package has been generated, the service advisor can navigate to the detail view to review all line items associated with the selected package. If the SMP package data is available, the detail grid is populated from the staging area and the advisor is taken to the detail screen. If the data has not been generated, the advisor is informed and cannot proceed.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package details have been generated.

**Main Flow:**

**Step 1 - SMP generation status checked before loading detail view**
The system verifies that the SMP package data has been generated before attempting to display the detail lines.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| SMP package data exists before detail view is loaded | Generation flag check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_DTL; checks NB_MCP_GEN flag | When the advisor clicks the Details button | Prevents navigating to an empty detail grid when package data has not been computed | *"SMP details not found, Please generate and check details"* is shown; processing stops |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - SMP data not generated - *"SMP details not found, Please generate and check details"*; advisor must generate the SMP package first.

**Step 2 - Package details populated and advisor navigated to detail view**
The system calls the local detail-population routine to load all line items from the staging table into the detail grid for the current registration and package, then navigates the advisor to the package detail section.

*Procedures called:*
- **POP_PKG_DETAILS** ([SP-006](#SP-006--POP_PKG_DETAILS)) - POP_PKG_DETAILS - reads line items from the staging table and populates the on-screen package detail grid.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Retrieve all non-add-on line items from the staging table for the current registration and package, filtered by service option.
    * **Step 3** - Populate each grid row with the service/part code, description, quantity, rate, basic amount, MCP discount, dealer discount, net amount, and charge (tax) amount.
    * **Step 4** - Accumulate and display the summary totals for labour, parts, consumables, discounts, and package amount.
    * **Step 5** - Retrieve and display any add-on line items in the add-on section.

**Alternative Flows:**
- **BR-012-AF-01** - (from Step 1) SMP data not yet generated - *"SMP details not found, Please generate and check details"*; blocked.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service Type (`SRV_TYPE`) | Read-only display | Text | N/A | N/A | Labour/Parts/Consumable type code | Package generated | System-populated | N/A |
| Service Code (`SRV_CODE`) | Read-only display | Text | N/A | N/A | Operation or part code | Package generated | System-populated | N/A |
| Service Description (`NB_SRV_DESC`) | Read-only display | Text | N/A | N/A | Operation or part description | Package generated | System-populated | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Apply TCS and Finalise Tax Calculation - Enable Save Action

**Business Description:**
After the service advisor has selected the applicable TCS rate (Normal or Higher), clicking the "Apply TCS" button re-runs the full tax calculation, incorporating the chosen TCS rate, and refreshes the package detail grid with the updated tax and charge amounts. The Save action is also enabled at this point, allowing the advisor to commit the finalised enquiry to the database.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package details have been generated.
- A TCS rate (Normal or Higher) has been selected on the TCS screen.

**Main Flow:**

**Step 1 - Save button enabled and tax calculation with TCS re-executed**
The system enables the Save button and calls the backend tax calculation routine, passing the selected TCS applicability flag along with the package code, registration, GST type, and dealer/customer state information. If the calculation succeeds, the package detail grid is refreshed with the updated charge amounts and the enquiry is marked as having completed the tax step.

*Screen: TCS (`CN_TCS`).*

*Procedures called:*
- **PKG_SMP.SP_POP_SMP_TAX** ([SP-025](#SP-025--PKG_SMP.SP_POP_SMP_TAX)) - PKG_SMP.SP_POP_SMP_TAX - recomputes GST and TCS amounts for all line items in the staging table using the selected TCS rate.
    * **Step 1** - Accept the principal, parent group, dealer, location, company, package code, registration number, GST type, dealer state, customer state, and the confirmed TCS applicability flag.
    * **Step 2** - Retrieve the vehicle's service variant, applicable tax codes, and customer's GST registration number.
    * **Step 3** - For each line item, calculate GST (intra-state or inter-state) and, where TCS applies at the selected rate, add the TCS component to the charge amount.
    * **Step 4** - Update the charge amounts in the staging table with the computed values.
    * **Step 5** - Return an error code and message if any calculation step fails.
- **POP_PKG_DETAILS** ([SP-006](#SP-006--POP_PKG_DETAILS)) - POP_PKG_DETAILS - reads the recomputed line items from the staging table and refreshes the on-screen package detail grid.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Retrieve all line items from the staging table for the current registration and package, filtered by service option.
    * **Step 3** - Populate each grid row with updated service/part codes, descriptions, quantities, rates, basic amounts, discounts, net amounts, and charge (tax) amounts.
    * **Step 4** - Update the summary totals for labour, parts, consumables, discounts, and package amount.
    * **Step 5** - Retrieve and refresh any add-on line items.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Tax calculation with TCS completed without error | Error code check - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_TCS_APPLY; checks ln_err_cd from PKG_SMP.SP_POP_SMP_TAX | When the advisor clicks the Apply TCS button | Ensures the final charge amounts are correctly computed before the Save action is enabled | Error message returned by the backend is shown; processing is blocked and Save remains disabled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - Tax calculation with TCS returns an error - error message from backend is shown; processing is blocked; Save button remains disabled.

**Alternative Flows:**
- **BR-013-AF-01** - (from Step 1) Tax calculation fails - error shown; Save button is not activated; advisor must resolve the issue.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TCS Applied Flag (`TCS_APPL_YN`) | Auto-populated | Text | N/A | N/A | TCS applicable / higher rate / not applicable | TCS rate selected | System-set from rate button selection | N/A |
| Package Amount (`PKG_AMT`) | Read-only display | Currency | N/A | N/A | Recomputed package total including TCS | TCS calculation complete | System-populated | N/A |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Navigate to Add-On Services - Display Add-On Selection Screen

**Business Description:**
The service advisor can add optional add-on services to the SMP enquiry before finalising it. Clicking the "Add-On" button first verifies that a package has been selected, then resets any previously computed tax amounts so they will be recalculated after add-ons are applied, disables the Save button (to prevent saving before the add-ons are processed), and navigates the advisor to the add-on selection screen where available add-on services for the vehicle are listed.

**Actors:** Service Advisor

**Preconditions:**
- A package code has been selected.
- The form is in new-enquiry mode (no existing enquiry number loaded for review).

**Main Flow:**

**Step 1 - Package code confirmed before navigating to add-on screen**
The system checks that a package code is selected before allowing the add-on screen to be opened.

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-010](#SP-010--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL - verifies the package code field is not blank.
    * **Step 1** - Receive the field value and the field's business label ("Applicable Package").
    * **Step 2** - If blank, display an error and stop.
    * **Step 3** - If present, return control to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Package code is not blank | Mandatory check - GENERAL.CHECK_NULL [SP-010]; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_ADDON | When the advisor clicks the Add-On button | Ensures a package is selected before add-on services can be associated with it | Error shown by mandatory check; navigation is blocked |

**Step 2 - Tax amounts reset and add-on screen opened**
The system resets the tax summary fields (total tax, labour tax, parts tax, consumables tax) to zero and sets the tax-complete flag to indicate that tax must be recalculated after add-ons are processed. The Save button is disabled. The advisor is navigated to the first record on the add-on selection screen where available add-on services are listed.

*Screen: Addon Details (`CN_ADDON`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Applicable Package (`PKG_CODE`) | Mandatory | Text | N/A | SMP package master | Package code | Service type confirmed | Must be selected before navigating to add-ons | Error shown by mandatory check |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Add-On Services Screen - Load Available Add-Ons and Handle Add-On Selection

**Business Description:**
When the add-on selection screen opens, the system loads all available add-on services defined for the principal and displays them in the list for the advisor to select. Each add-on row shows a checkbox. When the advisor ticks an add-on's checkbox to include it in the enquiry, the system calls the backend to populate the add-on's line items (labour, parts, consumables) into the staging area and loads them into the add-on detail grid below. If the advisor unticks the checkbox, the corresponding add-on's staging records are removed from the detail. This allows the advisor to include one or more optional services alongside the core SMP package.

**Actors:** Service Advisor

**Preconditions:**
- The add-on screen has been opened from the main enquiry screen after a package has been selected.

**Main Flow:**

**Step 1 - Available add-on services loaded into the list**
When the add-on screen becomes active, the system queries the add-on service master for all active add-on services defined for the principal and populates the add-on selection list. Each row displays the add-on code, description, and a checkbox.

*Screen: Addon Details (`CN_ADDON`).*

**Step 2 - Advisor selects or deselects an add-on service**
The advisor ticks the checkbox next to an add-on service to include it. When the checkbox is ticked, the system calls the backend add-on population routine to compute and stage the add-on's line items. These are then loaded into the add-on detail grid and the add-on's basic amount, discount amount, and net total are displayed on the add-on row. When the checkbox is unticked, the system removes the corresponding staging records (both the add-on staging entry and the associated detail records) and refreshes the add-on detail display by clearing those rows.

*Screen: Addon Details (`CN_ADDON`).*

*Procedures called:*
- **PKG_SMP.SP_POP_SMP_ADDON** ([SP-022](#SP-022--PKG_SMP.SP_POP_SMP_ADDON)) - PKG_SMP.SP_POP_SMP_ADDON - computes and inserts the add-on service's line items into the staging table.
    * **Step 1** - Accept the principal, parent group, dealer, location, company, service type, package code, registration number, service sub-range, number of services, and GST type.
    * **Step 2** - Retrieve the vehicle's service variant, model, variant, city category, and customer details.
    * **Step 3** - Compute the labour operations, parts, and consumables included in the add-on service based on the sub-service range and vehicle profile; apply applicable MCP discount rates.
    * **Step 4** - Insert all add-on line items into the staging table with their quantities, rates, basic amounts, discounts, and net amounts, flagged with the add-on type.
    * **Step 5** - Return an error code and message if any step fails.
- **POP_ADDON_DETAILS** ([SP-002](#SP-002--POP_ADDON_DETAILS)) - POP_ADDON_DETAILS - reads the add-on line items from the staging table and loads them into the add-on detail grid.
    * **Step 1** - Clear the add-on detail section of the on-screen grid.
    * **Step 2** - Query the staging table for all line items that are linked to an add-on service in the add-on staging master for the current registration and package.
    * **Step 3** - Populate each add-on detail row with the service type, code, description, quantity, rate, basic amount, discount, and net amount.
    * **Step 4** - Update the add-on summary amounts (labour, parts, consumables, and total add-on amount) on the add-on row.

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 2) Add-on checkbox is unticked after being previously selected - staging records for that add-on are deleted from both the add-on staging master and the detail table, and the add-on detail section is cleared.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Add-On Code (`ADDON_CODE`) | Read-only display | Text | N/A | Add-on service master (AM_LIST - SMP_ADDON) | Add-on service code | Add-on screen open | System-populated; not user-editable | N/A |
| Description (`ADDON_DESC`) | Read-only display | Text | N/A | N/A | Add-on service description | Add-on screen open | System-populated | N/A |
| Include Add-On (`ADDON_YN`) | Optional | Checkbox | N/A | N/A | Selected / not selected | Add-on screen open | Advisor ticks to include; untick removes it | N/A |
| Basic Amount (`BASIC_AMT_ADDON`) | Read-only display | Currency | N/A | N/A | Add-on basic amount | Add-on selected | System-populated from staging | N/A |
| Discount Amount (`DISCOUNT_AMT_ADDON`) | Read-only display | Currency | N/A | N/A | Add-on MCP discount amount | Add-on selected | System-populated from staging | N/A |
| After-MCP-Discount Total (`TOT_AFT_MCP_DISC_ADDON`) | Read-only display | Currency | N/A | N/A | Add-on net after MCP discount | Add-on selected | System-populated from staging | N/A |

---

---

#### Requirement ID: BR-016

**Requirement Title:** Add-On Quantity Entry - Validate Quantity and Retrieve Default from Master

**Business Description:**
When the service advisor enters a quantity for an add-on service, the system validates that the quantity is greater than zero. If the quantity is zero or negative, the system issues a warning and automatically resets the quantity to the default value defined in the add-on master (the add-on's SFDC identifier, where configured). If no default is found, the quantity is reset to 1. After the quantity is confirmed as valid, the system checks that the quantity falls within the allowed minimum and maximum service range for the add-on and vehicle.

**Actors:** Service Advisor

**Preconditions:**
- The add-on selection screen is active and at least one add-on has been selected.

**Main Flow:**

**Step 1 - Quantity validated as greater than zero**
The system checks that the entered quantity is greater than zero. If it is zero or negative, a warning is shown and the quantity is reset to the default value from the master (or 1 if no default is found).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Add-on quantity is greater than zero | Range check - WHEN-VALIDATE-ITEM on B_ADDON.ADDON_CNT; checks ADDON_CNT > 0 | When the advisor navigates away from the quantity field on the add-on row | Prevents an add-on service from being included with a zero or negative quantity | *"Add-On Quantity Can't be Negative or Zero"* warning is shown; quantity is automatically reset to the default value from the add-on master, or to 1 if no default exists |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-WS-01** - Quantity is zero or negative - *"Add-On Quantity Can't be Negative or Zero"*; quantity is automatically corrected.

**Step 2 - Quantity range validated against add-on service limits**
Once a valid quantity (greater than zero) has been confirmed, the system checks whether the quantity is within the minimum and maximum allowed service range configured for the add-on and vehicle. If the quantity is outside the allowed range, a warning is displayed and the quantity is adjusted to the appropriate limit.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quantity within allowed service range for add-on | Range check - WHEN-VALIDATE-ITEM on B_ADDON.ADDON_CNT; queries AM_LIST_RANGE for min/max service limits | After the quantity is confirmed as positive | Ensures the add-on quantity is within the contractually allowed range for the vehicle and service | Warning shown; quantity is adjusted to the allowed minimum or maximum as appropriate |

**Alternative Flows:**
- **BR-016-AF-01** - (from Step 1) Default quantity exists in the add-on master (SFDC identifier) - the quantity is reset to that value; no further action required by the advisor.
- **BR-016-AF-02** - (from Step 1) No default exists in the master - quantity is reset to 1.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quantity (`ADDON_CNT`) | Mandatory | Numeric | N/A | Add-on service master (AM_LIST - SMP_ADDON for default; AM_LIST_RANGE for range limits) | Default quantity (SFDC ID) or 1 | Add-on selected | Must be greater than zero; must be within allowed min/max service range | *"Add-On Quantity Can't be Negative or Zero"* - quantity auto-corrected |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Add-On Dealer Discount Entry - Validate Discount Indicator and Amount

**Business Description:**
When the service advisor enters a dealer discount value for an add-on service line, the system validates that a discount type indicator has been selected first, that any percentage discount does not exceed 100%, and that any percentage does not go negative. If the indicator is missing or the value is out of range, processing is blocked and the advisor is informed. When the discount indicator is changed, any previously entered discount value is automatically cleared to prevent mismatched data.

**Actors:** Service Advisor

**Preconditions:**
- The add-on selection screen is active and an add-on service is being configured.

**Main Flow:**

**Step 1 - Discount indicator validated before discount value accepted**
If the advisor enters a discount value without first selecting a discount type indicator, the system blocks the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Discount indicator selected before entering a discount value | Pre-requisite check - WHEN-VALIDATE-ITEM on B_ADDON.DLR_DISC; checks DLR_DISC_IND is not null when DLR_DISC is not null | When the advisor navigates away from the add-on discount field | Ensures the system knows whether the discount is a percentage or a flat amount before accepting the value | *"Please select Discount Indicator before selecting Disc Value"* is shown; processing is blocked |
| Discount percentage does not exceed 100% | Range check - WHEN-VALIDATE-ITEM on B_ADDON.DLR_DISC; checks DLR_DISC ≤ 100 when indicator is percentage | When the advisor navigates away from the add-on discount field | Prevents an economically invalid discount that would exceed the full item price | *"Discount Percentage Can't be greater than 100%"* is shown; processing is blocked |
| Discount percentage is not negative | Range check - WHEN-VALIDATE-ITEM on B_ADDON.DLR_DISC; checks DLR_DISC ≥ 0 | When the advisor navigates away from the add-on discount field | Prevents a negative discount that would increase the price instead of reducing it | *"Discount Percentage Can't be negative"* is shown; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-017-ES-01** - Discount value entered without selecting indicator first - *"Please select Discount Indicator before selecting Disc Value"*; processing is blocked.
- **BR-017-ES-02** - Discount percentage exceeds 100% - *"Discount Percentage Can't be greater than 100%"*; processing is blocked.
- **BR-017-ES-03** - Discount percentage is negative - *"Discount Percentage Can't be negative"*; processing is blocked.

**Step 2 - Discount value cleared when indicator is changed**
If the advisor changes the discount type indicator after having already entered a discount value, the discount value field is automatically cleared so the advisor must re-enter an appropriate value for the new indicator.

*Screen: Addon Details (`CN_ADDON`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dlr Disc Ind (`DLR_DISC_IND`) | Conditional - mandatory before entering a discount value | List | N/A | N/A | Percentage / Amount indicator | Add-on selected | Must be selected before a discount value is entered | *"Please select Discount Indicator before selecting Disc Value"* |
| Dlr Disc (`DLR_DISC`) | Optional | Numeric | N/A | N/A | N/A | Discount indicator selected | Must not exceed 100 (for percentage indicator); must not be negative | *"Discount Percentage Can't be greater than 100%"*; *"Discount Percentage Can't be negative"* |

---

---

#### Requirement ID: BR-018

**Requirement Title:** Package Detail Line Dealer Discount Entry - Validate Discount Indicator and Amount

**Business Description:**
In the package detail grid, the service advisor may enter a dealer discount for individual service or parts lines. The system validates that a discount type indicator has been selected before a discount value is entered, that any percentage discount does not exceed 100%, and that the percentage is not negative. When the discount indicator is changed, any previously entered discount value and its derived amounts are cleared. For a loaded existing enquiry (opened by enquiry number), the dealer discount fields on the detail lines are disabled.

**Actors:** Service Advisor

**Preconditions:**
- The package detail grid is visible with line items loaded.
- The form is in new-enquiry mode (dealer discount fields are enabled for a new enquiry).

**Main Flow:**

**Step 1 - Detail grid dealer discount field access controlled by enquiry mode**
When the package detail section is entered, the system enables or disables the dealer discount indicator and value fields based on whether a new enquiry is being created or an existing one is being reviewed.

*Screen: Details (`CN_DEF`).*

**Step 2 - Discount indicator selected before discount value is accepted**
If the advisor enters a discount value on a detail line without first selecting the discount type, the system blocks the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Discount indicator selected before discount value for a detail line | Pre-requisite check - WHEN-VALIDATE-ITEM on B_VD_AMC_ENQ.DLR_DISC; checks DLR_DISC_IND is not null when DLR_DISC is not null | When the advisor navigates away from a detail line's dealer discount field | Ensures the system knows the discount type before accepting the value | *"Please select Discount Indicator before selecting Disc Value"* is shown; processing is blocked |
| Discount percentage ≤ 100% | Range check - WHEN-VALIDATE-ITEM on B_VD_AMC_ENQ.DLR_DISC; checks DLR_DISC ≤ 100 for percentage indicator | When the advisor navigates away from the detail discount field | Prevents an invalid over-100% discount | *"Discount Percentage Can't be greater than 100%"* is shown; processing is blocked |
| Discount percentage not negative | Range check - WHEN-VALIDATE-ITEM on B_VD_AMC_ENQ.DLR_DISC; checks DLR_DISC ≥ 0 | When the advisor navigates away from the detail discount field | Prevents a price-increasing negative discount | *"Discount Percentage Can't be negative"* is shown; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-01** - Discount value entered without selecting indicator - *"Please select Discount Indicator before selecting Disc Value"*; processing is blocked.
- **BR-018-ES-02** - Percentage discount exceeds 100% - *"Discount Percentage Can't be greater than 100%"*; processing is blocked.
- **BR-018-ES-03** - Percentage discount is negative - *"Discount Percentage Can't be negative"*; processing is blocked.

**Step 3 - Discount value cleared when discount indicator is changed**
When the advisor changes the discount type indicator on a detail line, the discount value, discount amount, and after-dealer-discount total for that line are cleared automatically.

*Screen: Details (`CN_DEF`).*

**Alternative Flows:**
- **BR-018-AF-01** - (from Step 1) Enquiry is loaded for review via enquiry number - dealer discount indicator and value fields on all detail lines are disabled; discount entry is not permitted.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dlr Disc Ind (`DLR_DISC_IND`) | Conditional - mandatory before entering a discount | List | N/A | N/A | Percentage / Amount indicator | Detail lines loaded; new enquiry mode | Must be selected before discount value | *"Please select Discount Indicator before selecting Disc Value"* |
| Dlr Disc (`DLR_DISC`) | Optional | Numeric | N/A | N/A | N/A | Discount indicator selected | Must not exceed 100 (percentage); must not be negative | *"Discount Percentage Can't be greater than 100%"*; *"Discount Percentage Can't be negative"* |
| After-MCP-Discount Total (`TOT_AFT_MCP_DISC`) | Read-only display | Currency | N/A | N/A | Pre-dealer-discount net amount | Package generated | System-populated | N/A |
| After-Dealer-Discount Total (`TOT_AFT_DLR_DISC`) | Read-only display | Currency | N/A | N/A | Net after dealer discount | Dealer discount confirmed | System-populated | N/A |

---

---

#### Requirement ID: BR-019

**Requirement Title:** Header Dealer Discount Entry - Validate Labour, Parts, and Consumable Discount Indicators and Amounts

**Business Description:**
The service advisor may enter aggregate dealer discount values at the enquiry header level for three service categories: labour, parts, and consumables. For each category, the system validates that a discount type indicator has been selected first, that the entered discount value does not exceed the applicable maximum (100% for a percentage discount, or the total category amount for a flat-amount discount), and that the value is not negative. When the indicator is changed, the corresponding discount value is automatically cleared.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package has been generated and the package details are displayed.
- The form is in new-enquiry mode.

**Main Flow:**

**Step 1 - Labour discount validated**
When the advisor enters a labour discount value, the system checks that the labour discount indicator has been selected, the value does not exceed 100% (for percentage indicator), the value does not exceed the total labour amount times the labour count (for flat-amount indicator), and the value is not negative.

*Screen: Details (`CN_DEF`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Labour discount indicator selected before value | Pre-requisite check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_LAB_DISC; checks LAB_DISC_IND not null when DLR_LAB_DISC not null | When the advisor navigates away from the labour discount field | Ensures labour discount type is defined before the value is accepted | *"Please select Labour Discount Indicator before selecting Disc Value"* |
| Labour percentage ≤ 100% | Range check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_LAB_DISC; percentage indicator path | When the advisor navigates away from the labour discount field | Prevents a logically invalid over-100% labour discount | *"Labour Discount Percentage Can't be greater than 100%"* |
| Labour flat amount ≤ total labour amount | Amount cap check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_LAB_DISC; amount indicator path; compares to NB_LBR_AMT × NB_LBR_CNT | When the advisor navigates away from the labour discount field | Prevents a flat labour discount that exceeds the total labour cost | *"Labour Discount Amount Can't be greater than [total labour amount]"* - the actual computed amount is appended |
| Labour discount not negative | Non-negative check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_LAB_DISC | When the advisor navigates away from the labour discount field | Prevents a negative discount that would increase the price | *"Labour Discount Can't be negative"* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-01** - Labour discount indicator not selected - *"Please select Labour Discount Indicator before selecting Disc Value"*; blocked.
- **BR-019-ES-02** - Labour percentage exceeds 100% - *"Labour Discount Percentage Can't be greater than 100%"*; blocked.
- **BR-019-ES-03** - Labour flat-amount discount exceeds total labour - *"Labour Discount Amount Can't be greater than [computed total labour amount]"*; blocked.

**Step 2 - Parts discount validated**
When the advisor enters a parts discount value, the system applies the same indicator, percentage cap, flat-amount cap (against total parts amount times parts count), and non-negative checks for the parts category.

*Screen: Details (`CN_DEF`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Parts discount indicator selected before value | Pre-requisite check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_PART_DISC; checks PART_DISC_IND not null when DLR_PART_DISC not null | When the advisor navigates away from the parts discount field | Ensures parts discount type is defined | *"Please select Part Discount Indicator before selecting Disc Value"* |
| Parts percentage ≤ 100% | Range check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_PART_DISC; percentage path | When the advisor navigates away from the parts discount field | Prevents over-100% parts discount | *"Part Discount Percentage Can't be greater than 100%"* |
| Parts flat amount ≤ total parts amount | Amount cap - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_PART_DISC; compares to NB_PART_AMT × NB_PART_CNT | When the advisor navigates away | Prevents flat parts discount exceeding total parts cost | *"Part Discount Amount Can't be greater than [computed total parts amount]"* |
| Parts discount not negative | Non-negative - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_PART_DISC | When the advisor navigates away | Prevents price-increasing negative discount | *"Part Discount Can't be negative"* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-04** - Parts discount indicator not selected - *"Please select Part Discount Indicator before selecting Disc Value"*; blocked.
- **BR-019-ES-05** - Parts percentage exceeds 100% - *"Part Discount Percentage Can't be greater than 100%"*; blocked.
- **BR-019-ES-06** - Parts flat amount exceeds total parts - *"Part Discount Amount Can't be greater than [computed total parts amount]"*; blocked.

**Step 3 - Consumable discount validated**
When the advisor enters a consumables discount value, the same checks apply for the consumables category.

*Screen: Details (`CN_DEF`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consumable discount indicator selected before value | Pre-requisite check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_CONS_DISC; checks CONS_DISC_IND not null when DLR_CONS_DISC not null | When the advisor navigates away from the consumable discount field | Ensures consumable discount type is defined | *"Please select Consumable Discount Indicator before selecting Disc Value"* |
| Consumable percentage ≤ 100% | Range check - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_CONS_DISC; percentage path | When the advisor navigates away | Prevents over-100% consumable discount | *"Consumable Discount Percentage Can't be greater than 100%"* |
| Consumable flat amount ≤ total consumables | Amount cap - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_CONS_DISC; compares to NB_CONS_AMT × NB_CONS_CNT | When the advisor navigates away | Prevents flat consumable discount exceeding total consumable cost | *"Consumable Discount Amount Can't be greater than [computed total consumable amount]"* |
| Consumable discount not negative | Non-negative - WHEN-VALIDATE-ITEM on CB_VT_AMC_ENQ.DLR_CONS_DISC | When the advisor navigates away | Prevents negative consumable discount | *"Consumable Discount Can't be negative"* |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-ES-07** - Consumable discount indicator not selected - *"Please select Consumable Discount Indicator before selecting Disc Value"*; blocked.
- **BR-019-ES-08** - Consumable percentage exceeds 100% - *"Consumable Discount Percentage Can't be greater than 100%"*; blocked.
- **BR-019-ES-09** - Consumable flat amount exceeds total consumables - *"Consumable Discount Amount Can't be greater than [computed total consumable amount]"*; blocked.

**Step 4 - Discount indicator change clears the corresponding discount value**
When the advisor changes any of the three discount type indicators (labour, parts, or consumables), the corresponding discount value field is automatically cleared.

*Screen: Details (`CN_DEF`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Lab Disc Ind (`LAB_DISC_IND`) | Conditional - mandatory before entering labour discount | List | N/A | N/A | Percentage / Amount | Package generated | Must be selected first | *"Please select Labour Discount Indicator before selecting Disc Value"* |
| Dlr Lab Disc (`DLR_LAB_DISC`) | Optional | Numeric | N/A | N/A | N/A | Labour discount indicator selected | Must not exceed 100% or total labour; must not be negative | Multiple - see Business outcomes |
| Part Disc Ind (`PART_DISC_IND`) | Conditional - mandatory before entering parts discount | List | N/A | N/A | Percentage / Amount | Package generated | Must be selected first | *"Please select Part Discount Indicator before selecting Disc Value"* |
| Dlr Part Disc (`DLR_PART_DISC`) | Optional | Numeric | N/A | N/A | N/A | Parts discount indicator selected | Must not exceed 100% or total parts; must not be negative | Multiple - see Business outcomes |
| Cons Disc Ind (`CONS_DISC_IND`) | Conditional - mandatory before entering consumable discount | List | N/A | N/A | Percentage / Amount | Package generated | Must be selected first | *"Please select Consumable Discount Indicator before selecting Disc Value"* |
| Dlr Cons Disc (`DLR_CONS_DISC`) | Optional | Numeric | N/A | N/A | N/A | Consumable discount indicator selected | Must not exceed 100% or total consumables; must not be negative | Multiple - see Business outcomes |

---

---

#### Requirement ID: BR-020

**Requirement Title:** Calculate and Apply Dealer Discounts - Update Staging Table and Refresh Detail View

**Business Description:**
After the service advisor enters dealer discount values for labour, parts, and consumables at the header level, clicking the "Calculate Discount" button validates all three discount entries and, if they are all valid, writes the dealer discount values into the staging table for every applicable line item and then refreshes the detail grid to show the updated after-dealer-discount amounts. This action is only available when creating a new enquiry; it is not available when reviewing an existing enquiry.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package has been generated and line items are displayed.
- The form is in new-enquiry mode.
- At least one dealer discount value has been entered.

**Main Flow:**

**Step 1 - All three discount entries validated before writing to staging**
The system re-validates all entered discount values for labour, parts, and consumables (indicator present, percentage ≤ 100%, flat amount ≤ category total, non-negative) before writing anything to the staging table. The same validation rules as those applied in BR-019 apply here.

*Screen: Details (`CN_DEF`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Labour discount entries valid | Same rules as BR-019 Step 1 - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC; re-runs all labour discount checks | When the advisor clicks Calculate Discount | Prevents writing invalid discount values to the staging table | Corresponding error shown; processing is blocked |
| Parts discount entries valid | Same rules as BR-019 Step 2 - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC | When the advisor clicks Calculate Discount | Prevents writing invalid parts discount values | Corresponding error shown; processing is blocked |
| Consumable discount entries valid | Same rules as BR-019 Step 3 - WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC | When the advisor clicks Calculate Discount | Prevents writing invalid consumable discount values | Corresponding error shown; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-020-ES-01** - Labour discount indicator missing or value out of range - same error messages as BR-019 labour validations.
- **BR-020-ES-02** - Parts discount indicator missing or value out of range - same error messages as BR-019 parts validations.
- **BR-020-ES-03** - Consumable discount indicator missing or value out of range - same error messages as BR-019 consumable validations.

**Step 2 - Dealer discount values written to the staging table**
If all validation passes, the system iterates through all staging table entries for the current registration and package, applies the appropriate dealer discount (labour indicator and value for labour lines, parts indicator and value for parts lines, consumable indicator and value for consumable lines), calculates the dealer discount amount and after-dealer-discount total for each line, and writes these back to the staging table.

*Procedures called:*
- **POP_DISC** ([SP-004](#SP-004--POP_DISC)) - POP_DISC - writes the dealer discount indicator, value, discount amount, and after-dealer-discount total for each staging table line item based on the header-level discount entries.
    * **Step 1** - Identify all line items in the staging table for the current registration, package, and location.
    * **Step 2** - For each line item, determine which discount indicator and value applies (labour, parts, or consumables) based on the line's service type.
    * **Step 3** - Calculate the dealer discount amount and the resulting after-dealer-discount total for each line.
    * **Step 4** - Update the staging table with the computed discount indicator, discount amount, and after-dealer-discount total for each affected line.

**Step 3 - Detail grid refreshed with updated after-dealer-discount amounts**
After the staging table is updated, the detail grid is refreshed to show the new dealer discount amounts and after-dealer-discount totals for each line item, and the summary totals on the header section are updated.

*Procedures called:*
- **POP_DETAILS_AFT_DISC** ([SP-003](#SP-003--POP_DETAILS_AFT_DISC)) - POP_DETAILS_AFT_DISC - reloads the detail grid from the staging table, incorporating the newly computed dealer discount amounts for all line items.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Read all non-add-on line items from the staging table with updated dealer discount and after-dealer-discount values.
    * **Step 3** - Populate the detail grid rows with the updated amounts.
    * **Step 4** - Accumulate and update the summary totals for labour, parts, consumables, discounts, and package amount.
    * **Step 5** - Read and refresh any add-on line items in the add-on detail section.

**Alternative Flows:**
- **BR-020-AF-01** - (from Step 1) Any discount validation fails - the corresponding error message is shown; nothing is written to the staging table; the advisor must correct the invalid entry.
- **BR-020-AF-02** - (from Main Flow) The enquiry number field contains a loaded enquiry - the entire Calculate Discount action is skipped; the button does not execute for existing enquiries.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Lab Disc Ind (`LAB_DISC_IND`) | Conditional | List | N/A | N/A | Percentage / Amount | Package generated | Validated same as BR-019 | Multiple - see BR-020-ES-01 |
| Dlr Lab Disc (`DLR_LAB_DISC`) | Optional | Numeric | N/A | N/A | N/A | Labour indicator selected | Validated same as BR-019 | Multiple - see BR-020-ES-01 |
| Part Disc Ind (`PART_DISC_IND`) | Conditional | List | N/A | N/A | Percentage / Amount | Package generated | Validated same as BR-019 | Multiple - see BR-020-ES-02 |
| Dlr Part Disc (`DLR_PART_DISC`) | Optional | Numeric | N/A | N/A | N/A | Parts indicator selected | Validated same as BR-019 | Multiple - see BR-020-ES-02 |
| Cons Disc Ind (`CONS_DISC_IND`) | Conditional | List | N/A | N/A | Percentage / Amount | Package generated | Validated same as BR-019 | Multiple - see BR-020-ES-03 |
| Dlr Cons Disc (`DLR_CONS_DISC`) | Optional | Numeric | N/A | N/A | N/A | Consumable indicator selected | Validated same as BR-019 | Multiple - see BR-020-ES-03 |

---

---

#### Requirement ID: BR-021

**Requirement Title:** Clear Dealer Discounts - Reset Discount Fields and Refresh Detail View

**Business Description:**
The service advisor can reset all dealer discount fields at the header level (for labour, parts, and consumables) back to their default state by clicking the "Clear Discount" button. This removes any discount values entered and resets the discount indicators to percentage type, clears the staging table of all dealer discount values, and refreshes the detail grid so all line items show zero dealer discount. This action is only available when creating a new enquiry.

**Actors:** Service Advisor

**Preconditions:**
- The SMP package has been generated.
- The form is in new-enquiry mode.

**Main Flow:**

**Step 1 - Discount fields reset to default state and staging table updated**
The system resets all three header-level discount indicators to percentage type and clears all three discount value fields. It then iterates through the staging table and removes all dealer discount values from each line item, setting the discount indicator, discount amount, and after-dealer-discount total back to their zero/null state.

*Procedures called:*
- **POP_DISC_CLEAR** ([SP-005](#SP-005--POP_DISC_CLEAR)) - POP_DISC_CLEAR - resets all dealer discount fields on the screen and clears all dealer discount values from the staging table line items.
    * **Step 1** - Reset the header-level labour, parts, and consumable discount indicators to the percentage type and clear the corresponding discount value fields.
    * **Step 2** - Iterate through all staging table line items for the current registration and package.
    * **Step 3** - For each line item, set the dealer discount indicator, discount amount, and after-dealer-discount total back to their cleared/zero state.
    * **Step 4** - Update the staging table with the cleared values.

**Step 2 - Detail grid refreshed to reflect cleared discounts**
After the staging table is cleared, the detail grid is refreshed to show that all dealer discount amounts are now zero.

*Procedures called:*
- **POP_DETAILS_AFT_DISC** ([SP-003](#SP-003--POP_DETAILS_AFT_DISC)) - POP_DETAILS_AFT_DISC - reloads the detail grid from the staging table with cleared dealer discount values.
    * **Step 1** - Clear the on-screen detail grid.
    * **Step 2** - Read all line items from the staging table with their now-cleared dealer discount fields.
    * **Step 3** - Populate the grid rows with the updated (zero-discount) amounts.
    * **Step 4** - Update the summary totals to reflect the cleared discounts.
    * **Step 5** - Refresh any add-on line items.

**Alternative Flows:**
- **BR-021-AF-01** - (from Main Flow) The enquiry number field contains a loaded enquiry - the Clear Discount action is skipped; the button does not execute for existing enquiries.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Lab Disc Ind (`LAB_DISC_IND`) | Auto-populated on clear | List | N/A | N/A | Reset to percentage indicator | Package generated; new enquiry | System-reset | N/A |
| Dlr Lab Disc (`DLR_LAB_DISC`) | Auto-populated on clear | Numeric | N/A | N/A | Cleared to null | Package generated; new enquiry | System-cleared | N/A |
| Part Disc Ind (`PART_DISC_IND`) | Auto-populated on clear | List | N/A | N/A | Reset to percentage indicator | Package generated; new enquiry | System-reset | N/A |
| Dlr Part Disc (`DLR_PART_DISC`) | Auto-populated on clear | Numeric | N/A | N/A | Cleared to null | Package generated; new enquiry | System-cleared | N/A |
| Cons Disc Ind (`CONS_DISC_IND`) | Auto-populated on clear | List | N/A | N/A | Reset to percentage indicator | Package generated; new enquiry | System-reset | N/A |
| Dlr Cons Disc (`DLR_CONS_DISC`) | Auto-populated on clear | Numeric | N/A | N/A | Cleared to null | Package generated; new enquiry | System-cleared | N/A |

---

---

#### Requirement ID: BR-022

**Requirement Title:** Save SMP Enquiry - Insert Charges, Commit to Database, Display Enquiry Number, and Print Report

**Business Description:**
When the service advisor is ready to save the completed SMP enquiry, the system validates that the form is in a state where saving is permitted, inserts the computed charge records into the permanent charges table, clears the temporary staging data, commits all the enquiry header and detail records to the database, displays the generated SMP enquiry number to the advisor, and then automatically triggers the SMP enquiry report for printing. The form is then cleared for the next enquiry. If saving is not permitted (the form is in a read-only or incomplete state), the action is blocked.

**Actors:** Service Advisor

**Preconditions:**
- All enquiry details have been entered, the SMP package has been generated, and the tax calculation has been applied.
- The Save button has been enabled (TCS has been applied and no validation errors remain).
- The MCP (Maruti Care Programme) feature is activated for this dealership location; if it is not, the Save toolbar button blocks saving with a gate message.

**Main Flow:**

**Step 1 - MCP activation confirmed before enquiry number generation**
When the advisor clicks the Save toolbar button (FT_SAVE), the system first checks whether the MCP feature is active for the current dealership location. If MCP is not active, saving is blocked with an error. If MCP is active and no enquiry number has yet been assigned, the system generates the next sequential SMP enquiry number for the current financial year by calling the number-generation service. If the generation service returns an error, that error is shown and saving is blocked; otherwise the generated number is assigned to the enquiry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| MCP feature is active for the dealership location | MCP flag check - FT_SAVE toolbar trigger; reads nb_mcp_yn flag on the vehicle header | When the advisor clicks the Save toolbar button | Prevents saving an SMP enquiry when the MCP programme is not enabled at this location | *"Please generate enquiry"* is shown; saving is blocked |
| Enquiry number generation succeeded | Error code check - FT_SAVE; calls pk_validate_back_date.generate_next_num ('SME'); checks lv_err_cd | When enquiry number is not yet assigned at save time | Ensures a valid sequential number is obtained before the data is committed | Error message from the number-generation service is shown; saving is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-022-ES-01** - MCP is not active - *"Please generate enquiry"*; advisor cannot save until the enquiry has been generated through the correct MCP flow.
- **BR-022-ES-02** - Enquiry number generation fails - error from the number-generation service is shown; saving is blocked.

**Step 2 - Form state validated before commit**
The system runs a form-level validation to ensure all entered data is valid, then checks whether the Save button is currently enabled. If it is not enabled, saving is blocked.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-009](#SP-009--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE - checks whether the form is in a valid state after the validation pass and raises an error if not.
    * **Step 1** - Check whether the form validation completed successfully.
    * **Step 2** - If the form reports a validation error, display the error text (the system's database error message for Oracle errors, or the Forms error text for Forms-level errors) and abort saving.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Form is in a valid, saveable state | Form failure check - GENERAL.CHECK_FORM_FAILURE [SP-009]; KEY-COMMIT in Form | When the advisor triggers the save action | Prevents saving an enquiry with outstanding validation errors | Error displayed by GENERAL.CHECK_FORM_FAILURE; save is blocked |
| Save button is enabled | Access check - KEY-COMMIT in Form; checks PB_BLK.PB_SAVE.ENABLED property | When the advisor triggers the save action | Prevents committing an enquiry that has not completed the TCS and tax calculation steps | *"Updation Not Allowed Here"* is shown; save is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-022-ES-03** - Save button is disabled - *"Updation Not Allowed Here"*; advisor must complete all required steps before saving.

**Step 3 - Charge records inserted into permanent table**
The system inserts the computed charge detail records from the staging table into the permanent enquiry charges table for the current enquiry. If any exception occurs during insertion, the charge insert procedure displays an error and halts the commit.

*Procedures called:*
- **SP_INSERT_CHARGES** ([SP-008](#SP-008--SP_INSERT_CHARGES)) - SP_INSERT_CHARGES - inserts all computed charge records from the staging table into the permanent charges table, assigning the current enquiry number.
    * **Step 1** - Read all charge records from the staging table for the current dealership location and company.
    * **Step 2** - Insert each charge record into the permanent charges table with the enquiry number, serial number, service type, service code, charge serial number, charge indicators, charge value, charge amount, creator, and creation date.
    * **Step 3** - If any exception occurs during the insert, display *"Error... In Tax Calculation"* and raise a form failure to abort the commit.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Charge insert completes without exception | Exception handler - SP_INSERT_CHARGES [SP-008]; KEY-COMMIT in Form | During the charge insert step of the save action | Prevents a partial commit when the charge insert encounters a database error | *"Error... In Tax Calculation"* is shown; commit is aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-022-ES-04** - Charge insert exception - *"Error... In Tax Calculation"*; commit is aborted.

**Step 4 - Temporary staging data removed and enquiry committed to the database**
After inserting the charges, the system deletes all temporary staging records (SMP staging, detail, and charges) for the current session, then commits all data - the enquiry header, service detail lines, and charges - permanently to the database. Performance logging records the operation timing (category: *"SMP Enquiry"*, action: "Saving SMP enquiry details") when application logging is active.

**Step 5 - Enquiry number displayed and report generated**
The system displays the generated SMP enquiry number to the advisor. It then calls the report generation routine to run the SMP enquiry report and offer the advisor the option to print or save it as PDF. After the report is handled, the form is cleared for the next entry.

*Procedures called:*
- **CALL_REPORT_ENQ** ([SP-001](#SP-001--CALL_REPORT_ENQ)) - CALL_REPORT_ENQ - runs the SMP enquiry report (vr_smp_enq) for the saved enquiry and handles the report print/preview alert.
    * **Step 1** - Receive the principal, parent group, dealer, location, company, and the generated enquiry number.
    * **Step 2** - Locate the report object and set the report filename to "vr_smp_enq" and the report server from the session configuration.
    * **Step 3** - Display an alert (AL_REPORT) to the advisor with options to print the report (printer) or save as PDF.
    * **Step 4** - If the advisor selects printer output, build the report parameter string with destination type PRINTER and options *"MODE=CHARACTER BLANKPAGES=NO"*, then execute the report via the report server and check the output status.
    * **Step 5** - If the advisor selects PDF output, set the destination format to PDF and options MODE=BITMAP BLANKPAGES=NO, then execute the report and open it in the browser.
    * **Step 6** - After the report is handled, the form is cleared via the KEY-CLRFRM action.

*Business outcomes (errors, warnings, success, and status):*
- **BR-022-SM-01** - Enquiry saved and number generated - *"SMP Enquiry Number generated is [enquiry number]"*; the enquiry number is displayed and the report is triggered.

**Step 6 - Reprint existing enquiry from the Print toolbar button**
The service advisor may also trigger the SMP enquiry report at any time after the enquiry has been saved by clicking the Print toolbar button (FT_PRINT). The system checks that the Print button is enabled and an enquiry number exists, then calls the same report generation routine to reprint or save the enquiry report.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Enquiry number exists before reprinting | Null check - FT_PRINT toolbar trigger; checks NB_ENQ_NUM is not null | When the advisor clicks the Print toolbar button | Prevents the report from being run when no saved enquiry is loaded | Print button is disabled or action is silently suppressed |

*Procedures called:*
- **CALL_REPORT_ENQ** ([SP-001](#SP-001--CALL_REPORT_ENQ)) - CALL_REPORT_ENQ - runs the SMP enquiry report as described in Step 5 above, using the current enquiry number.

**Alternative Flows:**
- **BR-022-AF-01** - (from Step 1) MCP is not active - *"Please generate enquiry"*; save is blocked.
- **BR-022-AF-02** - (from Step 1) Enquiry number generation fails - error from service is shown; save is blocked.
- **BR-022-AF-03** - (from Step 2) Save button is disabled - *"Updation Not Allowed Here"*; save is blocked; advisor must complete all required pre-save steps.
- **BR-022-AF-04** - (from Step 2) Form validation fails - error shown; save is blocked.
- **BR-022-AF-05** - (from Step 3) Charge insert exception - *"Error... In Tax Calculation"*; commit is aborted.
- **BR-022-AF-06** - (from Step 5) Advisor declines the print option - report is not printed; form is cleared for the next enquiry.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Enquiry No. (`ENQ_NUM`) | Auto-populated on save | Text | N/A | N/A | System-generated SMP enquiry number | All fields valid and Save enabled | System-generated only | N/A |
| Created By (`CREATED_BY`) | Auto-populated on save | Text | N/A | N/A | Logged-in user ID | Pre-Insert trigger fires on save | System-set from session user | N/A |
| Created Date (`CREATED_DATE`) | Auto-populated on save | Date/Time | N/A | N/A | Current system date/time | Pre-Insert trigger fires on save | System-set from SYSDATE | N/A |
| Modified By (`MODIFIED_BY`) | Auto-populated on update | Text | N/A | N/A | Logged-in user ID | Pre-Update trigger fires on update | System-set from session user | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated on update | Date/Time | N/A | N/A | Current system date/time | Pre-Update trigger fires on update | System-set from SYSDATE | N/A |

---

---

#### Requirement ID: BR-023

**Requirement Title:** Clear Form - Reset All Fields and Purge Temporary Staging Data

**Business Description:**
The service advisor can clear all entries on the current enquiry screen at any time before saving by triggering the clear form action. When unsaved changes are present, the system asks the advisor to confirm before discarding data. If the advisor confirms, or if there are no unsaved changes, the form discards all entries, removes all temporary staging data (SMP staging, detail, and charges) accumulated in the working area for the current session, resets field editability to the default new-entry state, and displays the copyright notice. The form is returned to a blank state ready for the next enquiry. The Cancel toolbar button (FT_CANCEL) also invokes this flow when the Cancel button is enabled.

**Actors:** Service Advisor

**Preconditions:**
- The form is open (whether partially filled or empty).

**Main Flow:**

**Step 1 - Advisor initiates the clear or cancel action**
The advisor either clicks the Cancel toolbar button or triggers the clear form action. The system checks whether the Cancel button is currently enabled; if the button is disabled, no action is taken.

**Step 2 - Unsaved changes checked and confirmation requested if needed**
If the form contains unsaved changes, the system prompts the advisor for confirmation before discarding them. If the advisor confirms the discard, or if there are no unsaved changes, the clear action proceeds.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Advisor confirms discard when form has unsaved changes | Confirmation alert - FT_CANCEL toolbar trigger; calls GENERAL.ASK_CONFIRM when form status is CHANGED | When the advisor triggers clear or cancel and the form has unsaved data | Prevents accidental loss of entered enquiry details | *"Entered data will not be Saved"*; advisor must confirm to proceed; if the advisor cancels the confirmation, the form is not cleared |

*Business outcomes (errors, warnings, success, and status):*
- **BR-023-WS-01** - Form has unsaved changes and advisor is asked to confirm - *"Entered data will not be Saved"*; if the advisor declines, the form remains unchanged.

**Step 3 - Form cleared and all on-screen entries discarded**
All fields on the form are cleared without validation, discarding any unsaved entries.

**Step 4 - Temporary staging data removed for the current session**
The system deletes all temporary SMP staging records, detail line items, and charge records that were accumulated in the working area for the current dealer, location, and company during this session.

**Step 5 - Field properties reset and copyright notice displayed**
The enquiry number field is re-enabled for entry. The GST type radio group is reset to editable. The copyright notice is refreshed by calling the copyright declaration function.

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-034](#SP-034--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - returns the current copyright text to be displayed in the copyright notice field on the form.
    * **Step 1** - Return the applicable copyright declaration text.

**Alternative Flows:**
- **BR-023-AF-01** - (from Step 2) Advisor declines the discard confirmation - the form is not cleared; the advisor can continue editing.
- **BR-023-AF-02** - (from Step 1) Cancel button is disabled - no action is taken.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display | N/A | N/A | Copyright declaration text | Form clear triggered | System-set only | N/A |

---

---

#### Requirement ID: BR-024

**Requirement Title:** Exit Form - Close the SMP Enquiry Form Without Saving

**Business Description:**
The service advisor can close the SMP Enquiry form at any time by triggering the exit action. The form closes immediately without prompting for validation or saving of any unsaved changes. The current database session activity tracking is cleared so that monitoring tools no longer associate activity with this form.

**Actors:** Service Advisor

**Preconditions:**
- The SMP Enquiry form is open.

**Main Flow:**

**Step 1 - Session monitoring cleared and form closed without validation**
The system clears the form module name and client information from the current database session monitoring record (so that monitoring tools no longer associate activity with this form), clears the action name, and then closes the form immediately without validating or saving any unsaved entries.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

---

#### Requirement ID: BR-025

**Requirement Title:** Form-Level Error Interception - Translate Oracle Form Errors Into User-Friendly Messages

**Business Description:**
Certain Oracle Forms internal error codes are intercepted by the system and translated into plain, user-friendly messages rather than displaying raw system error codes to the advisor. Specifically, errors raised when a date entered in a field is not a valid calendar date are caught and shown as a readable error; date format errors and numeric-field data type errors are also intercepted and translated. Errors indicating that a record has been updated by another user concurrently are caught and shown with a re-query instruction. Any SQL exception from the database (non-zero SQL code) is also shown and rolled back. Navigation errors (40401 and 40405) are silently suppressed. All other errors are handled by the standard form mechanism.

**Actors:** Service Advisor (recipient of the translated messages)

**Preconditions:**
- The SMP Enquiry form is open and an action that triggers a validation has been performed.

**Main Flow:**

**Step 1 - Invalid date entry intercepted and plain message shown**
When the form raises an internal error indicating that a date value is not valid (error code 50004), the system displays a plain message and blocks further processing on the current field or step.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date entered is a valid calendar date | Error interception - ON-ERROR in Form; catches error code 50004 | When any date field receives an invalid entry | Replaces an obscure system error code with a readable message | *"Entered Date is not valid Date"* is shown; processing is blocked |
| Date entered is in the correct format | Error interception - ON-ERROR in Form; catches error codes 50025 and 50026 | When a date field receives a value in the wrong format | Tells the advisor the exact format expected | *"Enter the Date in the proper format (DD-MM-YYYY)"* is shown; processing is blocked |
| Data type compatible with field | Error interception - ON-ERROR in Form; catches error codes 40209 and 50016 | When a field receives a value of incompatible data type | Replaces a technical data-compatibility error with a plain message | *"Characters/Special Characters are not allowed here, enter the numeric value"* is shown; processing is blocked |
| Field-level error message shown as-is | Error interception - ON-ERROR in Form; catches error code 40207 | When a Forms field-level validation fails with a custom message | Surfaces the form-defined error text to the advisor without modification | The field's own error text is shown; processing is blocked |
| No concurrent update conflict on the record | Error interception - ON-ERROR in Form; catches error codes 40654, 40655, 40656, 40657, and 40659 | When Oracle Forms detects that the current record was modified by another session | Prevents the advisor from overwriting another user's changes without first re-querying | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is shown; the pending transaction is rolled back; processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-025-ES-01** - Date field contains an invalid date - *"Entered Date is not valid Date"*; processing is blocked.
- **BR-025-ES-02** - Date field contains a value in the wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; processing is blocked.
- **BR-025-ES-03** - Numeric field contains non-numeric characters - *"Characters/Special Characters are not allowed here, enter the numeric value"*; processing is blocked.
- **BR-025-ES-04** - Field-level validation error (error code 40207) - the field's own error message is shown; processing is blocked.
- **BR-025-ES-05** - Concurrent update detected (error codes 40654, 40655, 40656, 40657, or 40659) - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; transaction is rolled back; processing is blocked.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

---

#### Requirement ID: BR-026

**Requirement Title:** Form-Level Message Interception - Convert Oracle Forms Informational Messages to Errors

**Business Description:**
Certain Oracle Forms informational messages that would normally display silently or as status messages are intercepted and converted into explicit error notifications to ensure the advisor is not confused by technical platform messages. Specifically, messages with code 40209 or 40207 are promoted to error-level messages and block further processing on the field or step.

**Actors:** Service Advisor (recipient of the intercepted messages)

**Preconditions:**
- The SMP Enquiry form is open.

**Main Flow:**

**Step 1 - Platform informational messages with specific codes intercepted and shown as errors**
When Oracle Forms generates a message with code 40209 (record has been updated by another user) or 40207, the system intercepts it, formats it as an error message combining the error type, error number, and error text, displays it to the advisor, and blocks further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message codes 40209 and 40207 promoted to errors | Message interception - ON-MESSAGE in Form; catches error codes 40209 and 40207 | When Oracle Forms generates one of these message codes during any operation | Prevents the advisor from missing a record-concurrency or field-compatibility issue that would otherwise display silently | The message is displayed as a formatted error (error type + code + text); processing is blocked |

*Business outcomes (errors, warnings, success, and status):*
- **BR-026-ES-01** - Record updated by another user or field conflict detected - *"[error type]-[error code]: [error text]"*; processing is blocked.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

---

#### Requirement ID: BR-027

**Requirement Title:** Performance Timer Expiry - Record Operation Timing for Application Logging

**Business Description:**
When an internal performance timer set up by the application logging infrastructure expires, the system delegates the expiry processing to the shared timer procedure. This allows the performance monitoring framework to record how long specific operations within the SMP enquiry form took to complete when application logging is active.

**Actors:** System

**Preconditions:**
- Performance logging is enabled for the environment.
- A performance timer was started earlier in the session.

**Main Flow:**

**Step 1 - Timer expiry delegated to the general timer procedure**
When a timer fires, the system calls the general timer-expiry procedure to handle the expiry event and record the elapsed time.

*Procedures called:*
- **GENERAL.PROC_TIMER_EXPIRED** ([SP-014](#SP-014--GENERAL.PROC_TIMER_EXPIRED)) - GENERAL.PROC_TIMER_EXPIRED - processes the timer expiry event for application performance logging.
    * **Step 1** - Receive the timer expiry notification.
    * **Step 2** - Retrieve the elapsed time from the timer started earlier.
    * **Step 3** - Record the timing data for the current operation.
    * **Step 4** - Complete the expiry handling and return control to the form.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

---

#### Requirement ID: BR-028

**Requirement Title:** Package Detail Navigation - Skip Empty Service Code Rows

**Business Description:**
When the cursor moves to a new row in the package detail grid, the system automatically skips rows that have no service code populated. This prevents the advisor from landing on empty placeholder rows and ensures navigation in the detail grid only stops on rows that have actual service or parts data.

**Actors:** Service Advisor

**Preconditions:**
- The package detail grid is visible with line items loaded.

**Main Flow:**

**Step 1 - Empty rows skipped during detail grid navigation**
When the system enters a new record in the package detail grid, it checks whether the service code field is populated. If the row is empty (no service code), the system automatically moves to the previous record, effectively skipping the empty row.

*Screen: Details (`CN_DEF`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service Code (`SRV_CODE`) | Read-only display | Text | N/A | N/A | Operation or part code | Package generated | Navigation skips row if blank | N/A |

---

---

#### Requirement ID: BR-029

**Requirement Title:** Enquiry Record Display - Populate Derived Display Fields on Query

**Business Description:**
When an SMP enquiry header record is retrieved from the database for display (either via the enquiry number lookup or when the form reloads after a save), the system automatically populates all derived display-only fields that are not stored directly in the header table. These include the vehicle model description, variant description, fuel type, package description, SMP expiry parameters, vehicle sale date, validity window, enquiry status description, customer city description, employee name, state description, discount summaries, tax totals, and add-on sub-totals. The GST type radio group is locked for records that already have an enquiry number.

**Actors:** System

**Preconditions:**
- An enquiry record has been queried and is being displayed.

**Main Flow:**

**Step 1 - Model, variant, and package descriptions populated**
The system looks up and displays the model description, variant description, fuel type code, and package description from the relevant master tables.

**Step 2 - SMP expiry parameters refreshed**
The system calls the SMP expiry routine to re-retrieve the plan's expiry month count and expiry mileage for display.

*Procedures called:*
- **PKG_SMP.SP_GET_SMP_EXP** ([SP-020](#SP-020--PKG_SMP.SP_GET_SMP_EXP)) - PKG_SMP.SP_GET_SMP_EXP - retrieves the SMP contract's expiry parameters for the vehicle, service type, and sub-service range.
    * **Step 1** - Accept the principal, VIN, service type, and ending sub-service code.
    * **Step 2** - Retrieve the vehicle's invoice date and service variant.
    * **Step 3** - Look up the sub-service calendar to determine expiry mileage and vehicle age.
    * **Step 4** - Calculate the contract expiry date.
    * **Step 5** - Return expiry age in months, expiry mileage, and validity-to date.

**Step 3 - Vehicle sale date, validity window, and running average computed**
The vehicle's invoice (sale) date and last recorded mileage are retrieved. If the plan validity start date is not already set, it is defaulted to the enquiry date, the vehicle age and average running are calculated, and the validity end date is derived based on the running average.

**Step 4 - Enquiry status description, city description, and employee name retrieved**
The status description, customer city name, and service executive name are retrieved from their respective master tables for display.

**Step 5 - Discount and tax summary fields computed and displayed**
Discount amounts, tax amounts, net amounts, and sub-totals are aggregated from the saved detail records and computed into the various summary display fields (MCP discounts, dealer discounts, combined discounts, taxes, net sub-totals, add-on sub-totals, and combined totals including add-ons). The coolant and engine oil codes and descriptions from the detail records are also displayed.

**Step 6 - State description retrieved**
If the customer state code is populated, the corresponding state description is retrieved and displayed.

**Step 7 - GST type radio group locked for completed enquiries**
If the record has an enquiry number (a completed, saved enquiry), the GST type radio group is locked to prevent changes.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Model Description (`NB_MODEL_DESC`) | Read-only display | Text | N/A | Model master (VM_SVAR) | Model description | Record queried | System-populated; null silently if not found | N/A |
| Variant Description (`NB_VARIANT_DESC`) | Read-only display | Text | N/A | Variant master (GM_VAR) | Variant description | Record queried | System-populated | N/A |
| Package Description (`PKG_DESC`) | Read-only display | Text | N/A | SMP package master (VM_SMP_PACKAGE) | Package description | Record queried | System-populated | N/A |
| Employee Name (`EMP_NAME`) | Read-only display | Text | N/A | Employee master (GM_EMP) | Employee name | Record queried | System-populated | N/A |
| State Description (`STATE_DESC`) | Read-only display | Text | N/A | State master (GM_STATE) | State description + GST state code | Record queried | System-populated | N/A |

---

---

#### Requirement ID: BR-030

**Requirement Title:** Package Detail Line Display - Populate Service or Part Description on Query

**Business Description:**
When a package detail line is retrieved from the database for display, the system automatically populates the service or part description that corresponds to each line's type and code. Labour operation lines have their description retrieved from the operations master; parts and consumable lines have their description retrieved from the parts master.

**Actors:** System

**Preconditions:**
- Package detail lines have been queried and are being displayed.

**Main Flow:**

**Step 1 - Service or part description retrieved based on line type**
For each detail line, the system checks the service type. If it is a labour line, the operation description is retrieved from the operations master for the current principal, dealer type, vehicle model, and operation code. If it is a parts or consumable line, the part description is retrieved from the parts master for the principal. If no description is found, null is set silently.

*Screen: Details (`CN_DEF`).*

#### Business Scenarios - How description lookup differs by service type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Labour line** | Description is retrieved from the operations master (VM_MSIL_OPR) matching the principal, dealer type "D", vehicle model, and operation code. |
| **Parts or consumable line** | Description is retrieved from the parts master (PM_PART) matching the principal and part number. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Service Description (`NB_SRV_DESC`) | Read-only display | Text | N/A | Operations master (VM_MSIL_OPR) or Parts master (PM_PART) | Operation or part description | Detail line queried | System-populated; null silently if not found | N/A |

---

---

#### Requirement ID: BR-031

**Requirement Title:** Keyboard Scroll Navigation on Vehicle Header - Scroll Through Enquiry Records Using Arrow Keys

**Business Description:**
On the vehicle header section of the SMP Enquiry form, the Down Arrow key and Up Arrow key allow the service advisor to scroll forwards and backwards through enquiry records already loaded in the header block. Pressing the Down Arrow key advances to the next enquiry record; pressing the Up Arrow key returns to the previous enquiry record. These keys operate only within the vehicle header section and provide keyboard-driven navigation as an alternative to mouse-based record scrolling.

**Actors:** Service Advisor

**Preconditions:**
- The SMP Enquiry form is open.
- The cursor focus is within the vehicle header section (B_VH_AMC_ENQ).

**Main Flow:**

**Step 1 - Advisor presses Down Arrow key to advance to the next enquiry record**
The form moves the current record pointer forward by one row in the vehicle header block, displaying the next enquiry record's details on screen.

**Step 2 - Advisor presses Up Arrow key to return to the previous enquiry record**
The form moves the current record pointer backward by one row in the vehicle header block, displaying the previous enquiry record's details on screen.

**Alternative Flows:**
- **BR-031-AF-01** - (from Step 1) No next record exists - the form remains on the current record; standard Forms end-of-records behaviour applies.
- **BR-031-AF-02** - (from Step 2) No previous record exists - the form remains on the current record; standard Forms beginning-of-records behaviour applies.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

---

---

#### Requirement ID: BR-032

**Requirement Title:** Delete SMP Enquiry Record - Confirm and Remove Current Enquiry Record

**Business Description:**
When the service advisor wishes to remove the current enquiry record from the form, the Delete toolbar button allows deletion after the advisor confirms the action. The system first disables form-level validation to avoid false validation errors during the delete operation, navigates to the enquiry data block, and asks the advisor to confirm. If confirmed, the current record is deleted from the form and the underlying database row is removed. If the form has no unsaved changes at the point of the delete action, the form is instead cleared without deleting a database record. If the Delete button is not enabled, the action is suppressed.

**Actors:** Service Advisor

**Preconditions:**
- The SMP Enquiry form is open.
- The Delete toolbar button (PB_DEL) is enabled.
- An enquiry record is currently loaded or the form is in a changed state.

**Main Flow:**

**Step 1 - Advisor clicks the Delete toolbar button**
The system checks whether the Delete toolbar button is enabled. If it is disabled, no action is taken and processing ends.

**Step 2 - Form validation temporarily suspended and enquiry block focused**
The system suspends form-level validation so that partially filled fields do not block the delete action, then navigates focus to the enquiry data block.

**Step 3 - Advisor prompted to confirm deletion**
When the form is in a changed state (indicating a record is loaded or being edited), the system prompts the advisor for explicit confirmation before proceeding with the delete.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Advisor confirms deletion when form has a loaded or changed record | Confirmation alert - FT_DEL toolbar trigger; calls GENERAL.ASK_CONFIRM when form status is CHANGED | When the advisor triggers the delete action with a record loaded | Prevents accidental deletion of the current enquiry record | *"Are you sure to Delete"*; advisor must confirm to proceed; if declined, the record is not deleted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-032-WS-01** - Advisor is asked to confirm deletion - *"Are you sure to Delete"*; if the advisor declines, the record is not deleted.

**Step 4 - Record deleted or form cleared**
If the advisor confirms deletion, the current record is deleted from the form and the corresponding database row is removed. If the form has no unsaved changes, the form is instead cleared without a database delete. Form-level validation is re-enabled after the operation completes.

**Alternative Flows:**
- **BR-032-AF-01** - (from Step 1) Delete button is disabled - no action is taken; the advisor cannot delete a record in the current form state.
- **BR-032-AF-02** - (from Step 3) Advisor declines the deletion confirmation - the record is not deleted; the form remains unchanged; form validation is re-enabled.
- **BR-032-AF-03** - (from Step 4) Form has no unsaved changes at delete time - form is cleared rather than a database delete being executed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| - | - | - | - | - | - | - | - | - |

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | SMP Enquiry Number Must Exist | Validation | BR-002 | Enquiry number is entered but no matching SMP enquiry is found for the current dealership and location | Block entry and show *"SMP Enquiry Number Not Found"* | Prevents an advisor from loading a non-existent enquiry and ensures only valid historical records can be reviewed |
| BRC-002 | Registration Number Must Be Found | Validation | BR-003 | Registration number entered does not match any vehicle in the master | Block entry and show *"Registration Number Not Found"* | Ensures only vehicles registered in the master can have SMP enquiries created |
| BRC-003 | Registration Number Must Be Unique | Validation | BR-003 | More than one vehicle record matches the entered registration number | Block entry and show *"More than one Registration Number found for [registration]"* | Prevents ambiguous vehicle identification from resulting in incorrect enquiry data |
| BRC-004 | Vehicle Must Be SMP-Eligible | Validation | BR-003, BR-004 | The SMP eligibility check for the vehicle returns a not-eligible result | Block processing and show *"Vehicle can not be considered for SMP"* | Ensures the SMP programme is only offered to vehicles that genuinely qualify |
| BRC-005 | SMP Validity Mileage Not Exceeded | Validation | BR-004 | Current mileage entered exceeds the maximum validity mileage for the vehicle's SMP plan | Block processing and show *"Milease expired, So Vehicle can not be considered for SMP"* | Prevents creating an enquiry for a vehicle that has run beyond its contractual SMP coverage |
| BRC-006 | SMP Validity Age Not Exceeded | Validation | BR-004 | Current date is more than the SMP validity period after the vehicle sale date | Block processing and show *"Enquiry for a vehicle can be generated within 4yrs of vehicle sale"* | Enforces the SMP plan's time-based eligibility limit |
| BRC-007 | Current Mileage Must Not Be Below Previous Service Mileage | Validation | BR-004 | Entered mileage is less than the vehicle's previously recorded service mileage or True Value selling mileage | Block processing and show the appropriate mileage error with the reference mileage appended | Prevents illogical mileage entries that would indicate data entry errors or odometer fraud |
| BRC-008 | Current Mileage Is Mandatory | Validation | BR-004 | Current mileage field is left blank | Block and display mandatory-field error | Mileage is required to assess SMP eligibility and determine the applicable service sub-range |
| BRC-009 | Service Executive Is Mandatory for New Enquiries | Validation | BR-005 | Executive field is blank when creating a new enquiry | Block and display mandatory-field error | Every new SMP enquiry must be assigned to a specific service executive for accountability |
| BRC-010 | Service Type Is Mandatory | Validation | BR-006 | Service type field is left blank | Block and display mandatory-field error | Service type determines the package list category and applicable package options |
| BRC-011 | Package Code Is Mandatory | Validation | BR-008, BR-009, BR-011, BR-014 | Package code field is left blank | Block and display mandatory-field error | A package must be selected before any package-level computation or add-on selection can proceed |
| BRC-012 | SMP Package Data Must Be Generated Before Key Actions | Validation | BR-009, BR-011, BR-012 | Generate SMP, Generate Enquiry, or View Details is invoked before the SMP package data has been generated | Block and show *"SMP details not found, Please generate and check details"* | Prevents actions that depend on computed package data from running on an empty or uninitialized enquiry |
| BRC-013 | TCS Declaration Is Required When Not Pre-Selected | Validation | BR-011 | Advisor dismisses the TCS alert or declines the second-level declaration without confirming | Block processing and show *"TCS Declaration is required"* | Statutory requirement - every high-value SMP transaction must have a documented TCS applicability decision |
| BRC-014 | Duplicate Open SMP Enquiry Warning | Constraint | BR-003 | An open SMP enquiry already exists for the same vehicle at the current dealership | Display the duplicate enquiry alert (AL_ENQ); block if advisor declines, or allow if advisor confirms | Prevents accidental duplicate enquiries for the same vehicle; keeps the advisor informed before proceeding |
| BRC-015 | Labour Discount Indicator Must Be Selected Before Value | Validation | BR-019, BR-020 | Labour discount value is entered but the labour discount indicator is not selected | Block and show *"Please select Labour Discount Indicator before selecting Disc Value"* or *"Please Select Labour Discount Indicator before selecting Disc Value"* | Ensures the system knows whether the discount is a percentage or flat amount before accepting the value |
| BRC-016 | Labour Discount Percentage Must Not Exceed 100% | Validation | BR-019, BR-020 | Labour discount indicator is percentage and the entered value exceeds 100 | Block and show *"Labour Discount Percentage Can't be greater than 100%"* | Prevents an economically invalid labour discount |
| BRC-017 | Labour Flat Discount Must Not Exceed Total Labour Amount | Validation | BR-019, BR-020 | Labour discount indicator is flat amount and the entered value exceeds the total labour cost | Block and show *"Labour Discount Amount Can't be greater than [computed total]"* | Prevents a flat labour discount that would result in a negative labour amount |
| BRC-018 | Labour Discount Must Not Be Negative | Validation | BR-019, BR-020 | Labour discount value is negative | Block and show *"Labour Discount Can't be negative"* | Prevents a price-increasing negative discount |
| BRC-019 | Parts Discount Indicator Must Be Selected Before Value | Validation | BR-019, BR-020 | Parts discount value entered but indicator not selected | Block and show *"Please select Part Discount Indicator before selecting Disc Value"* or *"Please Select Part Discount Indicator before selecting Disc Value"* | Ensures the system knows the discount type before accepting the parts discount value |
| BRC-020 | Parts Discount Percentage Must Not Exceed 100% | Validation | BR-019, BR-020 | Parts discount indicator is percentage and value exceeds 100 | Block and show *"Part Discount Percentage Can't be greater than 100%"* | Prevents an invalid over-100% parts discount |
| BRC-021 | Parts Flat Discount Must Not Exceed Total Parts Amount | Validation | BR-019, BR-020 | Parts flat discount exceeds total parts cost | Block and show *"Part Discount Amount Can't be greater than [computed total]"* | Prevents a flat parts discount that would result in a negative parts amount |
| BRC-022 | Parts Discount Must Not Be Negative | Validation | BR-019, BR-020 | Parts discount value is negative | Block and show *"Part Discount Can't be negative"* | Prevents a negative parts discount |
| BRC-023 | Consumable Discount Indicator Must Be Selected Before Value | Validation | BR-019, BR-020 | Consumable discount value entered but indicator not selected | Block and show *"Please select Consumable Discount Indicator before selecting Disc Value"* or *"Please Select Consumable Discount Indicator before selecting Disc Value"* | Ensures the system knows the discount type before accepting the consumable discount |
| BRC-024 | Consumable Discount Percentage Must Not Exceed 100% | Validation | BR-019, BR-020 | Consumable discount indicator is percentage and value exceeds 100 | Block and show *"Consumable Discount Percentage Can't be greater than 100%"* | Prevents an invalid over-100% consumable discount |
| BRC-025 | Consumable Flat Discount Must Not Exceed Total Consumable Amount | Validation | BR-019, BR-020 | Consumable flat discount exceeds total consumable cost | Block and show *"Consumable Discount Amount Can't be greater than [computed total]"* | Prevents a flat consumable discount that would result in a negative consumable amount |
| BRC-026 | Consumable Discount Must Not Be Negative | Validation | BR-019, BR-020 | Consumable discount value is negative | Block and show *"Consumable Discount Can't be negative"* | Prevents a negative consumable discount |
| BRC-027 | Detail Line Discount Indicator Must Be Selected Before Value | Validation | BR-018 | Dealer discount value entered on a detail line without selecting the indicator | Block and show *"Please select Discount Indicator before selecting Disc Value"* | Ensures the discount type is defined at line level before the value is accepted |
| BRC-028 | Detail Line Discount Percentage Must Not Exceed 100% | Validation | BR-018 | Detail line percentage discount exceeds 100 | Block and show *"Discount Percentage Can't be greater than 100%"* | Prevents invalid over-100% line-level discounts |
| BRC-029 | Detail Line Discount Must Not Be Negative | Validation | BR-018 | Detail line discount value is negative | Block and show *"Discount Percentage Can't be negative"* | Prevents price-increasing negative line discounts |
| BRC-030 | Add-On Discount Indicator Must Be Selected Before Value | Validation | BR-017 | Add-on dealer discount value entered without selecting the indicator | Block and show *"Please select Discount Indicator before selecting Disc Value"* | Ensures add-on discount type is defined before value |
| BRC-031 | Add-On Discount Percentage Must Not Exceed 100% | Validation | BR-017 | Add-on percentage discount exceeds 100 | Block and show *"Discount Percentage Can't be greater than 100%"* | Prevents invalid add-on discount |
| BRC-032 | Add-On Discount Must Not Be Negative | Validation | BR-017 | Add-on discount value is negative | Block and show *"Discount Percentage Can't be negative"* | Prevents negative add-on discount |
| BRC-033 | Add-On Quantity Must Be Greater Than Zero | Validation | BR-016 | Add-on quantity is zero or negative | Show warning *"Add-On Quantity Can't be Negative or Zero"* and reset to default value from master (or 1) | Prevents including an add-on service with a meaningless quantity |
| BRC-034 | Save Action Requires All Steps Completed | Constraint | BR-022 | Save button is disabled when the advisor triggers the save action | Block and show *"Updation Not Allowed Here"* | Ensures the enquiry is only committed after all required steps (TCS, tax calculation) are complete |
| BRC-035 | Date Fields Must Contain Valid Dates | Validation | BR-025 | A date field receives a value that is not a valid calendar date (error code 50004) | Show *"Entered Date is not valid Date"* and block | Prevents saving enquiries with invalid date values |
| BRC-036 | Date Fields Must Use Correct Format | Validation | BR-025 | A date field receives a value in the wrong format (error codes 50025, 50026) | Show *"Enter the Date in the proper format (DD-MM-YYYY)"* and block | Guides advisors to enter dates in the expected format |
| BRC-037 | Numeric Fields Must Contain Only Numeric Values | Validation | BR-025 | A numeric field receives non-numeric characters (error codes 40209, 50016) | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and block | Prevents data type errors in numeric fields |
| BRC-038 | Record Updated Concurrently | Constraint | BR-026, BR-022 | The record has been updated by another user (error code 40209) | Show formatted error message (type + code + text) and block | Protects data integrity by alerting the advisor to concurrent modifications |
| BRC-039 | Existing Enquiry Fields Are Read-Only | Constraint | BR-002 | An existing enquiry is loaded via the enquiry number field | Disable registration number, mileage, executive, service option, discount, and action fields; set form to read-only mode | Prevents inadvertent modification of committed enquiry data |
| BRC-040 | GST Type Locked When Dealer and Customer States Match or Customer Is SEZ | Derivation | BR-003 | Dealer state equals customer state, or customer is registered as an SEZ entity | Lock the GST type radio group to the appropriate value; disable user selection | Ensures the correct GST treatment is automatically applied for same-state or SEZ transactions without manual selection |
| BRC-041 | True Value SMP Mileage Limit Enforced | Validation | BR-004 | For a True Value SMP vehicle, entered mileage exceeds the True Value SMP mileage limit (selling mileage plus configured maximum) | Reset the True Value SMP flag to not applicable for the entered mileage | Prevents the True Value SMP plan from being applied when the vehicle has exceeded its mileage window |

**Total Business Rules Identified: 41**

---

## 6. Data Requirements

*This section covers the business entities persisted and referenced by the SMP Enquiry form (VT_SMP_ENQ), the data captured at each stage of the enquiry process, the reference data lookups the form uses, and the enquiry record lifecycle.*

### 6.1 Business Entities and Relationships

*The form creates and maintains SMP enquiry header records and associated service detail lines, staging the computed package data in a temporary working area before committing.*

#### SMP Enquiry Header - VH_AMC_ENQ

The SMP enquiry header stores one record per enquiry, capturing the vehicle identified for the SMP plan, the customer profile, the selected service type and package, the plan validity window, pricing totals, GST and TCS details, and the enquiry status. The header is the root record for the entire SMP enquiry (via the `B_VH_AMC_ENQ` block).

#### SMP Enquiry Service Detail - VD_AMC_ENQ

The service detail entity stores the individual labour operations, parts, and consumable items that make up the SMP package for a given enquiry. Each detail row is linked to an enquiry header by the enquiry number and carries its own service type, code, quantity, rate, MCP discount, dealer discount, net amount, GST charge amount, and group code. The detail lines are written during the form commit and are also read back by the POST-QUERY trigger to display discount, tax, and sub-total summaries on the header screen (via the `B_VD_AMC_ENQ` block).

#### SMP Enquiry Charges - VD_AMC_ENQCHARGES

The charges entity stores the computed GST and TCS charge records for each service or parts line in the enquiry. Each charge row is inserted by the SP_INSERT_CHARGES program unit during the save step and is linked to the enquiry detail lines by enquiry number, serial number, service type, and service code.

#### SMP Package Staging (Work Area) - GBL_AMC_DTL

The temporary staging entity holds the computed package line items (labour, parts, consumables, and add-ons) while the advisor is working through the enquiry. Records are written into this staging area by the backend package population routines (PKG_SMP.SP_POP_SMP_PKG, PKG_SMP.SP_POP_SMP_PKG_TV, PKG_SMP.SP_POP_SMP_ADDON, POP_DISC) and are read back for display, discount calculation, and tax computation. The staging area is deleted for the current session on save (KEY-COMMIT) and on form clear (KEY-CLRFRM).

#### SMP Add-On Staging (Work Area) - GBL_SMP

The add-on staging entity records which add-on services have been selected by the advisor for the current enquiry session. Each row links a selected add-on type to the current vehicle, package, and session identifiers. The add-on staging records are also deleted on save and form clear.

#### SMP Enquiry Charges Staging (Work Area) - GBL_AMC_CHARGES

The charges staging entity holds the computed charge records accumulated during the tax calculation step before they are permanently committed. These records are deleted from the staging area on save and form clear, having been moved to the permanent charges table (VD_AMC_ENQCHARGES) by SP_INSERT_CHARGES.

#### Entity Relationships

The SMP Enquiry Header is the root entity for the form. Each header has one or more service detail lines; each detail line may have associated charge records. Three temporary staging entities hold in-progress working data that is linked to the same vehicle and session identifiers as the header, and are purged on save or clear.

```
VH_AMC_ENQ (SMP Enquiry Header)
        ├── VD_AMC_ENQ (SMP Enquiry Service Detail)  <- linked by ENQ_NUM
        │       └── VD_AMC_ENQCHARGES (SMP Enquiry Charges) <- linked by ENQ_NUM + SRL_NUM + SRV_TYPE + SRV_CD
        ├── GBL_AMC_DTL (SMP Package Staging - work area)  <- linked by PARENT_GROUP + DEALER_MAP_CD + LOC_CD + COMP_FA + REG_NUM + PKG_CODE
        ├── GBL_SMP (Add-On Staging - work area)  <- linked by PARENT_GROUP + DEALER_MAP_CD + LOC_CD + COMP_FA + REG_NUM + PKG_CODE
        └── GBL_AMC_CHARGES (Charges Staging - work area)  <- linked by PARENT_GROUP + DEALER_MAP_CD + LOC_CD + COMP_FA
```

### 6.2 Data Capture Requirements

*The form captures enquiry header data (vehicle, customer, plan, and pricing details) and service detail line data (labour, parts, consumables, and add-ons). Some fields are mandatory, others are system-derived or conditionally required.*

#### Enquiry Identification (Advisor - new or existing)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Enquiry No. (`NB_ENQ_NUM`) | Conditional | Optional: entered only when reviewing an existing SMP enquiry rather than creating a new one | If entered, must match an existing SMP enquiry for the current dealership and location; form is set to read-only if a match is found |

#### Vehicle and Customer Details (Advisor - new enquiry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Registration Number (`REG_NUM`) | Yes | The vehicle's registration number, which uniquely identifies the vehicle for the SMP enquiry | Must exist in the vehicle master; must be unique; non-alphanumeric characters are stripped before lookup |
| Current Mileage (`ODOMETER_READING`) | Yes | The vehicle's current odometer reading at the time of the enquiry, used to assess SMP eligibility and determine the applicable service sub-range | Must not be blank; must not be less than the previous service mileage; must not exceed the SMP validity mileage; vehicle must be within the SMP validity age |
| Executive (`EMP_CD`) | Conditional | The service executive code assigned to handle the enquiry; mandatory for new enquiries only | Must not be blank when creating a new enquiry; selected from the active executive list |
| Enquiry Date (`ENQ_DATE`) | Auto-Populated | The date and time the enquiry record is created; set by the system | System-set; not user-editable |
| GST Type (`RG_GSTTYPE`) | Conditional | The applicable GST category (intra-state or inter-state) for the transaction | Derived automatically from dealer and customer state; locked when states match or customer is SEZ-registered; user-selectable only when states differ and customer is not SEZ |

#### SMP Package Selection (Advisor - after vehicle confirmed)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Applicable Service Type (`SERV_TYPE`) | Yes | The type of SMP service being enquired (e.g. PMS, CVMS) | Must not be blank; selected from the configured SMP service type list |
| Service Option (`SERV_OPTION`) | Conditional | The package option (full parts package or labour-only); enabled only for PMS service type on a new enquiry | System-defaulted to full package; user may change only when service type is PMS and a new enquiry is being created |
| Applicable Package (`PKG_CODE`) | Yes | The SMP package code applicable to the vehicle for the selected service type and mileage | Must not be blank; auto-derived from package list category; can be overridden by the advisor for applicable packages |
| Engine Oil (`ENGINE_OIL`) | Auto-Populated | The default engine oil part number for the vehicle, service sub-range, and package; auto-populated from the parts master | Auto-derived; can be changed via the engine oil LOV |
| Coolant (`COOLANT`) | Auto-Populated | The default coolant part number for PMS packages; auto-populated from the parts master | Auto-derived for PMS service type only; set to "NA" when no coolant applies |
| True Value SMP (`TV_SMP`) | Conditional | Flag indicating whether this is a True Value (pre-owned) SMP package; auto-determined | System-set based on vehicle's True Value status and eligibility; disabled from user entry |

#### TCS Declaration (Advisor - before tax calculation)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| TCS Applicability (`NB_TCS_APPL_YN` / `TCS_APPL_YN`) | Yes | Radio button selection and stored flag for whether Tax Collected at Source applies to the transaction | Must be selected before the Apply TCS button is used; once the normal or higher rate is selected and applied, the flag is set |
| TCS Description (`NBT_TCS_DESC`) | Auto-Populated | Description of the TCS decision made by the advisor ("Normal Rate Applied", "Higher Rate Applied", or "TCS Not Applied") | System-set from the rate button selection or TCS non-applicable selection |

#### Dealer Discount Entry (Advisor - optional, new enquiry only)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Lab Disc Ind (`LAB_DISC_IND`) | Conditional | Indicator specifying whether the labour dealer discount is a percentage or flat amount | Must be selected before entering a labour discount value |
| Dlr Lab Disc (`DLR_LAB_DISC`) | Conditional | Dealer discount value applied to the labour total | Must not exceed 100% (percentage) or the total labour amount (flat); must not be negative |
| Part Disc Ind (`PART_DISC_IND`) | Conditional | Indicator specifying whether the parts dealer discount is a percentage or flat amount | Must be selected before entering a parts discount value |
| Dlr Part Disc (`DLR_PART_DISC`) | Conditional | Dealer discount value applied to the parts total | Must not exceed 100% (percentage) or the total parts amount (flat); must not be negative |
| Cons Disc Ind (`CONS_DISC_IND`) | Conditional | Indicator specifying whether the consumable dealer discount is a percentage or flat amount | Must be selected before entering a consumable discount value |
| Dlr Cons Disc (`DLR_CONS_DISC`) | Conditional | Dealer discount value applied to the consumables total | Must not exceed 100% (percentage) or the total consumable amount (flat); must not be negative |

#### Package Detail Lines (System - after Generate SMP)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Service Type (`SRV_TYPE`) | Auto-Populated | Type code for the line item (Labour, Parts, or Consumable) | System-populated from staging; read-only display |
| Service Code (`SRV_CODE`) | Auto-Populated | The operation or part code for the line item | System-populated from staging |
| Quantity (`QTY`) | Auto-Populated | The quantity of the service operation or part included in the package | System-populated from staging |
| SMP Disc % (`DISCOUNT_PER`) | Auto-Populated | The MCP discount percentage applied to the line item | System-populated from the MCP discount master |
| Rate (`RATE`) | Auto-Populated | The unit rate for the operation or part | System-populated from pricing master |
| Basic Amount (`BASIC_AMT`) | Auto-Populated | The line item amount before any discount | System-populated from staging |
| After-MCP-Discount Total (`TOT_AFT_MCP_DISC`) | Auto-Populated | The line item net amount after MCP discount | System-populated from staging |
| Dealer Discount Indicator (`DLR_DISC_IND`) | Conditional | Discount type indicator for the dealer discount on this line; enabled only for new enquiries | Must be selected before entering a dealer discount |
| Dealer Discount (`DLR_DISC`) | Conditional | Dealer discount value for this individual line item | Must not exceed 100% or be negative |
| After-Dealer-Discount Total (`TOT_AFT_DLR_DISC`) | Auto-Populated | Line net amount after both MCP and dealer discounts | System-calculated |
| Charge Amount (`CHARGE_AMT`) | Auto-Populated | GST and TCS charge computed for the line item | System-populated by tax calculation |

#### Add-On Services (Advisor - optional, new enquiry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Add-On Code (`ADDON_CODE`) | Auto-Populated | The add-on service code from the add-on master | System-loaded from master list |
| Description (`ADDON_DESC`) | Auto-Populated | The add-on service description | System-loaded from master list |
| Include Add-On (`ADDON_YN`) | Conditional | Checkbox for the advisor to include or exclude the add-on service | When ticked, backend population routine is invoked; when unticked, staging records are removed |
| Quantity (`ADDON_CNT`) | Conditional | The quantity for the add-on service | Must be greater than zero; must be within allowed service range; auto-corrected to default if entered as zero or negative |
| Dealer Discount Indicator (`DLR_DISC_IND`) | Conditional | Discount type indicator for dealer discount on the add-on | Must be selected before entering a discount value |
| Dealer Discount (`DLR_DISC`) | Conditional | Dealer discount for the add-on service | Must not exceed 100% or be negative |

#### Parameters and Session Flags (System)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Query Parameter (`P_QUERY`) | Auto-Populated | Internal flag indicating whether the form is in query-display mode; set and cleared by POST-QUERY and KEY-CLRFRM | System-set only; not user-visible |
| Save Permitted Flag (`P_OKFOR_SAVE`) | Auto-Populated | Internal flag controlling whether saving is permitted | System-set based on form completion state |
| New Record Flag (`NEW_REC`) | Auto-Populated | Set to indicate that a new header record has been inserted via PRE-INSERT | System-set on pre-insert |

### 6.3 Reference Data

*Lists the master and configuration data that the form reads for lookups, drop-down lists, and derived values.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| SMP Service Type List (RG_SRV_TYPE / AM_LIST - list_name 'SMP_SERV_TYPE') | Provides the list of applicable SMP service types the advisor can select from | When the advisor selects the service type field |
| SMP Package List (RG_PACKAGE / VM_SMP_PACKAGE) | Provides the available SMP package codes and descriptions for the selected principal and package list category | When the advisor selects or confirms the package code |
| Active Executive List (RG_EXEC / GM_EMP) | Provides the list of active service executives (vehicle category, not departed) for the advisor to assign to the enquiry | When the advisor selects the executive field |
| Engine Oil Parts (RG_ENGINEOIL / PM_PART + AM_LIST_RANGE) | Provides available engine oil part numbers with descriptions and MRPs for the vehicle and service sub-range | When the package code is validated or the advisor overrides the engine oil |
| Coolant Parts (RG_COOLANT / PM_PART + AM_LIST_RANGE) | Provides available coolant part numbers with descriptions and MRPs for PMS packages | When the package code is validated or the advisor overrides the coolant |
| Vehicle Master (GM_VIN) | Provides the vehicle's VIN, chassis, engine number, model, variant, and last mileage for the entered registration number | When the advisor validates the registration number |
| Vehicle Variant Master (GM_VAR) | Provides the variant description and fuel type for the vehicle | On record query (POST-QUERY) and during registration number validation |
| Model Description Master (VM_SVAR) | Provides the service model description for the vehicle's model code | On record query (POST-QUERY) |
| SMP Package Parameters (VM_SMP_PACKAGE) | Provides the package description and package type for display | When the package code is selected or a record is queried |
| SMP Validity Parameters (VM_SMP_PARAM - EXTERNAL / NOT IN BUNDLE) | Provides the expiry months, expiry mileage, and number of services for a package and vehicle category | During package code validation (SP_PKG_DETAIL) |
| SMP Sub-Service Calendar (VM_SUB_SRV_CAL - EXTERNAL / NOT IN BUNDLE) | Provides the mileage and age-to limits for service sub-categories | During SMP expiry calculation (SP_GET_SMP_EXP) |
| Add-On Service Master (AM_LIST - list_name 'SMP_ADDON') | Provides the list of available add-on services for the principal | When the add-on screen is opened |
| Add-On Service Range (AM_LIST_RANGE) | Provides the minimum and maximum quantity limits and TV parameters for add-on services | During add-on quantity validation and True Value SMP mileage limit check |
| Enquiry Status Description (AM_LIST_RANGE - list_name 'AMC_ENQSTATUS') | Provides the human-readable description for each enquiry status code | On record query (POST-QUERY) |
| City Master (GM_CITY) | Provides the customer's city description | On record query (POST-QUERY) |
| Employee Master (GM_EMP) | Provides the service executive's name | On record query (POST-QUERY) |
| State Master (GM_STATE) | Provides the customer state description with GST state code | During registration number validation and on record query |
| Dealer Location Master (AM_DEALER_LOC) | Provides the dealer's state code and city RPH type for GST and pricing | During registration number validation |
| Parts Master (PM_PART) | Provides part descriptions and MRPs for engine oil and coolant | During package code validation and on record query |
| Operations Master (VM_MSIL_OPR) | Provides operation descriptions for labour line items | On package detail record query (POST-QUERY on B_VD_AMC_ENQ) |
| SMP Package Detail Master (GBL_AMC_DTL - staging) | Temporary storage for computed package line items during an active session | During Generate SMP, Generate Enquiry, discount calculation, and detail display |
| True Value Vehicle Extension (GM_VIN_EXT - via SP_GET_TV_DETAIL, SP_TV_SRV) | Provides True Value resale date, warranty expiry, and service history for pre-owned vehicles | During registration number validation when the vehicle is flagged as True Value |
| Fleet/Commercial Vehicle Data (NI_NEW_MINS - EXTERNAL / NOT IN BUNDLE) | Used to determine whether a vehicle qualifies as a commercial fleet vehicle | During vehicle registration lookup (PKG_SMP.SF_FLEET_CHECK) |

### 6.4 Data Lifecycle

*Describes how SMP enquiry records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- A new SMP enquiry header record is initiated when the advisor enters vehicle details and confirms the vehicle, mileage, service type, package, and TCS decision on a new enquiry (no enquiry number loaded).
- The system records the dealership, location, company, enquiry type ("SMP"), creator user ID, and creation timestamp on the header record automatically when the record is inserted (PRE-INSERT trigger on B_VH_AMC_ENQ).
- Each service detail line is similarly stamped with the creator user ID, creation timestamp, and the parent enquiry number on insert (PRE-INSERT trigger on B_VD_AMC_ENQ).
- The charge records (VD_AMC_ENQCHARGES) are inserted in bulk from the staging area by SP_INSERT_CHARGES immediately before the final commit within KEY-COMMIT.

**Updates**

- The header record's modified user ID and modified timestamp are updated automatically whenever an existing header record is changed (PRE-UPDATE trigger on B_VH_AMC_ENQ).
- The detail record's modified user ID and modified timestamp are similarly updated on change (PRE-UPDATE trigger on B_VD_AMC_ENQ).
- The staging table (GBL_AMC_DTL) is updated by POP_DISC when dealer discounts are applied, and by PKG_SMP.SP_POP_SMP_TAX when tax and charge amounts are computed.

**Save and Commit**

- Saving is initiated by the advisor via the KEY-COMMIT trigger, which first validates the form state, then calls SP_INSERT_CHARGES to write the charge records, then deletes all temporary staging data (GBL_SMP, GBL_AMC_DTL, GBL_AMC_CHARGES) for the current session, and finally commits the header and detail records permanently to the database.
- After a successful commit, the system displays the generated enquiry number and calls CALL_REPORT_ENQ to offer the advisor the option to print the SMP enquiry report (vr_smp_enq).
- When the advisor clears the form (KEY-CLRFRM), all temporary staging records for the session are deleted and all form fields are reset; this does not commit any unsaved enquiry data.

**Retention and Audit**

- The header record carries creation user ID and creation timestamp (`CREATED_BY`, `CREATED_DATE`) and modification user ID and modification timestamp (`MODIFIED_BY`, `MODIFIED_DATE`), set automatically by the pre-insert and pre-update triggers.
- The detail records carry the same four audit stamps.
- No archival or purge policy is evidenced in this form's code.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AMC | Annual Maintenance Contract - a service agreement under which a vehicle receives scheduled maintenance at a fixed contract price | Maintenance Contract | SMP, MCP |
| B_ADDON | Add-on Services block - the form panel where optional add-on services are selected and quantified | Add-On Block | B_VD_AMC_ENQ, Add-on |
| B_ADDON_DLT | Add-on Detail List block - the read-only display panel showing add-on service lines after selection | Add-On Detail Block | B_ADDON |
| B_TCS | TCS block - the radio-button panel where the executive confirms TCS applicability and rate | TCS Block | TCS |
| B_VD_AMC_ENQ | Vehicle Detail AMC Enquiry block - the multi-row panel displaying individual service lines (labour, parts, consumables) for the SMP package | Detail Block | B_VH_AMC_ENQ |
| B_VH_AMC_ENQ | Vehicle Header AMC Enquiry block - the main panel capturing vehicle details, customer details, package selection, and billing summary | Header Block | B_VD_AMC_ENQ |
| CB_VT_AMC_ENQ | Control block - the entry and action panel for enquiry number lookup, discount entry, and action buttons | Control Block | B_VH_AMC_ENQ |
| CDS | Customer Delight Scheme - a special eligibility flag indicating the vehicle qualifies for CDS-linked SMP benefits | | SMP |
| CGST | Central Goods and Services Tax - GST component levied by the central government on intra-state transactions | | GST, SGST, IGST |
| COM | Commercial vehicle classification code - indicates the vehicle is a commercial fleet vehicle | Fleet, CVMS | NCOM, Fleet Type |
| Consumables | Consumable service items in an SMP package - fluids, filters, and other non-durable items used during a service | Cons | Labour, Parts |
| DMS | Dealer Management System - the integrated software platform used by dealerships to manage vehicle sales, service, and customer records | | AMC, SMP |
| DPL | Dealer Platform Library - the shared Oracle Forms program library (.pld) providing common utility procedures used across forms | | PLD, WEBUTIL |
| ENQ_NUM | Enquiry Number - the system-generated unique identifier assigned to each SMP enquiry | Contract Number | VH_AMC_ENQ |
| GBL_AMC_CHARGES | Global AMC Charges working table - a session-level temporary table holding calculated tax and charge lines pending commit | | GBL_AMC_DTL |
| GBL_AMC_DTL | Global AMC Detail working table - a session-level temporary table storing service line items for the in-progress SMP enquiry before final save | | GBL_SMP, VD_AMC_ENQ |
| GBL_SMP | Global SMP working table - a session-level temporary table storing add-on and SMP-specific session data | | GBL_AMC_DTL |
| GST | Goods and Services Tax - the unified Indian indirect tax system replacing earlier taxes; comprises CGST, SGST (intra-state), or IGST (inter-state) | | CGST, SGST, IGST |
| IGST | Integrated Goods and Services Tax - GST component levied on inter-state or SEZ transactions | | GST, CGST, SGST |
| Labour | Labour service items in an SMP package - workshop operations performed by technicians | Lbr | Parts, Consumables |
| LOV | List of Values - a popup selection list in Oracle Forms used to choose from pre-defined options | Dropdown, Picklist | Record Group |
| MCP | Manufacturer-Certified Programme - the manufacturer's scheduled maintenance programme offered through authorised dealerships; used interchangeably with SMP in some contexts | | SMP, AMC |
| NCOM | Non-commercial vehicle classification code - indicates the vehicle is a personal passenger vehicle | Personal Vehicle | COM, Fleet Type |
| Parts | Parts service items in an SMP package - replacement components supplied during a service | Spare Parts | Labour, Consumables |
| PCK | Package - prefix used in the BRD to reference database package routines (PCK-NNN) | | PKG_AMC, PKG_SMP |
| PKG_AMC | AMC database package - provides GST type determination and AMC support logic used by the form | | PKG_SMP |
| PKG_CODE | Package Code - the code identifying the specific SMP package selected for a vehicle | Package | SMP, SERV_TYPE |
| PKG_SMP | SMP database package - the primary business logic package providing vehicle eligibility validation, fleet type determination, service line population, and tax calculation for SMP enquiries | | PKG_AMC |
| PLD | Program Library Definition - a shared Oracle Forms library file (.pld) containing reusable PL/SQL procedures used across multiple forms | | DPL |
| Principal | Principal Map Code - the manufacturer/principal identifier (e.g. a car brand) used as the primary partition key for all database lookups | Principal Map CD | Dealer, DEALER |
| REG_NUM | Registration Number - the vehicle's road registration plate number used as the primary lookup key in the form | Reg No., Plate Number | VIN |
| RPH | Rate Per Hour type - the city-based labour rate category used to determine labour charges for a dealership location | City RPH | Rate, Labour |
| SAC | Services Accounting Code - the HSN/SAC code used for GST classification of service items | HSN, HSN/SAC | GST |
| SERV_TYPE | Service Type - the code identifying the SMP service category (e.g. standard or fleet) for package selection | Service Type | PKG_CODE, SMP |
| SEZ | Special Economic Zone - a designated area with special tax status; SEZ customers always attract IGST regardless of dealer location | | IGST, GST |
| SGST | State Goods and Services Tax - GST component levied by the state government on intra-state transactions | | GST, CGST, IGST |
| SMP | Scheduled Maintenance Programme - an annual service contract under which a vehicle receives a fixed set of scheduled services at a pre-agreed price | Maintenance Plan, MCP | AMC, PKG_SMP |
| TCS | Tax Collected at Source - a tax collected by the seller on sales exceeding ₹50 lakhs in a financial year under Section 206C(1H) of the Income Tax Act | Tax at Source | GST |
| TCS Rate (Higher) | Higher TCS rate - applied when the buyer does not provide a valid PAN or Aadhaar number; rate is 1% | | TCS |
| TCS Rate (Normal) | Normal TCS rate - applied when a valid PAN or Aadhaar number is available; rate is 0.075% up to 31 March 2021 and 0.1% thereafter | | TCS |
| True Value | Maruti Suzuki True Value programme - a certified pre-owned vehicle scheme; vehicles in this scheme may qualify for a special TV SMP package | TV | SMP |
| TV | True Value - abbreviated code used in the form to flag a True Value pre-owned vehicle (NB_TV_SMP, TV_SMP fields) | True Value | SMP |
| VD_AMC_ENQ | Vehicle Detail AMC Enquiry table - the database table storing committed SMP enquiry service detail lines | | VH_AMC_ENQ |
| VH_AMC_ENQ | Vehicle Header AMC Enquiry table - the primary database table storing committed SMP enquiry header records | | VD_AMC_ENQ |
| VIN | Vehicle Identification Number - the unique alphanumeric identifier assigned to each vehicle at manufacture | Chassis / Frame Number | REG_NUM |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vt_smp_enq (VT_SMP_ENQ)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: `WN_MAIN - SMP Enquiry`
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_AMC, PKG_SMP, PK_VALIDATE_BACK_DATE
- Source artifacts: `vt_smp_enq_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DPL (DPL.pld program library); PCK `PKG_AMC.pck`; PCK `PKG_SMP.pck`; PCK `PK_VALIDATE_BACK_DATE.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_LOG | Char | Trigger | Flags application logging; set Y to enable stop_watch timing |
| COMP_FA | Char | ProgramUnit / Trigger | Company/facility code filtering enquiry records |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer code used as filter for all block queries |
| LOC_CD | Char | ProgramUnit / RecordGroup / Trigger | Location code used as filter for all block queries |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group code used as filter across all block queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code (manufacturer) for all database lookups |
| PRINTOUTPUT | Char | ProgramUnit | Report output file name used by the print timer |
| P_FIN_YR | Char | Trigger | Current financial year value passed into the form context for period-sensitive queries and validations |
| REPORTHANDLE | Char | ProgramUnit | Report job handle used to track report execution status |
| REP_SERVER | Char | ProgramUnit | Report server name used to submit report jobs |
| USERID | Char | ProgramUnit / Trigger | Current logged-in user ID stamped on insert and update |

### 8.1.2 Form Parameters

*All 7 ModuleParameter entries from vt_smp_enq_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_QUERY | Char | N | Controls whether form opens in query-only mode; Y = query mode, N = normal entry mode |
| P_OKFOR_SAVE | Char | N | Indicates whether the save operation is permitted from the calling context |
| P_SAVE | Char | N | Triggers automatic save when set to Y on form open |
| CLOSE | Char | N | When Y, closes the form after a successful save operation |
| CHECK_NEW | Char | Y | When Y (default), checks for existing open enquiry before creating a new one |
| NEW_ITEM | Char | Y | When Y (default), enables creation of new enquiry items |
| NEW_REC | Char | N | When N (default), prevents creation of new enquiry records by default |

**Total Parameters:** 7

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENQ | - | 1 | N/N/N/N | Default | Control - enquiry number entry and action button panel |
| B_VH_AMC_ENQ | VH_AMC_ENQ | 1 | Y/Y/Y/N | Delayed | - (standalone primary block) |
| B_VD_AMC_ENQ | VD_AMC_ENQ | 14 | Y/Y/Y/N | Delayed | Detail of B_VH_AMC_ENQ via ENQ_NUM |
| B_ADDON | - | 5 | N/N/N/N | Default | - |
| B_ADDON_DLT | - | 9 | N/N/N/N | Delayed | Detail of B_VH_AMC_ENQ via ENQ_NUM (add-on display list) |
| B_TCS | - | 1 | N/N/N/N | Default | - |

**Total Blocks:** 6 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vt_smp_enq_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| B_VH_AMC_ENQ | Fetches the SMP enquiry header for the current dealer, location, company, and entered enquiry number where enquiry type is SMP | - | parent_group  = :global.parent_group   and dealer_map_cd = :global.dealer  and loc_cd  = :global.loc_cd  and comp_fa =:global.comp_fa  and enq_num = :CB_VT_AMC_ENQ.NB_ENQ_NUM and enq_type = 'SMP' |
| B_VD_AMC_ENQ | Fetches SMP enquiry service detail lines for the current enquiry, excluding serial number 0, ordered by add-on type and serial number | DECODE(NVL(addon_type,'A'), 'A', 1, 2), addon_type, srl_num | parent_group  = :global.parent_group   and dealer_map_cd = :global.dealer  and loc_cd  = :global.loc_cd  and comp_fa =:global.comp_fa  and enq_num = :CB_VT_AMC_ENQ.NB_ENQ_NUM and srl_num > 0 |

### 8.3 Items Summary

*Complete item inventory from `vt_smp_enq_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_VT_AMC_ENQ | 35 | 0 | 35 |
| B_VH_AMC_ENQ | 125 | 51 | 74 |
| B_VD_AMC_ENQ | 33 | 28 | 5 |
| B_ADDON | 9 | 5 | 4 |
| B_ADDON_DLT | 17 | 15 | 2 |
| B_TCS | 1 | 0 | 1 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 16 | 0 | 16 |
| **Total** | **237** | **99** | **138** |

**Item detail (all 237 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENQ | NB_ENQ_NUM | false | Enquiry number search field - entered to fetch an existing SMP enquiry |
| CB_VT_AMC_ENQ | COPY_RIGHT | false | Copyright notice display field |
| CB_VT_AMC_ENQ | STATUS | false | Current enquiry status display |
| CB_VT_AMC_ENQ | PB_GEN_ENQ | false | Generate enquiry button - creates a new SMP enquiry for the vehicle |
| CB_VT_AMC_ENQ | PB_FETCH_DTL | false | Fetch package details button - populates service lines from selected package |
| CB_VT_AMC_ENQ | PB_ADDON | false | Add-on services button - opens add-on selection panel |
| CB_VT_AMC_ENQ | PB_DTL | false | View package detail button - shows package line items |
| CB_VT_AMC_ENQ | NB_STATUS | false | Enquiry status display field |
| CB_VT_AMC_ENQ | PB_TCS_APPLY | false | Apply TCS button - calculates and applies tax collected at source |
| CB_VT_AMC_ENQ | PB_TCS_RATE_N | false | Apply normal TCS rate button - sets TCS at normal rate |
| CB_VT_AMC_ENQ | PB_TCS_RATE_H | false | Apply higher TCS rate button - sets TCS at higher rate |
| CB_VT_AMC_ENQ | SRV_TYPE | false | Vehicle fleet type code (commercial/non-commercial) |
| CB_VT_AMC_ENQ | PKG_LIST_CD | false | Package list code for the selected service type |
| CB_VT_AMC_ENQ | LAB_DISC_IND | false | Labour discount type indicator dropdown |
| CB_VT_AMC_ENQ | PART_DISC_IND | false | Parts discount type indicator dropdown |
| CB_VT_AMC_ENQ | CONS_DISC_IND | false | Consumables discount type indicator dropdown |
| CB_VT_AMC_ENQ | DLR_LAB_DISC | false | Dealer labour discount percentage entry |
| CB_VT_AMC_ENQ | DLR_PART_DISC | false | Dealer parts discount percentage entry |
| CB_VT_AMC_ENQ | DLR_CONS_DISC | false | Dealer consumables discount percentage entry |
| CB_VT_AMC_ENQ | PB_CAL_DISC | false | Calculate discount button - applies dealer discounts to line items |
| CB_VT_AMC_ENQ | PB_CLEAR_DISC | false | Clear discount button - resets all dealer discounts |
| CB_VT_AMC_ENQ | NB_LBR_CNT | false | Labour service line count display |
| CB_VT_AMC_ENQ | NB_PART_CNT | false | Parts service line count display |
| CB_VT_AMC_ENQ | NB_CONS_CNT | false | Consumables service line count display |
| CB_VT_AMC_ENQ | NB_LBR_AMT | false | Total labour amount display |
| CB_VT_AMC_ENQ | NB_PART_AMT | false | Total parts amount display |
| CB_VT_AMC_ENQ | NB_CONS_AMT | false | Total consumables amount display |
| CB_VT_AMC_ENQ | ENGINE_OIL | false | Engine oil part number - selected via LOV |
| CB_VT_AMC_ENQ | ENGINE_OIL_DESC | false | Engine oil description display |
| CB_VT_AMC_ENQ | ENGINE_GROUP | false | Engine oil group code |
| CB_VT_AMC_ENQ | COOLANT | false | Coolant part number - selected via LOV |
| CB_VT_AMC_ENQ | COOLANT_DESC | false | Coolant description display |
| CB_VT_AMC_ENQ | COOLANT_GROUP | false | Coolant group code |
| CB_VT_AMC_ENQ | ENGINE_MRP | false | Engine oil maximum retail price display |
| CB_VT_AMC_ENQ | COOLANT_MRP | false | Coolant maximum retail price display |
| B_VH_AMC_ENQ | PARENT_GROUP | true | Parent group code - identifies the principal/dealer group |
| B_VH_AMC_ENQ | DEALER_MAP_CD | true | Dealer map code - identifies the dealership |
| B_VH_AMC_ENQ | LOC_CD | true | Location code - identifies the dealer outlet |
| B_VH_AMC_ENQ | COMP_FA | true | Company/facility code |
| B_VH_AMC_ENQ | ENQ_TYPE | true | Enquiry type - always SMP for this form |
| B_VH_AMC_ENQ | ENQ_NUM | false | Enquiry number - system-assigned unique identifier |
| B_VH_AMC_ENQ | ENQ_DATE | false | Enquiry date - date the enquiry was created |
| B_VH_AMC_ENQ | REG_NUM | true | Vehicle registration number - primary lookup key |
| B_VH_AMC_ENQ | VIN | true | Vehicle identification number |
| B_VH_AMC_ENQ | VARIANT_CD | true | Vehicle variant code |
| B_VH_AMC_ENQ | CHASSIS_NUM | true | Vehicle chassis number |
| B_VH_AMC_ENQ | ENGINE_NUM | true | Vehicle engine number |
| B_VH_AMC_ENQ | SVAR_CD | true | Sub-variant code |
| B_VH_AMC_ENQ | ODOMETER_READING | true | Current odometer reading in kilometres |
| B_VH_AMC_ENQ | EMP_CD | false | Service executive employee code |
| B_VH_AMC_ENQ | CUST_CD | true | Customer code |
| B_VH_AMC_ENQ | CUST_NAME | true | Customer name |
| B_VH_AMC_ENQ | CUST_ADDR1 | true | Customer address line 1 |
| B_VH_AMC_ENQ | CUST_ADDR2 | true | Customer address line 2 |
| B_VH_AMC_ENQ | CUST_ADDR3 | true | Customer address line 3 |
| B_VH_AMC_ENQ | CITY_CD | true | City code |
| B_VH_AMC_ENQ | CITY_DESC | false | City description display |
| B_VH_AMC_ENQ | PHONE | true | Customer phone number |
| B_VH_AMC_ENQ | MOBILE | true | Customer mobile number |
| B_VH_AMC_ENQ | ENQ_STATUS | true | Enquiry status - O=Open, C=Closed |
| B_VH_AMC_ENQ | CREATED_BY | true | User who created the enquiry record |
| B_VH_AMC_ENQ | CREATED_DATE | true | Date the record was created |
| B_VH_AMC_ENQ | MODIFIED_BY | true | User who last modified the record |
| B_VH_AMC_ENQ | MODIFIED_DATE | true | Date the record was last modified |
| B_VH_AMC_ENQ | NB_MODEL_DESC | false | Model description - fetched from vehicle master (non-DB display) |
| B_VH_AMC_ENQ | NB_VARIANT_DESC | false | Variant description - fetched from vehicle master |
| B_VH_AMC_ENQ | NB_COLOUR_CD | false | Colour code - fetched from vehicle master |
| B_VH_AMC_ENQ | NB_COLOUR_DESC | false | Colour description - fetched from vehicle master |
| B_VH_AMC_ENQ | VAL_FROM_DT | true | Package validity start date |
| B_VH_AMC_ENQ | VAL_TO_DT | true | Package validity end date |
| B_VH_AMC_ENQ | SERV_TYPE | true | Applicable service type code - selected via LOV |
| B_VH_AMC_ENQ | SERV_OPTION | true | Service option indicator - sub-type of service |
| B_VH_AMC_ENQ | PKG_CODE | true | Applicable package code - selected via LOV |
| B_VH_AMC_ENQ | EXPIRY_MONTH | false | Package expiry months display |
| B_VH_AMC_ENQ | PKG_DESC | false | Package description display |
| B_VH_AMC_ENQ | EXPIRY_MILEAGE | false | Package expiry mileage display |
| B_VH_AMC_ENQ | PKG_AMT | true | Total package amount |
| B_VH_AMC_ENQ | LABOUR_AMT | true | Total labour component amount |
| B_VH_AMC_ENQ | PART_AMT | true | Total parts component amount |
| B_VH_AMC_ENQ | CONSUMABLE_AMT | true | Total consumables component amount |
| B_VH_AMC_ENQ | DISCOUNT_AMT | true | MCP discount amount |
| B_VH_AMC_ENQ | SRV_TAX_AMT | true | Service tax amount |
| B_VH_AMC_ENQ | SBC_TAX_AMT | false | Swachh Bharat cess tax amount |
| B_VH_AMC_ENQ | KKC_TAX_AMT | false | Krishi Kalyan cess tax amount |
| B_VH_AMC_ENQ | TOT_BILL_AMT | true | Total billing amount |
| B_VH_AMC_ENQ | NB_ODOMETER_READING | false | Odometer reading display - last RO reading at time of query |
| B_VH_AMC_ENQ | NB_AVG_RUN | false | Average vehicle running display |
| B_VH_AMC_ENQ | NB_VEH_AGE | false | Vehicle age in months display |
| B_VH_AMC_ENQ | NB_CITY_CATG | false | City RPH category display |
| B_VH_AMC_ENQ | NB_FUELTYPE | false | Fuel type display |
| B_VH_AMC_ENQ | NB_VEH_SALE_DT | false | Vehicle sale date display |
| B_VH_AMC_ENQ | NB_AMC_TYPE | false | AMC type display |
| B_VH_AMC_ENQ | EMAIL | true | Customer email address |
| B_VH_AMC_ENQ | NB_TOT_BILL_AMT | false | Total bill amount display (formatted) |
| B_VH_AMC_ENQ | SALE_DT | false | Vehicle sale date formatted display |
| B_VH_AMC_ENQ | RG_GSTTYPE | false | GST type radio group - S=SGST, I=IGST |
| B_VH_AMC_ENQ | CUST_STATE_CD | true | Customer state code for GST calculation |
| B_VH_AMC_ENQ | CUST_SEZ | true | Customer SEZ flag - Y if customer is in Special Economic Zone |
| B_VH_AMC_ENQ | DLR_STATE_CD | true | Dealer state code for GST calculation |
| B_VH_AMC_ENQ | NB_LBR_DISC | false | Labour discount amount display |
| B_VH_AMC_ENQ | NB_PART_DISC | false | Parts discount amount display |
| B_VH_AMC_ENQ | NB_CONS_DISC | false | Consumables discount amount display |
| B_VH_AMC_ENQ | NB_LBR_TAX | false | Labour tax amount display |
| B_VH_AMC_ENQ | NB_PART_TAX | false | Parts tax amount display |
| B_VH_AMC_ENQ | NB_CONS_TAX | false | Consumables tax amount display |
| B_VH_AMC_ENQ | NB_LBR_NET | false | Labour net amount display |
| B_VH_AMC_ENQ | NB_PART_NET | false | Parts net amount display |
| B_VH_AMC_ENQ | NB_CONS_NET | false | Consumables net amount display |
| B_VH_AMC_ENQ | NB_TAX_AMT | false | Total tax amount display |
| B_VH_AMC_ENQ | EMP_NAME | false | Service executive name display |
| B_VH_AMC_ENQ | STATE_DESC | false | Customer state description display |
| B_VH_AMC_ENQ | TCS_APPL_YN | false | TCS applicable flag - Y=applicable, H=higher rate, N=not applicable |
| B_VH_AMC_ENQ | NBT_TCS_DESC | false | TCS description display |
| B_VH_AMC_ENQ | NB_VAL_MIL | false | Package validity mileage display |
| B_VH_AMC_ENQ | NB_VAL_AGE | false | Package validity age display |
| B_VH_AMC_ENQ | NB_SRV_NO | false | Number of services in package display |
| B_VH_AMC_ENQ | NB_SMP_YN | false | SMP eligible flag display |
| B_VH_AMC_ENQ | NB_SUB_SRV | false | Sub-service type display |
| B_VH_AMC_ENQ | NB_CDS_YN | false | CDS applicable flag display |
| B_VH_AMC_ENQ | NO_OF_SRV | true | Number of services in package |
| B_VH_AMC_ENQ | FROM_SUBSRV | true | Package from sub-service number |
| B_VH_AMC_ENQ | TO_SUBSRV | true | Package to sub-service number |
| B_VH_AMC_ENQ | NB_MCP_GEN | false | MCP generated flag display |
| B_VH_AMC_ENQ | NB_MCP_YN | false | MCP created flag display |
| B_VH_AMC_ENQ | NB_DUP_CAN | false | Duplicate enquiry cancellation flag |
| B_VH_AMC_ENQ | NB_LBR_DISC_DLR | false | Dealer labour discount display |
| B_VH_AMC_ENQ | NB_PART_DISC_DLR | false | Dealer parts discount display |
| B_VH_AMC_ENQ | NB_CONS_DISC_DLR | false | Dealer consumables discount display |
| B_VH_AMC_ENQ | DISCOUNT_AMT_DLR | true | Dealer total discount amount |
| B_VH_AMC_ENQ | NB_LBR_DISC_TOT | false | Total labour discount display |
| B_VH_AMC_ENQ | NB_PART_DISC_TOT | false | Total parts discount display |
| B_VH_AMC_ENQ | NB_CONS_DISC_TOT | false | Total consumables discount display |
| B_VH_AMC_ENQ | NB_DISCOUNT_AMT_TOT | false | Total discount amount display |
| B_VH_AMC_ENQ | NB_LBR_SUBTOT | false | Labour sub-total display |
| B_VH_AMC_ENQ | NB_PART_SUBTOT | false | Parts sub-total display |
| B_VH_AMC_ENQ | NB_CONS_SUBTOT | false | Consumables sub-total display |
| B_VH_AMC_ENQ | NB_TOT_SUBTOT | false | Total sub-total display |
| B_VH_AMC_ENQ | LABR_ADDON_AMT | true | Labour add-on amount |
| B_VH_AMC_ENQ | PART_ADDON_AMT | true | Parts add-on amount |
| B_VH_AMC_ENQ | CONS_ADDON_AMT | true | Consumables add-on amount |
| B_VH_AMC_ENQ | ADDON_AMT | true | Total add-on amount |
| B_VH_AMC_ENQ | NB_LBR_SUBTOT_ADD | false | Labour sub-total including add-ons display |
| B_VH_AMC_ENQ | NB_PART_SUBTOT_ADD | false | Parts sub-total including add-ons display |
| B_VH_AMC_ENQ | NB_CONS_SUBTOT_ADD | false | Consumables sub-total including add-ons display |
| B_VH_AMC_ENQ | NB_TOT_SUBTOT_ADD | false | Total sub-total including add-ons display |
| B_VH_AMC_ENQ | NB_TOT_DISC_ADD | false | Total discount including add-ons display |
| B_VH_AMC_ENQ | NB_LBR_DISC_ADD | false | Labour discount on add-ons display |
| B_VH_AMC_ENQ | NB_PART_DISC_ADD | false | Parts discount on add-ons display |
| B_VH_AMC_ENQ | NB_CONS_DISC_ADD | false | Consumables discount on add-ons display |
| B_VH_AMC_ENQ | NB_ADD_LBR_SUBTOT | false | Add-on labour sub-total display |
| B_VH_AMC_ENQ | NB_ADD_PART_SUBTOT | false | Add-on parts sub-total display |
| B_VH_AMC_ENQ | NB_ADD_CONS_SUBTOT | false | Add-on consumables sub-total display |
| B_VH_AMC_ENQ | NB_ADD_TOT_SUBTOT | false | Add-on total sub-total display |
| B_VH_AMC_ENQ | NB_TRUE_VALUE | false | True value vehicle flag - Y if vehicle is True Value pre-owned |
| B_VH_AMC_ENQ | NB_TV_SMP | false | True Value SMP eligibility flag display |
| B_VH_AMC_ENQ | NB_TV_AGE | false | True Value SMP age eligibility parameter |
| B_VH_AMC_ENQ | NB_TV_ODM | false | True Value SMP odometer eligibility parameter |
| B_VH_AMC_ENQ | TV_SMP | true | True Value SMP flag stored value |
| B_VH_AMC_ENQ | TV_FROM_SUBSRV | true | True Value SMP from sub-service |
| B_VH_AMC_ENQ | NB_POC_ODM | false | Pre-owned car selling mileage display |
| B_VD_AMC_ENQ | PARENT_GROUP | true | Parent group code - partition key for detail records |
| B_VD_AMC_ENQ | DEALER_MAP_CD | true | Dealer code - partition key |
| B_VD_AMC_ENQ | LOC_CD | true | Location code - partition key |
| B_VD_AMC_ENQ | COMP_FA | true | Company/facility code - partition key |
| B_VD_AMC_ENQ | ENQ_NUM | false | Enquiry number - links detail to header |
| B_VD_AMC_ENQ | SRL_NUM | true | Serial number - line sequence within the package |
| B_VD_AMC_ENQ | SRV_TYPE | true | Service line type - L=Labour, P=Parts, C=Consumables |
| B_VD_AMC_ENQ | SRV_CODE | true | Service/part code |
| B_VD_AMC_ENQ | NB_SRV_DESC | false | Service or part description display |
| B_VD_AMC_ENQ | QTY | true | Quantity |
| B_VD_AMC_ENQ | DISCOUNT_PER | true | Discount percentage (MCP) |
| B_VD_AMC_ENQ | RATE | true | Unit rate |
| B_VD_AMC_ENQ | BASIC_AMT | true | Basic amount (qty × rate) |
| B_VD_AMC_ENQ | DISCOUNT_AMT | true | Discount amount |
| B_VD_AMC_ENQ | NET_AMT | true | Net amount after discount |
| B_VD_AMC_ENQ | CREATED_BY | true | User who created the line |
| B_VD_AMC_ENQ | CREATED_DATE | true | Date the line was created |
| B_VD_AMC_ENQ | MODIFIED_BY | true | User who last modified the line |
| B_VD_AMC_ENQ | MODIFIED_DATE | true | Date the line was last modified |
| B_VD_AMC_ENQ | NB_CATG_DESC | false | Category description display |
| B_VD_AMC_ENQ | CATG_CD | true | Category code |
| B_VD_AMC_ENQ | GROUP_CD | true | Group code |
| B_VD_AMC_ENQ | NB_NET_AMT | false | Net amount display |
| B_VD_AMC_ENQ | NB_GROUP_DESC | false | Group description display |
| B_VD_AMC_ENQ | HSN_SAC_CODE | true | HSN/SAC code for GST classification |
| B_VD_AMC_ENQ | SELL_PRICE | true | Selling price after discount |
| B_VD_AMC_ENQ | CHARGE_AMT | true | Tax charge amount |
| B_VD_AMC_ENQ | DLR_DISC_IND | true | Dealer discount type indicator |
| B_VD_AMC_ENQ | DLR_DISC | true | Dealer discount percentage |
| B_VD_AMC_ENQ | TOT_AFT_MCP_DISC | true | Total after MCP discount |
| B_VD_AMC_ENQ | TOT_AFT_DLR_DISC | true | Total after dealer discount |
| B_VD_AMC_ENQ | DLR_DISC_AMT | true | Dealer discount amount |
| B_VD_AMC_ENQ | ADDON_TYPE | true | Add-on type code - distinguishes base vs add-on lines |
| B_ADDON | ADDON_CODE | false | Add-on service code |
| B_ADDON | ADDON_DESC | false | Add-on service description |
| B_ADDON | ADDON_CNT | false | Add-on quantity entry |
| B_ADDON | DLR_DISC_IND | true | Dealer discount type indicator for add-on |
| B_ADDON | DLR_DISC | true | Dealer discount percentage for add-on |
| B_ADDON | ADDON_YN | false | Add-on selection checkbox - Y to include this add-on |
| B_ADDON | BASIC_AMT_ADDON | true | Add-on basic amount |
| B_ADDON | DISCOUNT_AMT_ADDON | true | Add-on discount amount |
| B_ADDON | TOT_AFT_MCP_DISC_ADDON | true | Add-on total after MCP discount |
| B_ADDON_DLT | SRV_TYPE | true | Add-on service type |
| B_ADDON_DLT | SRV_CODE | true | Add-on service/part code |
| B_ADDON_DLT | NB_SRV_DESC | false | Add-on service description display |
| B_ADDON_DLT | QTY | true | Add-on quantity |
| B_ADDON_DLT | DISCOUNT_PER | true | Add-on discount percentage |
| B_ADDON_DLT | RATE | true | Add-on unit rate |
| B_ADDON_DLT | BASIC_AMT | true | Add-on basic amount |
| B_ADDON_DLT | DISCOUNT_AMT | true | Add-on discount amount |
| B_ADDON_DLT | NET_AMT | true | Add-on net amount |
| B_ADDON_DLT | GROUP_CD | true | Add-on group code |
| B_ADDON_DLT | NB_GROUP_DESC | false | Add-on group description display |
| B_ADDON_DLT | CHARGE_AMT | true | Add-on tax charge amount |
| B_ADDON_DLT | DLR_DISC_IND | true | Add-on dealer discount type indicator |
| B_ADDON_DLT | DLR_DISC | true | Add-on dealer discount percentage |
| B_ADDON_DLT | TOT_AFT_MCP_DISC | true | Add-on total after MCP discount |
| B_ADDON_DLT | TOT_AFT_DLR_DISC | true | Add-on total after dealer discount |
| B_ADDON_DLT | DLR_DISC_AMT | true | Add-on dealer discount amount |
| B_TCS | NB_TCS_APPL_YN | false | TCS applicability radio group - Y = apply TCS, N = TCS not applicable |
| CB_ERR | TXT_ERR | false | Error message text display item in the inherited error canvas (CN_ERR); shows formatted error or informational message text to the user |
| PB_BLK | PB_EXIT | false | Exit button (inherited from DPL.olb) - closes the current form |
| PB_BLK | PB_LIST | false | LOV button (inherited from DPL.olb) - opens the list of values for the current item |
| PB_BLK | PB_INSERT | false | Insert button (inherited from DPL.olb) - creates a new record in the current block |
| PB_BLK | PM_CONT | false | Continue button (inherited from DPL.olb) - resumes processing after a pause or confirmation |
| PB_BLK | PB_DEL | false | Delete button (inherited from DPL.olb) - marks the current record for deletion |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited from DPL.olb) - cancels pending changes in the current block |
| PB_BLK | PB_SAVE | false | Save button (inherited from DPL.olb) - commits all pending changes to the database |
| PB_BLK | PB_PRINT | false | Print button (inherited from DPL.olb) - initiates the report print action for the current enquiry |
| PB_BLK | PB_CUT | false | Cut button (inherited from DPL.olb) - cuts the selected text from the current item |
| PB_BLK | PB_COPY | false | Copy button (inherited from DPL.olb) - copies the selected text from the current item |
| PB_BLK | PB_PASTE | false | Paste button (inherited from DPL.olb) - pastes clipboard text into the current item |
| PB_BLK | PB_ERR_EXIT | false | Error exit button (inherited from DPL.olb) - dismisses the error canvas without taking action |
| PB_BLK | PB_ERR_OK | false | Error OK button (inherited from DPL.olb) - acknowledges and dismisses the error message on CN_ERR |
| PB_BLK | PB_BACK | false | Back button (inherited from DPL.olb) - navigates back to the previous canvas or block |
| PB_BLK | PB_ADDON_BACK | false | Add-on back button (inherited from DPL.olb) - returns from the add-on selection panel to the main enquiry canvas |
| PB_BLK | PB_ADDON_GEN | false | Add-on generate button (inherited from DPL.olb) - triggers generation of selected add-on service lines; inactive stub in current form version |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_SRV_TYPE | Applicable Service Type | RG_SRV_TYPE | B_VH_AMC_ENQ.SERV_TYPE |
| LV_PACKAGE | Applicable Service Type | RG_PACKAGE | B_VH_AMC_ENQ.PKG_CODE |
| LOV_EXEC | Executives | RG_EXEC | B_VH_AMC_ENQ.EMP_CD |
| LOV_ENGINEOIL | Engine Oil List | RG_ENGINEOIL | CB_VT_AMC_ENQ.ENGINE_OIL |
| LOV_COOLANT | Coolant List | RG_COOLANT | CB_VT_AMC_ENQ.COOLANT |

**Total LOVs:** 5

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_PRINT | Print | (set at runtime) | Inherited from DPL.olb via object group; displayed by GENERAL.PROC_REPORT_CALL when prompting for print destination |
| AL_ERRINFO | Error | (set at runtime) | Inherited from DPL.olb via object group; displayed by GENERAL.RAISE_ERROR and GENERAL.DISP_TEXT for error-severity messages |
| AL_NOTE | Note | (set at runtime) | Inherited from DPL.olb via object group; displayed by GENERAL.DISP_TEXT for informational messages |
| AL_REPORT | AMC Enquiry | Do you want to? | ProgramUnit: CALL_REPORT_ENQ - prompts user to choose report output destination before submitting the SMP enquiry report |
| AL_CONFIRM | Caution | (set at runtime) | Inherited from DPL.olb via object group; displayed by GENERAL.ASK_CONFIRM for user confirmation prompts |
| AL_TCS_DECR | - | Please confirm whether total sale made to the buyer from the seller till date including the current invoice do not exceed 50 lakhs rupees. | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ; Trigger: WHEN-RADIO-CHANGED in B_TCS.NB_TCS_APPL_YN |
| AL_TCS | - | In this case If PAN/ Aadhaar is available rate is 0. 075% upto 31st March 21 and 0.1% after that, if PAN/Aadhar Is not available,  rate is 1%. Please select whether TCS applicable or not.&#10; | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ; Trigger: WHEN-RADIO-CHANGED in B_TCS.NB_TCS_APPL_YN |
| AL_ENQ | MCP Enquiry Exist | Open Enquiry Exist . Existing Enquiry Will Be Cancelled .Want to Continue ? | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM |

**Total Alerts:** 8

### 8.6 Program Units

*Authoritative catalogue of **8 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| CALL_REPORT_ENQ | Procedure | FIND_REPORT_OBJECT, SHOW_ALERT (AL_REPORT), SET_REPORT_OBJECT_PROPERTY, RUN_REPORT_OBJECT, WEB.SHOW_DOCUMENT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER | Generates and launches the SMP enquiry report (PDF or print); prompts user to choose output destination and submits report to report server |
| POP_PKG_DETAILS | Procedure | GBL_AMC_DTL, AM_LIST, CLEAR_BLOCK | Populates the package detail block (B_VD_AMC_ENQ) by reading service lines from the GBL_AMC_DTL working table for the current enquiry and vehicle |
| SP_INSERT_CHARGES | Procedure | VD_AMC_ENQCHARGES, GBL_AMC_CHARGES, GENERAL.DISP_TEXT | Inserts calculated tax and charge lines from GBL_AMC_CHARGES into the VD_AMC_ENQCHARGES table during the commit operation |
| POP_DISC | Procedure | GBL_AMC_DTL, GENERAL.DISP_TEXT | Applies dealer discount values from the control block to all service lines in GBL_AMC_DTL; updates discount amounts and totals |
| POP_DISC_CLEAR | Procedure | GBL_AMC_DTL | Clears all dealer discount fields in the control block and resets GBL_AMC_DTL discount amounts to zero |
| POP_SMP_DETAILS | Procedure | GBL_AMC_DTL, AM_LIST, CLEAR_BLOCK | Refreshes the B_VD_AMC_ENQ detail block with current SMP service lines from GBL_AMC_DTL |
| POP_ADDON_DETAILS | Procedure | GBL_AMC_DTL, GBL_SMP, CLEAR_BLOCK | Populates the add-on detail block (B_ADDON_DLT) from GBL_AMC_DTL and GBL_SMP add-on data |
| POP_DETAILS_AFT_DISC | Procedure | GBL_AMC_DTL, AM_LIST, CLEAR_BLOCK | Refreshes package detail display after discount recalculation; re-reads GBL_AMC_DTL and updates summary fields |

**Total Program Units:** 8

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Presents a modal confirmation dialog to the user; returns the user's response for conditional branching in calling triggers |
| GENERAL.CHECK_NULL | Library routine | B_VH_AMC_ENQ.EMP_CD, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, B_VH_AMC_ENQ.REG_NUM, B_VH_AMC_ENQ.SERV_TYPE, CB_VT_AMC_ENQ.PB_ADDON, CB_VT_AMC_ENQ.PB_FETCH_DTL, CB_VT_AMC_ENQ.PB_GEN_ENQ | Validates that a required field is not null; displays error and raises FORM_TRIGGER_FAILURE if value is null |
| GENERAL.DISP_TEXT | Library routine | B_ADDON.ADDON_CNT, B_ADDON.ADDON_YN, B_ADDON.DLR_DISC, B_VD_AMC_ENQ.DLR_DISC, B_VH_AMC_ENQ, B_VH_AMC_ENQ.ODOMETER_READING, B_VH_AMC_ENQ.PKG_CODE, B_VH_AMC_ENQ.REG_NUM, CB_VT_AMC_ENQ.DLR_CONS_DISC, CB_VT_AMC_ENQ.DLR_LAB_DISC, CB_VT_AMC_ENQ.DLR_PART_DISC, CB_VT_AMC_ENQ.NB_CONS_AMT, CB_VT_AMC_ENQ.NB_CONS_CNT, CB_VT_AMC_ENQ.NB_ENQ_NUM, CB_VT_AMC_ENQ.NB_LBR_AMT, CB_VT_AMC_ENQ.NB_LBR_CNT, CB_VT_AMC_ENQ.NB_PART_AMT, CB_VT_AMC_ENQ.NB_PART_CNT, CB_VT_AMC_ENQ.PB_CAL_DISC, CB_VT_AMC_ENQ.PB_DTL, CB_VT_AMC_ENQ.PB_FETCH_DTL, CB_VT_AMC_ENQ.PB_GEN_ENQ, CB_VT_AMC_ENQ.PB_TCS_APPLY, Form level, ProgramUnit: POP_DISC, ProgramUnit: POP_SMP_DETAILS, ProgramUnit: SP_INSERT_CHARGES | Displays an informational or error alert dialog with the provided message text and title |
| GENERAL.PROC_REPORT_CALL | Library routine | ProgramUnit: CALL_REPORT_ENQ | Configures and submits a report object to the report server for batch printing; returns report handle and output file name |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up error message text by code, displays it with appropriate severity, and raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | FT_INSERT | Insert new record action at form toolbar level | Body is `null;` - insert action suppressed at form level; record creation is controlled through block-level logic instead |
| **Inactive stub** | B_VH_AMC_ENQ | - | KEY-UP | Navigation upward in block | Body is `null;` - upward navigation suppressed; UP key disabled in this block |
| **Inactive stub** | B_VH_AMC_ENQ | - | KEY-DOWN | Navigation downward in block | Body is `null;` - downward navigation suppressed; DOWN key disabled in this block |
| **Inactive stub** | PB_BLK | PB_ADDON_GEN | WHEN-BUTTON-PRESSED | Generate add-on service lines from the add-on panel | Body is `null;` - add-on generation via this button is suppressed; add-on population is handled by WHEN-CHECKBOX-CHANGED on B_ADDON.ADDON_YN instead |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (85 business triggers):**
*vt_smp_enq_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms and database error events; formats and displays error messages using GENERAL.RAISE_ERROR or GENERAL.DISP_TEXT based on error type |
| ON-MESSAGE | Form | - | Form level | Intercepts Oracle Forms informational messages; suppresses standard messages and displays custom text via GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Clears application-info context and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Opens the LOV for the current item using a form-property-adjusted LOV name |
| KEY-COMMIT | Form | - | Form level | Validates entry, inserts charge lines, clears working tables, and commits the SMP enquiry to the database |
| KEY-CLRFRM | Form | - | Form level | Clears the form and deletes working-table data (GBL_SMP, GBL_AMC_DTL, GBL_AMC_CHARGES) for the current session |
| KEY-OTHERS | Form | - | Form level (inherited) | Suppresses unhandled key events at form level; inherited from DPL.olb object group |
| KEY-NEXT-ITEM | Form | - | Form level (inherited) | Handles forward tab navigation between items at form level; inherited from DPL.olb object group |
| KEY-PREV-ITEM | Form | - | Form level (inherited) | Handles backward tab navigation between items at form level; inherited from DPL.olb object group |
| KEY-NXTBLK | Form | - | Form level (inherited) | Navigates to the next block at form level; inherited from DPL.olb object group |
| KEY-PRVBLK | Form | - | Form level (inherited) | Navigates to the previous block at form level; inherited from DPL.olb object group |
| KEY-DOWN | Form | - | Form level (inherited) | Handles downward navigation at form level; inherited from DPL.olb object group |
| KEY-UP | Form | - | Form level (inherited) | Handles upward navigation at form level; inherited from DPL.olb object group |
| FT_CANCEL | Form | - | Form level (inherited) | Cancels pending changes in the current block; inherited from DPL.olb object group |
| FT_INSERT | Form | - | Form level (inherited) | **INACTIVE** - null stub; insert action at form toolbar level is suppressed |
| FT_SAVE | Form | - | Form level (inherited) | Commits all pending changes to the database; inherited from DPL.olb object group |
| FT_DEL | Form | - | Form level (inherited) | Marks the current record for deletion; inherited from DPL.olb object group |
| FT_LIST | Form | - | Form level (inherited) | Opens the LOV for the current item; inherited from DPL.olb object group |
| FT_PRINT | Form | - | Form level (inherited) | Initiates the report print action; inherited from DPL.olb object group |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level (inherited) | Initialises form-level globals, sets session context, and applies parameter-driven behaviour (P_QUERY, P_SAVE, CHECK_NEW) on form startup; inherited from DPL.olb object group |
| PRE-FORM | Form | - | Form level | Sets Oracle application-info client and module context before form opens |
| WHEN-TIMER-EXPIRED | Form | - | Form level | Delegates timer expiry handling to GENERAL.PROC_TIMER_EXPIRED to check report print status |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_ENQ_NUM | CB_VT_AMC_ENQ.NB_ENQ_NUM | Validates that the entered enquiry number exists in VH_AMC_ENQ for the current session globals; raises error if not found |
| KEY-NEXT-ITEM | CB_VT_AMC_ENQ | NB_ENQ_NUM | CB_VT_AMC_ENQ.NB_ENQ_NUM | Moves focus to B_VH_AMC_ENQ.REG_NUM after enquiry number entry |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_GEN_ENQ | CB_VT_AMC_ENQ.PB_GEN_ENQ | Generates a new SMP enquiry; checks for duplicate open enquiry, applies TCS declarations, and calls SP_POP_SMP_TAX to calculate package tax |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_FETCH_DTL | CB_VT_AMC_ENQ.PB_FETCH_DTL | Fetches and populates service package detail lines by calling SP_POP_SMP_PKG_TV or SP_POP_SMP_PKG based on True Value flag |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_ADDON | CB_VT_AMC_ENQ.PB_ADDON | Opens the add-on panel; validates package selection and navigates to B_ADDON block |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_DTL | CB_VT_AMC_ENQ.PB_DTL | Displays current package detail lines by calling POP_PKG_DETAILS or POP_SMP_DETAILS based on enquiry mode |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_APPLY | CB_VT_AMC_ENQ.PB_TCS_APPLY | Navigates to TCS block; calls SP_POP_SMP_TAX to calculate taxes and populates package details |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_RATE_N | CB_VT_AMC_ENQ.PB_TCS_RATE_N | Sets TCS applicability to normal rate (Y) and updates TCS description display |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_TCS_RATE_H | CB_VT_AMC_ENQ.PB_TCS_RATE_H | Sets TCS applicability to higher rate (H) and updates TCS description display |
| WHEN-LIST-CHANGED | CB_VT_AMC_ENQ | LAB_DISC_IND | CB_VT_AMC_ENQ.LAB_DISC_IND | Clears the labour discount percentage entry when the discount indicator type changes |
| WHEN-LIST-CHANGED | CB_VT_AMC_ENQ | PART_DISC_IND | CB_VT_AMC_ENQ.PART_DISC_IND | Clears the parts discount percentage entry when the discount indicator type changes |
| WHEN-LIST-CHANGED | CB_VT_AMC_ENQ | CONS_DISC_IND | CB_VT_AMC_ENQ.CONS_DISC_IND | Clears the consumables discount percentage entry when the discount indicator type changes |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | DLR_LAB_DISC | CB_VT_AMC_ENQ.DLR_LAB_DISC | Validates dealer labour discount entry; checks indicator is set and discount is within range |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | DLR_PART_DISC | CB_VT_AMC_ENQ.DLR_PART_DISC | Validates dealer parts discount entry; checks indicator is set and discount is within range |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | DLR_CONS_DISC | CB_VT_AMC_ENQ.DLR_CONS_DISC | Validates dealer consumables discount entry; checks indicator is set and discount is within range |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_CAL_DISC | CB_VT_AMC_ENQ.PB_CAL_DISC | Calculates and applies dealer discounts to all service lines when in new-enquiry mode |
| WHEN-BUTTON-PRESSED | CB_VT_AMC_ENQ | PB_CLEAR_DISC | CB_VT_AMC_ENQ.PB_CLEAR_DISC | Clears all dealer discount values by calling POP_DISC_CLEAR and refreshes detail display |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_LBR_CNT | CB_VT_AMC_ENQ.NB_LBR_CNT | Validates labour count entry; checks discount indicator and range constraints |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_PART_CNT | CB_VT_AMC_ENQ.NB_PART_CNT | Validates parts count entry; checks discount indicator and range constraints |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_CONS_CNT | CB_VT_AMC_ENQ.NB_CONS_CNT | Validates consumables count entry; checks discount indicator and range constraints |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_LBR_AMT | CB_VT_AMC_ENQ.NB_LBR_AMT | Validates labour override amount; checks discount indicator is set |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_PART_AMT | CB_VT_AMC_ENQ.NB_PART_AMT | Validates parts override amount; checks discount indicator is set |
| WHEN-VALIDATE-ITEM | CB_VT_AMC_ENQ | NB_CONS_AMT | CB_VT_AMC_ENQ.NB_CONS_AMT | Validates consumables override amount; checks discount indicator is set |
| PRE-INSERT | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | Populates partition key fields (PARENT_GROUP, DEALER_MAP_CD, LOC_CD, COMP_FA) from session globals before inserting the enquiry header |
| POST-QUERY | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | Enriches the queried header with vehicle description, variant, colour, package details, city, employee, state, SMP expiry, and summary calculations after each record is fetched |
| PRE-UPDATE | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | Stamps MODIFIED_DATE and MODIFIED_BY from globals before updating the header record |
| KEY-UP | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | **INACTIVE** - null stub; upward navigation is suppressed for this block |
| KEY-DOWN | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | **INACTIVE** - null stub; downward navigation is suppressed for this block |
| WHEN-NEW-BLOCK-INSTANCE | B_VH_AMC_ENQ | - | B_VH_AMC_ENQ | On block entry, executes query and initialises SMP fields when an enquiry number is present; starts stop-watch timer if logging is enabled |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | REG_NUM | B_VH_AMC_ENQ.REG_NUM | Validates registration number exists; fetches vehicle details, checks for duplicate open enquiry, determines True Value SMP eligibility, determines fleet type, and retrieves GST type |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | ODOMETER_READING | B_VH_AMC_ENQ.ODOMETER_READING | Validates odometer reading is provided; calls SP_VIN_VALIDATE to check SMP eligibility based on mileage |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | EMP_CD | B_VH_AMC_ENQ.EMP_CD | Validates service executive code is not null when creating a new enquiry |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | SERV_TYPE | B_VH_AMC_ENQ.SERV_TYPE | Validates service type is selected; looks up eligible package list and determines SMP type via SF_SMP_TYPE |
| WHEN-LIST-CHANGED | B_VH_AMC_ENQ | SERV_OPTION | B_VH_AMC_ENQ.SERV_OPTION | Clears package amounts when service option is changed |
| WHEN-VALIDATE-ITEM | B_VH_AMC_ENQ | PKG_CODE | B_VH_AMC_ENQ.PKG_CODE | Validates package code is selected; retrieves package details, expiry, and default engine oil/coolant parts |
| PRE-INSERT | B_VD_AMC_ENQ | - | B_VD_AMC_ENQ | Populates partition key fields from session globals before inserting detail records |
| PRE-UPDATE | B_VD_AMC_ENQ | - | B_VD_AMC_ENQ | Stamps MODIFIED_DATE and MODIFIED_BY before updating detail records |
| POST-QUERY | B_VD_AMC_ENQ | - | B_VD_AMC_ENQ | Fetches service description, category, and group descriptions after each detail record is queried |
| WHEN-NEW-BLOCK-INSTANCE | B_VD_AMC_ENQ | - | B_VD_AMC_ENQ | On block entry, sets dealer discount indicator to read-only when enquiry number is already set |
| WHEN-NEW-RECORD-INSTANCE | B_VD_AMC_ENQ | - | B_VD_AMC_ENQ | Moves to previous record if the current service code is null (end of detail lines) |
| WHEN-LIST-CHANGED | B_VD_AMC_ENQ | DLR_DISC_IND | B_VD_AMC_ENQ.DLR_DISC_IND | Clears dealer discount percentage and amount fields when discount type indicator changes |
| WHEN-VALIDATE-ITEM | B_VD_AMC_ENQ | DLR_DISC | B_VD_AMC_ENQ.DLR_DISC | Validates dealer discount percentage entry; checks indicator is set and discount is within allowed range |
| WHEN-NEW-BLOCK-INSTANCE | B_ADDON | - | B_ADDON | Navigates to B_ADDON block and populates the add-on list from AM_LIST master |
| WHEN-VALIDATE-ITEM | B_ADDON | ADDON_CNT | B_ADDON.ADDON_CNT | Validates add-on quantity is greater than zero; checks CDS eligibility and maximum allowed count |
| WHEN-LIST-CHANGED | B_ADDON | DLR_DISC_IND | B_ADDON.DLR_DISC_IND | Clears dealer discount percentage when add-on discount type changes |
| WHEN-VALIDATE-ITEM | B_ADDON | DLR_DISC | B_ADDON.DLR_DISC | Validates dealer discount for add-on; checks indicator is set and discount is within allowed range |
| WHEN-CHECKBOX-CHANGED | B_ADDON | ADDON_YN | B_ADDON.ADDON_YN | When add-on is checked, calls SP_POP_SMP_ADDON to populate add-on lines; when unchecked, removes add-on lines from working table |
| WHEN-NEW-BLOCK-INSTANCE | B_TCS | - | B_TCS | Enables the TCS apply button if TCS applicability is already set on the header record |
| WHEN-RADIO-CHANGED | B_TCS | NB_TCS_APPL_YN | B_TCS.NB_TCS_APPL_YN | Sets TCS applicability flag and description on header; enables/disables TCS rate buttons based on radio selection |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Closes the current form; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens the LOV for the current item; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Creates a new record in the current block; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Resumes processing after a pause or confirmation dialog; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Marks the current record for deletion; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels pending changes in the current block; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Commits all pending changes to the database; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Initiates the report print action for the current enquiry; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts selected text from the current item; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies selected text from the current item; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text into the current item; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK | PB_BLK.PB_BACK (inherited) | Navigates back to the previous canvas or block; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ADDON_BACK | PB_BLK.PB_ADDON_BACK (inherited) | Returns from the add-on selection panel to the main enquiry canvas; inherited from DPL.olb object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ADDON_GEN | PB_BLK.PB_ADDON_GEN (inherited) | **INACTIVE** - null stub; add-on generation via this button is suppressed; inherited from DPL.olb object group |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | SMP Enquiry Generation (Rel: 1.0.4) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | - |
| CN_MAIN | Content | - |
| CN_DEF | Stacked | WN_MAIN |
| CN_ERR | Content | - |
| CN_TCS | Content | WN_MAIN |
| CN_ADDON | Content | WN_MAIN |

---

### 8.9 Editors

*No editors found in vt_smp_enq_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*2 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DEFAULT |
| VA_MANDATORY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vt_smp_enq_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*105 DataSourceColumn elements across 3 blocks - formal query column-to-block mapping from vt_smp_enq_fmb.xml.*

#### B_VH_AMC_ENQ (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

#### B_VD_AMC_ENQ (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

#### B_ADDON_DLT (35 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| PRINCIPAL_MAP_CD | NUMBER |
| EWARR_NUM | VARCHAR2 |
| EWARR_DATE | DATE |
| CUST_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| REG_NUM | VARCHAR2 |
| MUL_FIN_YN | VARCHAR2 |
| MUL_FIN_NUM | VARCHAR2 |
| OPTION_CD | VARCHAR2 |
| MAX_MILEAGE | NUMBER |
| VALID_UPTO | DATE |
| PAY_MODE_CD | VARCHAR2 |
| BOOKLET_NUM | VARCHAR2 |
| INSTRUMENT_FAVOUR | VARCHAR2 |
| BRANCH_NAME | VARCHAR2 |
| INSTRUMENT_NUM | VARCHAR2 |
| INSTRUMENT_DATE | DATE |
| BANK_NAME | VARCHAR2 |
| INSTRUMENT_AMT | VARCHAR2 |
| CREDIT_CARD_NUM | VARCHAR2 |
| EXPIRY_DATE | DATE |
| SERVICE_PER | NUMBER |
| SERVICE_AMT | NUMBER |
| PREMIMUM_RECD | NUMBER |
| PREMIMUM_ACTL | NUMBER |
| PREMIMUM_CAL | NUMBER |
| EWARR_AMT | NUMBER |
| PARENT_GROUP | VARCHAR2 |
| DEALER_MAP_CD | NUMBER |
| COMP_FA | VARCHAR2 |
| LOC_CD | VARCHAR2 |
| CREATED_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |

**Total DataSourceColumns:** 105 across 3 blocks

## 9. Object Library

*The DPL Object Library (DPL_olb.xml) provides the shared visual attributes, property classes, and object groups used across Oracle Forms in this application suite. The VT_SMP_ENQ form references this library for standard appearance and behavioural properties.*

Source OLB file(s): DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Grey background, Arial 8pt, black foreground, transparent fill - used for checkbox items | referenced | Checkbox items in the DPL standard layout |
| VA_RB | VisualAttribute | Grey background, Arial 8pt, black foreground, transparent fill - used for radio button items | referenced | Radio button items |
| VA_ICONIC_BUTN | VisualAttribute | White background, black foreground, transparent fill - used for iconic push buttons | referenced | Iconic toolbar buttons |
| VA_DESC | VisualAttribute | Grey background, Small Fonts 7pt, medium weight, blue foreground - used for description display items | referenced | Description display fields |
| VA_NUM | VisualAttribute | White background, Arial 8pt, medium weight, black foreground - used for numeric input items | referenced | Numeric text items |
| VA_MAND | VisualAttribute | Cyan background, Arial 9pt, medium weight, black foreground - used to visually mark mandatory items | referenced | Mandatory text items |
| VA_OPROMPT | VisualAttribute | Prompt type; white background, Arial 9pt, black prompt foreground - optional field prompt styling | referenced | Optional field prompt labels |
| VA_MPROMPT | VisualAttribute | Prompt type; white background, Arial 9pt, red prompt foreground - mandatory field prompt styling | referenced | Mandatory field prompt labels |
| VA_TEXT | VisualAttribute | White background, Arial 9pt, medium weight, black foreground - general text item styling | referenced | Standard text fields |
| VA_BUTN | VisualAttribute | Grey background, Arial 10pt, bold, black foreground - standard push button styling | referenced | Action push buttons |
| VA_ALERT | VisualAttribute | Grey background, MT Extra 11pt, demilight - alert dialog styling | referenced | Alert dialog objects |
| VA_TITLE | VisualAttribute | Grey background, Arial 10pt, bold, blue foreground - canvas section title styling | referenced | Section title display items |
| VA_TRNI_DT | VisualAttribute | White background, Courier, bold, black foreground - used for transaction date fields | referenced | Transaction date fields |
| VA_LOV | VisualAttribute | Grey background, Arial 9pt, dark blue foreground - LOV list item styling | referenced | List of values items |
| VA_DISP | VisualAttribute | RGB (r25g75b75) background, Arial 8pt, bold, black foreground - used for calculated/display-only items | referenced | Display-only computed fields |
| PC_DESC | PropertyClass | Left-justified display item; Arial 9pt, blue foreground, max 110 chars, no bevel - standard description display | referenced | Description display items |
| PC_SC_DATE | PropertyClass | Date display item; Arial 8pt, bold, blue foreground; format DD-MM-YY; hint shown on entry | referenced | Short date display fields |
| PC_TITLE | PropertyClass | Centre-justified text item; Arial 10pt, bold, blue foreground, uppercase | referenced | Section title items |
| PC_FORMAT | PropertyClass | Centre-justified text item; Arial 9pt, max 12 chars, uppercase | referenced | Formatted code fields |
| PC_MR_BLK | PropertyClass | Block-level; navigation to PB_BLK on next; vertical orientation, change-record navigation | referenced | Multi-record block definitions |
| PC_DISP | PropertyClass | Left-justified display item; Arial 9pt, grey8 background, lowered bevel, non-navigable - standard read-only field | referenced | Read-only display items |
| PC_LOV | PropertyClass | LOV-enabled text item; Arial 8pt, grey background, dark blue foreground; LOV at position 80,96; auto-select off | referenced | LOV-linked text items |
| PC_FORM | PropertyClass | Form-level class; validation at item level; savepoint off; menu module menu.mmx; includes ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM triggers | referenced | Form-level properties |
| PC_DISP_DATE | PropertyClass | Date display item; Arial 9pt, grey8 background, DD-MM-RRRR format mask, non-navigable | referenced | Date display-only fields |
| PC_DISP_NUM | PropertyClass | Right-justified numeric display item; Arial 9pt, grey8 background, lowered bevel, non-navigable | referenced | Numeric display-only fields |
| PC_DATE | PropertyClass | Date text item; Arial 9pt, DD-MM-RRRR format, mouse navigate, hint for entry format; popup menu POP_MAIN | referenced | Editable date input fields |
| PC_DTTIME | PropertyClass | Date/time text item; Arial, DD-MM-RRRR HH24:MI format, initialised to database datetime | referenced | Date-time input fields |
| PC_CB | PropertyClass | Checkbox item; Arial 9pt, white background | referenced | Checkbox items |
| PC_ALERT | PropertyClass | Alert object; grey background, MT Extra 11pt, demilight | referenced | Alert objects |
| PC_MDATE | PropertyClass | Mandatory date text item; DD-MM-RRRR format; red prompt foreground; WHEN-VALIDATE-ITEM enforces non-null | referenced | Mandatory date fields |
| PC_RB | PropertyClass | Radio button item; grey background, Arial 9pt, black foreground | referenced | Radio button groups |
| PC_WIND | PropertyClass | Window-level class; resizable, closeable, hide on exit, grey background, blue foreground, Arial 10pt | referenced | Window objects |
| PC_CANV | PropertyClass | Canvas class; white background, Arial, window WN_MAIN, raise on enter | referenced | Canvas objects |
| PC_BUTN | PropertyClass | Push button class; Arial 9pt, bold, grey background, no mouse navigate | referenced | Standard action buttons |
| PC_TEXT | PropertyClass | Left-justified text item; Arial 9pt, mixed case, white background, popup POP_MAIN | referenced | Standard editable text items |
| PC_MTEXT | PropertyClass | Mandatory text item; red prompt foreground; WHEN-VALIDATE-ITEM enforces non-null | referenced | Mandatory text input fields |
| PC_UTEXT | PropertyClass | Left-justified uppercase text item; Arial 9pt, white background, popup POP_MAIN | referenced | Uppercase text fields |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item; red prompt foreground; WHEN-VALIDATE-ITEM enforces non-null | referenced | Mandatory uppercase fields |
| PC_NUM | PropertyClass | Right-justified numeric text item; Arial 9pt, lowest value 0, white background | referenced | Numeric input fields |
| PC_MNUM | PropertyClass | Mandatory numeric text item; red prompt foreground; WHEN-VALIDATE-ITEM enforces non-zero | referenced | Mandatory numeric fields |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button; 20-wide, no mouse navigate, no bevel | referenced | Iconic action buttons |
| PC_SCROLL | PropertyClass | Scrollbar width 13 - scrollbar styling | referenced | Scrollable regions |
| VA_DEFAULT | VisualAttribute | Default visual attribute referenced across the form for standard item appearance | referenced | General purpose items across the form |
| VA_MANDATORY | VisualAttribute | Visual attribute referenced for marking mandatory items on the form | referenced | Mandatory items across the form |
| OG_GROUP | ObjectGroup | Object group sourced from DPL_MTPL.fmb; contains KEY-OTHERS, KEY-NEXT-ITEM, KEY-PREV-ITEM subclassed triggers | 1 | Form-level keyboard navigation trigger group |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_SRV_TYPE | Query | LV_SRV_TYPE | LIST_CODE | LIST_DESC | Yes - B_VH_AMC_ENQ, CB_VT_AMC_ENQ | Lists available SMP service types for the selected vehicle and package context | LV_SRV_TYPE -> B_VH_AMC_ENQ.SERV_TYPE |
| RG_PACKAGE | Query | LV_PACKAGE | PKG_TYPE | PKG_DESC | Yes - CB_VT_AMC_ENQ | Lists applicable SMP packages available for the selected service type and vehicle | LV_PACKAGE -> B_VH_AMC_ENQ.PKG_CODE |
| RG_ENGINEOIL | Query | LOV_ENGINEOIL | PART_NUM | PART_DESC | Yes - B_VH_AMC_ENQ, CB_VT_AMC_ENQ | Lists available engine oil parts for selection as the default engine oil in the enquiry | LOV_ENGINEOIL -> CB_VT_AMC_ENQ.ENGINE_OIL |
| RG_COOLANT | Query | LOV_COOLANT | PART_NUM | PART_DESC | Yes - B_VH_AMC_ENQ, CB_VT_AMC_ENQ | Lists available coolant parts for selection as the default coolant in the enquiry | LOV_COOLANT -> CB_VT_AMC_ENQ.COOLANT |
| RG_EXEC | Query | LOV_EXEC | EMP_CD | EMP_NAME | No | Lists service executives available for assignment to the SMP enquiry | LOV_EXEC -> B_VH_AMC_ENQ.EMP_CD |

**Total Record Groups:** 5

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_VT_AMC_ENQ | - | - | No |
| B_VH_AMC_ENQ | VH_AMC_ENQ | - | Yes |
| B_VD_AMC_ENQ | VD_AMC_ENQ | - | Yes |
| B_ADDON | - | - | No |
| B_ADDON_DLT | - | - | No |
| B_TCS | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-VALIDATE-ITEM | Dealer location master - holds state code, channel, and city RPH type for each dealer outlet |
| `AM_DEALER_LOC_PARAM` | - | Trigger WHEN-NEW-FORM-INSTANCE | Dealer location parameter master - queried at form startup to retrieve dealer-level configuration parameters governing form behaviour |
| `AM_LIST` | - | POP_DETAILS_AFT_DISC, POP_PKG_DETAILS, POP_SMP_DETAILS, RG_SRV_TYPE, Trigger POST-QUERY, Trigger WHEN-CHECKBOX-CHANGED, Trigger WHEN-NEW-BLOCK-INSTANCE, Trigger WHEN-VALIDATE-ITEM | AMC list master - provides configurable list values (service types, SMP parameters, add-on categories) used across the form |
| `AM_LIST_RANGE` | - | RG_EXEC, Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | AMC list range master - stores range-based configuration parameters including SMP eligibility limits and exception models |
| `DUAL` | - | Trigger WHEN-VALIDATE-ITEM | Oracle system table - used for date formatting calculations |
| `GBL_AMC_CHARGES` | - | Trigger KEY-CLRFRM, Trigger KEY-COMMIT | Global AMC charges working table - holds calculated tax and charge lines pending commit or clear |
| `GBL_AMC_DTL` | - | POP_ADDON_DETAILS, POP_DETAILS_AFT_DISC, POP_DISC, POP_DISC_CLEAR, POP_PKG_DETAILS, POP_SMP_DETAILS, Trigger KEY-CLRFRM, Trigger KEY-COMMIT, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-CHECKBOX-CHANGED | Global AMC detail working table - stores service line items for the in-progress SMP enquiry before final commit |
| `GBL_SMP` | - | POP_ADDON_DETAILS, Trigger KEY-CLRFRM, Trigger KEY-COMMIT, Trigger WHEN-CHECKBOX-CHANGED | Global SMP working table - stores add-on and SMP-specific data for the current enquiry session |
| `GM_CITY` | - | Trigger POST-QUERY | City master - provides city description for the vehicle customer city code |
| `GM_EMP` | - | RG_EXEC, Trigger POST-QUERY | Employee master - provides executive name and list of service executives for LOV selection |
| `GM_STATE` | - | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | State master - provides GST state code and state description for GST type determination |
| `GM_VAR` | - | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Vehicle variant master - provides fuel type and variant details for fleet and SMP eligibility checks |
| `GM_VIN` | - | Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Vehicle identification number master - primary source for vehicle details, sale date, odometer, model, and customer linkage |
| `PI_PM_PART_MRP` | - | RG_COOLANT, RG_ENGINEOIL | Part MRP master - provides maximum retail price for engine oil and coolant parts in LOV queries |
| `PM_PART` | - | RG_COOLANT, RG_ENGINEOIL, Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | Part master - provides part description and part details for engine oil, coolant, and package service items |
| `SH_POC_INVOICE` | - | Trigger WHEN-VALIDATE-ITEM | Pre-owned car invoice - provides selling mileage for True Value SMP eligibility calculation |
| `VD_AMC_ENQ` | - | B_VD_AMC_ENQ | AMC enquiry service detail - stores service line items for committed SMP enquiry records |
| `VD_AMC_ENQCHARGES` | - | SP_INSERT_CHARGES | AMC enquiry charge detail - stores tax and charge lines inserted during enquiry commit |
| `VH_AMC_ENQ` | - | B_VH_AMC_ENQ, Trigger FT_SAVE, Trigger WHEN-VALIDATE-ITEM | AMC enquiry header - primary table for SMP enquiry records; stores vehicle, customer, package, and amount details; also referenced directly in Trigger FT_SAVE for save-time validation and updates |
| `VH_RO` | - | Trigger WHEN-VALIDATE-ITEM | Vehicle repair order - queried to determine last service sub-category and True Value TV3 RO status |
| `VM_MENU_CD` | - | RG_COOLANT, RG_ENGINEOIL | Menu code master - used in conjunction with part MRP to list engine oil and coolant options |
| `VM_MSIL_OPR` | - | Trigger POST-QUERY | MSIL operation master - provides operation description for labour service codes in detail post-query |
| `VM_SMP_PACKAGE` | - | RG_PACKAGE, Trigger POST-QUERY, Trigger WHEN-VALIDATE-ITEM | SMP package master - defines available SMP packages with expiry months, mileage, and service count |
| `VM_SVAR` | - | Trigger POST-QUERY | Sub-variant master - provides sub-variant description for vehicle model display |

**Total Referenced Objects:** 24

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO (Oracle built-in) | Records the form module identity in the current database session for monitoring |
| BR-003 | SP_VALIDATE_ALPHANUMERIC | Strips non-alphanumeric characters from the registration number before lookup |
| BR-003 | SP_GET_VEH_DETAILS | Retrieves vehicle identification and customer profile for the entered registration number |
| BR-003 | PKG_SMP.SF_FLEET_CHECK | Determines whether the vehicle is a commercial/fleet vehicle |
| BR-003 | SP_GET_TV_DETAIL | Retrieves True Value resale and warranty details for pre-owned vehicles |
| BR-003 | SP_TV_SRV | Validates whether a True Value SMP service window is still active for the vehicle |
| BR-003 | PKG_AMC.SP_GET_GST_TYPE | Derives the applicable GST category and retrieves dealer/customer state codes |
| BR-003 | PKG_SMP.SP_VIN_VALIDATE | Validates SMP eligibility and returns plan validity parameters |
| BR-003 | SP_VALIDATE_OEMVIN | Validates the OEM VIN format and authenticity for the entered registration |
| BR-004 | PKG_SMP.SP_VIN_VALIDATE | Re-validates SMP eligibility at the entered mileage |
| BR-005 | GENERAL.CHECK_NULL | Validates the service executive field is not blank |
| BR-006 | GENERAL.CHECK_NULL | Validates the service type field is not blank |
| BR-006 | PKG_SMP.SF_SMP_TYPE | Determines the applicable package list category for the vehicle, service type, and mileage |
| BR-008 | GENERAL.CHECK_NULL | Validates the package code field is not blank |
| BR-008 | PKG_SMP.SP_PKG_DETAIL | Retrieves expiry months, expiry mileage, and number of services for the selected package |
| BR-008 | PKG_SMP.SP_GET_SMP_EXP | Retrieves the SMP contract expiry date and mileage for the service sub-range |
| BR-008 | PKG_SMP.SP_GET_DEFAULT_PART | Determines and returns the recommended engine oil and coolant default parts |
| BR-009 | GENERAL.CHECK_NULL | Validates the package code before generating SMP detail lines |
| BR-009 | PKG_SMP.SP_POP_SMP_PKG | Computes and stages the full SMP package line items for standard vehicles |
| BR-009 | PKG_SMP.SP_POP_SMP_PKG_TV | Computes and stages the True Value SMP package line items |
| BR-009 | POP_SMP_DETAILS | Loads staged line items into the on-screen package detail grid |
| BR-011 | PKG_SMP.SP_POP_SMP_TAX | Computes GST and TCS charges for all staged package line items |
| BR-011 | POP_PKG_DETAILS | Loads fully costed line items (including tax) into the detail grid |
| BR-012 | POP_PKG_DETAILS | Loads line items from staging into the detail grid for review |
| BR-013 | PKG_SMP.SP_POP_SMP_TAX | Re-runs tax computation with the selected TCS rate |
| BR-013 | POP_PKG_DETAILS | Refreshes the detail grid after TCS tax recalculation |
| BR-014 | GENERAL.CHECK_NULL | Validates package code before navigating to the add-on screen |
| BR-015 | PKG_SMP.SP_POP_SMP_ADDON | Computes and stages add-on service line items for a selected add-on |
| BR-015 | POP_ADDON_DETAILS | Loads add-on line items from staging into the add-on detail section |
| BR-020 | POP_DISC | Writes dealer discount values to the staging table line items |
| BR-020 | POP_DETAILS_AFT_DISC | Reloads the detail grid after dealer discounts are applied |
| BR-021 | POP_DISC_CLEAR | Clears all dealer discount values from the staging table and resets header fields |
| BR-021 | POP_DETAILS_AFT_DISC | Refreshes the detail grid after discounts are cleared |
| BR-022 | GENERAL.CHECK_FORM_FAILURE | Validates the form is in a committable state before saving |
| BR-022 | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Generates the next sequential enquiry document number at save time |
| BR-022 | SP_INSERT_CHARGES | Inserts charge records from staging into the permanent charges table |
| BR-022 | CALL_REPORT_ENQ | Runs the SMP enquiry report after a successful save |
| BR-023 | SF_COPYRIGHT_DECLARATION | Returns the copyright text for the copyright notice field after form clear |
| BR-027 | GENERAL.PROC_TIMER_EXPIRED | Handles performance timer expiry for application logging |
| BR-029 | PKG_SMP.SP_GET_SMP_EXP | Retrieves SMP expiry parameters when an enquiry record is queried for display |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before destructive or irreversible operations |
| - | GENERAL.DISP_TEXT | Displays informational and error messages throughout the form |
| - | GENERAL.PROC_REPORT_CALL | Configures and submits the enquiry report to the report server |
| - | GENERAL.PROC_TIMER | Creates the repeating timer used to poll report-server job status |
| - | GENERAL.RAISE_ERROR | Looks up and displays Oracle Forms/database error messages from the ON-ERROR trigger |
| - | SF_GET_AMLIST | Retrieves a configurable AM_LIST value by key for use in form logic |
| - | SF_TODATE | Converts a string representation to an Oracle DATE for use in date calculations |
| - | SP_VALIDATE_OEMVIN | Validates the OEM VIN format and authenticity during registration number validation |
| - | STOP_WATCH.STOP_TIMER | Records elapsed time for the save operation in the performance logging infrastructure |

---

### 12.2 Procedure and Package Catalogue

#### CALL_REPORT_ENQ

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| CALL_REPORT_ENQ | Form Program Unit | KEY-COMMIT trigger (Form) | Runs the SMP enquiry report (vr_smp_enq) for the saved enquiry; displays a print/skip alert and executes the report via the report server when the advisor confirms |

#### POP_ADDON_DETAILS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_ADDON_DETAILS | Form Program Unit | WHEN-CHECKBOX-CHANGED on B_ADDON.ADDON_YN | Reads add-on line items from GBL_AMC_DTL that are linked to selected add-on types in GBL_SMP, and loads them into the add-on detail section of the screen |

#### POP_DETAILS_AFT_DISC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_DETAILS_AFT_DISC | Form Program Unit | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CLEAR_DISC | Reloads the detail grid from GBL_AMC_DTL after dealer discounts are applied or cleared, reflecting the updated discount amounts and sub-totals |

#### POP_DISC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_DISC | Form Program Unit | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC | Iterates through all staging table line items (GBL_AMC_DTL) and writes the dealer discount indicator, discount amount, and after-dealer-discount total for each line based on the header-level discount entries |

#### POP_DISC_CLEAR

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_DISC_CLEAR | Form Program Unit | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CLEAR_DISC | Resets all header-level discount indicators to percentage type, clears the discount value fields, and removes all dealer discount values from the staging table |

#### POP_PKG_DETAILS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_PKG_DETAILS | Form Program Unit | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_DTL; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_TCS_APPLY | Reads all line items from the staging table (GBL_AMC_DTL) for the current registration and package and populates the on-screen package detail grid with service codes, descriptions, quantities, rates, discounts, net amounts, and charge amounts |

#### POP_SMP_DETAILS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| POP_SMP_DETAILS | Form Program Unit | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL | Reads staged line items from GBL_AMC_DTL for the current registration and package, populates the on-screen detail grid, and computes summary totals for labour, parts, consumables, and discounts |

#### SP_INSERT_CHARGES

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_INSERT_CHARGES | Form Program Unit | KEY-COMMIT trigger (Form) | Inserts all computed charge records from the staging table (GBL_AMC_CHARGES) into the permanent charges table (VD_AMC_ENQCHARGES), assigning the generated enquiry number |

#### GENERAL.ASK_CONFIRM

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | Attached Library (DPL.pld) | Trigger: FT_CANCEL (Form); Trigger: FT_DEL (Form); WHEN-BUTTON-PRESSED on PB_BLK.PB_COPY; WHEN-BUTTON-PRESSED on PB_BLK.PB_CUT; WHEN-BUTTON-PRESSED on PB_BLK.PB_DEL; WHEN-BUTTON-PRESSED on PB_BLK.PB_EXIT; WHEN-BUTTON-PRESSED on PB_BLK.PB_INSERT; WHEN-BUTTON-PRESSED on PB_BLK.PB_LIST; WHEN-BUTTON-PRESSED on PB_BLK.PB_PASTE; WHEN-BUTTON-PRESSED on PB_BLK.PB_PRINT | Presents a confirmation dialog containing the supplied message text and returns the user's response as a NUMBER; called before destructive or irreversible operations such as deletion, cut, exit without saving, and similar actions |

#### GENERAL.CHECK_FORM_FAILURE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.CHECK_FORM_FAILURE | Attached Library (DPL.pld) | KEY-COMMIT trigger (Form) | Checks whether the form completed its last operation successfully; if not, displays the relevant Oracle or Forms error message and raises a trigger failure |

#### GENERAL.CHECK_NULL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.CHECK_NULL | Attached Library (DPL.pld) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.EMP_CD; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.SERV_TYPE; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.PKG_CODE; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_ADDON; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ | Verifies that a given field value is not null/blank, raising an error with the field's business label if empty |

#### GENERAL.DISP_TEXT

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Attached Library (DPL.pld) | POP_DISC; POP_SMP_DETAILS; SP_INSERT_CHARGES; Trigger FT_SAVE (Form); Trigger KEY-COMMIT (Form); Trigger ON-ERROR (Form); Trigger ON-MESSAGE (Form); POST-QUERY on B_VH_AMC_ENQ; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_CAL_DISC; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_DTL; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_TCS_APPLY; WHEN-CHECKBOX-CHANGED on B_ADDON.ADDON_YN; WHEN-NEW-FORM-INSTANCE (Form); multiple WHEN-VALIDATE-ITEM triggers | Displays an informational or error alert dialog using AL_ERRINFO for Error-titled messages and AL_NOTE for all other titles; called pervasively throughout the form for error reporting, validation messages, informational notes, and status updates |

#### GENERAL.PROC_REPORT_CALL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.PROC_REPORT_CALL | Attached Library (DPL.pld) | POP_SMP_DETAILS program unit (via CALL_REPORT_ENQ) | Configures a report object for batch print output to a file on the server, sets execution mode to BATCH, destination type to FILE, and report server from the REP_SERVER global; submits the report via RUN_REPORT_OBJECT and returns the report job handle and output file name for polling |

#### GENERAL.PROC_TIMER

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.PROC_TIMER | Attached Library (DPL.pld) | CALL_REPORT_ENQ program unit | Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5-second interval to poll the report server for the status of a submitted print job; invoked after PROC_REPORT_CALL to start the polling cycle |

#### GENERAL.PROC_TIMER_EXPIRED

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.PROC_TIMER_EXPIRED | Attached Library (DPL.pld) | WHEN-TIMER-EXPIRED trigger (Form) | Handles the PRINTER_QUEUE timer expiry event; reads the report handle and print output file name from global variables, checks report execution status via REPORT_OBJECT_STATUS, and either displays the output document in the browser, continues waiting, or raises an error and deletes the timer |

#### GENERAL.RAISE_ERROR

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.RAISE_ERROR | Attached Library (DPL.pld) | ON-ERROR trigger (Form) | Looks up an error message by code, classifies it as Error, Note, or Caution, and displays the message with the appropriate title using GENERAL.DISP_TEXT; raises FORM_TRIGGER_FAILURE for Error-type messages to halt processing |

#### PKG_AMC.SP_GET_GST_TYPE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_AMC.SP_GET_GST_TYPE | Database Package (PKG_AMC) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Determines the applicable GST category and retrieves the dealer and customer GST state codes and SEZ status for the registration; returns SGST when dealer and customer states match, IGST when states differ or the customer is in a Special Economic Zone |

#### PKG_SMP.SF_FLEET_CHECK

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SF_FLEET_CHECK | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Determines whether the vehicle is a commercial fleet vehicle by checking GM_VAR for CVMS service flag and NI_NEW_MINS for commercial vehicle type codes C1/C2; returns 'COM' for commercial and 'NCOM' for non-commercial |

#### PKG_SMP.SF_SMP_TYPE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SF_SMP_TYPE | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.SERV_TYPE | Determines the SMP sub-service number for a vehicle based on its odometer reading and service history; compares the vehicle's last completed repair order sub-category against AM_LIST SMP service types and evaluates odometer against VM_SMP calibration rules to select the applicable sub-service |

#### PKG_SMP.SP_GET_DEFAULT_PART

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_GET_DEFAULT_PART | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.PKG_CODE | Retrieves the default engine oil or coolant part number for the vehicle variant from VM_MENU_CD; determines old vs new coolant type using GM_VIN_EXT and AM_LIST (BLUE_COOLANT_DT) and returns the part number and MRP from PI_PM_PART_MRP |

#### PKG_SMP.SP_GET_SMP_EXP

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_GET_SMP_EXP | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.PKG_CODE; POST-QUERY on B_VH_AMC_ENQ | Calculates the SMP package expiry parameters for a vehicle and service/sub-service combination; reads VM_SUB_SRV_CAL to derive maximum odometer and vehicle age limits, applies SMP_PARAM override from AM_LIST_RANGE when age exceeds threshold, and returns expiry age in years, mileage, and calculated expiry date based on vehicle invoice date |

#### PKG_SMP.SP_PKG_DETAIL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_PKG_DETAIL | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.PKG_CODE | Retrieves SMP package master details for a given fleet type and package code from VM_SMP_PARAM; returns expiry months, expiry mileage, and number of services included in the package |

#### PKG_SMP.SP_POP_SMP_ADDON

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_POP_SMP_ADDON | Database Package (PKG_SMP) | WHEN-CHECKBOX-CHANGED on B_ADDON.ADDON_YN | Populates or removes add-on service lines in GBL_AMC_DTL when the user checks or unchecks an add-on checkbox; fetches city RPH type and vehicle details, determines applicable discount, and inserts labour, parts, and consumable lines with rates and discount amounts for the selected add-on |

#### PKG_SMP.SP_POP_SMP_PKG

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_POP_SMP_PKG | Database Package (PKG_SMP) | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL (standard SMP path) | Populates all SMP package service lines into GBL_AMC_DTL for the selected vehicle and package; retrieves city RPH type, vehicle variant, and applicable discount, then inserts labour, parts, and consumable lines with rates, quantities, and discount amounts from package definition tables; handles engine oil and coolant lines with MRP |

#### PKG_SMP.SP_POP_SMP_PKG_TV

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_POP_SMP_PKG_TV | Database Package (PKG_SMP) | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_FETCH_DTL (TV SMP path) | Populates SMP service detail lines for True Value pre-owned vehicles into GBL_AMC_DTL; resolves city RPH type, retrieves vehicle identity from GM_VIN, determines coolant type using GM_VIN_EXT and BLUE_COOLANT_DT cutoff, verifies SMP discount record in VM_SMP_DISC, and iterates over True Value SMP service definitions in VM_MENU_CD to insert labour, parts, and consumable lines with TV3-specific sub-service mapping |

#### PKG_SMP.SP_POP_SMP_TAX

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_POP_SMP_TAX | Database Package (PKG_SMP) | WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_GEN_ENQ; WHEN-BUTTON-PRESSED on CB_VT_AMC_ENQ.PB_TCS_APPLY | Calculates and inserts GST tax charge lines into GBL_AMC_CHARGES for all service lines in GBL_AMC_DTL; applies labour and parts tax codes from VM_DLR_LTS, evaluates CGST/SGST or IGST based on GST type, and optionally applies TCS charges |

#### PKG_SMP.SP_VIN_VALIDATE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PKG_SMP.SP_VIN_VALIDATE | Database Package (PKG_SMP) | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM; WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.ODOMETER_READING | Validates VIN eligibility for SMP enrolment; checks vehicle exists, verifies no active MCP, validates OEM VIN, determines fleet type and applicable sub-service number from odometer reading and service history; returns SMP eligibility flag, validity mileage, validity age, service number, sub-service, CDS flag, and error details |

#### PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM | Database Package (PK_VALIDATE_BACK_DATE) | FT_SAVE trigger (Form) | Generates the next sequential document number for an AMC enquiry at save time; accepts dealer, principal, location, company, and document-type identifiers and returns the next available document number with any error code and message, ensuring each saved enquiry receives a unique, centrally controlled reference number |

#### SF_COPYRIGHT_DECLARATION

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Standalone Database Function | KEY-CLRFRM trigger (Form) | Returns the copyright declaration text for display in the copyright notice field |

#### SF_GET_AMLIST

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_GET_AMLIST | Standalone Database Function | Multiple triggers and program units throughout the form | Retrieves a configurable AM_LIST value by key for use in form logic; provides a single-call interface to the AM_LIST configuration master for parameter lookups |

#### SF_TODATE

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_TODATE | Standalone Database Function | Multiple triggers throughout the form | Converts a string representation to an Oracle DATE value for use in date arithmetic and comparison operations within the form |

#### SP_GET_TV_DETAIL

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_GET_TV_DETAIL | Standalone Database Procedure | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Retrieves True Value resale date, warranty expiry date, and True Value eligibility flag for a vehicle identified by VIN |

#### SP_GET_VEH_DETAILS

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_GET_VEH_DETAILS | Standalone Database Procedure | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Retrieves the full vehicle and customer profile (VIN, model, variant, colour, chassis, engine, customer details, mileage, sale date) for a given registration number |

#### SP_TV_SRV

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_TV_SRV | Standalone Database Procedure | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Validates whether a True Value SMP service window is still active for the vehicle and confirms eligibility for the TV3 sub-service |

#### SP_VALIDATE_ALPHANUMERIC

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_VALIDATE_ALPHANUMERIC | Standalone Database Procedure | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Strips non-alphanumeric characters from the registration number, retaining only letters and digits |

#### SP_VALIDATE_OEMVIN

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_VALIDATE_OEMVIN | Standalone Database Procedure | WHEN-VALIDATE-ITEM on B_VH_AMC_ENQ.REG_NUM | Validates the OEM VIN format and authenticity for the vehicle identified by the entered registration number; called during registration number validation to confirm the VIN meets OEM structural and checksum requirements before SMP eligibility processing proceeds |

#### STOP_WATCH.STOP_TIMER

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| STOP_WATCH.STOP_TIMER | Database Package (STOP_WATCH) | KEY-COMMIT trigger (Form) - conditional on app_log = 'Y' | Records the elapsed time for the save operation in the performance logging infrastructure when application logging is enabled |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-AMC | PKG_AMC | AMC support package - provides GST type determination by comparing dealer and customer state codes, and resolves GST state codes and SEZ status for the form's registration number validation | The form depends on PKG_AMC to determine the applicable GST type (SGST or IGST) for each SMP enquiry based on the dealer and customer state relationship | SP_GET_GST_TYPE correctly returns SGST when dealer and customer states match; SP_GET_GST_TYPE returns IGST when states differ or customer is in a Special Economic Zone; error is returned when customer state is not recorded in the customer master |
| BR-T-PKG-SMP | PKG_SMP | SMP (Scheduled Maintenance Programme) business engine - validates vehicle eligibility, determines fleet type and SMP programme type, retrieves package details and expiry, populates service line items for labour/parts/consumables, handles add-on services, and calculates package tax including GST | The form depends on PKG_SMP to drive all SMP enquiry business logic: vehicle eligibility checks, package selection validation, service line population, add-on management, and tax calculation | SF_FLEET_CHECK correctly identifies commercial vs non-commercial vehicles; SP_VIN_VALIDATE rejects VINs without a valid invoice date or with an active MCP; SF_SMP_TYPE returns the correct SMP sub-service number based on odometer and service history; SP_PKG_DETAIL returns package expiry months, mileage, and service count; SP_GET_SMP_EXP calculates expiry date from vehicle invoice date; SP_POP_SMP_PKG populates all service lines with correct rates and discounts; SP_POP_SMP_PKG_TV populates True Value SMP service lines; SP_POP_SMP_ADDON populates add-on lines when checkbox is checked; SP_POP_SMP_TAX calculates GST charges on all line items; SP_GET_DEFAULT_PART returns the correct default engine oil and coolant part numbers |
| BR-T-PK-VALIDATE-BACK-DATE | Pk_Validate_Back_Date | Back-date validation package - enforces organisational rules governing the maximum number of days in the past for which a transaction date may be entered, preventing users from posting SMP enquiry records beyond the permitted back-dating threshold | The form depends on Pk_Validate_Back_Date to ensure that transaction dates entered by users do not exceed the back-dating limit configured for the dealer, thereby maintaining audit integrity and preventing unauthorised ante-dating of SMP records | The package correctly retrieves the permitted back-date limit for the current dealer; a transaction date within the allowed window is accepted without error; a transaction date that exceeds the back-date limit is rejected and an appropriate error is raised to the user |

**Total Matched Packages:** 3

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_AMC.pck, PKG_SMP.pck, PK_VALIDATE_BACK_DATE.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_AMC.pck | PKG_AMC | SP_GET_GST_TYPE | Procedure | PROCEDURE SP_GET_GST_TYPE(p_pmc IN NUMBER, p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc IN VARCHAR2, p_reg_num IN VARCHAR2, p_gst_type OUT VARCHAR2, p_dlr_gst_state OUT VARCH... | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Determines the applicable GST type (SGST or IGST) for a vehicle registration. Looks up the dealer's state from AM_DEALER_LOC and the customer's state from GM_VIN and GM_CIN. Returns IGST when states differ or customer is a Special Economic Zone; returns SGST when dealer and customer states match. Also resolves GST state codes and SEZ flag. Invoked when the user exits the registration number field. |
| PKG_SMP.pck | PKG_SMP | SF_FLEET_CHECK | Function | FUNCTION SF_FLEET_CHECK(p_pmc NUMBER, p_vin VARCHAR2, p_variant_cd VARCHAR2 ) | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Determines whether a vehicle is a commercial fleet vehicle. Checks GM_VAR for CVMS service flag and NI_NEW_MINS for commercial vehicle type codes C1/C2. Returns 'COM' for commercial and 'NCOM' for non-commercial. This classification drives the package type (SRV_TYPE) used in all subsequent SMP calculations. |
| PKG_SMP.pck | PKG_SMP | SF_SMP_TYPE | Function | FUNCTION SF_SMP_TYPE(p_pmc NUMBER, p_vin VARCHAR2, p_srv_type VARCHAR2, p_odometer NUMBER ) | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.SERV_TYPE | Determines the SMP sub-service number for a vehicle based on its odometer reading and service history. Compares the vehicle's last completed repair order sub-category against AM_LIST SMP service types, then evaluates odometer against VM_SMP calibration rules to select the applicable sub-service. Returns a numeric sub-service code used to select the correct package lines. |
| PKG_SMP.pck | PKG_SMP | SP_GET_DEFAULT_PART | Procedure | PROCEDURE SP_GET_DEFAULT_PART (pn_pmc NUMBER, pn_vin VARCHAR2, pn_group VARCHAR2, pn_fsrvtype VARCHAR2, pn_tsrvtype VARCHAR2, po_group OUT VARCHAR2, po_part OUT VARCHAR2, pn_mrp... | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | Retrieves the default engine oil or coolant part number for the vehicle variant. Looks up VM_MENU_CD for the variant's applicable part in the given group, determines old vs new coolant type using GM_VIN_EXT and AM_LIST (BLUE_COOLANT_DT), and returns the part number and MRP from PI_PM_PART_MRP. Invoked after package code selection to pre-fill engine oil and coolant fields. |
| PKG_SMP.pck | PKG_SMP | SP_GET_SMP_EXP | Procedure | PROCEDURE SP_GET_SMP_EXP (pn_pmc NUMBER, pn_vin VARCHAR2, pn_srv VARCHAR2, pn_subsrv VARCHAR2, po_exp_age OUT NUMBER, po_exp_mil OUT NUMBER, po_exp_date OUT DATE, po_err_cd OUT... | Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | Calculates the SMP package expiry parameters for a vehicle and service/sub-service combination. Reads VM_SUB_SRV_CAL to derive maximum odometer and vehicle age limits. Applies SMP_PARAM override from AM_LIST_RANGE when age exceeds threshold. Returns expiry age in years, mileage, and calculated expiry date based on vehicle invoice date. |
| PKG_SMP.pck | PKG_SMP | SP_PKG_DETAIL | Procedure | PROCEDURE SP_PKG_DETAIL(p_pmc NUMBER, p_fleet_type VARCHAR2, p_serv_type VARCHAR2, p_pkg_sel VARCHAR2, p_exp_month OUT NUMBER, p_exp_mileage OUT NUMBER, p_srv_no OUT NUMBER, p_e... | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | Retrieves SMP package master details for a given fleet type and package code from VM_SMP_PARAM. Returns expiry months, expiry mileage, and number of services included in the package. Invoked when the user selects a package code to populate the package description fields on the form. |
| PKG_SMP.pck | PKG_SMP | SP_POP_SMP_ADDON | Procedure | PROCEDURE SP_POP_SMP_ADDON (p_pmc NUMBER, p_parent VARCHAR2, p_dealer NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_pkg_type VARCHAR2, p_pkg_code VARCHAR2, p_reg_num VARCHAR2, p_su... | Trigger: WHEN-CHECKBOX-CHANGED in B_ADDON.ADDON_YN | Populates or removes add-on service lines in GBL_AMC_DTL when the user checks or unchecks an add-on checkbox. Fetches city RPH type and vehicle details, determines applicable discount, and inserts labour, parts, and consumable lines with rates and discount amounts for the selected add-on. Invoked when B_ADDON.ADDON_YN is toggled. |
| PKG_SMP.pck | PKG_SMP | SP_POP_SMP_PKG | Procedure | PROCEDURE SP_POP_SMP_PKG (p_pmc NUMBER, p_parent VARCHAR2, p_dealer NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_pkg_type VARCHAR2, p_pkg_code VARCHAR2, p_reg_num VARCHAR2, p_sub_... | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL | Populates all SMP package service lines into GBL_AMC_DTL for the selected vehicle and package. Retrieves city RPH type, vehicle variant, and applicable discount; then inserts labour, parts, and consumable lines with rates, quantities, and discount amounts from package definition tables. Handles engine oil and coolant lines with MRP. Invoked when user clicks Fetch Details button. |
| PKG_SMP.pck | PKG_SMP | SP_POP_SMP_PKG_TV | Procedure | PROCEDURE SP_POP_SMP_PKG_TV (p_pmc NUMBER, p_parent VARCHAR2, p_dealer NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_pkg_type VARCHAR2, p_pkg_code VARCHAR2, p_reg_num VARCHAR2, p_t... | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL | Populates SMP service detail lines for True Value pre-owned vehicles into GBL_AMC_DTL. Resolves the city RPH type for the dealer, retrieves vehicle identity (VIN, model, variant) from GM_VIN, determines the applicable coolant type (old or new) using GM_VIN_EXT and the BLUE_COOLANT_DT cutoff date from AM_LIST, and verifies that an SMP discount record exists in VM_SMP_DISC for the vehicle variant and package. Derives labour, parts, and consumable discount percentages from VM_SMP_DISC. Clears any previous working-table records from GBL_SMP and GBL_AMC_DTL for the session. Iterates over True Value SMP service definitions in VM_MENU_CD - selecting the TV-specific sub-service (TV3 maps to FR3; others use the passed sub-service) - and inserts labour, parts, and consumable service lines with applicable rates, quantities, and discount amounts. Handles engine oil and coolant lines with MRP from PI_PM_PART_MRP for the correct part group and coolant type. Returns an error code and message if the city type is undefined, the VIN is not found, or the SMP package is not defined for the vehicle model. |
| PKG_SMP.pck | PKG_SMP | SP_POP_SMP_TAX | Procedure | PROCEDURE SP_POP_SMP_TAX (p_pmc NUMBER, p_parent VARCHAR2, p_dealer NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_pkg_code VARCHAR2, p_reg_num VARCHAR2, p_gst_type VARCHAR2, p_dlr_... | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY | Calculates and inserts GST tax charge lines into GBL_AMC_CHARGES for all service lines in GBL_AMC_DTL. Applies labour and parts tax codes from VM_DLR_LTS, evaluates CGST/SGST or IGST based on GST type, and optionally applies TCS charges. Invoked when generating the enquiry (PB_GEN_ENQ) or applying TCS (PB_TCS_APPLY). |
| PKG_SMP.pck | PKG_SMP | SP_VIN_VALIDATE | Procedure | PROCEDURE SP_VIN_VALIDATE(pn_pmc NUMBER, pn_vin VARCHAR2, pn_odm NUMBER, po_smp_yn OUT VARCHAR2, po_val_mil OUT NUMBER, po_val_age OUT NUMBER, po_srv_no OUT NUMBER, po_sub_srv O... | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | Validates VIN eligibility for SMP enrolment. Checks vehicle exists, verifies no active MCP, validates OEM VIN, determines fleet type and applicable sub-service number from odometer reading and service history. Returns SMP eligibility flag, validity mileage, validity age, service number, sub-service, CDS flag, and error details. Invoked on registration and odometer field validation. |
| PK_VALIDATE_BACK_DATE.pck | Pk_Validate_Back_Date | Generate_Next_Num | Procedure | PROCEDURE Generate_Next_Num ( pi_dealer_map_cd IN NUMBER, pi_principal_map_cd IN NUMBER, pi_loc_cd IN VARCHAR2, pi_comp_fa IN VARCHAR2, pi_doc_type IN VARCHAR2, po_doc_num OUT V... | FT_SAVE in Form | Generates the next sequential document number for an AMC enquiry at save time. Accepts dealer, principal, location, company, and document-type identifiers and returns the next available document number together with any error code and message. Ensures each saved enquiry receives a unique, centrally controlled reference number consistent with the dealership's document-numbering scheme. |

**Total Matched Package Routines (called from form XML):** 12

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| SF_FLEET_CHECK | Varchar2 | COM, NCOM | COM = commercial fleet vehicle; NCOM = non-commercial/personal vehicle - determines the package type used throughout SMP calculation |
| SF_SMP_TYPE | Number | Numeric sub-service code (integer ≥ 1) | SMP sub-service number representing the applicable scheduled maintenance stage for the vehicle, used to select correct package lines |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded `.pld` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT | Presents a confirmation dialog containing the supplied `confirm_msg` text and returns the user's response as a NUMBER. Called from toolbar/canvas button triggers (PB_BLK group) and form-level function-key triggers FT_CANCEL and FT_DEL to obtain explicit user confirmation before performing destructive or irreversible operations such as deletion, cut, exit without saving, and similar actions. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the last Oracle Forms operation completed successfully. If the form is not in a success state, reads ERROR_TYPE and ERROR_TEXT and calls GENERAL.DISP_TEXT to display the error message, then raises FORM_TRIGGER_FAILURE to stop further execution. Invoked at the start of KEY-COMMIT to abort the save if a prior validation step failed. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_ADDON, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.EMP_CD, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.SERV_TYPE | Validates that a required field value is not null. If p_value is null, displays the message 'Enter a valid {column_title}' using GENERAL.DISP_TEXT with an Error title and raises FORM_TRIGGER_FAILURE. Called from multiple validation triggers and button-pressed triggers to enforce mandatory field completion before proceeding. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: POP_DISC, ProgramUnit: POP_SMP_DETAILS, ProgramUnit: SP_INSERT_CHARGES, Trigger: FT_SAVE in Form, Trigger: KEY-COMMIT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_CAL_DISC, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY, Trigger: WHEN-CHECKBOX-CHANGED in B_ADDON.ADDON_YN, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in B_ADDON.ADDON_CNT, Trigger: WHEN-VALIDATE-ITEM in B_ADDON.DLR_DISC, Trigger: WHEN-VALIDATE-ITEM in B_VD_AMC_ENQ.DLR_DISC, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_CONS_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_LAB_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_PART_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_CONS_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_CONS_CNT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_ENQ_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_LBR_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_LBR_CNT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_PART_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_PART_CNT | Displays an informational or error alert dialog. Uses AL_ERRINFO alert for Error-titled messages and AL_NOTE for all other titles. Sets the alert title and message text via SET_ALERT_PROPERTY then shows the alert with SHOW_ALERT. Called pervasively throughout the form for error reporting, validation messages, informational notes, and status updates. The call site set has been extended relative to the prior revision to include FT_SAVE and WHEN-NEW-FORM-INSTANCE, reflecting additional save-path feedback and form-initialisation status messaging. |
| PROC_REPORT_CALL | Procedure | Procedure(REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) | ProgramUnit: CALL_REPORT_ENQ | Configures a report object for batch print output to a file on the server. Sets report execution mode to BATCH, destination type to FILE, output path under /iashome/ias/reports/printer/, and report server from the REP_SERVER global. Submits the report via RUN_REPORT_OBJECT and returns the report job handle and output file name for use by the timer-based polling mechanism. |
| PROC_TIMER | Procedure | Procedure() | ProgramUnit: CALL_REPORT_ENQ | Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5-second interval. This timer is used to poll the report server for the status of a submitted print job. Invoked after PROC_REPORT_CALL to start the polling cycle. |
| PROC_TIMER_EXPIRED | Procedure | Procedure() | Trigger: WHEN-TIMER-EXPIRED in Form | Handles the PRINTER_QUEUE timer expiry event. Reads the report handle and print output file name from global variables, checks the report execution status via REPORT_OBJECT_STATUS. If the report has finished, displays the output document in the browser using web.show_document; if still running, waits; if failed, displays an error and deletes the timer. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by code, classifies it as Error, Note, or Caution, and displays the message with the appropriate title using GENERAL.DISP_TEXT. For Error-type messages, raises FORM_TRIGGER_FAILURE to halt processing. Called from the ON-ERROR trigger to handle Oracle Forms and database error events. |

**Total Active Routines:** 8 of 24 in DPL.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Vehicle Lookup Service | SP_GET_VEH_DETAILS, GM_VIN | Principal, parent group, dealer, location, registration number | Vehicle and customer profile (VIN, model, variant, chassis, engine, customer details, sale date, last mileage, error code/message) | Retrieves the complete vehicle identification and customer profile for a given registration number | `GET /api/v1/vehicles/{registrationNumber}?principal={principal}&dealer={dealer}&location={location}` |
| MS-002 | SMP Eligibility Validation Service | PKG_SMP.SP_VIN_VALIDATE, VM_SMP_PARAM | Principal, VIN, current mileage | SMP eligibility flag, validity mileage, validity age, number of services, sub-service range, CDS indicator, error code/message | Validates whether a vehicle is eligible for an SMP plan and returns the plan's validity parameters | `POST /api/v1/smp/eligibility` |
| MS-003 | SMP Package List Category Service | PKG_SMP.SF_SMP_TYPE, GM_VIN | Principal, VIN, service type, current mileage | Package list category number | Determines the applicable SMP package list category for a given vehicle, service type, and mileage | `GET /api/v1/smp/package-category?principal={principal}&vin={vin}&serviceType={serviceType}&mileage={mileage}` |
| MS-004 | SMP Package Detail Service | PKG_SMP.SP_PKG_DETAIL, VM_SMP_PARAM | Principal, fleet/vehicle category, service type, package code | Expiry months, expiry mileage, number of services, error code/message | Retrieves the SMP package's expiry parameters and number of services from the plan configuration | `GET /api/v1/smp/packages/{packageCode}/details?principal={principal}&category={category}&serviceType={serviceType}` |
| MS-005 | SMP Contract Expiry Service | PKG_SMP.SP_GET_SMP_EXP, VM_SUB_SRV_CAL, GM_VIN | Principal, VIN, service type, ending sub-service code | Expiry age in months, expiry mileage, validity-to date, error code/message | Retrieves the SMP contract's expiry date and mileage for a vehicle's service sub-range | `GET /api/v1/smp/contracts/expiry?principal={principal}&vin={vin}&serviceType={serviceType}&toSubService={toSubService}` |
| MS-006 | Default Consumable Parts Service | PKG_SMP.SP_GET_DEFAULT_PART, PM_PART, AM_LIST_RANGE | Principal, VIN, part group (ENGOIL/COOLANT), from-sub-service, to-sub-service | Part group code, part number, MRP, error code/message | Determines the recommended default engine oil or coolant part for a vehicle and service sub-range | `GET /api/v1/smp/parts/default?principal={principal}&vin={vin}&partGroup={partGroup}&fromSubService={fromSubService}&toSubService={toSubService}` |
| MS-007 | SMP Package Population Service | PKG_SMP.SP_POP_SMP_PKG, GBL_AMC_DTL | Principal, parent group, dealer, location, company, service type, package code, registration number, sub-service range, number of services, GST type, engine oil, coolant | Error code/message (line items written to staging) | Computes and stages all SMP package line items (labour, parts, consumables) for a standard vehicle enquiry | `POST /api/v1/smp/enquiries/package-lines` |
| MS-008 | True Value SMP Package Population Service | PKG_SMP.SP_POP_SMP_PKG_TV, GBL_AMC_DTL | Same as MS-007 plus TV from-sub-service | Error code/message (line items written to staging) | Computes and stages True Value SMP package line items using TV3-specific pricing and sub-service logic | `POST /api/v1/smp/enquiries/tv-package-lines` |
| MS-009 | SMP Add-On Population Service | PKG_SMP.SP_POP_SMP_ADDON, GBL_AMC_DTL, GBL_SMP | Principal, parent group, dealer, location, company, service type, package code, registration number, sub-service range, number of services, GST type | Error code/message (add-on lines written to staging) | Computes and stages add-on service line items for an SMP enquiry | `POST /api/v1/smp/enquiries/addon-lines` |
| MS-010 | SMP Tax Calculation Service | PKG_SMP.SP_POP_SMP_TAX, GBL_AMC_DTL | Principal, parent group, dealer, location, company, package code, registration number, GST type, dealer state, customer state, TCS applicability flag | Error code/message (charge amounts updated in staging) | Computes GST and TCS charge amounts for all staged SMP package and add-on line items | `POST /api/v1/smp/enquiries/tax-calculation` |
| MS-011 | GST Type Determination Service | PKG_AMC.SP_GET_GST_TYPE, AM_DEALER_LOC, GM_CIN, GM_VIN | Principal, parent group, dealer, location, registration number | GST type, dealer state code, customer state code, SEZ status, error code/message | Determines the applicable GST category (intra-state or inter-state) and retrieves dealer/customer state information | `GET /api/v1/gst/type?principal={principal}&dealer={dealer}&location={location}&registrationNumber={registrationNumber}` |
| MS-012 | Fleet Classification Service | PKG_SMP.SF_FLEET_CHECK, GM_VAR, NI_NEW_MINS | Principal, VIN, variant code | Service type category (commercial or standard) | Determines whether a vehicle qualifies as a commercial/fleet vehicle for pricing and SMP categorisation | `GET /api/v1/vehicles/{vin}/fleet-classification?principal={principal}&variantCode={variantCode}` |
| MS-013 | True Value Vehicle Detail Service | SP_GET_TV_DETAIL, GM_VIN, GM_VIN_EXT | VIN, current date, current mileage | True Value eligibility flag, resale date, warranty expiry date | Retrieves True Value resale and warranty details for pre-owned vehicle SMP eligibility assessment | `GET /api/v1/vehicles/{vin}/true-value-details?mileage={mileage}` |
| MS-014 | True Value SMP Service Validation Service | SP_TV_SRV, GM_VIN_EXT, VH_RO | Parent group, registration number, current date, current mileage, service category | Error code/message (True Value SMP service window validity result) | Validates whether the True Value SMP service window is still active for the vehicle | `POST /api/v1/smp/true-value/service-validation` |
| MS-015 | SMP Enquiry Report Service | CALL_REPORT_ENQ (vr_smp_enq report) | Principal, parent group, dealer, location, company, enquiry number | Report output (PDF/print) | Generates and delivers the SMP enquiry report for a committed enquiry | `GET /api/v1/smp/enquiries/{enquiryNumber}/report` |

**Total Microservices Identified: 15**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | New SMP Enquiry Creation | Advisor opens the form with no enquiry number | 1. Form opens and session is registered. 2. Advisor enters vehicle registration number; system validates and loads vehicle and customer details. 3. Advisor enters current mileage; system re-validates SMP eligibility. 4. Advisor selects service executive. 5. Advisor selects service type; system derives package list category. 6. Advisor confirms or adjusts package code; system retrieves expiry and default parts. 7. Advisor clicks "Generate SMP"; system populates package line items and loads detail grid. 8. Advisor optionally enters dealer discounts and applies them. 9. Advisor optionally navigates to add-on screen and selects add-on services. 10. Advisor navigates TCS declaration; system routes to Normal Rate, Higher Rate, or TCS Not Applied. 11. Advisor clicks "Apply TCS"; system computes tax and enables save. 12. Advisor saves; system inserts charges, commits, displays enquiry number, and offers report print. 13. Form clears for next enquiry. | Vehicle not found -> block; Mileage below threshold -> block; SMP not eligible -> block; TV SMP path vs standard path; TCS applicable vs not applicable; Rate selection (Normal vs Higher); Duplicate open enquiry -> advisor decides to continue or cancel; Save button enabled only after TCS applied | Enquiry saved and confirmed with generated enquiry number; SMP enquiry report offered |
| WF-002 | Existing SMP Enquiry Review | Advisor enters an existing enquiry number | 1. Advisor enters enquiry number. 2. System validates the number against the SMP enquiry master. 3. If found, system loads the enquiry header and detail records. 4. All entry and action fields are disabled for read-only review. 5. Advisor reviews the enquiry details. | Enquiry number not found -> block with error; Enquiry found -> load in read-only mode | Enquiry displayed in read-only mode; no changes persisted |
| WF-003 | True Value SMP Package Generation | Advisor selects TV3 sub-service path during Generate SMP | 1. After vehicle registration validation, system determines that the vehicle is a True Value pre-owned vehicle eligible for TV SMP. 2. Advisor selects service type and confirms package code. 3. Advisor clicks "Generate SMP". 4. System calls the True Value SMP package population routine (TV3 sub-service) to stage line items. 5. Staged line items are loaded into the detail grid. 6. Flow continues to TCS declaration and tax calculation as in WF-001. | TV SMP eligibility fails -> fall back to standard SMP; TV3 routine errors -> error shown | True Value SMP package detail populated; enquiry proceeds to tax and save steps |
| WF-004 | Dealer Discount Application | Advisor enters header-level dealer discounts | 1. After SMP package detail is loaded, advisor enters discount indicator and value for labour, parts, and/or consumables. 2. System validates each indicator-value pair on field exit. 3. Advisor clicks "Calculate Discount". 4. System re-validates all discount entries. 5. If all valid, system writes discounts to staging table and refreshes detail grid. 6. Advisor can click "Clear Discount" to reset all discounts to zero and reload the grid. | Missing indicator -> block; Value out of range -> block; Valid -> write to staging and refresh | Detail grid refreshed with updated dealer discount amounts and after-dealer-discount totals |
| WF-005 | Add-On Service Selection | Advisor opens the Add-On screen | 1. After package code is confirmed, advisor clicks "Add-On" button. 2. System validates package code is present, resets tax fields, and navigates to add-on screen. 3. System loads available add-on services from the master list. 4. Advisor ticks checkbox to include an add-on; system stages line items. 5. Advisor optionally adjusts add-on quantity and dealer discount. 6. System validates quantity and discount values. 7. Advisor unticks a checkbox to remove an add-on; system removes staging records. 8. Advisor returns to main screen to proceed with TCS and tax calculation. | Package code missing -> block navigation; Invalid quantity -> reset to default; Invalid discount -> block | Add-on services staged and displayed; enquiry proceeds to TCS step |
| WF-006 | Form Discard and Reset | Advisor clears the form before saving | 1. Advisor triggers the clear form action (KEY-CLRFRM). 2. System clears all on-screen fields without saving. 3. System deletes all temporary staging records (GBL_SMP, GBL_AMC_DTL, GBL_AMC_CHARGES) for the current session. 4. System resets field editability to default new-entry state and refreshes the copyright notice. | No decisions - unconditional clear | Form reset to blank state; temporary staging data removed; ready for next enquiry |
| WF-007 | Form Exit | Advisor exits the form | 1. Advisor triggers the exit action (KEY-EXIT). 2. System clears the session monitoring record. 3. Form closes without validation or saving. | No decisions - unconditional exit | Form closed; session deregistered from monitoring |

**Total Workflows Identified: 7**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

*No routines from ``webutil.pld`` are referenced in ``vt_smp_enq_fmb.xml``.*


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When the last form operation fails, then the commit is aborted and the error message is displayed to the user |
| PLD-002 | CHECK_NULL | Validation | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_ADDON, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.EMP_CD, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.SERV_TYPE | /api/v1/pld/check_null | When a required field is null, then an error message is displayed and navigation or processing is stopped |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: POP_DISC, ProgramUnit: POP_SMP_DETAILS, ProgramUnit: SP_INSERT_CHARGES, Trigger: KEY-COMMIT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_CAL_DISC, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY, Trigger: WHEN-CHECKBOX-CHANGED in B_ADDON.ADDON_YN, Trigger: WHEN-VALIDATE-ITEM in B_ADDON.ADDON_CNT, Trigger: WHEN-VALIDATE-ITEM in B_ADDON.DLR_DISC, Trigger: WHEN-VALIDATE-ITEM in B_VD_AMC_ENQ.DLR_DISC, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_CONS_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_LAB_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.DLR_PART_DISC, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_CONS_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_CONS_CNT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_ENQ_NUM, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_LBR_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_LBR_CNT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_PART_AMT, Trigger: WHEN-VALIDATE-ITEM in CB_VT_AMC_ENQ.NB_PART_CNT | /api/v1/pld/disp_text | When a message or error event occurs, then an alert dialog with the appropriate title and text is displayed to the user |
| PLD-004 | PROC_REPORT_CALL | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_report_call | When a print output is requested, then the report is configured and submitted to the report server and the job handle is returned for status polling |
| PLD-005 | PROC_TIMER | Business Logic | ProgramUnit: CALL_REPORT_ENQ | /api/v1/pld/proc_timer | When a print job is submitted, then a repeating 5-second timer is created to poll the report server for completion |
| PLD-006 | PROC_TIMER_EXPIRED | Business Logic | Trigger: WHEN-TIMER-EXPIRED in Form | /api/v1/pld/proc_timer_expired | When the polling timer fires and the report is finished, then the output document is opened in the browser; if failed, an error is shown and the timer is deleted |
| PLD-007 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a form error event occurs, then the error message is displayed with the appropriate severity and processing is halted for error-type messages |

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_AMC.SP_GET_GST_TYPE | Validation | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/packages/pkg_amc/sp_get_gst_type | When a vehicle registration is validated, then GST type is determined as SGST or IGST based on dealer and customer state codes, and IGST is forced for SEZ customers |
| PCK-002 | PKG_SMP.SF_FLEET_CHECK | Business Logic | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/packages/pkg_smp/sf_fleet_check | When a vehicle VIN and variant are provided, then the fleet type is returned as COM for commercial vehicles or NCOM for non-commercial vehicles |
| PCK-003 | PKG_SMP.SF_SMP_TYPE | Business Logic | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.SERV_TYPE | /api/v1/packages/pkg_smp/sf_smp_type | When a service type and odometer reading are provided, then the applicable SMP sub-service number is returned based on vehicle service history and odometer calibration |
| PCK-004 | PKG_SMP.SP_GET_DEFAULT_PART | Business Logic | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | /api/v1/packages/pkg_smp/sp_get_default_part | When a package is selected, then the default engine oil or coolant part number and MRP are retrieved for the vehicle variant based on the coolant type configuration |
| PCK-005 | PKG_SMP.SP_GET_SMP_EXP | Business Logic | Trigger: POST-QUERY in B_VH_AMC_ENQ, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | /api/v1/packages/pkg_smp/sp_get_smp_exp | When a VIN and service/sub-service combination are provided, then the package expiry age, mileage, and expiry date are calculated from vehicle invoice date and sub-service calibration |
| PCK-006 | PKG_SMP.SP_PKG_DETAIL | Business Logic | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.PKG_CODE | /api/v1/packages/pkg_smp/sp_pkg_detail | When a fleet type and package code are provided, then the package expiry months, expiry mileage, and number of services are retrieved from the SMP package master |
| PCK-007 | PKG_SMP.SP_POP_SMP_ADDON | Business Logic | Trigger: WHEN-CHECKBOX-CHANGED in B_ADDON.ADDON_YN | /api/v1/packages/pkg_smp/sp_pop_smp_addon | When an add-on service is selected, then the corresponding labour, parts, and consumable lines are inserted into the working table with applicable rates and discounts |
| PCK-008 | PKG_SMP.SP_POP_SMP_PKG | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL | /api/v1/packages/pkg_smp/sp_pop_smp_pkg | When the Fetch Details button is clicked for a standard SMP package, then all service lines are populated into the working table with rates, quantities, and discount amounts |
| PCK-009 | PKG_SMP.SP_POP_SMP_PKG_TV | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_FETCH_DTL | /api/v1/packages/pkg_smp/sp_pop_smp_pkg_tv | When the Fetch Details button is clicked for a True Value pre-owned vehicle, then SMP service lines are populated using the TV-specific package configuration |
| PCK-010 | PKG_SMP.SP_POP_SMP_TAX | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_GEN_ENQ, Trigger: WHEN-BUTTON-PRESSED in CB_VT_AMC_ENQ.PB_TCS_APPLY | /api/v1/packages/pkg_smp/sp_pop_smp_tax | When an enquiry is generated or TCS is applied, then GST tax charge lines are calculated and inserted into the charges working table for all service lines |
| PCK-011 | PKG_SMP.SP_VIN_VALIDATE | Validation | Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.ODOMETER_READING, Trigger: WHEN-VALIDATE-ITEM in B_VH_AMC_ENQ.REG_NUM | /api/v1/packages/pkg_smp/sp_vin_validate | When a VIN is validated, then SMP eligibility is confirmed, active MCP conflicts are rejected, and validity mileage, age, service number, and sub-service are returned |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| VH_AMC_ENQ - SMP Enquiry Header | Oracle Table (Read/Write) | Stores and retrieves the SMP enquiry header record including vehicle, customer, plan, pricing, GST, TCS, and audit details | Form writes on commit (KEY-COMMIT); form reads on query (WHEN-NEW-BLOCK-INSTANCE with EXECUTE_QUERY when an enquiry number is entered) | Standard Oracle Forms error handling via ON-ERROR trigger; GENERAL.CHECK_FORM_FAILURE called after commit |
| VD_AMC_ENQ - SMP Enquiry Detail | Oracle Table (Read/Write) | Stores and retrieves individual SMP service detail lines (labour, parts, consumables) linked to the enquiry header | Form writes on commit; form reads via POST-QUERY (to populate discount and tax summaries) and via EXECUTE_QUERY from WHEN-NEW-BLOCK-INSTANCE | Standard Oracle Forms error handling |
| VD_AMC_ENQCHARGES - SMP Enquiry Charges | Oracle Table (Insert) | Stores the computed GST and TCS charge records for each line item in the enquiry | SP_INSERT_CHARGES inserts during KEY-COMMIT before the final commit | Error raised by SP_INSERT_CHARGES propagates to KEY-COMMIT; commit is aborted |
| GBL_AMC_DTL - SMP Detail Staging | Oracle Table (Select/Insert/Update/Delete) | Temporary working storage for computed SMP package and add-on line items during an active session | PKG_SMP.SP_POP_SMP_PKG, SP_POP_SMP_PKG_TV, SP_POP_SMP_ADDON insert; POP_DISC updates; PKG_SMP.SP_POP_SMP_TAX updates; POP_PKG_DETAILS, POP_SMP_DETAILS, POP_ADDON_DETAILS, POP_DETAILS_AFT_DISC read; KEY-COMMIT and KEY-CLRFRM delete for current session | WHEN OTHERS exception blocks in procedures return error codes; trigger checks error code and shows message |
| GBL_SMP - Add-On Staging | Oracle Table (Select/Insert/Delete) | Temporary record of which add-on services have been selected for the current session | PKG_SMP.SP_POP_SMP_ADDON inserts; WHEN-CHECKBOX-CHANGED deletes on unselect; KEY-COMMIT and KEY-CLRFRM delete for current session | WHEN OTHERS exception handling within called procedures |
| GBL_AMC_CHARGES - Charges Staging | Oracle Table (Select/Delete) | Temporary staging for computed charge records before permanent commit | SP_INSERT_CHARGES reads and inserts into VD_AMC_ENQCHARGES; KEY-COMMIT and KEY-CLRFRM delete for current session | Error in SP_INSERT_CHARGES aborts commit |
| GM_VIN - Vehicle Identification Master | Oracle Table (Select) | Provides vehicle identification data (VIN, chassis, engine, model, sale date, mileage, True Value flag) | Read by SP_GET_VEH_DETAILS, WHEN-VALIDATE-ITEM on REG_NUM (existence check), POST-QUERY on B_VH_AMC_ENQ | NO_DATA_FOUND -> *"Registration Number Not Found"*; TOO_MANY_ROWS -> duplicate error; WHEN OTHERS -> execution failed error |
| PKG_SMP - SMP Processing Package | Oracle Database Package | Provides all SMP business logic: fleet check, SMP type, VIN validation, package population, add-on population, tax calculation, expiry, and default parts | Called from multiple triggers and program units throughout the form session | Error codes returned in output parameters; trigger checks code and calls GENERAL.DISP_TEXT with the error message |
| PKG_AMC - AMC Processing Package | Oracle Database Package | Provides GST type determination for AMC/SMP transactions | Called from WHEN-VALIDATE-ITEM on REG_NUM | Error code returned; trigger shows message via GENERAL.DISP_TEXT |
| DBMS_APPLICATION_INFO - Oracle Built-In | Oracle Built-In Package | Registers form identity (vt_smp_enq) in the current database session for monitoring | Called from PRE-FORM trigger on form open; called from KEY-EXIT to clear on form close | No explicit error handling - built-in procedure |
| STOP_WATCH - Performance Logging Package | Oracle Database Package | Records performance timing for key operations when application logging is enabled | KEY-COMMIT calls STOP_WATCH.STOP_TIMER when :global.app_log = 'Y' | No explicit error handling |

### 20.2 External System Integrations

The VT_SMP_ENQ form does not invoke any external systems directly via web services, messaging, or external APIs. All processing is conducted against the Oracle database using stored procedures and packages. The PKG_SMP package references NI_NEW_MINS (fleet registration data - EXTERNAL / NOT IN BUNDLE) as a read-only lookup during the fleet classification check, but this is accessed via an in-database SQL query rather than an external system call.

No external system integrations are evidenced by the form's triggers, program units, cross-form references, external file references, or message content.

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| vr_smp_enq | :global.rep_server (session variable - INFERRED) | Enquiry number (passed to report via REPORT_CALL object; report server destination set dynamically) | Print / report server output (INFERRED) | CALL_REPORT_ENQ program unit, invoked from KEY-COMMIT after successful commit; advisor chooses print or skip via AL_REPORT alert |
| D:\reports\samples\demo\vr_ew_certificate.rdf | N/A | N/A | N/A | Static filename declared on the REPORT_CALL report object in vt_smp_enq_fmb.xml (xml_report_object source); overridden at runtime by SET_REPORT_OBJECT_PROPERTY to vr_smp_enq in CALL_REPORT_ENQ - this file is the object's initial declared filename, not the active runtime report |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VT_SMP_ENQ form.

### 21.1 Catalogue Index

43 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT_ENQ) | CALL_REPORT_ENQ |
| [SP-002](#SP-002--POP_ADDON_DETAILS) | POP_ADDON_DETAILS |
| [SP-003](#SP-003--POP_DETAILS_AFT_DISC) | POP_DETAILS_AFT_DISC |
| [SP-004](#SP-004--POP_DISC) | POP_DISC |
| [SP-005](#SP-005--POP_DISC_CLEAR) | POP_DISC_CLEAR |
| [SP-006](#SP-006--POP_PKG_DETAILS) | POP_PKG_DETAILS |
| [SP-007](#SP-007--POP_SMP_DETAILS) | POP_SMP_DETAILS |
| [SP-008](#SP-008--SP_INSERT_CHARGES) | SP_INSERT_CHARGES |
| [SP-009](#SP-009--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-010](#SP-010--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-011](#SP-011--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-012](#SP-012--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-013](#SP-013--GENERAL.PROC_REPORT_CALL) | GENERAL.PROC_REPORT_CALL |
| [SP-014](#SP-014--GENERAL.PROC_TIMER) | GENERAL.PROC_TIMER |
| [SP-015](#SP-015--GENERAL.PROC_TIMER_EXPIRED) | GENERAL.PROC_TIMER_EXPIRED |
| [SP-016](#SP-016--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-017](#SP-017--PKG_AMC.SP_GET_GST_TYPE) | PKG_AMC.SP_GET_GST_TYPE |
| [SP-018](#SP-018--PKG_SMP.SF_FLEET_CHECK) | PKG_SMP.SF_FLEET_CHECK |
| [SP-019](#SP-019--PKG_SMP.SF_SMP_TYPE) | PKG_SMP.SF_SMP_TYPE |
| [SP-020](#SP-020--PKG_SMP.SP_GET_DEFAULT_PART) | PKG_SMP.SP_GET_DEFAULT_PART |
| [SP-021](#SP-021--PKG_SMP.SP_GET_SMP_EXP) | PKG_SMP.SP_GET_SMP_EXP |
| [SP-022](#SP-022--PKG_SMP.SP_PKG_DETAIL) | PKG_SMP.SP_PKG_DETAIL |
| [SP-023](#SP-023--PKG_SMP.SP_POP_SMP_ADDON) | PKG_SMP.SP_POP_SMP_ADDON |
| [SP-024](#SP-024--PKG_SMP.SP_POP_SMP_PKG) | PKG_SMP.SP_POP_SMP_PKG |
| [SP-025](#SP-025--PKG_SMP.SP_POP_SMP_PKG_TV) | PKG_SMP.SP_POP_SMP_PKG_TV |
| [SP-026](#SP-026--PKG_SMP.SP_POP_SMP_TAX) | PKG_SMP.SP_POP_SMP_TAX |
| [SP-027](#SP-027--PKG_SMP.SP_VIN_VALIDATE) | PKG_SMP.SP_VIN_VALIDATE |
| [SP-028](#SP-028--PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM) | PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM |
| [SP-029](#SP-029--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-030](#SP-030--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-031](#SP-031--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-032](#SP-032--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-033](#SP-033--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-034](#SP-034--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-035](#SP-035--WEBUTIL.WAIT) | WEBUTIL.WAIT |
| [SP-036](#SP-036--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-037](#SP-037--SF_GET_AMLIST) | SF_GET_AMLIST |
| [SP-038](#SP-038--SF_TODATE) | SF_TODATE |
| [SP-039](#SP-039--SP_GET_TV_DETAIL) | SP_GET_TV_DETAIL |
| [SP-040](#SP-040--SP_GET_VEH_DETAILS) | SP_GET_VEH_DETAILS |
| [SP-041](#SP-041--SP_TV_SRV) | SP_TV_SRV |
| [SP-042](#SP-042--SP_VALIDATE_ALPHANUMERIC) | SP_VALIDATE_ALPHANUMERIC |
| [SP-043](#SP-043--SP_VALIDATE_OEMVIN) | SP_VALIDATE_OEMVIN |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT_ENQ

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: FT_PRINT]
- vt_smp_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Generates and delivers the enquiry call report (vr_smp_enq) for a given combination of principal, parent, dealer, location, financial company, and enquiry number. The procedure presents the user with an output-format choice (PDF preview, printer, or cancel) and dispatches the report to the Oracle Reports server accordingly, delegating printer-path execution and timer coordination to GENERAL.PROC_REPORT_CALL and GENERAL.PROC_TIMER respectively.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | VARCHAR2 | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_enq_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.PROC_REPORT_CALL ([SP-013](#SP-013--GENERAL.PROC_REPORT_CALL)) - matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-014](#SP-014--GENERAL.PROC_TIMER)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the pre-defined report object named 'REPORT_CALL' within the form using Find_Report_Object and assign it to the working report handle.
- Step 2 - Set the target report filename to 'vr_smp_enq'.
- Step 3 - Retrieve the alert object 'AL_REPORT' and display it to the user, capturing the button selection in lv_alert.
- Step 4 - Evaluate the user's alert response to determine the output destination (PDF, printer, or cancel).
- Step 5 (PDF path - Alert Button 1) - Clear any pending messages, set the report destination format to PDF, and build the report parameter string from the six input parameters (p_parent, p_principal, p_comp_fa, p_dealer, p_loc, p_enq_num) with REPORT_DESTYPE=FILE and MODE=BITMAP BLANKPAGES=NO.
- Step 6 (PDF path) - Apply the report server (sourced from :global.rep_server), assign the filename, and execute the report via RUN_REPORT_OBJECT, capturing the job identifier.
- Step 7 (PDF path) - Open the generated PDF in a new browser window by constructing the Reports servlet URL using the job identifier suffix extracted from the run result string.
- Step 8 (Printer path - Alert Button 2) - Assign the report filename and set the destination format to 'wided', then build the parameter string with REPORT_DESTYPE=PRINTER and MODE=CHARACTER BLANKPAGES=NO using the same six input parameters.
- Step 9 (Printer path) - Set the report server property and invoke GENERAL.PROC_REPORT_CALL, passing the report object handle and receiving back the report handle and print output values.
- Step 10 (Printer path) - Store the returned report handle and print output in the global variables :global.reporthandle and :global.printoutput respectively.
- Step 11 (Printer path) - Call GENERAL.PROC_TIMER to initiate the report completion timer.
- Step 12 (Cancel path - Else) - Clear any pending messages and exit without generating a report.

---
**Decision Points**

DP-001

Condition:
lv_alert = Alert_Button1 (user selects the PDF / file output option from the AL_REPORT alert)

TRUE:
Configure the report object for PDF format (REPORT_DESFORMAT = PDF, REPORT_DESTYPE = FILE, MODE = BITMAP), set all report parameters and the report server, run the report via RUN_REPORT_OBJECT, and display the output in a new browser window using the Reports servlet URL.

FALSE:
Proceed to evaluate DP-002.

---

DP-002

Condition:
lv_alert = Alert_Button2 (user selects the printer output option from the AL_REPORT alert)

TRUE:
Configure the report object for wide/character format (REPORT_DESFORMAT = wided, REPORT_DESTYPE = PRINTER, MODE = CHARACTER), set all report parameters and the report server, delegate execution to GENERAL.PROC_REPORT_CALL, store the returned report handle and print output in global variables, and invoke GENERAL.PROC_TIMER.

FALSE:
User selected neither Button 1 nor Button 2 (cancel); clear any pending messages and exit without running the report.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server name must be sourced exclusively from the form global variable :global.rep_server; no hard-coded server value is permitted.
- BR-002 - Both p_principal and p_dealer must be passed to the report engine as numeric values (via TO_NUMBER conversion); all other parameters are passed as VARCHAR2 strings.
- BR-003 - Regardless of output format, the report is always generated with BLANKPAGES=NO to suppress empty pages in the output.
- BR-004 - PDF output must be rendered in BITMAP mode and delivered as a file, then surfaced to the user in a new browser window via the Reports servlet job-ID URL.
- BR-005 - Printer output must use CHARACTER mode with destination type PRINTER and must be executed through GENERAL.PROC_REPORT_CALL rather than a direct RUN_REPORT_OBJECT call, ensuring centralised printer-dispatch handling.
- BR-006 - After a successful printer-path execution, the report job handle and print output returned by GENERAL.PROC_REPORT_CALL must be persisted in the global variables :global.reporthandle and :global.printoutput for use by subsequent form logic.
- BR-007 - GENERAL.PROC_TIMER must be called immediately after GENERAL.PROC_REPORT_CALL on the printer path to manage report completion timing.
- BR-008 - If the user dismisses the AL_REPORT alert without selecting a valid output option, the procedure must clear any pending form messages and take no further action.

---
**Implementation Logic**

```plsql
PROCEDURE CALL_REPORT_ENQ(p_principal VARCHAR2,
												  p_parent 		VARCHAR2,
												  p_dealer 	  VARCHAR2,
                          p_loc 			VARCHAR2, 
                          p_comp_fa 	VARCHAR2,  
                          p_enq_num 	VARCHAR2
                         )IS
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       varchar2(2000);
	lv_print        varchar2(2000);
	LV_REP_FLAG			varchar2(1);
Begin
	repid := Find_Report_Object('REPORT_CALL');
  lv_report_name := 'vr_smp_enq';
	l_AlertId := Find_Alert('AL_REPORT');
	lv_alert := Show_Alert(l_AlertId);

	If lv_alert = Alert_Button1 Then
    Clear_Message;
	  Set_Report_Object_Property(repid,Report_Desformat,'PDF');
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_ENQ_NUM='||p_enq_num||
                                                  ' REPORT_DESTYPE =FILE'||
                                                  ' MODE=BITMAP BLANKPAGES=NO');		                                         
		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
	Elsif lv_alert = Alert_Button2 Then
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'wided');
	  SET_REPORT_OBJECT_PROPERTY(repid,Report_Other,' P_PARENT='||p_parent||
                                                  ' P_PRINCIPAL='||to_number(p_principal)||
                                                  ' P_COMP_FA='||p_comp_fa||
                                                  ' P_DEALER='||to_number(p_dealer)||
                                                  ' P_LOC='||p_loc||
                                                  ' P_ENQ_NUM='||p_enq_num||
                                                  ' REPORT_DESTYPE =PRINTER'||
                                                  ' MODE=CHARACTER BLANKPAGES=NO');		                                         
	 	SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
	 	general.PROC_REPORT_CALL (REPID,lv_report,lv_print);
	 	:global.reporthandle := lv_report;
		:global.printoutput  := lv_print;
        general.PROC_TIMER;	
	Else
		Clear_Message;
	End If;
End;
```

#### SP-002 - POP_ADDON_DETAILS

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]

---

**Screen:**

Addon Details (WN_MAIN / CN_ADDON)

---

**Purpose**

Populates the Addon Details block (B_ADDON_DLT) on the Addon Details screen (WN_MAIN / CN_ADDON) when a checkbox change event fires. The procedure retrieves AMC add-on line items from GBL_AMC_DTL that have a matching record in GBL_SMP for the current vehicle, package, and organisational context, displays each line in the detail block, and then accumulates gross amounts and discounts by service type (Labour, Parts, Consumables, and overall package) into the B_ADDON and B_VH_AMC_ENQ summary fields - including combined base-plus-addon subtotals.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to block B_ADDON_DLT and clear it without validation, then position to the first record, preparing the block for fresh population.
- Step 2 - Execute cursor cur_add against GBL_AMC_DTL, filtered by the current session context (parent_group, dealer, loc_cd, comp_fa), the selected vehicle registration (B_VH_AMC_ENQ.REG_NUM), and package code (B_VH_AMC_ENQ.PKG_CODE). Only rows that have a corresponding record in GBL_SMP for the same key attributes and addon_type are included; results are ordered by addon_type, then srv_type descending.
- Step 3 - For each row returned by cur_add, write the service type, service code, quantity, discount percentage, rate, basic amount, discount amount, post-MCP-discount total, post-dealer-discount total, net amount, charge amount, group code, service description, group description, dealer discount indicator (defaulting to 'P' if null), dealer discount, and dealer discount amount into the corresponding B_ADDON_DLT fields.
- Step 4 - Accumulate running package-level totals: add the row's sell_price to ln_pkg_amt_add and discount_amt to ln_pkg_dis_add for every row processed.
- Step 5 - Classify each row by srv_type and accumulate into the appropriate service-type bucket: srv_type = 'L' increments ln_lbr_amt_add and ln_lbr_dis_add; srv_type = 'P' increments ln_part_amt_add and ln_part_dis_add; srv_type = 'C' increments ln_cons_amt_add and ln_cons_dis_add.
- Step 6 - Advance to the next record in B_ADDON_DLT after each iteration; reset to the first record after the loop completes.
- Step 7 - Execute cursor cur_sum against GBL_AMC_DTL using the same organisational and vehicle/package filters, additionally restricting to the currently selected addon code (B_ADDON.ADDON_CODE). Accumulate sell_price into ln_addon_amt, discount_amt into ln_addon_dis, and tot_value into ln_addon_net across all matching rows.
- Step 8 - Write the addon-level summary totals (ln_addon_amt, ln_addon_dis, ln_addon_net) to B_ADDON.BASIC_AMT_ADDON, B_ADDON.DISCOUNT_AMT_ADDON, and B_ADDON.TOT_AFT_MCP_DISC_ADDON respectively.
- Step 9 - Populate B_VH_AMC_ENQ with the service-type breakdown amounts and discounts: labr_addon_amt, part_addon_amt, cons_addon_amt, addon_amt (package total), nb_lbr_disc_add, nb_part_disc_add, nb_cons_disc_add, and nb_tot_disc_add.
- Step 10 - Calculate addon-only net subtotals per service type (amount minus discount) and store them in nb_add_lbr_subtot, nb_add_part_subtot, nb_add_cons_subtot, and nb_add_tot_subtot on B_VH_AMC_ENQ.
- Step 11 - Compute combined base-plus-addon subtotals by adding each existing base subtotal (NB_LBR_SUBTOT, NB_PART_SUBTOT, NB_CONS_SUBTOT, NB_TOT_SUBTOT) to its corresponding addon subtotal, and store the results in NB_LBR_SUBTOT_ADD, NB_PART_SUBTOT_ADD, NB_CONS_SUBTOT_ADD, and NB_TOT_SUBTOT_ADD on B_VH_AMC_ENQ.

---
**Decision Points**

DP-001

Condition:
The GBL_AMC_DTL row processed by cur_add has srv_type = 'L'.

TRUE:
The row's sell_price is added to the Labour amount accumulator (ln_lbr_amt_add) and its discount_amt is added to the Labour discount accumulator (ln_lbr_dis_add).

FALSE:
The Labour accumulators are not updated; evaluation continues to DP-002.

---

DP-002

Condition:
The GBL_AMC_DTL row processed by cur_add has srv_type = 'P' (evaluated only when DP-001 is FALSE).

TRUE:
The row's sell_price is added to the Parts amount accumulator (ln_part_amt_add) and its discount_amt is added to the Parts discount accumulator (ln_part_dis_add).

FALSE:
The Parts accumulators are not updated; evaluation continues to DP-003.

---

DP-003

Condition:
The GBL_AMC_DTL row processed by cur_add has srv_type = 'C' (evaluated only when DP-001 and DP-002 are both FALSE).

TRUE:
The row's sell_price is added to the Consumables amount accumulator (ln_cons_amt_add) and its discount_amt is added to the Consumables discount accumulator (ln_cons_dis_add).

FALSE:
No service-type-specific accumulator is updated for this row; the row still contributes to the package-level totals (ln_pkg_amt_add, ln_pkg_dis_add).

---

DP-004

Condition:
The dlr_disc_ind value retrieved from GBL_AMC_DTL for a cur_add row is NULL.

TRUE:
The B_ADDON_DLT.DLR_DISC_IND field is set to the default value 'P'.

FALSE:
B_ADDON_DLT.DLR_DISC_IND is set to the actual dlr_disc_ind value from the database.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Read GBL_SMP - Reads data from GBL_SMP for lookup or validation.
**Business Rules**

- BR-001 - Only add-on detail lines from GBL_AMC_DTL that have a corresponding active record in GBL_SMP for the same parent_group, dealer_map_cd, loc_cd, comp_fa, reg_num, pkg_code, and addon_type are eligible for display in the detail block; unmatched lines are excluded.
- BR-002 - The detail block (B_ADDON_DLT) is fully cleared without validation before repopulation, ensuring no stale data from a previous addon selection remains on screen.
- BR-003 - Add-on detail lines are presented ordered first by addon_type and then by srv_type in descending order, providing a consistent grouping and sequencing for the user.
- BR-004 - A NULL dealer discount indicator (dlr_disc_ind) must default to 'P' when written to the B_ADDON_DLT block.
- BR-005 - Addon-level summary totals (basic amount, discount amount, and post-MCP-discount total written to B_ADDON) are derived exclusively from GBL_AMC_DTL rows matching the currently selected addon code (B_ADDON.ADDON_CODE), independently of the full detail population query.
- BR-006 - Service-type net subtotals (nb_add_lbr_subtot, nb_add_part_subtot, nb_add_cons_subtot, nb_add_tot_subtot) are calculated as the difference between the accumulated sell_price and discount_amt for each service type; NVL protection ensures NULL values are treated as zero in all arithmetic.
- BR-007 - Combined base-plus-addon subtotals (NB_LBR_SUBTOT_ADD, NB_PART_SUBTOT_ADD, NB_CONS_SUBTOT_ADD, NB_TOT_SUBTOT_ADD) are derived by adding the pre-existing base package subtotals already held in B_VH_AMC_ENQ to the newly computed addon subtotals, maintaining a running cumulative view of total service costs including add-ons.
- BR-008 - All amount and discount accumulators are initialised to zero before the cursors execute, preventing carry-over from any prior invocation within the same session context.

---
**Implementation Logic**

```plsql
PROCEDURE POP_ADDON_DETAILS IS
	CURSOR cur_add IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     --AND r.addon_type = :B_ADDON.ADDON_CODE
	     AND EXISTS (SELECT 1
                    FROM gbl_smp a
                   WHERE a.parent_group = r.parent_group
                     AND a.dealer_map_cd = r.dealer_map_cd
                     AND a.loc_cd = r.loc_cd
                     AND a.comp_fa = r.comp_fa      
                     AND a.reg_num = r.reg_num
                     AND a.pkg_code = r.pkg_code
                     AND a.addon_type = r.addon_type
                     )
      ORDER BY r.addon_type, r.srv_type DESC;

	CURSOR cur_sum IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type = :B_ADDON.ADDON_CODE;
  
  ln_addon_amt   NUMBER(12,3) := 0;	
	ln_addon_dis   NUMBER(12,3) := 0;
	ln_addon_net   NUMBER(12,3) := 0;
	
	ln_pkg_amt_add   NUMBER(12,3) := 0;
  ln_lbr_amt_add   NUMBER(12,3) := 0;
  ln_part_amt_add  NUMBER(12,3) := 0;
  ln_cons_amt_add  NUMBER(12,3) := 0;  	     	     	  	       	     
  
  ln_pkg_dis_add   NUMBER(12,3) := 0;
  ln_lbr_dis_add   NUMBER(12,3) := 0;
  ln_part_dis_add  NUMBER(12,3) := 0;
  ln_cons_dis_add  NUMBER(12,3) := 0;

BEGIN
	go_block('B_ADDON_DLT');
	clear_block(NO_VALIDATE);
	first_record;
	FOR cur_i IN cur_add LOOP
		:B_ADDON_DLT.SRV_TYPE := cur_i.srv_type;
		:B_ADDON_DLT.SRV_CODE := cur_i.srv_cd;	
		:B_ADDON_DLT.QTY      := cur_i.qty;	
		:B_ADDON_DLT.DISCOUNT_PER := cur_i.discount_per;	
		:B_ADDON_DLT.RATE := cur_i.rate;	
		:B_ADDON_DLT.BASIC_AMT := cur_i.sell_price;	
		:B_ADDON_DLT.DISCOUNT_AMT := cur_i.discount_amt;	
		    
    :B_ADDON_DLT.TOT_AFT_MCP_DISC := cur_i.tot_value;	
    :B_ADDON_DLT.TOT_AFT_DLR_DISC := cur_i.tot_aft_dlr_disc;
		:B_ADDON_DLT.NET_AMT := cur_i.net_value;				
		:B_ADDON_DLT.CHARGE_AMT := cur_i.charge_amt;	
		
		:B_ADDON_DLT.GROUP_CD := cur_i.group_cd;		
		:B_ADDON_DLT.NB_SRV_DESC := cur_i.srv_desc;
		:B_ADDON_DLT.NB_GROUP_DESC := cur_i.group_desc;
		
		:B_ADDON_DLT.DLR_DISC_IND := NVL(cur_i.dlr_disc_ind,'P');
		:B_ADDON_DLT.DLR_DISC     := cur_i.dlr_disc;
		:B_ADDON_DLT.DLR_DISC_AMT := cur_i.dlr_disc_amt;		

    ln_pkg_amt_add := NVL(ln_pkg_amt_add, 0) + NVL(cur_i.sell_price, 0);
		ln_pkg_dis_add := NVL(ln_pkg_dis_add, 0) + NVL(cur_i.discount_amt, 0);
		
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_amt_add  := NVL(ln_lbr_amt_add, 0) + NVL(cur_i.sell_price, 0);
			ln_lbr_dis_add  := NVL(ln_lbr_dis_add, 0) + NVL(cur_i.discount_amt, 0);
	  ELSIF cur_i.srv_type = 'P' THEN
			ln_part_amt_add := NVL(ln_part_amt_add, 0) + NVL(cur_i.sell_price, 0);
			ln_part_dis_add := NVL(ln_part_dis_add, 0) + NVL(cur_i.discount_amt, 0);
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_amt_add := NVL(ln_cons_amt_add, 0) + NVL(cur_i.sell_price, 0);
			ln_cons_dis_add := NVL(ln_cons_dis_add, 0) + NVL(cur_i.discount_amt, 0);
		END IF;	
		next_record;		
	END LOOP;	
	  first_record;

	FOR cur_s IN cur_sum LOOP
		ln_addon_amt := NVL(ln_addon_amt, 0) + NVL(cur_s.sell_price, 0);
		ln_addon_dis := NVL(ln_addon_dis, 0) + NVL(cur_s.discount_amt, 0);
		ln_addon_net := NVL(ln_addon_net, 0) + NVL(cur_s.tot_value, 0);
		next_record;		
	END LOOP;	
    first_record;
    
		:B_ADDON.BASIC_AMT_ADDON         := ln_addon_amt;	
		:B_ADDON.DISCOUNT_AMT_ADDON      := ln_addon_dis;			    
    :B_ADDON.TOT_AFT_MCP_DISC_ADDON  := ln_addon_net;	
    
    :B_VH_AMC_ENQ.labr_addon_amt  	 := ln_lbr_amt_add;
	  :B_VH_AMC_ENQ.part_addon_amt  	 := ln_part_amt_add;
	  :B_VH_AMC_ENQ.cons_addon_amt  	 := ln_cons_amt_add;
		:B_VH_AMC_ENQ.addon_amt       	 := ln_pkg_amt_add;

    :B_VH_AMC_ENQ.nb_lbr_disc_add  	 := ln_lbr_dis_add;
    :B_VH_AMC_ENQ.nb_part_disc_add 	 := ln_part_dis_add;
    :B_VH_AMC_ENQ.nb_cons_disc_add 	 := ln_cons_dis_add;
    :B_VH_AMC_ENQ.nb_tot_disc_add  	 := ln_pkg_dis_add;

    :B_VH_AMC_ENQ.nb_add_lbr_subtot  := NVL(ln_lbr_amt_add,0) - NVL(ln_lbr_dis_add,0);
    :B_VH_AMC_ENQ.nb_add_part_subtot := NVL(ln_part_amt_add,0) - NVL(ln_part_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_cons_subtot := NVL(ln_cons_amt_add,0) - NVL(ln_cons_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_tot_subtot  := NVL(ln_pkg_amt_add,0) - NVL(ln_pkg_dis_add,0); 

	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_LBR_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_lbr_subtot,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_PART_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_part_subtot,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_CONS_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_cons_subtot,0);  
		:B_VH_AMC_ENQ.NB_TOT_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_TOT_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_tot_subtot,0);
END;
```

#### SP-003 - POP_DETAILS_AFT_DISC

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Details (WN_MAIN / CN_DEF)

---

**Purpose**

Populates the B_VD_AMC_ENQ detail block and computes all financial summary totals on the B_VH_AMC_ENQ header block after discounts have been applied. The procedure retrieves standard package service lines and add-on service lines from GBL_AMC_DTL for the current vehicle/package context, displays each line in the detail grid, and rolls up sell prices, MCP discounts, dealer discounts, taxes, and net values by service type (Labour, Parts, Consumables) and by package vs. add-on category.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to block B_VD_AMC_ENQ and clear all existing rows without validation to prepare for a fresh data load.
- Step 2 - Open cursor cur_smp to retrieve standard package service lines from GBL_AMC_DTL filtered by the current parent group, dealer, location, company FA, registration number, and package code, where ADDON_TYPE is NULL. If the service option is 'L', only lines with srv_type = 'L' are included; if the service option is 'P', all srv_type values are included. Results are ordered by serial number.
- Step 3 - For each standard package row returned by cur_smp, write all service detail fields (serial number, service type, service code, quantity, discount percentage, rate, basic amount, discount amount, totals after MCP and dealer discounts, net amount, sell price, charge amount, HSN/SAC code, category, group, add-on type, descriptions, dealer discount indicator, dealer discount value and amount) into the current B_VD_AMC_ENQ record.
- Step 4 - Accumulate running package-level totals (ln_pkg_amt, ln_pkg_dis, ln_pkg_dis_dlr, ln_pkg_net) from each standard line's sell price, discount amount, dealer discount amount, and net value.
- Step 5 - Within the same loop, branch on srv_type to accumulate separate Labour ('L'), Parts ('P'), and Consumables ('C') sub-totals for amount, MCP discount, dealer discount, tax (charge_amt), and net value into their respective accumulators.
- Step 6 - Advance to the next form record after each standard line is written.
- Step 7 - Open cursor cur_add to retrieve add-on service lines from GBL_AMC_DTL for the same vehicle/package context where ADDON_TYPE IS NOT NULL, ordered by addon_type then serial number.
- Step 8 - For each add-on row, write the same set of detail fields into the current B_VD_AMC_ENQ record. For the GROUP_CD display field, use ADDON_TYPE if populated, otherwise use the stored group code.
- Step 9 - Resolve the NB_GROUP_DESC for add-on lines: if ADDON_TYPE is not null, look up LIST_DESC from AM_LIST where LIST_NAME = 'SMP_ADDON' and LIST_CODE matches the add-on type for the current principal; if the lookup fails for any reason, fall back to the raw ADDON_TYPE value. If ADDON_TYPE is null, use the stored group description.
- Step 10 - Accumulate add-on package-level totals (ln_pkg_amt_add, ln_pkg_dis_add combining both discount_amt and dlr_disc_amt, ln_pkg_net_add) and, branching on srv_type, accumulate Labour, Parts, and Consumables add-on sub-totals for amount, combined discount, tax, and net.
- Step 11 - Advance to the next form record after each add-on line is written.
- Step 12 - Return focus to the first record of B_VD_AMC_ENQ.
- Step 13 - Write accumulated standard-package amounts, MCP discounts, dealer discounts, combined total discounts, and sub-totals (amount minus total discount) by service type to the corresponding B_VH_AMC_ENQ header fields.
- Step 14 - Write accumulated add-on amounts, combined add-on discounts, and add-on sub-totals by service type to the add-on summary fields on B_VH_AMC_ENQ.
- Step 15 - Compute and write combined sub-totals (standard sub-total + add-on sub-total) per service type to the NB_*_SUBTOT_ADD fields.
- Step 16 - Compute and write total tax as the sum of Labour, Parts, and Consumables tax accumulators across both standard and add-on lines, and write the per-type tax breakdowns.
- Step 17 - Compute and write the overall total bill amount and per-type net amounts as the sum of standard and add-on net value accumulators.

---
**Decision Points**

DP-001

Condition:
:B_VH_AMC_ENQ.SERV_OPTION = 'L'

TRUE:
cur_smp filters GBL_AMC_DTL to rows where srv_type = 'L' (Labour-only service option).

FALSE:
If SERV_OPTION = 'P', cur_smp includes rows of all srv_type values (r.srv_type = r.srv_type is always true), returning the full package.

---

DP-002

Condition:
cur_i.srv_type = 'L' (within the cur_smp accumulation loop)

TRUE:
The line's sell price, MCP discount, dealer discount, tax, and net value are added to the Labour accumulators (ln_lbr_*).

FALSE:
Proceed to check DP-003.

---

DP-003

Condition:
cur_i.srv_type = 'P' (within the cur_smp accumulation loop)

TRUE:
The line's values are added to the Parts accumulators (ln_part_*).

FALSE:
Proceed to check DP-004.

---

DP-004

Condition:
cur_i.srv_type = 'C' (within the cur_smp accumulation loop)

TRUE:
The line's values are added to the Consumables accumulators (ln_cons_*).

FALSE:
No service-type sub-total is updated; the line still contributes to the package-level totals.

---

DP-005

Condition:
cur_a.addon_type IS NOT NULL (within the cur_add display loop, for GROUP_CD assignment)

TRUE:
:B_VD_AMC_ENQ.GROUP_CD is set to cur_a.addon_type.

FALSE:
:B_VD_AMC_ENQ.GROUP_CD is set to cur_a.group_cd.

---

DP-006

Condition:
cur_a.addon_type IS NOT NULL (within the cur_add display loop, for NB_GROUP_DESC resolution)

TRUE:
A SELECT is executed against AM_LIST (LIST_NAME = 'SMP_ADDON', PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL, LIST_CODE = cur_a.addon_type) to retrieve LIST_DESC. If the query raises any exception, NB_GROUP_DESC falls back to the raw addon_type value.

FALSE:
:B_VD_AMC_ENQ.NB_GROUP_DESC is set directly from cur_a.group_desc.

---

DP-007

Condition:
cur_a.srv_type = 'L' (within the cur_add accumulation loop)

TRUE:
The add-on line's values are added to the Labour add-on accumulators (ln_lbr_*_add).

FALSE:
Proceed to check DP-008.

---

DP-008

Condition:
cur_a.srv_type = 'P' (within the cur_add accumulation loop)

TRUE:
The add-on line's values are added to the Parts add-on accumulators (ln_part_*_add).

FALSE:
Proceed to check DP-009.

---

DP-009

Condition:
cur_a.srv_type = 'C' (within the cur_add accumulation loop)

TRUE:
The add-on line's values are added to the Consumables add-on accumulators (ln_cons_*_add).

FALSE:
No service-type add-on sub-total is updated; the line still contributes to the package-level add-on totals.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - Standard package lines are identified by ADDON_TYPE IS NULL in GBL_AMC_DTL; add-on lines are identified by ADDON_TYPE IS NOT NULL. The two sets are processed separately and displayed in sequence in the detail block.
- BR-002 - When the service option is 'L' (Labour only), only Labour service lines (srv_type = 'L') are loaded into the detail block from the standard package cursor; when the service option is 'P' (Full Package), lines of all service types are loaded.
- BR-003 - The dealer discount indicator defaults to 'P' when no value is stored (NVL(dlr_disc_ind, 'P')), ensuring the field is never left null on the form.
- BR-004 - For standard package lines, MCP discount (discount_amt) and dealer discount (dlr_disc_amt) are accumulated separately; the combined total discount per service type is the sum of both.
- BR-005 - For add-on lines, the combined discount accumulator (ln_pkg_dis_add and its service-type equivalents) is computed as discount_amt + dlr_disc_amt in a single accumulation step, not separately.
- BR-006 - Sub-totals at both the standard-package level and the add-on level are calculated as gross sell price minus the applicable total discount (standard: MCP disc + dealer disc separately tracked; add-on: combined disc).
- BR-007 - Combined sub-totals (NB_*_SUBTOT_ADD fields) represent the sum of the standard sub-total and the add-on sub-total for each service type, providing a single net-before-tax figure across the full AMC package.
- BR-008 - Total tax (NB_TAX_AMT) and per-type tax fields are the sum of charge_amt across both standard and add-on lines for each service type; tax is not split between MCP and dealer portions.
- BR-009 - The overall total bill amount (TOT_BILL_AMT) is the sum of net_value across all standard and add-on lines, representing the final payable amount after all discounts and including taxes.
- BR-010 - The group description for add-on lines is sourced from AM_LIST using the add-on type code and the current principal mapping; if no matching list entry exists, the raw addon_type code is displayed as a fallback to ensure the field is always populated.
- BR-011 - All numeric accumulations use NVL to treat NULL values as zero, preventing arithmetic errors when individual line amounts are not populated.

---
**Implementation Logic**

```plsql
PROCEDURE POP_DETAILS_AFT_DISC IS
	CURSOR cur_smp IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NULL
	     AND ((:B_VH_AMC_ENQ.SERV_OPTION = 'L' AND r.srv_type = 'L') OR 
	          (:B_VH_AMC_ENQ.SERV_OPTION = 'P' AND r.srv_type = r.srv_type))
	   ORDER BY r.srl_num;       

	CURSOR cur_add IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NOT NULL
	   ORDER BY r.addon_type, r.srl_num;
  
  ln_pkg_amt   NUMBER(12,3) := 0;
  ln_lbr_amt   NUMBER(12,3) := 0;
  ln_part_amt  NUMBER(12,3) := 0;
  ln_cons_amt  NUMBER(12,3) := 0;  	     	     	
	
	ln_pkg_dis   NUMBER(12,3) := 0;
  ln_lbr_dis   NUMBER(12,3) := 0;
  ln_part_dis  NUMBER(12,3) := 0;
  ln_cons_dis  NUMBER(12,3) := 0;
  
  ln_pkg_dis_dlr   NUMBER(12,3) := 0;  	    
  ln_lbr_dis_dlr   NUMBER(12,3) := 0;
  ln_part_dis_dlr  NUMBER(12,3) := 0;
  ln_cons_dis_dlr  NUMBER(12,3) := 0;  	    

  ln_lbr_tax   NUMBER(12,3) := 0;
  ln_part_tax  NUMBER(12,3) := 0;
  ln_cons_tax  NUMBER(12,3) := 0;  	    
	
	ln_pkg_net   NUMBER(12,3) := 0;
  ln_lbr_net   NUMBER(12,3) := 0;
  ln_part_net  NUMBER(12,3) := 0;
  ln_cons_net  NUMBER(12,3) := 0;  	       	     

  ln_pkg_amt_add   NUMBER(12,3) := 0;
  ln_lbr_amt_add   NUMBER(12,3) := 0;
  ln_part_amt_add  NUMBER(12,3) := 0;
  ln_cons_amt_add  NUMBER(12,3) := 0;  	

	ln_pkg_dis_add   NUMBER(12,3) := 0;
  ln_lbr_dis_add   NUMBER(12,3) := 0;
  ln_part_dis_add  NUMBER(12,3) := 0;
  ln_cons_dis_add  NUMBER(12,3) := 0;

  ln_lbr_tax_add   NUMBER(12,3) := 0;
  ln_part_tax_add  NUMBER(12,3) := 0;
  ln_cons_tax_add  NUMBER(12,3) := 0;  	    

	ln_pkg_net_add   NUMBER(12,3) := 0;
  ln_lbr_net_add   NUMBER(12,3) := 0;
  ln_part_net_add  NUMBER(12,3) := 0;
  ln_cons_net_add  NUMBER(12,3) := 0;  	       	     
     	     	  	       	     
BEGIN	
	go_block('B_VD_AMC_ENQ');
	clear_block(NO_VALIDATE);
	first_record;
	FOR cur_i IN cur_smp LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_i.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_i.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_i.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_i.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_i.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_i.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_i.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_i.discount_amt;	
    
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_i.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_i.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_i.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_i.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_i.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_i.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_i.catg_cd;		
		:B_VD_AMC_ENQ.GROUP_CD := cur_i.group_cd;		
		:B_VD_AMC_ENQ.ADDON_TYPE  := cur_i.addon_type;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_i.srv_desc;
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_i.catg_desc;
		:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_i.group_desc;
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_i.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_i.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_i.dlr_disc_amt;
		
		ln_pkg_amt := NVL(ln_pkg_amt, 0) + NVL(cur_i.sell_price, 0);
		ln_pkg_dis := NVL(ln_pkg_dis, 0) + NVL(cur_i.discount_amt, 0);
		ln_pkg_dis_dlr := NVL(ln_pkg_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
		ln_pkg_net := NVL(ln_pkg_net, 0) + NVL(cur_i.net_value, 0);
		
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_amt := NVL(ln_lbr_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_lbr_dis := NVL(ln_lbr_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_lbr_dis_dlr := NVL(ln_lbr_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_lbr_tax := NVL(ln_lbr_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_lbr_net := NVL(ln_lbr_net, 0) + NVL(cur_i.net_value, 0);
	  ELSIF cur_i.srv_type = 'P' THEN
			ln_part_amt := NVL(ln_part_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_part_dis := NVL(ln_part_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_part_dis_dlr := NVL(ln_part_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_part_tax := NVL(ln_part_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_part_net := NVL(ln_part_net, 0) + NVL(cur_i.net_value, 0);
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_amt := NVL(ln_cons_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_cons_dis := NVL(ln_cons_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_cons_dis_dlr := NVL(ln_cons_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_cons_tax := NVL(ln_cons_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_cons_net := NVL(ln_cons_net, 0) + NVL(cur_i.net_value, 0);
		END IF;						
		next_record;		
	END LOOP;	
	
	FOR cur_a IN cur_add LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_a.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_a.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_a.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_a.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_a.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_a.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_a.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_a.discount_amt;	
    
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_a.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_a.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_a.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_a.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_a.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_a.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_a.catg_cd;	
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_a.catg_desc;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_a.srv_desc;			
		:B_VD_AMC_ENQ.GROUP_CD := NVL(cur_a.addon_type,cur_a.group_cd);	
		:B_VD_AMC_ENQ.ADDON_TYPE  := cur_a.addon_type;
		
		IF cur_a.addon_type IS NOT NULL THEN
			BEGIN
				SELECT LIST_DESC 
				  INTO :B_VD_AMC_ENQ.NB_GROUP_DESC
          FROM AM_LIST l
         WHERE LIST_NAME = 'SMP_ADDON'
           AND PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL
           AND LIST_CODE = cur_a.addon_type;
			EXCEPTION WHEN OTHERS THEN
				:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.addon_type;
			END;	
		ELSE
			:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.group_desc;
	  END IF;				
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_a.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_a.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_a.dlr_disc_amt;
		
		ln_pkg_amt_add := NVL(ln_pkg_amt_add, 0) + NVL(cur_a.sell_price, 0);
		ln_pkg_dis_add := NVL(ln_pkg_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
		ln_pkg_net_add := NVL(ln_pkg_net_add, 0) + NVL(cur_a.net_value, 0);
		
		IF cur_a.srv_type = 'L' THEN
			ln_lbr_amt_add  := NVL(ln_lbr_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_lbr_dis_add  := NVL(ln_lbr_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_lbr_tax_add  := NVL(ln_lbr_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_lbr_net_add  := NVL(ln_lbr_net_add, 0) + NVL(cur_a.net_value, 0);
	  ELSIF cur_a.srv_type = 'P' THEN
			ln_part_amt_add := NVL(ln_part_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_part_dis_add := NVL(ln_part_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_part_tax_add := NVL(ln_part_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_part_net_add := NVL(ln_part_net_add, 0) + NVL(cur_a.net_value, 0);
		ELSIF cur_a.srv_type = 'C' THEN
			ln_cons_amt_add := NVL(ln_cons_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_cons_dis_add := NVL(ln_cons_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_cons_tax_add := NVL(ln_cons_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_cons_net_add := NVL(ln_cons_net_add, 0) + NVL(cur_a.net_value, 0);
		END IF;						
		next_record;		
	END LOOP;	

	  first_record;
	  
	  :B_VH_AMC_ENQ.PKG_AMT    := ln_pkg_amt;
	  :B_VH_AMC_ENQ.LABOUR_AMT := ln_lbr_amt;
	  :B_VH_AMC_ENQ.PART_AMT   := ln_part_amt;
	  :B_VH_AMC_ENQ.CONSUMABLE_AMT := ln_cons_amt;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT  := ln_pkg_dis;	  
	  :B_VH_AMC_ENQ.NB_LBR_DISC   := ln_lbr_dis;
	  :B_VH_AMC_ENQ.NB_PART_DISC  := ln_part_dis;
	  :B_VH_AMC_ENQ.NB_CONS_DISC  := ln_cons_dis;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT_DLR  := ln_pkg_dis_dlr;
	  :B_VH_AMC_ENQ.NB_LBR_DISC_DLR 	:= ln_lbr_dis_dlr;
    :B_VH_AMC_ENQ.NB_PART_DISC_DLR 	:= ln_part_dis_dlr;
    :B_VH_AMC_ENQ.NB_CONS_DISC_DLR 	:= ln_cons_dis_dlr;

	  :B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT  := NVL(ln_pkg_dis_dlr,0) + NVL(ln_pkg_dis,0);
	  :B_VH_AMC_ENQ.NB_LBR_DISC_TOT 	:= NVL(ln_lbr_dis_dlr,0) + NVL(ln_lbr_dis,0); 
    :B_VH_AMC_ENQ.NB_PART_DISC_TOT 	:= NVL(ln_part_dis_dlr,0) + NVL(ln_part_dis,0); 
    :B_VH_AMC_ENQ.NB_CONS_DISC_TOT 	:= NVL(ln_cons_dis_dlr,0) + NVL(ln_cons_dis,0);  

	  :B_VH_AMC_ENQ.NB_TOT_SUBTOT   := NVL(:B_VH_AMC_ENQ.PKG_AMT ,0) - NVL(:B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT,0);
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.LABOUR_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_LBR_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.PART_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_PART_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.CONSUMABLE_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_CONS_DISC_TOT,0);  
	  
	  :B_VH_AMC_ENQ.labr_addon_amt  := ln_lbr_amt_add;
	  :B_VH_AMC_ENQ.part_addon_amt  := ln_part_amt_add;
	  :B_VH_AMC_ENQ.cons_addon_amt  := ln_cons_amt_add;
		:B_VH_AMC_ENQ.addon_amt       := ln_pkg_amt_add;
		    
    :B_VH_AMC_ENQ.nb_lbr_disc_add  := ln_lbr_dis_add;
    :B_VH_AMC_ENQ.nb_part_disc_add := ln_part_dis_add;
    :B_VH_AMC_ENQ.nb_cons_disc_add := ln_cons_dis_add;
    :B_VH_AMC_ENQ.nb_tot_disc_add  := ln_pkg_dis_add;

    :B_VH_AMC_ENQ.nb_add_lbr_subtot := NVL(ln_lbr_amt_add,0) - NVL(ln_lbr_dis_add,0);
    :B_VH_AMC_ENQ.nb_add_part_subtot := NVL(ln_part_amt_add,0) - NVL(ln_part_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_cons_subtot := NVL(ln_cons_amt_add,0) - NVL(ln_cons_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_tot_subtot  := NVL(ln_pkg_amt_add,0) - NVL(ln_pkg_dis_add,0); 
        	  
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_LBR_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_lbr_subtot,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_PART_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_part_subtot,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_CONS_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_cons_subtot,0);  
		:B_VH_AMC_ENQ.NB_TOT_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_TOT_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_tot_subtot,0);
		
	  :B_VH_AMC_ENQ.NB_TAX_AMT   := NVL(ln_lbr_tax,0) + NVL(ln_part_tax,0) + NVL(ln_cons_tax,0) 
	                                      + NVL(ln_lbr_tax_add,0) + NVL(ln_part_tax_add,0) + NVL(ln_cons_tax_add,0);
	  :B_VH_AMC_ENQ.NB_LBR_TAX   := NVL(ln_lbr_tax,0) + NVL(ln_lbr_tax_add,0);
	  :B_VH_AMC_ENQ.NB_PART_TAX  := NVL(ln_part_tax,0) + NVL(ln_part_tax_add,0);
	  :B_VH_AMC_ENQ.NB_CONS_TAX  := NVL(ln_cons_tax,0) + NVL(ln_cons_tax_add,0);
	  
	  :B_VH_AMC_ENQ.TOT_BILL_AMT := NVL(ln_pkg_net,0) + NVL(ln_pkg_net_add,0);
	  :B_VH_AMC_ENQ.NB_LBR_NET   := NVL(ln_lbr_net,0) + NVL(ln_lbr_net_add,0);
	  :B_VH_AMC_ENQ.NB_PART_NET  := NVL(ln_part_net,0) + NVL(ln_part_net_add,0);
	  :B_VH_AMC_ENQ.NB_CONS_NET  := NVL(ln_cons_net,0) + NVL(ln_cons_net_add,0);
END;
```

#### SP-004 - POP_DISC

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Details (WN_MAIN / CN_DEF)

---

**Purpose**

POP_DISC populates dealer discount details on AMC (Annual Maintenance Contract) service-line records. When triggered by a button press on the Details screen, it iterates over all GBL_AMC_DTL rows matching the current enquiry context and, for each service type (Parts, Consumables, Labour), calculates and writes the applicable dealer discount indicator, discount rate, discount amount, and post-discount total back to the same row.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open a cursor over GBL_AMC_DTL rows filtered by the current session context (PARENT_GROUP, DEALER_MAP_CD, LOC_CD, COMP_FA, REG_NUM, PKG_CODE) to retrieve each service-line's ROWID, service type, and total value.
- Step 2 - For each row returned, initialise working variables: lv_disc_int = NULL, lv_disc = NULL, lv_disc_amt = 0, ln_tot_amt = 0, lv_upd = 'N'.
- Step 3 - Evaluate the service type of the current row against three mutually exclusive branches (Parts = 'P', Consumables = 'C', Labour = 'L'), but only when the corresponding dealer discount value on the form block CB_VT_AMC_ENQ is greater than zero.
- Step 4 - Within the matching branch, capture the discount indicator (Percentage = 'P' or Amount = 'A') from the relevant form item and set lv_upd = 'Y' to flag that an update is required.
- Step 5 - Calculate the discount amount based on the indicator type: if 'P' (percentage), multiply the row's total value by the discount rate and divide by 100; if 'A' (absolute amount), distribute the total discount evenly across the applicable service-line count using ROUND, and set lv_disc_amt equal to that per-line amount.
- Step 6 - After the service-type evaluation, check whether lv_upd = 'Y'. If so, compute the post-discount total as tot_value minus lv_disc_amt.
- Step 7 - If the computed post-discount total is negative, floor it to zero to prevent negative contract values.
- Step 8 - Update the GBL_AMC_DTL row (identified by ROWID) with the calculated DLR_DISC_IND, DLR_DISC, DLR_DISC_AMT, and TOT_AFT_DLR_DISC values.
- Step 9 - Continue to the next cursor row until all matching service lines have been processed.

---
**Decision Points**

DP-001

Condition:
The current GBL_AMC_DTL row has srv_type = 'P' AND the Parts dealer discount on the form (CB_VT_AMC_ENQ.DLR_PART_DISC) is greater than zero.

TRUE:
Capture the Parts discount indicator into lv_disc_int, set lv_upd = 'Y', and proceed to DP-002 to determine the discount calculation method.

FALSE:
Evaluate DP-003 (Consumables branch).

---

DP-002

Condition:
The Parts discount indicator (CB_VT_AMC_ENQ.PART_DISC_IND) equals 'P' (percentage).

TRUE:
Set lv_disc to the percentage rate (DLR_PART_DISC) and calculate lv_disc_amt as tot_value × lv_disc / 100.

FALSE (indicator = 'A', absolute amount):
Distribute the total Parts discount evenly: lv_disc = ROUND(DLR_PART_DISC / NB_PART_CNT, 2); lv_disc_amt = lv_disc.

---

DP-003

Condition:
The current row has srv_type = 'C' AND CB_VT_AMC_ENQ.DLR_CONS_DISC is greater than zero.

TRUE:
Capture the Consumables discount indicator, set lv_upd = 'Y', and proceed to DP-004.

FALSE:
Evaluate DP-005 (Labour branch).

---

DP-004

Condition:
The Consumables discount indicator (CB_VT_AMC_ENQ.CONS_DISC_IND) equals 'P'.

TRUE:
Set lv_disc to DLR_CONS_DISC and calculate lv_disc_amt as tot_value × lv_disc / 100.

FALSE (indicator = 'A'):
Distribute the total Consumables discount evenly: lv_disc = ROUND(DLR_CONS_DISC / NB_CONS_CNT, 2); lv_disc_amt = lv_disc.

---

DP-005

Condition:
The current row has srv_type = 'L' AND CB_VT_AMC_ENQ.DLR_LAB_DISC is greater than zero.

TRUE:
Capture the Labour discount indicator, set lv_upd = 'Y', and proceed to DP-006.

FALSE:
No discount is applicable for this row; lv_upd remains 'N' and no update is performed.

---

DP-006

Condition:
The Labour discount indicator (CB_VT_AMC_ENQ.LAB_DISC_IND) equals 'P'.

TRUE:
Set lv_disc to DLR_LAB_DISC and calculate lv_disc_amt as tot_value × lv_disc / 100.

FALSE (indicator = 'A'):
Distribute the total Labour discount evenly: lv_disc = ROUND(DLR_LAB_DISC / NB_LBR_CNT, 2); lv_disc_amt = lv_disc.

---

DP-007

Condition:
lv_upd = 'Y' (a discount was matched and calculated for the current row).

TRUE:
Compute ln_tot_amt = tot_value - lv_disc_amt, apply the negative-floor rule (DP-008), and update GBL_AMC_DTL.

FALSE:
Skip the UPDATE statement and move to the next cursor row.

---

DP-008

Condition:
The computed post-discount total (ln_tot_amt) is less than zero.

TRUE:
Set ln_tot_amt = 0 to prevent a negative contract line value.

FALSE:
Retain the calculated ln_tot_amt as-is.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Update GBL_AMC_DTL - Updates existing rows in GBL_AMC_DTL.
**Business Rules**

- BR-001 - A dealer discount is applied to a service line only when the corresponding discount value entered on the form is greater than zero; lines with a zero or null discount are left unchanged.
- BR-002 - Each service line is categorised as Parts ('P'), Consumables ('C'), or Labour ('L'); the discount source fields and counts used in the calculation are specific to the service type and must not be mixed across types.
- BR-003 - When the discount indicator is 'P' (percentage), the discount amount is derived as a percentage of the individual service line's total value (tot_value × rate / 100).
- BR-004 - When the discount indicator is 'A' (absolute amount), the total dealer discount for the service type is distributed equally across all applicable service lines using ROUND(..., 2) to avoid rounding drift; the per-line discount amount is stored as both the rate (DLR_DISC) and the amount (DLR_DISC_AMT).
- BR-005 - The post-discount total (TOT_AFT_DLR_DISC) must never be negative; if the calculated value falls below zero it is floored to zero.
- BR-006 - Updates are performed at the individual row level using the ROWID captured in the cursor, ensuring that only the specific service-line record is modified and no unintended rows are affected.
- BR-007 - The scope of records processed is strictly bounded by the session context globals (PARENT_GROUP, DEALER_MAP_CD, LOC_CD, COMP_FA) combined with the form-block values REG_NUM and PKG_CODE, ensuring discounts are applied only to the AMC contract currently under enquiry.

---
**Implementation Logic**

```plsql
PROCEDURE POP_DISC IS
 lv_disc_int  gbl_amc_dtl.dlr_disc_ind%TYPE;
 lv_disc      gbl_amc_dtl.dlr_disc%TYPE;
 lv_disc_amt  gbl_amc_dtl.dlr_disc_amt%TYPE; 
 ln_tot_amt   gbl_amc_dtl.tot_aft_dlr_disc%TYPE;
 lv_upd       VARCHAR2(1);
BEGIN
	FOR cur_d IN (SELECT r.rowid crowid, r.srv_type, r.tot_value
								  FROM gbl_amc_dtl r
							   WHERE parent_group = :global.parent_group
							     AND dealer_map_cd = :global.dealer
							     AND loc_cd = :global.loc_cd
							     AND comp_fa = :global.comp_fa        
							     AND reg_num = :B_VH_AMC_ENQ.REG_NUM
							     AND pkg_code = :B_VH_AMC_ENQ.PKG_CODE
							     )
	 LOOP
	 	lv_disc_int := NULL;
	 	lv_disc     := NULL;
	 	lv_disc_amt := 0;
	 	ln_tot_amt  := 0;
	 	lv_upd		  := 'N';
	 	
	 	IF cur_d.srv_type = 'P' AND NVL(:CB_VT_AMC_ENQ.dlr_part_disc,0) > 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.part_disc_ind;	
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.part_disc_ind = 'P' THEN	
	 		 	  lv_disc     := :CB_VT_AMC_ENQ.dlr_part_disc;	 		 	  
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;
	 		 ELSIF :CB_VT_AMC_ENQ.part_disc_ind = 'A' THEN
	 		 	  lv_disc     := ROUND((:CB_VT_AMC_ENQ.dlr_part_disc / NVL(:CB_VT_AMC_ENQ.nb_part_cnt,1)),2);
	 		 	  lv_disc_amt := lv_disc;	
	 		 	  --general.disp_text('Step 1 :: '||:CB_VT_AMC_ENQ.dlr_part_disc||' - '||:CB_VT_AMC_ENQ.part_cnt||' - '||lv_disc_amt||' - '||lv_upd,'Error');		 		 	  	 		 	  
	 		 END IF;	  
	 	ELSIF cur_d.srv_type = 'C' AND NVL(:CB_VT_AMC_ENQ.dlr_cons_disc,0) > 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.cons_disc_ind;
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.cons_disc_ind = 'P' THEN	 
	 		 	  lv_disc     := :CB_VT_AMC_ENQ.dlr_cons_disc;			 	  
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;
	 		 ELSIF :CB_VT_AMC_ENQ.cons_disc_ind = 'A' THEN
	 		 	  lv_disc     := ROUND((:CB_VT_AMC_ENQ.dlr_cons_disc / NVL(:CB_VT_AMC_ENQ.nb_cons_cnt,1)),2);
	 		 	  lv_disc_amt := lv_disc;		 		 	  	 		 	  
	 		 END IF;	  
	 	ELSIF cur_d.srv_type = 'L' AND NVL(:CB_VT_AMC_ENQ.dlr_lab_disc,0) > 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.lab_disc_ind;
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.lab_disc_ind = 'P' THEN
	 		 	  lv_disc     := :CB_VT_AMC_ENQ.dlr_lab_disc;
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;          
	 		 ELSIF :CB_VT_AMC_ENQ.lab_disc_ind = 'A' THEN
	 		 	  lv_disc     := ROUND((:CB_VT_AMC_ENQ.dlr_lab_disc / NVL(:CB_VT_AMC_ENQ.nb_lbr_cnt,1)),2);	
	 		 	  lv_disc_amt := lv_disc;	 	    
	 		 END IF;	  
	 	END IF;	
	 	
	 	IF NVL(lv_upd, 'N') = 'Y' THEN
      ln_tot_amt  := NVL(cur_d.tot_value, 0) - NVL(lv_disc_amt, 0);
		 	IF ln_tot_amt < 0 THEN
		 		ln_tot_amt  := 0;
		 		--lv_disc_amt := cur_d.tot_value;
		 	END IF;	
		 	UPDATE gbl_amc_dtl r
			   SET dlr_disc_ind = lv_disc_int,
			   	   dlr_disc     = lv_disc,
			   	   dlr_disc_amt = lv_disc_amt,
			   	   tot_aft_dlr_disc = ln_tot_amt
		   WHERE ROWID = cur_d.crowid;
		END IF;   
	END LOOP;
END;
```

#### SP-005 - POP_DISC_CLEAR

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Details (WN_MAIN / CN_DEF)

---

**Purpose**

POP_DISC_CLEAR resets all dealer discount indicators and values on the AMC enquiry screen to their default 'P' (percentage) state with null amounts, then recalculates and persists dealer discount figures for every AMC detail line belonging to the current vehicle/package/dealer/location context. The procedure ensures that discount amounts and post-discount totals stored in GBL_AMC_DTL accurately reflect the cleared (zeroed) discount inputs.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Reset screen discount controls: set the labour, parts, and consumable discount indicators (lab_disc_ind, part_disc_ind, cons_disc_ind) to 'P' and null out the corresponding dealer discount amount fields (dlr_lab_disc, dlr_part_disc, dlr_cons_disc) in the CB_VT_AMC_ENQ block.
- Step 2 - Retrieve all GBL_AMC_DTL rows for the current context: query GBL_AMC_DTL filtered by parent_group, dealer_map_cd, loc_cd, comp_fa, reg_num, and pkg_code, returning each row's ROWID, service type (srv_type), and total value (tot_value).
- Step 3 - Initialise working variables for each row: reset lv_disc_int, lv_disc, lv_disc_amt, ln_tot_amt, and lv_upd to their null/zero/N defaults at the start of every loop iteration.
- Step 4 - Determine applicable discount inputs by service type: evaluate cur_d.srv_type against 'P' (parts), 'C' (consumable), and 'L' (labour). For the matching type, capture the corresponding screen discount indicator and discount value into lv_disc_int and lv_disc, and set lv_upd to 'Y', provided the relevant screen discount field is >= 0 (after NVL to 0).
- Step 5 - Calculate the discount amount based on the indicator type: if the discount indicator is 'P', compute lv_disc_amt as (tot_value × lv_disc / 100); if the indicator is 'A', set lv_disc_amt equal to lv_disc directly.
- Step 6 - Compute the post-discount total: subtract lv_disc_amt from tot_value to derive ln_tot_amt; if the result is negative, floor it to zero.
- Step 7 - Update GBL_AMC_DTL: when lv_upd is 'Y', update the current row (identified by ROWID) with the calculated dlr_disc_ind, dlr_disc, dlr_disc_amt, and tot_aft_dlr_disc values.
- Step 8 - Repeat Steps 3-7 for every qualifying GBL_AMC_DTL row returned by the cursor.

---
**Decision Points**

DP-001

Condition:
cur_d.srv_type = 'P' AND NVL(:CB_VT_AMC_ENQ.dlr_part_disc, 0) >= 0

TRUE:
Capture part_disc_ind and dlr_part_disc as the active discount inputs; set lv_upd = 'Y'; proceed to DP-004 to calculate the parts discount amount.

FALSE:
Evaluate DP-002 (consumable service type check).

---

DP-002

Condition:
cur_d.srv_type = 'C' AND NVL(:CB_VT_AMC_ENQ.dlr_cons_disc, 0) >= 0

TRUE:
Capture cons_disc_ind and dlr_cons_disc as the active discount inputs; set lv_upd = 'Y'; proceed to DP-005 to calculate the consumable discount amount.

FALSE:
Evaluate DP-003 (labour service type check).

---

DP-003

Condition:
cur_d.srv_type = 'L' AND NVL(:CB_VT_AMC_ENQ.dlr_lab_disc, 0) >= 0

TRUE:
Capture lab_disc_ind and dlr_lab_disc as the active discount inputs; set lv_upd = 'Y'; proceed to DP-006 to calculate the labour discount amount.

FALSE:
lv_upd remains 'N'; no discount calculation or update is performed for this row.

---

DP-004

Condition:
:CB_VT_AMC_ENQ.part_disc_ind = 'P' (percentage indicator for parts)

TRUE:
lv_disc_amt := NVL(cur_d.tot_value, 0) × NVL(lv_disc, 0) / 100.

FALSE:
Evaluate whether part_disc_ind = 'A'; if so, lv_disc_amt := lv_disc (absolute amount).

---

DP-005

Condition:
:CB_VT_AMC_ENQ.cons_disc_ind = 'P' (percentage indicator for consumables)

TRUE:
lv_disc_amt := NVL(cur_d.tot_value, 0) × NVL(lv_disc, 0) / 100.

FALSE:
Evaluate whether cons_disc_ind = 'A'; if so, lv_disc_amt := lv_disc (absolute amount).

---

DP-006

Condition:
:CB_VT_AMC_ENQ.lab_disc_ind = 'P' (percentage indicator for labour)

TRUE:
lv_disc_amt := NVL(cur_d.tot_value, 0) × NVL(lv_disc, 0) / 100.

FALSE:
Evaluate whether lab_disc_ind = 'A'; if so, lv_disc_amt := lv_disc (absolute amount).

---

DP-007

Condition:
NVL(lv_upd, 'N') = 'Y'

TRUE:
Calculate ln_tot_amt and execute the UPDATE on GBL_AMC_DTL for the current row.

FALSE:
Skip the update; proceed to the next cursor row.

---

DP-008

Condition:
ln_tot_amt < 0 (post-discount total is negative)

TRUE:
Floor ln_tot_amt to 0 to prevent a negative post-discount total being stored.

FALSE:
Retain the calculated ln_tot_amt as-is.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Update GBL_AMC_DTL - Updates existing rows in GBL_AMC_DTL.
**Business Rules**

- BR-001 - On invocation, all three dealer discount indicators (labour, parts, consumable) must be reset to 'P' and all dealer discount amount fields must be nulled before any recalculation is performed, ensuring a clean baseline.
- BR-002 - A discount calculation is only performed for a GBL_AMC_DTL row when the screen discount value for the matching service type is non-negative (>= 0 after NVL); negative discount inputs are ignored and the row is not updated.
- BR-003 - When the discount indicator is 'P', the discount amount is derived as a percentage of the line's total value (tot_value × discount_rate / 100).
- BR-004 - When the discount indicator is 'A', the discount amount is the absolute value entered by the dealer, applied directly without reference to tot_value.
- BR-005 - The post-discount total (tot_aft_dlr_disc) must never be stored as a negative value; if the computed result is less than zero it is floored to zero before the update.
- BR-006 - Updates to GBL_AMC_DTL are scoped exclusively to rows matching the current session context (parent_group, dealer_map_cd, loc_cd, comp_fa, reg_num, pkg_code) and are targeted by ROWID to ensure precision.
- BR-007 - Each GBL_AMC_DTL row is processed independently within the cursor loop; variables are re-initialised for every iteration to prevent carry-over of discount values between rows.

---
**Implementation Logic**

```plsql
PROCEDURE POP_DISC_CLEAR IS
 lv_disc_int  gbl_amc_dtl.dlr_disc_ind%TYPE;
 lv_disc      gbl_amc_dtl.dlr_disc%TYPE;
 lv_disc_amt  gbl_amc_dtl.dlr_disc_amt%TYPE; 
 ln_tot_amt   gbl_amc_dtl.tot_aft_dlr_disc%TYPE;
 lv_upd       VARCHAR2(1);
BEGIN
	:CB_VT_AMC_ENQ.lab_disc_ind  := 'P';
	:CB_VT_AMC_ENQ.part_disc_ind := 'P';
	:CB_VT_AMC_ENQ.cons_disc_ind := 'P';
	:CB_VT_AMC_ENQ.dlr_lab_disc  := NULL;
	:CB_VT_AMC_ENQ.dlr_part_disc := NULL;
	:CB_VT_AMC_ENQ.dlr_cons_disc := NULL;
	
	FOR cur_d IN (SELECT r.rowid crowid, r.srv_type, r.tot_value
								  FROM gbl_amc_dtl r
							   WHERE parent_group = :global.parent_group
							     AND dealer_map_cd = :global.dealer
							     AND loc_cd = :global.loc_cd
							     AND comp_fa = :global.comp_fa        
							     AND reg_num = :B_VH_AMC_ENQ.REG_NUM
							     AND pkg_code = :B_VH_AMC_ENQ.PKG_CODE
							     )
	 LOOP
	 	lv_disc_int := NULL;
	 	lv_disc     := NULL;
	 	lv_disc_amt := 0;
	 	ln_tot_amt  := 0;
	 	lv_upd		  := 'N';
	 	
	 	IF cur_d.srv_type = 'P' AND NVL(:CB_VT_AMC_ENQ.dlr_part_disc,0) >= 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.part_disc_ind;
	 		 lv_disc     := :CB_VT_AMC_ENQ.dlr_part_disc;	 		 
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.part_disc_ind = 'P' THEN	 		 	  
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;
	 		 ELSIF :CB_VT_AMC_ENQ.part_disc_ind = 'A' THEN
	 		 	  lv_disc_amt := lv_disc;		 		 	  
	 		 END IF;	  
	 	ELSIF cur_d.srv_type = 'C' AND NVL(:CB_VT_AMC_ENQ.dlr_cons_disc,0) >= 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.cons_disc_ind;
	 		 lv_disc     := :CB_VT_AMC_ENQ.dlr_cons_disc;	 		 
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.cons_disc_ind = 'P' THEN	 		 	  
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;
	 		 ELSIF :CB_VT_AMC_ENQ.cons_disc_ind = 'A' THEN
	 		 	  lv_disc_amt := lv_disc;		 		 	  
	 		 END IF;	  
	 	ELSIF cur_d.srv_type = 'L' AND NVL(:CB_VT_AMC_ENQ.dlr_lab_disc,0) >= 0 THEN
	 		 lv_disc_int := :CB_VT_AMC_ENQ.lab_disc_ind;
	 		 lv_disc     := :CB_VT_AMC_ENQ.dlr_lab_disc;
	 		 lv_upd		   := 'Y';
	 		 IF :CB_VT_AMC_ENQ.lab_disc_ind = 'P' THEN
	 		 	  lv_disc_amt := NVL(cur_d.tot_value, 0) * NVL(lv_disc, 0) / 100;          
	 		 ELSIF :CB_VT_AMC_ENQ.lab_disc_ind = 'A' THEN
	 		 	  lv_disc_amt := lv_disc;		 		 	    
	 		 END IF;	  
	 	END IF;	
	 	
	 	IF NVL(lv_upd, 'N') = 'Y' THEN
      ln_tot_amt  := NVL(cur_d.tot_value, 0) - NVL(lv_disc_amt, 0);
		 	IF ln_tot_amt < 0 THEN
		 		ln_tot_amt := 0;
		 	END IF;	
		 	UPDATE gbl_amc_dtl r
			   SET dlr_disc_ind = lv_disc_int,
			   	   dlr_disc     = lv_disc,
			   	   dlr_disc_amt = lv_disc_amt,
			   	   tot_aft_dlr_disc = ln_tot_amt
		   WHERE ROWID = cur_d.crowid;
		END IF;   
	END LOOP;
END;
```

#### SP-006 - POP_PKG_DETAILS

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Details (WN_MAIN / CN_DEF); SMP Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

POP_PKG_DETAILS populates the AMC (Annual Maintenance Contract) package detail lines and computes all financial summary totals for a selected vehicle package. It is triggered when the user presses a button on the SMP Enquiry form. The procedure loads standard package service lines (labour, parts, consumables) and add-on service lines from GBL_AMC_DTL into the detail block B_VD_AMC_ENQ, resolves add-on type descriptions from AM_LIST, and then aggregates gross amounts, MCP discounts, dealer discounts, taxes, subtotals, and net values - split by service type and add-on category - into the header block B_VH_AMC_ENQ for display across the Details, SMP Details, and TCS screens.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Reset service-type item counters (labour, parts, consumables) in the control block CB_VT_AMC_ENQ to zero before loading any data.
- Step 2 - Navigate to block B_VD_AMC_ENQ and clear all existing rows without validation, then move to the first record position.
- Step 3 - Execute cursor cur_smp to retrieve standard (non-add-on) package lines from GBL_AMC_DTL, filtered by the current session context (parent group, dealer, location, company FA), the selected vehicle registration number and package code, rows where ADDON_TYPE IS NULL, and the applicable service option filter (service option 'L' restricts to SRV_TYPE = 'L'; service option 'P' accepts all SRV_TYPE values). Rows are ordered by serial number.
- Step 4 - For each standard line returned, map all GBL_AMC_DTL columns to the corresponding B_VD_AMC_ENQ fields (serial number, service type, service code, quantity, discount percentage, rate, basic amount, discount amount, post-MCP-discount total, post-dealer-discount total, net amount, sell price, charge amount, HSN/SAC code, category code, group code, add-on type, service description, category description, group description, dealer discount indicator defaulting to 'P', dealer discount, and dealer discount amount).
- Step 5 - Accumulate running package-level totals for standard lines: gross sell price (ln_pkg_amt), MCP discount (ln_pkg_dis), dealer discount (ln_pkg_dis_dlr), and net value (ln_pkg_net).
- Step 6 - Branch on SRV_TYPE for each standard line: if 'L' (Labour), accumulate labour-specific gross, MCP discount, dealer discount, tax (charge_amt), and net accumulators; increment the labour item counter; and conditionally update the minimum post-MCP-discount labour amount in CB_VT_AMC_ENQ. If 'P' (Parts), perform the equivalent accumulation and counter increment for parts. If 'C' (Consumables), perform the equivalent accumulation and counter increment for consumables.
- Step 7 - Advance to the next block record after each standard line and continue the loop.
- Step 8 - Execute cursor cur_add to retrieve add-on package lines from GBL_AMC_DTL for the same session context, registration number, and package code, but where ADDON_TYPE IS NOT NULL. Rows are ordered by add-on type then serial number.
- Step 9 - For each add-on line, map all GBL_AMC_DTL columns to B_VD_AMC_ENQ fields as for standard lines, with the exception that GROUP_CD is set to ADDON_TYPE when ADDON_TYPE is not null, otherwise to the stored group code.
- Step 10 - Resolve the group description for each add-on line: if ADDON_TYPE is not null, look up LIST_DESC from AM_LIST where LIST_NAME = 'SMP_ADDON' and LIST_CODE matches the add-on type for the current principal; if no matching row is found, fall back to the raw ADDON_TYPE value as the description. If ADDON_TYPE is null, use the stored group description.
- Step 11 - Accumulate running add-on package-level totals: gross sell price (ln_pkg_amt_add), combined MCP and dealer discount (ln_pkg_dis_add), and net value (ln_pkg_net_add).
- Step 12 - Branch on SRV_TYPE for each add-on line (Labour / Parts / Consumables) and accumulate the corresponding add-on gross, combined discount, tax, and net accumulators; increment the shared service-type item counters; and conditionally update the minimum post-MCP-discount amount in CB_VT_AMC_ENQ using the same comparison logic as for standard lines.
- Step 13 - After both loops complete, return to the first record in B_VD_AMC_ENQ.
- Step 14 - Write standard-line financial summaries to B_VH_AMC_ENQ: PKG_AMT, LABOUR_AMT, PART_AMT, CONSUMABLE_AMT; MCP discount totals (DISCOUNT_AMT, NB_LBR_DISC, NB_PART_DISC, NB_CONS_DISC); dealer discount totals (DISCOUNT_AMT_DLR and per-type equivalents).
- Step 15 - Compute and write combined (MCP + dealer) discount totals for the package and each service type (NB_DISCOUNT_AMT_TOT, NB_LBR_DISC_TOT, NB_PART_DISC_TOT, NB_CONS_DISC_TOT).
- Step 16 - Compute and write standard-line subtotals (gross minus combined discount) for the package and each service type (NB_TOT_SUBTOT, NB_LBR_SUBTOT, NB_PART_SUBTOT, NB_CONS_SUBTOT).
- Step 17 - Write add-on gross amounts, combined add-on discounts, and add-on subtotals (gross minus combined discount) for the package and each service type to the corresponding NB_ADD_* and ADDON_AMT fields in B_VH_AMC_ENQ.
- Step 18 - Compute combined (standard + add-on) subtotals for each service type and the package total (NB_LBR_SUBTOT_ADD, NB_PART_SUBTOT_ADD, NB_CONS_SUBTOT_ADD, NB_TOT_SUBTOT_ADD).
- Step 19 - Compute and write total tax amounts (charge_amt) combining standard and add-on lines for the package and each service type (NB_TAX_AMT, NB_LBR_TAX, NB_PART_TAX, NB_CONS_TAX).
- Step 20 - Compute and write final net billing amounts combining standard and add-on net values for the package total and each service type (TOT_BILL_AMT, NB_LBR_NET, NB_PART_NET, NB_CONS_NET).

---
**Decision Points**

DP-001

Condition:
Service option on B_VH_AMC_ENQ (:B_VH_AMC_ENQ.SERV_OPTION) equals 'L' when filtering standard lines in cur_smp.

TRUE:
Only rows where GBL_AMC_DTL.SRV_TYPE = 'L' are included in the standard package line result set.

FALSE:
When SERV_OPTION = 'P', rows of any SRV_TYPE are included (the condition r.srv_type = r.srv_type is always true), returning all service types.

---

DP-002

Condition:
For a standard or add-on line, SRV_TYPE = 'L' (Labour).

TRUE:
Labour-specific accumulators (amount, MCP discount, dealer discount, tax, net) are incremented; the labour item counter is incremented; and the minimum post-MCP-discount labour amount in CB_VT_AMC_ENQ is conditionally updated.

FALSE:
Processing falls through to the ELSIF check for SRV_TYPE = 'P'.

---

DP-003

Condition:
For a standard or add-on line, SRV_TYPE = 'P' (Parts).

TRUE:
Parts-specific accumulators (amount, MCP discount, dealer discount, tax, net) are incremented; the parts item counter is incremented; and the minimum post-MCP-discount parts amount in CB_VT_AMC_ENQ is conditionally updated.

FALSE:
Processing falls through to the ELSIF check for SRV_TYPE = 'C'.

---

DP-004

Condition:
For a standard or add-on line, SRV_TYPE = 'C' (Consumables).

TRUE:
Consumables-specific accumulators (amount, MCP discount, dealer discount, tax, net) are incremented; the consumables item counter is incremented; and the minimum post-MCP-discount consumables amount in CB_VT_AMC_ENQ is conditionally updated.

FALSE:
No service-type-specific accumulation is performed for this line (the line is still included in package-level totals).

---

DP-005

Condition:
For a standard or add-on line of any service type, NVL(CB_VT_AMC_ENQ.nb_[type]_amt, B_VD_AMC_ENQ.tot_aft_mcp_disc) >= B_VD_AMC_ENQ.tot_aft_mcp_disc.

TRUE:
CB_VT_AMC_ENQ.nb_[type]_amt is updated to the current line's TOT_AFT_MCP_DISC value, retaining the lowest post-MCP-discount amount seen so far for that service type.

FALSE:
CB_VT_AMC_ENQ.nb_[type]_amt is left unchanged.

---

DP-006

Condition:
For an add-on line, cur_a.ADDON_TYPE IS NOT NULL.

TRUE:
A lookup is performed against AM_LIST (LIST_NAME = 'SMP_ADDON', PRINCIPAL_MAP_CD = current principal, LIST_CODE = ADDON_TYPE) to retrieve the descriptive label for the add-on type. If the query raises an exception (no data found or any other error), the raw ADDON_TYPE value is used as the group description. GROUP_CD on B_VD_AMC_ENQ is set to ADDON_TYPE.

FALSE:
The stored group description (cur_a.group_desc) is used as-is for NB_GROUP_DESC, and GROUP_CD is set to the stored group code.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - Standard package lines are scoped exclusively to the current session context: parent group, dealer mapping code, location code, and company FA must all match the corresponding global variables, and the registration number and package code must match the values held in B_VH_AMC_ENQ.
- BR-002 - Standard lines (cur_smp) must have ADDON_TYPE IS NULL; add-on lines (cur_add) must have ADDON_TYPE IS NOT NULL. The two populations are mutually exclusive and processed in separate loops.
- BR-003 - When the service option is 'L', only Labour-type standard lines are retrieved; when the service option is 'P', standard lines of all service types are retrieved.
- BR-004 - The dealer discount indicator (DLR_DISC_IND) defaults to 'P' when the stored value is null, ensuring a discount indicator is always present on every detail line.
- BR-005 - For standard lines, the MCP discount (discount_amt) and the dealer discount (dlr_disc_amt) are accumulated separately at both the package level and the per-service-type level, allowing independent reporting of each discount source.
- BR-006 - For add-on lines, the MCP discount and dealer discount are combined into a single discount accumulator (ln_pkg_dis_add and its service-type equivalents), meaning add-on discounts are not reported separately by source.
- BR-007 - Tax amounts are sourced from the CHARGE_AMT column of GBL_AMC_DTL for both standard and add-on lines, and are accumulated separately by service type before being combined into a single package tax total.
- BR-008 - Combined (standard + add-on) subtotals and net amounts are always computed as the arithmetic sum of the two populations; neither population can offset the other.
- BR-009 - Add-on group descriptions are resolved from AM_LIST using the 'SMP_ADDON' list name scoped to the current principal. If no matching list entry exists, the raw ADDON_TYPE code is displayed as the description, ensuring the field is never blank.
- BR-010 - All financial accumulations use NVL to treat null amounts as zero, preventing null propagation in running totals and summary fields.

---
**Implementation Logic**

```plsql
PROCEDURE POP_PKG_DETAILS IS
	CURSOR cur_smp IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NULL
	     AND ((:B_VH_AMC_ENQ.SERV_OPTION = 'L' AND r.srv_type = 'L') OR 
	          (:B_VH_AMC_ENQ.SERV_OPTION = 'P' AND r.srv_type = r.srv_type))
	   ORDER BY r.srl_num;

	CURSOR cur_add IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NOT NULL
	   ORDER BY r.addon_type, r.srl_num;
  
  ln_pkg_amt   NUMBER(12,3) := 0;
  ln_lbr_amt   NUMBER(12,3) := 0;
  ln_part_amt  NUMBER(12,3) := 0;
  ln_cons_amt  NUMBER(12,3) := 0;  	     	     	
	
	ln_pkg_dis   NUMBER(12,3) := 0;
  ln_lbr_dis   NUMBER(12,3) := 0;
  ln_part_dis  NUMBER(12,3) := 0;
  ln_cons_dis  NUMBER(12,3) := 0;
  
  ln_pkg_dis_dlr   NUMBER(12,3) := 0;  	    
  ln_lbr_dis_dlr   NUMBER(12,3) := 0;
  ln_part_dis_dlr  NUMBER(12,3) := 0;
  ln_cons_dis_dlr  NUMBER(12,3) := 0;  	    

  ln_lbr_tax   NUMBER(12,3) := 0;
  ln_part_tax  NUMBER(12,3) := 0;
  ln_cons_tax  NUMBER(12,3) := 0;  	    
	
	ln_pkg_net   NUMBER(12,3) := 0;
  ln_lbr_net   NUMBER(12,3) := 0;
  ln_part_net  NUMBER(12,3) := 0;
  ln_cons_net  NUMBER(12,3) := 0;  	       	     

  ln_pkg_amt_add   NUMBER(12,3) := 0;
  ln_lbr_amt_add   NUMBER(12,3) := 0;
  ln_part_amt_add  NUMBER(12,3) := 0;
  ln_cons_amt_add  NUMBER(12,3) := 0;  	

	ln_pkg_dis_add   NUMBER(12,3) := 0;
  ln_lbr_dis_add   NUMBER(12,3) := 0;
  ln_part_dis_add  NUMBER(12,3) := 0;
  ln_cons_dis_add  NUMBER(12,3) := 0;

  ln_lbr_tax_add   NUMBER(12,3) := 0;
  ln_part_tax_add  NUMBER(12,3) := 0;
  ln_cons_tax_add  NUMBER(12,3) := 0;  	    

	ln_pkg_net_add   NUMBER(12,3) := 0;
  ln_lbr_net_add   NUMBER(12,3) := 0;
  ln_part_net_add  NUMBER(12,3) := 0;
  ln_cons_net_add  NUMBER(12,3) := 0;  	       	     
     	     	  	       	     
BEGIN	
	:CB_VT_AMC_ENQ.nb_lbr_cnt  := 0;
	:CB_VT_AMC_ENQ.nb_part_cnt := 0;
	:CB_VT_AMC_ENQ.nb_cons_cnt := 0;
	
	go_block('B_VD_AMC_ENQ');
	clear_block(NO_VALIDATE);
	first_record;
	FOR cur_i IN cur_smp LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_i.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_i.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_i.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_i.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_i.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_i.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_i.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_i.discount_amt;	
    
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_i.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_i.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_i.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_i.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_i.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_i.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_i.catg_cd;		
		:B_VD_AMC_ENQ.GROUP_CD := cur_i.group_cd;		
		:B_VD_AMC_ENQ.ADDON_TYPE  := cur_i.addon_type;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_i.srv_desc;
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_i.catg_desc;
		:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_i.group_desc;
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_i.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_i.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_i.dlr_disc_amt;
		
		ln_pkg_amt := NVL(ln_pkg_amt, 0) + NVL(cur_i.sell_price, 0);
		ln_pkg_dis := NVL(ln_pkg_dis, 0) + NVL(cur_i.discount_amt, 0);
		ln_pkg_dis_dlr := NVL(ln_pkg_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
		ln_pkg_net := NVL(ln_pkg_net, 0) + NVL(cur_i.net_value, 0);
		
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_amt := NVL(ln_lbr_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_lbr_dis := NVL(ln_lbr_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_lbr_dis_dlr := NVL(ln_lbr_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_lbr_tax := NVL(ln_lbr_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_lbr_net := NVL(ln_lbr_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_lbr_cnt := NVL(:CB_VT_AMC_ENQ.nb_lbr_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_lbr_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_lbr_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
	  ELSIF cur_i.srv_type = 'P' THEN
			ln_part_amt := NVL(ln_part_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_part_dis := NVL(ln_part_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_part_dis_dlr := NVL(ln_part_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_part_tax := NVL(ln_part_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_part_net := NVL(ln_part_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_part_cnt := NVL(:CB_VT_AMC_ENQ.nb_part_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_part_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_part_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_amt := NVL(ln_cons_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_cons_dis := NVL(ln_cons_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_cons_dis_dlr := NVL(ln_cons_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_cons_tax := NVL(ln_cons_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_cons_net := NVL(ln_cons_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_cons_cnt := NVL(:CB_VT_AMC_ENQ.nb_cons_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_cons_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_cons_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
		END IF;						
		next_record;		
	END LOOP;	
	
	FOR cur_a IN cur_add LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_a.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_a.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_a.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_a.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_a.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_a.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_a.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_a.discount_amt;	
    
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_a.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_a.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_a.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_a.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_a.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_a.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_a.catg_cd;	
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_a.catg_desc;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_a.srv_desc;			
		:B_VD_AMC_ENQ.GROUP_CD := NVL(cur_a.addon_type,cur_a.group_cd);	
		:B_VD_AMC_ENQ.ADDON_TYPE  := cur_a.addon_type;
		
		IF cur_a.addon_type IS NOT NULL THEN
			BEGIN
				SELECT LIST_DESC 
				  INTO :B_VD_AMC_ENQ.NB_GROUP_DESC
          FROM AM_LIST l
         WHERE LIST_NAME = 'SMP_ADDON'
           AND PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL
           AND LIST_CODE = cur_a.addon_type;
			EXCEPTION WHEN OTHERS THEN
				:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.addon_type;
			END;	
		ELSE
			:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.group_desc;
	  END IF;				
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_a.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_a.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_a.dlr_disc_amt;
		
		ln_pkg_amt_add := NVL(ln_pkg_amt_add, 0) + NVL(cur_a.sell_price, 0);
		ln_pkg_dis_add := NVL(ln_pkg_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
		ln_pkg_net_add := NVL(ln_pkg_net_add, 0) + NVL(cur_a.net_value, 0);
		
		IF cur_a.srv_type = 'L' THEN
			ln_lbr_amt_add  := NVL(ln_lbr_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_lbr_dis_add  := NVL(ln_lbr_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_lbr_tax_add  := NVL(ln_lbr_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_lbr_net_add  := NVL(ln_lbr_net_add, 0) + NVL(cur_a.net_value, 0);
			:CB_VT_AMC_ENQ.nb_lbr_cnt := NVL(:CB_VT_AMC_ENQ.nb_lbr_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_lbr_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_lbr_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
	  ELSIF cur_a.srv_type = 'P' THEN
			ln_part_amt_add := NVL(ln_part_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_part_dis_add := NVL(ln_part_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_part_tax_add := NVL(ln_part_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_part_net_add := NVL(ln_part_net_add, 0) + NVL(cur_a.net_value, 0);
			:CB_VT_AMC_ENQ.nb_part_cnt := NVL(:CB_VT_AMC_ENQ.nb_part_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_part_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_part_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;
		ELSIF cur_a.srv_type = 'C' THEN
			ln_cons_amt_add := NVL(ln_cons_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_cons_dis_add := NVL(ln_cons_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			ln_cons_tax_add := NVL(ln_cons_tax_add, 0) + NVL(cur_a.charge_amt, 0);
			ln_cons_net_add := NVL(ln_cons_net_add, 0) + NVL(cur_a.net_value, 0);
			:CB_VT_AMC_ENQ.nb_cons_cnt := NVL(:CB_VT_AMC_ENQ.nb_cons_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_cons_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_cons_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
		END IF;						
		next_record;		
	END LOOP;	

	  first_record;
	  
	  :B_VH_AMC_ENQ.PKG_AMT    := ln_pkg_amt;
	  :B_VH_AMC_ENQ.LABOUR_AMT := ln_lbr_amt;
	  :B_VH_AMC_ENQ.PART_AMT   := ln_part_amt;
	  :B_VH_AMC_ENQ.CONSUMABLE_AMT := ln_cons_amt;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT  := ln_pkg_dis;	  
	  :B_VH_AMC_ENQ.NB_LBR_DISC   := ln_lbr_dis;
	  :B_VH_AMC_ENQ.NB_PART_DISC  := ln_part_dis;
	  :B_VH_AMC_ENQ.NB_CONS_DISC  := ln_cons_dis;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT_DLR  := ln_pkg_dis_dlr;
	  :B_VH_AMC_ENQ.NB_LBR_DISC_DLR 	:= ln_lbr_dis_dlr;
    :B_VH_AMC_ENQ.NB_PART_DISC_DLR 	:= ln_part_dis_dlr;
    :B_VH_AMC_ENQ.NB_CONS_DISC_DLR 	:= ln_cons_dis_dlr;

	  :B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT  := NVL(ln_pkg_dis_dlr,0) + NVL(ln_pkg_dis,0);
	  :B_VH_AMC_ENQ.NB_LBR_DISC_TOT 	:= NVL(ln_lbr_dis_dlr,0) + NVL(ln_lbr_dis,0); 
    :B_VH_AMC_ENQ.NB_PART_DISC_TOT 	:= NVL(ln_part_dis_dlr,0) + NVL(ln_part_dis,0); 
    :B_VH_AMC_ENQ.NB_CONS_DISC_TOT 	:= NVL(ln_cons_dis_dlr,0) + NVL(ln_cons_dis,0);  

	  :B_VH_AMC_ENQ.NB_TOT_SUBTOT   := NVL(:B_VH_AMC_ENQ.PKG_AMT ,0) - NVL(:B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT,0);
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.LABOUR_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_LBR_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.PART_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_PART_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.CONSUMABLE_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_CONS_DISC_TOT,0);  
	  
	  :B_VH_AMC_ENQ.labr_addon_amt  := ln_lbr_amt_add;
	  :B_VH_AMC_ENQ.part_addon_amt  := ln_part_amt_add;
	  :B_VH_AMC_ENQ.cons_addon_amt  := ln_cons_amt_add;
		:B_VH_AMC_ENQ.addon_amt       := ln_pkg_amt_add;
		    
    :B_VH_AMC_ENQ.nb_lbr_disc_add  := ln_lbr_dis_add;
    :B_VH_AMC_ENQ.nb_part_disc_add := ln_part_dis_add;
    :B_VH_AMC_ENQ.nb_cons_disc_add := ln_cons_dis_add;
    :B_VH_AMC_ENQ.nb_tot_disc_add  := ln_pkg_dis_add;

    :B_VH_AMC_ENQ.nb_add_lbr_subtot := NVL(ln_lbr_amt_add,0) - NVL(ln_lbr_dis_add,0);
    :B_VH_AMC_ENQ.nb_add_part_subtot := NVL(ln_part_amt_add,0) - NVL(ln_part_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_cons_subtot := NVL(ln_cons_amt_add,0) - NVL(ln_cons_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_tot_subtot  := NVL(ln_pkg_amt_add,0) - NVL(ln_pkg_dis_add,0); 
        	  
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_LBR_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_lbr_subtot,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_PART_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_part_subtot,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_CONS_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_cons_subtot,0);  
		:B_VH_AMC_ENQ.NB_TOT_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_TOT_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_tot_subtot,0);
		
	  :B_VH_AMC_ENQ.NB_TAX_AMT   := NVL(ln_lbr_tax,0) + NVL(ln_part_tax,0) + NVL(ln_cons_tax,0) 
	                                      + NVL(ln_lbr_tax_add,0) + NVL(ln_part_tax_add,0) + NVL(ln_cons_tax_add,0);
	  :B_VH_AMC_ENQ.NB_LBR_TAX   := NVL(ln_lbr_tax,0) + NVL(ln_lbr_tax_add,0);
	  :B_VH_AMC_ENQ.NB_PART_TAX  := NVL(ln_part_tax,0) + NVL(ln_part_tax_add,0);
	  :B_VH_AMC_ENQ.NB_CONS_TAX  := NVL(ln_cons_tax,0) + NVL(ln_cons_tax_add,0);
	  
	  :B_VH_AMC_ENQ.TOT_BILL_AMT := NVL(ln_pkg_net,0) + NVL(ln_pkg_net_add,0);
	  :B_VH_AMC_ENQ.NB_LBR_NET   := NVL(ln_lbr_net,0) + NVL(ln_lbr_net_add,0);
	  :B_VH_AMC_ENQ.NB_PART_NET  := NVL(ln_part_net,0) + NVL(ln_part_net_add,0);
	  :B_VH_AMC_ENQ.NB_CONS_NET  := NVL(ln_cons_net,0) + NVL(ln_cons_net_add,0);
END;
```

#### SP-007 - POP_SMP_DETAILS

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Populates the SMP Package Details screen (B_VD_AMC_ENQ) with line-item service records for a selected AMC package and computes summary totals - broken down by service type (Labour, Parts, Consumables) - for both standard package lines and add-on lines. The procedure is triggered from the SMP Enquiry form when the user presses the relevant button to view package details.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Reset the labour, parts, and consumables item counters in the control block (CB_VT_AMC_ENQ) to zero before loading any data.
- Step 2 - Navigate to block B_VD_AMC_ENQ and clear all existing records without validation to prepare for fresh data.
- Step 3 - Open cursor cur_smp to retrieve standard package lines from GBL_AMC_DTL filtered by the current session context (parent group, dealer, location, company FA), the selected vehicle registration number and package code, excluding add-on lines (addon_type IS NULL), and applying a service-option filter: if the selected service option is 'L' only Labour lines are returned; if 'P' all service types are returned. Results are ordered by serial number.
- Step 4 - For each standard package row returned by cur_smp, populate all detail fields in B_VD_AMC_ENQ (serial number, service type, service code, quantity, discount percentage, rate, basic amount, discount amount, totals after MCP and dealer discounts, net amount, sell price, charge amount, HSN/SAC code, category, service description, group code, add-on type, group description, dealer discount indicator, dealer discount, and dealer discount amount). The dealer discount indicator defaults to 'P' if null.
- Step 5 - Accumulate running package-level totals (sell price, MCP discount, dealer discount, net value) into ln_pkg_amt, ln_pkg_dis, ln_pkg_dis_dlr, and ln_pkg_net.
- Step 6 - Based on the service type of each standard line, accumulate type-specific totals and tax amounts into the corresponding Labour ('L'), Parts ('P'), or Consumables ('C') accumulators, increment the relevant item counter, and update the minimum post-MCP-discount amount held in the control block for that service type.
- Step 7 - Advance to the next form record and continue until all standard package lines are processed.
- Step 8 - Open cursor cur_add to retrieve add-on lines from GBL_AMC_DTL for the same package, where addon_type IS NOT NULL, ordered by addon_type and serial number.
- Step 9 - For each add-on row, populate the same detail fields in B_VD_AMC_ENQ. For the group description, attempt to look up the descriptive label from AM_LIST using list name 'SMP_ADDON' and the current principal; if no matching row is found, fall back to the raw addon_type value. If addon_type is null the stored group_desc is used directly.
- Step 10 - Accumulate add-on package-level totals (sell price into ln_pkg_amt_add; combined MCP discount plus dealer discount into ln_pkg_dis_add).
- Step 11 - Based on the service type of each add-on line, accumulate type-specific add-on amounts and combined discounts into the Labour, Parts, or Consumables add-on accumulators, increment the relevant item counter, and update the minimum post-MCP-discount amount in the control block.
- Step 12 - Advance to the next form record and continue until all add-on lines are processed.
- Step 13 - Navigate back to the first record in the detail block.
- Step 14 - Write all accumulated standard-package totals to the header block B_VH_AMC_ENQ: gross amounts, MCP discounts, dealer discounts, combined total discounts, sub-totals (gross minus total discount), tax amounts, and net amounts - each split by Labour, Parts, Consumables, and overall package.
- Step 15 - Write all accumulated add-on totals to B_VH_AMC_ENQ: add-on gross amounts, add-on discounts, add-on sub-totals, and combined (standard + add-on) sub-totals per service type and overall.

---
**Decision Points**

DP-001

Condition:
The selected service option (:B_VH_AMC_ENQ.SERV_OPTION) equals 'L'.

TRUE:
The standard-package cursor (cur_smp) filters GBL_AMC_DTL to return only rows where srv_type = 'L' (Labour lines only).

FALSE:
When the service option is 'P', the cursor returns all service types (the condition r.srv_type = r.srv_type is always true, acting as no filter).

---

DP-002

Condition:
A standard package line's service type (cur_i.srv_type) equals 'L'.

TRUE:
The line's amounts are accumulated into Labour-specific totals (ln_lbr_amt, ln_lbr_dis, ln_lbr_dis_dlr, ln_lbr_tax, ln_lbr_net), the labour item counter is incremented, and the control-block Labour amount is updated if the current post-MCP-discount value is less than or equal to the stored value.

FALSE:
Processing falls through to DP-003.

---

DP-003

Condition:
A standard package line's service type (cur_i.srv_type) equals 'P'.

TRUE:
The line's amounts are accumulated into Parts-specific totals (ln_part_amt, ln_part_dis, ln_part_dis_dlr, ln_part_tax, ln_part_net), the parts item counter is incremented, and the control-block Parts amount is updated accordingly.

FALSE:
Processing falls through to DP-004.

---

DP-004

Condition:
A standard package line's service type (cur_i.srv_type) equals 'C'.

TRUE:
The line's amounts are accumulated into Consumables-specific totals (ln_cons_amt, ln_cons_dis, ln_cons_dis_dlr, ln_cons_tax, ln_cons_net), the consumables item counter is incremented, and the control-block Consumables amount is updated accordingly.

FALSE:
No type-specific accumulation is performed for this line (unrecognised service type).

---

DP-005

Condition:
An add-on line's addon_type IS NOT NULL.

TRUE:
A lookup is attempted against AM_LIST (list name 'SMP_ADDON', current principal, list code = addon_type) to retrieve a descriptive label for NB_GROUP_DESC. If the query raises any exception, NB_GROUP_DESC is set to the raw addon_type value. GROUP_CD is also set to addon_type rather than group_cd.

FALSE:
NB_GROUP_DESC is populated from the stored group_desc column and GROUP_CD from group_cd.

---

DP-006

Condition:
An add-on line's service type (cur_a.srv_type) equals 'L', 'P', or 'C' (evaluated in sequence as per DP-002/DP-003/DP-004 logic applied to add-on accumulators).

TRUE:
The line's sell price and combined discount (discount_amt + dlr_disc_amt) are accumulated into the matching add-on type accumulator (ln_lbr_amt_add / ln_part_amt_add / ln_cons_amt_add and corresponding discount variables), the relevant item counter is incremented, and the control-block amount is updated.

FALSE:
No type-specific add-on accumulation is performed.

---

DP-007

Condition:
The dealer discount indicator (dlr_disc_ind) is NULL for a given line (standard or add-on).

TRUE:
NB_VD_AMC_ENQ.DLR_DISC_IND is defaulted to 'P'.

FALSE:
The stored dlr_disc_ind value is used as-is.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL for lookup or validation.
- DB-002 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - Standard package lines are scoped strictly to the current session context: parent group, dealer, location, and company FA must all match the global session variables.
- BR-002 - Standard package lines are further filtered by the vehicle registration number and package code selected on the enquiry screen, and must have no add-on type (addon_type IS NULL).
- BR-003 - When the service option is 'L', only Labour service-type lines are loaded for the standard package; when the service option is 'P', all service types are loaded.
- BR-004 - Add-on lines are identified by a non-null addon_type and are always loaded regardless of the service option, ordered by addon_type then serial number.
- BR-005 - The dealer discount indicator defaults to 'P' (percentage) when no value is stored against a line.
- BR-006 - For add-on lines with a non-null addon_type, the group description is resolved from the AM_LIST reference table using list name 'SMP_ADDON' and the current principal; if no matching entry exists the raw addon_type code is displayed instead.
- BR-007 - For add-on lines, the combined discount accumulator merges both the MCP discount amount and the dealer discount amount (discount_amt + dlr_disc_amt), whereas for standard lines these are tracked in separate accumulators.
- BR-008 - Per-service-type sub-totals are calculated as gross sell price minus total combined discount (MCP discount plus dealer discount).
- BR-009 - Overall combined sub-totals (NB_LBR_SUBTOT_ADD, NB_PART_SUBTOT_ADD, NB_CONS_SUBTOT_ADD, NB_TOT_SUBTOT_ADD) represent the sum of the standard package sub-total and the add-on sub-total for each service type.
- BR-010 - Tax amounts (charge_amt) are accumulated only from standard package lines; no tax accumulation is performed for add-on lines.
- BR-011 - The control-block minimum post-MCP-discount amount (nb_lbr_amt, nb_part_amt, nb_cons_amt) is updated for each processed line only when the stored value is greater than or equal to the current line's tot_aft_mcp_disc, ensuring the lowest qualifying amount is retained.
- BR-012 - Item counters (nb_lbr_cnt, nb_part_cnt, nb_cons_cnt) are incremented for both standard and add-on lines, giving a total count of all detail rows per service type across both sets.

---
**Implementation Logic**

```plsql
PROCEDURE POP_SMP_DETAILS IS
	CURSOR cur_smp IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NULL
	     AND ((:B_VH_AMC_ENQ.SERV_OPTION = 'L' AND r.srv_type = 'L') OR 
	          (:B_VH_AMC_ENQ.SERV_OPTION = 'P' AND r.srv_type = r.srv_type))
	   ORDER BY r.srl_num;

	CURSOR cur_add IS
		SELECT *
		  FROM gbl_amc_dtl r
	   WHERE r.parent_group = :global.parent_group
	     AND r.dealer_map_cd = :global.dealer
	     AND r.loc_cd = :global.loc_cd
	     AND r.comp_fa = :global.comp_fa        
	     AND r.reg_num = :B_VH_AMC_ENQ.REG_NUM
	     AND r.pkg_code = :B_VH_AMC_ENQ.PKG_CODE
	     AND r.addon_type IS NOT NULL
	   ORDER BY r.addon_type, r.srl_num;
  
  ln_pkg_amt   NUMBER(12,3) := 0;
  ln_lbr_amt   NUMBER(12,3) := 0;
  ln_part_amt  NUMBER(12,3) := 0;
  ln_cons_amt  NUMBER(12,3) := 0;  	     	     	
	
	ln_pkg_dis   NUMBER(12,3) := 0;
  ln_lbr_dis   NUMBER(12,3) := 0;
  ln_part_dis  NUMBER(12,3) := 0;
  ln_cons_dis  NUMBER(12,3) := 0;
  
  ln_pkg_dis_dlr   NUMBER(12,3) := 0;  	    
  ln_lbr_dis_dlr   NUMBER(12,3) := 0;
  ln_part_dis_dlr  NUMBER(12,3) := 0;
  ln_cons_dis_dlr  NUMBER(12,3) := 0;  	    

  ln_lbr_tax   NUMBER(12,3) := 0;
  ln_part_tax  NUMBER(12,3) := 0;
  ln_cons_tax  NUMBER(12,3) := 0;  	    
	
	ln_pkg_net   NUMBER(12,3) := 0;
  ln_lbr_net   NUMBER(12,3) := 0;
  ln_part_net  NUMBER(12,3) := 0;
  ln_cons_net  NUMBER(12,3) := 0;  

  ln_pkg_amt_add   NUMBER(12,3) := 0;
  ln_lbr_amt_add   NUMBER(12,3) := 0;
  ln_part_amt_add  NUMBER(12,3) := 0;
  ln_cons_amt_add  NUMBER(12,3) := 0;  
  
  ln_pkg_dis_add   NUMBER(12,3) := 0;
  ln_lbr_dis_add   NUMBER(12,3) := 0;
  ln_part_dis_add  NUMBER(12,3) := 0;
  ln_cons_dis_add  NUMBER(12,3) := 0;	     	     	  	       	     
BEGIN
	:CB_VT_AMC_ENQ.nb_lbr_cnt  := 0;
	:CB_VT_AMC_ENQ.nb_part_cnt := 0;
	:CB_VT_AMC_ENQ.nb_cons_cnt := 0;
	
	go_block('B_VD_AMC_ENQ');
	clear_block(NO_VALIDATE);
	first_record;
	FOR cur_i IN cur_smp LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_i.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_i.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_i.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_i.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_i.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_i.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_i.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_i.discount_amt;	
    
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_i.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_i.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_i.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_i.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_i.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_i.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_i.catg_cd;	
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_i.catg_desc;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_i.srv_desc;			

		:B_VD_AMC_ENQ.GROUP_CD := cur_i.group_cd;	
		:B_VD_AMC_ENQ.ADDON_TYPE    := cur_i.addon_type;
		:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_i.group_desc;		
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_i.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_i.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_i.dlr_disc_amt;
		
		ln_pkg_amt := NVL(ln_pkg_amt, 0) + NVL(cur_i.sell_price, 0);
		ln_pkg_dis := NVL(ln_pkg_dis, 0) + NVL(cur_i.discount_amt, 0);
		ln_pkg_dis_dlr := NVL(ln_pkg_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
		ln_pkg_net := NVL(ln_pkg_net, 0) + NVL(cur_i.net_value, 0);
		
		IF cur_i.srv_type = 'L' THEN
			ln_lbr_amt := NVL(ln_lbr_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_lbr_dis := NVL(ln_lbr_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_lbr_dis_dlr := NVL(ln_lbr_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_lbr_tax := NVL(ln_lbr_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_lbr_net := NVL(ln_lbr_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_lbr_cnt := NVL(:CB_VT_AMC_ENQ.nb_lbr_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_lbr_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_lbr_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
	  ELSIF cur_i.srv_type = 'P' THEN
			ln_part_amt := NVL(ln_part_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_part_dis := NVL(ln_part_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_part_dis_dlr := NVL(ln_part_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_part_tax := NVL(ln_part_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_part_net := NVL(ln_part_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_part_cnt := NVL(:CB_VT_AMC_ENQ.nb_part_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_part_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_part_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
		ELSIF cur_i.srv_type = 'C' THEN
			ln_cons_amt := NVL(ln_cons_amt, 0) + NVL(cur_i.sell_price, 0);
			ln_cons_dis := NVL(ln_cons_dis, 0) + NVL(cur_i.discount_amt, 0);
			ln_cons_dis_dlr := NVL(ln_cons_dis_dlr, 0) + NVL(cur_i.dlr_disc_amt, 0);
			ln_cons_tax := NVL(ln_cons_tax, 0) + NVL(cur_i.charge_amt, 0);
			ln_cons_net := NVL(ln_cons_net, 0) + NVL(cur_i.net_value, 0);
			:CB_VT_AMC_ENQ.nb_cons_cnt := NVL(:CB_VT_AMC_ENQ.nb_cons_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_cons_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_cons_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
		END IF;						
		next_record;		
	END LOOP;	

	FOR cur_a IN cur_add LOOP
		:B_VD_AMC_ENQ.SRL_NUM	 := cur_a.srl_num;
		:B_VD_AMC_ENQ.SRV_TYPE := cur_a.srv_type;
		:B_VD_AMC_ENQ.SRV_CODE := cur_a.srv_cd;	
		:B_VD_AMC_ENQ.QTY      := cur_a.qty;	
		:B_VD_AMC_ENQ.DISCOUNT_PER := cur_a.discount_per;	
		:B_VD_AMC_ENQ.RATE := cur_a.rate;	
		:B_VD_AMC_ENQ.BASIC_AMT := cur_a.sell_price;	
		:B_VD_AMC_ENQ.DISCOUNT_AMT := cur_a.discount_amt;	
    --general.disp_text('Add-On :: '||:B_VD_AMC_ENQ.SRV_CODE||' - '||:B_VD_AMC_ENQ.RATE||' - '||:B_VD_AMC_ENQ.BASIC_AMT||' - '||cur_a.sell_price,'Error');
    :B_VD_AMC_ENQ.TOT_AFT_MCP_DISC := cur_a.tot_value;	
    :B_VD_AMC_ENQ.TOT_AFT_DLR_DISC := cur_a.tot_aft_dlr_disc;
		:B_VD_AMC_ENQ.NET_AMT := cur_a.net_value;				
		:B_VD_AMC_ENQ.SELL_PRICE := cur_a.sell_price;	
		:B_VD_AMC_ENQ.CHARGE_AMT := cur_a.charge_amt;	
		:B_VD_AMC_ENQ.HSN_SAC_CODE := cur_a.hsn_sac_cd;	
		
		:B_VD_AMC_ENQ.CATG_CD := cur_a.catg_cd;	
		:B_VD_AMC_ENQ.NB_CATG_DESC := cur_a.catg_desc;
		:B_VD_AMC_ENQ.NB_SRV_DESC := cur_a.srv_desc;			
		:B_VD_AMC_ENQ.GROUP_CD := NVL(cur_a.addon_type,cur_a.group_cd);	
		:B_VD_AMC_ENQ.ADDON_TYPE  := cur_a.addon_type;
		
		IF cur_a.addon_type IS NOT NULL THEN
			BEGIN
				SELECT LIST_DESC 
				  INTO :B_VD_AMC_ENQ.NB_GROUP_DESC
          FROM AM_LIST l
         WHERE LIST_NAME = 'SMP_ADDON'
           AND PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL
           AND LIST_CODE = cur_a.addon_type;
			EXCEPTION WHEN OTHERS THEN
				:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.addon_type;
			END;	
		ELSE
			:B_VD_AMC_ENQ.NB_GROUP_DESC := cur_a.group_desc;
	  END IF;				
		
		:B_VD_AMC_ENQ.DLR_DISC_IND := NVL(cur_a.dlr_disc_ind,'P');
		:B_VD_AMC_ENQ.DLR_DISC     := cur_a.dlr_disc;
		:B_VD_AMC_ENQ.DLR_DISC_AMT := cur_a.dlr_disc_amt;
		
		ln_pkg_amt_add := NVL(ln_pkg_amt_add, 0) + NVL(cur_a.sell_price, 0);
		ln_pkg_dis_add := NVL(ln_pkg_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);

		IF cur_a.srv_type = 'L' THEN
			ln_lbr_amt_add  := NVL(ln_lbr_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_lbr_dis_add  := NVL(ln_lbr_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			:CB_VT_AMC_ENQ.nb_lbr_cnt := NVL(:CB_VT_AMC_ENQ.nb_lbr_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_lbr_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_lbr_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
	  ELSIF cur_a.srv_type = 'P' THEN
			ln_part_amt_add := NVL(ln_part_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_part_dis_add := NVL(ln_part_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			:CB_VT_AMC_ENQ.nb_part_cnt := NVL(:CB_VT_AMC_ENQ.nb_part_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_part_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_part_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;
		ELSIF cur_a.srv_type = 'C' THEN
			ln_cons_amt_add := NVL(ln_cons_amt_add, 0) + NVL(cur_a.sell_price, 0);
			ln_cons_dis_add := NVL(ln_cons_dis_add, 0) + NVL(cur_a.discount_amt, 0) + NVL(cur_a.dlr_disc_amt, 0);
			:CB_VT_AMC_ENQ.nb_cons_cnt := NVL(:CB_VT_AMC_ENQ.nb_cons_cnt,0) + 1;
			IF NVL(:CB_VT_AMC_ENQ.nb_cons_amt, :B_VD_AMC_ENQ.tot_aft_mcp_disc) >= :B_VD_AMC_ENQ.tot_aft_mcp_disc THEN
				:CB_VT_AMC_ENQ.nb_cons_amt := :B_VD_AMC_ENQ.tot_aft_mcp_disc;
			END IF;	
		END IF;						
		next_record;		
	END LOOP;	

	  first_record;
	  
	  :B_VH_AMC_ENQ.PKG_AMT    := ln_pkg_amt;
	  :B_VH_AMC_ENQ.LABOUR_AMT := ln_lbr_amt;
	  :B_VH_AMC_ENQ.PART_AMT   := ln_part_amt;
	  :B_VH_AMC_ENQ.CONSUMABLE_AMT := ln_cons_amt;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT  := ln_pkg_dis;	  
	  :B_VH_AMC_ENQ.NB_LBR_DISC   := ln_lbr_dis;
	  :B_VH_AMC_ENQ.NB_PART_DISC  := ln_part_dis;
	  :B_VH_AMC_ENQ.NB_CONS_DISC  := ln_cons_dis;
	  
	  :B_VH_AMC_ENQ.DISCOUNT_AMT_DLR  := ln_pkg_dis_dlr;
	  :B_VH_AMC_ENQ.NB_LBR_DISC_DLR 	:= ln_lbr_dis_dlr;
    :B_VH_AMC_ENQ.NB_PART_DISC_DLR 	:= ln_part_dis_dlr;
    :B_VH_AMC_ENQ.NB_CONS_DISC_DLR 	:= ln_cons_dis_dlr;

	  :B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT  := NVL(ln_pkg_dis_dlr,0) + NVL(ln_pkg_dis,0);
	  :B_VH_AMC_ENQ.NB_LBR_DISC_TOT 	:= NVL(ln_lbr_dis_dlr,0) + NVL(ln_lbr_dis,0); 
    :B_VH_AMC_ENQ.NB_PART_DISC_TOT 	:= NVL(ln_part_dis_dlr,0) + NVL(ln_part_dis,0); 
    :B_VH_AMC_ENQ.NB_CONS_DISC_TOT 	:= NVL(ln_cons_dis_dlr,0) + NVL(ln_cons_dis,0);  

	  :B_VH_AMC_ENQ.NB_TOT_SUBTOT   := NVL(:B_VH_AMC_ENQ.PKG_AMT ,0) - NVL(:B_VH_AMC_ENQ.NB_DISCOUNT_AMT_TOT,0);
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.LABOUR_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_LBR_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.PART_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_PART_DISC_TOT,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT 	:= NVL(:B_VH_AMC_ENQ.CONSUMABLE_AMT,0) - NVL(:B_VH_AMC_ENQ.NB_CONS_DISC_TOT,0);  

    :B_VH_AMC_ENQ.labr_addon_amt  := ln_lbr_amt_add;
	  :B_VH_AMC_ENQ.part_addon_amt  := ln_part_amt_add;
	  :B_VH_AMC_ENQ.cons_addon_amt  := ln_cons_amt_add;
		:B_VH_AMC_ENQ.addon_amt       := ln_pkg_amt_add;
		    
    :B_VH_AMC_ENQ.nb_lbr_disc_add  := ln_lbr_dis_add;
    :B_VH_AMC_ENQ.nb_part_disc_add := ln_part_dis_add;
    :B_VH_AMC_ENQ.nb_cons_disc_add := ln_cons_dis_add;
    :B_VH_AMC_ENQ.nb_tot_disc_add  := ln_pkg_dis_add;

    :B_VH_AMC_ENQ.nb_add_lbr_subtot  := NVL(ln_lbr_amt_add,0) - NVL(ln_lbr_dis_add,0);
    :B_VH_AMC_ENQ.nb_add_part_subtot := NVL(ln_part_amt_add,0) - NVL(ln_part_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_cons_subtot := NVL(ln_cons_amt_add,0) - NVL(ln_cons_dis_add,0); 
    :B_VH_AMC_ENQ.nb_add_tot_subtot  := NVL(ln_pkg_amt_add,0) - NVL(ln_pkg_dis_add,0); 
        	  
	  :B_VH_AMC_ENQ.NB_LBR_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_LBR_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_lbr_subtot,0); 
    :B_VH_AMC_ENQ.NB_PART_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_PART_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_part_subtot,0); 
    :B_VH_AMC_ENQ.NB_CONS_SUBTOT_ADD := NVL(:B_VH_AMC_ENQ.NB_CONS_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_cons_subtot,0);  
		:B_VH_AMC_ENQ.NB_TOT_SUBTOT_ADD  := NVL(:B_VH_AMC_ENQ.NB_TOT_SUBTOT,0) + NVL(:B_VH_AMC_ENQ.nb_add_tot_subtot,0);

	  :B_VH_AMC_ENQ.NB_TAX_AMT   := NVL(ln_lbr_tax,0) + NVL(ln_part_tax,0) + NVL(ln_cons_tax,0);
	  :B_VH_AMC_ENQ.NB_LBR_TAX   := ln_lbr_tax;
	  :B_VH_AMC_ENQ.NB_PART_TAX  := ln_part_tax;
	  :B_VH_AMC_ENQ.NB_CONS_TAX  := ln_cons_tax;
	  
	  :B_VH_AMC_ENQ.TOT_BILL_AMT := ln_pkg_net;
	  :B_VH_AMC_ENQ.NB_LBR_NET   := ln_lbr_net;
	  :B_VH_AMC_ENQ.NB_PART_NET  := ln_part_net;
	  :B_VH_AMC_ENQ.NB_CONS_NET  := ln_cons_net;
END;
```

#### SP-008 - SP_INSERT_CHARGES

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Inserts default charge records for an AMC enquiry by copying applicable charge definitions from the global charges master table (GBL_AMC_CHARGES) into the enquiry charges table (VD_AMC_ENQCHARGES). The procedure is triggered during the KEY-COMMIT event on the AMC enquiry form and seeds all charge lines relevant to the current vehicle registration number and package code for the logged-in dealer/location context.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-012](#SP-012--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Execute an INSERT...SELECT statement that reads all matching rows from GBL_AMC_CHARGES filtered by the current session context (parent group, dealer, location, company FA, vehicle registration number, and package code).
- Step 2 - Map each selected charge row into VD_AMC_ENQCHARGES, carrying over charge attributes (charge_srl, common_ind, order_srl, charge_cd, charge_type, charge_ind, charge_value, charge_amt, srv_type, srv_cd, srl_num) directly from the master table.
- Step 3 - Substitute the enquiry number from the form block item :B_VH_AMC_ENQ.ENQ_NUM (rather than any value stored in GBL_AMC_CHARGES) as the foreign key for the new charge rows.
- Step 4 - Stamp the new rows with the current Oracle user identity (:GLOBAL.USERID) as created_by and SYSDATE as created_date.
- Step 5 - If any exception occurs during the insert, invoke GENERAL.DISP_TEXT to display the message 'Error... In Tax Calculation' with severity 'Error', then raise FORM_TRIGGER_FAILURE to halt the commit.

---
**Decision Points**

DP-001

Condition:
An unhandled exception is raised during the INSERT...SELECT operation (WHEN OTHERS).

TRUE:
GENERAL.DISP_TEXT is called to present the error message 'Error... In Tax Calculation' to the user, and FORM_TRIGGER_FAILURE is raised to abort the KEY-COMMIT trigger and roll back any pending changes.

FALSE:
The INSERT completes successfully; processing returns normally to the calling KEY-COMMIT trigger with no error surfaced.

---
**Database Interactions**

- DB-001 - Insert into VD_AMC_ENQCHARGES - Persists a new row into VD_AMC_ENQCHARGES using columns: parent group, dealer map cd, loc cd, comp fa, enq num, srl num, srv type, srv cd, and 10 more column(s).
- DB-002 - Read GBL_AMC_CHARGES - Reads data from GBL_AMC_CHARGES for lookup or validation.
**Business Rules**

- BR-001 - Charge rows are copied exclusively from GBL_AMC_CHARGES where the combination of parent_group, dealer_map_cd, loc_cd, comp_fa, reg_num, and pkg_code matches the current session globals and the active AMC enquiry; no charges outside this scope are inserted.
- BR-002 - The enquiry number recorded on each new charge row must be taken from the form block item :B_VH_AMC_ENQ.ENQ_NUM, ensuring charges are linked to the correct in-progress enquiry rather than any value held in the master table.
- BR-003 - Audit columns created_by and created_date must be populated at insert time using the global session user (:GLOBAL.USERID) and the database system date (SYSDATE) respectively; these values are never sourced from GBL_AMC_CHARGES.
- BR-004 - Any failure during charge insertion must be communicated to the end user via GENERAL.DISP_TEXT and must prevent the form commit from completing by raising FORM_TRIGGER_FAILURE.

---
**Implementation Logic**

```plsql
PROCEDURE SP_INSERT_CHARGES IS
BEGIN
  INSERT INTO vd_amc_enqcharges (parent_group,
																 dealer_map_cd,
													 			 loc_cd,
																 comp_fa,
																 enq_num,
																 srl_num,
																 srv_type,
																 srv_cd,
																 charge_srl,
																 common_ind,
																 order_srl,
																 charge_cd,
																 charge_type,
																 charge_ind,
																 charge_value,
																 charge_amt,
																 created_by,
																 created_date
																 )
													SELECT parent_group,
																 dealer_map_cd,
																 loc_cd,
																 comp_fa,
																 :B_VH_AMC_ENQ.ENQ_NUM,
																 srl_num,
																 srv_type,
																 srv_cd,
																 charge_srl,
																 common_ind,
																 order_srl,
																 charge_cd,
																 charge_type,
																 charge_ind,
																 charge_value,
																 charge_amt,
																 :GLOBAL.USERID,
																 SYSDATE
                            FROM gbl_amc_charges
											 		 WHERE parent_group = :global.parent_group
													   AND dealer_map_cd = :global.dealer
													   AND loc_cd = :global.loc_cd
													   AND comp_fa = :global.comp_fa        
													   AND reg_num = :B_VH_AMC_ENQ.REG_NUM
													   AND pkg_code = :B_VH_AMC_ENQ.PKG_CODE;    
EXCEPTION WHEN OTHERS THEN
	general.disp_text ('Error... In Tax Calculation', 'Error');
	RAISE form_trigger_failure; 		
END;
```

#### SP-009 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: FT_CANCEL]
- vt_smp_enq_fmb.xml [Trigger: FT_DEL]
- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. Calling triggers use the return value to determine whether to proceed with or cancel a requested action such as deletion or cancellation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using SET_ALERT_PROPERTY.
- Step 3 - Display the AL_CONFIRM alert to the user via SHOW_ALERT and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response against ALERT_BUTTON1.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (affirmative confirmation), or 0 for any other button press (non-confirmation).

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/affirmative button on the AL_CONFIRM alert)

TRUE: The function returns 1, signalling to the calling trigger that the user confirmed the action.

FALSE: The function returns 0, signalling to the calling trigger that the user did not confirm the action and the requested operation should be aborted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined Oracle Forms alert named AL_CONFIRM; no other alert is permissible within this function.
- BR-002 - The alert message text is dynamically overridden at runtime with the value supplied in confirm_msg, allowing a single alert object to serve multiple confirmation scenarios across different triggers.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1); any other button response must be treated as a rejection and returns 0, ensuring a binary confirmed/not-confirmed contract with all callers.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-010 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Provides a centralised post-operation failure check for Oracle Forms commit processing. After a commit attempt is initiated via the KEY-COMMIT trigger, this procedure inspects the Forms runtime success status and, if a failure is detected, determines the error origin (Oracle database or Oracle Forms), displays the appropriate error message to the user via GENERAL.DISP_TEXT, and halts further trigger processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-012](#SP-012--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the Oracle Forms built-in FORM_SUCCESS function to determine whether the most recent Forms operation completed without error.
- Step 2 - If FORM_SUCCESS returns FALSE (i.e., a failure occurred), inspect the ERROR_TYPE built-in variable to identify the source of the error.
- Step 3 - If ERROR_TYPE is 'ORA' (an Oracle database-level error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (an Oracle Forms-level error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to abort the KEY-COMMIT trigger and prevent any further processing.
- Step 6 - If FORM_SUCCESS returns TRUE, no action is taken and the procedure exits normally.

---
**Decision Points**

DP-001

Condition:
FORM_SUCCESS evaluates to FALSE (i.e., NOT FORM_SUCCESS is TRUE).

TRUE:
Proceed to inspect ERROR_TYPE and display the relevant error message, then raise FORM_TRIGGER_FAILURE.

FALSE:
No failure has occurred; the procedure exits without any action.

---

DP-002

Condition:
ERROR_TYPE = 'ORA' (the failure originated from an Oracle database error).

TRUE:
Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity label 'Error'.

FALSE:
Fall through to the next condition (DP-003).

---

DP-003

Condition:
ERROR_TYPE = 'FRM' (the failure originated from an Oracle Forms runtime error).

TRUE:
Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms error message text) and severity label 'Error'.

FALSE:
Neither ORA nor FRM branch is matched; no message is displayed, but FORM_TRIGGER_FAILURE is still raised because the outer NOT FORM_SUCCESS condition was TRUE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation that does not achieve Forms success must never be allowed to complete silently; an error message must always be presented to the user before processing is halted.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be surfaced using the Oracle-supplied SQLERRM message to ensure the user receives the precise database error description.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be surfaced using the Forms-supplied ERROR_TEXT message to ensure the user receives the precise Forms error description.
- BR-004 - All error messages must be displayed with the severity label 'Error' via GENERAL.DISP_TEXT (SP-012), ensuring consistent error presentation across the application.
- BR-005 - Upon detection of any form failure, FORM_TRIGGER_FAILURE must be raised to unconditionally abort the KEY-COMMIT trigger and prevent any downstream processing from executing.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-011 - GENERAL.CHECK_NULL

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SMP Details (N/A / CN_MAIN); SMP Package Details (N/A / CN_MAIN); Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Validates that a mandatory field value has been supplied by the user. If the passed value is NULL, the procedure displays a contextual error message identifying the offending field by its column title and halts further form processing by raising a trigger failure. It is used across SMP Details, SMP Package Details, and Vehicle Details screens to enforce not-null business rules at the point of button press and item validation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-012](#SP-012--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the field value (P_value) and the human-readable column label (column_title) as input parameters.
- Step 2 - Construct a user-facing error message by concatenating the literal 'Enter a valid ' with the supplied column_title, storing the result in the local variable mesg_text (maximum 80 characters).
- Step 3 - Evaluate whether P_value is NULL.
- Step 4 - If P_value IS NULL, invoke GENERAL.DISP_TEXT (SP-012) passing mesg_text and the severity indicator 'Error' to present the error message to the user.
- Step 5 - After displaying the error, raise FORM_TRIGGER_FAILURE to abort the current Oracle Forms trigger and prevent any further processing.
- Step 6 - If P_value is NOT NULL, no action is taken and control returns normally to the calling trigger.

---
**Decision Points**

DP-001

Condition:
P_value IS NULL

TRUE:
Call GENERAL.DISP_TEXT with the constructed error message ('Enter a valid <column_title>') and severity 'Error', then raise FORM_TRIGGER_FAILURE to halt the trigger.

FALSE:
No action is taken; the procedure exits normally and processing continues in the calling trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A field value passed to this procedure must not be NULL; a NULL value is treated as an invalid entry and is never silently accepted.
- BR-002 - The error message presented to the user must always identify the specific field in error by incorporating the column_title parameter in the format 'Enter a valid <column_title>'.
- BR-003 - Error messages generated by this procedure must be classified with severity 'Error' when displayed via GENERAL.DISP_TEXT (SP-012).
- BR-004 - Upon detecting a NULL value, form processing must be unconditionally halted by raising FORM_TRIGGER_FAILURE, preventing any downstream trigger logic from executing.
- BR-005 - This validation applies uniformly across all calling contexts (WHEN-BUTTON-PRESSED and WHEN-VALIDATE-ITEM triggers) on the SMP Details, SMP Package Details, and Vehicle Details screens.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-012 - GENERAL.DISP_TEXT

**Invoked From:**

- vt_smp_enq_fmb.xml [ProgramUnit: SP_INSERT_CHARGES]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.PROC_TIMER_EXPIRED]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vt_smp_enq_fmb.xml [StoredProcedure: SP_INSERT_CHARGES]
- vt_smp_enq_fmb.xml [Trigger: FT_SAVE]
- vt_smp_enq_fmb.xml [Trigger: KEY-COMMIT]
- vt_smp_enq_fmb.xml [Trigger: ON-ERROR]
- vt_smp_enq_fmb.xml [Trigger: ON-MESSAGE]
- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vt_smp_enq_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]
- vt_smp_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]
- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Addon Details (WN_MAIN / CN_ADDON); Details (WN_MAIN / CN_DEF); SMP Details (N/A / CN_MAIN); SMP Enquiry Details (N/A / CN_MAIN); SMP Package Details (N/A / CN_MAIN); Vehicle Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

Displays a modal alert dialog to the user containing a caller-supplied message and title. The procedure selects the appropriate Oracle Forms alert object based on whether the title indicates an error condition, configures its title and message text at runtime, and presents it to the user. It is used across multiple screens and calling contexts as the single, centralised mechanism for surfacing informational and error notifications.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (`text_string`) and dialog title (`title_string`) as input parameters.
- Step 2 - Initialise the local alert name variable to the default error alert `AL_ERRINFO`.
- Step 3 - Evaluate the title string (case-insensitive) to determine which alert object to use: if the title equals 'ERROR', retain `AL_ERRINFO`; otherwise switch to the informational alert `AL_NOTE`.
- Step 4 - Set the title property of the selected alert object to `title_string` using `SET_ALERT_PROPERTY`.
- Step 5 - Set the message text property of the selected alert object to `text_string` using `SET_ALERT_PROPERTY`.
- Step 6 - Display the configured alert to the user via `SHOW_ALERT` and capture the user's response in the local variable `p_alert_id` (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert object `AL_ERRINFO` is used to display the message, indicating an error-severity notification.

FALSE:
The alert object `AL_NOTE` is used to display the message, indicating an informational or non-error notification.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title comparison is performed case-insensitively; any capitalisation variant of the word 'ERROR' routes the dialog to the error alert `AL_ERRINFO`.
- BR-002 - All titles other than 'ERROR' are treated as informational and routed to the `AL_NOTE` alert, ensuring that only genuine error conditions use the error-styled dialog.
- BR-003 - The alert title and message text are set dynamically at runtime from the caller-supplied parameters, allowing a single pair of alert objects to serve all notification scenarios across the application.
- BR-004 - The user's button-press response returned by `SHOW_ALERT` is accepted but not evaluated; the procedure's sole responsibility is display, not response handling.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-013 - GENERAL.PROC_REPORT_CALL

**Invoked From:**

- vt_smp_enq_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_smp_enq_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Configures and submits an Oracle Reports report object for batch execution, directing output to a server-side file in a designated printer directory. The procedure returns the report job identifier and the generated output file name to the caller, enabling downstream processing (e.g., print or retrieval) by the invoking program unit.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| REPID | report_object | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| lv_report | varchar2 | OUT |
| lv_print | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the report server name from the global variable ':global.rep_server' using NAME_IN and store it in a local variable.
- Step 2 - Construct a unique output file name by concatenating the current Oracle Forms application username with the current system date/time formatted as 'YYYYMMDDHHMISS', then append the '.rrpp' file extension.
- Step 3 - Set the report execution mode to BATCH on the supplied report object (REPID), ensuring the report runs without user interaction.
- Step 4 - Set the report destination type to FILE so that output is written to the file system rather than a printer or screen.
- Step 5 - Set the report destination name to the fully qualified server-side path '/iashome/ias/reports/printer/' concatenated with the generated file name, directing output to the shared printer directory.
- Step 6 - Set the report server property on the report object to the value retrieved in Step 1.
- Step 7 - Execute the report by calling RUN_REPORT_OBJECT with the configured report object and capture the returned job identifier in the OUT parameter LV_REPORT.
- Step 8 - Assign the generated file name to the OUT parameter LV_PRINT so the caller can reference the output file for further processing.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure follows a single, unconditional execution path from configuration through submission.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server must be pre-populated in the global variable ':global.rep_server' before this procedure is called; the procedure reads but does not validate this value.
- BR-002 - Output file names must be unique per execution; uniqueness is enforced by combining the authenticated username with a timestamp accurate to the second (format 'YYYYMMDDHHMISS') and the fixed extension '.rrpp'.
- BR-003 - All reports submitted through this procedure must run in BATCH execution mode, prohibiting interactive or runtime parameter prompts during execution.
- BR-004 - Report output must be written as a FILE to the designated server-side directory '/iashome/ias/reports/printer/'; no alternative destination types are permitted by this procedure.
- BR-005 - The caller is responsible for using the returned LV_REPORT job identifier and LV_PRINT file name for any subsequent print, retrieval, or status-checking operations.

---
**Implementation Logic**

```plsql

PROCEDURE PROC_REPORT_CALL (REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) IS
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
      lv_server VARCHAR2(1000);
    Begin
    	  lv_server := name_in(':global.rep_server');
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,lv_server); --'mulreports
			  lv_report:= RUN_REPORT_OBJECT(repid);
			  lv_print := vcFile;			  
End;
```

#### SP-014 - GENERAL.PROC_TIMER

**Invoked From:**

- vt_smp_enq_fmb.xml [ProgramUnit: CALL_REPORT_ENQ]
- vt_smp_enq_fmb.xml [StoredProcedure: CALL_REPORT_ENQ]

---

**Screen:**

N/A

---

**Purpose**

Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5000-millisecond (5-second) interval. This procedure is called from the report enquiry program unit to establish a recurring timer that periodically triggers timer-fired logic for monitoring or polling the printer queue.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a local TIMER handle variable (hTimer) to hold the reference to the newly created timer.
- Step 2 - Invoke the Oracle Forms built-in CREATE_TIMER to create a timer named 'PRINTER_QUEUE' with an interval of 5000 milliseconds (5 seconds) and a repeat mode of REPEAT, assigning the resulting timer handle to hTimer.

---
**Decision Points**

No conditional decision points exist in this procedure. The CREATE_TIMER call is executed unconditionally every time PROC_TIMER is invoked.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The timer must be named 'PRINTER_QUEUE', ensuring that any WHEN-TIMER-EXPIRED trigger can identify and respond to this specific timer by name.
- BR-002 - The timer interval must be set to 5000 milliseconds (5 seconds), defining the polling frequency for printer queue monitoring.
- BR-003 - The timer must be created in REPEAT mode, meaning it fires continuously at the defined interval until explicitly deleted, rather than firing only once.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER IS
  hTimer    TIMER;
 begin
  hTimer := CREATE_TIMER('PRINTER_QUEUE','5000',REPEAT);
 end;
```

#### SP-015 - GENERAL.PROC_TIMER_EXPIRED

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-TIMER-EXPIRED]

---

**Screen:**

N/A

---

**Purpose**

Handles the WHEN-TIMER-EXPIRED trigger for the PRINTER_QUEUE timer. When the timer fires, the procedure checks the current status of an asynchronous report job (identified by a globally stored report handle) and either waits for the job to complete, opens the finished print output document in a new browser window, or displays an error message and cancels the timer if the report job has entered an unexpected failure state.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-012](#SP-012--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the name of the expired timer using GET_APPLICATION_PROPERTY(TIMER_NAME) and store it in a local variable.
- Step 2 - Read the global report handle (:GLOBAL.REPORTHANDLE) and the print output path (:GLOBAL.PRINTOUTPUT) from the Oracle Forms global variables into local variables.
- Step 3 - Evaluate whether the expired timer is named 'PRINTER_QUEUE'; if it is not, no action is taken and the procedure exits silently.
- Step 4 - Call REPORT_OBJECT_STATUS with the report handle to obtain the current execution status of the asynchronous report job.
- Step 5 - If the report status is RUNNING, OPENING_REPORT, or ENQUEUED, take no action (the timer will fire again on its next interval, allowing the job more time to complete).
- Step 6 - If the report status is FINISHED, invoke WEB.SHOW_DOCUMENT to open the completed print output at the '/printer/' path concatenated with the PRINTOUTPUT global value, targeting a new browser window ('_blank'), then delete the PRINTER_QUEUE timer to stop further polling.
- Step 7 - If the report status is any other value (indicating a failure or unknown state), call GENERAL.DISP_TEXT to display the message 'Unable to generate the report' with severity 'Error', then delete the PRINTER_QUEUE timer to stop further polling.

---
**Decision Points**

DP-001

Condition:
The expired timer name (retrieved via GET_APPLICATION_PROPERTY) equals 'PRINTER_QUEUE'.

TRUE:
Proceed to check the report job status and handle accordingly (DP-002).

FALSE:
No action is taken; the procedure exits without processing.

---

DP-002

Condition:
The report object status returned by REPORT_OBJECT_STATUS is one of: RUNNING, OPENING_REPORT, or ENQUEUED.

TRUE:
No action is taken; the timer continues to poll on its next interval.

FALSE:
Proceed to DP-003 to determine whether the job finished successfully or failed.

---

DP-003

Condition:
The report object status equals 'FINISHED'.

TRUE:
Open the completed print output document via WEB.SHOW_DOCUMENT (path '/printer/' || PRINTOUTPUT global, target '_blank') and delete the PRINTER_QUEUE timer.

FALSE:
Call GENERAL.DISP_TEXT to display the error message 'Unable to generate the report' with severity 'Error', then delete the PRINTER_QUEUE timer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the timer named 'PRINTER_QUEUE' is handled by this procedure; any other timer expiry is ignored.
- BR-002 - While a report job is in a transitional state (RUNNING, OPENING_REPORT, or ENQUEUED), the procedure takes no action and allows the timer to continue polling.
- BR-003 - A report job with status FINISHED is considered successfully completed; the print output is opened in a new browser window using the path stored in the :GLOBAL.PRINTOUTPUT global variable.
- BR-004 - Any report job status other than RUNNING, OPENING_REPORT, ENQUEUED, or FINISHED is treated as a failure; the user is notified via GENERAL.DISP_TEXT with the message 'Unable to generate the report' at Error severity.
- BR-005 - Upon reaching a terminal state (FINISHED or failure), the PRINTER_QUEUE timer must be deleted to prevent continued polling.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER_EXPIRED IS
	vcStatus varchar2(50);
	vcTimerName varchar2(30);
	hTimer timer;
	report_id report_object;
  lv_report_handle varchar2(4000);
  lv_printout      varchar2(4000);
begin
	vcTimerName := get_application_property(timer_name);
   			lv_report_handle := name_in(':global.reporthandle');
        lv_printout      := name_in(':GLOBAL.PRINTOUTPUT');
 
	if vcTimerName = 'PRINTER_QUEUE' then
		 vcStatus := REPORT_OBJECT_STATUS(lv_report_handle);
	   if vcStatus in ('RUNNING','OPENING_REPORT','ENQUEUED') THEN
	   	  NULL;
	   ELSIF VCsTATUS = 'FINISHED' THEN
        web.show_document('/printer/'||lv_printout ,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(:global.reporthandle,instr(:global.reporthandle,'_',-1)+1)||'?'||'server=mulreports'||:GLOBAL.PRINTOUTPUT,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
        delete_timer(vcTimerName);
	   ELSE
--	   	  general.disp_text('Unable to generate the report'||vcStatus,'Error');
        general.disp_text('Unable to generate the report','Error');
	   	  delete_timer(vcTimerName);
	   end if;
	end if;   
end;
```

#### SP-016 - GENERAL.RAISE_ERROR

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises error, note, and caution message handling for Oracle Forms. When a form trigger raises an error (ON-ERROR), this procedure receives a message code, constructs a display string, classifies the message by type, and presents it to the user via GENERAL.DISP_TEXT with an appropriate title. For error-class messages it also halts further trigger processing by raising FORM_TRIGGER_FAILURE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-012](#SP-012--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) passed in by the calling ON-ERROR trigger.
- Step 2 - Concatenate mesg_code with the (currently unresolved) mesg_text to form the full display string in the format 'mesg_code : mesg_text'.
- Step 3 - Evaluate mesg_type to determine the classification of the message (Error, Note, or Caution).
- Step 4 - If the message type is 'E', set the title to 'Error', call GENERAL.DISP_TEXT to present the message, then raise FORM_TRIGGER_FAILURE to halt processing.
- Step 5 - If the message type is 'N', set the title to 'Note' and call GENERAL.DISP_TEXT to present the message without halting processing.
- Step 6 - If the message type is 'C', set the title to 'Caution' and call GENERAL.DISP_TEXT to present the message without halting processing.
- Step 7 - If mesg_type does not match any of the three recognised values, no action is taken and control returns silently to the caller.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set mesg_title to 'Error', invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the error message, then raise FORM_TRIGGER_FAILURE to abort the current trigger chain.

FALSE:
Proceed to evaluate DP-002.

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the informational message; processing continues normally.

FALSE:
Proceed to evaluate DP-003.

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT(mesg_text, mesg_title) to display the caution message; processing continues normally.

FALSE:
None of the recognised message types matched; the procedure exits without displaying a message or raising an exception.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The full message presented to the user must always include the originating message code as a prefix, formatted as 'mesg_code : mesg_text', ensuring traceability back to the source error code.
- BR-002 - A message classified as type 'E' (Error) is considered fatal to the current form trigger; FORM_TRIGGER_FAILURE must be raised after displaying the message to prevent the triggering action from completing.
- BR-003 - A message classified as type 'N' (Note) or 'C' (Caution) is informational only; the procedure displays the message but must not interrupt form processing.
- BR-004 - All user-facing message dialogs must be rendered through GENERAL.DISP_TEXT (SP-012), ensuring consistent message presentation across the application.
- BR-005 - Only the three message type codes 'E', 'N', and 'C' are recognised; any other value results in silent no-operation, and no message is displayed.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-017 - PKG_AMC.SP_GET_GST_TYPE

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Determines the applicable GST type (Intra-state 'S' or Inter-state 'I') for a vehicle service enquiry by comparing the dealer's state against the customer's registered state. The procedure also identifies whether the customer is located in a Special Economic Zone (SEZ), retrieves the GST state codes for both the dealer and the customer, and returns descriptive error information when mandatory state data is missing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_gst_type | VARCHAR2 | OUT |
| p_dlr_gst_state | VARCHAR2 | OUT |
| p_cust_gst_state | VARCHAR2 | OUT |
| p_cust_sez | VARCHAR2 | OUT |
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output error indicators: set p_err_cd to 0 and p_err_msg to NULL.
- Step 2 - Retrieve the dealer location state code (lv_dlr_state) from AM_DEALER_LOC by matching the parent group (p_parent), dealer map code (p_dealer), and location code (p_loc). If no row is found, lv_dlr_state remains NULL and processing continues.
- Step 3 - Retrieve the customer party code (lv_cust) and variant code (lv_var) from GM_VIN using the vehicle registration number (p_reg_num). If no row is found, both local variables remain NULL and processing continues.
- Step 4 - Retrieve the customer's state code (lv_cust_state) and SEZ flag (p_cust_sez) from GM_CIN by matching the customer code (lv_cust) and principal map code (p_pmc). If no row is found, both values are set to NULL.
- Step 5 - Evaluate whether the customer state is available. If lv_cust_state IS NULL, set p_err_cd to 1 and p_err_msg to instruct the user to update the customer state via Customer Master; no further processing occurs.
- Step 6 - When lv_cust_state is populated, check the SEZ flag. If p_cust_sez equals 'Y', assign GST type 'I' (IGST) and set p_err_msg to inform the user that IGST applies because the customer is in a Special Economic Zone.
- Step 7 - If the customer is not SEZ, compare lv_dlr_state with lv_cust_state. If they are equal, assign GST type 'S' (SGST/CGST - intra-state); otherwise assign GST type 'I' (IGST - inter-state).
- Step 8 - Retrieve the GST state code for the customer (p_cust_gst_state) from GM_STATE by matching p_pmc and lv_cust_state. If no row is found, p_cust_gst_state remains NULL.
- Step 9 - Retrieve the GST state code for the dealer (p_dlr_gst_state) from GM_STATE by matching p_pmc and lv_dlr_state. If no row is found, p_dlr_gst_state remains NULL.
- Step 10 - Return all output parameters (p_gst_type, p_dlr_gst_state, p_cust_gst_state, p_cust_sez, p_err_cd, p_err_msg) to the calling form trigger.

---
**Decision Points**

DP-001

Condition:
lv_cust_state IS NULL (customer state could not be resolved from GM_CIN)

TRUE:
Set p_err_cd = 1 and p_err_msg = 'Please update State of Customer through Customer Master'. No GST type or GST state codes are determined; procedure exits the conditional block.

FALSE:
Proceed to evaluate the SEZ flag and determine the GST type (DP-002).

---

DP-002

Condition:
NVL(p_cust_sez, 'N') = 'Y' (customer is flagged as a Special Economic Zone entity)

TRUE:
Assign p_gst_type = 'I' (IGST applicable) and set p_err_msg to notify the user that IGST applies due to SEZ status. Skip the dealer-vs-customer state comparison.

FALSE:
Proceed to compare dealer state with customer state to determine intra-state or inter-state GST (DP-003).

---

DP-003

Condition:
lv_dlr_state = lv_cust_state (dealer location state matches the customer's registered state)

TRUE:
Assign p_gst_type = 'S' (intra-state - SGST/CGST applicable).

FALSE:
Assign p_gst_type = 'I' (inter-state - IGST applicable).

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-003 - Read GM_CIN - Reads data from GM_CIN for lookup or validation.
- DB-004 - Update STATE - Updates existing rows in STATE.
- DB-005 - Read GM_STATE - Reads data from GM_STATE for lookup or validation.
**Business Rules**

- BR-001 - A customer state code must be present in GM_CIN for the given customer and principal map code before any GST determination can proceed; if absent, the transaction is blocked with an error directing the user to update the Customer Master.
- BR-002 - A customer designated as a Special Economic Zone (SEZ) entity (cust_sez = 'Y' in GM_CIN) always attracts IGST (GST type 'I'), regardless of whether the dealer and customer states match.
- BR-003 - For non-SEZ customers, GST type is determined solely by state comparison: identical dealer and customer states result in intra-state GST ('S'); differing states result in inter-state GST ('I').
- BR-004 - The GST state codes returned to the caller (p_dlr_gst_state and p_cust_gst_state) must be resolved from GM_STATE using the principal map code (p_pmc) combined with the respective state code; these codes are only populated when the customer state is available (i.e., no error condition).
- BR-005 - Failures to retrieve the dealer location state, vehicle registration details, or GST state codes are handled silently (WHEN OTHERS -> NULL), allowing the procedure to continue with partial data rather than raising an exception to the caller.
- BR-006 - The procedure is invoked during the WHEN-VALIDATE-ITEM trigger on the Vehicle Details screen, ensuring GST type classification occurs at the point of vehicle registration number validation during a service enquiry.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_GET_GST_TYPE(p_pmc            IN NUMBER,
                            p_parent         IN VARCHAR2,
                            p_dealer         IN NUMBER,
                            p_loc            IN VARCHAR2,
                            p_reg_num        IN VARCHAR2,
                            p_gst_type       OUT VARCHAR2,
                            p_dlr_gst_state  OUT VARCHAR2,
                            p_cust_gst_state OUT VARCHAR2,
                            p_cust_sez       OUT VARCHAR2,  -- RR on 21-FEB-2018 for SEZ
                            p_err_cd         OUT NUMBER,
                            p_err_msg        OUT VARCHAR2) IS
    lv_dlr_state  am_dealer_loc.state_cd%TYPE;
    lv_cust       gm_vin.party_cd%TYPE;
    lv_var        gm_vin.variant_cd%TYPE;
    lv_cust_state gm_cin.state_cd%TYPE;
  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;
    BEGIN
      SELECT state_cd
        INTO lv_dlr_state
        FROM am_dealer_loc
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      SELECT party_cd, variant_cd
        INTO lv_cust, lv_var
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    BEGIN
      SELECT state_cd,
             cust_sez -- RR on 21-FEB-2018 for SEZ
        INTO lv_cust_state, p_cust_sez
        FROM gm_cin
       WHERE cust_cd = lv_cust
         AND principal_map_cd = p_pmc;
    EXCEPTION
      WHEN OTHERS THEN
        lv_cust_state := NULL;
        p_cust_sez   := NULL;
    END;

    IF lv_cust_state IS NULL THEN
      p_err_cd  := 1;
      p_err_msg := 'Please update State of Customer through Customer Master';
    ELSE
      IF NVL(p_cust_sez,'N') = 'Y' THEN  -- SEZ Check Added by RR on 21-FEB-2018
        p_gst_type := 'I';
        p_err_msg := 'You have selected Customer as Special Economy Zone. Hence IGST will be applicable';
      ELSE
        IF lv_dlr_state = lv_cust_state THEN
          p_gst_type := 'S';
        ELSE
          p_gst_type := 'I';
        END IF;
      END IF;

      BEGIN
        SELECT gst_state_cd
          INTO p_cust_gst_state
          FROM gm_state
         WHERE principal_map_cd = p_pmc
           AND state_cd = lv_cust_state;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      BEGIN
        SELECT gst_state_cd
          INTO p_dlr_gst_state
          FROM gm_state
         WHERE principal_map_cd = p_pmc
           AND state_cd = lv_dlr_state;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;
  END sp_get_gst_type;
```

#### SP-018 - PKG_SMP.SF_FLEET_CHECK

**Invoked From:**

- PKG_SMP.pck [StoredProcedure: PKG_SMP.SF_SMP_TYPE]
- PKG_SMP.pck [StoredProcedure: PKG_SMP.SP_VIN_VALIDATE]
- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Determines whether a given vehicle qualifies as a commercial/fleet unit by checking two independent data sources: the variant configuration table (GM_VAR) for CVMS service eligibility, and the new-vehicle registration table (NI_NEW_MINS) for recognised commercial vehicle types. Returns a two-value indicator ('COM' or 'NCOM') used by callers to drive downstream SMP processing logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_vin | VARCHAR2 | IN |
| p_variant_cd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: the Principal Map Code (p_pmc), the Vehicle Identification Number (p_vin), and the Variant Code (p_variant_cd).
- Step 2 - Query GM_VAR to determine whether the combination of Principal Map Code and Variant Code has the CVMS service flag (cvms_srv) set to 'Y'; a matching row contributes a count of 1.
- Step 3 - Query NI_NEW_MINS to determine whether the VIN exists with a vehicle type classified as 'C1' or 'C2' (commercial vehicle categories); a matching row contributes a count of 1.
- Step 4 - Combine both result sets via UNION ALL and count the total number of qualifying rows into the local variable lv_cvms_chk.
- Step 5 - Evaluate lv_cvms_chk: if the combined count is 1 or greater, return 'COM' to indicate a commercial/fleet vehicle; otherwise return 'NCOM' to indicate a non-commercial vehicle.

---
**Decision Points**

DP-001

Condition:
The combined row count (lv_cvms_chk) from the GM_VAR CVMS eligibility check and the NI_NEW_MINS commercial vehicle type check is greater than or equal to 1.

TRUE:
The function returns 'COM', classifying the vehicle as a commercial/fleet unit.

FALSE:
The function returns 'NCOM', classifying the vehicle as a non-commercial unit.

---
**Database Interactions**

- DB-001 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-002 - Read NI_NEW_MINS - Reads data from NI_NEW_MINS for lookup or validation.
**Business Rules**

- BR-001 - A vehicle is classified as commercial ('COM') if at least one of the following conditions is satisfied: (a) its Principal Map Code and Variant Code exist in GM_VAR with the CVMS service flag (cvms_srv) equal to 'Y', or (b) its VIN exists in NI_NEW_MINS with a vehicle type of 'C1' or 'C2'.
- BR-002 - The CVMS service flag on GM_VAR defaults to 'N' when null (via NVL); a null flag is therefore treated as non-CVMS-eligible.
- BR-003 - Commercial vehicle type eligibility in NI_NEW_MINS is restricted to the values 'C1' and 'C2'; any other vehicle type does not satisfy the fleet criterion through this source.
- BR-004 - The two eligibility checks are evaluated independently and combined; satisfaction of either check alone is sufficient to return 'COM'.
- BR-005 - The function returns only two possible values: 'COM' (commercial/fleet) or 'NCOM' (non-commercial); no other return states exist.

---
**Implementation Logic**

```plsql

  FUNCTION SF_FLEET_CHECK(p_pmc        NUMBER,
                          p_vin        VARCHAR2,
                          p_variant_cd VARCHAR2
                          ) RETURN VARCHAR2
   IS
    lv_cvms_chk NUMBER(5);
  BEGIN
    SELECT COUNT(*)
      INTO lv_cvms_chk
      FROM (SELECT 1
              FROM gm_var m
             WHERE m.principal_map_cd = p_pmc
               AND m.variant_cd = p_variant_cd
               AND NVL(m.cvms_srv, 'N') = 'Y'
            UNION ALL
            SELECT 1
              FROM NI_NEW_MINS m
             WHERE m.mins_vin = p_vin
               AND m.mins_vehicle_type IN ('C1', 'C2'));
    IF lv_cvms_chk >= 1 THEN
      RETURN 'COM';
    ELSE
      RETURN 'NCOM';
    END IF;
  END SF_FLEET_CHECK;
```

#### SP-019 - PKG_SMP.SF_SMP_TYPE

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Determines the appropriate SMP (Service Maintenance Package) list code for a vehicle visit by evaluating the vehicle type (fleet or non-fleet), its age and odometer reading, prior repair-order service history, and the pending sub-service category. The returned numeric code (1-4) drives package selection on the SMP Package Details screen.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_vin | VARCHAR2 | IN |
| p_srv_type | VARCHAR2 | IN |
| p_odometer | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- PKG_SMP.SF_FLEET_CHECK ([SP-018](#SP-018--PKG_SMP.SF_FLEET_CHECK)) - PKG_SMP.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise all local variables to their default values (lv_pms_chk = 'N', ln_veh_age = 0, ln_rsubsrv = 1, ln_csubsrv = 1, etc.).
- Step 2 - Query GM_VIN using the supplied VIN (p_vin) to retrieve the vehicle's model code, variant code, and age in months (MONTHS_BETWEEN SYSDATE and inv_date). Exceptions are silently suppressed; variables retain their defaults if no row is found.
- Step 3 - Call PKG_SMP.SF_FLEET_CHECK (SP-018) with p_pmc, p_vin, and the retrieved variant code to classify the vehicle as 'COM' (commercial/fleet) or another type (passenger/non-fleet). The result is stored in lv_vehtype.
- Step 4 - Query VH_RO to check whether the vehicle has a prior closed repair order (ro_status IN ('30','40')) whose repair category (rcateg_cd) is listed in AM_LIST under the principal's 'SMP_SERVTYPE' active entries and which has a non-null sub_rcateg_cd. The most recent such RO (MAX ro_date) is selected. If found, lv_pms_chk is set to 'Y' and lv_rsubsrv is populated with the sub-repair-category code. Exceptions are silently suppressed.
- Step 5 - If lv_rsubsrv is not null, extract the numeric suffix starting at position 4 (SUBSTR(lv_rsubsrv, 4)) into ln_rsubsrv to obtain the sub-service sequence number for comparison.
- Step 6 - Call GET_SUB_SRV_RCATEG_DESC with the current odometer, service type 'PMS', the VIN, and the principal map code to determine the pending sub-service category description (lv_csubsrv). If the call raises any exception, lv_csubsrv is set to NULL.
- Step 7 - If lv_csubsrv is not null, extract its numeric suffix from position 4 into ln_csubsrv.
- Step 8 - Apply the package-code determination logic branching first on vehicle type (COM vs. non-COM), then on odometer/age thresholds, prior PMS history flag, service type (CDS vs. other), model code (CA; VR/R; other), and sub-service sequence numbers to assign lv_pkg_list_cd a value of 1, 2, 3, or 4.
- Step 9 - Return lv_pkg_list_cd to the caller.

---
**Decision Points**

DP-001

Condition:
lv_vehtype = 'COM' (vehicle is classified as commercial/fleet by SF_FLEET_CHECK)

TRUE:
Apply commercial vehicle package logic (DP-002 onwards).

FALSE:
Apply passenger/non-fleet vehicle package logic (DP-005 onwards).

---

DP-002

Condition:
p_odometer <= 18000 AND ln_veh_age <= 16 (commercial vehicle within low-mileage and young-age thresholds)

TRUE:
Evaluate prior PMS history (DP-003).

FALSE:
Evaluate sub-service sequence for higher-mileage/older commercial vehicle (DP-004).

---

DP-003

Condition:
NVL(lv_pms_chk, 'N') = 'Y' (commercial vehicle has a prior qualifying PMS repair order)

TRUE:
Assign package code 2 (repeat/continuation service).

FALSE:
Assign package code 1 (initial/entry-level service).

---

DP-004

Condition:
ln_rsubsrv >= 12 (last recorded sub-service sequence is 12 or above)

TRUE:
Assign package code 3.

FALSE:
Evaluate pending sub-service sequence: if ln_csubsrv > 12 assign package code 3; otherwise assign package code 2.

---

DP-005

Condition:
NVL(lv_pms_chk, 'N') = 'Y' (non-fleet vehicle has a prior qualifying PMS repair order)

TRUE:
Evaluate service type for non-fleet vehicle with prior PMS history (DP-006).

FALSE:
Evaluate service type for non-fleet vehicle without prior PMS history (DP-010).

---

DP-006

Condition:
p_srv_type = 'CDS' (service type is CDS, applicable to non-fleet vehicle with prior PMS history)

TRUE:
Evaluate model code (DP-007).

FALSE:
If ln_csubsrv > 6 assign package code 3; otherwise assign package code 2.

---

DP-007

Condition:
lv_mod = 'CA' (model code is CA)

TRUE:
Assign package code 4.

FALSE:
Evaluate whether model is VR or R (DP-008).

---

DP-008

Condition:
lv_mod IN ('VR', 'R') (model code is VR or R)

TRUE:
Apply VR/R sub-service range logic: ln_csubsrv between 2 and 6 -> code 2; ln_csubsrv > 6 and < 10 -> code 3; otherwise -> code 4.

FALSE:
Apply other-model sub-service range logic: ln_csubsrv < 8 -> code 4; ln_csubsrv >= 8 and < 10 -> code 3; otherwise -> code 4 (DP-009).

---

DP-009

Condition:
NVL(ln_csubsrv, 1) >= 8 AND NVL(ln_csubsrv, 1) < 10 (other-model, mid-range sub-service sequence)

TRUE:
Assign package code 3.

FALSE:
Assign package code 4 (covers both < 8 and >= 10 cases).

---

DP-010

Condition:
p_srv_type = 'CDS' (service type is CDS, non-fleet vehicle without prior PMS history)

TRUE:
Apply the same model-code / sub-service-range logic as DP-007 through DP-009 (identical branching: CA -> 4; VR/R -> range 2/3/4; other -> range 4/3/4).

FALSE:
Evaluate odometer and vehicle age thresholds (DP-011).

---

DP-011

Condition:
p_odometer <= 18000 AND ln_veh_age <= 16 (non-fleet, no prior PMS, non-CDS, within low-mileage/young-age thresholds)

TRUE:
Assign package code 1 (initial/entry-level service).

FALSE:
If ln_csubsrv > 6 assign package code 3; otherwise assign package code 2.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read VH_RO - Reads data from VH_RO for lookup or validation.
- DB-003 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - A vehicle is classified as commercial ('COM') or non-fleet by delegating to PKG_SMP.SF_FLEET_CHECK (SP-018); this classification is the primary branching criterion for all subsequent package-code decisions.
- BR-002 - Prior qualifying PMS service history is determined by the existence of a closed repair order (ro_status IN ('30','40')) whose repair category appears in the principal's active 'SMP_SERVTYPE' list in AM_LIST (NVL(list_flag,'Y') = 'Y') and which carries a non-null sub-repair-category code. Only the most recent such RO date is considered.
- BR-003 - The sub-service sequence number used for threshold comparisons is derived by extracting the numeric portion starting at character position 4 of the sub-repair-category code (e.g., 'PMS012' yields 12).
- BR-004 - For commercial vehicles within the low-usage threshold (odometer ≤ 18,000 and vehicle age ≤ 16 months), prior PMS history determines whether package code 2 (repeat) or 1 (initial) is assigned.
- BR-005 - For commercial vehicles exceeding the low-usage threshold, the last recorded sub-service sequence (ln_rsubsrv) takes precedence; if it is 12 or above, package code 3 is assigned. If below 12, the pending sub-service sequence (ln_csubsrv) is used as a secondary check (> 12 -> code 3; otherwise -> code 2).
- BR-006 - For non-fleet vehicles with a CDS service type, the model code overrides all other criteria: model 'CA' always yields package code 4 regardless of odometer, age, or PMS history.
- BR-007 - For non-fleet CDS visits with model 'VR' or 'R', the pending sub-service sequence governs the package code: 2-6 -> code 2; 7-9 -> code 3; all other values -> code 4.
- BR-008 - For non-fleet CDS visits with any other model code, the pending sub-service sequence yields code 4 when < 8, code 3 when 8-9, and code 4 when ≥ 10.
- BR-009 - For non-fleet, non-CDS visits with prior PMS history, the pending sub-service sequence determines the code: > 6 -> code 3; otherwise -> code 2.
- BR-010 - For non-fleet, non-CDS visits without prior PMS history and within the low-usage threshold (odometer ≤ 18,000 and vehicle age ≤ 16 months), package code 1 (initial service) is assigned.
- BR-011 - For non-fleet, non-CDS visits without prior PMS history and outside the low-usage threshold, the pending sub-service sequence determines the code: > 6 -> code 3; otherwise -> code 2.
- BR-012 - All database lookups (GM_VIN, VH_RO, AM_LIST) and the GET_SUB_SRV_RCATEG_DESC call are wrapped in exception handlers that suppress errors, allowing the function to proceed with default values rather than raising an unhandled exception to the caller.

---
**Implementation Logic**

```plsql

  FUNCTION SF_SMP_TYPE(p_pmc      NUMBER,
                       p_vin      VARCHAR2,
                       p_srv_type VARCHAR2,
                       p_odometer NUMBER
                       ) RETURN NUMBER
   IS
    lv_mod          gm_vin.model_cd%TYPE;
    lv_variant      gm_vin.variant_cd%TYPE;
    lv_rsubsrv      vh_ro.sub_rcateg_cd%TYPE;
    ln_rsubsrv      NUMBER;
    lv_vehtype      VARCHAR2(5);
    lv_pms_chk      VARCHAR2(1);
    ln_veh_age      NUMBER;
    lv_csubsrv      VARCHAR2(5);
    ln_csubsrv      NUMBER;
    lv_pkg_list_cd  NUMBER;
  BEGIN
    lv_pms_chk := 'N';
    ln_veh_age := 0;
    lv_csubsrv := NULL;
    ln_csubsrv := 1;
    lv_mod     := NULL;
    lv_rsubsrv := NULL;
    ln_rsubsrv := 1;

    BEGIN
      SELECT model_cd, variant_cd, MONTHS_BETWEEN(SYSDATE, inv_date)
        INTO lv_mod, lv_variant, ln_veh_age
        FROM gm_vin
       WHERE vin = p_vin;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    lv_vehtype := SF_FLEET_CHECK(p_pmc,
                                 p_vin,
                                 lv_variant
                                 );
    --DBMS_OUTPUT.PUT_LINE('Step 1 :: '||lv_vehtype);

    BEGIN
      SELECT 'Y', r.sub_rcateg_cd
        INTO lv_pms_chk, lv_rsubsrv
        FROM vh_ro r
       WHERE r.vin = p_vin
         AND r.ro_status IN ('30', '40')
         AND r.sub_rcateg_cd IS NOT NULL
         AND r.rcateg_cd IN
             (SELECT l.list_code
                FROM am_list l
               WHERE l.principal_map_cd = p_pmc
                 AND l.list_name = 'SMP_SERVTYPE'
                 AND NVL(l.list_flag, 'Y') = 'Y')
         AND r.ro_date =
             (SELECT MAX(r1.ro_date)
                FROM vh_ro r1
               WHERE r1.vin = r.vin
                 AND r1.ro_status IN ('30', '40')
                 AND r1.sub_rcateg_cd IS NOT NULL
                 AND r1.rcateg_cd IN
                     (SELECT l.list_code
                        FROM am_list l
                       WHERE l.principal_map_cd = p_pmc
                         AND l.list_name = 'SMP_SERVTYPE'
                         AND NVL(l.list_flag, 'Y') = 'Y'));
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF lv_rsubsrv IS NOT NULL THEN
       ln_rsubsrv := SUBSTR(lv_rsubsrv, 4);
    END IF;
    --DBMS_OUTPUT.PUT_LINE('Step 2 :: '||lv_rsubsrv||' - '||ln_rsubsrv);

    /*IF lv_vehtype = 'COM' THEN
      BEGIN
        SELECT 'Y'
          INTO lv_pms_chk
          FROM vh_ro r
         WHERE r.vin = p_vin
           AND r.ro_status IN ('30', '40')
           AND r.rcateg_cd IN ('FR', 'FR3', 'PMS', 'CVMS')
           AND ROWNUM = 1;
      EXCEPTION WHEN OTHERS THEN
         lv_pms_chk := 'N';
      END;
    ELSE
      BEGIN
        SELECT 'Y'
          INTO lv_pms_chk
          FROM vh_ro r
         WHERE r.vin = p_vin
           AND r.ro_status IN ('30', '40')
           AND r.rcateg_cd IN ('FR', 'FR3', 'PMS', 'CDS')
           AND ROWNUM = 1;
      EXCEPTION WHEN OTHERS THEN
         lv_pms_chk := 'N';
      END;
    END IF;*/

    -- Check pending sub service
    BEGIN
      lv_csubsrv := GET_SUB_SRV_RCATEG_DESC(p_odometer, 'PMS', p_vin, p_pmc);
    EXCEPTION WHEN OTHERS THEN
      lv_csubsrv := NULL;
    END;

    IF lv_csubsrv IS NOT NULL THEN
      ln_csubsrv := SUBSTR(lv_csubsrv, 4);
    END IF;
    --DBMS_OUTPUT.PUT_LINE('Step 2 :: '||lv_vehtype||' - '||lv_pms_chk||' - '||lv_mod||' - '||lv_csubsrv||' - '||ln_csubsrv);

    IF lv_vehtype = 'COM' THEN
      IF p_odometer <= 18000 AND ln_veh_age <= 16 THEN
        IF NVL(lv_pms_chk, 'N') = 'Y' THEN
          lv_pkg_list_cd := 2;
        ELSE
          lv_pkg_list_cd := 1;
        END IF;
      ELSE
        IF ln_rsubsrv >= 12 THEN
          lv_pkg_list_cd := 3;
        ELSE
          IF ln_csubsrv > 12 THEN
            lv_pkg_list_cd := 3;
          ELSE
            lv_pkg_list_cd := 2;
          END IF;
        END IF;
      END IF;
    ELSE
      IF NVL(lv_pms_chk, 'N') = 'Y' THEN
        IF p_srv_type = 'CDS' THEN
          IF lv_mod = 'CA' THEN
            lv_pkg_list_cd := 4;
          ELSE
            IF lv_mod IN ('VR', 'R') THEN
              IF NVL(ln_csubsrv, 1) >= 2 AND NVL(ln_csubsrv, 1) <= 6 THEN
                lv_pkg_list_cd := 2;
              ELSIF NVL(ln_csubsrv, 1) > 6 AND NVL(ln_csubsrv, 1) < 10 THEN
                lv_pkg_list_cd := 3;
              ELSE
                lv_pkg_list_cd := 4;
              END IF;
            ELSE
              IF NVL(ln_csubsrv, 1) < 8 THEN
                lv_pkg_list_cd := 4;
              ELSIF NVL(ln_csubsrv, 1) >= 8 AND NVL(ln_csubsrv, 1) < 10 THEN
                lv_pkg_list_cd := 3;
              ELSE
                lv_pkg_list_cd := 4;
              END IF;
            END IF;
          END IF;
        ELSE
          IF ln_csubsrv > 6 THEN
            lv_pkg_list_cd := 3;
          ELSE
            lv_pkg_list_cd := 2;
          END IF;
        END IF;
      ELSE
        IF p_srv_type = 'CDS' THEN
          IF lv_mod = 'CA' THEN
            lv_pkg_list_cd := 4;
          ELSE
            IF lv_mod IN ('VR', 'R') THEN
              IF NVL(ln_csubsrv, 1) >= 2 AND NVL(ln_csubsrv, 1) <= 6 THEN
                lv_pkg_list_cd := 2;
              ELSIF NVL(ln_csubsrv, 1) > 6 AND NVL(ln_csubsrv, 1) < 10 THEN
                lv_pkg_list_cd := 3;
              ELSE
                lv_pkg_list_cd := 4;
              END IF;
            ELSE
              IF NVL(ln_csubsrv, 1) < 8 THEN
                lv_pkg_list_cd := 4;
              ELSIF NVL(ln_csubsrv, 1) >= 8 AND NVL(ln_csubsrv, 1) < 10 THEN
                lv_pkg_list_cd := 3;
              ELSE
                lv_pkg_list_cd := 4;
              END IF;
            END IF;
          END IF;
        ELSE
          IF p_odometer <= 18000 AND ln_veh_age <= 16 THEN
            lv_pkg_list_cd := 1;
          ELSE
            IF ln_csubsrv > 6 THEN
              lv_pkg_list_cd := 3;
            ELSE
              lv_pkg_list_cd := 2;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;

    RETURN lv_pkg_list_cd;
  END SF_SMP_TYPE;
```

#### SP-020 - PKG_SMP.SP_GET_DEFAULT_PART

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves the default SMP part, its service group code, and MRP for a given vehicle (VIN) and principal map code (PMC) within a specified service-type range. The procedure also determines whether the vehicle requires a new or old coolant part variant before selecting the most appropriate part from the active menu catalogue.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_pmc | NUMBER | IN |
| pn_vin | VARCHAR2 | IN |
| pn_group | VARCHAR2 | IN |
| pn_fsrvtype | VARCHAR2 | IN |
| pn_tsrvtype | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_group | VARCHAR2 | OUT |
| po_part | VARCHAR2 | OUT |
| pn_mrp | NUMBER | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output error code to 0 and error message to NULL.
- Step 2 - Query GM_VIN using the supplied VIN to obtain the vehicle's SVAR code (lv_svar) and variant code (lv_variant). If no row is found, both local variables remain NULL and processing continues.
- Step 3 - Query GM_VIN_EXT using the supplied VIN to retrieve the factory check-out (FCOK) date and the old-coolant flag. If no row is found, FCOK date defaults to NULL and the old-coolant flag defaults to 'N'.
- Step 4 - Query AM_LIST for the list entry named 'BLUE_COOLANT_DT' for the supplied PMC to obtain the coolant scheme start date (ld_coolant_stdt). If no row is found, the start date defaults to NULL.
- Step 5 - Derive the coolant flag (lv_coolant_flag): set to 'O' if the old-coolant flag from GM_VIN_EXT is 'Y'; otherwise set to 'N' if the vehicle's FCOK date is later than the coolant start date; otherwise set to 'O'.
- Step 6 - Query the active menu catalogue (vm_menu_cd) filtered by PMC, SVAR code, variant code, active status, current date within the effective date range, and service type 'P'. Restrict eligible service codes to those listed in AM_LIST_RANGE for the group 'SMP_PARTGROUP' matching the supplied part group (pn_group), excluding the coolant part code that is inappropriate for the derived coolant flag ('ZP016' excluded when lv_coolant_flag = 'N'; 'ZP01P' excluded otherwise). Further restrict rows where the numeric portion of the sub-service code falls within the supplied from/to service-type range.
- Step 7 - For each candidate menu row, look up the maximum MRP from PI_PM_PART_MRP for the same PMC and part number.
- Step 8 - From the result set, retain only rows where MRP is not NULL, order by MRP ascending, and select the first row (ROWNUM = 1) to return po_part, pn_mrp, and po_group. If no qualifying row exists, the output parameters remain NULL and no error is raised.

---
**Decision Points**

DP-001

Condition:
lv_old_coolant_flag (from GM_VIN_EXT) = 'Y'

TRUE:
Set lv_coolant_flag to 'O' (old coolant), indicating the vehicle uses the legacy coolant part regardless of FCOK date.

FALSE:
Proceed to DP-002 to evaluate the FCOK date against the coolant scheme start date.

---

DP-002

Condition:
ld_fcok_date (vehicle FCOK date) > ld_coolant_stdt (BLUE_COOLANT_DT start date from AM_LIST)

TRUE:
Set lv_coolant_flag to 'N' (new coolant), indicating the vehicle was produced after the new coolant scheme was introduced.

FALSE:
Set lv_coolant_flag to 'O' (old coolant), indicating the vehicle was produced before or on the coolant scheme start date.

---

DP-003

Condition:
lv_coolant_flag = 'N'

TRUE:
Exclude part code 'ZP016' from the eligible service codes in AM_LIST_RANGE (new-coolant vehicles must not be offered the old coolant part).

FALSE:
Exclude part code 'ZP01P' from the eligible service codes in AM_LIST_RANGE (old-coolant vehicles must not be offered the new coolant part).

---

DP-004

Condition:
At least one candidate part row exists with a non-NULL MRP after all filters are applied.

TRUE:
Return the part number, MRP, and service group code of the lowest-MRP qualifying row (ROWNUM = 1 after ORDER BY MRP ASC).

FALSE:
Leave po_part, pn_mrp, and po_group as NULL; no error is raised.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read GM_VIN_EXT - Reads data from GM_VIN_EXT for lookup or validation.
- DB-003 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-004 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP for lookup or validation.
- DB-005 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
**Business Rules**

- BR-001 - A vehicle's coolant type is determined in priority order: an explicit old-coolant flag of 'Y' on GM_VIN_EXT always classifies the vehicle as old-coolant ('O'), overriding the FCOK date comparison.
- BR-002 - If the old-coolant flag is not 'Y', the vehicle is classified as new-coolant ('N') only when its FCOK date is strictly later than the BLUE_COOLANT_DT start date configured in AM_LIST for the relevant PMC; otherwise it is classified as old-coolant ('O').
- BR-003 - New-coolant vehicles (lv_coolant_flag = 'N') must never be offered part code 'ZP016'; old-coolant vehicles (lv_coolant_flag = 'O') must never be offered part code 'ZP01P'.
- BR-004 - Only parts belonging to the 'SMP_PARTGROUP' list group matching the supplied pn_group, with list_flag = 'Y', are eligible candidates (sourced from AM_LIST_RANGE).
- BR-005 - Only menu entries with service type 'P', active status 'Y', and an effective date range that includes the current system date are considered.
- BR-006 - The numeric suffix of the sub-service code must fall within the range defined by pn_fsrvtype and pn_tsrvtype; entries outside this range are excluded.
- BR-007 - A part is only returnable if a valid MRP exists in PI_PM_PART_MRP for the given PMC; parts with no MRP record are excluded from selection.
- BR-008 - When multiple eligible parts exist, the part with the lowest MRP is selected as the default (ORDER BY MRP ASC, ROWNUM = 1).
- BR-009 - Failures during VIN lookup (GM_VIN, GM_VIN_EXT) or configuration lookup (AM_LIST) are silently suppressed; the procedure continues with NULL or default values rather than raising an error to the caller.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_GET_DEFAULT_PART (pn_pmc       NUMBER,
                                 pn_vin       VARCHAR2,
                                 pn_group     VARCHAR2,
                                 pn_fsrvtype  VARCHAR2,
                                 pn_tsrvtype  VARCHAR2,
                                 po_group     OUT VARCHAR2,
                                 po_part      OUT VARCHAR2,
                                 pn_mrp       OUT NUMBER,
                                 po_err_cd    OUT NUMBER,
                                 po_err_msg   OUT VARCHAR2
                                 )
   IS
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_variant    gm_vin.variant_cd%TYPE;

    -- Added by Rajeev on 13-APR-2026
    ld_fcok_date         DATE;
    ld_coolant_stdt      DATE;
    lv_old_coolant_flag  VARCHAR2(1);
    lv_coolant_flag      VARCHAR2(1);
  BEGIN
    po_err_cd  := 0;
    po_err_msg := NULL;

    BEGIN
      SELECT svar_cd, variant_cd
        INTO lv_svar, lv_variant
        FROM gm_vin
       WHERE vin = pn_vin;
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;

    -- Added by Rajeev on 13-APR-2026
    BEGIN
      BEGIN
        SELECT TO_DATE(v.fcok_date, 'DD-MON-RRRR'),
               NVL(v.old_coolant_flag, 'X')
          INTO ld_fcok_date, lv_old_coolant_flag
          FROM gm_vin_ext V
         WHERE v.vin = pn_vin;
      EXCEPTION WHEN OTHERS THEN
          ld_fcok_date        := NULL;
          lv_old_coolant_flag := 'N';
      END;

      BEGIN
        SELECT TO_DATE(list_desc, 'DD-MON-RRRR')
          INTO ld_coolant_stdt
          FROM am_list
         WHERE list_name = 'BLUE_COOLANT_DT'
           AND principal_map_cd = pn_pmc;
      EXCEPTION WHEN OTHERS THEN
          ld_coolant_stdt := NULL;
      END;

      IF lv_old_coolant_flag = 'Y' THEN
        lv_coolant_flag := 'O';
      ELSIF ld_fcok_date > ld_coolant_stdt THEN
        lv_coolant_flag := 'N';
      ELSE
        lv_coolant_flag := 'O';
      END IF;
      --DBMS_OUTPUT.PUT_LINE(lv_coolant_flag||' - '||ld_fcok_date||' - '||ld_coolant_stdt);
    END;

    BEGIN
      SELECT part_num, mrp, srv_cd
        INTO po_part, pn_mrp, po_group
        FROM (SELECT m.part_num,
                     (SELECT MAX(d.mrp)
                        FROM pi_pm_part_mrp d
                       WHERE d.principal_map_cd = pn_pmc
                         AND d.part_num = m.part_num
                         ) mrp,
                     m.srv_cd
                FROM vm_menu_cd m
               WHERE m.principal_map_cd = pn_pmc
                 AND m.svar_mod_cd = lv_svar
                 AND m.variant_cd = lv_variant
                 AND m.active_yn = 'Y'
                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                 AND m.srv_type = 'P'
                 --AND m.srv_cd = pn_group
                 AND m.srv_cd IN (SELECT list_code
                                    FROM am_list_range
                                   WHERE principal_map_Cd = pn_pmc
                                     AND list_name = 'SMP_PARTGROUP'
                                     AND list_grp_code = pn_group
                                     AND list_flag = 'Y'
                                     AND list_code <> (CASE WHEN lv_coolant_flag = 'N' THEN
                                                         'ZP016'
                                                         ELSE
                                                          'ZP01P'
                                                       END) -- Added by Rajeev on 13-APR-2026
                                     )
                 AND TO_NUMBER(SUBSTR(m.sub_srv_cd,4)) BETWEEN NVL(TO_NUMBER(SUBSTR(pn_fsrvtype,4)),1) AND TO_NUMBER(SUBSTR(pn_tsrvtype,4))
               ORDER BY 2
                 )
       WHERE mrp IS NOT NULL
         AND ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END;
```

#### SP-021 - PKG_SMP.SP_GET_SMP_EXP

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: POST-QUERY]
- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves the SMP (Service Maintenance Package) expiry details for a given vehicle and service/sub-service combination. Using the vehicle's invoice date and SVAR code from GM_VIN, together with the service calendar limits defined in VM_SUB_SRV_CAL, the procedure calculates and returns the expiry age (in years), expiry odometer reading, and expiry date applicable to the SMP contract. If the calculated age ceiling exceeds 11 years, a principal-specific override value is sourced from AM_LIST_RANGE to cap the expiry age.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_pmc | NUMBER | IN |
| pn_vin | VARCHAR2 | IN |
| pn_srv | VARCHAR2 | IN |
| pn_subsrv | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_exp_age | NUMBER | OUT |
| po_exp_mil | NUMBER | OUT |
| po_exp_date | DATE | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output error code to 0, error message to NULL, and internal age accumulator to 0.
- Step 2 - Query GM_VIN using the supplied VIN (pn_vin) to retrieve the vehicle's invoice date (truncated to date only) and SVAR code into local variables ld_inv_dt and lv_svar. Exceptions are silently suppressed; variables retain NULL if no row is found.
- Step 3 - Query VM_SUB_SRV_CAL for rows matching the principal map code (pn_pmc), SVAR code (lv_svar), service category (pn_srv), and sub-service category (pn_subsrv). For each matching row, derive exp_mil as odometer_to when odometer_from > 0 (otherwise 0), and exp_age as vehicle_age_to when odometer_from = 0 (otherwise 0). Take the MAX of both derived columns as the applicable expiry mileage and expiry age in days.
- Step 4 - Convert the raw expiry age (days) to years by dividing by 365 and rounding to 2 decimal places (ln_upto_age).
- Step 5 - If ln_upto_age exceeds 11 years, query AM_LIST_RANGE for the principal-specific SMP parameter (list_name = 'SMP_PARAM', list_code = 'PMS10', list_flag = 'Y' or NULL) and replace the expiry age (ln_exp_age) with the list_to_range value retrieved. Exceptions are silently suppressed.
- Step 6 - Recalculate ln_upto_age from the (potentially overridden) ln_exp_age.
- Step 7 - Assign output parameters: po_exp_age as ln_exp_age / 365 rounded to 2 decimal places, po_exp_mil as ln_exp_mil, and po_exp_date as the vehicle invoice date plus ln_exp_age days.

---
**Decision Points**

DP-001

Condition:
odometer_from > 0 for a row in VM_SUB_SRV_CAL.

TRUE:
The row contributes its odometer_to value as exp_mil (mileage-based expiry limit).

FALSE:
exp_mil is set to 0 for that row (row is not mileage-based).

---

DP-002

Condition:
odometer_from = 0 for a row in VM_SUB_SRV_CAL.

TRUE:
The row contributes its vehicle_age_to value as exp_age (age-based expiry limit in days).

FALSE:
exp_age is set to 0 for that row (row is not age-based).

---

DP-003

Condition:
The calculated expiry age in years (ln_upto_age = ROUND(ln_exp_age / 365, 2)) exceeds 11 years.

TRUE:
Query AM_LIST_RANGE for the principal-specific cap value (list_name = 'SMP_PARAM', list_code = 'PMS10', active flag = 'Y') and override ln_exp_age with the retrieved list_to_range value.

FALSE:
The expiry age derived from VM_SUB_SRV_CAL is used as-is without any override.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read VM_SUB_SRV_CAL - Reads data from VM_SUB_SRV_CAL for lookup or validation.
- DB-003 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
**Business Rules**

- BR-001 - The vehicle's invoice date and SVAR code must be sourced from GM_VIN using the supplied VIN; if the VIN is not found, invoice date and SVAR code remain NULL and downstream calculations will yield NULL outputs without raising an error.
- BR-002 - The expiry mileage limit is determined only from service calendar rows where odometer_from > 0; age-based rows (odometer_from = 0) do not contribute to the mileage expiry.
- BR-003 - The expiry age limit (in days) is determined only from service calendar rows where odometer_from = 0; mileage-based rows do not contribute to the age expiry.
- BR-004 - Where multiple matching rows exist in VM_SUB_SRV_CAL, the maximum derived expiry mileage and maximum derived expiry age are applied, ensuring the most permissive limit governs the SMP contract.
- BR-005 - Expiry age in days is converted to years by dividing by 365 (rounded to 2 decimal places) for comparison and output purposes.
- BR-006 - An expiry age ceiling of 11 years is enforced: if the service calendar yields an age exceeding 11 years, the procedure replaces it with the principal-specific override value stored in AM_LIST_RANGE under list_name = 'SMP_PARAM' and list_code = 'PMS10' (active records only, where list_flag is 'Y' or NULL).
- BR-007 - The SMP expiry date is calculated as the vehicle's invoice date plus the final expiry age expressed in days (po_exp_date = ld_inv_dt + ln_exp_age).
- BR-008 - All database lookup exceptions are silently suppressed; the procedure always completes without raising an unhandled error, returning po_err_cd = 0 and po_err_msg = NULL regardless of lookup failures.

---
**Implementation Logic**

```plsql

  PROCEDURE SP_GET_SMP_EXP (pn_pmc       NUMBER,
                            pn_vin       VARCHAR2,
                            pn_srv       VARCHAR2,
                            pn_subsrv    VARCHAR2,
                            po_exp_age   OUT NUMBER,
                            po_exp_mil   OUT NUMBER,
                            po_exp_date  OUT DATE,
                            po_err_cd    OUT NUMBER,
                            po_err_msg   OUT VARCHAR2
                           )
   IS
   ld_inv_dt   gm_vin.inv_date%TYPE;
   lv_svar     gm_vin.svar_cd%TYPE;
   ln_exp_mil  vm_sub_srv_cal.odometer_to%TYPE;
   ln_exp_age  vm_sub_srv_cal.vehicle_age_to%TYPE;
   ln_upto_age NUMBER(5,2);
  BEGIN
    po_err_cd   := 0;
    po_err_msg  := NULL;
    ln_upto_age := 0;

    BEGIN
      SELECT TRUNC(inv_date), svar_cd
        INTO ld_inv_dt, lv_svar
        FROM gm_vin
       WHERE vin = pn_vin;
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;

    BEGIN
      SELECT MAX(exp_mil), MAX(exp_age)
        INTO ln_exp_mil, ln_exp_age
        FROM (SELECT CASE WHEN l.odometer_from > 0 THEN
                       l.odometer_to
                     ELSE
                       0
                     END exp_mil,
                     CASE WHEN l.odometer_from = 0 THEN
                       l.vehicle_age_to
                     ELSE
                       0
                     END exp_age
                FROM vm_sub_srv_cal l
               WHERE l.principal_map_cd = pn_pmc
                 AND l.svar_cd = lv_svar
                 AND l.rcateg_cd = pn_srv
                 AND l.sub_rcateg_cd = pn_subsrv
                 );
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
    ln_upto_age := ROUND(ln_exp_age / 365, 2);
    --DBMS_OUTPUT.PUT_LINE('Age : '||ln_exp_age||' :: '||ln_upto_age);

    IF ln_upto_age > 11 THEN
      BEGIN
        SELECT list_to_range
          INTO ln_exp_age
          FROM am_list_range
         WHERE principal_map_cd = pn_pmc
           AND list_name = 'SMP_PARAM'
           AND list_code = 'PMS10'
          AND NVL(list_flag,'Y') = 'Y';
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;
    END IF;
    ln_upto_age := ROUND(ln_exp_age / 365, 2);
    --DBMS_OUTPUT.PUT_LINE('New Age : '||ln_exp_age||' :: '||ln_upto_age);

    po_exp_age  := ROUND(ln_exp_age / 365, 2);
    po_exp_mil  := ln_exp_mil;
    po_exp_date := ld_inv_dt + ln_exp_age;
    --DBMS_OUTPUT.PUT_LINE('Service : '||pn_srv||' - '||pn_subsrv||chr(10)||'Age : '||ln_exp_age||chr(10)||ld_inv_dt||chr(10)||po_exp_date);
  END;
```

#### SP-022 - PKG_SMP.SP_PKG_DETAIL

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves the expiry month threshold, expiry mileage threshold, and number of services defined for a specific SMP package configuration. Given a principal map code, fleet (vehicle) category, service type, and package selection code, the procedure looks up the corresponding master record in VM_SMP_PARAM and returns the package detail values to the calling Oracle Forms trigger for display or further validation on the SMP Package Details screen.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_fleet_type | VARCHAR2 | IN |
| p_serv_type | VARCHAR2 | IN |
| p_pkg_sel | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_exp_month | NUMBER | OUT |
| p_exp_mileage | NUMBER | OUT |
| p_srv_no | NUMBER | OUT |
| p_error_cd | NUMBER | OUT |
| p_error_desc | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the four input parameters: principal map code (p_pmc), fleet type / vehicle category (p_fleet_type), service type (p_serv_type), and package selection code (p_pkg_sel).
- Step 2 - Query VM_SMP_PARAM, filtering by PRINCIPAL_MAP_CD = p_pmc, AMC_OPTION = p_pkg_sel, and VEH_CATEG = p_fleet_type, to retrieve EXPIRY_MONTHS, EXPIRY_MILEAGE, and NO_OF_SERV into the output parameters p_exp_month, p_exp_mileage, and p_srv_no respectively.
- Step 3 - If the SELECT succeeds, return the retrieved values to the caller with no error code set.
- Step 4 - If any exception occurs (including NO_DATA_FOUND or TOO_MANY_ROWS), set p_error_cd to 1 and populate p_error_desc with a descriptive message identifying the unresolved package code and the Oracle error text (SQLERRM).

---
**Decision Points**

DP-001

Condition:
Does a matching record exist in VM_SMP_PARAM for the combination of PRINCIPAL_MAP_CD = p_pmc, AMC_OPTION = p_pkg_sel, and VEH_CATEG = p_fleet_type?

TRUE:
The procedure populates p_exp_month, p_exp_mileage, and p_srv_no with the values retrieved from the master table and returns control to the caller with no error indicators set.

FALSE (or any other exception):
The procedure sets p_error_cd to 1 and sets p_error_desc to 'Master not defined for package : <p_pkg_sel> Error: <SQLERRM>', signalling to the caller that the package master record could not be found or another database error occurred.

---
**Database Interactions**

- DB-001 - Read VM_SMP_PARAM - Reads data from VM_SMP_PARAM for lookup or validation.
**Business Rules**

- BR-001 - A valid SMP package master record must exist in VM_SMP_PARAM for the exact combination of principal map code, package selection code (AMC_OPTION), and vehicle category before package detail values can be returned; absence of such a record is treated as a configuration error.
- BR-002 - The expiry month threshold, expiry mileage threshold, and number of services are all sourced exclusively from the VM_SMP_PARAM master table and are not derived or defaulted by this procedure.
- BR-003 - Any database exception during the lookup (including no data found) must result in p_error_cd being set to 1 and p_error_desc containing both the offending package code and the Oracle error message, enabling the calling screen trigger to handle the error condition gracefully.
- BR-004 - The service type input parameter (p_serv_type) is accepted by the procedure signature but is not applied as a filter criterion in the VM_SMP_PARAM query; package detail lookup is governed solely by principal map code, package selection code, and vehicle category.

---
**Implementation Logic**

```plsql

  PROCEDURE SP_PKG_DETAIL(p_pmc         NUMBER,
                          p_fleet_type  VARCHAR2,
                          p_serv_type   VARCHAR2,
                          p_pkg_sel     VARCHAR2,
                          p_exp_month   OUT NUMBER,
                          p_exp_mileage OUT NUMBER,
                          p_srv_no      OUT NUMBER,
                          p_error_cd    OUT NUMBER,
                          p_error_desc  OUT VARCHAR2
                          ) IS
  BEGIN
    BEGIN
      SELECT expiry_months, expiry_mileage, no_of_serv
        INTO p_exp_month, p_exp_mileage, p_srv_no
        FROM vm_smp_param
       WHERE principal_map_cd = p_pmc
         AND amc_option = p_pkg_sel
         AND veh_categ = p_fleet_type;
    EXCEPTION
      WHEN OTHERS THEN
        p_error_cd   := 1;
        p_error_desc := 'Master not defined for package : ' || p_pkg_sel ||
                        ' Error: ' || sqlerrm;
    END;
  END SP_PKG_DETAIL;
```

#### SP-023 - PKG_SMP.SP_POP_SMP_ADDON

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]

---

**Screen:**

Addon Details (WN_MAIN / CN_ADDON)

---

**Purpose**

Populates the SMP (Service Maintenance Package) add-on line items for a specific vehicle and package selection on the Addon Details screen. When a user checks an add-on checkbox, the procedure validates the dealer's city type, vehicle details, and SMP discount eligibility, enforces add-on quantity limits where applicable, clears any previously staged add-on data, retrieves the applicable labour and part menu lines from the add-on catalogue, prices each line using a tiered rate-lookup strategy, and inserts fully costed records into the GBL_SMP staging table and GBL_AMC_DTL detail table ready for quotation display.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp | VARCHAR2 | IN |
| p_pkg_type | VARCHAR2 | IN |
| p_pkg_code | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_sub_srv | VARCHAR2 | IN |
| p_srv_no | NUMBER | IN |
| p_gst_type | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise all output and working variables (p_err_cd = 0, p_err_msg = NULL, counters = 0).
- Step 2 - Retrieve the dealer location's city RPH type and channel from AM_DEALER_LOC joined to GM_FOR using the principal map code and dealer/location keys. If the lookup fails or returns NULL, return error 'City type not defined for dealer'.
- Step 3 - Retrieve the vehicle's super-variant code (svar_cd), variant code, and party code from GM_VIN using the registration number. If not found, return error 'VIN not found'.
- Step 4 - Check whether a valid SMP discount record exists in VM_SMP_DISC for the combination of principal, package type, package code, vehicle variant, and current date. If no matching record exists (lv_disc_chk = 'N'), return error 'SMP package not defined for Specific Vehicle Model'.
- Step 5 - If the discount record exists, retrieve the maximum labour (L), part (P), and consumable (C) discount percentages from VM_SMP_DISC for the same filter criteria into ln_labor_disc_per, ln_part_disc_per, and ln_cons_disc_per respectively.
- Step 6 - Look up the add-on range configuration from AM_LIST_RANGE (list_name = 'SMP_ADDON') to obtain the minimum service count (ln_min_srv), maximum service count (ln_max_srv), and add-on type flag (lv_addon_type: 'P' = part-and-labour, 'L' = labour-only).
- Step 7 - If lv_addon_type = 'L', validate that the requested service quantity (p_srv_no) is within the allowed min/max range; return an appropriate boundary error if violated.
- Step 8 - Delete all existing GBL_SMP rows and GBL_AMC_DTL rows for the current parent/dealer/location/company/registration/package/add-on sub-service combination, then COMMIT to clear the staging area.
- Step 9 - Iterate over the active add-on menu lines from VM_MENU_CD (svar_mod_cd = 'ADDON', active_yn = 'Y', sub_srv_cd = p_sub_srv, within date range) for parts (srv_type = 'P') and labour (srv_type = 'L') in a UNION ALL cursor ordered by type priority. For each line, attempt to UPDATE the matching GBL_SMP row by accumulating srv_qty; if no row exists (SQL%NOTFOUND), INSERT a new GBL_SMP row with the appropriate discount percentage based on service type (L/P/C).
- Step 10 - After the cursor loop, if no rows were processed (ln_cnt = 0), return error 'Add-On not defined for Specific Service Model'.
- Step 11 - Retrieve the current maximum serial number from GBL_AMC_DTL for the package to ensure sequential numbering of new detail lines.
- Step 12 - Iterate over the newly staged GBL_SMP rows for the add-on. For each labour line (srv_type = 'L'): (a) attempt to retrieve a fixed flat amount and SAC code from VM_DLR_LTS; (b) if rate is zero, calculate rate as FRT × rate-per-hour from VM_RCATEG (rcateg_cd = 'PMS'); (c) if still zero, look up the SAC code from VM_MSIL_OPR and the MSIL operation amount from VM_OPR_AMT; (d) if still zero, compute rate as FRT × RPH from VM_OPR_AMT joined to VM_MSIL_RPH_SVAR for dealer type and channel. Increment ln_lcnt for each labour line with a non-zero rate.
- Step 13 - For each part line (srv_type ≠ 'L'): look up the mapped part number and MRP from VM_MENU_CD joined to PI_PM_PART_MRP, filtered by variant via DMSD_EPC_DMS_PART_MAPPING; select the highest-MRP mapped part. Increment ln_part_cnt for each part with a non-zero rate. Retrieve the HSN code and part description from PM_PART.
- Step 14 - For each line where the resolved rate > 0, calculate basic value (qty × rate), discount amount (basic × discount%), and total value (basic - discount), then INSERT the costed row into GBL_AMC_DTL with the GST type, sell price, and addon_type.
- Step 15 - After the detail loop, apply add-on type validation: if lv_addon_type = 'P' and no parts were costed (ln_part_cnt = 0), ROLLBACK and return error 'Add-On Part not defined for Specific Vehicle Model'; if lv_addon_type = 'P' and no labour was costed (ln_lcnt = 0), ROLLBACK and return error 'Add-On Labour not defined for Specific Vehicle Model'; if lv_addon_type = 'L' and no labour was costed, ROLLBACK and return error 'Add-On not defined for Specific Vehicle Model'.
- Step 16 - If the add-on sub-service is 'RB', delete from GBL_AMC_DTL any labour lines whose operation code does not appear in the AM_LIST_RANGE mapping (list_name = 'ADDON_LBR') linked to the corresponding part group codes already inserted for this add-on.
- Step 17 - COMMIT all successful inserts and return with p_err_cd = 0.

---
**Decision Points**

DP-001

Condition:
City RPH type lookup from AM_DEALER_LOC/GM_FOR raises an exception or returns NULL.

TRUE:
Set p_err_cd = 1, p_err_msg = 'City type not defined for dealer', and RETURN.

FALSE:
Continue processing with the resolved lv_city_rph and lv_channel values.

---

DP-002

Condition:
Vehicle registration number not found in GM_VIN.

TRUE:
Set p_err_cd = 1, p_err_msg = 'VIN not found', and RETURN.

FALSE:
Continue with resolved lv_svar, lv_variant, and lv_party_cd.

---

DP-003

Condition:
No active VM_SMP_DISC record exists for the principal/package type/package code/variant/current date combination (lv_disc_chk = 'N').

TRUE:
Set p_err_cd = 1, p_err_msg = 'SMP package not defined for Specific Vehicle Model', and RETURN.

FALSE:
Retrieve the maximum discount percentages for labour, parts, and consumables and continue.

---

DP-004

Condition:
lv_addon_type = 'L' (labour-only add-on) AND p_srv_no exceeds ln_max_srv.

TRUE:
Set p_err_cd = 1, p_err_msg = 'Add-On Quantity Can't be Greater than <ln_max_srv>', and RETURN.

FALSE:
Proceed to the minimum quantity check (DP-005).

---

DP-005

Condition:
lv_addon_type = 'L' AND p_srv_no is less than ln_min_srv.

TRUE:
Set p_err_cd = 1, p_err_msg = 'Add-On Quantity Can't be Less than <ln_min_srv>', and RETURN.

FALSE:
Proceed to clear existing staging data and populate add-on lines.

---

DP-006

Condition:
After iterating the VM_MENU_CD cursor, ln_cnt = 0 (no add-on menu lines found).

TRUE:
Set p_err_cd = 1, p_err_msg = 'Add-On not defined for Specific Service Model', and RETURN.

FALSE:
Proceed to build the GBL_AMC_DTL detail lines.

---

DP-007

Condition:
For a labour line, the flat amount from VM_DLR_LTS is zero or unavailable.

TRUE:
Calculate rate as FRT × rate-per-hour from VM_RCATEG (rcateg_cd = 'PMS').

FALSE:
Use the flat amount from VM_DLR_LTS as the line rate.

---

DP-008

Condition:
Labour rate is still zero after the VM_RCATEG lookup.

TRUE:
Look up the MSIL operation amount from VM_OPR_AMT; if still zero, compute rate as FRT × RPH from VM_OPR_AMT joined to VM_MSIL_RPH_SVAR.

FALSE:
Use the rate derived from VM_RCATEG.

---

DP-009

Condition:
Resolved line rate (ln_rate) > 0 for any line (labour or part).

TRUE:
Calculate basic value, discount amount, and total value, then INSERT the row into GBL_AMC_DTL.

FALSE:
Skip the INSERT; the line is not costed.

---

DP-010

Condition:
lv_addon_type defaults to or equals 'P' AND ln_part_cnt = 0 after the detail loop.

TRUE:
ROLLBACK, set p_err_cd = 1, p_err_msg = 'Add-On Part not defined for Specific Vehicle Model', and RETURN.

FALSE:
Proceed to the labour count check for 'P'-type add-ons (DP-011).

---

DP-011

Condition:
lv_addon_type = 'P' AND ln_lcnt = 0 after the detail loop.

TRUE:
ROLLBACK, set p_err_cd = 1, p_err_msg = 'Add-On Labour not defined for Specific Vehicle Model', and RETURN.

FALSE:
Proceed to the labour-only add-on check (DP-012).

---

DP-012

Condition:
lv_addon_type = 'L' AND ln_lcnt = 0 after the detail loop.

TRUE:
ROLLBACK, set p_err_cd = 1, p_err_msg = 'Add-On not defined for Specific Vehicle Model', and RETURN.

FALSE:
Proceed to the RB sub-service cleanup check (DP-013).

---

DP-013

Condition:
p_sub_srv = 'RB' (Rubber/Battery add-on type).

TRUE:
Delete from GBL_AMC_DTL any labour lines whose operation code is not mapped via AM_LIST_RANGE (list_name = 'ADDON_LBR') to an already-inserted part group for this add-on, then COMMIT.

FALSE:
COMMIT without the additional labour-line pruning.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-003 - Read VM_SMP_DISC - Reads data from VM_SMP_DISC for lookup or validation.
- DB-004 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-005 - Delete from TEMP - Deletes rows from TEMP.
- DB-006 - Delete from GBL_SMP - Deletes rows from GBL_SMP.
- DB-007 - Delete from GBL_AMC_DTL - Deletes rows from GBL_AMC_DTL.
- DB-008 - Read VM_MSIL_OPR - Reads data from VM_MSIL_OPR for lookup or validation.
- DB-009 - Update GBL_SMP - Updates existing rows in GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, to subtype, and 9 more column(s)).
- DB-010 - Insert into GBL_SMP - Persists a new row into GBL_SMP using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, to subtype, and 9 more column(s).
- DB-011 - Insert into DETAILS - Persists a new row into DETAILS.
- DB-012 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s)) for lookup or validation.
- DB-013 - Read GBL_SMP - Reads data from GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, to subtype, and 9 more column(s)) for lookup or validation.
- DB-014 - Read VM_DLR_LTS - Reads data from VM_DLR_LTS for lookup or validation.
- DB-015 - Read VM_RCATEG - Reads data from VM_RCATEG for lookup or validation.
- DB-016 - Read VM_OPR_AMT - Reads data from VM_OPR_AMT for lookup or validation.
- DB-017 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP for lookup or validation.
- DB-018 - Read DMSD_EPC_DMS_PART_MAPPING - Reads data from DMSD_EPC_DMS_PART_MAPPING for lookup or validation.
- DB-019 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-020 - Insert into GBL_AMC_DTL - Persists a new row into GBL_AMC_DTL using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s).
**Business Rules**

- BR-001 - A valid city RPH type must be configured for the dealer location before any add-on can be processed; absence of this configuration is a hard stop.
- BR-002 - The vehicle registration number must exist in GM_VIN; an unrecognised registration number prevents add-on population.
- BR-003 - An active SMP discount record in VM_SMP_DISC must exist for the combination of principal, package type, package code, vehicle variant, and the current date before add-on lines can be staged.
- BR-004 - Discount percentages for labour, parts, and consumables are derived independently from VM_SMP_DISC and applied per service-type category when inserting into GBL_SMP.
- BR-005 - For labour-only add-ons (lv_addon_type = 'L'), the requested service quantity (p_srv_no) must fall within the min/max range defined in AM_LIST_RANGE (list_name = 'SMP_ADDON'); violations return a boundary-specific error.
- BR-006 - Existing GBL_SMP and GBL_AMC_DTL rows for the same parent/dealer/location/company/registration/package/add-on sub-service are always deleted before new lines are inserted, ensuring no duplicate add-on staging data.
- BR-007 - Add-on menu lines are sourced exclusively from VM_MENU_CD where svar_mod_cd = 'ADDON', active_yn = 'Y', and the current date falls within the active date range.
- BR-008 - Labour rates are resolved using a four-tier fallback: (1) fixed flat amount from VM_DLR_LTS, (2) FRT × dealer rate-per-hour from VM_RCATEG, (3) MSIL operation amount from VM_OPR_AMT, (4) FRT × MSIL RPH from VM_OPR_AMT joined to VM_MSIL_RPH_SVAR.
- BR-009 - Part selection requires a matching entry in DMSD_EPC_DMS_PART_MAPPING for the vehicle variant; when multiple parts match, the part with the highest MRP is selected.
- BR-010 - Only lines with a resolved rate greater than zero are inserted into GBL_AMC_DTL; zero-rate lines are silently excluded from the quotation detail.
- BR-011 - For part-and-labour add-ons (lv_addon_type = 'P'), both at least one costed part line and at least one costed labour line must result from processing; failure of either condition triggers a ROLLBACK and a specific error message.
- BR-012 - For labour-only add-ons (lv_addon_type = 'L'), at least one costed labour line must result; if none are found the transaction is rolled back.
- BR-013 - For the 'RB' (Rubber/Battery) sub-service, labour lines are pruned post-insert: any labour operation not linked via AM_LIST_RANGE (list_name = 'ADDON_LBR') to a part group already present in the detail is removed before the final COMMIT.
- BR-014 - The HSN/SAC code defaults to '998729' for labour lines where no explicit SAC code is configured, and to '8708' for part lines where no HS code is defined in PM_PART.
- BR-015 - The sell price stored in GBL_AMC_DTL is set equal to the basic value (quantity × rate before discount), and the GST type is passed directly from the calling context (p_gst_type).

---
**Implementation Logic**

```plsql
  PROCEDURE SP_POP_SMP_ADDON (p_pmc        NUMBER,
                              p_parent     VARCHAR2,
                              p_dealer     NUMBER,
                              p_loc        VARCHAR2,
                              p_comp       VARCHAR2,
                              p_pkg_type   VARCHAR2,
                              p_pkg_code   VARCHAR2,
                              p_reg_num    VARCHAR2,
                              p_sub_srv    VARCHAR2,
                              p_srv_no     NUMBER,
                              p_gst_type   VARCHAR2,
                              p_err_cd     OUT NUMBER,
                              p_err_msg    OUT VARCHAR2
                             )
   IS
    lv_channel    am_dealer_loc.channel%TYPE;
    lv_city_rph   gm_for.city_rph_type%TYPE;
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_variant    gm_vin.variant_cd%TYPE;
    lv_hsn_sac    vm_dlr_lts.sac_code%TYPE;
    lv_part_num   pm_part.part_num%TYPE;
    lv_part_desc  pm_part.part_desc%TYPE;
    lv_party_cd   gm_vin.party_cd%TYPE;

    ln_cnt            NUMBER;
    ln_srl            NUMBER;
    ln_part_cnt       NUMBER;
    ln_rate           NUMBER(12,2) := 0;
    ln_frt            NUMBER(12,2) := 0;
    ln_basic          NUMBER(12,2) := 0;
    ln_disc           NUMBER(12,2) := 0;
    ln_tot            NUMBER(12,2) := 0;
    ln_labor_disc_per NUMBER(5,2)  := 0;
    ln_part_disc_per  NUMBER(5,2)  := 0;
    ln_cons_disc_per  NUMBER(5,2)  := 0;
    lv_disc_chk       VARCHAR2(1) := 'N';

    -- Added by Rajeev on 16-APR-2026
    ln_min_srv        NUMBER;
    ln_max_srv        NUMBER;
    lv_addon_type     VARCHAR2(3);
    ln_lcnt           NUMBER;
  BEGIN
    p_err_cd    := 0;
    p_err_msg   := NULL;
    ln_cnt      := 0;
    ln_part_cnt := 0;
    ln_srl      := 0;
    ln_lcnt     := 0;

    -- City RPH
    BEGIN
      SELECT m.city_rph_type, l.channel
        INTO lv_city_rph, lv_channel
        FROM am_dealer_loc l, gm_for m
       WHERE l.parent_group = p_parent
         AND l.dealer_map_cd = p_dealer
         AND l.loc_cd = p_loc
         AND m.principal_map_cd = p_pmc
         AND m.for_cd = l.for_cd;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END;
    IF lv_city_rph IS NULL THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END IF;

    -- Vehicle Details
    BEGIN
      SELECT svar_cd, variant_cd, party_cd
        INTO lv_svar, lv_variant, lv_party_cd
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'VIN not found';
      RETURN;
    END;

    -- Discount Check
    BEGIN
      SELECT 'Y' INTO lv_disc_chk
        FROM vm_smp_disc
       WHERE principal_map_cd = p_pmc
         AND rcateg_cd = p_pkg_type
         AND smp_type = p_pkg_code
         AND variant = lv_variant
         AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
         AND ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
      lv_disc_chk := 'N';
    END;

    IF NVL(lv_disc_chk,'N') = 'N' THEN
       p_err_cd  := 1;
       p_err_msg := 'SMP package not defined for Specific Vehicle Model';
       RETURN;
    ELSE
      BEGIN
         SELECT MAX(lbr_disc), MAX(part_disc), MAX(cons_disc)
           INTO ln_labor_disc_per, ln_part_disc_per, ln_cons_disc_per
           FROM ( SELECT offer_catg_type,
                         CASE WHEN offer_catg_type = 'L' THEN
                           disc_value
                         ELSE
                           0
                         END lbr_disc,
                         CASE WHEN offer_catg_type = 'P' THEN
                           disc_value
                         ELSE
                           0
                         END part_disc,
                         CASE WHEN offer_catg_type = 'C' THEN
                           disc_value
                         ELSE
                           0
                         END cons_disc
                    FROM vm_smp_disc
                   WHERE principal_map_cd = p_pmc
                     AND rcateg_cd = p_pkg_type
                     AND smp_type = p_pkg_code
                     AND variant = lv_variant
                     AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
                    );
      EXCEPTION WHEN OTHERS THEN
        ln_labor_disc_per := 0;
        ln_part_disc_per  := 0;
        ln_cons_disc_per  := 0;
      END;
    END IF;

    -- Added by Rajeev on 16-APR-2026
    BEGIN
      BEGIN
        SELECT l.list_from_range min_srv, NVL(l.list_to_range,30) max_srv, l.list_flag addon_type
          INTO ln_min_srv, ln_max_srv, lv_addon_type
          FROM am_list_range l
         WHERE l.principal_map_cd =  p_pmc
           AND l.list_name = 'SMP_ADDON'
           AND l.list_grp_code = p_pkg_code
           AND l.list_code = p_sub_srv
           AND NVL(close_date, SYSDATE) >= SYSDATE;
      EXCEPTION WHEN OTHERS THEN
        NULL;
      END;

      IF NVL(lv_addon_type,'P') = 'L' THEN
        IF p_srv_no > ln_max_srv  THEN
          p_err_cd  := 1;
          p_err_msg := 'Add-On Quantity Can''t be Greater than '||ln_max_srv;
          RETURN;
        ELSIF p_srv_no < ln_min_srv  THEN
          p_err_cd  := 1;
          p_err_msg := 'Add-On Quantity Can''t be Less than '||ln_min_srv;
          RETURN;
        END IF;
      END IF;
    END;

    -- Delete from temp table
    DELETE FROM gbl_smp
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_type = p_pkg_type
       AND pkg_code = p_pkg_code
       AND addon_type = p_sub_srv;

    DELETE FROM gbl_amc_dtl
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code
       AND addon_type = p_sub_srv;
    COMMIT;

    ln_cnt  := 0;
    FOR cur_m IN (SELECT ROWNUM srl_num, srv_type, srv_cd, srv_desc, srv_qty
                    FROM (SELECT DISTINCT
                                 CASE WHEN m.srv_type = 'L' THEN
                                   4
                                 ELSE
                                   3
                                 END slr,
                                 m.srv_type srv_type,
                                 m.srv_cd,
                                 CASE WHEN m.srv_type = 'L' THEN
                                     (SELECT o.opr_desc
                                        FROM vm_msil_opr o
                                       WHERE o.principal_map_cd = p_pmc
                                         AND o.opr_cd = m.srv_cd
                                         AND o.dealer_type = 'D'
                                         AND o.svar_cd = lv_svar
                                         AND ROWNUM = 1
                                         )
                                   ELSE
                                     (SELECT l.list_desc
                                        FROM am_list_range l
                                       WHERE l.principal_map_cd = p_pmc
                                         AND l.list_name = 'PART_TYPE'
                                         AND l.list_code = m.srv_cd
                                         AND ROWNUM = 1
                                       )
                                 END srv_desc,
                                 m.srv_qty
                            FROM vm_menu_cd m
                           WHERE m.principal_map_cd = p_pmc
                             AND m.svar_mod_cd = 'ADDON'
                             AND m.active_yn = 'Y'
                             AND m.sub_srv_cd = p_sub_srv
                             AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                             AND m.srv_type = 'P'
                          UNION ALL
                          SELECT DISTINCT
                                 CASE WHEN m.srv_type = 'L' THEN
                                   4
                                 ELSE
                                   3
                                 END slr,
                                 m.srv_type srv_type,
                                 m.srv_cd,
                                 CASE WHEN m.srv_type = 'L' THEN
                                     (SELECT o.opr_desc
                                        FROM vm_msil_opr o
                                       WHERE o.principal_map_cd = p_pmc
                                         AND o.opr_cd = m.srv_cd
                                         AND o.dealer_type = 'D'
                                         AND o.svar_cd = lv_svar
                                         AND ROWNUM = 1
                                         )
                                   ELSE
                                     (SELECT l.list_desc
                                        FROM am_list_range l
                                       WHERE l.principal_map_cd = p_pmc
                                         AND l.list_name = 'PART_TYPE'
                                         AND l.list_code = m.srv_cd
                                         AND ROWNUM = 1
                                       )
                                 END srv_desc,
                                 m.srv_qty
                            FROM vm_menu_cd m
                           WHERE m.principal_map_cd = p_pmc
                             AND m.svar_mod_cd = 'ADDON'
                             AND m.active_yn = 'Y'
                             AND m.sub_srv_cd = p_sub_srv
                             AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                             AND m.srv_type = 'L'
                           ORDER by 1,2 DESC,3
                         )
                     )
     LOOP
       ln_cnt := NVL(ln_cnt,0) + 1;
       UPDATE gbl_smp
          SET srv_qty = NVL(srv_qty,0) + NVL(cur_m.srv_qty,0)
        WHERE parent_group = p_parent
          AND dealer_map_cd = p_dealer
          AND loc_cd = p_loc
          AND comp_fa = p_comp
          AND reg_num = p_reg_num
          AND pkg_type = p_pkg_type
          AND pkg_code = p_pkg_code
          AND srv_type = cur_m.srv_type
          AND srv_cd = cur_m.srv_cd
          AND addon_type = p_sub_srv;

       IF SQL%NOTFOUND THEN
         BEGIN
           INSERT INTO gbl_smp (parent_group,
                                dealer_map_cd,
                                loc_cd,
                                comp_fa,
                                reg_num,
                                pkg_type,
                                from_subtype,
                                to_subtype,
                                no_of_srv,
                                pkg_code,
                                srl_num,
                                srv_type,
                                srv_cd,
                                srv_desc,
                                srv_qty,
                                discount_per,
                                addon_type
                                )
                     VALUES   (p_parent,
                               p_dealer,
                               p_loc,
                               p_comp,
                               p_reg_num,
                               p_pkg_type,
                               p_sub_srv,
                               'ADD',
                               p_srv_no,
                               p_pkg_code,
                               cur_m.srl_num,
                               cur_m.srv_type,
                               cur_m.srv_cd,
                               cur_m.srv_desc,
                               p_srv_no,
                               CASE WHEN cur_m.srv_type = 'L' THEN
                                  ln_labor_disc_per
                                WHEN cur_m.srv_type = 'P' THEN
                                  ln_part_disc_per
                                WHEN cur_m.srv_type = 'C' THEN
                                  ln_cons_disc_per
                                ELSE
                                  0
                                END,
                                p_sub_srv
                               );
         EXCEPTION WHEN OTHERS THEN
           NULL;
         END;
       END IF;
    END LOOP;

    IF NVL(ln_cnt, 0) = 0 THEN
      p_err_cd  := 1;
      p_err_msg := 'Add-On not defined for Specific Service Model';
      RETURN;
    END IF;

    -- Insert into Details Table
    IF p_err_cd = 0 THEN
      ln_part_cnt := 0;
      ln_lcnt     := 0;

      -- Added on 18-MAY-2026 for check serial number
      BEGIN
        SELECT MAX(x.srl_num)
          INTO ln_srl
          FROM gbl_amc_dtl x
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code;
      EXCEPTION WHEN OTHERS THEN
        ln_srl := 0;
      END;

      FOR cur_d IN (SELECT x.*
                      FROM gbl_smp x
                     WHERE parent_group = p_parent
                       AND dealer_map_cd = p_dealer
                       AND loc_cd = p_loc
                       AND comp_fa = p_comp
                       AND reg_num = p_reg_num
                       AND pkg_type = p_pkg_type
                       AND pkg_code = p_pkg_code
                       AND addon_type = p_sub_srv
                      ORDER BY srl_num
                     )
      LOOP
        ln_rate     := 0;
        ln_frt      := 0;
        lv_hsn_sac  := NULL;
        ln_srl  := NVL(ln_srl, 0) + 1;
        IF cur_d.srv_type = 'L' THEN -- Labour
          -- Labour Fixed Amount on WS
          BEGIN
            SELECT NVL(L.sac_code, '998729'), l.flat_amt, l.flat_rate_hrs
              INTO lv_hsn_sac, ln_rate, ln_frt
              FROM vm_dlr_lts l
             WHERE l.dealer_map_cd = p_dealer
               AND l.loc_cd = p_loc
               AND l.svar_cd = lv_svar
               AND l.opr_cd = cur_d.srv_cd;
          EXCEPTION WHEN OTHERS THEN
             NULL;
          END;

          IF NVL(ln_rate,0) = 0 THEN -- FRT if Fixed amount not available at WS
            BEGIN
              SELECT NVL(l.rate_per_hour,0) * NVL(ln_frt,0)
                INTO ln_rate
                FROM vm_rcateg l
               WHERE l.dealer_map_cd = p_dealer
                 AND l.loc_cd = p_loc
                 AND l.svar_cd = lv_svar
                 AND l.rcateg_cd = 'PMS';
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
          END IF;

          IF NVL(ln_rate,0) = 0 THEN -- Check Rate at MSIL if not available at Dealer
            BEGIN
              SELECT NVL(sac_code, '998729')
                INTO lv_hsn_sac
                FROM vm_msil_opr l
               WHERE l.principal_map_cd = p_pmc
                 AND l.dealer_type = 'D'
                 AND l.svar_cd = lv_svar
                 AND l.opr_cd = cur_d.srv_cd;
            EXCEPTION WHEN OTHERS THEN
               lv_hsn_sac  := NULL;
            END;

            BEGIN
              SELECT m.opr_amt
                INTO ln_rate
                FROM vm_opr_amt m
               WHERE m.principal_map_cd = p_pmc
                 AND m.opr_cd = cur_d.srv_cd
                 AND m.svar_cd = lv_svar
                 AND m.city_rph_type = lv_city_rph
                 AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE));
            EXCEPTION WHEN OTHERS THEN
               ln_rate := 0;
            END;

            IF NVL(ln_rate,0) = 0 THEN
              BEGIN
                SELECT NVL(m.frt, 0) * NVL(x.rph, 0) opr_amt
                  INTO ln_rate
                  FROM vm_opr_amt m, vm_msil_rph_svar x
                 WHERE m.principal_map_cd = p_pmc
                   AND m.opr_cd = cur_d.srv_cd
                   AND m.svar_cd = lv_svar
                   AND m.city_rph_type = lv_city_rph
                   AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE))
                   AND x.principal_map_cd = m.principal_map_cd
                   AND x.city_rph_type = m.city_rph_type
                   AND x.svar_cd = m.svar_cd
                   AND x.rph_type = 'D'
                   AND x.channel = lv_channel;
              EXCEPTION WHEN OTHERS THEN
                 ln_rate := 0;
              END;
            END IF;
          END IF;

          -- Added by Rajeev on 16-APR-2026 for Count Labour
          IF cur_d.srv_cd IS NOT NULL AND NVL(ln_rate, 0) > 0 THEN
            ln_lcnt := NVL(ln_lcnt,0) + 1;
          END IF;

        ELSE -- Parts
          -- Check Part & MRP
          BEGIN
            SELECT part_num, mrp
              INTO lv_part_num, ln_rate
              FROM (SELECT m.part_num,
                           (SELECT MAX(d.mrp)
                              FROM pi_pm_part_mrp d
                             WHERE d.principal_map_cd = p_pmc
                               AND d.part_num = m.part_num
                               ) mrp
                      FROM vm_menu_cd m
                     WHERE m.principal_map_cd = p_pmc
                       AND m.svar_mod_cd = 'ADDON'
                       AND m.active_yn = 'Y'
                       AND m.sub_srv_cd = cur_d.addon_type
                       AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                       AND m.srv_type = 'P'
                       AND m.srv_cd = cur_d.srv_cd
                       AND EXISTS (SELECT 1 FROM dmsd_epc_dms_part_mapping ep
                                    WHERE ep.variant_cd = lv_variant
                                      AND ep.part_num = m.part_num
                                      )
                     ORDER BY 2 DESC
                       )
             WHERE mrp IS NOT NULL
               AND ROWNUM = 1;
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;

          -- Part Count
          IF lv_part_num IS NOT NULL AND NVL(ln_rate, 0) > 0 THEN
            ln_part_cnt := NVL(ln_part_cnt,0) + 1;
          END IF;

          -- Part Details
          BEGIN
            SELECT NVL(hs_code, '8708'), part_desc
              INTO lv_hsn_sac, lv_part_desc
              FROM pm_part
             WHERE part_num = lv_part_num
               AND principal_map_cd = p_pmc
               AND dealer_map_cd = p_pmc;
          EXCEPTION WHEN OTHERS THEN
             lv_hsn_sac   := NULL;
             lv_part_desc := NULL;
          END;
        END IF;

        IF NVL(ln_rate, 0) > 0 THEN
          ln_basic := NVL(cur_d.srv_qty, 0) * NVL(ln_rate, 0);
          ln_disc  := NVL(ln_basic, 0) * NVL(cur_d.discount_per, 0) / 100;
          ln_tot   := NVL(ln_basic, 0) - NVL(ln_disc, 0);

          BEGIN
           INSERT INTO gbl_amc_dtl (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    group_cd,
                                    group_desc,
                                    qty,
                                    discount_per,
                                    catg_cd,
                                    catg_desc,
                                    hsn_sac_cd,
                                    rate,
                                    basic_value,
                                    discount_amt,
                                    tot_value,
                                    gst_type,
                                    sell_price,
                                    addon_type
                                    )
                        VALUES     (cur_d.parent_group,
                                    cur_d.dealer_map_cd,
                                    cur_d.loc_cd,
                                    cur_d.comp_fa,
                                    cur_d.reg_num,
                                    cur_d.pkg_code,
                                    ln_srl,
                                    cur_d.srv_type,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_cd
                                    ELSE
                                      lv_part_num
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_desc
                                    ELSE
                                      lv_part_desc
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_cd
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_desc
                                    END,
                                    cur_d.srv_qty,
                                    cur_d.discount_per,

                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      'G'
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      (SELECT list_desc
                                         FROM am_list_range
                                        WHERE principal_map_cd = p_pmc
                                          AND list_name = 'AMC_CATG_TYPE'
                                          AND list_code = 'G')
                                    END,
                                    lv_hsn_sac,
                                    ln_rate,
                                    ln_basic,
                                    ln_disc,
                                    ln_tot,
                                    p_gst_type,
                                    ln_basic,
                                    cur_d.addon_type
                                    );
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
        END IF;
      END LOOP;
      --dbms_output.put_line('Part Count '||ln_part_cnt);
      IF NVL(lv_addon_type,'P') = 'P' AND NVL(ln_part_cnt, 0) = 0 THEN
        ROLLBACK;
        p_err_cd  := 1;
        p_err_msg := 'Add-On Part not defined for Specific Vehicle Model';
        RETURN;
      ELSIF NVL(lv_addon_type,'P') = 'P' AND NVL(ln_lcnt, 0) = 0 THEN -- Added by Rajeev on 16-APR for check Labour count also for P type addon
        ROLLBACK;
        p_err_cd  := 1;
        p_err_msg := 'Add-On Labour not defined for Specific Vehicle Model';
        RETURN;
      ELSIF NVL(lv_addon_type,'P') = 'L' AND NVL(ln_lcnt, 0) = 0 THEN -- Added by Rajeev on 16-APR for check Only Labour count for L type addon
        ROLLBACK;
        p_err_cd  := 1;
        p_err_msg := 'Add-On not defined for Specific Vehicle Model';
        RETURN;
      ELSE
        IF p_sub_srv = 'RB' THEN
          DELETE FROM gbl_amc_dtl x
           WHERE x.srv_type = 'L'
             AND x.parent_group = p_parent
             AND x.dealer_map_cd = p_dealer
             AND x.loc_cd = p_loc
             AND x.comp_fa = p_comp
             AND x.reg_num = p_reg_num
             AND x.pkg_code = p_pkg_code
             AND x.addon_type = p_sub_srv
             AND x.srv_cd NOT IN (SELECT l.list_desc
                                    FROM gbl_amc_dtl d, am_list_range l
                                   WHERE d.srv_type = 'P'
                                     AND d.parent_group = p_parent
                                     AND d.dealer_map_cd = p_dealer
                                     AND d.loc_cd = p_loc
                                     AND d.comp_fa = p_comp
                                     AND d.reg_num = p_reg_num
                                     AND d.pkg_code = p_pkg_code
                                     AND d.addon_type = p_sub_srv
                                     AND l.principal_map_cd = p_pmc
                                     AND l.list_name = 'ADDON_LBR'
                                     AND l.list_grp_code = d.addon_type
                                     AND d.group_cd = l.list_code
                                     );
        END IF;
        COMMIT;
      END IF;
    END IF;
    COMMIT;
  END ;
```

#### SP-024 - PKG_SMP.SP_POP_SMP_PKG

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Populates the SMP (Service Maintenance Package) staging and detail tables for a selected vehicle and package combination. When a user initiates package population from the SMP Enquiry screen, this procedure validates the dealer's city classification, retrieves vehicle details, confirms that a valid discount definition exists for the package and vehicle variant, then builds line-item records in GBL_SMP (service menu lines) and GBL_AMC_DTL (costed detail lines) covering labour, parts, and consumables across all services included in the package. It also applies coolant-type logic to exclude the inapplicable coolant part code and removes orphaned road-bike labour lines after population.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp | VARCHAR2 | IN |
| p_pkg_type | VARCHAR2 | IN |
| p_pkg_code | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_sub_srv | VARCHAR2 | IN |
| p_srv_no | NUMBER | IN |
| p_gst_type | VARCHAR2 | IN |
| p_engine | VARCHAR2 | IN |
| p_coolant | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output parameters (p_err_cd = 0, p_err_msg = NULL) and working counters.
- Step 2 - Query AM_DEALER_LOC joined to GM_FOR to derive the dealer location's city RPH type and sales channel for the given principal, parent group, dealer, and location. If the query fails or returns a NULL city type, set p_err_cd = 1 with message 'City type not defined for dealer' and exit.
- Step 3 - Query GM_VIN to retrieve the VIN, model code, SVAR code, variant code, and party code for the supplied registration number. If not found, set p_err_cd = 1 with message 'VIN not found' and exit.
- Step 4 - Query GM_VIN_EXT for the vehicle's FCOK date and old-coolant flag. If no record exists, default FCOK date to NULL and old-coolant flag to 'N'. Separately query AM_LIST for the BLUE_COOLANT_DT configuration date for the principal. Derive lv_coolant_flag: 'O' if old_coolant_flag = 'Y'; 'N' if FCOK date is after the coolant start date; otherwise 'O'. This flag controls which coolant part code (ZP016 vs ZP01P) is excluded from menu selection.
- Step 5 - Query VM_SMP_DISC to confirm a discount record exists for the principal, package type, package code, vehicle variant, and current date. If none found, set p_err_cd = 1 with message 'SMP package not defined for Specific Vehicle Model' and exit.
- Step 6 - If a discount record exists, aggregate maximum discount percentages by offer category type (L = labour, P = parts, C = consumables) from VM_SMP_DISC into ln_labor_disc_per, ln_part_disc_per, and ln_cons_disc_per. Default all to 0 on exception.
- Step 7 - Delete existing GBL_SMP rows for the package/vehicle combination (where addon_type IS NULL) and all matching GBL_AMC_DTL rows, then COMMIT to clear prior staging data.
- Step 8 - If p_pkg_type = 'PMS': iterate from the starting sub-service number up to p_srv_no services. For each iteration, query VM_MENU_CD for the SVAR/variant, filtering by the current sub-service code and excluding the inapplicable coolant part. Labour lines are included; FR3 service type restricts to parts only. For each menu line, attempt an UPDATE on GBL_SMP (accumulating quantity); if no row is updated, INSERT a new GBL_SMP row with the appropriate discount percentage by service type. After each service iteration, increment the sub-service counter. If no menu lines were found for a service iteration, set p_err_cd = 1 with message '<service code> Service Menu Code not defined for Specific Service Model' and exit.
- Step 9 - If p_pkg_type IN ('CDS', 'CVMS'): iterate similarly, but service 1 maps to sub-service 'FR3' (parts only, no labour) and subsequent services map to 'PMS'||n. Parts are further restricted to those listed in AM_LIST_RANGE under 'CDS_CVMS_PGROUP'. Labour lines are sourced from a separate UNION branch using SVAR = 'SVAR' and sub_srv_cd = p_pkg_type, and are excluded for FR3 iterations. GBL_SMP is updated or inserted with the CDS/CVMS-specific sub-service code (lv_cds_cvm). Same error handling as Step 8 applies.
- Step 10 - If p_err_cd = 0, iterate over all GBL_SMP rows for the package/vehicle (including addon lines) ordered by service type priority. For each line:
  - Labour lines: look up the flat rate and SAC code from VM_DLR_LTS. If rate is zero, calculate rate from VM_RCATEG (rate per hour × FRT). If still zero, look up SAC from VM_MSIL_OPR and rate from VM_OPR_AMT; if still zero, calculate as FRT × RPH from VM_MSIL_RPH_SVAR using the dealer channel.
  - Part/consumable lines (non-addon): determine the part group from AM_LIST_RANGE under 'SMP_PARTGROUP'. If the group is 'ENGOIL' and an engine part number is supplied, resolve part number and MRP from VM_MENU_CD/PI_PM_PART_MRP using p_engine. If 'COOLANT' and a coolant part number is supplied, resolve using p_coolant. Otherwise resolve the highest-MRP part mapped in DMSD_EPC_DMS_PART_MAPPING; if none found, fall back to the highest-MRP part without the EPC mapping filter.
  - Addon part lines: resolve part number and MRP from VM_MENU_CD with svar_mod_cd = 'ADDON', filtered by DMSD_EPC_DMS_PART_MAPPING.
  - For all non-labour lines, retrieve HSN code and part description from PM_PART.
- Step 11 - If the resolved rate is greater than zero, calculate basic value (qty × rate), discount amount (basic × discount%), and net total, then INSERT a row into GBL_AMC_DTL with full costing, HSN/SAC, GST type, and addon type.
- Step 12 - After the detail loop, delete GBL_AMC_DTL labour rows of addon type 'RB' whose operation code does not correspond to a part line in the same package linked via AM_LIST_RANGE 'ADDON_LBR', ensuring orphaned road-bike labour lines are removed.
- Step 13 - COMMIT all changes.

---
**Decision Points**

DP-001

Condition:
City RPH type query on AM_DEALER_LOC/GM_FOR fails or returns NULL.

TRUE:
Set p_err_cd = 1, p_err_msg = 'City type not defined for dealer', and RETURN.

FALSE:
Continue to vehicle detail retrieval.

---

DP-002

Condition:
GM_VIN query for the registration number fails (no row found or exception).

TRUE:
Set p_err_cd = 1, p_err_msg = 'VIN not found', and RETURN.

FALSE:
Continue to coolant flag derivation.

---

DP-003

Condition:
lv_old_coolant_flag = 'Y' (vehicle is flagged as having old coolant).

TRUE:
Set lv_coolant_flag = 'O' (old coolant).

FALSE:
Evaluate DP-004.

---

DP-004

Condition:
FCOK date (ld_fcok_date) is after the BLUE_COOLANT_DT configuration date (ld_coolant_stdt).

TRUE:
Set lv_coolant_flag = 'N' (new/blue coolant); exclude part ZP016 from menu selection.

FALSE:
Set lv_coolant_flag = 'O' (old coolant); exclude part ZP01P from menu selection.

---

DP-005

Condition:
No active VM_SMP_DISC record exists for the principal, package type, package code, vehicle variant, and current date (lv_disc_chk = 'N').

TRUE:
Set p_err_cd = 1, p_err_msg = 'SMP package not defined for Specific Vehicle Model', and RETURN.

FALSE:
Aggregate discount percentages from VM_SMP_DISC and continue.

---

DP-006

Condition:
p_pkg_type = 'PMS'.

TRUE:
Process services using PMS sub-service codes (FR3 for first free service, PMS||n for subsequent); include both labour and parts except for FR3 which is parts-only.

FALSE:
Evaluate DP-007.

---

DP-007

Condition:
p_pkg_type IN ('CDS', 'CVMS').

TRUE:
Process services using CDS/CVMS logic: service 1 = FR3 (parts only from CDS_CVMS_PGROUP list); subsequent services = PMS||n parts from CDS_CVMS_PGROUP plus generic labour from SVAR menu.

FALSE:
No service lines are generated (package type not handled).

---

DP-008

Condition:
For a PMS or CDS/CVMS service iteration, no menu lines are returned from VM_MENU_CD (ln_cnt = 0) after processing all rows.

TRUE:
Set p_err_cd = 1, p_err_msg = '<service code> Service Menu Code not defined for Specific Service Model', and RETURN.

FALSE:
Increment sub-service counter and continue to the next iteration.

---

DP-009

Condition:
GBL_SMP UPDATE for a menu line affects no rows (SQL%NOTFOUND).

TRUE:
INSERT a new GBL_SMP row for the service line with the applicable discount percentage.

FALSE:
Row already existed; quantity has been accumulated via UPDATE; no INSERT required.

---

DP-010

Condition:
Detail line service type is 'L' (labour).

TRUE:
Resolve rate and SAC code through the labour rate lookup chain (VM_DLR_LTS -> VM_RCATEG -> VM_OPR_AMT flat -> VM_OPR_AMT FRT×RPH).

FALSE:
Resolve part number and MRP through the parts/consumables lookup chain (DP-011 onwards).

---

DP-011

Condition:
Detail line has no addon_type (standard package part/consumable).

TRUE:
Determine part group from AM_LIST_RANGE 'SMP_PARTGROUP' and apply engine-oil, coolant, or general part resolution logic (DP-012, DP-013, DP-014).

FALSE:
Resolve part number and MRP from VM_MENU_CD with svar_mod_cd = 'ADDON', filtered by DMSD_EPC_DMS_PART_MAPPING.

---

DP-012

Condition:
Part group = 'ENGOIL' AND p_engine is not 'NA' or NULL.

TRUE:
Resolve part number and MRP from VM_MENU_CD/PI_PM_PART_MRP matching the supplied engine part number (p_engine).

FALSE:
Evaluate DP-013.

---

DP-013

Condition:
Part group = 'COOLANT' AND p_coolant is not 'NA' or NULL.

TRUE:
Resolve part number and MRP from VM_MENU_CD/PI_PM_PART_MRP matching the supplied coolant part number (p_coolant).

FALSE:
Evaluate DP-014.

---

DP-014

Condition:
A matching part exists in DMSD_EPC_DMS_PART_MAPPING for the resolved part number and variant.

TRUE:
Use the EPC-mapped part number and its maximum MRP from PI_PM_PART_MRP.

FALSE:
Fall back to the highest-MRP part from VM_MENU_CD/PI_PM_PART_MRP without the EPC mapping filter.

---

DP-015

Condition:
Resolved rate (ln_rate) > 0 for the current detail line.

TRUE:
Calculate basic value, discount amount, and net total; INSERT a costed row into GBL_AMC_DTL.

FALSE:
Skip INSERT; no cost record is created for this line.

---

DP-016

Condition:
Labour rate from VM_DLR_LTS flat_amt is zero after the initial lookup.

TRUE:
Calculate rate as rate_per_hour × FRT from VM_RCATEG for the SVAR and 'PMS' category.

FALSE:
Use the flat amount retrieved from VM_DLR_LTS.

---

DP-017

Condition:
Labour rate is still zero after the VM_RCATEG calculation.

TRUE:
Look up SAC from VM_MSIL_OPR and rate from VM_OPR_AMT (flat opr_amt); if still zero, compute as FRT × RPH from VM_MSIL_RPH_SVAR using the dealer channel.

FALSE:
Use the rate derived from VM_RCATEG.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-003 - Read GM_VIN_EXT - Reads data from GM_VIN_EXT for lookup or validation.
- DB-004 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-005 - Read VM_SMP_DISC - Reads data from VM_SMP_DISC for lookup or validation.
- DB-006 - Delete from TEMP - Deletes rows from TEMP.
- DB-007 - Delete from GBL_SMP - Deletes rows from GBL_SMP.
- DB-008 - Delete from GBL_AMC_DTL - Deletes rows from GBL_AMC_DTL.
- DB-009 - Insert into SMP - Persists a new row into SMP.
- DB-010 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-011 - Read VM_MSIL_OPR - Reads data from VM_MSIL_OPR for lookup or validation.
- DB-012 - Update GBL_SMP - Updates existing rows in GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s)).
- DB-013 - Insert into GBL_SMP - Persists a new row into GBL_SMP using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s).
- DB-014 - Insert into DETAILS - Persists a new row into DETAILS.
- DB-015 - Read GBL_SMP - Reads data from GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s)) for lookup or validation.
- DB-016 - Read VM_DLR_LTS - Reads data from VM_DLR_LTS for lookup or validation.
- DB-017 - Read VM_RCATEG - Reads data from VM_RCATEG for lookup or validation.
- DB-018 - Read VM_OPR_AMT - Reads data from VM_OPR_AMT for lookup or validation.
- DB-019 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP for lookup or validation.
- DB-020 - Read DMSD_EPC_DMS_PART_MAPPING - Reads data from DMSD_EPC_DMS_PART_MAPPING for lookup or validation.
- DB-021 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-022 - Insert into GBL_AMC_DTL - Persists a new row into GBL_AMC_DTL using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s).
- DB-023 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s)) for lookup or validation.
**Business Rules**

- BR-001 - A dealer location must have a city RPH type configured in GM_FOR; the procedure will not proceed without a valid city classification.
- BR-002 - The registration number supplied must correspond to an active VIN record in GM_VIN; package population cannot proceed for an unrecognised vehicle.
- BR-003 - An active SMP discount definition must exist in VM_SMP_DISC for the combination of principal, package type, package code, vehicle variant, and current date before any package lines are generated.
- BR-004 - Discount percentages are derived separately for labour ('L'), parts ('P'), and consumables ('C') offer category types from VM_SMP_DISC and applied per line type when writing GBL_SMP and GBL_AMC_DTL records.
- BR-005 - Prior staging data for the same package/vehicle combination is always cleared (GBL_SMP where addon_type IS NULL, and all GBL_AMC_DTL rows) before re-population, ensuring no stale lines carry forward.
- BR-006 - The coolant part included in the service menu is determined by the vehicle's FCOK date relative to the BLUE_COOLANT_DT principal configuration date: vehicles with FCOK after that date use new/blue coolant (exclude ZP016); all others use old coolant (exclude ZP01P). If the vehicle's old_coolant_flag is explicitly 'Y', old coolant is always used regardless of FCOK date.
- BR-007 - For PMS packages, the first free service (FR3) is restricted to parts only; all other PMS sub-services include both parts and labour.
- BR-008 - For CDS and CVMS packages, parts must belong to the 'CDS_CVMS_PGROUP' list in AM_LIST_RANGE (active, non-closed entries only); labour is sourced from a generic SVAR menu entry and is excluded for the FR3 (first) service.
- BR-009 - If a service menu code yields no lines for a given service iteration within the package, the procedure raises an error and aborts, preventing partial package population.
- BR-010 - GBL_SMP is maintained as an upsert: if a service code/type combination already exists for the package, its quantity is accumulated; otherwise a new row is inserted.
- BR-011 - Engine-oil parts are resolved using the caller-supplied engine part number (p_engine) when the part group is 'ENGOIL'; coolant parts are resolved using p_coolant when the part group is 'COOLANT'. For all other parts, the EPC mapping table (DMSD_EPC_DMS_PART_MAPPING) is the preferred resolution source, with a fallback to the highest-MRP part without EPC filtering.
- BR-012 - Labour rates are resolved through a four-level fallback: (1) flat amount from VM_DLR_LTS; (2) rate per hour × FRT from VM_RCATEG; (3) flat operation amount from VM_OPR_AMT; (4) FRT × RPH from VM_MSIL_RPH_SVAR using the dealer's sales channel and city RPH type.
- BR-013 - Only detail lines with a resolved rate greater than zero are written to GBL_AMC_DTL; zero-rate lines are silently skipped.
- BR-014 - The HSN/SAC code defaults to '998729' for labour lines where no SAC is found, and to '8708' for part lines where no HS code is defined in PM_PART.
- BR-015 - After detail population, orphaned road-bike ('RB') addon labour lines in GBL_AMC_DTL are removed if their operation code does not correspond to a part line in the same package as defined by the 'ADDON_LBR' list in AM_LIST_RANGE, ensuring labour/part consistency for road-bike add-ons.
- BR-016 - All data modifications (deletes, inserts, updates) are committed in two stages: once after the initial cleanup (Step 7) and once after all detail lines are written and orphan cleanup is complete (Step 13).

---
**Implementation Logic**

```plsql

  PROCEDURE SP_POP_SMP_PKG (p_pmc        NUMBER,
                            p_parent     VARCHAR2,
                            p_dealer     NUMBER,
                            p_loc        VARCHAR2,
                            p_comp       VARCHAR2,
                            p_pkg_type   VARCHAR2,
                            p_pkg_code   VARCHAR2,
                            p_reg_num    VARCHAR2,
                            p_sub_srv    VARCHAR2,
                            p_srv_no     NUMBER,
                            p_gst_type   VARCHAR2,
                            p_engine     VARCHAR2,
                            p_coolant    VARCHAR2,
                            p_err_cd     OUT NUMBER,
                            p_err_msg    OUT VARCHAR2
                            )
   IS
    lv_channel    am_dealer_loc.channel%TYPE;
    lv_city_rph   gm_for.city_rph_type%TYPE;
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_model      gm_vin.model_cd%TYPE;
    lv_variant    gm_vin.variant_cd%TYPE;
    lv_hsn_sac    vm_dlr_lts.sac_code%TYPE;
    lv_part_num   pm_part.part_num%TYPE;
    lv_part_desc  pm_part.part_desc%TYPE;
    lv_party_cd   gm_vin.party_cd%TYPE;
    lv_part_grp   am_list_range.list_grp_code%TYPE;

    ln_cnt            NUMBER;
    ln_srl            NUMBER;
    ln_rate           NUMBER(12,2) := 0;
    ln_frt            NUMBER(12,2) := 0;
    ln_basic          NUMBER(12,2) := 0;
    ln_disc           NUMBER(12,2) := 0;
    ln_tot            NUMBER(12,2) := 0;
    ln_labor_disc_per NUMBER(5,2)  := 0;
    ln_part_disc_per  NUMBER(5,2)  := 0;
    ln_cons_disc_per  NUMBER(5,2)  := 0;
    ln_sub_srv        NUMBER;
    lv_sub_srv        VARCHAR2(5);
    lv_smp_srv        VARCHAR2(5);
    lv_cds_cvm        VARCHAR2(5);
    lv_disc_chk       VARCHAR2(1) := 'N';

    -- Added by Rajeev on 13-APR-2026
    lv_vin               gm_vin.vin%TYPE;
    ld_fcok_date         DATE;
    ld_coolant_stdt      DATE;
    lv_old_coolant_flag  VARCHAR2(1);
    lv_coolant_flag      VARCHAR2(1);
  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;
    ln_cnt    := 0;
    ln_srl    := 0;

    -- City RPH
    BEGIN
      SELECT m.city_rph_type, l.channel
        INTO lv_city_rph, lv_channel
        FROM am_dealer_loc l, gm_for m
       WHERE l.parent_group = p_parent
         AND l.dealer_map_cd = p_dealer
         AND l.loc_cd = p_loc
         AND m.principal_map_cd = p_pmc
         AND m.for_cd = l.for_cd;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END;
    IF lv_city_rph IS NULL THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END IF;

    -- Vehicle Details
    BEGIN
      SELECT vin, model_cd, svar_cd, variant_cd, party_cd
        INTO lv_vin, lv_model, lv_svar, lv_variant, lv_party_cd
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'VIN not found';
      RETURN;
    END;

    -- Added by Rajeev on 13-APR-2026
    BEGIN
      BEGIN
        SELECT TO_DATE(v.fcok_date, 'DD-MON-RRRR'),
               NVL(v.old_coolant_flag, 'X')
          INTO ld_fcok_date, lv_old_coolant_flag
          FROM gm_vin_ext V
         WHERE v.vin = lv_vin;
      EXCEPTION WHEN OTHERS THEN
          ld_fcok_date        := NULL;
          lv_old_coolant_flag := 'N';
      END;

      BEGIN
        SELECT TO_DATE(list_desc, 'DD-MON-RRRR')
          INTO ld_coolant_stdt
          FROM am_list
         WHERE list_name = 'BLUE_COOLANT_DT'
           AND principal_map_cd = p_pmc;
      EXCEPTION WHEN OTHERS THEN
          ld_coolant_stdt := NULL;
      END;

      IF lv_old_coolant_flag = 'Y' THEN
        lv_coolant_flag := 'O';
      ELSIF ld_fcok_date > ld_coolant_stdt THEN
        lv_coolant_flag := 'N';
      ELSE
        lv_coolant_flag := 'O';
      END IF;
      --DBMS_OUTPUT.PUT_LINE(lv_coolant_flag||' - '||ld_fcok_date||' - '||ld_coolant_stdt);
    END;

    -- Discount Check
    BEGIN
      SELECT 'Y' INTO lv_disc_chk
        FROM vm_smp_disc
       WHERE principal_map_cd = p_pmc
         AND rcateg_cd = p_pkg_type
         AND smp_type = p_pkg_code
         AND variant = lv_variant
         AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
         AND ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
      lv_disc_chk := 'N';
    END;

    IF NVL(lv_disc_chk,'N') = 'N' THEN
       p_err_cd  := 1;
       p_err_msg := 'SMP package not defined for Specific Vehicle Model';
       RETURN;
    ELSE
      BEGIN
         SELECT MAX(lbr_disc), MAX(part_disc), MAX(cons_disc)
           INTO ln_labor_disc_per, ln_part_disc_per, ln_cons_disc_per
           FROM ( SELECT offer_catg_type,
                         CASE WHEN offer_catg_type = 'L' THEN
                           disc_value
                         ELSE
                           0
                         END lbr_disc,
                         CASE WHEN offer_catg_type = 'P' THEN
                           disc_value
                         ELSE
                           0
                         END part_disc,
                         CASE WHEN offer_catg_type = 'C' THEN
                           disc_value
                         ELSE
                           0
                         END cons_disc
                    FROM vm_smp_disc
                   WHERE principal_map_cd = p_pmc
                     AND rcateg_cd = p_pkg_type
                     AND smp_type = p_pkg_code
                     AND variant = lv_variant
                     AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
                    );
      EXCEPTION WHEN OTHERS THEN
        ln_labor_disc_per := 0;
        ln_part_disc_per  := 0;
        ln_cons_disc_per  := 0;
      END;
    END IF;

    -- Delete from temp table
    DELETE FROM gbl_smp
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_type = p_pkg_type
       AND pkg_code = p_pkg_code
       AND addon_type IS NULL;

    DELETE FROM gbl_amc_dtl
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code
       --AND addon_type IS NULL
       ;
    COMMIT;

    -- Insert into SMP Def. Table
    IF p_pkg_type = 'PMS' THEN
      IF p_sub_srv = 'FR3' THEN
        ln_sub_srv := 1;
      ELSE
        ln_sub_srv := SUBSTR(p_sub_srv,4);
      END IF;
      lv_sub_srv := p_pkg_type;
      lv_smp_srv  := p_sub_srv;
      FOR j IN 1..p_srv_no LOOP
        --lv_smp_srv  := lv_sub_srv||ln_sub_srv;
        ln_cnt := 0;
        FOR cur_m IN (SELECT ROWNUM srl_num, srv_type, srv_cd, srv_desc, srv_qty
                        FROM (SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           AND ROWNUM = 1
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = lv_svar
                                 AND m.variant_cd = lv_variant
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND ((lv_smp_srv IN ('FR','FR3','FR4') AND m.srv_type = 'P') OR (lv_smp_srv != 'FR3' AND m.srv_type IN ('P', 'L')))
                                 AND m.srv_cd <> (CASE WHEN lv_coolant_flag = 'N' THEN
                                                         'ZP016'
                                                         ELSE
                                                          'ZP01P'
                                                       END) -- Added by Rajeev on 13-APR-2026
                                 AND m.sub_srv_cd = lv_smp_srv
                               ORDER by 1,2 DESC,3
                             )
                         )
         LOOP
           ln_cnt := NVL(ln_cnt,0) + 1;
           UPDATE gbl_smp
              SET srv_qty = NVL(srv_qty,0) + NVL(cur_m.srv_qty,0),
                  to_subtype = lv_smp_srv
            WHERE parent_group = p_parent
              AND dealer_map_cd = p_dealer
              AND loc_cd = p_loc
              AND comp_fa = p_comp
              AND reg_num = p_reg_num
              AND pkg_type = p_pkg_type
              AND pkg_code = p_pkg_code
              AND srv_type = cur_m.srv_type
              AND srv_cd = cur_m.srv_cd;

           IF SQL%NOTFOUND THEN
             BEGIN
               INSERT INTO gbl_smp (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_type,
                                    from_subtype,
                                    no_of_srv,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    srv_qty,
                                    discount_per
                                    )
                         VALUES   (p_parent,
                                   p_dealer,
                                   p_loc,
                                   p_comp,
                                   p_reg_num,
                                   p_pkg_type,
                                   lv_smp_srv,
                                   p_srv_no,
                                   p_pkg_code,
                                   cur_m.srl_num,
                                   cur_m.srv_type,
                                   cur_m.srv_cd,
                                   cur_m.srv_desc,
                                   cur_m.srv_qty,
                                   CASE WHEN cur_m.srv_type = 'L' THEN
                                      ln_labor_disc_per
                                    WHEN cur_m.srv_type = 'P' THEN
                                      ln_part_disc_per
                                    WHEN cur_m.srv_type = 'C' THEN
                                      ln_cons_disc_per
                                    ELSE
                                      0
                                    END
                                   );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;
           END IF;
        END LOOP;
        ln_sub_srv := ln_sub_srv + 1;
        lv_smp_srv  := lv_sub_srv||ln_sub_srv;

        IF NVL(ln_cnt, 0) = 0 THEN
          p_err_cd  := 1;
          p_err_msg := lv_smp_srv||' Service Menu Code not defined for Specific Service Model';
          RETURN;
        END IF;
      END LOOP;
    ELSIF p_pkg_type IN ('CDS', 'CVMS') THEN
      IF p_sub_srv = 'FR3' THEN
        ln_sub_srv := 1;
      ELSE
        ln_sub_srv := SUBSTR(p_sub_srv,4);
      END IF;
      --ln_sub_srv := SUBSTR(p_sub_srv,4);
      FOR j IN 1..p_srv_no LOOP
        IF ln_sub_srv = 1 THEN
          lv_smp_srv := 'FR3';
          lv_cds_cvm := 'FR3';
        ELSE
          lv_smp_srv := 'PMS'||ln_sub_srv;
          lv_cds_cvm := SUBSTR(p_pkg_type,1,3)||ln_sub_srv;
        END IF;

        ln_cnt := 0;
        FOR cur_m IN (SELECT ROWNUM srl_num, srv_type, srv_cd, srv_desc, srv_qty
                        FROM (SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = lv_svar
                                 AND m.variant_cd = lv_variant
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND m.srv_type = 'P'
                                 --AND m.sub_srv_cd = 'PMS'||ln_sub_srv
                                 AND m.sub_srv_cd = lv_smp_srv -- Changed by Rajeev on 28-APR-2026
                                 AND m.srv_cd IN (SELECT l.list_code
                                                    FROM am_list_range l
                                                   WHERE l.principal_map_cd = p_pmc
                                                     AND l.list_name = 'CDS_CVMS_PGROUP'
                                                     AND l.list_flag = 'Y'
                                                     AND NVL(close_date, SYSDATE) >= SYSDATE
                                                     )
                                 AND m.srv_cd <> (CASE WHEN lv_coolant_flag = 'N' THEN
                                                         'ZP016'
                                                         ELSE
                                                          'ZP01P'
                                                       END)
                              UNION ALL
                              SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             --AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = 'SVAR'
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND m.srv_type = 'L'
                                 AND m.sub_srv_cd = p_pkg_type
                                 AND lv_smp_srv != 'FR3'  -- Added by Rajeev on 28-APR-2026
                               ORDER by 1,2 DESC,3
                             )
                         )
         LOOP
           ln_cnt := NVL(ln_cnt,0) + 1;
           UPDATE gbl_smp
              SET srv_qty = NVL(srv_qty,0) + NVL(cur_m.srv_qty,0),
                  to_subtype = lv_cds_cvm
            WHERE parent_group = p_parent
              AND dealer_map_cd = p_dealer
              AND loc_cd = p_loc
              AND comp_fa = p_comp
              AND reg_num = p_reg_num
              AND pkg_type = p_pkg_type
              AND pkg_code = p_pkg_code
              AND srv_type = cur_m.srv_type
              AND srv_cd = cur_m.srv_cd;

           IF SQL%NOTFOUND THEN
             BEGIN
               INSERT INTO gbl_smp (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_type,
                                    from_subtype,
                                    no_of_srv,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    srv_qty,
                                    discount_per
                                    )
                         VALUES   (p_parent,
                                   p_dealer,
                                   p_loc,
                                   p_comp,
                                   p_reg_num,
                                   p_pkg_type,
                                   lv_cds_cvm, --lv_smp_srv,
                                   p_srv_no,
                                   p_pkg_code,
                                   cur_m.srl_num,
                                   cur_m.srv_type,
                                   cur_m.srv_cd,
                                   cur_m.srv_desc,
                                   cur_m.srv_qty,
                                   CASE WHEN cur_m.srv_type = 'L' THEN
                                      ln_labor_disc_per
                                    WHEN cur_m.srv_type = 'P' THEN
                                      ln_part_disc_per
                                    WHEN cur_m.srv_type = 'C' THEN
                                      ln_cons_disc_per
                                    ELSE
                                      0
                                    END
                                   );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;
           END IF;
        END LOOP;
        ln_sub_srv := ln_sub_srv + 1;

        IF NVL(ln_cnt, 0) = 0 THEN
          p_err_cd  := 1;
          p_err_msg := lv_smp_srv||' Service Menu Code not defined for Specific Service Model';
          RETURN;
        END IF;
      END LOOP;
    END IF; -- Service Type

    -- Insert into Details Table
    IF p_err_cd = 0 THEN
      FOR cur_d IN (SELECT  DECODE(x.addon_type, 'CL', 5, 'BR', 6, DECODE(x.srv_type, 'L',1,'P',2,'C',3,4)) ord_srl, x.*
                      FROM gbl_smp x
                     WHERE parent_group = p_parent
                       AND dealer_map_cd = p_dealer
                       AND loc_cd = p_loc
                       AND comp_fa = p_comp
                       AND reg_num = p_reg_num
                       AND pkg_type = p_pkg_type
                       AND pkg_code = p_pkg_code
                      ORDER BY 1, srl_num
                     )
      LOOP
        ln_rate     := 0;
        ln_frt      := 0;
        lv_hsn_sac  := NULL;
        lv_part_num := NULL;
        lv_part_grp := NULL;
        ln_srl      := NVL(ln_srl, 0) + 1;

        IF cur_d.srv_type = 'L' THEN
          -- Labour SAC
          BEGIN
            SELECT NVL(L.sac_code, '998729'), l.flat_amt, l.flat_rate_hrs
              INTO lv_hsn_sac, ln_rate, ln_frt
              FROM vm_dlr_lts l
             WHERE l.dealer_map_cd = p_dealer
               AND l.loc_cd = p_loc
               AND l.svar_cd = lv_svar
               AND l.opr_cd = cur_d.srv_cd;
          EXCEPTION WHEN OTHERS THEN
             NULL;
          END;

          IF NVL(ln_rate,0) = 0 THEN
            BEGIN
              SELECT NVL(l.rate_per_hour,0) * NVL(ln_frt,0)
                INTO ln_rate
                FROM vm_rcateg l
               WHERE l.dealer_map_cd = p_dealer
                 AND l.loc_cd = p_loc
                 AND l.svar_cd = lv_svar
                 AND l.rcateg_cd = 'PMS';
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
          END IF;

          IF NVL(ln_rate,0) = 0 THEN
            BEGIN
              SELECT NVL(sac_code, '998729')
                INTO lv_hsn_sac
                FROM vm_msil_opr l
               WHERE l.principal_map_cd = p_pmc
                 AND l.dealer_type = 'D'
                 AND l.svar_cd = lv_svar
                 AND l.opr_cd = cur_d.srv_cd;
            EXCEPTION WHEN OTHERS THEN
               lv_hsn_sac  := NULL;
            END;

            BEGIN
              SELECT m.opr_amt
                INTO ln_rate
                FROM vm_opr_amt m
               WHERE m.principal_map_cd = p_pmc
                 AND m.opr_cd = cur_d.srv_cd
                 AND m.svar_cd = lv_svar
                 AND m.city_rph_type = lv_city_rph
                 AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE));
            EXCEPTION WHEN OTHERS THEN
               ln_rate := 0;
            END;

            IF NVL(ln_rate,0) = 0 THEN
              BEGIN
                SELECT NVL(m.frt, 0) * NVL(x.rph, 0) opr_amt
                  INTO ln_rate
                  FROM vm_opr_amt m, vm_msil_rph_svar x
                 WHERE m.principal_map_cd = p_pmc
                   AND m.opr_cd = cur_d.srv_cd
                   AND m.svar_cd = lv_svar
                   AND m.city_rph_type = lv_city_rph
                   AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE))
                   AND x.principal_map_cd = m.principal_map_cd
                   AND x.city_rph_type = m.city_rph_type
                   AND x.svar_cd = m.svar_cd
                   AND x.rph_type = 'D'
                   AND x.channel = lv_channel;
              EXCEPTION WHEN OTHERS THEN
                 ln_rate := 0;
              END;
            END IF;
          END IF;
        ELSE -- Parts / Cons
          IF cur_d.addon_type IS NULL THEN
            BEGIN
              SELECT list_grp_code INTO lv_part_grp
                FROM am_list_range
               WHERE principal_map_Cd = 1
                 AND list_name = 'SMP_PARTGROUP'
                 AND list_code = cur_d.srv_cd;
            EXCEPTION WHEN OTHERS THEN
              lv_part_grp := NULL;
            END;

            IF lv_part_grp = 'ENGOIL' AND NVL(p_engine,'NA') != 'NA' THEN
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.part_num = p_engine
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;
            ELSIF lv_part_grp = 'COOLANT' AND NVL(p_coolant,'NA') != 'NA' THEN
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.part_num = p_coolant
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;
            ELSE
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                           AND EXISTS (SELECT 1 FROM dmsd_epc_dms_part_mapping ep
                                        WHERE ep.variant_cd = m.variant_cd
                                          AND ep.part_num = m.part_num
                                        )
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                lv_part_num := NULL;
              END;

              IF lv_part_num IS NULL THEN
                BEGIN
                  SELECT part_num, mrp
                    INTO lv_part_num, ln_rate
                    FROM (SELECT m.part_num,
                                 (SELECT MAX(d.mrp)
                                    FROM pi_pm_part_mrp d
                                   WHERE d.principal_map_cd = p_pmc
                                     AND d.part_num = m.part_num
                                     ) mrp
                            FROM vm_menu_cd m
                           WHERE m.principal_map_cd = p_pmc
                             AND m.svar_mod_cd = lv_svar
                             AND m.variant_cd = lv_variant
                             AND m.active_yn = 'Y'
                             AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                             AND m.srv_type = 'P'
                             AND m.srv_cd = cur_d.srv_cd
                             AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                           ORDER BY 2
                             )
                   WHERE mrp IS NOT NULL
                     AND ROWNUM = 1;
                EXCEPTION WHEN OTHERS THEN
                  NULL;
                END;
              END IF;

            END IF; -- Part Details
          ELSE -- Addon parts
            BEGIN
              SELECT part_num, mrp
                INTO lv_part_num, ln_rate
                FROM (SELECT m.part_num,
                             (SELECT MAX(d.mrp)
                                FROM pi_pm_part_mrp d
                               WHERE d.principal_map_cd = p_pmc
                                 AND d.part_num = m.part_num
                                 ) mrp
                        FROM vm_menu_cd m
                       WHERE m.principal_map_cd = p_pmc
                         AND m.svar_mod_cd = 'ADDON'
                         AND m.active_yn = 'Y'
                         AND m.sub_srv_cd = cur_d.addon_type
                         AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                         AND m.srv_type = 'P'
                         AND m.srv_cd = cur_d.srv_cd
                         AND EXISTS (SELECT 1 FROM dmsd_epc_dms_part_mapping ep
                                      WHERE ep.variant_cd = lv_variant
                                        AND ep.part_num = m.part_num
                                      )
                       ORDER BY 2 DESC
                         )
               WHERE mrp IS NOT NULL
                 AND ROWNUM = 1;
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
            --dbms_output.put_line('Part '||cur_d.srv_cd ||' - '||cur_d.addon_type||' - '||lv_part_num|| ' - '||ln_rate);
          END IF;

          -- Part Details
          BEGIN
            SELECT NVL(hs_code, '8708'), part_desc
              INTO lv_hsn_sac, lv_part_desc
              FROM pm_part
             WHERE part_num = lv_part_num
               AND principal_map_cd = p_pmc
               AND dealer_map_cd = p_pmc;
          EXCEPTION WHEN OTHERS THEN
             lv_hsn_sac   := NULL;
             lv_part_desc := NULL;
          END;
        END IF;

        IF  NVL(ln_rate, 0) > 0 THEN
          ln_basic := NVL(cur_d.srv_qty, 0) * NVL(ln_rate, 0);
          ln_disc  := NVL(ln_basic, 0) * NVL(cur_d.discount_per, 0) / 100;
          ln_tot   := NVL(ln_basic, 0) - NVL(ln_disc, 0);
          BEGIN
           INSERT INTO gbl_amc_dtl (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    group_cd,
                                    group_desc,
                                    qty,
                                    discount_per,
                                    catg_cd,
                                    catg_desc,
                                    hsn_sac_cd,
                                    rate,
                                    basic_value,
                                    discount_amt,
                                    tot_value,
                                    gst_type,
                                    sell_price,
                                    addon_type
                                    )
                        VALUES     (cur_d.parent_group,
                                    cur_d.dealer_map_cd,
                                    cur_d.loc_cd,
                                    cur_d.comp_fa,
                                    cur_d.reg_num,
                                    cur_d.pkg_code,
                                    ln_srl,
                                    cur_d.srv_type,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_cd
                                    ELSE
                                      lv_part_num
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_desc
                                    ELSE
                                      lv_part_desc
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_cd
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_desc
                                    END,
                                    cur_d.srv_qty,
                                    cur_d.discount_per,

                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      'G'
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      (SELECT list_desc
                                         FROM am_list_range
                                        WHERE principal_map_cd = p_pmc
                                          AND list_name = 'AMC_CATG_TYPE'
                                          AND list_code = 'G')
                                    END,
                                    lv_hsn_sac,
                                    ln_rate,
                                    ln_basic,
                                    ln_disc,
                                    ln_tot,
                                    p_gst_type,
                                    ln_basic,
                                    cur_d.addon_type
                                    );
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
        END IF;
      END LOOP;

      DELETE FROM gbl_amc_dtl x
       WHERE x.srv_type = 'L'
         AND x.parent_group = p_parent
         AND x.dealer_map_cd = p_dealer
         AND x.loc_cd = p_loc
         AND x.comp_fa = p_comp
         AND x.reg_num = p_reg_num
         AND x.pkg_code = p_pkg_code
         AND x.addon_type = 'RB'
         AND x.srv_cd NOT IN (SELECT l.list_desc
                                FROM gbl_amc_dtl d, am_list_range l
                               WHERE d.srv_type = 'P'
                                 AND d.parent_group = p_parent
                                 AND d.dealer_map_cd = p_dealer
                                 AND d.loc_cd = p_loc
                                 AND d.comp_fa = p_comp
                                 AND d.reg_num = p_reg_num
                                 AND d.pkg_code = p_pkg_code
                                 AND d.addon_type = 'RB'
                                 AND l.principal_map_cd = p_pmc
                                 AND l.list_name = 'ADDON_LBR'
                                 AND l.list_grp_code = d.addon_type
                                 AND d.group_cd = l.list_code
                                 );
    END IF;
    COMMIT;
  END SP_POP_SMP_PKG;
```

#### SP-025 - PKG_SMP.SP_POP_SMP_PKG_TV

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SMP Package Details (N/A / CN_MAIN)

---

**Purpose**

Populates the SMP package detail working tables (GBL_SMP and GBL_AMC_DTL) for a specific vehicle and package selection on the SMP Package Details screen. Given a registration number, package type (PMS, CDS, or CVMS), package code, service television type, and supporting vehicle attributes, the procedure validates dealer city classification, vehicle master data, and active discount definitions, then builds a line-by-line service menu (labour, parts, and consumables) with applicable rates, discount percentages, and calculated values ready for downstream enquiry and booking.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp | VARCHAR2 | IN |
| p_pkg_type | VARCHAR2 | IN |
| p_pkg_code | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_tv_srv | VARCHAR2 | IN |
| p_fsub_srv | VARCHAR2 | IN |
| p_srv_no | NUMBER | IN |
| p_gst_type | VARCHAR2 | IN |
| p_engine | VARCHAR2 | IN |
| p_coolant | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output parameters (p_err_cd = 0, p_err_msg = NULL) and working counters.
- Step 2 - Retrieve the dealer location's city RPH type and channel from AM_DEALER_LOC joined to GM_FOR using the principal map code, parent group, dealer, and location. If the query fails or returns a NULL city type, set p_err_cd = 1 with message 'City type not defined for dealer' and exit.
- Step 3 - Retrieve vehicle master data (VIN, model code, SVAR code, variant code, party code) from GM_VIN using the registration number. If not found, set p_err_cd = 1 with message 'VIN not found' and exit.
- Step 4 - Retrieve the vehicle's FCOK date and old-coolant flag from GM_VIN_EXT using the VIN. If unavailable, default FCOK date to NULL and old-coolant flag to 'N'.
- Step 5 - Retrieve the blue-coolant start date from AM_LIST for list name 'BLUE_COOLANT_DT' and the current principal. If unavailable, default to NULL.
- Step 6 - Derive the coolant flag: set to 'O' if old_coolant_flag = 'Y'; set to 'N' if FCOK date is after the blue-coolant start date; otherwise set to 'O'. This flag controls which coolant part code is excluded from service menu queries.
- Step 7 - Check VM_SMP_DISC for an active discount record matching the principal, package type, package code, vehicle variant, and current date. If none found, set lv_disc_chk = 'N'; otherwise set lv_disc_chk = 'Y'.
- Step 8 - If lv_disc_chk = 'N', set p_err_cd = 1 with message 'SMP package not defined for Specific Vehicle Model' and exit.
- Step 9 - If lv_disc_chk = 'Y', aggregate the maximum labour (L), part (P), and consumable (C) discount percentages from VM_SMP_DISC for the same filter criteria.
- Step 10 - Delete existing GBL_SMP rows (excluding add-on types) and all GBL_AMC_DTL rows for the same dealer/location/vehicle/package combination, then COMMIT.
- Step 11 - Branch on p_pkg_type:
  - PMS branch: derive the service sub-type code (lv_smp_srv) from p_tv_srv and p_fsub_srv. For each service number in 1..p_srv_no, query VM_MENU_CD (joined with AM_LIST_RANGE and VM_MSIL_OPR for descriptions) for active, variant-matched menu items, excluding the coolant part code that does not apply. For labour items, all service types are included unless the service is FR/FR3/FR4 (parts only). For each menu row, attempt UPDATE on GBL_SMP; if no row is updated, INSERT a new GBL_SMP row with the applicable discount percentage by service type. Increment the sub-service counter and advance lv_smp_srv for the next iteration. If no menu rows are found for an iteration, set p_err_cd = 1 with a descriptive message and exit.
  - CDS/CVMS branch: if p_tv_srv = 'TV3', initialise lv_smp_srv = 'FR3' and lv_cds_cvm = 'TV3'; otherwise derive from p_fsub_srv. For each service number, query VM_MENU_CD for parts from the CDS_CVMS_PGROUP list (UNION ALL with labour items from the generic SVAR menu when not FR3). Apply the same upsert logic into GBL_SMP with the CDS/CVM sub-type label. After the first iteration, reset the sub-service counter from p_fsub_srv and advance lv_smp_srv and lv_cds_cvm accordingly. If no rows are found, set p_err_cd = 1 and exit.
- Step 12 - If p_err_cd = 0, iterate over all GBL_SMP rows for the package (ordered by service type priority then serial number) to populate GBL_AMC_DTL:
  - For labour items: look up the flat amount and flat rate hours from VM_DLR_LTS. If rate is zero, calculate rate as rate-per-hour × flat rate hours from VM_RCATEG. If still zero, retrieve the operation amount from VM_OPR_AMT; if still zero, compute rate as FRT × RPH from VM_OPR_AMT joined to VM_MSIL_RPH_SVAR using the channel and city RPH type. Retrieve the SAC code from VM_DLR_LTS or VM_MSIL_OPR.
  - For part/consumable items without an add-on type: determine the part group from AM_LIST_RANGE (SMP_PARTGROUP). If the group is ENGOIL and a specific engine part number is supplied (p_engine), select the matching part number and MRP from VM_MENU_CD joined to PI_PM_PART_MRP. If the group is COOLANT and a coolant part number is supplied (p_coolant), apply the same logic. Otherwise, select the part number and MRP preferring records with a matching DMSD_EPC_DMS_PART_MAPPING entry; if none found, fall back to any matching VM_MENU_CD row. Retrieve the HSN code and part description from PM_PART.
  - For add-on parts: select the part number and MRP from VM_MENU_CD using SVAR_MOD_CD = 'ADDON', filtered by the add-on type and a DMSD_EPC_DMS_PART_MAPPING match.
  - If the resolved rate is greater than zero, compute basic value (qty × rate), discount amount (basic × discount%), and total value (basic - discount), then INSERT into GBL_AMC_DTL with all pricing, HSN/SAC, GST type, and add-on type attributes.
- Step 13 - After the detail loop, delete from GBL_AMC_DTL any labour rows of add-on type 'RB' whose operation code does not correspond to a part in the same package that maps to an ADDON_LBR list entry, ensuring orphaned add-on labour lines are removed.
- Step 14 - COMMIT all changes.

---
**Decision Points**

DP-001

Condition:
City RPH type retrieved from AM_DEALER_LOC/GM_FOR is NULL or the query raises an exception.

TRUE:
Set p_err_cd = 1, p_err_msg = 'City type not defined for dealer', and exit the procedure.

FALSE:
Continue to vehicle master data retrieval.

---

DP-002

Condition:
GM_VIN record for p_reg_num is not found (exception raised).

TRUE:
Set p_err_cd = 1, p_err_msg = 'VIN not found', and exit the procedure.

FALSE:
Continue to VIN extension and coolant flag derivation.

---

DP-003

Condition:
lv_old_coolant_flag = 'Y' (vehicle is flagged as having old-type coolant).

TRUE:
Set lv_coolant_flag = 'O' (old coolant).

FALSE:
Evaluate DP-004.

---

DP-004

Condition:
FCOK date of the vehicle is later than the blue-coolant start date from AM_LIST.

TRUE:
Set lv_coolant_flag = 'N' (new/blue coolant); part code ZP016 is excluded from service menu queries.

FALSE:
Set lv_coolant_flag = 'O' (old coolant); part code ZP01P is excluded from service menu queries.

---

DP-005

Condition:
An active VM_SMP_DISC record exists for the principal, package type, package code, vehicle variant, and current date (lv_disc_chk = 'Y').

TRUE:
Aggregate labour, part, and consumable discount percentages from VM_SMP_DISC and proceed to build the service menu.

FALSE:
Set p_err_cd = 1, p_err_msg = 'SMP package not defined for Specific Vehicle Model', and exit.

---

DP-006

Condition:
p_pkg_type = 'PMS'.

TRUE:
Execute PMS service menu population logic using VM_MENU_CD with labour and parts (except for FR/FR3/FR4 sub-types where only parts are included).

FALSE:
Evaluate DP-007.

---

DP-007

Condition:
p_pkg_type IN ('CDS', 'CVMS').

TRUE:
Execute CDS/CVMS service menu population logic using a UNION of CDS_CVMS_PGROUP parts and generic SVAR labour items.

FALSE:
No service menu population is performed for this package type.

---

DP-008

Condition:
p_tv_srv = 'TV3' (third service television type) within either the PMS or CDS/CVMS branch.

TRUE:
Set lv_smp_srv = 'FR3' (and lv_cds_cvm = 'TV3' for CDS/CVMS); the first service iteration uses the free-service 3 menu.

FALSE:
Derive lv_smp_srv directly from p_fsub_srv.

---

DP-009

Condition:
For a given service iteration, the VM_MENU_CD cursor returns zero rows (ln_cnt = 0).

TRUE:
Set p_err_cd = 1, p_err_msg = '<lv_smp_srv> Service Menu Code not defined for Specific Service Model', and exit.

FALSE:
Continue to the next service iteration or proceed to detail population.

---

DP-010

Condition:
A GBL_SMP row already exists for the same dealer/location/vehicle/package/service type/service code combination (SQL%NOTFOUND is FALSE after UPDATE).

TRUE:
Increment srv_qty on the existing GBL_SMP row and update to_subtype.

FALSE:
Insert a new GBL_SMP row with full attributes and the applicable discount percentage.

---

DP-011

Condition:
p_err_cd = 0 after all service menu iterations complete.

TRUE:
Proceed to populate GBL_AMC_DTL from GBL_SMP rows.

FALSE:
Skip detail population; procedure exits after the final COMMIT.

---

DP-012

Condition:
GBL_SMP row being processed has srv_type = 'L' (labour).

TRUE:
Resolve rate via VM_DLR_LTS flat amount; if zero, via VM_RCATEG rate-per-hour; if still zero, via VM_OPR_AMT direct amount; if still zero, via VM_OPR_AMT FRT × VM_MSIL_RPH_SVAR RPH.

FALSE:
Resolve part number and MRP via the parts/consumables logic (DP-013 onwards).

---

DP-013

Condition:
GBL_SMP row has no add-on type (addon_type IS NULL) and srv_type is part or consumable.

TRUE:
Look up the part group from AM_LIST_RANGE (SMP_PARTGROUP) and apply engine-oil, coolant, or general part resolution logic (DP-014, DP-015, DP-016).

FALSE:
Resolve part number and MRP from VM_MENU_CD using SVAR_MOD_CD = 'ADDON' filtered by add-on type and DMSD_EPC_DMS_PART_MAPPING.

---

DP-014

Condition:
Part group is 'ENGOIL' AND p_engine is not 'NA' or NULL.

TRUE:
Select part number and MRP from VM_MENU_CD where part_num = p_engine.

FALSE:
Evaluate DP-015.

---

DP-015

Condition:
Part group is 'COOLANT' AND p_coolant is not 'NA' or NULL.

TRUE:
Select part number and MRP from VM_MENU_CD where part_num = p_coolant.

FALSE:
Evaluate DP-016.

---

DP-016

Condition:
A matching VM_MENU_CD part row exists with a corresponding DMSD_EPC_DMS_PART_MAPPING entry.

TRUE:
Use that part number and MRP.

FALSE:
Fall back to any matching VM_MENU_CD row without the DMSD_EPC_DMS_PART_MAPPING filter.

---

DP-017

Condition:
Resolved rate (ln_rate) > 0 for the current GBL_SMP detail row.

TRUE:
Calculate basic value, discount amount, and total value, then insert a row into GBL_AMC_DTL.

FALSE:
Skip the GBL_AMC_DTL insert for this row; no zero-value lines are written.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-003 - Read GM_VIN_EXT - Reads data from GM_VIN_EXT for lookup or validation.
- DB-004 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-005 - Read VM_SMP_DISC - Reads data from VM_SMP_DISC for lookup or validation.
- DB-006 - Delete from TEMP - Deletes rows from TEMP.
- DB-007 - Delete from GBL_SMP - Deletes rows from GBL_SMP.
- DB-008 - Delete from GBL_AMC_DTL - Deletes rows from GBL_AMC_DTL.
- DB-009 - Insert into SMP - Persists a new row into SMP.
- DB-010 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-011 - Read VM_MSIL_OPR - Reads data from VM_MSIL_OPR for lookup or validation.
- DB-012 - Update GBL_SMP - Updates existing rows in GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s)).
- DB-013 - Insert into GBL_SMP - Persists a new row into GBL_SMP using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s).
- DB-014 - Insert into SMP_PARAM - Persists a new row into SMP_PARAM.
- DB-015 - Insert into DETAILS - Persists a new row into DETAILS.
- DB-016 - Read GBL_SMP - Reads data from GBL_SMP (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg type, from subtype, no of srv, and 8 more column(s)) for lookup or validation.
- DB-017 - Read VM_DLR_LTS - Reads data from VM_DLR_LTS for lookup or validation.
- DB-018 - Read VM_RCATEG - Reads data from VM_RCATEG for lookup or validation.
- DB-019 - Read VM_OPR_AMT - Reads data from VM_OPR_AMT for lookup or validation.
- DB-020 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP for lookup or validation.
- DB-021 - Read DMSD_EPC_DMS_PART_MAPPING - Reads data from DMSD_EPC_DMS_PART_MAPPING for lookup or validation.
- DB-022 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-023 - Insert into GBL_AMC_DTL - Persists a new row into GBL_AMC_DTL using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s).
- DB-024 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL (columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 16 more column(s)) for lookup or validation.
**Business Rules**

- BR-001 - A valid city RPH type must be configured for the dealer location before any SMP package can be populated; absence of this configuration is a hard stop.
- BR-002 - The vehicle registration number must exist in GM_VIN; an unresolvable registration is a hard stop.
- BR-003 - The coolant part included in the service menu is determined by the vehicle's FCOK date relative to the blue-coolant introduction date (AM_LIST, 'BLUE_COOLANT_DT'): vehicles with FCOK after that date use the new blue-coolant part (ZP01P included, ZP016 excluded); all others use the old-type part (ZP016 included, ZP01P excluded). A vehicle explicitly flagged old_coolant_flag = 'Y' always uses the old-type part regardless of FCOK date.
- BR-004 - An active discount definition in VM_SMP_DISC must exist for the combination of principal, package type, package code, vehicle variant, and current date before any service menu lines are generated; absence is a hard stop with the message 'SMP package not defined for Specific Vehicle Model'.
- BR-005 - Discount percentages are sourced separately for labour (offer_catg_type = 'L'), parts (offer_catg_type = 'P'), and consumables (offer_catg_type = 'C') from VM_SMP_DISC and applied per line in GBL_SMP and GBL_AMC_DTL.
- BR-006 - Existing GBL_SMP rows (non-add-on) and all GBL_AMC_DTL rows for the package are deleted before re-population, ensuring the working tables always reflect the latest package configuration.
- BR-007 - For PMS packages, FR/FR3/FR4 sub-service types include only parts (srv_type = 'P'); all other PMS sub-service types include both parts and labour.
- BR-008 - For CDS/CVMS packages, only parts belonging to the active CDS_CVMS_PGROUP list are included; labour is sourced from the generic SVAR menu and is excluded when the current sub-service is FR3.
- BR-009 - If a service iteration produces zero menu rows, the procedure aborts with an error identifying the missing menu code, preventing partial or empty package definitions.
- BR-010 - GBL_SMP population uses an upsert pattern: if a row for the same service code and type already exists, its quantity is incremented; otherwise a new row is inserted.
- BR-011 - Labour rates are resolved in priority order: (1) flat amount from VM_DLR_LTS, (2) rate-per-hour × flat rate hours from VM_RCATEG, (3) direct operation amount from VM_OPR_AMT, (4) FRT × dealer RPH from VM_OPR_AMT joined to VM_MSIL_RPH_SVAR using the dealer's channel and city RPH type.
- BR-012 - For engine-oil parts, if a specific engine part number is provided (p_engine ≠ 'NA'), only that part number is used for MRP lookup; similarly for coolant parts when p_coolant ≠ 'NA'.
- BR-013 - For general parts, the preferred part number is one that has a corresponding entry in DMSD_EPC_DMS_PART_MAPPING for the vehicle variant; if no such entry exists, the highest-MRP part from VM_MENU_CD is used as a fallback.
- BR-014 - Only lines with a resolved rate greater than zero are inserted into GBL_AMC_DTL; zero-rate lines are silently omitted.
- BR-015 - After GBL_AMC_DTL is populated, orphaned add-on labour rows of type 'RB' that have no corresponding part in the same package mapped through the ADDON_LBR list are deleted, maintaining referential consistency between add-on parts and their associated labour operations.
- BR-016 - The sub-service type stored in GBL_SMP (from_subtype) drives the DECODE mapping when resolving part numbers from VM_MENU_CD: 'TV3' and 'FR3' both map to sub_srv_cd 'FR3'; all other values are prefixed with 'PMS' and the numeric suffix.

---
**Implementation Logic**

```plsql
  PROCEDURE SP_POP_SMP_PKG_TV (p_pmc        NUMBER,
                               p_parent     VARCHAR2,
                               p_dealer     NUMBER,
                               p_loc        VARCHAR2,
                               p_comp       VARCHAR2,
                               p_pkg_type   VARCHAR2,
                               p_pkg_code   VARCHAR2,
                               p_reg_num    VARCHAR2,
                               p_tv_srv     VARCHAR2,
                               p_fsub_srv   VARCHAR2,
                               p_srv_no     NUMBER,
                               p_gst_type   VARCHAR2,
                               p_engine     VARCHAR2,
                               p_coolant    VARCHAR2,
                               p_err_cd     OUT NUMBER,
                               p_err_msg    OUT VARCHAR2
                               )
   IS
    lv_channel    am_dealer_loc.channel%TYPE;
    lv_city_rph   gm_for.city_rph_type%TYPE;
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_model      gm_vin.model_cd%TYPE;
    lv_variant    gm_vin.variant_cd%TYPE;
    lv_hsn_sac    vm_dlr_lts.sac_code%TYPE;
    lv_part_num   pm_part.part_num%TYPE;
    lv_part_desc  pm_part.part_desc%TYPE;
    lv_party_cd   gm_vin.party_cd%TYPE;
    lv_part_grp   am_list_range.list_grp_code%TYPE;

    ln_cnt            NUMBER;
    ln_srl            NUMBER;
    ln_rate           NUMBER(12,2) := 0;
    ln_frt            NUMBER(12,2) := 0;
    ln_basic          NUMBER(12,2) := 0;
    ln_disc           NUMBER(12,2) := 0;
    ln_tot            NUMBER(12,2) := 0;
    ln_labor_disc_per NUMBER(5,2)  := 0;
    ln_part_disc_per  NUMBER(5,2)  := 0;
    ln_cons_disc_per  NUMBER(5,2)  := 0;
    ln_sub_srv        NUMBER;
    lv_sub_srv        VARCHAR2(5);
    lv_smp_srv        VARCHAR2(5);
    lv_cds_cvm        VARCHAR2(5);
    lv_disc_chk       VARCHAR2(1) := 'N';

    lv_vin               gm_vin.vin%TYPE;
    ld_fcok_date         DATE;
    ld_coolant_stdt      DATE;
    lv_old_coolant_flag  VARCHAR2(1);
    lv_coolant_flag      VARCHAR2(1);
  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;
    ln_cnt    := 0;
    ln_srl    := 0;

    -- City RPH
    BEGIN
      SELECT m.city_rph_type, l.channel
        INTO lv_city_rph, lv_channel
        FROM am_dealer_loc l, gm_for m
       WHERE l.parent_group = p_parent
         AND l.dealer_map_cd = p_dealer
         AND l.loc_cd = p_loc
         AND m.principal_map_cd = p_pmc
         AND m.for_cd = l.for_cd;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END;
    IF lv_city_rph IS NULL THEN
      p_err_cd  := 1;
      p_err_msg := 'City type not defined for dealer';
      RETURN;
    END IF;

    -- Vehicle Details
    BEGIN
      SELECT vin, model_cd, svar_cd, variant_cd, party_cd
        INTO lv_vin, lv_model, lv_svar, lv_variant, lv_party_cd
        FROM gm_vin
       WHERE reg_num = p_reg_num;
    EXCEPTION WHEN OTHERS THEN
      p_err_cd  := 1;
      p_err_msg := 'VIN not found';
      RETURN;
    END;

    BEGIN
      BEGIN
        SELECT TO_DATE(v.fcok_date, 'DD-MON-RRRR'),
               NVL(v.old_coolant_flag, 'X')
          INTO ld_fcok_date, lv_old_coolant_flag
          FROM gm_vin_ext V
         WHERE v.vin = lv_vin;
      EXCEPTION WHEN OTHERS THEN
          ld_fcok_date        := NULL;
          lv_old_coolant_flag := 'N';
      END;

      BEGIN
        SELECT TO_DATE(list_desc, 'DD-MON-RRRR')
          INTO ld_coolant_stdt
          FROM am_list
         WHERE list_name = 'BLUE_COOLANT_DT'
           AND principal_map_cd = p_pmc;
      EXCEPTION WHEN OTHERS THEN
          ld_coolant_stdt := NULL;
      END;

      IF lv_old_coolant_flag = 'Y' THEN
        lv_coolant_flag := 'O';
      ELSIF ld_fcok_date > ld_coolant_stdt THEN
        lv_coolant_flag := 'N';
      ELSE
        lv_coolant_flag := 'O';
      END IF;
      --DBMS_OUTPUT.PUT_LINE(lv_coolant_flag||' - '||ld_fcok_date||' - '||ld_coolant_stdt);
    END;

    -- Discount Check
    BEGIN
      SELECT 'Y' INTO lv_disc_chk
        FROM vm_smp_disc
       WHERE principal_map_cd = p_pmc
         AND rcateg_cd = p_pkg_type
         AND smp_type = p_pkg_code
         AND variant = lv_variant
         AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
         AND ROWNUM = 1;
    EXCEPTION WHEN OTHERS THEN
      lv_disc_chk := 'N';
    END;

    IF NVL(lv_disc_chk,'N') = 'N' THEN
       p_err_cd  := 1;
       p_err_msg := 'SMP package not defined for Specific Vehicle Model';
       RETURN;
    ELSE
      BEGIN
         SELECT MAX(lbr_disc), MAX(part_disc), MAX(cons_disc)
           INTO ln_labor_disc_per, ln_part_disc_per, ln_cons_disc_per
           FROM ( SELECT offer_catg_type,
                         CASE WHEN offer_catg_type = 'L' THEN
                           disc_value
                         ELSE
                           0
                         END lbr_disc,
                         CASE WHEN offer_catg_type = 'P' THEN
                           disc_value
                         ELSE
                           0
                         END part_disc,
                         CASE WHEN offer_catg_type = 'C' THEN
                           disc_value
                         ELSE
                           0
                         END cons_disc
                    FROM vm_smp_disc
                   WHERE principal_map_cd = p_pmc
                     AND rcateg_cd = p_pkg_type
                     AND smp_type = p_pkg_code
                     AND variant = lv_variant
                     AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
                    );
      EXCEPTION WHEN OTHERS THEN
        ln_labor_disc_per := 0;
        ln_part_disc_per  := 0;
        ln_cons_disc_per  := 0;
      END;
    END IF;

    -- Delete from temp table
    DELETE FROM gbl_smp
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_type = p_pkg_type
       AND pkg_code = p_pkg_code
       AND addon_type IS NULL;

    DELETE FROM gbl_amc_dtl
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code;

    COMMIT;

    -- Insert into SMP Def. Table
    IF p_pkg_type = 'PMS' THEN

      IF p_tv_srv = 'TV3' THEN
        ln_sub_srv := SUBSTR(p_fsub_srv,4);
      ELSE
        ln_sub_srv := SUBSTR(p_fsub_srv,4);
      END IF;
      lv_sub_srv := p_pkg_type;
      IF p_tv_srv = 'TV3' THEN
         lv_smp_srv  := 'FR3';
      ELSE
         lv_smp_srv  := p_fsub_srv;
      END IF;

      FOR j IN 1..p_srv_no LOOP
        --lv_smp_srv  := lv_sub_srv||ln_sub_srv;
        ln_cnt := 0;
        FOR cur_m IN (SELECT ROWNUM srl_num, srv_type, srv_cd, srv_desc, srv_qty
                        FROM (SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           AND ROWNUM = 1
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = lv_svar
                                 AND m.variant_cd = lv_variant
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND ((lv_smp_srv IN ('FR','FR3','FR4') AND m.srv_type = 'P') OR (lv_smp_srv != 'FR3' AND m.srv_type IN ('P', 'L')))
                                 AND m.srv_cd <> (CASE WHEN lv_coolant_flag = 'N' THEN
                                                         'ZP016'
                                                         ELSE
                                                          'ZP01P'
                                                       END)
                                 AND m.sub_srv_cd = lv_smp_srv
                               ORDER by 1,2 DESC,3
                             )
                         )
         LOOP
           ln_cnt := NVL(ln_cnt,0) + 1;
           UPDATE gbl_smp
              SET srv_qty = NVL(srv_qty,0) + NVL(cur_m.srv_qty,0),
                  to_subtype = lv_smp_srv
            WHERE parent_group = p_parent
              AND dealer_map_cd = p_dealer
              AND loc_cd = p_loc
              AND comp_fa = p_comp
              AND reg_num = p_reg_num
              AND pkg_type = p_pkg_type
              AND pkg_code = p_pkg_code
              AND srv_type = cur_m.srv_type
              AND srv_cd = cur_m.srv_cd;

           IF SQL%NOTFOUND THEN
             BEGIN
               INSERT INTO gbl_smp (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_type,
                                    from_subtype,
                                    no_of_srv,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    srv_qty,
                                    discount_per
                                    )
                         VALUES   (p_parent,
                                   p_dealer,
                                   p_loc,
                                   p_comp,
                                   p_reg_num,
                                   p_pkg_type,
                                   lv_smp_srv,
                                   p_srv_no,
                                   p_pkg_code,
                                   cur_m.srl_num,
                                   cur_m.srv_type,
                                   cur_m.srv_cd,
                                   cur_m.srv_desc,
                                   cur_m.srv_qty,
                                   CASE WHEN cur_m.srv_type = 'L' THEN
                                      ln_labor_disc_per
                                    WHEN cur_m.srv_type = 'P' THEN
                                      ln_part_disc_per
                                    WHEN cur_m.srv_type = 'C' THEN
                                      ln_cons_disc_per
                                    ELSE
                                      0
                                    END
                                   );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;
           END IF;
        END LOOP;
        ln_sub_srv := ln_sub_srv + 1;
        lv_smp_srv  := lv_sub_srv||ln_sub_srv;

        /*INSERT INTO smp_param VALUES (p_pmc, p_parent, p_dealer, p_loc, p_comp, p_pkg_type, p_pkg_code, p_reg_num, p_tv_srv,
                                      p_fsub_srv, p_srv_no, p_gst_type, p_engine, p_coolant, ln_cnt, p_err_msg);
                                      COMMIT;*/
        IF NVL(ln_cnt, 0) = 0 THEN
          p_err_cd  := 1;
          p_err_msg := lv_smp_srv||' Service Menu Code not defined for Specific Service Model';
          RETURN;
        END IF;
      END LOOP;
    ELSIF p_pkg_type IN ('CDS', 'CVMS') THEN

      IF p_tv_srv = 'TV3' THEN
        ln_sub_srv := 1;
        lv_smp_srv := 'FR3';
        lv_cds_cvm := 'TV3';
      ELSE
        ln_sub_srv := SUBSTR(p_fsub_srv,4);
      END IF;

      --ln_sub_srv := SUBSTR(p_sub_srv,4);
      FOR j IN 1..p_srv_no LOOP
        --DBMS_OUTPUT.PUT_LINE(ln_sub_srv||' :: '||lv_smp_srv||' :: '||lv_cds_cvm);
        ln_cnt := 0;
        FOR cur_m IN (SELECT ROWNUM srl_num, srv_type, srv_cd, srv_desc, srv_qty
                        FROM (SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = lv_svar
                                 AND m.variant_cd = lv_variant
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND m.srv_type = 'P'
                                 --AND m.sub_srv_cd = 'PMS'||ln_sub_srv
                                 AND m.sub_srv_cd = lv_smp_srv
                                 AND m.srv_cd IN (SELECT l.list_code
                                                    FROM am_list_range l
                                                   WHERE l.principal_map_cd = p_pmc
                                                     AND l.list_name = 'CDS_CVMS_PGROUP'
                                                     AND l.list_flag = 'Y'
                                                     AND NVL(close_date, SYSDATE) >= SYSDATE
                                                     )
                                 AND m.srv_cd <> (CASE WHEN lv_coolant_flag = 'N' THEN
                                                         'ZP016'
                                                         ELSE
                                                          'ZP01P'
                                                       END)
                              UNION ALL
                              SELECT DISTINCT
                                     CASE WHEN m.srv_type = 'L' THEN
                                       1
                                     ELSE
                                       2
                                     END slr,
                                     CASE WHEN m.srv_type = 'L' THEN
                                        m.srv_type
                                      ELSE
                                       (SELECT DISTINCT DECODE(l.list_grp_code,'CONS','C','P')
                                          FROM am_list_range l
                                         WHERE l.principal_map_cd = p_pmc
                                           AND l.list_name = 'PART_TYPE'
                                           AND l.list_code = m.srv_cd
                                           )
                                     END srv_type,
                                     m.srv_cd,
                                     CASE WHEN m.srv_type = 'L' THEN
                                         (SELECT o.opr_desc
                                            FROM vm_msil_opr o
                                           WHERE o.principal_map_cd = p_pmc
                                             AND o.opr_cd = m.srv_cd
                                             AND o.dealer_type = 'D'
                                             --AND o.svar_cd = m.svar_mod_cd
                                             AND ROWNUM = 1
                                             )
                                       ELSE
                                         (SELECT l.list_desc
                                            FROM am_list_range l
                                           WHERE l.principal_map_cd = p_pmc
                                             AND l.list_name = 'PART_TYPE'
                                             AND l.list_code = m.srv_cd
                                             AND ROWNUM = 1
                                           )
                                     END srv_desc,
                                     m.srv_qty
                                FROM vm_menu_cd m
                               WHERE m.principal_map_cd = p_pmc
                                 AND m.svar_mod_cd = 'SVAR'
                                 AND m.active_yn = 'Y'
                                 AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                                 AND m.srv_type = 'L'
                                 AND m.sub_srv_cd = p_pkg_type
                                 AND lv_smp_srv != 'FR3'
                               ORDER by 1,2 DESC,3
                             )
                         )
         LOOP
           ln_cnt := NVL(ln_cnt,0) + 1;
           UPDATE gbl_smp
              SET srv_qty = NVL(srv_qty,0) + NVL(cur_m.srv_qty,0),
                  to_subtype = lv_cds_cvm
            WHERE parent_group = p_parent
              AND dealer_map_cd = p_dealer
              AND loc_cd = p_loc
              AND comp_fa = p_comp
              AND reg_num = p_reg_num
              AND pkg_type = p_pkg_type
              AND pkg_code = p_pkg_code
              AND srv_type = cur_m.srv_type
              AND srv_cd = cur_m.srv_cd;

           IF SQL%NOTFOUND THEN
             BEGIN
               INSERT INTO gbl_smp (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_type,
                                    from_subtype,
                                    no_of_srv,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    srv_qty,
                                    discount_per
                                    )
                         VALUES   (p_parent,
                                   p_dealer,
                                   p_loc,
                                   p_comp,
                                   p_reg_num,
                                   p_pkg_type,
                                   lv_cds_cvm, --lv_smp_srv,
                                   p_srv_no,
                                   p_pkg_code,
                                   cur_m.srl_num,
                                   cur_m.srv_type,
                                   cur_m.srv_cd,
                                   cur_m.srv_desc,
                                   cur_m.srv_qty,
                                   CASE WHEN cur_m.srv_type = 'L' THEN
                                      ln_labor_disc_per
                                    WHEN cur_m.srv_type = 'P' THEN
                                      ln_part_disc_per
                                    WHEN cur_m.srv_type = 'C' THEN
                                      ln_cons_disc_per
                                    ELSE
                                      0
                                    END
                                   );
             EXCEPTION WHEN OTHERS THEN
               NULL;
             END;
           END IF;
        END LOOP;

        IF ln_sub_srv = 1 THEN
          ln_sub_srv := SUBSTR(p_fsub_srv,4);
        END IF;

        ln_sub_srv := ln_sub_srv + 1;
        lv_smp_srv := 'PMS'||ln_sub_srv;
        lv_cds_cvm := SUBSTR(p_pkg_type,1,3)||ln_sub_srv;

        IF NVL(ln_cnt, 0) = 0 THEN
          p_err_cd  := 1;
          p_err_msg := lv_smp_srv||' Service Menu Code not defined for Specific Service Model';
          RETURN;
        END IF;
      END LOOP;
    END IF; -- Service Type

    -- Insert into Details Table
    IF p_err_cd = 0 THEN
      --DBMS_OUTPUT.PUT_LINE(p_reg_num||' :: '||p_pkg_type||' :: '||p_pkg_code);
      FOR cur_d IN (SELECT  DECODE(x.addon_type, 'CL', 5, 'BR', 6, DECODE(x.srv_type, 'L',1,'P',2,'C',3,4)) ord_srl, x.*
                      FROM gbl_smp x
                     WHERE parent_group = p_parent
                       AND dealer_map_cd = p_dealer
                       AND loc_cd = p_loc
                       AND comp_fa = p_comp
                       AND reg_num = p_reg_num
                       AND pkg_type = p_pkg_type
                       AND pkg_code = p_pkg_code
                      ORDER BY 1, srl_num
                     )
      LOOP
        ln_rate     := 0;
        ln_frt      := 0;
        lv_hsn_sac  := NULL;
        lv_part_num := NULL;
        lv_part_grp := NULL;
        ln_srl      := NVL(ln_srl, 0) + 1;

        IF cur_d.srv_type = 'L' THEN
          -- Labour SAC
          BEGIN
            SELECT NVL(L.sac_code, '998729'), l.flat_amt, l.flat_rate_hrs
              INTO lv_hsn_sac, ln_rate, ln_frt
              FROM vm_dlr_lts l
             WHERE l.dealer_map_cd = p_dealer
               AND l.loc_cd = p_loc
               AND l.svar_cd = lv_svar
               AND l.opr_cd = cur_d.srv_cd;
          EXCEPTION WHEN OTHERS THEN
             NULL;
          END;

          IF NVL(ln_rate,0) = 0 THEN
            BEGIN
              SELECT NVL(l.rate_per_hour,0) * NVL(ln_frt,0)
                INTO ln_rate
                FROM vm_rcateg l
               WHERE l.dealer_map_cd = p_dealer
                 AND l.loc_cd = p_loc
                 AND l.svar_cd = lv_svar
                 AND l.rcateg_cd = 'PMS';
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
          END IF;

          IF NVL(ln_rate,0) = 0 THEN
            BEGIN
              SELECT NVL(sac_code, '998729')
                INTO lv_hsn_sac
                FROM vm_msil_opr l
               WHERE l.principal_map_cd = p_pmc
                 AND l.dealer_type = 'D'
                 AND l.svar_cd = lv_svar
                 AND l.opr_cd = cur_d.srv_cd;
            EXCEPTION WHEN OTHERS THEN
               lv_hsn_sac  := NULL;
            END;

            BEGIN
              SELECT m.opr_amt
                INTO ln_rate
                FROM vm_opr_amt m
               WHERE m.principal_map_cd = p_pmc
                 AND m.opr_cd = cur_d.srv_cd
                 AND m.svar_cd = lv_svar
                 AND m.city_rph_type = lv_city_rph
                 AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE));
            EXCEPTION WHEN OTHERS THEN
               ln_rate := 0;
            END;

            IF NVL(ln_rate,0) = 0 THEN
              BEGIN
                SELECT NVL(m.frt, 0) * NVL(x.rph, 0) opr_amt
                  INTO ln_rate
                  FROM vm_opr_amt m, vm_msil_rph_svar x
                 WHERE m.principal_map_cd = p_pmc
                   AND m.opr_cd = cur_d.srv_cd
                   AND m.svar_cd = lv_svar
                   AND m.city_rph_type = lv_city_rph
                   AND TRUNC(SYSDATE) BETWEEN from_Date AND NVL(to_Date, TRUNC(SYSDATE))
                   AND x.principal_map_cd = m.principal_map_cd
                   AND x.city_rph_type = m.city_rph_type
                   AND x.svar_cd = m.svar_cd
                   AND x.rph_type = 'D'
                   AND x.channel = lv_channel;
              EXCEPTION WHEN OTHERS THEN
                 ln_rate := 0;
              END;
            END IF;
          END IF;
        ELSE -- Parts / Cons
          IF cur_d.addon_type IS NULL THEN
            BEGIN
              SELECT list_grp_code INTO lv_part_grp
                FROM am_list_range
               WHERE principal_map_Cd = 1
                 AND list_name = 'SMP_PARTGROUP'
                 AND list_code = cur_d.srv_cd;
            EXCEPTION WHEN OTHERS THEN
              lv_part_grp := NULL;
            END;

            IF lv_part_grp = 'ENGOIL' AND NVL(p_engine,'NA') != 'NA' THEN
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.part_num = p_engine
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'TV3', 'FR3', 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;
            ELSIF lv_part_grp = 'COOLANT' AND NVL(p_coolant,'NA') != 'NA' THEN
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.part_num = p_coolant
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'TV3', 'FR3', 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                NULL;
              END;
            ELSE
              BEGIN
                SELECT part_num, mrp
                  INTO lv_part_num, ln_rate
                  FROM (SELECT m.part_num,
                               (SELECT MAX(d.mrp)
                                  FROM pi_pm_part_mrp d
                                 WHERE d.principal_map_cd = p_pmc
                                   AND d.part_num = m.part_num
                                   ) mrp
                          FROM vm_menu_cd m
                         WHERE m.principal_map_cd = p_pmc
                           AND m.svar_mod_cd = lv_svar
                           AND m.variant_cd = lv_variant
                           AND m.active_yn = 'Y'
                           AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                           AND m.srv_type = 'P'
                           AND m.srv_cd = cur_d.srv_cd
                           AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'TV3', 'FR3', 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                           AND EXISTS (SELECT 1 FROM dmsd_epc_dms_part_mapping ep
                                        WHERE ep.variant_cd = m.variant_cd
                                          AND ep.part_num = m.part_num
                                        )
                         ORDER BY 2
                           )
                 WHERE mrp IS NOT NULL
                   AND ROWNUM = 1;
              EXCEPTION WHEN OTHERS THEN
                lv_part_num := NULL;
              END;
              --DBMS_OUTPUT.PUT_LINE('1 - '||lv_svar||' :: '||lv_variant||' :: '||cur_d.srv_cd||' :: '|| cur_d.from_subtype||' :: '||lv_part_num||' :: '||ln_rate);
              IF lv_part_num IS NULL THEN
                BEGIN
                  SELECT part_num, mrp
                    INTO lv_part_num, ln_rate
                    FROM (SELECT m.part_num,
                                 (SELECT MAX(d.mrp)
                                    FROM pi_pm_part_mrp d
                                   WHERE d.principal_map_cd = p_pmc
                                     AND d.part_num = m.part_num
                                     ) mrp
                            FROM vm_menu_cd m
                           WHERE m.principal_map_cd = p_pmc
                             AND m.svar_mod_cd = lv_svar
                             AND m.variant_cd = lv_variant
                             AND m.active_yn = 'Y'
                             AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                             AND m.srv_type = 'P'
                             AND m.srv_cd = cur_d.srv_cd
                             AND m.sub_srv_cd = DECODE(cur_d.from_subtype, 'TV3', 'FR3', 'FR3', cur_d.from_subtype, 'PMS'||SUBSTR(cur_d.from_subtype,4))
                           ORDER BY 2
                             )
                   WHERE mrp IS NOT NULL
                     AND ROWNUM = 1;
                EXCEPTION WHEN OTHERS THEN
                  NULL;
                END;
              END IF;
              --DBMS_OUTPUT.PUT_LINE('2 - '||lv_svar||' :: '||lv_variant||' :: '||cur_d.srv_cd||' :: '|| cur_d.from_subtype||' :: '||lv_part_num||' :: '||ln_rate);
            END IF; -- Part Details
          ELSE -- Addon parts
            BEGIN
              SELECT part_num, mrp
                INTO lv_part_num, ln_rate
                FROM (SELECT m.part_num,
                             (SELECT MAX(d.mrp)
                                FROM pi_pm_part_mrp d
                               WHERE d.principal_map_cd = p_pmc
                                 AND d.part_num = m.part_num
                                 ) mrp
                        FROM vm_menu_cd m
                       WHERE m.principal_map_cd = p_pmc
                         AND m.svar_mod_cd = 'ADDON'
                         AND m.active_yn = 'Y'
                         AND m.sub_srv_cd = cur_d.addon_type
                         AND TRUNC(SYSDATE) BETWEEN m.from_date AND NVL(m.to_date, TRUNC(SYSDATE))
                         AND m.srv_type = 'P'
                         AND m.srv_cd = cur_d.srv_cd
                         AND EXISTS (SELECT 1 FROM dmsd_epc_dms_part_mapping ep
                                      WHERE ep.variant_cd = lv_variant
                                        AND ep.part_num = m.part_num
                                      )
                       ORDER BY 2 DESC
                         )
               WHERE mrp IS NOT NULL
                 AND ROWNUM = 1;
            EXCEPTION WHEN OTHERS THEN
              NULL;
            END;
            --dbms_output.put_line('Part '||cur_d.srv_cd ||' - '||cur_d.addon_type||' - '||lv_part_num|| ' - '||ln_rate);
          END IF;

          -- Part Details
          BEGIN
            SELECT NVL(hs_code, '8708'), part_desc
              INTO lv_hsn_sac, lv_part_desc
              FROM pm_part
             WHERE part_num = lv_part_num
               AND principal_map_cd = p_pmc
               AND dealer_map_cd = p_pmc;
          EXCEPTION WHEN OTHERS THEN
             lv_hsn_sac   := NULL;
             lv_part_desc := NULL;
          END;
        END IF;

        IF  NVL(ln_rate, 0) > 0 THEN
          ln_basic := NVL(cur_d.srv_qty, 0) * NVL(ln_rate, 0);
          ln_disc  := NVL(ln_basic, 0) * NVL(cur_d.discount_per, 0) / 100;
          ln_tot   := NVL(ln_basic, 0) - NVL(ln_disc, 0);
          BEGIN
           INSERT INTO gbl_amc_dtl (parent_group,
                                    dealer_map_cd,
                                    loc_cd,
                                    comp_fa,
                                    reg_num,
                                    pkg_code,
                                    srl_num,
                                    srv_type,
                                    srv_cd,
                                    srv_desc,
                                    group_cd,
                                    group_desc,
                                    qty,
                                    discount_per,
                                    catg_cd,
                                    catg_desc,
                                    hsn_sac_cd,
                                    rate,
                                    basic_value,
                                    discount_amt,
                                    tot_value,
                                    gst_type,
                                    sell_price,
                                    addon_type
                                    )
                        VALUES     (cur_d.parent_group,
                                    cur_d.dealer_map_cd,
                                    cur_d.loc_cd,
                                    cur_d.comp_fa,
                                    cur_d.reg_num,
                                    cur_d.pkg_code,
                                    ln_srl,
                                    cur_d.srv_type,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_cd
                                    ELSE
                                      lv_part_num
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      cur_d.srv_desc
                                    ELSE
                                      lv_part_desc
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_cd
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      cur_d.srv_desc
                                    END,
                                    cur_d.srv_qty,
                                    cur_d.discount_per,

                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      'G'
                                    END,
                                    CASE WHEN cur_d.srv_type = 'L' THEN
                                      NULL
                                    ELSE
                                      (SELECT list_desc
                                         FROM am_list_range
                                        WHERE principal_map_cd = p_pmc
                                          AND list_name = 'AMC_CATG_TYPE'
                                          AND list_code = 'G')
                                    END,
                                    lv_hsn_sac,
                                    ln_rate,
                                    ln_basic,
                                    ln_disc,
                                    ln_tot,
                                    p_gst_type,
                                    ln_basic,
                                    cur_d.addon_type
                                    );
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
        END IF;
      END LOOP;

      DELETE FROM gbl_amc_dtl x
       WHERE x.srv_type = 'L'
         AND x.parent_group = p_parent
         AND x.dealer_map_cd = p_dealer
         AND x.loc_cd = p_loc
         AND x.comp_fa = p_comp
         AND x.reg_num = p_reg_num
         AND x.pkg_code = p_pkg_code
         AND x.addon_type = 'RB'
         AND x.srv_cd NOT IN (SELECT l.list_desc
                                FROM gbl_amc_dtl d, am_list_range l
                               WHERE d.srv_type = 'P'
                                 AND d.parent_group = p_parent
                                 AND d.dealer_map_cd = p_dealer
                                 AND d.loc_cd = p_loc
                                 AND d.comp_fa = p_comp
                                 AND d.reg_num = p_reg_num
                                 AND d.pkg_code = p_pkg_code
                                 AND d.addon_type = 'RB'
                                 AND l.principal_map_cd = p_pmc
                                 AND l.list_name = 'ADDON_LBR'
                                 AND l.list_grp_code = d.addon_type
                                 AND d.group_cd = l.list_code
                                 );
    END IF;
    COMMIT;
  END SP_POP_SMP_PKG_TV;
```

#### SP-026 - PKG_SMP.SP_POP_SMP_TAX

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SMP Details (N/A / CN_MAIN); TCS (WN_MAIN / CN_TCS)

---

**Purpose**

Calculates and persists GST tax charges for all labour and parts line items belonging to a Service Management Package (SMP) AMC contract. For each line item the procedure determines the applicable tax code, evaluates the charge expression to derive individual charge amounts, updates the net value on GBL_AMC_DTL, and writes the resulting charge breakdown rows to GBL_AMC_CHARGES. Parts tax calculation is conditional on whether TCS (Tax Collected at Source) applies to the package.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pmc | NUMBER | IN |
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp | VARCHAR2 | IN |
| p_pkg_code | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_gst_type | VARCHAR2 | IN |
| p_dlr_state | VARCHAR2 | IN |
| p_cust_state | VARCHAR2 | IN |
| p_tcs_app_yn | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output parameters (p_err_cd = 0, p_err_msg = NULL) and determine the GST state to use: if p_gst_type = 'S' (intra-state / same state) use the dealer state (p_dlr_state); otherwise use the customer state (p_cust_state).
- Step 2 - Delete all existing charge rows from GBL_AMC_CHARGES for the package identified by the combination of p_parent, p_dealer, p_loc, p_comp, p_reg_num, and p_pkg_code, ensuring a clean recalculation.
- Step 3 - Labour charge calculation: iterate over every labour line item (srv_type = 'L') in GBL_AMC_DTL for the package (cursor cur_lbr).
  - Step 3a - For each labour line, look up the operation tax code (opr_tax_cd) and normal/common split percentages from VM_DLR_LTS using the dealer, location, operation code, and SVAR code. If no matching row is found, default to tax code 'LB001' with 100% normal and 0% common.
  - Step 3b - Retrieve the applicable charge definitions for the resolved tax code, GST type, and GST state from AM_CHARGE joined with VM_TAX (cursor cur_lbr_charge, filtered to common_ind = 'M'). Build the charge collection arrays (tc_opr_charges / to_opr_charges) and construct the expression parameter string, prefixing sell price, quantity, discount, normal-rate, and common-rate tokens.
  - Step 3c - Evaluate the charge expression: if cess is applicable (lv_cess_appl = 'Y'), GST type is intra-state, and the GST number indicates an unregistered customer, call Evaluate_Expr with formula 'MCPINV'; otherwise call Evaluate_Expr with formula 'AMCINV'. On any exception, set p_err_cd = 1 and p_err_msg = 'Evaluate Error - Operation'.
  - Step 3d - Parse the semicolon-delimited output parameter string from Evaluate_Expr; match each returned charge type token back to the corresponding entry in to_opr_charges by charge_type and operation serial number, storing the rounded charge amount and accumulating the total labour charge amount (lv_opr_chg_amt).
  - Step 3e - Update GBL_AMC_DTL for the labour line: set charge_amt = lv_opr_chg_amt and net_value = sell_price - (discount_amt + dlr_disc_amt) + lv_opr_chg_amt.
- Step 4 - Insert labour charge rows: for every entry in to_opr_charges where opr_cd is not null, insert one row into GBL_AMC_CHARGES carrying the package key fields, charge serial, charge code/type/indicator/value, and the calculated charge amount (defaulting to 0 if null).
- Step 5 - Parts charge calculation: only when p_tcs_app_yn is 'Y' or 'H', iterate over every non-labour line item in GBL_AMC_DTL (cursor cur_part).
  - Step 5a - For each parts line, look up the part tax code (part_tax_cd) from PM_PART using the part number and principal/dealer map code. Default to 'A' if not found.
  - Step 5b - Retrieve applicable charge definitions from AM_CHARGE joined with PM_TAX (cursor cur_part_charge, tax_type = 'S', common_ind in 'M' or the GST-type-specific indicator). Build tc_part_charges / to_part_charges arrays and the expression parameter string.
  - Step 5c - Evaluate the parts charge expression using Evaluate_Expr with a formula determined by lv_tcs_appl_flag: 'AMCINVTT' for flag 'YT', 'AMCINVTP' for 'YP', 'AMCINVTN' for 'YN', or 0 (no evaluation) for any other value. On any exception, set p_err_cd = 1 and p_err_msg = 'Evaluate Error - Operation'.
  - Step 5d - Parse the output parameter string and match charge type tokens back to to_part_charges entries by charge_type and serial number, accumulating lv_part_chg_amt.
  - Step 5e - Update GBL_AMC_DTL for the parts line: set charge_amt = lv_part_chg_amt and net_value = sell_price - (discount_amt + dlr_disc_amt) + lv_part_chg_amt.
- Step 6 - When p_tcs_app_yn is neither 'Y' nor 'H', update GBL_AMC_DTL for each parts line setting charge_amt and net_value using zero charge amount (no tax applied).
- Step 7 - Insert parts charge rows: for every entry in to_part_charges where opr_cd is not null and charge_amt > 0, insert one row into GBL_AMC_CHARGES.
- Step 8 - COMMIT all changes.

---
**Decision Points**

DP-001

Condition:
p_gst_type = 'S' (intra-state supply)

TRUE:
Use the dealer state (p_dlr_state) as the GST state (lv_gst_state) for all subsequent tax lookups.

FALSE:
Use the customer state (p_cust_state) as the GST state.

---

DP-002

Condition:
A matching row is found in VM_DLR_LTS for the current labour operation (dealer, location, operation code, SVAR code).

TRUE:
Use the retrieved opr_tax_cd, ln_nor_per, and ln_com_per values for the charge expression.

FALSE:
Default to opr_tax_cd = 'LB001', ln_nor_per = 100, ln_com_per = 0.

---

DP-003

Condition:
lv_cess_appl = 'Y' AND p_gst_type = 'S' AND lv_gst_num = 'GSTUNREGISTERED' (or null) for a labour line.

TRUE:
Call Evaluate_Expr with formula code 'MCPINV' (unregistered customer cess path).

FALSE:
Call Evaluate_Expr with formula code 'AMCINV' (standard AMC invoice path).

---

DP-004

Condition:
NVL(p_tcs_app_yn, 'N') IN ('Y', 'H')

TRUE:
Perform full parts tax calculation: look up part tax code, build charge expression, call Evaluate_Expr with TCS-variant formula, parse results, and update GBL_AMC_DTL with the computed charge amount.

FALSE:
Update GBL_AMC_DTL for each parts line with zero charge amount and net value = sell_price - discounts (no tax charges inserted).

---

DP-005

Condition:
lv_tcs_appl_flag value when processing parts lines (evaluated only when DP-004 is TRUE).

TRUE (= 'YT'):
Call Evaluate_Expr with formula 'AMCINVTT'.

TRUE (= 'YP'):
Call Evaluate_Expr with formula 'AMCINVTP'.

TRUE (= 'YN'):
Call Evaluate_Expr with formula 'AMCINVTN'.

FALSE (any other value):
Set ln_num = 0; no expression evaluation performed.

---

DP-006

Condition:
A parts line entry in to_part_charges has opr_cd IS NOT NULL AND charge_amt > 0 at the insert step.

TRUE:
Insert the charge row into GBL_AMC_CHARGES.

FALSE:
Skip the insert; no charge row is written for that entry.

---

DP-007

Condition:
A labour line entry in to_opr_charges has opr_cd IS NOT NULL at the insert step.

TRUE:
Insert the charge row into GBL_AMC_CHARGES (charge_amt defaults to 0 if null).

FALSE:
Skip the insert for that entry.

---
**Database Interactions**

- DB-001 - Read GBL_AMC_DTL - Reads data from GBL_AMC_DTL (columns: charge amt, net value) for lookup or validation.
- DB-002 - Read AM_CHARGE - Reads data from AM_CHARGE for lookup or validation.
- DB-003 - Delete from GBL_AMC_CHARGES - Deletes rows from GBL_AMC_CHARGES.
- DB-004 - Read VM_DLR_LTS - Reads data from VM_DLR_LTS for lookup or validation.
- DB-005 - Update GBL_AMC_DTL - Updates existing rows in GBL_AMC_DTL (columns: charge amt, net value).
- DB-006 - Insert into GBL_AMC_CHARGES - Persists a new row into GBL_AMC_CHARGES using columns: parent group, dealer map cd, loc cd, comp fa, reg num, pkg code, srl num, srv type, and 9 more column(s).
- DB-007 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - All existing tax charge rows in GBL_AMC_CHARGES for the package must be deleted before recalculation to prevent duplicate or stale charge entries.
- BR-002 - The GST state used for tax lookups is the dealer's state for intra-state (same-state) transactions and the customer's state for inter-state transactions.
- BR-003 - Labour lines are identified by srv_type = 'L'; all other srv_type values are treated as parts lines.
- BR-004 - If no operation tax code is found in VM_DLR_LTS for a labour operation, the fallback tax code 'LB001' must be applied with a 100% normal split and 0% common split.
- BR-005 - Labour charge definitions are sourced from AM_CHARGE joined with VM_TAX, restricted to common_ind = 'M', ensuring only mandatory tax components are applied to labour.
- BR-006 - For an unregistered GST customer (lv_gst_num = 'GSTUNREGISTERED') on an intra-state transaction where cess applies, the 'MCPINV' expression formula is used instead of the standard 'AMCINV' formula.
- BR-007 - Parts tax charges are only calculated and inserted when the TCS applicability flag (p_tcs_app_yn) is 'Y' or 'H'; otherwise parts lines are updated with zero charge amounts.
- BR-008 - The parts charge expression formula is selected based on lv_tcs_appl_flag: 'AMCINVTT' (full TCS), 'AMCINVTP' (partial TCS), or 'AMCINVTN' (no TCS variant); any other flag value results in no expression evaluation and a zero charge.
- BR-009 - If no part tax code is found in PM_PART for a parts line, the default tax code 'A' must be used.
- BR-010 - Parts charge definitions are sourced from AM_CHARGE joined with PM_TAX, restricted to tax_type = 'S' and common_ind = 'M' or the GST-type-specific indicator ('O' for intra-state, 'C' for inter-state).
- BR-011 - Charge amounts are rounded to two decimal places before being stored or accumulated.
- BR-012 - A parts charge row is inserted into GBL_AMC_CHARGES only when the charge amount is greater than zero; labour charge rows are inserted regardless of amount (defaulting to zero).
- BR-013 - The net value of each line item in GBL_AMC_DTL is computed as: sell_price - (discount_amt + dlr_disc_amt) + charge_amt.
- BR-014 - All data modifications (deletes, updates, inserts) are committed in a single COMMIT at the end of the procedure.

---
**Implementation Logic**

```plsql

  PROCEDURE SP_POP_SMP_TAX (p_pmc        NUMBER,
                            p_parent     VARCHAR2,
                            p_dealer     NUMBER,
                            p_loc        VARCHAR2,
                            p_comp       VARCHAR2,
                            p_pkg_code   VARCHAR2,
                            p_reg_num    VARCHAR2,
                            p_gst_type   VARCHAR2,
                            p_dlr_state  VARCHAR2,
                            p_cust_state VARCHAR2,
                            p_tcs_app_yn VARCHAR2,
                            p_err_cd     OUT NUMBER,
                            p_err_msg    OUT VARCHAR2
                            )
   IS
    lv_svar       gm_vin.svar_cd%TYPE;
    lv_opr_tax_cd vm_dlr_lts.opr_tax_cd%TYPE;
    lv_part_tax   pm_part.part_tax_cd%TYPE;
    lv_gst_num    gm_cin.gst_num%TYPE;

    lv_gst_state   VARCHAR2(3);
    ln_com_per     NUMBER := 0;
    ln_nor_per     NUMBER := 0;

    ln_chg_srl     NUMBER := 1;
    ln_opr_srl     NUMBER := 0;
    lc_cus_chg_cnt NUMBER := 1;
    lv_divide      NUMBER(15, 4);
    lv_divisor     NUMBER(15, 2);
    lv_param       VARCHAR2(4000);
    ln_num         VARCHAR2(15) := 0;
    lv_oparam      VARCHAR2(4000);
    lv_token       VARCHAR2(200);
    lv_value       NUMBER;
    lv_opr_chg_amt NUMBER;

    tc_opr_charges  ctab;
    to_opr_charges  ctab;
    tc_part_charges ctab;
    to_part_charges ctab;

    ln_pchg_srl      NUMBER := 1;
    ln_part_srl      NUMBER := 0;
    lv_part_chg_amt  NUMBER;
    lv_cess_appl     VARCHAR2(5) := 'N';
    lv_tcs_appl_flag VARCHAR2(2);

    CURSOR cur_lbr IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             NVL(discount_amt,0) + NVL(dlr_disc_amt,0) discount_amt,
             sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc
         AND comp_fa = p_comp
         AND reg_num = p_reg_num
         AND pkg_code = p_pkg_code
         AND srv_type = 'L';

    CURSOR cur_lbr_charge(pi_ptax_cd   IN VARCHAR2,
                          pi_gst_type  IN VARCHAR2,
                          pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, vm_tax b
       WHERE b.dealer_map_cd = p_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND a.loc_cd = p_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND NVL(b.gst_type, 'S') = pi_gst_type
         AND b.gst_state_cd = pi_gst_state
         AND b.common_ind = 'M'
         AND b.opr_tax_cd = pi_ptax_cd;

    CURSOR cur_part IS
      SELECT srl_num,
             srv_type,
             srv_cd,
             qty,
             basic_value,
             NVL(discount_amt,0) + NVL(dlr_disc_amt,0) discount_amt,
             sell_price
        FROM gbl_amc_dtl
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc
         AND comp_fa = p_comp
         AND reg_num = p_reg_num
         AND pkg_code = p_pkg_code
         AND srv_type != 'L';

    CURSOR cur_part_charge(pi_ptax_cd   IN VARCHAR2,
                           pi_gst_type  IN VARCHAR2,
                           pi_gst_state IN VARCHAR2) IS
      SELECT a.charge_type,
             a.charge_ind,
             a.charge_value,
             a.charge_cd,
             b.common_ind,
             b.order_srl
        FROM am_charge a, Pm_tax b
       WHERE b.dealer_map_cd = p_dealer
         AND a.dealer_map_cd = b.dealer_map_cd
         AND a.loc_cd = b.loc_cd
         AND A.LOC_CD = p_loc
         AND a.charge_type = b.charge_type
         AND a.charge_cd = b.charge_cd
         AND (b.common_ind IN ('M') OR
              b.common_ind = DECODE(pi_gst_type, 'S', 'O', 'I', 'C'))
         AND tax_type = 'S'
         AND b.gst_state_cd = pi_gst_state
         AND b.part_tax_cd = pi_ptax_cd;

  BEGIN
    p_err_cd  := 0;
    p_err_msg := NULL;

    IF p_gst_type = 'S' THEN
      lv_gst_state := p_dlr_state;
    ELSE
      lv_gst_state := p_cust_state;
    END IF;

    DELETE FROM gbl_amc_charges
     WHERE parent_group = p_parent
       AND dealer_map_cd = p_dealer
       AND loc_cd = p_loc
       AND comp_fa = p_comp
       AND reg_num = p_reg_num
       AND pkg_code = p_pkg_code;

    -- Calculate Labour Charges
    FOR cur_l IN cur_lbr LOOP
      ln_opr_srl := cur_l.srl_num;
      lv_param   := NULL;
      ln_nor_per := 100;
      ln_com_per := 0;

      BEGIN
        SELECT opr_tax_cd, 100, 0
          INTO lv_opr_tax_cd, ln_nor_per, ln_com_per
          FROM vm_dlr_lts
         WHERE dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND opr_cd = cur_l.srv_cd
           AND svar_cd = lv_svar;
      EXCEPTION
        WHEN OTHERS THEN
          lv_opr_tax_cd := 'LB001';
          ln_nor_per    := 100;
          ln_com_per    := 0;
      END;

      DECLARE
        ln_charge_cnt NUMBER := 1;
      BEGIN
        FOR cur_c IN cur_lbr_charge(lv_opr_tax_cd,
                                    p_gst_type,
                                    lv_gst_state) LOOP
          tc_opr_charges(ln_charge_cnt).charge_type := cur_c.charge_type;
          tc_opr_charges(ln_charge_cnt).charge_ind := cur_c.charge_ind;
          tc_opr_charges(ln_charge_cnt).charge_value := cur_c.charge_value;
          tc_opr_charges(ln_charge_cnt).charge_cd := cur_c.charge_cd;
          tc_opr_charges(ln_charge_cnt).common_ind := cur_c.common_ind;
          tc_opr_charges(ln_charge_cnt).charge_srl := ln_chg_srl;
          tc_opr_charges(ln_charge_cnt).order_srl := cur_c.order_srl;
          tc_opr_charges(ln_charge_cnt).srv_type := cur_l.srv_type;
          tc_opr_charges(ln_charge_cnt).opr_cd := cur_l.srv_cd;
          tc_opr_charges(ln_charge_cnt).opr_srl := cur_l.srl_num;
          ln_charge_cnt := ln_charge_cnt + 1;

          IF cur_c.charge_ind = 'P' THEN
            lv_divisor := 100;
          ELSE
            lv_divisor := 1;
          END IF;
          lv_divide := cur_c.charge_value / lv_divisor;
          lv_param  := lv_param || cur_c.charge_type || ';' ||
                       TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                       cur_c.charge_ind || ';';

          ln_chg_srl := ln_chg_srl + 1;
        END LOOP;

        FOR x IN 1 .. tc_opr_charges.COUNT LOOP
          to_opr_charges(lc_cus_chg_cnt).charge_type := tc_opr_charges(x)
                                                        .charge_type;
          to_opr_charges(lc_cus_chg_cnt).charge_ind := tc_opr_charges(x)
                                                       .charge_ind;
          to_opr_charges(lc_cus_chg_cnt).charge_value := tc_opr_charges(x)
                                                         .charge_value;
          to_opr_charges(lc_cus_chg_cnt).charge_cd := tc_opr_charges(x)
                                                      .charge_cd;
          to_opr_charges(lc_cus_chg_cnt).common_ind := tc_opr_charges(x)
                                                       .common_ind;
          to_opr_charges(lc_cus_chg_cnt).charge_srl := tc_opr_charges(x)
                                                       .charge_srl;
          to_opr_charges(lc_cus_chg_cnt).order_srl := tc_opr_charges(x)
                                                      .order_srl;
          to_opr_charges(lc_cus_chg_cnt).srv_type := tc_opr_charges(x)
                                                     .srv_type;
          to_opr_charges(lc_cus_chg_cnt).opr_cd := tc_opr_charges(x)
                                                   .opr_cd;
          to_opr_charges(lc_cus_chg_cnt).opr_srl := tc_opr_charges(x)
                                                    .opr_srl;
          lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
        END LOOP;

        lv_param := 'SP;' || TO_CHAR(cur_l.sell_price) || ';' || 'P;' ||
                    'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' || 'DIS;' ||
                    TO_CHAR(NVL(cur_l.discount_amt, 0)) || ';' || 'A;' ||
                    'NAT;' || (NVL(ln_nor_per, 0) / 100) || ';' || 'P;' ||
                    'COM;' || TO_CHAR(NVL(ln_com_per, 0) / 100) || ';' || 'P;' ||
                    lv_param;
      END;

      BEGIN
        IF NVL(lv_cess_appl, 'N') = 'Y' AND p_gst_type = 'S' AND
           NVL(lv_gst_num, 'GSTUNREGISTERED') = 'GSTUNREGISTERED' THEN
          Evaluate_Expr('MCPINV',
                        lv_param,
                        p_dealer,
                        p_loc,
                        lv_oparam,
                        ln_num);
        ELSE
          Evaluate_Expr('AMCINV',
                        lv_param,
                        p_dealer,
                        p_loc,
                        lv_oparam,
                        ln_num);
        END IF;

      EXCEPTION
        WHEN OTHERS THEN
          p_err_cd  := 1;
          p_err_msg := 'Evaluate Error - Operation';
      END;
      lv_opr_chg_amt := 0;

      LOOP
        lv_token  := SUBSTR(lv_oparam, 1, INSTR(lv_oparam, ';', 1, 1) - 1);
        lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
        lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                      1,
                                      INSTR(lv_oparam, ';', 1, 1) - 1));
        lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
        IF to_opr_charges.COUNT > 0 THEN
          FOR i IN to_opr_charges.FIRST .. to_opr_charges.LAST LOOP
            IF to_opr_charges(i).charge_type = lv_token AND to_opr_charges(i)
               .opr_srl = ln_opr_srl THEN
              to_opr_charges(i).charge_amt := ROUND(lv_value, 2);
              lv_opr_chg_amt := NVL(lv_opr_chg_amt, 0) +
                                ROUND(NVL(lv_value, 0), 2);
            END IF;
          END LOOP;
        END IF;
        EXIT WHEN lv_oparam IS NULL;
      END LOOP;

     UPDATE gbl_amc_dtl
         SET charge_amt = lv_opr_chg_amt,
             net_value  = NVL(sell_price, 0) - (NVL(discount_amt, 0) + NVL(dlr_disc_amt,0)) + NVL(lv_opr_chg_amt, 0)
       WHERE parent_group = p_parent
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc
         AND comp_fa = p_comp
         AND reg_num = p_reg_num
         AND pkg_code = p_pkg_code
         AND srl_num = cur_l.srl_num
         AND srv_type = cur_l.srv_type
         AND srv_cd = cur_l.srv_cd;
    END LOOP;

    -- Insert Labour Charges
    FOR i IN 1 .. to_opr_charges.COUNT LOOP
      IF to_opr_charges(i).opr_cd IS NOT NULL THEN
        INSERT INTO gbl_amc_charges
          (parent_group,
           dealer_map_cd,
           loc_cd,
           comp_fa,
           reg_num,
           pkg_code,
           srl_num,
           srv_type,
           srv_cd,
           charge_srl,
           common_ind,
           order_srl,
           charge_cd,
           charge_type,
           charge_ind,
           charge_value,
           charge_amt)
        VALUES
          (p_parent,
           p_dealer,
           p_loc,
           p_comp,
           p_reg_num,
           p_pkg_code,
           to_opr_charges(i).opr_srl,
           to_opr_charges(i).srv_type,
           to_opr_charges(i).opr_cd,
           to_opr_charges(i).charge_srl,
           to_opr_charges(i).common_ind,
           to_opr_charges(i).order_srl,
           to_opr_charges(i).charge_cd,
           to_opr_charges(i).charge_type,
           to_opr_charges(i).charge_ind,
           to_opr_charges(i).charge_value,
           NVL(to_opr_charges(i).charge_amt, 0));
      END IF;
    END LOOP;

    -- Calculate Part Charges
    lc_cus_chg_cnt := 1;
    ln_pchg_srl    := ln_chg_srl;
    IF NVL(p_tcs_app_yn, 'N') IN ('Y', 'H') THEN
      FOR cur_p IN cur_part LOOP
        lv_param    := NULL;
        lv_oparam   := NULL;
        ln_part_srl := cur_p.srl_num;
        BEGIN
          SELECT NVL(part_tax_cd, 'A')
            INTO lv_part_tax
            FROM pm_part
           WHERE part_num = cur_p.srv_cd
             AND principal_map_cd = p_pmc
             AND dealer_map_cd = p_pmc;
        EXCEPTION
          WHEN OTHERS THEN
            lv_part_tax := 'A';
        END;

        DECLARE
          ln_chg_cnt NUMBER := 1;
        BEGIN
          FOR cur_c IN cur_part_charge(lv_part_tax,
                                       p_gst_type,
                                       lv_gst_state) LOOP
            tc_part_charges(ln_chg_cnt).charge_type := cur_c.charge_type;
            tc_part_charges(ln_chg_cnt).charge_ind := cur_c.charge_ind;
            tc_part_charges(ln_chg_cnt).charge_value := cur_c.charge_value;
            tc_part_charges(ln_chg_cnt).charge_cd := cur_c.charge_cd;
            tc_part_charges(ln_chg_cnt).common_ind := cur_c.common_ind;
            tc_part_charges(ln_chg_cnt).charge_srl := ln_pchg_srl;
            tc_part_charges(ln_chg_cnt).srl_num := cur_p.srl_num;
            tc_part_charges(ln_chg_cnt).order_srl := cur_c.order_srl;
            tc_part_charges(ln_chg_cnt).srv_type := cur_p.srv_type;
            tc_part_charges(ln_chg_cnt).opr_cd := cur_p.srv_cd;
            ln_chg_cnt := ln_chg_cnt + 1;

            IF cur_c.charge_ind = 'P' THEN
              lv_divisor := 100;
            ELSE
              lv_divisor := 1;
            END IF;

            lv_divide   := cur_c.charge_value / lv_divisor;
            lv_param    := lv_param || cur_c.charge_type || ';' ||
                           TO_CHAR(cur_c.charge_value / lv_divisor) || ';' ||
                           cur_c.charge_ind || ';';
            ln_pchg_srl := ln_pchg_srl + 1;
          END LOOP;

          FOR x IN 1 .. tc_part_charges.COUNT LOOP
            to_part_charges(lc_cus_chg_cnt).charge_type := tc_part_charges(x)
                                                           .charge_type;
            to_part_charges(lc_cus_chg_cnt).charge_ind := tc_part_charges(x)
                                                          .charge_ind;
            to_part_charges(lc_cus_chg_cnt).charge_value := tc_part_charges(x)
                                                            .charge_value;
            to_part_charges(lc_cus_chg_cnt).charge_cd := tc_part_charges(x)
                                                         .charge_cd;
            to_part_charges(lc_cus_chg_cnt).common_ind := tc_part_charges(x)
                                                          .common_ind;
            to_part_charges(lc_cus_chg_cnt).charge_srl := tc_part_charges(x)
                                                          .charge_srl;
            to_part_charges(lc_cus_chg_cnt).order_srl := tc_part_charges(x)
                                                         .order_srl;
            to_part_charges(lc_cus_chg_cnt).srl_num := tc_part_charges(x)
                                                       .srl_num;
            to_part_charges(lc_cus_chg_cnt).srv_type := tc_part_charges(x)
                                                        .srv_type;
            to_part_charges(lc_cus_chg_cnt).opr_cd := tc_part_charges(x)
                                                      .opr_cd;
            lc_cus_chg_cnt := lc_cus_chg_cnt + 1;
          END LOOP;
          lv_param := 'SP;' || TO_CHAR(cur_p.sell_price) || ';' || 'P;' ||
                      'QTY;' || TO_CHAR(NVL(1, 1)) || ';' || 'A;' ||
                      'DIS;' || TO_CHAR(NVL(cur_p.discount_amt, 0)) || ';' || 'A;' ||
                      'NAT;' || (NVL(100, 0) / 100) || ';' || 'P;' ||
                      'COM;' || TO_CHAR(NVL(0, 0) / 100) || ';' || 'P;' ||
                      lv_param;
        END;
        BEGIN
          IF NVL(LV_TCS_APPL_FLAG, 'N') = 'YT' THEN
            --TCS
            Evaluate_Expr('AMCINVTT',
                          lv_param,
                          p_dealer,
                          p_loc,
                          lv_oparam,
                          ln_num);
          ELSIF NVL(LV_TCS_APPL_FLAG, 'N') = 'YP' THEN
            --TCS
            Evaluate_Expr('AMCINVTP',
                          lv_param,
                          p_dealer,
                          p_loc,
                          lv_oparam,
                          ln_num);
          ELSIF NVL(LV_TCS_APPL_FLAG, 'N') = 'YN' THEN
            Evaluate_Expr('AMCINVTN',
                          lv_param,
                          p_dealer,
                          p_loc,
                          lv_oparam,
                          ln_num);
          ELSE
            ln_num := 0;
          END IF;
        EXCEPTION
          WHEN OTHERS THEN
            p_err_cd  := 1;
            p_err_msg := 'Evaluate Error - Operation';
        END;
        lv_part_chg_amt := 0;
        LOOP
          lv_token  := SUBSTR(lv_oparam,
                              1,
                              INSTR(lv_oparam, ';', 1, 1) - 1);
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);
          lv_value  := TO_NUMBER(SUBSTR(lv_oparam,
                                        1,
                                        INSTR(lv_oparam, ';', 1, 1) - 1));
          lv_oparam := SUBSTR(lv_oparam, INSTR(lv_oparam, ';', 1, 1) + 1);

          IF to_part_charges.COUNT > 0 THEN
            FOR z IN to_part_charges.FIRST .. to_part_charges.LAST LOOP
              IF to_part_charges(z).charge_type = lv_token AND to_part_charges(z)
                 .srl_num = ln_part_srl THEN
                to_part_charges(z).charge_amt := ROUND(lv_value, 2);
                lv_part_chg_amt := NVL(lv_part_chg_amt, 0) +
                                   ROUND(NVL(lv_value, 0), 2);
              END IF;
            END LOOP;
          END IF;
          EXIT WHEN lv_oparam IS NULL;
        END LOOP;
        UPDATE gbl_amc_dtl
           SET charge_amt = lv_part_chg_amt,
               net_value  = NVL(sell_price, 0) - (NVL(discount_amt, 0) + NVL(dlr_disc_amt,0)) + NVL(lv_part_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;
    ELSE
      FOR cur_p IN cur_part LOOP
        UPDATE gbl_amc_dtl
           SET charge_amt = NVL(lv_part_chg_amt, 0),
               net_value  = NVL(sell_price, 0) - (NVL(discount_amt, 0) + NVL(dlr_disc_amt,0)) + NVL(lv_part_chg_amt, 0)
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc
           AND comp_fa = p_comp
           AND reg_num = p_reg_num
           AND pkg_code = p_pkg_code
           AND srl_num = cur_p.srl_num
           AND srv_type = cur_p.srv_type
           AND srv_cd = cur_p.srv_cd;
      END LOOP;
    END IF; -- TCS
    -- Insert Part Charges
    FOR z IN 1 .. to_part_charges.COUNT LOOP
      IF to_part_charges(z)
       .opr_cd IS NOT NULL AND to_part_charges(z).charge_amt > 0 THEN
        INSERT INTO gbl_amc_charges
          (parent_group,
           dealer_map_cd,
           loc_cd,
           comp_fa,
           reg_num,
           pkg_code,
           srl_num,
           srv_type,
           srv_cd,
           charge_srl,
           common_ind,
           order_srl,
           charge_cd,
           charge_type,
           charge_ind,
           charge_value,
           charge_amt)
        VALUES
          (p_parent,
           p_dealer,
           p_loc,
           p_comp,
           p_reg_num,
           p_pkg_code,
           to_part_charges(z).srl_num,
           to_part_charges(z).srv_type,
           to_part_charges(z).opr_cd,
           to_part_charges(z).charge_srl,
           to_part_charges(z).common_ind,
           to_part_charges(z).order_srl,
           to_part_charges(z).charge_cd,
           to_part_charges(z).charge_type,
           to_part_charges(z).charge_ind,
           to_part_charges(z).charge_value,
           to_part_charges(z).charge_amt);
      END IF;
    END LOOP;
    COMMIT;
  END SP_POP_SMP_TAX;
```

#### SP-027 - PKG_SMP.SP_VIN_VALIDATE

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Validates whether a vehicle identified by its VIN is eligible for a Service Maintenance Plan (SMP) issuance. The procedure performs a series of sequential checks-VIN resolution, vehicle master lookup, active plan detection, exception and restriction screening, age and mileage eligibility, pending service position determination, and discount configuration verification-and returns eligibility flags, validity parameters, the applicable sub-service position, a CDS eligibility indicator, and any error details to the calling screen trigger.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_pmc | NUMBER | IN |
| pn_vin | VARCHAR2 | IN |
| pn_odm | NUMBER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_smp_yn | VARCHAR2 | OUT |
| po_val_mil | NUMBER | OUT |
| po_val_age | NUMBER | OUT |
| po_srv_no | NUMBER | OUT |
| po_sub_srv | VARCHAR2 | OUT |
| po_cds_yn | VARCHAR2 | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

- PKG_SMP.SF_FLEET_CHECK ([SP-018](#SP-018--PKG_SMP.SF_FLEET_CHECK)) - PKG_SMP.pck (or .pld)
- SP_VALIDATE_OEMVIN ([SP-043](#SP-043--SP_VALIDATE_OEMVIN)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Initialise all output and local variables to safe defaults (po_err_cd = 0, po_smp_yn = 'N', lv_excp_yn = 'N', lv_rest_yn = 'N', lv_disc_yn = 'N', etc.).
- Step 2 - Validate that pn_vin is not NULL; if NULL, set po_err_cd = 1 with message 'Enter a valid VIN' and return immediately.
- Step 3 - Resolve the raw VIN input by calling SP_VALIDATE_OEMVIN (SP-043), which returns the canonical lv_vin and lv_oem_vin. If the dependency returns po_err_cd = 1, return immediately.
- Step 4 - Query GM_VIN using lv_vin to retrieve invoice date (ld_inv_dt), vehicle age in months (ln_veh_age), last recorded odometer (ln_odometer), model code (lv_model_cd), and variant code (lv_variant). Handle NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, and OTHERS with distinct error messages. If ld_inv_dt is NULL or any error was set, return immediately.
- Step 5 - Query GM_VIN_EXT for an existing SMP number (lv_smp_num) and AMC expiry date (ld_amc_exdt). If ld_amc_exdt is in the future (TRUNC(ld_amc_exdt) > TRUNC(SYSDATE)), set po_err_cd = 1 ('Active Old MCP already available') and return.
- Step 6 - Check AM_LIST_RANGE for an active SMP_EXCEPTION entry matching pn_pmc and lv_model_cd. If found (lv_excp_yn = 'Y'), set po_err_cd = 1 with the exception model description and return.
- Step 7 - Check VM_RESTRICTED_VIN for lv_vin where active_yn = 'Y' and approve_yn = 'Y'. If found (lv_rest_yn = 'Y'), set po_err_cd = 1 ('Restricted Vehicle') and return.
- Step 8 - Determine the vehicle category (lv_vtype: 'COM' or non-COM) by calling PKG_SMP.SF_FLEET_CHECK (SP-018) with pn_pmc, lv_vin, and lv_variant.
- Step 9 - Query VM_SMP_PARAM for the maximum validity_months (ln_val_mon), validity_mileage (ln_val_mil), and no_of_serv (ln_srv_no) applicable to pn_pmc, lv_vtype, and the current date window.
- Step 10 - Compare ln_veh_age against ln_val_mon; if exceeded, set po_err_cd = 1 ('vehicle Age greater than N months') and return.
- Step 11 - Compare ln_odometer against ln_val_mil; if exceeded, set po_err_cd = 1 ('Mileage expired') and return.
- Step 12 - Determine the current pending sub-service position (lv_csubsrv) by calling GET_SUB_SRV_RCATEG_DESC with the effective odometer (COALESCE of pn_odm, ln_odometer, ln_val_mil), service category 'PMS', lv_vin, and pn_pmc. Extract the numeric suffix into ln_csubsrv.
- Step 13 - If ln_csubsrv exceeds (ln_srv_no - 1), set po_err_cd = 1 ('No Pending Service') and return.
- Step 14 - Query VH_RO for the most recent completed repair order (ro_status IN ('30','40')) with a valid sub_rcateg_cd whose rcateg_cd is listed in AM_LIST under 'SMP_SERVTYPE' for pn_pmc. Extract the numeric suffix into ln_rsubsrv.
- Step 15 - If ln_rsubsrv ≥ (ln_srv_no - 1), set po_err_cd = 1 (service already done) and return.
- Step 16 - Set po_sub_srv to whichever sub-service position is higher: lv_rsubsrv (if ln_rsubsrv ≥ ln_csubsrv) or lv_csubsrv otherwise.
- Step 17 - If lv_smp_num is not NULL, query VH_AMC_ENROL for the active (cancel_yn = 'N') enrolment range (lv_fsubsrv, lv_tsubsrv). If ln_tsubsrv ≥ ln_fsubsrv (derived from po_sub_srv), set po_err_cd = 1 ('Active SMP already available ... Service X To Y'), clear po_sub_srv, and return.
- Step 18 - Assign po_val_age = ln_val_mon, po_val_mil = ln_val_mil, po_srv_no = ln_srv_no.
- Step 19 - Validate discount configuration in VM_SMP_DISC. For 'COM' vehicles, check rcateg_cd IN ('PMS','CVMS') and lv_variant; set po_cds_yn = 'N'. For non-COM vehicles, check rcateg_cd IN ('PMS','CDS') and lv_variant. If no discount record exists in either branch, set po_err_cd = 1 ('SMP not defined for Specific Vehicle Model') and return.
- Step 20 - For non-COM vehicles, determine po_cds_yn based on lv_model_cd and ln_csubsrv: 'N' for model 'CA'; for models 'VR'/'R', 'Y' if ln_csubsrv is between 2 and 9 inclusive, else 'N'; for all other models, 'Y' if ln_csubsrv is between 8 and 9 inclusive, else 'N'.
- Step 21 - Set po_smp_yn = 'Y' if po_err_cd = 0, otherwise 'N'.

---
**Decision Points**

DP-001

Condition:
pn_vin IS NULL

TRUE:
Set po_err_cd = 1, po_err_msg = 'Enter a valid VIN', and return immediately.

FALSE:
Proceed to call SP_VALIDATE_OEMVIN to resolve the canonical VIN.

---

DP-002

Condition:
SP_VALIDATE_OEMVIN returns po_err_cd = 1

TRUE:
Return immediately, propagating the error from SP_VALIDATE_OEMVIN.

FALSE:
Continue to query GM_VIN with the resolved lv_vin.

---

DP-003

Condition:
GM_VIN query raises an exception (NO_DATA_FOUND, TOO_MANY_ROWS, VALUE_ERROR, or OTHERS) or ld_inv_dt IS NULL

TRUE:
Set po_err_cd = 1 with the appropriate message and return.

FALSE:
Continue to the active SMP check.

---

DP-004

Condition:
TRUNC(ld_amc_exdt) > TRUNC(SYSDATE) AND ld_amc_exdt IS NOT NULL

TRUE:
Set po_err_cd = 1 ('Active Old MCP already available') and return.

FALSE:
Continue to the SMP exception model check.

---

DP-005

Condition:
AM_LIST_RANGE contains an active SMP_EXCEPTION record matching pn_pmc and lv_model_cd (lv_excp_yn = 'Y')

TRUE:
Set po_err_cd = 1 ('SMP cannot be issued against [model]') and return.

FALSE:
Continue to the restricted VIN check.

---

DP-006

Condition:
VM_RESTRICTED_VIN contains an active and approved record for lv_vin (lv_rest_yn = 'Y')

TRUE:
Set po_err_cd = 1 ('Restricted Vehicle can not be considered for SMP') and return.

FALSE:
Continue to vehicle type and SMP parameter retrieval.

---

DP-007

Condition:
ln_veh_age > ln_val_mon (vehicle age in months exceeds the configured validity period)

TRUE:
Set po_err_cd = 1 ('SMP cannot be issued for vehicle Age greater than N months') and return.

FALSE:
Continue to the odometer check.

---

DP-008

Condition:
ln_odometer > ln_val_mil (last recorded odometer exceeds the configured mileage limit)

TRUE:
Set po_err_cd = 1 ('Mileage expired') and return.

FALSE:
Continue to pending sub-service position determination.

---

DP-009

Condition:
ln_csubsrv > NVL(ln_srv_no, 10) - 1 (current sub-service position exceeds the last serviceable position)

TRUE:
Set po_err_cd = 1 ('No Pending Service') and return.

FALSE:
Continue to the billed sub-service check against VH_RO.

---

DP-010

Condition:
ln_rsubsrv ≥ NVL(ln_srv_no, 10) - 1 (most recently billed sub-service meets or exceeds the last serviceable position)

TRUE:
Set po_err_cd = 1 ('[sub-service] Service done, So Vehicle can not be considered for SMP') and return.

FALSE:
Set po_sub_srv to the higher of lv_rsubsrv and lv_csubsrv and continue.

---

DP-011

Condition:
ln_rsubsrv ≥ ln_csubsrv

TRUE:
Set po_sub_srv = lv_rsubsrv (use the billed sub-service position).

FALSE:
Set po_sub_srv = lv_csubsrv (use the odometer-derived sub-service position).

---

DP-012

Condition:
lv_smp_num IS NOT NULL and an active VH_AMC_ENROL record exists where ln_tsubsrv ≥ NVL(ln_fsubsrv, 1)

TRUE:
Clear po_sub_srv, set po_err_cd = 1 ('Active SMP already available ... Service X To Y'), and return.

FALSE:
Continue to assign validity output parameters.

---

DP-013

Condition:
lv_vtype = 'COM'

TRUE:
Check VM_SMP_DISC for rcateg_cd IN ('PMS','CVMS') and lv_variant; set po_cds_yn = 'N'. If no record found, set po_err_cd = 1 and return.

FALSE:
Check VM_SMP_DISC for rcateg_cd IN ('PMS','CDS') and lv_variant; then apply model-specific CDS eligibility logic (DP-014 through DP-016).

---

DP-014

Condition:
lv_model_cd = 'CA' (non-COM path)

TRUE:
Set po_cds_yn = 'N'.

FALSE:
Evaluate whether lv_model_cd is in ('VR','R') to determine CDS eligibility thresholds (DP-015).

---

DP-015

Condition:
lv_model_cd IN ('VR','R') (non-COM, non-CA path)

TRUE:
Apply lower CDS threshold: set po_cds_yn = 'Y' if NVL(ln_csubsrv,1) ≥ 2 AND < 10, else 'N' (DP-016a).

FALSE:
Apply standard CDS threshold: set po_cds_yn = 'Y' if NVL(ln_csubsrv,1) ≥ 8 AND < 10, else 'N' (DP-016b).

---

DP-016a

Condition:
NVL(ln_csubsrv,1) ≥ 2 AND NVL(ln_csubsrv,1) < 10 (models VR/R)

TRUE:
Set po_cds_yn = 'Y'.

FALSE:
Set po_cds_yn = 'N'.

---

DP-016b

Condition:
NVL(ln_csubsrv,1) ≥ 8 AND NVL(ln_csubsrv,1) < 10 (all other non-COM, non-CA models)

TRUE:
Set po_cds_yn = 'Y'.

FALSE:
Set po_cds_yn = 'N'.

---

DP-017

Condition:
NVL(po_err_cd, 0) = 0 after all checks

TRUE:
Set po_smp_yn = 'Y' (vehicle is eligible for SMP).

FALSE:
Set po_smp_yn = 'N' (vehicle is not eligible).

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read GM_VIN_EXT - Reads data from GM_VIN_EXT for lookup or validation.
- DB-003 - Read AM_LIST_RANGE - Reads data from AM_LIST_RANGE for lookup or validation.
- DB-004 - Read VM_RESTRICTED_VIN - Reads data from VM_RESTRICTED_VIN for lookup or validation.
- DB-005 - Read VM_SMP_PARAM - Reads data from VM_SMP_PARAM for lookup or validation.
- DB-006 - Read VH_RO - Reads data from VH_RO for lookup or validation.
- DB-007 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
- DB-008 - Read VH_AMC_ENROL - Reads data from VH_AMC_ENROL for lookup or validation.
- DB-009 - Read VM_SMP_DISC - Reads data from VM_SMP_DISC for lookup or validation.
**Business Rules**

- BR-001 - A VIN must be provided; a NULL VIN immediately disqualifies the request.
- BR-002 - The submitted VIN must pass OEM VIN validation via SP_VALIDATE_OEMVIN (SP-043) before any further checks are performed; the canonical internal VIN (lv_vin) returned by that routine is used for all subsequent lookups.
- BR-003 - The vehicle must exist in GM_VIN with a single matching record and a non-NULL invoice date; absence, ambiguity, or a missing invoice date disqualifies the vehicle.
- BR-004 - A vehicle that already has an active MCP/AMC (GM_VIN_EXT.amc_exp_date is in the future) cannot receive a new SMP.
- BR-005 - A vehicle whose model code appears in the active SMP_EXCEPTION list (AM_LIST_RANGE) for the given principal mapping code is ineligible for SMP issuance.
- BR-006 - A vehicle flagged as both active and approved in VM_RESTRICTED_VIN is ineligible for SMP issuance.
- BR-007 - Vehicle category (commercial 'COM' vs. non-commercial) is determined by PKG_SMP.SF_FLEET_CHECK (SP-018) and governs which SMP parameters and discount records apply.
- BR-008 - SMP validity parameters (maximum age in months, maximum mileage, and total number of services) are sourced from VM_SMP_PARAM for the matching principal mapping code, vehicle category, and current date window.
- BR-009 - A vehicle whose age in months (calculated from invoice date to SYSDATE) exceeds the configured validity_months is ineligible for SMP.
- BR-010 - A vehicle whose last recorded odometer reading exceeds the configured validity_mileage is ineligible for SMP.
- BR-011 - The effective odometer used for sub-service position calculation is the first non-NULL value among pn_odm, ln_odometer, and ln_val_mil (COALESCE order).
- BR-012 - A vehicle has no pending services-and is therefore ineligible-if its current sub-service position (ln_csubsrv) exceeds (no_of_serv - 1).
- BR-013 - The most recently billed sub-service is determined from VH_RO by selecting the latest ro_date where ro_status is '30' or '40' and rcateg_cd is listed under 'SMP_SERVTYPE' in AM_LIST for the principal mapping code.
- BR-014 - If the most recently billed sub-service position (ln_rsubsrv) meets or exceeds (no_of_serv - 1), the vehicle is ineligible because the final covered service has already been performed.
- BR-015 - The sub-service position assigned to the new SMP (po_sub_srv) is the higher of the odometer-derived position (lv_csubsrv) and the billed position (lv_rsubsrv).
- BR-016 - If an existing active SMP enrolment in VH_AMC_ENROL already covers the derived sub-service position (ln_tsubsrv ≥ ln_fsubsrv), the vehicle cannot receive a new SMP for that range.
- BR-017 - A discount configuration record must exist in VM_SMP_DISC for the vehicle's variant; absence of such a record means SMP is not defined for that vehicle model and issuance is blocked.
- BR-018 - For commercial vehicles (lv_vtype = 'COM'), the CDS indicator (po_cds_yn) is always set to 'N'; the discount check uses service categories 'PMS' and 'CVMS'.
- BR-019 - For non-commercial vehicles, the discount check uses service categories 'PMS' and 'CDS'. Model 'CA' always yields po_cds_yn = 'N'. Models 'VR' and 'R' yield po_cds_yn = 'Y' only when the current sub-service position is between 2 and 9 inclusive. All other non-commercial models yield po_cds_yn = 'Y' only when the current sub-service position is between 8 and 9 inclusive.
- BR-020 - po_smp_yn is set to 'Y' only when all preceding checks pass without error (po_err_cd = 0); any single failure results in po_smp_yn = 'N'.

---
**Implementation Logic**

```plsql

  PROCEDURE SP_VIN_VALIDATE(pn_pmc     NUMBER,
                            pn_vin     VARCHAR2,
                            pn_odm     NUMBER,
                            po_smp_yn  OUT VARCHAR2,
                            po_val_mil OUT NUMBER,
                            po_val_age OUT NUMBER,
                            po_srv_no  OUT NUMBER,
                            po_sub_srv OUT VARCHAR2,
                            po_cds_yn  OUT VARCHAR2,
                            po_err_cd  OUT NUMBER,
                            po_err_msg OUT VARCHAR2
                            )
   IS
    lv_vin      gm_vin.vin%TYPE;
    lv_oem_vin  gm_vin_ext.oem_vin_number%TYPE;
    ld_inv_dt   gm_vin.inv_date%TYPE;
    ln_odometer gm_vin.last_ro_odometer_reading%TYPE;
    lv_model_cd gm_vin.model_cd%TYPE;
    lv_variant  gm_vin.variant_cd%TYPE;
    ln_val_mon  vm_smp_param.validity_months%TYPE;
    ln_val_mil  vm_smp_param.validity_mileage%TYPE;
    ln_srv_no   vm_smp_param.no_of_serv%TYPE;
    lv_smp_num  gm_vin_ext.msmp_num%TYPE;
    ld_amc_exdt gm_vin_ext.amc_exp_date%type;
    lv_fsubsrv  vh_amc_enrol.from_subsrv%TYPE;
    lv_tsubsrv  vh_amc_enrol.to_subsrv%TYPE;
    lv_excp_mod am_list_range.list_desc%TYPE;

    ln_veh_age  NUMBER;
    lv_excp_yn  VARCHAR2(1);
    lv_rest_yn  VARCHAR2(1);
    lv_vtype    VARCHAR2(5);
    lv_csubsrv  VARCHAR2(5);
    ln_csubsrv  NUMBER;
    lv_rsubsrv  VARCHAR2(5);
    ln_rsubsrv  NUMBER;
    lv_disc_yn  VARCHAR2(1);
    ln_fsubsrv  NUMBER;
    ln_tsubsrv  NUMBER;
  BEGIN
    po_err_cd  := 0;
    po_err_msg := NULL;
    po_smp_yn  := 'N';
    ln_veh_age := 0;
    lv_excp_yn := 'N';
    lv_rest_yn := 'N';
    lv_vtype   := NULL;
    lv_csubsrv := NULL;
    ln_csubsrv := 1;
    lv_rsubsrv := NULL;
    ln_rsubsrv := 1;
    lv_disc_yn := 'N';

    -- Check VIN
    IF pn_vin IS NULL THEN
      po_err_cd  := 1;
      po_err_msg := 'Enter a valid VIN';
      RETURN;
    ELSE
      BEGIN
        -- Check OEM VIN
        SP_VALIDATE_OEMVIN(pn_vin,
                           lv_vin,
                           lv_oem_vin,
                           po_err_cd,
                           po_err_msg);
      END;
      IF NVL(po_err_cd, 0) = 1 THEN
        RETURN;
      ELSE
        NULL;
      END IF;

      BEGIN
        SELECT inv_date,
               MONTHS_BETWEEN(SYSDATE, inv_date),
               NVL(last_ro_odometer_reading, 0),
               model_cd, variant_cd
          INTO ld_inv_dt, ln_veh_age, ln_odometer, lv_model_cd, lv_variant
          FROM gm_vin
         WHERE vin = lv_vin;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          po_err_cd  := 1;
          po_err_msg := 'VIN not found';
        WHEN TOO_MANY_ROWS THEN
          po_err_cd  := 1;
          po_err_msg := 'More than one Records found in Vehicle Master';
        WHEN VALUE_ERROR THEN
          po_err_cd  := 1;
          po_err_msg := 'Width problem/Incompatible data for fetching the Details';
        WHEN OTHERS THEN
          po_err_cd  := 1;
          po_err_msg := 'Execution failed to fetch details : ' || SQLERRM;
      END;
      -- Check vehicle invoice date
      IF ld_inv_dt IS NULL THEN
        po_err_cd  := 1;
        po_err_msg := 'Vehicle invoice date is not available';
      END IF;
      IF po_err_cd = 1 THEN
        RETURN;
      END IF;
    END IF;

    -- Check Active SMP
    BEGIN
      SELECT msmp_num, amc_exp_date
        INTO lv_smp_num, ld_amc_exdt
        FROM gm_vin_ext
       WHERE vin = lv_vin;
    EXCEPTION WHEN OTHERS THEN
      lv_smp_num := NULL;
    END;
    IF TRUNC(ld_amc_exdt) > TRUNC(SYSDATE) AND ld_amc_exdt IS NOT NULL THEN
       po_err_cd  := 1;
       po_err_msg := 'Active Old MCP already available against the Vehicle';
       RETURN;
    END IF;

    -- Check exception
    BEGIN
      SELECT 'Y', list_desc
        INTO lv_excp_yn, lv_excp_mod
        FROM am_list_range
       WHERE PRINCIPAL_MAP_CD = pn_pmc
         AND list_name = 'SMP_EXCEPTION'
         AND list_code = lv_model_cd
         AND NVL(list_flag, 'Y') = 'Y'
         AND NVL(close_date, SYSDATE) >= SYSDATE;
    EXCEPTION
      WHEN OTHERS THEN
        lv_excp_yn := 'N';
    END;

    IF NVL(lv_excp_yn, 'N') = 'Y' THEN
      po_err_cd  := 1;
      po_err_msg := 'SMP cannot be issued against '||lv_excp_mod||' model';
      RETURN;
    END IF;

    -- Check Restricted VIN
    BEGIN
      SELECT 'Y'
        INTO lv_rest_yn
        FROM vm_restricted_vin v
       WHERE v.vin = lv_vin
         AND NVL(v.active_yn, 'N') = 'Y'
         AND NVL(v.approve_yn, 'N') = 'Y';
    EXCEPTION
      WHEN OTHERS THEN
        lv_rest_yn := 'N';
    END;
    IF NVL(lv_rest_yn, 'N') = 'Y' THEN
      po_err_cd  := 1;
      po_err_msg := 'Restricted Vehicle can not be considered for SMP';
      RETURN;
    END IF;

    -- Check Vehicle type
    lv_vtype := SF_FLEET_CHECK(pn_pmc, lv_vin, lv_variant);
    BEGIN
      SELECT MAX(validity_months), MAX(validity_mileage), MAX(no_of_serv)
        INTO ln_val_mon, ln_val_mil, ln_srv_no
        FROM vm_smp_param
       WHERE principal_map_cd = pn_pmc
         AND TRUNC(SYSDATE) BETWEEN TRUNC(valid_from_date) AND
             NVL(TRUNC(valid_to_date), TRUNC(SYSDATE))
         AND veh_categ = lv_vtype;
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    IF ln_veh_age > ln_val_mon THEN
      po_err_cd  := 1;
      po_err_msg := 'SMP cannot be issued for vehicle Age greater than ' ||
                    ln_val_mon || ' months';
      RETURN;
    END IF;
    IF ln_odometer > ln_val_mil THEN
      po_err_cd  := 1;
      po_err_msg := 'Milease expired, So Vehicle can not be considered for SMP';
      RETURN;
    END IF;

    -- Check pending sub service
    BEGIN
      lv_csubsrv := GET_SUB_SRV_RCATEG_DESC(COALESCE(pn_odm,
                                                     ln_odometer,
                                                     ln_val_mil),
                                            'PMS',
                                            lv_vin,
                                            pn_pmc);
    EXCEPTION WHEN OTHERS THEN
      lv_csubsrv := NULL;
    END;

    IF lv_csubsrv IS NOT NULL THEN
      ln_csubsrv := SUBSTR(lv_csubsrv, 4);
    END IF;
    --DBMS_OUTPUT.PUT_LINE(lv_csubsrv||' - '||ln_csubsrv);
    IF ln_csubsrv > NVL(ln_srv_no, 10) - 1 THEN
      po_err_cd  := 1;
      po_err_msg := 'No Pending Service, So Vehicle can not be considered for SMP';
      RETURN;
    ELSE
      -- Check bill SMP sub service type
      BEGIN
        SELECT r.sub_rcateg_cd
          INTO lv_rsubsrv
          FROM vh_ro r
         WHERE r.vin = lv_vin
           AND r.ro_status IN ('30', '40')
           AND r.sub_rcateg_cd IS NOT NULL
           AND r.rcateg_cd IN
               (SELECT l.list_code
                  FROM am_list l
                 WHERE l.principal_map_cd = pn_pmc
                   AND l.list_name = 'SMP_SERVTYPE'
                   AND NVL(l.list_flag, 'Y') = 'Y')
           AND r.ro_date =
               (SELECT MAX(r1.ro_date)
                  FROM vh_ro r1
                 WHERE r1.vin = r.vin
                   AND r1.ro_status IN ('30', '40')
                   AND r1.sub_rcateg_cd IS NOT NULL
                   AND r1.rcateg_cd IN
                       (SELECT l.list_code
                          FROM am_list l
                         WHERE l.principal_map_cd = pn_pmc
                           AND l.list_name = 'SMP_SERVTYPE'
                           AND NVL(l.list_flag, 'Y') = 'Y'));
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
      IF lv_rsubsrv IS NOT NULL THEN
        ln_rsubsrv := SUBSTR(lv_rsubsrv, 4);
      END IF;
      IF ln_rsubsrv >= NVL(ln_srv_no, 10) - 1 THEN
        po_err_cd  := 1;
        po_err_msg := lv_rsubsrv ||' Service done, So Vehicle can not be considered for SMP'; -- || lv_vtype || ln_srv_no;
        RETURN;
      END IF;
      IF ln_rsubsrv >= ln_csubsrv THEN
        po_sub_srv := lv_rsubsrv;
      ELSE
        po_sub_srv := lv_csubsrv;
      END IF;

      --DBMS_OUTPUT.PUT_LINE('Step 1 :: '||' - '||lv_rsubsrv||' - '||lv_csubsrv ||' - '|| po_sub_srv);
      -- Check Active SMP
      IF lv_smp_num IS NOT NULL THEN
        BEGIN
          BEGIN
            SELECT from_subsrv, to_subsrv
              INTO lv_fsubsrv, lv_tsubsrv
              FROM vh_amc_enrol
             WHERE principal_map_cd = pn_pmc
               AND amc_num = lv_smp_num
               AND NVL(cancel_yn, 'N') = 'N';
          EXCEPTION WHEN OTHERS THEN
            NULL;
          END;
          ln_fsubsrv := SUBSTR(po_sub_srv, 4);
          ln_tsubsrv := SUBSTR(lv_tsubsrv, 4);
          --DBMS_OUTPUT.PUT_LINE(ln_fsubsrv||' - '||ln_tsubsrv);
          IF ln_tsubsrv >= NVL(ln_fsubsrv,1) THEN
            po_sub_srv := NULL;
            po_err_cd  := 1;
            po_err_msg := 'Active SMP already available against the Vehicle for Service '||lv_fsubsrv||' To '||lv_tsubsrv;
            RETURN;
          END IF;
        END;
      END IF;

    END IF;

    po_val_age := ln_val_mon;
    po_val_mil := ln_val_mil;
    po_srv_no  := ln_srv_no;

    IF lv_vtype = 'COM' THEN
      BEGIN
        SELECT 'Y' INTO lv_disc_yn
          FROM vm_smp_disc
         WHERE principal_map_cd = pn_pmc
           AND rcateg_cd IN ('PMS', 'CVMS')
           AND variant = lv_variant
           --AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
           AND ROWNUM = 1;
      EXCEPTION WHEN OTHERS THEN
        po_err_cd  := 1;
        po_err_msg := 'SMP not defined for Specific Vehicle Model';
        RETURN;
      END;
      po_cds_yn := 'N';
    ELSE
      BEGIN
        SELECT 'Y' INTO lv_disc_yn
          FROM vm_smp_disc
         WHERE principal_map_cd = pn_pmc
           AND rcateg_cd IN ('PMS', 'CDS')
           AND variant = lv_variant
           --AND TRUNC(SYSDATE) BETWEEN from_date AND NVL(to_date, TRUNC(SYSDATE))
           AND ROWNUM = 1;
      EXCEPTION WHEN OTHERS THEN
        po_err_cd  := 1;
        po_err_msg := 'SMP not defined for Specific Vehicle Model';
        RETURN;
      END;

      IF lv_model_cd = 'CA' THEN
        po_cds_yn := 'N';
      ELSE
        IF lv_model_cd IN ('VR', 'R') THEN
          IF NVL(ln_csubsrv, 1) >= 2 AND NVL(ln_csubsrv, 1) < 10 THEN
            po_cds_yn := 'Y';
          ELSE
            po_cds_yn := 'N';
          END IF;
        ELSE
          IF NVL(ln_csubsrv, 1) >= 8 AND NVL(ln_csubsrv, 1) < 10 THEN
            po_cds_yn := 'Y';
          ELSE
            po_cds_yn := 'N';
          END IF;
        END IF;
      END IF;
    END IF;

    IF NVL(po_err_cd, 0) = 0 THEN
      po_smp_yn := 'Y';
    ELSE
      po_smp_yn := 'N';
    END IF;
  END;
```

#### SP-028 - PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: FT_SAVE]

---

**Screen:**

N/A

---

**Purpose**

Generates the next sequential document number for a given dealer, principal, location, company, document type, and financial year combination. The procedure retrieves the current document number record from AM_DOCS with a pessimistic lock, increments the sequence counter, constructs the formatted document number by concatenating the prefix, suffix, and zero-padded numeric counter, and writes the updated counter and last document date back to AM_DOCS. The result is returned to the caller via the output parameter po_doc_num, with any error condition signalled through po_error and po_err_msg.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer_map_cd | NUMBER | IN |
| pi_principal_map_cd | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_doc_type | VARCHAR2 | IN |
| pi_fin_yr | NUMBER | IN |
| pi_last_doc_date | DATE | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_doc_num | VARCHAR2 | OUT |
| po_err_msg | VARCHAR2 | OUT |
| po_error | NUMBER | OUT |

---

**Dependencies**

- WEBUTIL.PUT_LINE ([SP-033](#SP-033--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WAIT ([SP-035](#SP-035--WEBUTIL.WAIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept all input parameters: dealer map code, principal map code, location code, company/FA indicator, document type, financial year, and last document date (defaults to SYSDATE if not supplied).
- Step 2 - Query AM_DOCS for the single row matching all six key attributes (dealer_map_cd, principal_map_cd, loc_cd, comp_fa, doc_type, Fin_Year) and acquire a pessimistic row-level lock using FOR UPDATE WAIT 5, retrieving doc_prefix, doc_num, doc_suffix, and the physical ROWID into local variables.
- Step 3 - Handle inner query exceptions: if no matching row is found, set po_error = 1 and append 'Type not defined in the document master' to po_err_msg; if multiple rows are found, set po_error = 1 and append 'Duplicate rows in the document master'; if SQLCODE = -54 (lock timeout), set po_error = 1 and set po_err_msg to 'Record is used by another user. Please Re-try'; for any other Oracle error, set po_error = 1 and append the SQLERRM text.
- Step 4 - Check whether po_error is still NULL or 0 (i.e., no error was raised in Step 3). If no error exists, increment the retrieved numeric counter by 1 (lv_doc_num := lv_doc_num + 1).
- Step 5 - Construct the formatted document number by concatenating lv_doc_prefix, lv_doc_suffix, and the incremented lv_doc_num left-padded to six digits with zeros, and assign the result to po_doc_num.
- Step 6 - Update the locked AM_DOCS row (identified by ROWID) with the new doc_num value and pi_last_doc_date.
- Step 7 - If an unhandled exception propagates to the outer block, set po_error = 1, append SQLERRM to po_err_msg, and emit a debug line via DBMS_OUTPUT.

---
**Decision Points**

DP-001

Condition: The SELECT FOR UPDATE WAIT 5 query against AM_DOCS returns exactly one row without a lock conflict.

TRUE: Local variables lv_doc_prefix, lv_doc_num, lv_doc_suffix, and lv_rowid are populated; processing continues to DP-002.

FALSE: An exception is raised - NO_DATA_FOUND, TOO_MANY_ROWS, lock timeout (SQLCODE -54), or another Oracle error - po_error is set to 1 and an appropriate message is written to po_err_msg; the increment and update steps are skipped.

---

DP-002

Condition: NVL(po_error, 0) <> 1 (i.e., no error was recorded during the SELECT FOR UPDATE phase).

TRUE: The numeric counter is incremented, the formatted document number is assembled and assigned to po_doc_num, and AM_DOCS is updated with the new doc_num and last_doc_date.

FALSE: The increment, formatting, and UPDATE steps are bypassed entirely; the procedure exits with the error state already set.

---

DP-003

Condition: Within the WHEN OTHERS handler of the inner block, SQLCODE = -54 (lock acquisition timeout after 5 seconds).

TRUE: po_err_msg is set to the specific concurrency message 'Record is used by another user. Please Re-try'.

FALSE: po_err_msg is set to the generic message 'Execution failed while trying to access the record' concatenated with SQLERRM.

---
**Database Interactions**

- DB-001 - Read AM_DOCS - Reads data from AM_DOCS (columns: doc num, last doc date) for lookup or validation.
- DB-002 - Update WAIT - Updates existing rows in WAIT.
- DB-003 - Update AM_DOCS - Updates existing rows in AM_DOCS (columns: doc num, last doc date).
**Business Rules**

- BR-001 - A document number may only be generated when exactly one AM_DOCS row exists for the combination of dealer_map_cd, principal_map_cd, loc_cd, comp_fa, doc_type, and Fin_Year; zero matches or multiple matches both constitute configuration errors and abort generation.
- BR-002 - The AM_DOCS row must be exclusively locked before the counter is read and incremented; the procedure waits up to 5 seconds for the lock. If the lock cannot be acquired within that window (ORA-00054), generation is aborted and the caller is instructed to retry, preventing concurrent duplicate number assignment.
- BR-003 - The document number is formatted as the concatenation of doc_prefix + doc_suffix + the incremented doc_num left-padded to exactly six digits with leading zeros, ensuring a consistent, fixed-width document number string.
- BR-004 - The numeric counter stored in AM_DOCS is always incremented by exactly 1 per successful call, guaranteeing a gapless sequential series within each prefix/suffix/financial-year combination, provided no errors occur.
- BR-005 - The last_doc_date column in AM_DOCS is updated to pi_last_doc_date on every successful number generation, recording the date of the most recently issued document; if the caller does not supply this parameter, it defaults to SYSDATE.
- BR-006 - Error state is communicated exclusively through the output parameters po_error (set to 1 on any failure) and po_err_msg (cumulative error description); no exceptions are re-raised to the caller, ensuring the invoking trigger (FT_SAVE) receives a controlled response.

---
**Implementation Logic**

```plsql
      PROCEDURE Generate_Next_Num (
            pi_dealer_map_cd      IN       NUMBER,
            pi_principal_map_cd   IN       NUMBER,
            pi_loc_cd             IN       VARCHAR2,
            pi_comp_fa            IN       VARCHAR2,
            pi_doc_type           IN       VARCHAR2,
            po_doc_num            OUT      VARCHAR2,
            po_err_msg            OUT      VARCHAR2,
            po_error              OUT      NUMBER,
            pi_fin_yr             IN       NUMBER,
            pi_last_doc_date      IN       DATE DEFAULT SYSDATE
      )
      IS
            lv_doc_prefix   VARCHAR2 (4);
            lv_doc_num      NUMBER (6);
            lv_doc_suffix   VARCHAR2 (2);
            lock_found      EXCEPTION;
            lv_year         VARCHAR2 (1);
            lv_rowid        ROWID;
            PRAGMA EXCEPTION_INIT (lock_found, -54);
            v_sql           VARCHAR2 (2000);
      BEGIN

            BEGIN

                  SELECT     doc_prefix,
                             doc_num,
                             doc_suffix,
                             ROWID
                        INTO lv_doc_prefix,
                             lv_doc_num,
                             lv_doc_suffix,
                             lv_rowid
                        FROM AM_DOCS
                       WHERE dealer_map_cd = pi_dealer_map_cd
                         AND principal_map_cd = pi_principal_map_cd
                         AND loc_cd = pi_loc_cd
                         AND comp_fa = pi_comp_fa
                         AND doc_type = pi_doc_type
                         AND Fin_Year = pi_fin_yr
                  FOR UPDATE WAIT 5;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Type not defined in the document master';
                  WHEN TOO_MANY_ROWS THEN
                        po_error := 1;
                        po_err_msg := po_err_msg || ' Duplicate rows in the document master';
                  WHEN OTHERS THEN
                        po_error := 1;

                        IF SQLCODE = -54 THEN                                                             ---IN (-30006,-54) THEN
                              po_err_msg := 'Record is used by another user.Please Re-try';
                        ---RAISE_APPLICATION_ERROR(-54,'Record is used by another user.Please Re-try');
                        ELSE
                              po_err_msg := 'Execution failed while trying to access the record ' || SQLERRM;
                        END IF;
            END;

            /*EXECUTE IMMEDIATE v_sql
                         INTO lv_doc_prefix,
                              lv_doc_num,
                              lv_doc_suffix,
                              lv_rowid
                        USING pi_dealer_map_cd, pi_principal_map_cd, pi_loc_cd, pi_comp_fa, pi_doc_type, pi_fin_yr;*/
            IF NVL ( po_error, 0) <> 1 THEN
                  lv_doc_num := lv_doc_num + 1;
                  po_doc_num := lv_doc_prefix || lv_doc_suffix || LPAD (lv_doc_num, 6, '0');

                  UPDATE AM_DOCS
                     SET doc_num = lv_doc_num,
                         last_doc_date = pi_last_doc_date
                   WHERE ROWID = lv_rowid;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Type not defined in the document master';
            WHEN TOO_MANY_ROWS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || ' Duplicate rows in the document master';
            WHEN OTHERS THEN
                  po_error := 1;
                  po_err_msg := po_err_msg || SQLERRM;
                  DBMS_OUTPUT.put_line ('ERRORCD' || po_error);
      END Generate_Next_Num;
```

#### SP-029 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the error text is presented in a modal alert dialog; otherwise it falls back to the Oracle Forms MESSAGE built-in. This procedure is primarily used to surface BEAN_NOT_REGISTERED or bean-not-found errors during WebUtil operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-031](#SP-031--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message text via the errText input parameter.
- Step 2 - Call WEBUTIL.ID_NULL (SP-031) to evaluate whether the module-level alert handle m_errorAlert is a valid, registered alert object.
- Step 3 - If m_errorAlert is valid (not null), set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 4 - Display the configured alert dialog to the user by calling SHOW_ALERT; the return value is captured in the local variable 'ignore' and discarded.
- Step 5 - If m_errorAlert is not valid (null/unregistered), fall back to the Oracle Forms MESSAGE built-in, prefixing the error text with 'WebUtil Error: ' and displaying it in the Forms status bar.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert is a valid, registered alert object.

TRUE:
Set the alert message text to errText via SET_ALERT_PROPERTY and display the alert dialog via SHOW_ALERT. The user sees a modal WebUtil Error alert.

FALSE:
Bypass the alert dialog and display the error using the Oracle Forms MESSAGE built-in, formatted as 'WebUtil Error: <errText>'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure is exclusively used to report WebUtil-specific errors, particularly BEAN_NOT_REGISTERED and bean-not-found conditions; it must not be repurposed for general application messaging.
- BR-002 - The validity of the alert handle m_errorAlert must be determined by calling WEBUTIL.ID_NULL (SP-031) before any attempt is made to interact with the alert object, preventing runtime errors from an unregistered handle.
- BR-003 - The alert title is not overwritten at runtime; it is assumed to be pre-configured in the alert's design-time properties, ensuring consistent branding of the error dialog.
- BR-004 - The return value of SHOW_ALERT is intentionally discarded (assigned to 'ignore'), meaning no branching logic is applied based on the user's button selection; the alert serves as an informational notification only.
- BR-005 - When the alert handle is unavailable, the fallback message must be prefixed with 'WebUtil Error: ' to maintain consistent error identification for the end user.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-030 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class entry for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameter `packageID` (PLS_INTEGER), which identifies the WebUtil package whose implementation class is required.
- Step 2 - Look up the implementation class short name from the `m_implClasses` collection using `packageID` as the index key.
- Step 3 - Prepend the constant `WEBUTIL_JAVA_ROOT` to the retrieved class short name to form the fully qualified Java class path.
- Step 4 - Return the concatenated fully qualified class name string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic lookup and concatenation with no branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The `packageID` supplied by the caller must correspond to a valid index in the `m_implClasses` collection; an invalid or unregistered index will raise a runtime collection error.
- BR-002 - The fully qualified Java class name is always constructed by prefixing `WEBUTIL_JAVA_ROOT` to the stored implementation class entry, ensuring all resolved class paths share the same root namespace.
- BR-003 - This function has no database interactions and no external dependencies; its output is derived entirely from in-memory package-level state (`WEBUTIL_JAVA_ROOT` and `m_implClasses`).

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-031 - WEBUTIL.ID_NULL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle pointer is uninitialised (null) by inspecting its internal `hnd` attribute. Returns TRUE if the handle carries no reference and FALSE if a valid reference is present. This utility function is used by WEBUTIL.ERRORALERT to guard against operations on invalid or uninitialised handle pointers.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the `handle` Pointer passed by the caller (WEBUTIL.ERRORALERT).
- Step 2 - Inspect the `hnd` attribute of the supplied `handle` pointer.
- Step 3 - If `handle.hnd` is NULL, return TRUE to indicate that the handle is uninitialised.
- Step 4 - If `handle.hnd` is NOT NULL, return FALSE to indicate that the handle holds a valid reference.

---
**Decision Points**

DP-001

Condition:
`handle.hnd IS NULL`

TRUE:
Return TRUE - the handle is uninitialised and carries no valid reference.

FALSE:
Return FALSE - the handle contains a non-null reference and is considered valid.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle pointer is considered null (uninitialised) solely by evaluating its `hnd` attribute; no other attribute or external state is consulted.
- BR-002 - The function must return a BOOLEAN result for every possible input state; no exception path or default return is permitted to leave the caller without a definitive TRUE or FALSE answer.
- BR-003 - The function does not modify the supplied handle or any application state; it is a pure read-only predicate.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-032 - WEBUTIL.LENGTH

**Invoked From:**

- SP_VALIDATE_ALPHANUMERIC.prc [StoredProcedure: SP_VALIDATE_ALPHANUMERIC]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. This utility function wraps the Java native `java.io.File.length()` method via the Oracle JNI bridge, providing Oracle Forms PL/SQL code with the ability to determine the size of a client-side or server-side file. It is called by SP_VALIDATE_ALPHANUMERIC to support file-related validation logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (`obj`) passed in by the calling routine (SP_VALIDATE_ALPHANUMERIC).
- Step 2 - Clear the JNI argument list by setting `args` to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method `length()` on the supplied `java.io.File` object via `JNI.CALL_LONG_METHOD`, specifying the method signature `()J` (no parameters, returns a long integer).
- Step 4 - Return the numeric result (file size in bytes) to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. The implementation unconditionally clears the argument list, invokes the Java `length()` method, and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input parameter `obj` must be a valid `ORA_JAVA.JOBJECT` reference representing a `java.io.File` instance; passing a null or incompatible object will cause the JNI call to fail at runtime.
- BR-002 - The JNI argument list (`args`) must be reset to NULL before each invocation to prevent argument contamination from prior JNI calls.
- BR-003 - The function returns the file length as a NUMBER (mapped from the Java `long` primitive type); a return value of 0 indicates either an empty file or a file that does not exist, consistent with the behaviour of `java.io.File.length()`.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-033 - WEBUTIL.PUT_LINE

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil client bean via property-setting calls. If the required bean is not registered or a property error occurs, the procedure raises a Forms tool error to halt further processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-029](#SP-029--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-030](#SP-030--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-034](#SP-034--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target file handle (file.handle) and the text string (item) as inputs.
- Step 2 - Invoke WEBUTIL.SETPROPERTY (via WebUtil_Core.setProperty) to transmit the file handle to the client bean by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean.
- Step 3 - Invoke WEBUTIL.SETPROPERTY again to pass the text content to the client bean by setting the WUF_TEXTIO_PUT property.
- Step 4 - Invoke WEBUTIL.SETPROPERTY a third time to signal a newline by setting the WUF_TEXTIO_NEWLINE property to 1, causing the client bean to append a line terminator after the written text.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any property-setting call, invoke WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display an error message identifying the missing bean class (retrieved via WEBUTIL.GETIMPLCLASS) and advising that CLIENT_TEXT_IO.put_line will not work, then raise TOOL_ERR.TOOL_ERROR.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR directly without displaying an alert.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to set a WebUtil property (i.e., the required WUF_PACKAGE client bean is not registered in the current session).

TRUE:
Invoke WEBUTIL.ERRORALERT to display a descriptive message that includes the implementation class name (obtained via WEBUTIL.GETIMPLCLASS) and states that CLIENT_TEXT_IO.put_line will not work, then raise TOOL_ERR.TOOL_ERROR to abort processing.

FALSE:
Continue to the next property-setting step without interruption.

---

DP-002

Condition:
A PROPERTY_ERROR exception is raised when attempting to set a WebUtil property (i.e., the bean is registered but a property assignment fails).

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to abort processing; no alert is displayed.

FALSE:
All three property-setting calls complete successfully; the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A line write operation requires three sequential property-setting calls in order: file handle, text content, and newline flag; all three must succeed for the write to be considered complete.
- BR-002 - The newline flag must always be set to 1 when writing a line, ensuring the client bean appends a line terminator after every PUT_LINE invocation.
- BR-003 - If the WebUtil client bean is not registered, the procedure must surface an informative error message via WEBUTIL.ERRORALERT that identifies the missing bean class before raising a tool error, ensuring the developer or administrator can diagnose the deployment issue.
- BR-004 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions must result in TOOL_ERR.TOOL_ERROR being raised, preventing the calling routine (PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM) from continuing with a failed or partial file-write state.
- BR-005 - The procedure has no formal output parameters; all results are communicated to the client exclusively through the WebUtil bean property mechanism.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-034 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.PUT_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value by delegating to the Java Native Interface (JNI) layer. The function wraps the standard Java `System.setProperty` call, allowing Oracle Forms to read or influence JVM-level configuration properties at runtime. The previous property value is returned to the caller as a VARCHAR2 string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept two VARCHAR2 input parameters: `a0` (the property name/key) and `a1` (the value to assign to that property).
- Step 2 - Initialise a JNI argument list sized for exactly two arguments by calling `JNI.CREATE_ARG_LIST(2)`.
- Step 3 - Add the property name (`a0`) to the argument list as a String argument via `JNI.ADD_STRING_ARG`.
- Step 4 - Add the property value (`a1`) to the argument list as a second String argument via `JNI.ADD_STRING_ARG`.
- Step 5 - Invoke the Java static method `java.lang.System.setProperty(String, String)` through `JNI.CALL_STRING_METHOD`, passing the assembled argument list. The call targets the JVM class `java/lang/System` using the method descriptor `(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;`.
- Step 6 - Return the VARCHAR2 result received from the JNI call, which represents the previous value of the property (or NULL if the property was not previously set), to the invoking routine `WEBUTIL.PUT_LINE`.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed, unconditional sequence: build the JNI argument list, populate it, and invoke the Java method. All branching, if any, is handled internally by the JNI layer or the JVM.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name (`a0`) and property value (`a1`) must both be supplied as VARCHAR2 values; the function signature does not enforce NOT NULL, but passing NULL to `java.lang.System.setProperty` will cause the underlying JVM to raise a NullPointerException, resulting in a JNI-level error.
- BR-002 - Exactly two string arguments must be registered in the JNI argument list before the Java method is called; the list is explicitly created with a capacity of 2 to enforce this contract.
- BR-003 - The target Java method is always `java.lang.System.setProperty` with the fixed descriptor `(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;`; no alternative methods or overloads are invoked.
- BR-004 - The function returns the prior value of the named system property as reported by the JVM; callers that require the old value must capture the function's return value at the point of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-035 - WEBUTIL.WAIT

**Invoked From:**

- PK_VALIDATE_BACK_DATE.pck [StoredProcedure: PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Invokes the Java method 'wait' on an AppServerFileWriter object via the Oracle Forms WebUtil JNI bridge. The procedure suspends execution of the referenced Java object for a specified duration, passing a long timeout value and an integer qualifier to the underlying Java layer. It is called indirectly through PK_VALIDATE_BACK_DATE.GENERATE_NEXT_NUM to introduce a controlled wait during back-date number generation processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | NUMBER | IN |
| a1 | NUMBER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target Java object reference (obj), a long-typed timeout value (a0), and an integer qualifier (a1) as input parameters.
- Step 2 - Create a JNI argument list sized for two arguments using JNI.CREATE_ARG_LIST(2).
- Step 3 - Append the long argument (a0) to the argument list via JNI.ADD_LONG_ARG, representing the primary wait duration.
- Step 4 - Append the integer argument (a1) to the argument list via JNI.ADD_INT_ARG, representing the secondary wait qualifier.
- Step 5 - Invoke the Java void method 'wait' on the oracle/forms/webutil/fileTransfer/AppServerFileWriter class through JNI.CALL_VOID_METHOD, passing the constructed argument list and the target object reference.
- Step 6 - Return control to the caller upon successful completion of the Java method call; no output value is produced.

---
**Decision Points**

No conditional decision points exist in this procedure. Execution follows a single, unconditional path: build the argument list and invoke the Java wait method.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list must always be constructed with exactly two arguments (long and integer) in the order a0 then a1, matching the Java method signature '(JI)V'.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileWriter; no alternative class may be substituted at runtime.
- BR-003 - The procedure produces no return value; any wait outcome is handled entirely within the Java layer and is not surfaced back to the PL/SQL caller.
- BR-004 - The obj parameter must be a valid ORA_JAVA.JOBJECT reference to an instantiated AppServerFileWriter; passing a null or invalid object reference will cause the JNI call to fail.

---
**Implementation Logic**

```plsql
  PROCEDURE wait(
    obj   ORA_JAVA.JOBJECT,
    a0    NUMBER,
    a1    NUMBER) IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_LONG_ARG(args, a0);
    JNI.ADD_INT_ARG(args, a1);
    JNI.CALL_VOID_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'wait', '(JI)V', args); 
  END;
```

#### SP-036 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: KEY-CLRFRM]
- vt_smp_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Derives and returns the correct copyright year string for Maruti Suzuki India Limited based on the current financial year. Because the Indian financial year runs April-March, the function adjusts the displayed calendar year so that months January, February, and March are attributed to the preceding year, ensuring the copyright notice always reflects the active financial year rather than the raw calendar year.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current system date using SYSDATE into a local date variable.
- Step 2 - Extract the three-character month abbreviation from the current date.
- Step 3 - Evaluate whether the current month falls in the January-March period (i.e., the tail end of the previous financial year).
- Step 4 - If the month IS January, February, or March, compute the copyright year as the current calendar year minus one, then format the result as '- <prior year> Maruti Suzuki India Limited '.
- Step 5 - If the month is NOT in January-March (i.e., April through December), use the current calendar year as-is and format the result as '- <current year> Maruti Suzuki India Limited '.
- Step 6 - Return the formatted copyright string to the calling trigger (KEY-CLRFRM or WHEN-NEW-FORM-INSTANCE in vt_smp_enq_fmb.xml).

---
**Decision Points**

DP-001

Condition:
The three-character abbreviation of the current month (derived from SYSDATE) is one of 'JAN', 'FEB', or 'MAR'.

TRUE:
The copyright year is set to the current calendar year minus one, reflecting that January-March belong to the financial year that started in the previous April. The returned string uses this prior year value.

FALSE:
The copyright year is set to the current calendar year as-is, because April-December fall within the financial year that started in the current April. The returned string uses the current year value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The copyright notice must always reflect the active Indian financial year (April-March) rather than the raw calendar year.
- BR-002 - Months January, February, and March are treated as part of the preceding financial year; the copyright year displayed for these months must be the current calendar year minus one.
- BR-003 - Months April through December are treated as part of the current financial year; the copyright year displayed must equal the current calendar year.
- BR-004 - The returned copyright string must follow the format '- <YYYY> Maruti Suzuki India Limited ' (including the leading hyphen and trailing space) so that it can be rendered directly in the form without further transformation.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-037 - SF_GET_AMLIST

**Invoked From:**

- SP_TV_SRV.prc [StoredProcedure: SP_TV_SRV]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the description text (`list_desc`) for a specific entry in the `AM_LIST` reference table by matching on a combination of principal map code, list name, and list code. The function is used as a lookup utility by `SP_TV_SRV` to resolve coded values into their human-readable descriptions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal_map_cd | number | IN |
| p_list_name | varchar2 | IN |
| p_list_code | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept three input parameters: `p_principal_map_cd` (numeric principal map identifier), `p_list_name` (the name of the list category), and `p_list_code` (the specific code within that list).
- Step 2 - Query the `AM_LIST` table using all three parameters as filter criteria (`principal_map_cd`, `list_name`, and `list_code`) to retrieve the corresponding `list_desc` value into the local variable `lv_desc`.
- Step 3 - Return the retrieved `list_desc` value to the caller.
- Step 4 - If no matching row exists in `AM_LIST`, handle the `NO_DATA_FOUND` exception by setting `lv_desc` to `NULL` and returning `NULL` to the caller.

---
**Decision Points**

DP-001

Condition:
A row exists in `AM_LIST` where `principal_map_cd = p_principal_map_cd`, `list_name = p_list_name`, and `list_code = p_list_code`.

TRUE:
The matched `list_desc` value is returned to the caller.

FALSE:
The `NO_DATA_FOUND` exception is raised; `lv_desc` is set to `NULL` and `NULL` is returned to the caller.

---
**Database Interactions**

- DB-001 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - The lookup requires an exact match on all three key attributes (`principal_map_cd`, `list_name`, and `list_code`); partial matches are not supported.
- BR-002 - The function expects the combination of `principal_map_cd`, `list_name`, and `list_code` to uniquely identify at most one row in `AM_LIST`; the `SELECT INTO` construct enforces single-row retrieval.
- BR-003 - If no matching entry is found in `AM_LIST`, the function returns `NULL` rather than raising an unhandled exception, ensuring the caller receives a graceful null result instead of a runtime error.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function        sf_get_amlist(p_principal_map_cd number, p_list_name varchar2, p_list_code varchar2)
return Char is
--lv_desc varchar2(30);
lv_desc am_list.list_desc%TYPE;
begin
  select list_desc into lv_desc from am_list where principal_map_cd = p_principal_map_cd and list_name = p_list_name and list_code = p_list_code;
  return (lv_desc);
exception
  when no_data_found then
      lv_DESC := null;
      return (lv_desc);
end;

```

#### SP-038 - SF_TODATE

**Invoked From:**

- SP_TV_SRV.prc [StoredProcedure: SP_TV_SRV]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

SF_TODATE is a scalar date-adjustment function invoked by SP_TV_SRV to resolve an edge case in period-end date calculations. When a 'from' date falls on the last day of a 30-day month and the candidate 'to' date falls on the 31st of its month, the function advances the 'to' date by one day so that end-of-month boundaries align correctly across months of differing lengths. In all other cases the original 'to' date is returned unchanged.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_fdate | DATE | IN |
| pn_tdate | DATE | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive two input dates: pn_fdate (the period start/from date) and pn_tdate (the candidate period end/to date).
- Step 2 - Derive the last calendar day of the month containing pn_fdate using the LAST_DAY built-in function and store it in ld_lastdate.
- Step 3 - Extract the two-digit day portion of ld_lastdate into lv_fmonth (representing the last day of the 'from' month).
- Step 4 - Extract the two-digit day portion of pn_tdate into lv_tmonth (representing the day of the 'to' date).
- Step 5 - Evaluate whether all three boundary conditions are simultaneously true: (a) pn_fdate is the last day of its month, (b) that last day is the 30th, and (c) the day of pn_tdate is the 31st.
- Step 6 - If all three conditions hold, return pn_tdate + 1 (advancing the 'to' date by one day to compensate for the month-length discrepancy).
- Step 7 - If any condition does not hold, return pn_tdate unchanged.

---
**Decision Points**

DP-001

Condition:
pn_fdate equals the last day of its month (pn_fdate = LAST_DAY(pn_fdate)), AND the last day of that month is the 30th (lv_fmonth = '30'), AND the day component of pn_tdate is the 31st (lv_tmonth = '31').

TRUE:
Return pn_tdate + 1 - the 'to' date is incremented by one day to align the period end across the month-length boundary.

FALSE:
Return pn_tdate unchanged - no adjustment is required.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must only adjust the 'to' date when the 'from' date is simultaneously the last day of its month, that last day is the 30th, and the 'to' date's day component is the 31st; all three conditions must be true concurrently for any adjustment to occur.
- BR-002 - When the adjustment condition is met, the 'to' date is advanced by exactly one calendar day (pn_tdate + 1); no other magnitude of adjustment is permitted.
- BR-003 - When the adjustment condition is not met, the original pn_tdate value is returned without modification, ensuring no unintended alteration of period boundaries.
- BR-004 - The function has no database interactions and no external dependencies; its output is determined solely by the two input date parameters and Oracle built-in date arithmetic.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
FUNCTION sf_todate (pn_fdate DATE,
                                      pn_tdate DATE
                                      ) RETURN DATE
 AS
  ld_lastdate DATE;
  lv_fmonth   VARCHAR2(2);
  lv_tmonth   VARCHAR2(2);
BEGIN
  ld_lastdate := last_day(pn_fdate);
  lv_fmonth   := TO_CHAR(ld_lastdate, 'DD');
  lv_tmonth   := TO_CHAR(pn_tdate, 'DD');

  IF pn_fdate = ld_lastdate AND lv_fmonth = '30' AND lv_tmonth = '31' THEN
    --dbms_output.put_line(pn_tdate-1);
    RETURN pn_tdate+1;
  ELSE
    --dbms_output.put_line(pn_tdate);
    RETURN pn_tdate;
  END IF;

END;

```

#### SP-039 - SP_GET_TV_DETAIL

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves True Value warranty details for a given vehicle identified by VIN. The procedure queries the GM_VIN and GM_VIN_EXT tables to determine whether the vehicle carries a True Value designation and, if so, returns its resale date and warranty expiry date. The results are used by the Vehicle Details screen during item validation to populate or suppress True Value-related fields.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_vin | varchar2 | IN |
| p_ro_date | date | IN |
| p_ro_milage | number | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_tvw | varchar2 | OUT |
| p_resale_dt | date | OUT |
| p_exp_date | date | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the output flag p_tvw to 'Y' as a default before attempting the database lookup.
- Step 2 - Query GM_VIN (aliased as a) joined to GM_VIN_EXT (aliased as b) on the VIN key, filtering to rows where the VIN matches p_vin and the GM_VIN.TRUE_VALUE column is 'Y' (treating NULL as 'N').
- Step 3 - If a matching row is found, populate p_tvw with 'Y', p_resale_dt with TV_RESALE_DATE, and p_exp_date with TV_WAR_EXP_DATE from the joined result.
- Step 4 - If no matching row exists (NO_DATA_FOUND) or any other exception is raised during the inner query, set p_tvw to 'N' and leave p_resale_dt and p_exp_date unpopulated.
- Step 5 - If an unexpected exception propagates to the outer block, set p_tvw to 'N' as a final safety default, ensuring the procedure always returns a deterministic value to the caller.

---
**Decision Points**

DP-001

Condition:
A row exists in GM_VIN joined to GM_VIN_EXT where GM_VIN.VIN = p_vin AND NVL(GM_VIN.TRUE_VALUE, 'N') = 'Y'.

TRUE:
Set p_tvw to 'Y' and populate p_resale_dt and p_exp_date with the TV_RESALE_DATE and TV_WAR_EXP_DATE values retrieved from the query.

FALSE:
NO_DATA_FOUND exception is caught; p_tvw is set to 'N' and the date output parameters remain NULL.

---

DP-002

Condition:
An unexpected (non-NO_DATA_FOUND) exception is raised during the inner SELECT.

TRUE:
The WHEN OTHERS handler in the inner block sets p_tvw to 'N', suppressing the error and preventing it from propagating further.

FALSE:
Processing completes normally via DP-001 logic.

---

DP-003

Condition:
An unexpected exception escapes the inner block and reaches the outer exception handler.

TRUE:
The outer WHEN OTHERS handler sets p_tvw to 'N', guaranteeing the procedure always exits with a defined output value.

FALSE:
No outer exception is raised; the procedure exits normally.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
**Business Rules**

- BR-001 - A vehicle is considered True Value eligible only when GM_VIN.TRUE_VALUE is explicitly set to 'Y'; a NULL value is treated as 'N' and the vehicle is deemed ineligible.
- BR-002 - Both GM_VIN and GM_VIN_EXT must contain a record for the supplied VIN; failure to satisfy the join (no matching row in either table) results in a non-True-Value response (p_tvw = 'N').
- BR-003 - The procedure must always return a value for p_tvw ('Y' or 'N'); under no circumstances should it propagate an unhandled exception to the calling form trigger.
- BR-004 - When the vehicle is not True Value eligible, p_resale_dt and p_exp_date are returned as NULL, indicating that no resale or warranty expiry dates are applicable.
- BR-005 - The input parameters p_ro_date and p_ro_milage are accepted by the procedure signature but are not used in the current query logic; they are reserved for potential future business rule evaluation without requiring a signature change.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_get_tv_detail
( p_vin        in varchar2,
  p_ro_date    in date,
  p_ro_milage  in number,
  p_tvw       out varchar2,
  p_resale_dt out date,
  p_exp_date  out date
) as
begin
BEGIN   p_tvw := 'Y';
   begin
      select 'Y',tv_resale_date,tv_war_exp_date
       into p_tvw,p_resale_dt,p_exp_date
    from gm_vin a, gm_vin_ext b
      where a.vin = p_vin
        and b.vin = a.vin
        and nvl(a.true_value,'N') = 'Y';
   exception
    when no_data_found then
        p_tvw := 'N';
   when others then
        p_tvw := 'N';
  end ;
exception
 when others then
   p_tvw := 'N';
END;
end sp_get_tv_detail;

```

#### SP-040 - SP_GET_VEH_DETAILS

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Retrieves full vehicle and customer details for a given registration number or VIN during a WHEN-VALIDATE-ITEM trigger on the Vehicle Details screen. The procedure resolves vehicle attributes (model/variant/colour), identifies the associated customer, and returns address, contact, VIP status, and outstanding amount information, scoped to the supplied principal, parent group, dealer, and location context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_principal | NUMBER | IN |
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_locn | VARCHAR2 | IN |
| pi_reg_num | VARCHAR2 | IN OUT |
| po_vin | VARCHAR2 | IN OUT |
| po_cust_cd | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_reg_num | VARCHAR2 | IN OUT |
| po_vin | VARCHAR2 | IN OUT |
| po_svar_cd | VARCHAR2 | OUT |
| po_svar_desc | VARCHAR2 | OUT |
| po_variant_cd | VARCHAR2 | OUT |
| po_variant_desc | VARCHAR2 | OUT |
| po_ecolor_cd | VARCHAR2 | OUT |
| po_ecolor_desc | VARCHAR2 | OUT |
| po_cust_cd | VARCHAR2 | IN OUT |
| po_cust_name | VARCHAR2 | OUT |
| po_addr1 | VARCHAR2 | OUT |
| po_addr2 | VARCHAR2 | OUT |
| po_addr3 | VARCHAR2 | OUT |
| po_work_phone | VARCHAR2 | OUT |
| po_res_phone | VARCHAR2 | OUT |
| po_mobile_phone | VARCHAR2 | OUT |
| po_city_cd | VARCHAR2 | OUT |
| po_city_desc | VARCHAR2 | OUT |
| po_email | VARCHAR2 | OUT |
| po_vip_yn | VARCHAR2 | OUT |
| po_os_amt | NUMBER | OUT |
| p_gm_vin_rec_out | gm_vin%ROWTYPE | OUT |
| po_errmsg | VARCHAR2 | OUT |
| po_error_cd | NUMBER | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Determine the lookup key: if po_vin is supplied, query GM_VIN by VIN to retrieve svar_cd, variant_cd, ecolor_cd, and (if pi_reg_num is null) the registration number; otherwise query GM_VIN by pi_reg_num to retrieve the VIN and the same vehicle attribute codes.
- Step 2 - Retrieve the full GM_VIN row into the output record p_gm_vin_rec_out using whichever key (VIN or registration number) is now resolved.
- Step 3 - Look up the vehicle model description from VM_SVAR using po_svar_cd and pi_principal.
- Step 4 - Look up the variant description from GM_VAR using po_variant_cd and pi_principal.
- Step 5 - Look up the exterior colour description from GM_ECLR using po_ecolor_cd and pi_principal.
- Step 6 - If po_cust_cd was not supplied by the caller, derive it by reading party_cd from GM_VIN using the resolved VIN or registration number.
- Step 7 - Check whether the customer exists in GD_CIN for the specific parent group, dealer, location, and customer code combination (count check).
- Step 8 - If the customer is found in GD_CIN (count > 0), retrieve full customer details from GM_CIN: full name, communication-indicator-driven address lines and city code, work/residential/mobile phone, and email, filtered by po_cust_cd and pi_principal.
- Step 9 - If a city code was returned, look up the city description from GM_CITY using po_city_cd and pi_principal.
- Step 10 - Retrieve VIP flag (defaulting to 'N') and outstanding DMS amount from GD_CIN for the dealer/customer/location/parent combination.
- Step 11 - If the customer is not found in GD_CIN (count = 0), retrieve only the customer name from GM_CIN, leaving all address and contact fields unpopulated.
- Step 12 - Concatenate all partial error messages accumulated across steps into po_errmsg and return po_error_cd to the caller.

---
**Decision Points**

DP-001

Condition:
po_vin IS NOT NULL

TRUE:
Query GM_VIN by VIN to obtain svar_cd, variant_cd, ecolor_cd, and conditionally pi_reg_num (DECODE returns existing pi_reg_num if not null, otherwise the stored reg_num).

FALSE:
Query GM_VIN by pi_reg_num to obtain po_vin, svar_cd, variant_cd, and ecolor_cd.

---

DP-002

Condition:
po_errmsg IS NULL (guard before retrieving the full GM_VIN row and all descriptive attributes)

TRUE:
Proceed to fetch the full GM_VIN row and all subsequent lookups (Steps 2-11).

FALSE:
Skip the remaining lookup steps; concatenate error messages and return.

---

DP-003

Condition:
po_vin IS NOT NULL (within the full-row GM_VIN fetch at Step 2)

TRUE:
Select the GM_VIN row using vin = po_vin.

FALSE:
Select the GM_VIN row using reg_num = pi_reg_num.

---

DP-004

Condition:
po_cust_cd IS NULL

TRUE:
Derive po_cust_cd from GM_VIN using the resolved VIN (if not null) or pi_reg_num.

FALSE:
Use the caller-supplied po_cust_cd without querying GM_VIN for the customer code.

---

DP-005

Condition:
po_vin IS NOT NULL (within the customer-code derivation branch at Step 6)

TRUE:
Read party_cd from GM_VIN where vin = po_vin.

FALSE:
Read party_cd from GM_VIN where reg_num = pi_reg_num.

---

DP-006

Condition:
po_cust_cd IS NOT NULL AND lv_cnt > 0 (customer exists in GD_CIN for the given dealer/location/parent context)

TRUE:
Retrieve full customer details (name, communication-driven address, contact numbers, email) from GM_CIN; retrieve city description from GM_CITY if city code is present; retrieve VIP flag and outstanding amount from GD_CIN.

FALSE:
Retrieve customer name only from GM_CIN; all address, contact, VIP, and outstanding fields remain unpopulated.

---

DP-007

Condition:
po_city_cd IS NOT NULL (after GM_CIN fetch within the GD_CIN-found branch)

TRUE:
Query GM_CITY for the city description using po_city_cd and pi_principal.

FALSE:
Skip the GM_CITY lookup; po_city_desc remains null.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read VM_SVAR - Reads data from VM_SVAR for lookup or validation.
- DB-003 - Read GM_VAR - Reads data from GM_VAR for lookup or validation.
- DB-004 - Read GM_ECLR - Reads data from GM_ECLR for lookup or validation.
- DB-005 - Read GD_CIN - Reads data from GD_CIN for lookup or validation.
- DB-006 - Read GM_CIN - Reads data from GM_CIN for lookup or validation.
- DB-007 - Read GM_CITY - Reads data from GM_CITY for lookup or validation.
**Business Rules**

- BR-001 - A vehicle record must exist in GM_VIN and can be located by either VIN or registration number; if neither resolves a record, an error is flagged and processing of descriptive attributes is skipped.
- BR-002 - If the caller supplies both a VIN and a registration number, the VIN takes precedence as the primary lookup key; the registration number is only overwritten when it was originally null.
- BR-003 - Vehicle model (svar_cd), variant (variant_cd), and exterior colour (ecolor_cd) must all be defined in their respective reference tables (VM_SVAR, GM_VAR, GM_ECLR) for the supplied principal; absence of any one raises an individual error message.
- BR-004 - All reference-data lookups (VM_SVAR, GM_VAR, GM_ECLR, GM_CIN, GM_CITY) are scoped to pi_principal (PRINCIPAL_MAP_CD) to enforce principal-level data segregation.
- BR-005 - If the caller does not supply a customer code, the procedure derives it from the party_cd field in GM_VIN; if party_cd is null after the query, an additional error is raised indicating the customer is not tagged to the vehicle record.
- BR-006 - Full customer contact and address details are returned only when the customer is registered in GD_CIN for the specific combination of parent group, dealer, and location; otherwise only the customer name is exposed.
- BR-007 - Address lines are selected based on the COMMUNICATION_IND flag in GM_CIN: a value of 'O' returns office address fields (OFF_ADDRESS1/2/3, OFF_CITY_CD); any other value returns permanent address fields (PERMANENT_ADDRESS1/2/3, CITY_CD).
- BR-008 - The VIP indicator defaults to 'N' when the vip_yn column in GD_CIN is null (NVL applied).
- BR-009 - All partial error messages are accumulated independently across each lookup step and concatenated into po_errmsg at the end, allowing the caller to receive a composite diagnostic string rather than only the first failure.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sp_Get_Veh_Details
/*
$Log: SP_GET_VEH_DETAILS.sql,v $
Revision 1.5  2005/06/25 07:33:54  muralidhard
Decode split into multiple select statements for performance bottleneck

Revision 1.4  2004/12/31 05:41:34  muralidhard
Address Display Changed as per the Communication Indicator

*/
(
 pi_principal IN NUMBER    ,
 pi_parent    IN VARCHAR2  ,
 pi_dealer     IN  NUMBER,
 pi_locn   IN VARCHAR2,
 pi_reg_num   IN  OUT VARCHAR2,
 po_vin   IN OUT VARCHAR2,
 po_svar_cd  OUT VARCHAR2,
 po_svar_desc OUT VARCHAR2,
 po_variant_cd   OUT VARCHAR2,
 po_variant_desc OUT VARCHAR2,
 po_ecolor_cd OUT VARCHAR2,
 po_ecolor_desc OUT VARCHAR2,
 po_cust_cd IN OUT VARCHAR2,
 po_cust_name OUT VARCHAR2,
 po_addr1 OUT VARCHAR2,
 po_addr2 OUT VARCHAR2,
 po_addr3 OUT VARCHAR2, po_work_phone OUT VARCHAR2, po_res_phone OUT VARCHAR2, po_mobile_phone OUT VARCHAR2,
 po_city_cd OUT VARCHAR2,
 po_city_desc  OUT VARCHAR2, po_email  OUT  VARCHAR2, po_vip_yn OUT VARCHAR2, po_os_amt OUT NUMBER,
 p_gm_vin_rec_out OUT gm_vin%ROWTYPE,
 po_errmsg  OUT VARCHAR2,
 po_error_cd  OUT NUMBER
) IS

lv_cnt NUMBER := 0;
lv_err1 VARCHAR2(60);
lv_err2 VARCHAR2(60);
lv_err3 VARCHAR2(60);
lv_err4 VARCHAR2(60);
lv_err5 VARCHAR2(60);
lv_err6 VARCHAR2(60);
lv_err7 VARCHAR2(60);
lv_err8 VARCHAR2(60);
lv_err9 VARCHAR2(60);
lv_err10 VARCHAR2(60);
lv_err11 VARCHAR2(60);
BEGIN

IF po_vin IS NOT NULL THEN
              BEGIN
			  SELECT svar_cd, variant_cd, ecolor_cd,DECODE(pi_reg_num,NULL,reg_num,pi_reg_num)
			  INTO    po_svar_cd, po_variant_cd, po_ecolor_cd,pi_reg_num
			        FROM gm_vin
			  WHERE
			           vin = po_vin;
					   EXCEPTION WHEN OTHERS THEN
					   lv_err1 := po_vin || ' VIN not found in GM_VIN & ';
					   po_error_cd := 1;
			 END;
ELSE
	 	       BEGIN
			   SELECT
			   DECODE(po_vin,NULL,vin,po_vin),
			   svar_cd,
			   variant_cd,
			   ecolor_cd
			   INTO
			   po_vin, po_svar_cd, po_variant_cd, po_ecolor_cd
			   FROM gm_vin
				WHERE
						 reg_num = pi_reg_num;
						  EXCEPTION
						    WHEN OTHERS THEN
								 		   lv_err2 := pi_reg_num || ' Reg Number not found in GM_VIN & ';
										   po_error_cd := 1;
		        END;
END IF;
IF po_errmsg IS NULL THEN

    IF po_vin IS NOT NULL THEN
    BEGIN
    SELECT *
    INTO    p_gm_vin_rec_out
    FROM    gm_vin WHERE
            vin = po_vin;
  	   EXCEPTION WHEN OTHERS THEN
 		   lv_err3 := pi_reg_num || ' VIN/Registration not found & ';
		   po_error_cd := 1;

     END;
	ELSE
	BEGIN
    SELECT *
    INTO    p_gm_vin_rec_out
    FROM    gm_vin WHERE
            reg_num = pi_reg_num;
  	   EXCEPTION WHEN OTHERS THEN
 		   lv_err3 := pi_reg_num || ' VIN/Registration not found & ';
		   po_error_cd := 1;

     END;
	 END IF;

		 BEGIN
		 SELECT svar_desc
		     INTO po_svar_desc
			  FROM vm_svar
			   WHERE svar_cd = po_svar_cd AND
			         PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err4 := po_svar_cd || ' Vehicle model not defined & ';
		   po_error_cd := 1;
		END;

     BEGIN			SELECT variant_desc
				 INTO po_variant_desc
				  FROM gm_var
				   WHERE variant_cd = po_variant_cd  AND
				   PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err5 := po_variant_cd || ' Variant not defined & ';
		   po_error_cd := 1;

      END;

      BEGIN				    SELECT ecolor_desc
					 INTO po_ecolor_desc
					  FROM gm_eclr
					   WHERE ecolor_cd = po_ecolor_cd AND
					   PRINCIPAL_MAP_CD = pi_principal;
		   EXCEPTION WHEN OTHERS THEN
 		   lv_err6 := po_ecolor_cd || ' Color not defined & ';
		   po_error_cd := 1;

      END;

IF po_cust_cd IS NULL THEN

        IF po_vin IS NOT NULL THEN
        BEGIN
		SELECT party_cd INTO po_cust_cd FROM gm_vin
		WHERE
		  vin = po_vin;
				   EXCEPTION WHEN OTHERS THEN
		 		   lv_err7 := pi_reg_num || ' VIN/Reg No not found & ';
				   po_error_cd := 1;
		           IF  po_cust_cd IS NULL THEN
			                   lv_err8 := pi_reg_num || ' Customer Code not tagged in Reg Number & ';
				               po_error_cd := 1;
		           END IF;

		END;
        ELSE
		BEGIN
		SELECT party_cd INTO po_cust_cd FROM gm_vin
		WHERE
		  reg_num = pi_reg_num;
				   EXCEPTION WHEN OTHERS THEN
		 		   lv_err7 := pi_reg_num || ' VIN/Reg No not found & ';
				   po_error_cd := 1;
		           IF  po_cust_cd IS NULL THEN
			                   lv_err8 := pi_reg_num || ' Customer Code not tagged in Reg Number & ';
				               po_error_cd := 1;
		           END IF;

		END;
		END IF;
END IF;

	  BEGIN
	  SELECT COUNT(*) INTO lv_cnt FROM gd_cin
	  WHERE parent_group  = pi_parent  AND
	        dealer_map_cd = pi_dealer AND
			loc_cd        = pi_locn   AND
			cust_cd       = po_cust_cd;
	  END;

IF po_cust_cd IS NOT NULL AND lv_cnt > 0 THEN
BEGIN

/* Murali 31.12.04
 select full_name,
        permanent_address1,
		permanent_address2,
		permanent_address3,
		city_cd,
        work_phone,
		res_phone,
		mobile_phone,
		email
 into   po_cust_name, po_addr1, po_addr2, po_addr3, po_city_cd,
        po_work_phone, po_res_phone, po_mobile_phone, po_email
 from gm_cin
 where cust_cd = po_cust_cd; */

/* Murali 31.12.04   Showing the address based on Communication*/
 SELECT nvl(full_name,CUST_NAME),
 	    DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS1 , PERMANENT_ADDRESS1 ),
		DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS2 , PERMANENT_ADDRESS2 ),
		DECODE(COMMUNICATION_IND ,'O',OFF_ADDRESS3 , PERMANENT_ADDRESS3 ) ,
		DECODE(COMMUNICATION_IND ,'O',OFF_CITY_CD , CITY_CD),
        work_phone,
		res_phone,
		mobile_phone,
		email
 INTO   po_cust_name, po_addr1, po_addr2, po_addr3, po_city_cd,
        po_work_phone, po_res_phone, po_mobile_phone, po_email
 FROM gm_cin
 WHERE cust_cd = po_cust_cd  AND
 PRINCIPAL_MAP_CD = pi_principal;
DBMS_OUTPUT.PUT_LINE('ADD' ||po_addr1);
 EXCEPTION
  WHEN OTHERS THEN
    lv_err9 := po_cust_cd  || 'Customer not found & ';
   po_error_cd := 1;
  END;

DBMS_OUTPUT.PUT_LINE('ADD1' ||po_addr1);
IF po_city_cd IS NOT NULL THEN
BEGIN
SELECT city_desc
 INTO po_city_desc
 FROM gm_city
 WHERE city_cd     = po_city_cd  AND
  PRINCIPAL_MAP_CD = pi_principal;
 EXCEPTION
  WHEN OTHERS THEN
    lv_err10 := po_city_cd || 'City not Defined & ';
    po_error_cd := 1;
 END;
END IF;

BEGIN
SELECT NVL(vip_yn,'N'), outstanding_dms
INTO po_vip_yn, po_os_amt
FROM gd_cin
WHERE dealer_map_cd = pi_dealer AND  cust_cd = po_cust_cd
AND  loc_cd = pi_locn AND parent_group = pi_parent;
END;

/* Hide all the info */
ELSE
dbms_output.put_line('in else');

BEGIN
SELECT nvl(full_name,CUST_NAME)
 INTO po_cust_name
 FROM gm_cin
 WHERE cust_cd = po_cust_cd AND PRINCIPAL_MAP_CD = pi_principal;
 EXCEPTION
  WHEN OTHERS THEN
    lv_err11 := po_cust_cd || 'Customer not found & ';
    po_error_cd := 1;
 END;
END IF;
END IF;

po_errmsg := lv_err1||lv_err2||lv_err3||lv_err4||lv_err5||lv_err6||lv_err7||lv_err8||lv_err9||lv_err10||lv_err11;
DBMS_OUTPUT.PUT_LINE('error'||po_error_cd||po_errmsg);
END;

```

#### SP-041 - SP_TV_SRV

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Validates whether a True Value or related service job card may be raised for a given vehicle. The procedure checks vehicle master data, purchase history, resale status, warranty expiry, mileage limits, and service-gap rules before allowing service categories such as TV1/TV2/TV3, BV1-BV4, REFF, and PMSTV to proceed. It is invoked from the Vehicle Details screen during item validation and returns a numeric error code and descriptive message to the calling form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | VARCHAR2 | IN |
| p_reg_num | VARCHAR2 | IN |
| p_ro_date | DATE | IN |
| p_mileage | NUMBER | IN |
| p_rcateg_cd | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_error_cd | NUMBER | OUT |
| p_error_desc | VARCHAR2 | OUT |

---

**Dependencies**

- SF_GET_AMLIST ([SP-037](#SP-037--SF_GET_AMLIST)) - standalone source file
- SF_TODATE ([SP-038](#SP-038--SF_TODATE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve core vehicle attributes (VIN, TV warranty expiry date and mileage, resale date, contract start date, last-modified date, True Value flag, model code, chassis number, and principal map code) from GM_VIN joined to GM_VIN_EXT using the supplied registration number.
- Step 2 - Query SH_TV_EVAL for the most recent buy date (MAX BUY_DATE) where the VIN matches and the evaluation status is 'Y' or 'B'.
- Step 3 - If no buy date is found by VIN, repeat the SH_TV_EVAL lookup using the registration number with the same status filter.
- Step 4 - If still no buy date is found, repeat the SH_TV_EVAL lookup using make = 'M', model code, and chassis number with the same status filter.
- Step 5 - If no errors have been raised and the repair-category code is 'REFF' or 'PMSTV', call SF_GET_AMLIST to resolve the human-readable description for the category, then validate that a buy date exists and that the vehicle has not been resold prior to the buy date.
- Step 6 - For 'PMSTV' specifically, retrieve the most recent RO date from VH_RO for the same VIN and category (excluding cancelled ROs with status '20'), then call SF_TODATE to derive an effective comparison date, and calculate the number of months elapsed since that RO using MONTHS_BETWEEN.
- Step 7 - Look up the minimum required service gap (in months) from AM_LIST using the principal map code, list name 'SRV_GAP', and the repair-category code; default to 1 month if no record is found.
- Step 8 - If the elapsed months are less than the required gap, raise an error stating the minimum gap requirement.
- Step 9 - If no errors have been raised and the repair-category code is one of TV1, TV2, TV3, BV1, BV2, BV3, or BV4, verify that the True Value flag on the vehicle is 'Y'; raise an error if it is 'N'.
- Step 10 - For the same TV/BV categories, verify that the contract start date, expiry date, expiry mileage, and resale date are all populated; raise an error if any are null.
- Step 11 - For TV/BV categories other than TV3, verify that the supplied mileage does not exceed the expiry mileage and that the RO date does not exceed the expiry date; raise an error if either condition is breached.
- Step 12 - Assign the accumulated error code and error description to the OUT parameters and return.

---
**Decision Points**

DP-001

Condition:
A vehicle record is found in GM_VIN / GM_VIN_EXT for the supplied registration number.

TRUE:
Vehicle attributes (VIN, expiry date, expiry mileage, resale date, start date, modified date, True Value flag, model, chassis, principal map code) are populated and processing continues.

FALSE:
p_err_cd is set to 1 and p_err_desc is set to 'Vehicle Details not found in vehicle master'.

---

DP-002

Condition:
A buy date is found in SH_TV_EVAL matching the VIN with status 'Y' or 'B'.

TRUE:
lv_buy_date is populated; the registration-number and model/chassis fallback lookups are skipped.

FALSE:
Processing falls through to the registration-number-based SH_TV_EVAL lookup (DP-003).

---

DP-003

Condition:
lv_buy_date is still NULL after the VIN-based lookup; a buy date is found in SH_TV_EVAL matching the registration number with status 'Y' or 'B'.

TRUE:
lv_buy_date is populated; the model/chassis fallback lookup is skipped.

FALSE:
Processing falls through to the model/chassis-based SH_TV_EVAL lookup (DP-004).

---

DP-004

Condition:
lv_buy_date is still NULL; a buy date is found in SH_TV_EVAL matching make = 'M', model code, and chassis number with status 'Y' or 'B'.

TRUE:
lv_buy_date is populated.

FALSE:
lv_buy_date remains NULL, which will trigger a validation error in subsequent checks for applicable categories.

---

DP-005

Condition:
p_err_cd = 0 AND p_rcateg_cd IN ('REFF', 'PMSTV').

TRUE:
Refurbishment / PMSTV-specific validations (buy date existence, resale check, and PMSTV gap check) are executed.

FALSE:
Refurbishment / PMSTV validations are skipped.

---

DP-006

Condition:
lv_buy_date IS NULL (within the REFF / PMSTV branch).

TRUE:
p_err_cd is set to 1 with message 'Vehicle not bought at your dealership- Please check'.

FALSE:
Processing continues to the resale-date check (DP-007).

---

DP-007

Condition:
lv_buy_date < p_resale_date AND p_resale_date IS NOT NULL.

TRUE:
p_err_cd is set to 1 with a message indicating the vehicle has been sold and the named service type is not allowed.

FALSE:
No resale error is raised; processing continues.

---

DP-008

Condition:
p_err_cd = 0 AND p_rcateg_cd = 'PMSTV'.

TRUE:
The most recent PMSTV RO date is retrieved from VH_RO, the elapsed months are calculated via SF_TODATE and MONTHS_BETWEEN, the required gap is looked up in AM_LIST, and a gap-compliance check is performed.

FALSE:
PMSTV gap validation is skipped.

---

DP-009

Condition:
ln_diff_month < ln_month (elapsed months since last PMSTV RO is less than the required gap).

TRUE:
p_err_cd is set to 1 with a message stating the minimum month gap required between two occurrences of the service type.

FALSE:
No gap error is raised.

---

DP-010

Condition:
p_err_cd = 0 AND p_rcateg_cd IN ('TV1', 'TV2', 'TV3', 'BV1', 'BV2', 'BV3', 'BV4').

TRUE:
True Value / BV-specific validations (TV flag, mandatory date/mileage fields, and expiry checks) are executed.

FALSE:
True Value / BV validations are skipped.

---

DP-011

Condition:
p_tv = 'N' (vehicle is not flagged as a True Value vehicle in GM_VIN).

TRUE:
p_err_cd is set to 1 with message 'True Value vehicle not found in the Record'.

FALSE:
Processing continues to mandatory-field checks.

---

DP-012

Condition:
Any of p_strt_date, p_exp_date, p_exp_mileage, or p_resale_date is NULL.

TRUE:
p_err_cd is set to 1 indicating that True Value service is not allowed because a required date or mileage value is missing.

FALSE:
Processing continues to the expiry check.

---

DP-013

Condition:
(p_mileage > p_exp_mileage OR p_ro_date > p_exp_date) AND p_rcateg_cd != 'TV3'.

TRUE:
p_err_cd is set to 1 with message 'Odometer reading / Mileage / Job card date is Greater than TV condition'.

FALSE:
No expiry-breach error is raised; the TV/BV validation block completes successfully.

---
**Database Interactions**

- DB-001 - Read GM_VIN - Reads data from GM_VIN for lookup or validation.
- DB-002 - Read SH_TV_EVAL - Reads data from SH_TV_EVAL for lookup or validation.
- DB-003 - Read VH_RO - Reads data from VH_RO for lookup or validation.
- DB-004 - Read AM_LIST - Reads data from AM_LIST for lookup or validation.
**Business Rules**

- BR-001 - A valid vehicle record must exist in GM_VIN and GM_VIN_EXT for the supplied registration number before any service-category validation can proceed.
- BR-002 - A True Value evaluation buy date (status 'Y' or 'B') must be traceable to the vehicle via VIN, then registration number, and finally make/model/chassis; the first successful match is used.
- BR-003 - For service categories REFF and PMSTV, the vehicle must have been purchased at the dealership (a buy date must exist); service is blocked if no buy date can be resolved.
- BR-004 - For service categories REFF and PMSTV, if the vehicle has been resold (p_resale_date is populated) and the buy date precedes the resale date, the service is not permitted.
- BR-005 - For the PMSTV category, a minimum number of months (configured in AM_LIST under list name 'SRV_GAP' for the relevant principal map code) must have elapsed since the last non-cancelled PMSTV repair order; if no gap record is found, a default of 1 month applies.
- BR-006 - SF_TODATE is used to derive a safe comparison date for the last PMSTV RO date, ensuring null or invalid dates are handled consistently before MONTHS_BETWEEN is applied.
- BR-007 - The human-readable description of the repair category used in error messages is resolved dynamically via SF_GET_AMLIST using the vehicle's principal map code, ensuring the message reflects the correct category label for the dealership context.
- BR-008 - For service categories TV1, TV2, TV3, BV1, BV2, BV3, and BV4, the vehicle must be flagged as a True Value vehicle (true_value = 'Y') in GM_VIN.
- BR-009 - For TV/BV service categories, all four True Value contract fields (contract start date, expiry date, expiry mileage, and resale date) must be populated; a null in any field blocks the service.
- BR-010 - For TV/BV service categories except TV3, the job card mileage must not exceed the TV warranty expiry mileage and the RO date must not exceed the TV warranty expiry date; breaching either condition blocks the service.
- BR-011 - The expiry-date and expiry-mileage check (BR-010) is explicitly exempted for category TV3, allowing TV3 job cards to be raised regardless of expiry-date or mileage position.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE SP_TV_SRV(p_parent_group IN VARCHAR2,
                                      p_reg_num    IN VARCHAR2,
                                      p_ro_date    IN DATE,
                                      p_mileage    IN NUMBER,
                                      p_rcateg_cd  IN VARCHAR2,
                                      p_error_cd   OUT NUMBER,
                                      p_error_desc OUT VARCHAR2) IS
  p_vin           gm_vin_ext.VIN%TYPE;
  p_exp_date      DATE;
  p_exp_mileage   gm_vin_ext.TV_WAR_EXP_MILEAGE%TYPE;
  p_resale_date   DATE;
  p_strt_date     DATE;
  p_err_cd        NUMBER := 0;
  p_err_desc      VARCHAR2(500) := null;
  p_modified_date DATE;
  p_tv            VARCHAR2(1);
  lv_buy_date     DATE;
  lv_model        gm_vin.model_cd%TYPE;
  lv_chassis      gm_vin.chassis_num%TYPE;
  -- Added by Rajeev on 15-APR-2024
  ln_pmc          NUMBER := 1;
  lv_desc         am_list.list_desc%TYPE;
  ld_ro_date      vh_ro.ro_date%TYPE;
  ln_diff_month   NUMBER;
  ln_month        NUMBER;
BEGIN
  BEGIN
    SELECT vn.vin,
           ext.tv_war_exp_date,
           ext.tv_war_exp_mileage,
           ext.tv_resale_date,
           ext.tv_cont_strt_date,
           ext.modified_date,
           Nvl(vn.true_value, 'N'),
           vn.model_cd, -- model/chassis added by Rajeev on 28-SEP-2016
           vn.chassis_num,
           vn.principal_map_cd  -- Added by Rajeev on 15-APR-2024
      INTO p_vin,
           p_exp_date,
           p_exp_mileage,
           p_resale_date,
           p_strt_date,
           p_modified_date,
           p_tv,
           lv_model,
           lv_chassis,
           ln_pmc  -- Added by Rajeev on 15-APR-2024
      FROM gm_vin vn, gm_vin_ext ext
     WHERE vn.reg_num = p_reg_num
       AND vn.vin = ext.vin(+);
  EXCEPTION
    WHEN OTHERS THEN
      p_err_cd   := 1;
      p_err_desc := 'Vehicle Details not found in vehicle master';
  END;

  ------- Added by Deepak on 06/05/2016 for TV-Refurbishment-----
  BEGIN
    SELECT  MAX(SH.BUY_DATE)
      INTO LV_BUY_DATE
      FROM  SH_TV_EVAL SH
     WHERE sh.VIN = p_vin
     --AND  parent_group = p_parent_group -- Commented by Rajeev on 09-OCT-2017 SCR DMSSERV-13408
     AND  STATUS IN ('Y','B');
  EXCEPTION
    WHEN OTHERS THEN
      p_err_cd   := 1;
      p_err_desc := 'Vehicle Details not found';
  END;

  -- Added by Rajeev on 28-SEP-2016, if Details not found according to vin then check for reg num or model and chassis
  IF lv_buy_date IS NULL THEN
    BEGIN
       SELECT MAX(sh.buy_date)
         INTO lv_buy_date
         FROM sh_tv_eval sh
        WHERE sh.reg_no = p_reg_num
          --AND parent_group = p_parent_group  -- Commented by Rajeev on 09-OCT-2017 SCR DMSSERV-13408
          AND status IN ('Y','B');
    EXCEPTION
      WHEN OTHERS THEN
        p_err_cd   := 1;
        p_err_desc := 'Vehicle Details not found';
    END;
    IF lv_buy_date IS NULL THEN
       BEGIN
         SELECT MAX(sh.buy_date)
           INTO lv_buy_date
           FROM sh_tv_eval sh
          WHERE make = 'M'
            AND sh.model = lv_model
            AND sh.chassis = lv_chassis
            --AND parent_group = p_parent_group  -- Commented by Rajeev on 09-OCT-2017 SCR DMSSERV-13408
            AND status IN ('Y','B');
       EXCEPTION WHEN OTHERS THEN
          p_err_cd   := 1;
          p_err_desc := 'Vehicle Details not found';
       END;
    END IF;
  END IF;

  IF p_err_cd = 0 /*AND p_modified_date IS NOT NULL AND
     TRUNC(p_modified_date) > '24-MAR-2013'*/ THEN
    IF p_rcateg_cd IN ('REFF', 'PMSTV') THEN  -- PMSTV Added by Rajeev on 15-APR-2024
      /*IF p_resale_date IS NOT NULL THEN
        p_err_cd   := 1;
        p_err_desc := 'Vehicle has been sold. So, TV-REFURBISHMENT (MECH ) Service not allowed'; */

        -- Added by Rajeev on 15-APR-2024
        lv_desc := SF_GET_AMLIST(NVL(ln_pmc,1), 'RCATEG_CD', p_rcateg_cd);
      IF LV_BUY_DATE IS  NULL THEN
        p_err_cd   := 1;
        p_err_desc := 'Vehicle not bought at your dealership- Please check';
      ELSIF LV_BUY_DATE < p_resale_date AND p_resale_date IS NOT NULL  THEN
        p_err_cd   := 1;
        --p_err_desc := 'Vehicle has been sold. So, TV-REFURBISHMENT (MECH ) Service not allowed';  -- Changed by Rajeev on 15-APR-2024
        p_err_desc := 'Vehicle has been sold. So, '||lv_desc||' Service not allowed';
      END IF;

      --Added by Rajeev on 15-APR-2024
      IF p_err_cd = 0 AND p_rcateg_cd = 'PMSTV' THEN
        BEGIN
          SELECT MAX(r.ro_date)
            INTO ld_ro_date
            FROM vh_ro r
           WHERE r.vin = p_vin
             AND r.rcateg_cd = 'PMSTV'
             AND r.ro_status != '20';
        EXCEPTION WHEN OTHERS THEN
          ld_ro_date := NULL;
        END;
        ln_diff_month := MONTHS_BETWEEN(SF_TODATE(ld_ro_date, TRUNC(SYSDATE)), ld_ro_date);
        --DBMS_OUTPUT.PUT_LINE('Value '||ld_ro_date||' - '||ln_diff_month);
        BEGIN
          SELECT TO_NUMBER(list_desc) gap
            INTO ln_month
            FROM am_list
           WHERE principal_map_cd = ln_pmc
             AND list_name = 'SRV_GAP'
             AND list_code = p_rcateg_cd;
        EXCEPTION WHEN OTHERS THEN
          ln_month := 1;
        END;
        IF ln_diff_month < ln_month THEN
          p_err_cd   := 1;
          p_err_desc := 'Minimum '|| ln_month ||' Months gap should be between two '||lv_desc||' Service Type';
        END IF;
      END IF;
    END IF;

    IF p_err_cd = 0 AND p_rcateg_cd IN ('TV1', 'TV2', 'TV3','BV1','BV2','BV3','BV4') THEN-- Added BV by Govind for 2W POV DMSSERV(S)-13289
      ---condition check for Vehicle is True value or not
      IF p_err_cd = 0 AND p_tv = 'N' THEN
        p_err_cd   := 1;
        p_err_desc := 'True Value vehicle not found in the Record';
      END IF;

      ---condition check for start date - expiry date - mileage and resale date
      IF p_err_cd = 0 AND (p_strt_date IS NULL OR p_exp_date IS NULL OR
         p_exp_mileage IS NULL OR p_resale_date IS NULL) THEN
        p_err_cd   := 1;
        p_err_desc := 'True Value Service Not Allowed for the vehicle.
                           Start date or expiry date or mileage or Re-Sale date Can be null';
      END IF;
      ---condition check for expiry date and mileage greater than true value
      IF p_err_cd = 0 AND
         ((p_mileage > p_exp_mileage) OR (p_ro_date > p_exp_date)) AND
         p_rcateg_cd != 'TV3' THEN
        p_err_cd   := 1;
        p_err_desc := 'Odometer reading / Mileage / Job card date is Greater than TV condition';
      END IF;
      ---condition check for rodate is less and mileage-15000 from expiry mileage
      /*  comment for - user can open job card in TV 'mileage-15000' condtion will not in use
                IF p_err_cd = 0 THEN
                  IF ((p_ro_date < p_strt_date) AND
                     ((p_mileage < (p_exp_mileage - 15000)) OR
                     (p_mileage > p_exp_mileage))) THEN
                    p_err_cd   := 1;
                    p_err_desc := 'True Value Service Not Allowed for the vehicle. Mileage not in rang';
                  END IF;
                END IF;
      */
    END IF; --End --True Valeue ('TV1', 'TV2', 'TV3') --
  END IF; ---end error - 2

  p_error_cd   := p_err_cd;
  p_error_desc := p_err_desc;
END;

```

#### SP-042 - SP_VALIDATE_ALPHANUMERIC

**Invoked From:**

- vt_smp_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Vehicle Details (N/A / CN_MAIN)

---

**Purpose**

Sanitises a varchar2 value so that it contains only uppercase alphabetic characters (A-Z) and numeric digits (0-9). Any character that falls outside those two ranges is stripped from the string in place. The procedure is invoked during item validation on the Vehicle Details screen to enforce an alphanumeric-only constraint before the value is committed to the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_var | Varchar2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_var | Varchar2 | IN OUT |

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-032](#SP-032--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input/output parameter P_var containing the string to be validated.
- Step 2 - Query DUAL via WEBUTIL.LENGTH (SP-032) to determine the current length of P_var and store it in the local variable `len`.
- Step 3 - Initialise the character-position counter `i` to 1 and begin iterating through each character position up to `len`.
- Step 4 - For each position `i`, extract the single character at that position from P_var using SUBSTR via a DUAL query and store it in the local variable `c`.
- Step 5 - Evaluate the ASCII value of `c`. If the character is neither an uppercase letter (ASCII 65-90) nor a digit (ASCII 48-57), remove it from P_var by replacing it with NULL via a DUAL query, then re-query DUAL to refresh `len` to the new (shorter) string length, and decrement `i` by 1 so the same position is re-evaluated after removal.
- Step 6 - Increment `i` by 1 and repeat from Step 4 until all character positions have been processed.
- Step 7 - Return the sanitised string in P_var to the caller.

---
**Decision Points**

DP-001

Condition:
The ASCII value of the current character `c` is NOT in the range 65-90 (uppercase A-Z) AND NOT in the range 48-57 (digits 0-9).

TRUE:
The character is non-alphanumeric. It is removed from P_var using REPLACE...NULL via DUAL. The string length `len` is refreshed from DUAL, and the position counter `i` is decremented by 1 to re-examine the same index after the string has contracted.

FALSE:
The character is a valid uppercase letter or digit. No modification is made to P_var or `len`. Processing continues to the next character position.

---
**Database Interactions**

- DB-001 - Read DUAL - Reads data from DUAL for lookup or validation.
**Business Rules**

- BR-001 - Only uppercase alphabetic characters (A-Z, ASCII 65-90) and numeric digit characters (0-9, ASCII 48-57) are permitted in P_var; all other characters are automatically removed.
- BR-002 - The procedure does not raise a validation error; instead it silently strips invalid characters and returns the cleaned value, allowing downstream form processing to continue with the sanitised string.
- BR-003 - String length is re-evaluated after every removal so that the iteration correctly tracks the contracted string and does not skip or over-run character positions.
- BR-004 - The procedure operates exclusively on uppercase letters; lowercase alphabetic characters (ASCII 97-122) are treated as invalid and are stripped from the value.
- BR-005 - All character extraction and string manipulation operations are performed via DUAL queries, consistent with the Oracle Forms PL/SQL execution context and the dependency on WEBUTIL.LENGTH (SP-032) for length resolution.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_validate_alphanumeric
/*
$Log: SP_VALIDATE_ALPHANUMERIC.sql,v $
Revision 1.2  2004/09/02 14:45:05  muralidhard
no message

*/

(
P_var  IN OUT Varchar2)
is
len number;
c   char  ;
i   number := 1;
begin
    select length(P_var) into len from dual;
    while (i <= len)
    loop
     select substr(P_var,i,1) into c from dual;
       if not (ASCII(c) >=65 and ASCII(c) <= 90)  and
          not (ASCII(c) >=48 and ASCII(c) <= 57)    then
          select replace(P_var,c,Null) into P_var from dual;
          select length(p_var) into len from dual;
          i := i - 1;
       end if;
          i := i + 1;
    end loop;
  end;

```

#### SP-043 - SP_VALIDATE_OEMVIN

**Invoked From:**

- PKG_SMP.pck [StoredProcedure: PKG_SMP.SP_VIN_VALIDATE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Validates a raw VIN string supplied by the caller, resolves it against the GM_VIN_EXT vehicle master, and returns the canonical VIN and its corresponding OEM VIN number. When the input encodes an OEM VIN (indicated by a tilde delimiter), the procedure also verifies that the full input matches the stored OEM VIN. Error code and message outputs signal any validation failure to the calling routine PKG_SMP.SP_VIN_VALIDATE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pn_vin | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_vin | VARCHAR2 | OUT |
| po_oemvin | VARCHAR2 | OUT |
| po_err_cd | NUMBER | OUT |
| po_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise all output and local variables: set po_err_cd to 0, po_err_msg to NULL, and all local VIN/OEM/position variables to NULL/0.
- Step 2 - Check whether the input parameter pn_vin is NULL; if so, set po_err_cd = 1 and po_err_msg = 'Please Enter VIN' and halt further processing.
- Step 3 - Query DUAL using REGEXP_SUBSTR to extract the first segment of pn_vin before any tilde ('~') character into lv_val, and capture the position of the tilde into ln_pos. If this query fails for any reason, set po_err_cd = 1 and po_err_msg = 'Please check vehicle number'.
- Step 4 - Query GM_VIN_EXT to retrieve the vin and oem_vin_number columns where vin matches lv_val (the extracted VIN segment). If a row is found, store the results in lv_vin and lv_oem respectively. If NO_DATA_FOUND, default lv_vin to lv_val (the raw extracted value) and leave lv_oem NULL. Any other exception sets po_err_cd = 1 and po_err_msg = 'Please check vehicle number'.
- Step 5 - If ln_pos > 0 (a tilde was present, indicating the full input includes an OEM VIN suffix), compare the full pn_vin against lv_oem (defaulting to 'NA' if NULL). If they do not match, set po_err_cd = 1 and po_err_msg = 'Enter VIN not in vehicle Master'.
- Step 6 - If po_err_cd remains 0 after all checks, assign lv_vin to po_vin and lv_oem to po_oemvin, returning the resolved values to the caller.

---
**Decision Points**

DP-001

Condition:
pn_vin IS NULL

TRUE:
Set po_err_cd = 1 and po_err_msg = 'Please Enter VIN'; skip all remaining processing.

FALSE:
Proceed to parse the VIN string and perform vehicle master lookups.

---

DP-002

Condition:
REGEXP_SUBSTR / INSTR query on DUAL raises an exception (WHEN OTHERS)

TRUE:
Set po_err_cd = 1 and po_err_msg = 'Please check vehicle number'.

FALSE:
lv_val is populated with the pre-tilde VIN segment and ln_pos holds the tilde position; continue to GM_VIN_EXT lookup.

---

DP-003

Condition:
GM_VIN_EXT lookup for vin = lv_val returns NO_DATA_FOUND

TRUE:
Default lv_vin to lv_val; lv_oem remains NULL. Continue processing.

FALSE (row found):
lv_vin and lv_oem are populated from the vehicle master record. Continue processing.

---

DP-004

Condition:
GM_VIN_EXT lookup raises an exception other than NO_DATA_FOUND (WHEN OTHERS)

TRUE:
Set po_err_cd = 1 and po_err_msg = 'Please check vehicle number'.

FALSE:
Normal path; no action under this branch.

---

DP-005

Condition:
ln_pos > 0 (tilde delimiter was present in pn_vin, signalling an OEM VIN input)

TRUE:
Evaluate whether pn_vin equals NVL(lv_oem, 'NA'); if they differ, set po_err_cd = 1 and po_err_msg = 'Enter VIN not in vehicle Master'.

FALSE:
Skip OEM VIN match check; proceed to final output assignment.

---

DP-006

Condition:
po_err_cd = 0 after all validation steps

TRUE:
Assign lv_vin to po_vin and lv_oem to po_oemvin; return resolved VIN data to the caller.

FALSE:
Leave po_vin and po_oemvin unset; po_err_cd and po_err_msg already carry the failure details.

---
**Database Interactions**

- DB-001 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-002 - Read GM_VIN_EXT - Reads data from GM_VIN_EXT for lookup or validation.
**Business Rules**

- BR-001 - A VIN input value is mandatory; a NULL pn_vin is rejected immediately with the message 'Please Enter VIN'.
- BR-002 - The input string may encode an OEM VIN by embedding a tilde ('~') delimiter; the segment before the tilde is treated as the base VIN for vehicle master lookup.
- BR-003 - The base VIN segment must resolve to a record in GM_VIN_EXT; if no record is found, the raw extracted value is accepted as the VIN and the OEM VIN is treated as unknown (NULL).
- BR-004 - When the input contains a tilde (ln_pos > 0), the full input string pn_vin must exactly match the oem_vin_number stored in GM_VIN_EXT; a mismatch is rejected with the message 'Enter VIN not in vehicle Master'. If oem_vin_number is NULL, the comparison defaults to 'NA', ensuring any tilde-delimited input fails unless a matching OEM VIN exists.
- BR-005 - Resolved output values (po_vin and po_oemvin) are only populated when no validation error has been raised (po_err_cd = 0), ensuring the caller never receives partial results alongside an error condition.
- BR-006 - Any unexpected database exception during either the DUAL parse or the GM_VIN_EXT lookup is surfaced as a generic input error ('Please check vehicle number') rather than propagated as an unhandled exception, preserving caller stability.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        sp_validate_oemvin(pn_vin      IN VARCHAR2,
			                                         po_vin      OUT VARCHAR2,
                                               po_oemvin   OUT VARCHAR2,
			                                         po_err_cd   OUT NUMBER,
                                               po_err_msg  OUT VARCHAR2
                                               )
 IS
  lv_val   gm_vin.vin%TYPE;
  lv_vin   gm_vin.vin%TYPE;
  lv_oem   gm_vin_ext.oem_vin_number%TYPE;
  ln_pos   NUMBER;
BEGIN
   po_err_cd  := 0;
   po_err_msg := NULL;
   lv_val     := NULL;
   lv_vin     := NULL;
   lv_oem     := NULL;
   ln_pos     := 0;
   IF pn_vin IS NULL THEN
      po_err_cd  := 1;
      po_err_msg := 'Please Enter VIN';
   ELSE
      BEGIN
        SELECT REGEXP_SUBSTR(pn_vin, '[^~]+'), INSTR(pn_vin, '~')
          INTO lv_val, ln_pos
          FROM DUAL;
      EXCEPTION WHEN OTHERS THEN
        po_err_cd  := 1;
        po_err_msg := 'Please check vehicle number';
      END;

      BEGIN
        SELECT vin, oem_vin_number
          INTO lv_vin, lv_oem
          FROM gm_vin_ext v
         WHERE vin = lv_val;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          lv_vin := lv_val;
        WHEN OTHERS THEN
          po_err_cd  := 1;
          po_err_msg := 'Please check vehicle number';
      END;

      IF ln_pos > 0 THEN
        IF pn_vin <> NVL(lv_oem,'NA') THEN
          po_err_cd  := 1;
          po_err_msg := 'Enter VIN not in vehicle Master';
        END IF;
      END IF;

      IF po_err_cd = 0 THEN
        po_vin    := lv_vin;
        po_oemvin := lv_oem;
      END IF;
   END IF;
END sp_validate_oemvin;

```

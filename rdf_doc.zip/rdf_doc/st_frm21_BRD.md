# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Business Scenarios - How the query differs by record type and print-status filter
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Business Scenarios - How printing differs by record type
    - Requirement ID: BR-014
    - Business Scenarios - How Word conversion differs by record type
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Vehicle Invoice - SH_INVOICE
    - Vehicle Allotment - ST_ALLOT
    - Order Book - SH_ORDBOOK
    - Customer Identity - GM_CIN
    - Party Master - GM_PARTY
    - RTO Master - RTO_MASTER
    - Dealer Location Parameters - AM_DEALER_LOC_PARAM
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Search Criteria - Selection Filters (User - before querying)
    - Record Selection - Print Selection (User - after query results are loaded)
    - Session and Global Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - CB_DUMMY (46 columns)
    - B_CUSTOMER (48 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - DPL.pld (`pkg_param_variables`)
  - webutil.pld (`WEBUTIL_CORE`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - CALL_REPORT_SR_FORM21
    - SP-002 - CALL_REPORT_SR_FORM21_WRD
    - SP-003 - CHECK_RTO_CREATED
    - SP-004 - FETCH_PARTY_DET
    - SP-005 - FORM_REP_PARAM
    - SP-006 - SET_REPORT_SERVER
    - SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-011 - D2KWUTIL.TRANSLATETYPE
    - SP-012 - GENERAL.ASK_CONFIRM
    - SP-013 - GENERAL.CHECK_FORM_FAILURE
    - SP-014 - GENERAL.DISP_TEXT
    - SP-015 - GENERAL.PROC_REPORT_CALL
    - SP-016 - GENERAL.PROC_TIMER
    - SP-017 - GENERAL.PROC_TIMER_EXPIRED
    - SP-018 - GENERAL.RAISE_ERROR
    - SP-019 - QRY_RECORDS.QUERY_RECORDS
    - SP-020 - WEBUTIL.BLOCKING
    - SP-021 - WEBUTIL.CHECKLIBS
    - SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-023 - WEBUTIL.CLOSEBLOB
    - SP-024 - WEBUTIL.CLOSEFILE
    - SP-025 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-026 - WEBUTIL.ERROR
    - SP-027 - WEBUTIL.ERRORALERT
    - SP-028 - WEBUTIL.EXECUTE
    - SP-029 - WEBUTIL.FCLOSE
    - SP-030 - WEBUTIL.FOPEN
    - SP-031 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-032 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-033 - WEBUTIL.GETCLIENTSETTING
    - SP-034 - WEBUTIL.GETIMPLCLASS
    - SP-035 - WEBUTIL.GETLASTERROR
    - SP-036 - WEBUTIL.GETLASTERRORARGS
    - SP-037 - WEBUTIL.GETNUMBER
    - SP-038 - WEBUTIL.GETOSFAMILY
    - SP-039 - WEBUTIL.GETOUTPUT
    - SP-040 - WEBUTIL.GETPROPERTY
    - SP-041 - WEBUTIL.GETSTRING
    - SP-042 - WEBUTIL.GETVAR
    - SP-043 - WEBUTIL.GET_LINE
    - SP-044 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-045 - WEBUTIL.ID_NULL
    - SP-046 - WEBUTIL.INIT
    - SP-047 - WEBUTIL.INITWEBUTIL
    - SP-048 - WEBUTIL.ISERROR
    - SP-049 - WEBUTIL.IS_OPEN
    - SP-050 - WEBUTIL.LENGTH
    - SP-051 - WEBUTIL.LOG
    - SP-052 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-053 - WEBUTIL.PUT_LINE
    - SP-054 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-055 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-056 - WEBUTIL.REGISTERBEAN
    - SP-057 - WEBUTIL.REGISTER_FUNCTION
    - SP-058 - WEBUTIL.RELEASE_PROCESS
    - SP-059 - WEBUTIL.SETCLIENTSETTING
    - SP-060 - WEBUTIL.SETDATA
    - SP-061 - WEBUTIL.SETPROPERTY
    - SP-062 - WEBUTIL.SHOWBEANS
    - SP-063 - WEBUTIL.WRITEDATA
    - SP-064 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-065 - ADD_ERROR
    - SP-066 - ADD_EXTERNAL_ERRORS
    - SP-067 - BOOLTOCHAR
    - SP-068 - CLEAN_ERROR_STACK
    - SP-069 - DEBUGLOG
    - SP-070 - GET_ENVIRONMENT_STRING
    - SP-071 - READ_REGISTRY
    - SP-072 - REGISTER_FUNCTION_CALL
    - SP-073 - RUN_REPORT
    - SP-074 - SETDEBUG
    - SP-075 - SF_GET_FORM21_LOCK
    - SP-076 - STRIPDIRSEP
    - SP-077 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | ST_FRM21 - Business Requirements Document |
| Form Module Name | ST_FRM21 |
| Document Version | 1.0 |
| Date Created | August 05, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 05, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the st_frm21 Form 21 Printing form, its purpose, and roles referenced in the module.*

The **st_frm21** Oracle Forms module is the dealership **Form 21 Printing** screen. When a sales representative needs to print government-prescribed Form 21 (vehicle delivery/registration documents), they open **st_frm21**, select the report type (invoice or allotment), apply optional date and invoice-type filters, optionally specify an RTO city, and submit a query to retrieve matching vehicle records. For each displayed record the agent selects which items to print by ticking the corresponding print checkbox, then clicks Print to generate the Form 21 report in PDF format on-screen or for the printer, or Convert to Word to generate the report in Word format. The form validates date ranges before querying, checks that an RTO record exists for the dealer when required, verifies that at least one record is selected before printing, and builds the report parameter string from the selected records before submitting the print job to the report server. A background timer monitors the asynchronous print job and opens the completed output in the browser.

### Key Stakeholders

*Who uses st_frm21*

| Stakeholder | Role |
| :--- | :--- |
| **Sales Representative / Dealer Staff** | **Primary interactive user** of st_frm21. Sets search filters, queries vehicle invoice and allotment records, selects records for printing, and triggers Form 21 report generation. |
| **Vehicle Buyer / Customer** | Beneficiary whose vehicle registration document (Form 21) is produced; the customer does not interact with the form directly. |
| **RTO (Road Transport Office)** | Regulatory body for which the Form 21 is prepared; RTO city details are configured in the system before the form is used. |

---

---

## 3. System Context

*Describes the st_frm21 module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **st_frm21** module is the dealership **Form 21 Printing** screen within the DMS (Dealer Management System). It serves as the operational entry point for generating the government-prescribed Form 21 vehicle delivery document, connecting dealer sales data (invoices and allotments) with the report generation service and the Road Transport Office registration workflow.

**System purpose:** Query vehicle invoice and allotment records by type, date range, and RTO city, allow the dealer agent to select records for printing, and generate the Form 21 report in PDF or Word format via the report server - as implemented in the st_frm21 Oracle Forms module.

**In scope:**

- Select report type: Invoice or Allotment
- Apply search filters: invoice type, print status, date range, and temporary registration number
- Select RTO city for Form 21 using a configured RTO master lookup
- Validate date range inputs before querying (from date must not exceed today; to date requires a from date)
- Verify RTO master records exist for the dealer and principal before printing
- Query vehicle invoice and allotment records matching the selected filters
- Display up to 500 matching records with invoice number, date, customer name, financier details, and current Form 21 print status
- Select individual records or select/deselect all records for printing
- Generate Form 21 report in PDF format (on-screen or printer output)
- Generate Form 21 report in Word format
- Monitor asynchronous report execution via a background polling timer and open completed output in the browser
- Control print options: contact number inclusion, line separator, customer details, and temporary registration certificate

**Process Name:** Form 21 Printing

**Process Owner:** INFERRED - Dealer Sales Manager

**Process Objective:** Query vehicle invoice or allotment records, validate RTO and date criteria, select records for Form 21 printing, and generate the report in PDF or Word format before vehicle registration.

**Process Trigger:** Dealer agent initiates Form 21 generation as part of vehicle delivery and registration

**Process Flow:**

The complete Form 21 printing process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         Dealer agent opens the st_frm21 Form 21 Printing screen.
         Application logging timer starts if the session logging flag is active.

STEP 2 ── SELECT REPORT TYPE
         Agent selects report type using the radio group:
         ├── INVOICE (I): Invoice Type and Print Status filters are enabled
         └── ALLOTMENT (A): Invoice Type and Print Status filters are disabled

STEP 3 ── OPTIONAL: APPLY INVOICE TYPE FILTER
         Agent selects an invoice type from the dropdown to narrow the query.
         Applies only when report type is Invoice.

STEP 4 ── OPTIONAL: SELECT PRINT STATUS FILTER
         Agent selects print status: Printed (P) or Not Printed (N).
         Applies only when report type is Invoice.

STEP 5 ── OPTIONAL: ENTER DATE RANGE
         Agent enters a From Date and/or To Date to filter records by invoice/allotment date.
         ├── From Date validation: must not be in the future
         └── To Date validation: From Date must be entered first; To Date must not precede From Date

STEP 6 ── OPTIONAL: ENTER TEMPORARY REGISTRATION NUMBER
         Agent enters a temporary registration number to filter records.
         Requires From Date to be entered if specified.

STEP 7 ── OPTIONAL: SELECT RTO CITY
         Agent opens the RTO city LOV to select the Road Transport Office city.
         LOV is filtered by the active dealer, location, and principal.

STEP 8 ── OPTIONAL: SET PRINT OPTIONS
         Agent sets print control options:
         - Whether contact numbers appear on the report
         - Whether a separator line is printed
         - Whether customer details are included
         - Whether a temporary registration certificate is printed
         - Whether the report includes a title

STEP 9 ── CLICK QUERY
         Agent clicks the Query button to navigate to the results area.

STEP 10 ── RTO CHECK - principal type 2 only
          System verifies that an RTO master record exists for the active dealer and location.
          ├── RTO exists: proceed to record display
          └── RTO missing: error message displayed; agent directed to create RTO in master data

STEP 11 ── RECORDS LOADED
          System queries invoice or allotment records matching all selected filters.
          Up to 500 records are loaded; if more than 500 match, the agent is advised to apply stricter filters.
          For each record, financier code and description are fetched from order and allotment data.

STEP 12 ── REVIEW RESULTS
          Records are displayed showing invoice/allotment number, date, customer name,
          financier details, current Form 21 print status, and order number.

STEP 13 ── SELECT RECORDS FOR PRINTING
          Agent selects individual records by ticking the Print checkbox (FORM21_YN).
          ├── SELECT ALL: Agent clicks Select All to mark all records; button toggles to Deselect All
          └── INDIVIDUAL: Agent ticks/unticks each record's checkbox

STEP 14 ── NAVIGATE RECORDS
          Agent uses keyboard navigation to move between records in the results list.
          Navigation prevents moving past the first or last record.

STEP 15 ── PRINT FORM 21 (PDF)
          Agent clicks the Print button to generate the Form 21 PDF report.
          System validates RTO setup (principal type 2), builds the invoice/allotment number
          filter string from selected records, sets the report server, and submits the report.
          Agent is prompted to choose View, Print, or Close; and whether to include the title.

STEP 16 ── GENERATE FORM 21 IN WORD FORMAT
          Agent clicks the Convert to Word button (not available for temporary registration certificate records).
          System validates that temporary registration certificate is not selected, builds parameters,
          and calls the Word report generation procedure.

STEP 17 ── REPORT SUBMITTED TO REPORT SERVER
          The report job is submitted asynchronously to the configured report server.
          A repeating background timer starts to monitor report execution status.

STEP 18 ── REPORT STATUS POLLING
          Every 5 seconds the system checks the report job status:
          ├── RUNNING / QUEUED: timer continues polling
          ├── FINISHED: output file is opened in the browser; timer is deleted
          └── FAILED: error message is displayed; timer is deleted

STEP 19 ── COMMIT
          Agent commits the form; form success is validated before and after commit.
          Form is cleared after successful commit.

STEP 20 ── CLEAR FORM
          Agent or system clears the form; all filter fields are reset and
          Invoice Type and Print Status fields are re-enabled for the next query.

STEP 21 ── EXIT
          Agent exits the form without validation.
```

**Major process interactions:**

- **Vehicle invoice data** - invoice and allotment records are queried to identify vehicles requiring Form 21
- **RTO master data** - RTO city records are validated and selected to associate the RTO office with the printed form
- **Order and allotment data** - financier details are fetched from sales order and allotment records for each displayed record
- **Report server** - Form 21 PDF and Word reports are submitted to and monitored via the configured Oracle Report Server
- **Dealer location configuration** - dealer location parameter settings (such as price flag) are read to control report content

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Application Performance Timer Initialization

**Business Description:**
When the Form 21 printing screen first opens, the system performs a series of initialisation steps: it identifies the form in the application session, sets the main window to full screen, disables the Save, Insert, and Delete action buttons until they are needed, configures the RTO City field visibility based on the current principal type, and checks whether application performance logging is switched on. If logging is active, the system starts an internal timer so that the time taken to load and use the form can be measured and recorded for performance monitoring purposes.

**Actors:** System

**Preconditions:**
- The session global variables (`GLOBAL.PRINCIPAL`, `GLOBAL.APP_LOG`) have been set before the form opens.

**Main Flow:**

**Step 1 - Form identity and session seed set**
When the Form 21 screen first opens, the system records the form identity in the session by setting the application identifier (`GLOBAL.APP_ID`) to `st_frm21` and propagating this value to the application-id parameter (`PARAMETER.P_APP_ID`).

**Step 2 - Main window maximised and action buttons disabled**
The system maximises the main application window (`WN_MAIN`) to fill the screen. It then disables the Save, Insert, and Delete action buttons so that they cannot be activated until the user has performed a successful query and selected records.

**Step 3 - RTO City field visibility set by principal type**
The system checks the current session principal type. For principal type 2, the RTO City code field is hidden and the RTO City description field is displayed with a mandatory visual indicator. For all other principal types, the RTO City code field is shown and the RTO City description field is hidden.

**Step 4 - Performance timer started on form open**
The system checks whether application performance logging is active for this session (`GLOBAL.APP_LOG = 'Y'`). If logging is active, the system starts a performance timer to begin measuring the time taken to load the form.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - Form opened - application identifier set to `st_frm21`; main window maximised; Save, Insert, and Delete buttons disabled; RTO City field visibility configured for the current principal type.
- **BR-001-IC-02** - Application logging active - performance timer is started; elapsed time will be recorded on form load completion.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 3) Principal type is not 2: RTO City code field shown; RTO City description field hidden; no mandatory indicator applied.
- **BR-001-AF-02** - (from Step 4) Application performance logging is not active: no timer is started and the form continues loading normally without any timing measurement.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Identifier (`GLOBAL.APP_ID`) | Auto-populated | Character | 20 | N/A | `st_frm21` | Form opened | Set to `st_frm21` on form open; not user-editable | N/A |
| Application ID Parameter (`PARAMETER.P_APP_ID`) | Auto-populated | Character | 20 | N/A | Copied from `GLOBAL.APP_ID` | Form opened | Propagated from `GLOBAL.APP_ID` on form open | N/A |
| Application Log Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | `Y` = logging active | Session established | System-read only; checked but not written by this step | N/A |
| Principal Type (`GLOBAL.PRINCIPAL`) | Auto-populated | Number | N/A | N/A | `2` = principal requiring RTO city description | Session established | Determines RTO City field layout on form open | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Form Loading Completion - Performance Timer Stop

**Business Description:**
Once the Form 21 screen has finished downloading and is ready for user interaction, the system records the time taken to load the form by stopping the performance timer and logging the elapsed duration. This step applies only when application performance logging is enabled for the current session.

**Actors:** System

**Preconditions:**
- The Form 21 screen has finished loading and the first navigable field is ready for input.
- Application performance logging is enabled for the current session.

**Main Flow:**

**Step 1 - Loading completion timer recorded**
When the cursor arrives at the first field on the form, the system checks whether performance logging is active. If it is, the system stops the timer that was started when the form opened, recording how long the form took to download and become ready for use.

*Procedures called:*
- **STOP_WATCH.STOP_TIMER** ([SP-013](#sp-013)) - STOP_WATCH.STOP_TIMER - records the elapsed time for the form-loading phase against the current user, then stops the timer.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Alternative Flows:**
- **BR-002-AF-01** - (from Step 1) Application performance logging is not active: no timer stop is performed and the form remains ready for normal use.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Application Log Flag (`GLOBAL.APP_LOG`) | Auto-populated | Character | 1 | N/A | `Y` = logging active | Session established | System-read only; not user-editable | N/A |
| User Identity (`GLOBAL.USER_ID`) | Auto-populated | Character | N/A | N/A | Current session user | Session established | System-set; not user-editable | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Record Type Selection Controls Available Print Options

**Business Description:**
When the user selects a different record type on the selection criteria screen - switching between allotted-vehicle records and invoiced-vehicle records - the system immediately adjusts which filter fields are available to match the chosen type. Choosing the allotted-records option disables the Invoice Type and Print Status filters, since those fields do not apply to allotments. Choosing the invoiced-records option re-enables those same filters so the user can refine the invoice search.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open and ready for use.

**Main Flow:**

**Step 1 - Record type changed; filter controls adjusted**
The user selects which type of records to work with by changing the record-type radio button. If the allotted-records option is chosen, the Invoice Type and Print Status filter fields are immediately disabled and made non-navigable, preventing accidental entry into fields that do not apply. If any other record type (invoiced-records mode) is selected, those same filter fields are re-enabled and made navigable so the user can apply them as needed.

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-IC-01** - Allotted-records mode selected - Invoice Type and Print Status filters are disabled and not navigable.
- **BR-003-IC-02** - Invoiced-records mode selected - Invoice Type and Print Status filters are enabled and navigable.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) User selects allotted-records mode: Invoice Type (`INV_TYPE`) and Print Status (`NB_PRINT`) controls are disabled and set to non-navigable; user cannot enter values in those fields.
- **BR-003-AF-02** - (from Step 1) User selects invoiced-records mode: Invoice Type (`INV_TYPE`) and Print Status (`NB_PRINT`) controls are enabled and set to navigable; user may enter filter values.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Record Type (`NB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `A` = Allotted; other = Invoiced | Form open | Must be selected before querying | N/A |
| Invoice Type (`INV_TYPE`) | Conditional - when invoiced-records mode | List Item | 3 | N/A | Invoice type codes | Record Type selected | Enabled only when invoiced-records mode is active | N/A |
| Print Status (`NB_PRINT`) | Conditional - when invoiced-records mode | Radio Group | N/A | N/A | `P` = Printed; `N` = Not Printed; `A` = All | Record Type selected | Enabled only when invoiced-records mode is active | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** From Date Validation

**Business Description:**
When the user enters a date in the From Date filter field, the system checks that the entered date is not in the future. A From Date that is later than today's date is not a valid search boundary for historical invoice or allotment records, so the system rejects it and requires the user to correct the entry before proceeding.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open.
- The user has entered a value in the From Date field.

**Main Flow:**

**Step 1 - From Date checked against today's date**
After the user enters a date in the From Date field and moves away from it, the system checks whether the date entered is later than today. If it is, the system displays an error message and prevents the user from moving past the field until a valid past or current date is entered.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_DUMMY.NB_FRM_DATE - checks `TRUNC(NB_FRM_DATE) > SYSDATE` | When the user leaves the From Date field after entering a value | Ensures the date range used to search historical records starts on or before today | *"From date cannot be greater then todays date"* is displayed; the trigger is aborted and the cursor stays on the field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - From Date entered is in the future - *"From date cannot be greater then todays date"*; the user must correct the date before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`NB_FRM_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | Form open | Must not be later than today's date when entered | *"From date cannot be greater then todays date"* displayed; cursor remains on field |

---

---

#### Requirement ID: BR-005

**Requirement Title:** To Date Validation

**Business Description:**
When the user enters a date in the To Date filter field, the system enforces two rules to ensure the date range is complete and logically consistent: first, that a From Date has already been entered (a To Date without a From Date is not meaningful); and second, that the To Date is not earlier than the From Date. If either rule is violated, the system rejects the entry and asks the user to correct it.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open.
- The user has entered a value in the To Date field.

**Main Flow:**

**Step 1 - To Date cross-validated against From Date**
After the user enters a date in the To Date field and moves away from it, the system first checks whether a From Date has been entered. If no From Date is present, the system clears the To Date, displays an error, and returns the cursor to the field. If a From Date is present, the system then checks that the To Date is not earlier than the From Date; if it is, the system displays an error and the cursor remains on the To Date field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be entered before To Date | WHEN-VALIDATE-ITEM on CB_DUMMY.NB_TO_DATE - checks `NB_FRM_DATE IS NULL` | When the user leaves the To Date field after entering a value | Ensures a complete and meaningful date range is specified; a To Date without a From Date is not a valid filter | *"Enter a valid From date"* displayed; To Date is cleared; trigger aborted, cursor remains on field |
| To Date must not be earlier than From Date | WHEN-VALIDATE-ITEM on CB_DUMMY.NB_TO_DATE - checks `TRUNC(NB_TO_DATE) < TRUNC(NB_FRM_DATE)` | When the user leaves the To Date field after entering a value and From Date is already present | Prevents an inverted date range that would return no records | *"To date cannot be less than From date"* displayed; trigger aborted, cursor remains on field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - To Date entered without a From Date - *"Enter a valid From date"*; To Date is cleared; user must first enter a From Date.
- **BR-005-ES-02** - To Date is earlier than From Date - *"To date cannot be less than From date"*; user must enter a To Date that is on or after the From Date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`NB_TO_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | Form open | When entered: From Date must already be present; To Date must be on or after From Date | *"Enter a valid From date"* (clears field) or *"To date cannot be less than From date"* |
| From Date (`NB_FRM_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | Form open | Must be entered before To Date can be validated | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Temporary Registration Number Date Range Validation

**Business Description:**
When the user enters a value in the Temporary Registration Number field, the system applies the same date-range cross-validation rules that govern the From Date and To Date filters. Specifically, if a To Date is present in the date range, the system checks that the From Date is also present and that the To Date is not earlier than the From Date, ensuring the search criteria remain consistent.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open.
- The user has entered or modified the Temporary Registration Number field.

**Main Flow:**

**Step 1 - Date range consistency re-checked on temporary registration entry**
After the user enters a value in the Temporary Registration Number field and moves away from it, the system re-checks whether the To Date and From Date combination is still valid. If the To Date is present but the From Date is absent, the system clears the To Date and displays an error. If both dates are present but the To Date precedes the From Date, the system displays an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be entered when To Date is present | WHEN-VALIDATE-ITEM on CB_DUMMY.NB_TMP_NO - checks `NB_TO_DATE IS NOT NULL AND NB_FRM_DATE IS NULL` | When the user leaves the Temporary Registration Number field after entering a value | Ensures the date range filter remains complete when temporary registration data is specified | *"Enter a valid From date"* displayed; To Date is cleared; trigger aborted |
| To Date must not be earlier than From Date | WHEN-VALIDATE-ITEM on CB_DUMMY.NB_TMP_NO - checks `TRUNC(NB_TO_DATE) < TRUNC(NB_FRM_DATE)` | When the user leaves the Temporary Registration Number field and both dates are present | Prevents an inverted date range that would return no records | *"To date cannot be less than From date"* displayed; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - To Date is present but From Date is absent when leaving the Temporary Registration Number field - *"Enter a valid From date"*; To Date is cleared.
- **BR-006-ES-02** - To Date is earlier than From Date when leaving the Temporary Registration Number field - *"To date cannot be less than From date"*.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Temporary Reg No (`NB_TMP_NO`) | Optional | Character | 100 | N/A | N/A | Form open | Entry triggers date-range re-check; no direct validation on this field's own value | N/A |
| To Date (`NB_TO_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | N/A | Must not precede From Date; cleared if From Date is absent | *"Enter a valid From date"* (clears field) or *"To date cannot be less than From date"* |
| From Date (`NB_FRM_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | N/A | Must be present whenever To Date is entered | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** RTO City Pre-entry Verification for Principal Type 2

**Business Description:**
When the user moves the cursor into the RTO City (Road Transport Office) selection field, the system checks whether any RTO locations have been set up in the master data for the current dealership and principal. This check applies only to a specific category of principals. If no RTO records have been configured, the user is shown a note directing them to first create the necessary RTO master data via the appropriate maintenance path before attempting to print Form 21.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open.
- The current session is for a principal type that requires RTO verification.

**Main Flow:**

**Step 1 - RTO master existence checked on field entry**
When the user moves the cursor into the RTO City field, the system checks whether at least one active RTO record exists for the current dealer, location, and principal combination in the RTO master. This check runs only when the session principal type matches the specific category that requires RTO verification. If no RTO records are found, the system shows a note message and returns the cursor to the RTO City field, preventing the user from proceeding until RTO data is set up.

> **Note on implementation:** The PRE-TEXT-ITEM trigger on the RTO City field contains this logic in block-commented form and is **INACTIVE** (does not execute). The equivalent active RTO verification check runs inline within the Print button's WHEN-BUTTON-PRESSED trigger (B_CUSTOMER.PB_PRINT) as documented in BR-013 Step 1. The program unit CHECK_RTO_CREATED ([SP-003](#SP-003--CHECK_RTO_CREATED)) is also called from within PB_PRINT's active trigger code and performs the RTO master lookup described here.

*Procedures called:*
- **CHECK_RTO_CREATED** ([SP-003](#sp-003)) - CHECK_RTO_CREATED - checks whether at least one RTO master record exists for the current dealership and principal; if none exist and the principal type requires RTO verification, stops the user from proceeding and directs them to create the RTO master data first.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| RTO master record must exist for principal type requiring it | CHECK_RTO_CREATED [SP-003] - queries RTO_MASTER by dealer, location, and principal; checks count > 0 | When the user moves the cursor into the RTO City field | Prevents Form 21 printing from being attempted without the prerequisite RTO master data in place for principals that require it | *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"* displayed as a note; trigger aborted; cursor returned to RTO City field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-WS-01** - No RTO records found for the current dealership and principal - *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"*; cursor returned to the RTO City field.

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 1) The current session principal type does not require RTO verification: the check is skipped entirely and the user may proceed to enter the RTO City value normally.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RTO Name (`RT_CITY_DESC`) | Conditional - when principal type requires RTO | Character | 2000 | RTO master (LV_RTO / RG_RTO) | RTO city description | RTO master records configured for dealership | At least one RTO record must exist for the dealer/principal before this field can be used | *"First Create RTO from RTO Master..."* note displayed; cursor returned to this field |

---

---

#### Requirement ID: BR-008

**Requirement Title:** RTO City Field Navigation Lock

**Business Description:**
The RTO City field on the selection criteria screen is configured so that pressing the standard next-field navigation key does not move the cursor to the next field on the form; instead, the cursor remains on the RTO City field. This prevents the user from accidentally navigating away from the field while an RTO value still needs to be selected.

**Actors:** Dealer User

**Preconditions:**
- The cursor is positioned on the RTO City field.

**Main Flow:**

**Step 1 - Navigation kept on RTO City field**
When the user presses the next-field key while the cursor is on the RTO City field, the system redirects focus back to the same RTO City field rather than moving to the next field in the tab order.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RTO Name (`RT_CITY_DESC`) | Conditional | Character | 2000 | RTO master (LV_RTO / RG_RTO) | RTO city description | N/A | Navigation redirected to remain on this field when next-item key is pressed | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Invoice and Allotment Record Query and Display

**Business Description:**
When the user presses the Query button after setting up the search criteria, the system retrieves all matching invoiced or allotted vehicle records from the database and displays them in the results list. The query is filtered by the record type, invoice type, print status, and date range the user specified. The system enforces a maximum of 500 results per query; if more records match, the user is asked to narrow the search criteria. Once records are loaded, the Print and Convert to Word action buttons become available.

**Actors:** Dealer User

**Preconditions:**
- The record type, and (for invoiced records) the invoice type and print status, have been selected.
- The optional date range filters have been entered and validated if used.

**Main Flow:**

**Step 1 - User triggers the record query**
The user clicks the Query button. The system navigates to the results list area to begin loading records.

**Step 2 - Records retrieved and loaded into the results list**
The system executes the appropriate database query based on the selected record type and print-status filter. For allotted records, it retrieves all non-cancelled allotments for the current dealer and principal that have not yet been invoiced, optionally filtered by allotment date. For invoiced records, it retrieves non-cancelled invoices matching the selected invoice type and print-status preference, optionally filtered by invoice date. The system loads each matching record - including the invoice or allotment number, date, and customer name - into the results display, one row per record.

*Procedures called:*
- **QRY_RECORDS.QUERY_RECORDS** ([SP-012](#sp-012)) - QRY_RECORDS.QUERY_RECORDS - builds and executes the appropriate database cursor to retrieve matching records based on the user's selected record type, print status, and optional date range; returns a cursor of allotment or invoice records for the calling block to fetch.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Result set must not exceed 500 records | WHEN-NEW-BLOCK-INSTANCE on B_CUSTOMER - checks `RES_CURSOR%ROWCOUNT > 500` | When the query results are being loaded into the display list | Prevents the screen from being overloaded with unmanageably large result sets | *"More than 500 invoiced/alloted records found.Please specify different query details"* displayed; results cleared; cursor returned to Query button; trigger aborted |
| At least one matching record must be found | WHEN-NEW-BLOCK-INSTANCE on B_CUSTOMER - checks `B_CUSTOMER.NB_INV_NUM IS NULL` after fetching | After all query results have been loaded | Confirms that the specified search criteria matched at least one record in the database | *"No alloted/invoiced records found"* displayed; cursor returned to Query button; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - More than 500 matching records found - *"More than 500 invoiced/alloted records found.Please specify different query details"*; results cleared; user must narrow the search.
- **BR-009-ES-02** - No matching records found - *"No alloted/invoiced records found"*; user must revise search criteria.
- **BR-009-ES-03** - Data incompatibility error during record loading - *"Width problem/Incompatible data in fetching the alloted/invoiced records"*; results cleared; cursor returned to Query button.
- **BR-009-ES-04** - Unexpected database error during record loading - the system's own database error text followed by *"Execution failed for fetching the alloted/invoice records "* concatenated with the database error detail; results cleared; cursor returned to Query button.

**Step 3 - Party (financier) details loaded for each record**
After records are loaded successfully, the system fetches the financier code and name for each record in the results list and populates those display fields.

*Procedures called:*
- **FETCH_PARTY_DET** ([SP-004](#sp-004)) - FETCH_PARTY_DET - for each record in the results list, looks up the financier linked to the allotment or invoice order and populates the Financier Code and Financier Description fields; if no financier is found for a record, those fields are left blank.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Step 4 - Selection controls set based on print preference**
After data is loaded, the system enables the Select/Deselect All control. If the user's print-status preference was set to "Printed" (already-printed records), all records in the list are pre-selected and the toggle button is labelled "Deselect All"; otherwise it is labelled "Select All" with no records pre-selected. The Print and Convert to Word buttons are also enabled.

**Step 5 - Application performance timer recorded for query**
If application performance logging is active, the system stops the query-phase performance timer and records the elapsed duration, then commits the log entry.

*Procedures called:*
- **STOP_WATCH.STOP_TIMER** ([SP-013](#sp-013)) - STOP_WATCH.STOP_TIMER - records the elapsed time for the query-execution phase against the current user, then stops the timer.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

#### Business Scenarios - How the query differs by record type and print-status filter

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Allotted records** | Retrieves allotments not yet invoiced for the current dealer and principal; Invoice Type and Print Status filters do not apply; date range filters on allotment date. |
| **Invoiced records - specific print status** | Retrieves invoices matching the selected Invoice Type and the chosen print status (printed or not yet printed); date range filters on invoice date. |
| **Invoiced records - all print statuses** | Retrieves all invoices matching the Invoice Type regardless of whether they have been printed; date range filters on invoice date. |

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 2) More than 500 records match: results are cleared, error shown, and the user is returned to the Query button to refine the criteria.
- **BR-009-AF-02** - (from Step 2) No records match: error shown and user returned to Query button.
- **BR-009-AF-03** - (from Step 2) Data incompatibility error during fetch: error shown, results cleared, user returned to Query button.
- **BR-009-AF-04** - (from Step 2) Unexpected database error: error shown with database error detail, results cleared, user returned to Query button.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice / Allotment No (`NB_INV_NUM`) | Auto-populated | Character | 20 | N/A | Retrieved from database | Query executed | Read-only; populated from query results | N/A |
| Invoice / Allotment Date (`NB_IA_DATE`) | Auto-populated | Datetime | DD-MM-RRRR HH24:MI | N/A | Retrieved from database | Query executed | Read-only; populated from query results | N/A |
| Customer Name (`SPA_NAME`) | Auto-populated | Character | 100 | N/A | Retrieved from database | Query executed | Read-only; populated from query results | N/A |
| Financier Code (`FIN_CD`) | Auto-populated | Character | N/A | N/A | Retrieved from order/invoice | Query executed | Read-only; may be blank if no financier linked | N/A |
| Financier Description (`FIN_DESC`) | Auto-populated | Character | 300 | N/A | Retrieved from party master | Query executed | Read-only; populated as financier name and branch | N/A |
| Record Type (`NB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `A` = Allotted; other = Invoiced | Form open | Used to determine which query branch runs | N/A |
| Invoice Type (`INV_TYPE`) | Conditional - invoiced records | List Item | 3 | N/A | Invoice type codes | Record Type = Invoiced | Applied as filter only in invoiced-records mode | N/A |
| Print Status (`NB_PRINT`) | Conditional - invoiced records | Radio Group | N/A | N/A | `P` = Printed; `N` = Not Printed; `A` = All | Record Type = Invoiced | Applied as print-status filter in invoiced-records mode | N/A |
| From Date (`NB_FRM_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | Form open | When present, filters records by date range start | Validated before query via BR-004 |
| To Date (`NB_TO_DATE`) | Optional | Date | DD-MM-RRRR | N/A | N/A | From Date present | When present, filters records by date range end | Validated before query via BR-005 |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Select All or Deselect All Records for Printing

**Business Description:**
After query results are loaded, the user can use the Select All / Deselect All toggle button to mark every record in the results list for printing in a single action, or to clear all selections at once. When all records are selected, the button label changes to "Deselect All" to indicate what the next click will do, and vice versa.

**Actors:** Dealer User

**Preconditions:**
- Records have been loaded into the results list following a successful query.
- The Select/Deselect All toggle button is enabled.

**Main Flow:**

**Step 1 - User clicks the Select All or Deselect All toggle**
When the user clicks the toggle button, the system reads the current button label to determine the requested action. If the label is "Select All", the system iterates through all records in the results list and marks every record as selected for printing, then changes the button label to "Deselect All". If the label is "Deselect All", the system iterates through all records and marks every record as deselected (not for printing), then changes the button label back to "Select All".

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-IC-01** - All records marked for printing - button label changes to "Deselect All".
- **BR-010-IC-02** - All records cleared from selection - button label changes to "Select All".

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print Flag (`FORM21_YN`) | Auto-populated | Character | 1 | N/A | `Y` = selected; `N` = not selected | Records loaded | Set by Select/Deselect All action; also individually settable per record | N/A |
| Select/Deselect All (`NB_SEL_ALL`) | Optional | Check Box | 1 | N/A | `Y` = select all active; `N` = deselect all active | Records loaded | Drives bulk selection/deselection of all listed records | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Individual Record Print Selection

**Business Description:**
For each record in the results list, the user can independently toggle whether that individual record should be included in the next print run. Selecting a record marks it for printing; de-selecting it removes it from the print selection. When a record is selected, all other records in the list are automatically de-selected so that only the most recently selected record is marked for printing.

**Actors:** Dealer User

**Preconditions:**
- Records have been loaded into the results list following a successful query.

**Main Flow:**

**Step 1 - User toggles the print selection for an individual record**
The user checks or unchecks the print-selection indicator for a specific record in the results list. When a record is checked (selected for printing), the system saves the invoice or allotment number of that record, then iterates through all records in the list and sets every record's print flag to deselected. It then iterates again and sets only the record whose number matches the saved value back to selected for printing.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-IC-01** - Individual record selected for printing - all other records deselected; the chosen record's print flag set to selected.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print Flag (`FORM21_YN`) | Optional | Character | 1 | N/A | `Y` = selected; `N` = not selected | Records loaded | Selection of one record auto-deselects all others | N/A |
| Invoice / Allotment No (`NB_INV_NUM`) | Auto-populated | Character | 20 | N/A | Loaded from query results | Records loaded | Used as key to identify which record was selected | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** Results List Record Navigation - Down and Up

**Business Description:**
When navigating through the results list, the user is informed if they try to move beyond the last record (downward) or before the first record (upward) in the list. The system shows an informational message to indicate the boundary has been reached and prevents navigation past it.

**Actors:** Dealer User

**Preconditions:**
- Records have been loaded into the results list following a successful query.

**Main Flow:**

**Step 1 - User navigates down in the results list**
When the user presses the down-navigation key while viewing records, the system checks if the currently highlighted row is the last record in the list. If it is, the system displays a message that this is the last record and prevents further downward navigation. If it is not the last record, the system moves the highlight to the next record.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User has not reached the last record | KEY-DOWN on B_CUSTOMER.FORM21_YN - checks `SYSTEM.LAST_RECORD = 'TRUE'` | When user presses the down-navigation key in the results list | Prevents the user from attempting to navigate below the last available record | *"This is the Last Record...."* displayed; navigation stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - User presses down-navigation at the last record - *"This is the Last Record...."*; navigation stops.

**Step 2 - User navigates up in the results list**
When the user presses the up-navigation key while viewing records, the system checks if the currently highlighted row is the first record. If it is, the system displays a message that this is the first record and prevents further upward navigation. If it is not the first record, the system moves the highlight to the previous record.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User has not reached the first record | KEY-UP on B_CUSTOMER.FORM21_YN - checks `SYSTEM.CURSOR_RECORD = 1` | When user presses the up-navigation key in the results list | Prevents the user from attempting to navigate above the first available record | *"This is the First Record...."* displayed; navigation stopped |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-02** - User presses up-navigation at the first record - *"This is the First Record...."*; navigation stops.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print Flag (`FORM21_YN`) | Optional | Character | 1 | N/A | `Y` = selected; `N` = not selected | Records loaded | Current row context used for navigation boundary detection | N/A |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Print Form 21

**Business Description:**
When the user clicks the Print button, the system prints Form 21 for all records the user has selected. Before printing, the system verifies that the RTO city has been configured for principal types that require it and that no selected invoice or allotment is currently locked by another user. For each selected record, the system checks and acquires a print lock to prevent concurrent duplicate prints. Invoice records that pass the lock check are also updated to record that Form 21 has been printed. The system then builds the parameter set required by the report, selects the appropriate report server, and submits the Form 21 print job. After the print job is submitted, the form is cleared and reset for the next operation.

**Actors:** Dealer User

**Preconditions:**
- Records have been loaded into the results list following a successful query.
- At least one record has been selected for printing.
- The Print button is enabled.

**Main Flow:**

**Step 1 - RTO city requirement verified (principal type requiring RTO only)**
Before processing any records, the system checks whether the current session is for a principal type that requires an RTO city to be specified. If so, the system queries the RTO master to confirm that at least one RTO record exists for the current dealership. If no RTO record is found, the user is shown a note message directing them to create the RTO master data first and printing stops. If an RTO record exists but no RTO city has been selected on screen, the user is prompted to enter the RTO city before proceeding.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| RTO master record must exist before printing (principal type requiring RTO only) | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT - inline SELECT COUNT(*) from RTO_MASTER for current dealer/location/principal | When the user clicks the Print button | Prevents Form 21 from being printed without the required RTO configuration | *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"* displayed as a note; trigger aborted |
| RTO city must be selected when RTO record exists (principal type requiring RTO only) | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT - checks `RT_CITY_CD IS NULL` when lv_cnt > 0 | When the user clicks Print and an RTO master exists but no city has been chosen | Ensures a specific RTO city is identified on the form before printing | *"Please enter RTO"* displayed as a note; cursor moved to RTO City field; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-WS-01** - No RTO master record found - *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"*; printing stopped.
- **BR-013-WS-02** - RTO city not selected - *"Please enter RTO"*; cursor moved to RTO City field; printing stopped.

**Step 2 - Print lock checked and acquired for each selected record**
The system iterates through all records in the results list. For each record where the print flag is set to selected, the system calls the print-lock procedure to attempt to acquire a print lock on that specific invoice or allotment number. If the lock cannot be acquired (because another user holds it), the record's print flag is cleared from the selection and the problematic invoice number is recorded for later reporting. Records that pass the lock check increment the count of records that will be printed.

*Procedures called:*
- **SF_GET_FORM21_LOCK** ([SP-023](#sp-023)) - SF_GET_FORM21_LOCK - attempts to acquire a Form 21 print lock for the specified invoice or allotment record; returns an error message if the lock cannot be obtained (e.g. the record is already locked by another user session).
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Step 3 - Lock failure reported for invoiced records**
If any invoice record could not be locked, the system displays an error message listing the affected invoice numbers and indicating that those invoices are currently locked by another user. This message is shown only when the record type is Invoice (not Allotment).

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No selected invoice record is locked by another user | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT - checks `LN_ERR_MESSAGE IS NOT NULL` and `NB_TYPE = 'I'` | After the lock-acquisition loop completes | Informs the user which invoices could not be included in the print run because another user holds a print lock on them | The concatenated error message (affected invoice numbers) followed by *" Invoices Number Has been locked by Another User"* is displayed; affected records excluded from print |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-01** - One or more selected invoices are locked by another user - the concatenated list of affected invoice numbers followed by *" Invoices Number Has been locked by Another User"* is displayed; those records are excluded from the print run.

**Step 4 - Report parameters prepared and invoice records updated**
If at least one record passed the lock check, the system builds the report parameter string (a list of selected invoice or allotment numbers) and, for Invoice-type records that have not yet been marked as printed, updates the invoice record to mark that Form 21 has been printed for them. Duplicate update errors and other database errors are caught and reported.

*Procedures called:*
- **FORM_REP_PARAM** ([SP-005](#sp-005)) - FORM_REP_PARAM - iterates through all selected records, marks eligible Invoice-type records as having had Form 21 printed (updating the database), and builds the parameter string of selected record numbers to pass to the report; returns an error code if a duplicate or unexpected database error occurs.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No duplicate print update errors | FORM_REP_PARAM [SP-005] - catches DUP_VAL_ON_INDEX | After parameters are built and database update runs | Detects and reports an attempt to record a Form 21 print for an invoice that has already been flagged as printed | *"Trying to create a duplicate record for invoice"* displayed; error code set; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-02** - Duplicate print record detected - *"Trying to create a duplicate record for invoice"*; printing stops.

**Step 5 - Report server selected and Form 21 print job submitted**
The system selects the appropriate report server for the record type (Invoice uses server configuration 1; Allotment uses server configuration 2) and submits the Form 21 print job with the assembled parameters, including the principal, dealer, location, company, record type, selected record numbers, print-line option, temporary registration number (for invoice mode), and RTO city.

*Procedures called:*
- **SET_REPORT_SERVER** ([SP-006](#sp-006)) - SET_REPORT_SERVER - reads the applicable report server name from a configuration file on the server's file system and stores it in the session for use by the report submission call.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.
- **CALL_REPORT_SR_FORM21** ([SP-001](#sp-001)) - CALL_REPORT_SR_FORM21 - validates that temporary-registration-certificate printing is not requested for allotted records, determines the correct report file (standard Form 21 or the temporary-registration variant), checks the dealer's price-display configuration, prompts the user to confirm the output format (PDF or directly to printer), and submits the report job to the report server; on success, the report output is delivered via the configured mechanism.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Temporary-registration print not allowed for allotted records | CALL_REPORT_SR_FORM21 [SP-001] - checks `NB_TYPE = 'A' AND CB_TEMP_REP = 'Y'` | When the report submission procedure is called for allotted-record mode | Prevents an invalid combination of allotted-records mode with temporary-registration-certificate output | *"No Temporary Registration Certificate for alloted numbers"* displayed; form cleared; trigger aborted |
| Dealer price configuration retrieved | CALL_REPORT_SR_FORM21 [SP-001] - SELECT from AM_DEALER_LOC_PARAM | When preparing report parameters | Obtains the dealer's price-display flag to include in the Form 21 report parameters | Database error detail via GENERAL.DISP_TEXT; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-ES-03** - Temporary-registration print requested for allotted records - *"No Temporary Registration Certificate for alloted numbers"*; form cleared; printing stopped.

**Step 6 - Form cleared after print submission**
After the print job has been submitted, the form is cleared and reset to its initial state, ready for the next operation.

#### Business Scenarios - How printing differs by record type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Invoice records** | RTO lock acquired per invoice; invoice records updated to mark Form 21 as printed; locked invoices reported; report server 1 used; temporary registration number included in report parameters. |
| **Allotment records** | No per-record invoice update; report server 2 used; temporary registration number not passed to report; allotment lock still checked but no duplicate-update risk. |
| **Temporary registration certificate (invoiced records)** | Standard Form 21 report replaced by the temporary-registration-certificate variant (`sr_form21_trc`). Not available for allotted records. |

**Alternative Flows:**
- **BR-013-AF-01** - (from Step 1) Principal type does not require RTO verification: RTO check skipped; processing continues from Step 2.
- **BR-013-AF-02** - (from Step 4) Report parameter preparation fails (error code > 0): trigger aborted without submitting the print job.
- **BR-013-AF-03** - (from Step 2) No records pass the lock check (lock count = 0): no report parameters are built and no print job is submitted; form remains open.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print Flag (`FORM21_YN`) | Optional | Character | 1 | N/A | `Y` = selected for printing | Records loaded | Records with flag set to selected are included in the print run | N/A |
| Invoice / Allotment No (`NB_INV_NUM`) | Auto-populated | Character | 20 | N/A | Loaded from query | Records loaded | Used as key for lock acquisition and report parameterisation | N/A |
| Record Type (`NB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `A` = Allotted; other = Invoiced | Form open | Determines which report branch and lock logic applies | N/A |
| Invoice Type (`INV_TYPE`) | Conditional | List Item | 3 | N/A | Invoice type codes | Invoiced-records mode | Used in report parameter string for invoiced records | N/A |
| Print Line Option (`CB_LINE`) | Optional | Character | N/A | N/A | Line print flag | N/A | Passed to the report as a display parameter | N/A |
| Temporary Reg No (`NB_TMP_NO`) | Optional | Character | 100 | N/A | N/A | N/A | Passed to report for invoice-mode printing only | N/A |
| RTO City (`RTO_CITY`) | Conditional - when principal type requires RTO | Character | 2000 | N/A | Loaded from RTO Name field | RTO master set up | Required for principal types that mandate RTO entry before printing | *"Please enter RTO"* if absent when required |
| RTO Name (`RT_CITY_DESC`) | Conditional - when principal type requires RTO | Character | 2000 | RTO master (LV_RTO) | RTO city description | RTO master configured | Source value for RTO City report parameter | N/A |
| Print Temporary Registration (`CB_TEMP_REP`) | Optional | Check Box | N/A | N/A | `Y` = print temp reg certificate | N/A | When set, selects the temporary-registration-certificate report variant; not allowed for allotted records | *"No Temporary Registration Certificate for alloted numbers"* if checked in allotted-records mode |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Convert Form 21 to Word Document

**Business Description:**
When the user clicks the Convert to Word button, the system generates the Form 21 content for all selected records as a Word (RTF) document instead of a printed PDF. Printing as a temporary-registration certificate is not supported in Word-conversion mode; the system rejects that combination before proceeding. The system builds the required report parameters, selects the applicable report server, and submits the Word-format report job. After submission, the form is cleared.

**Actors:** Dealer User

**Preconditions:**
- Records have been loaded into the results list following a successful query.
- At least one record has been selected for conversion.
- The Convert to Word button is enabled.

**Main Flow:**

**Step 1 - Temporary registration print option checked**
Before building any report parameters, the system checks whether the temporary-registration print option has been selected in combination with allotted-records or invoiced-records mode. If it has, Word conversion is not allowed and the system clears the form and shows an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Temporary-registration certificate not allowed for Word conversion | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_CONV_WRD - checks `CB_TEMP_REP = 'Y' AND NB_TYPE IN ('A','I')` | When the user clicks the Convert to Word button | Prevents the temporary-registration-certificate output from being generated in Word format, which is not supported | *"Conversion is not allowed for Temporary Registration Certificate"* displayed; form cleared; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Temporary-registration print option active - *"Conversion is not allowed for Temporary Registration Certificate"*; form cleared; conversion stopped.

**Step 2 - Report parameters prepared and records flagged**
The system builds the report parameter string (selected invoice or allotment numbers) and, for Invoice-type records not yet marked as printed, updates those records in the database.

*Procedures called:*
- **FORM_REP_PARAM** ([SP-005](#sp-005)) - FORM_REP_PARAM - iterates through all selected records, marks eligible Invoice-type records as having had Form 21 printed (updating the database), and builds the parameter string of selected record numbers; returns an error code if a duplicate or unexpected database error occurs.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No duplicate print update errors | FORM_REP_PARAM [SP-005] - catches DUP_VAL_ON_INDEX | After record update runs | Detects a duplicate Form 21 print record attempt | *"Trying to create a duplicate record for invoice"*; error code set; trigger aborted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-02** - Duplicate print record detected - *"Trying to create a duplicate record for invoice"*; conversion stopped.

**Step 3 - Report server selected and Word-format report job submitted**
The system selects the applicable report server (server 1 for Invoice mode; server 2 for Allotment mode) and submits the Word-format (RTF) Form 21 report job with all required parameters.

*Procedures called:*
- **SET_REPORT_SERVER** ([SP-006](#sp-006)) - SET_REPORT_SERVER - reads the applicable report server name from the server's file system configuration and stores it in the session for the report submission call.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.
- **CALL_REPORT_SR_FORM21_WRD** ([SP-002](#sp-002)) - CALL_REPORT_SR_FORM21_WRD - retrieves the dealer's price-display configuration, sets the report output format to RTF (Word), and submits the Form 21 report job to the report server with all required parameters; on database error during configuration retrieval, the error detail is displayed and processing stops.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer price configuration retrieved | CALL_REPORT_SR_FORM21_WRD [SP-002] - SELECT from AM_DEALER_LOC_PARAM | When preparing Word-format report parameters | Obtains the dealer's price-display flag to include in the Word-format Form 21 report parameters | Database error detail displayed; trigger aborted |

**Step 4 - Form cleared after conversion submission**
After the Word-format report job has been submitted, the form is cleared and reset to its initial state.

#### Business Scenarios - How Word conversion differs by record type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Invoice records** | Report server 1 used; invoice record type flag passed as `I` to report. |
| **Allotment records** | Report server 2 used; allotment record type flag passed as `A` to report. |

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 2) Report parameter preparation fails (error code > 0): trigger aborted without submitting the conversion job.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Print Temporary Registration (`CB_TEMP_REP`) | Optional | Check Box | N/A | N/A | `Y` = temp reg certificate mode | N/A | Must not be selected when using Word conversion | *"Conversion is not allowed for Temporary Registration Certificate"* |
| Record Type (`NB_TYPE`) | Mandatory | Radio Group | 1 | N/A | `A` = Allotted; other = Invoiced | Form open | Determines which report branch and server applies | N/A |
| Print Flag (`FORM21_YN`) | Optional | Character | 1 | N/A | `Y` = selected | Records loaded | Records with flag set are included in Word conversion | N/A |
| Invoice / Allotment No (`NB_INV_NUM`) | Auto-populated | Character | 20 | N/A | Loaded from query | Records loaded | Used as key for report parameterisation | N/A |
| Print Line Option (`CB_LINE`) | Optional | Character | N/A | N/A | Line print flag | N/A | Passed to the Word-format report as a display parameter | N/A |
| RTO City (`RTO_CITY`) | Conditional | Character | 2000 | N/A | Loaded from RTO Name field | N/A | Passed to Word-format report when applicable | N/A |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Commit and Save Form Data

**Business Description:**
When the user performs a save action, the system first validates all data currently on the form, commits any pending changes to the database, and then clears the form ready for the next operation. Two failure checks bracket the database commit to ensure that any validation or commit error is detected and handled before the form is cleared.

**Actors:** Dealer User

**Preconditions:**
- The user has entered or modified data on the Form 21 screen.

**Main Flow:**

**Step 1 - Data validation and commit executed**
When the user initiates a save, the system first runs the standard field-level enter/validation pass across all open fields. It then checks whether that pass produced any failures; if so, processing stops at that point. If validation passes, the system commits the data to the database, and checks again for any commit-phase failures. If commit succeeds without error, the system clears the form.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-007](#sp-007)) - GENERAL.CHECK_FORM_FAILURE - checks whether a trigger or commit failure was raised during the immediately preceding operation; if a failure condition is detected, it re-raises the failure to stop further processing.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Pre-commit validation must pass | GENERAL.CHECK_FORM_FAILURE [SP-007] - called after `enter` and before `commit_form` | When the user initiates a save | Ensures all on-screen data is valid before attempting to write to the database | Trigger failure raised; commit is not attempted |
| Post-commit check must pass | GENERAL.CHECK_FORM_FAILURE [SP-007] - called after `commit_form` | After the database commit has run | Detects any database-level error that occurred during the commit | Trigger failure raised; form clear is not performed |

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 1) Pre-commit validation fails: commit is not attempted; form remains open with data intact.
- **BR-015-AF-02** - (from Step 1) Commit fails: form clear is not performed; form remains open.

---

---

#### Requirement ID: BR-016

**Requirement Title:** Exit Form Without Saving

**Business Description:**
When the user chooses to exit or cancel from the Form 21 screen, the system handles unsaved data safely. If the user presses the exit key the form closes immediately. If the user clicks the Cancel button, the system checks whether any data has been changed since the last save: if changes exist the user is asked to confirm that those changes will be discarded before the form is cleared; if no changes are pending the form is cleared immediately. In both paths all unsaved data is discarded and the Invoice Type filter is reset to its default value.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 screen is open.

**Main Flow:**

**Step 1 - Form closed without saving**
The user presses the exit key. The system immediately closes the Form 21 screen without running any data validation or attempting to save any pending changes; all unsaved data is discarded.

**Step 2 - Cancel button pressed: unsaved-change check and form clear**
When the user clicks the Cancel button and the button is currently enabled, the system checks whether any data on screen has been changed since the last save. If the form has unsaved changes, the system asks the user to confirm that the entered data will not be saved before proceeding. If the user confirms (or if there are no unsaved changes), the system re-enables the Invoice Type field, clears the form, and resets the Invoice Type filter to its default value. If the form has unsaved changes and the user does not confirm, the cancel action is abandoned and the form remains open with all current data intact.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User must confirm discard when unsaved changes exist | FT_CANCEL - checks `SYSTEM.FORM_STATUS = 'CHANGED'`; calls `GENERAL.ASK_CONFIRM('Entered data will not be Saved')` | When the user clicks the Cancel button and the form has unsaved changes | Prevents accidental loss of entered data by requiring explicit confirmation before clearing | User declines confirmation - cancel is abandoned; form remains open with data intact |

*Business outcomes (errors, warnings, success, and status):*
- **BR-016-WS-01** - User clicks Cancel with unsaved changes and confirms the discard - *"Entered data will not be Saved"* confirmation shown; form cleared; Invoice Type reset to default.
- **BR-016-IC-01** - User clicks Cancel with no unsaved changes - form cleared immediately; Invoice Type reset to default.

**Alternative Flows:**
- **BR-016-AF-01** - (from Step 2) Cancel button is disabled: the button press has no effect; the form remains open.
- **BR-016-AF-02** - (from Step 2) Form has unsaved changes but the user declines the confirmation: cancel is abandoned; form data is preserved.

---

---

#### Requirement ID: BR-017

**Requirement Title:** Clear Form and Reset Selection Criteria

**Business Description:**
When the user clears the form, the system discards all current search criteria and query results without saving, and resets all selection controls and action buttons to their default enabled or disabled states. For sessions where an RTO city is required, the RTO City field is also visually highlighted to indicate it is mandatory. Any previously selected values in the invoice type, print status, and record selection filters are also cleared.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 screen is open.

**Main Flow:**

**Step 1 - Form cleared and controls reset to default state**
The system clears all current data and user-entered criteria from the screen without saving. It then restores the default control states: the Invoice Type and Print Status filters are re-enabled and navigable, the Select/Deselect All toggle label is reset to "Deselect All" and the control is disabled, and the Print and Convert to Word buttons are disabled. Two previously commented-out operations - pre-setting the Invoice Type to a fixed value and setting a new-record parameter - are inactive and do not execute.

**Step 2 - RTO City field highlighted as mandatory for applicable principal type**
For sessions where the session principal type requires an RTO entry, the system applies a mandatory visual attribute to the RTO City field to visually indicate that it must be completed before printing.

*Business outcomes (errors, warnings, success, and status):*
- **BR-017-IC-01** - Form cleared - Invoice Type and Print Status controls enabled; Select/Deselect All disabled and labelled "Deselect All"; Print and Convert to Word buttons disabled.
- **BR-017-IC-02** - RTO City field styled as mandatory (principal type requiring RTO only).

**Alternative Flows:**
- **BR-017-AF-01** - (from Step 2) Session principal type does not require RTO: no visual attribute is applied to the RTO City field; Step 2 is skipped.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Invoice Type (`INV_TYPE`) | Conditional - invoiced-records mode | List Item | 3 | N/A | Invoice type codes | Form cleared | Re-enabled and navigable after clear | N/A |
| Print Status (`NB_PRINT`) | Conditional - invoiced-records mode | Radio Group | N/A | N/A | Print / Not Printed / All | Form cleared | Re-enabled and navigable after clear | N/A |
| Select/Deselect All (`NB_SEL_ALL`) | Optional | Check Box | 1 | N/A | N/A | Form cleared | Disabled after clear; label reset to "Deselect All" | N/A |
| RTO Name (`RT_CITY_DESC`) | Conditional - principal type requiring RTO | Character | 2000 | RTO master (LV_RTO) | RTO city description | Form cleared | Mandatory visual attribute applied for applicable principal type | N/A |

---

---

#### Requirement ID: BR-018

**Requirement Title:** Specific Error Message Display Interception

**Business Description:**
When an Oracle Forms internal error is raised during normal operation, the system intercepts it and displays a user-friendly message rather than the raw system error dialog. The active error handler maps specific error codes to business-readable messages: date errors are shown with guidance on the correct date format, character-type errors prompt the user to enter a numeric value, concurrent-update errors instruct the user to re-query the record before saving, and all other non-trivial errors are displayed using the standard application message format. Only the codes listed in the interception logic are handled; errors that do not match any branch are silently passed through (codes 40401 and 40405 are suppressed without display).

**Actors:** System

**Preconditions:**
- The Form 21 screen is open and an Oracle Forms error or message event has been raised.

**Main Flow:**

**Step 1 - Date-format error intercepted**
When Oracle Forms raises error code `50004`, the system displays the message *"Entered Date is not valid Date"* and raises a trigger failure to halt the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 50004 detected | ON-ERROR (Form level) - checks `ERROR_CODE IN (50004)` | When Oracle Forms raises error code 50004 | Replaces the raw Forms error with a plain-language date-validity message | *"Entered Date is not valid Date"* displayed; current operation halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-01** - Oracle Forms error `50004` raised - *"Entered Date is not valid Date"*; current operation stopped.

**Step 2 - Date-format hint intercepted**
When Oracle Forms raises error code `50025` or `50026`, the system displays the message *"Enter the Date in the proper format (DD-MM-YYYY)"* and raises a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 50025 or 50026 detected | ON-ERROR (Form level) - checks `ERROR_CODE IN (50025, 50026)` | When Oracle Forms raises a date-format error | Guides the user to enter dates in the application-required format | *"Enter the Date in the proper format (DD-MM-YYYY)"* displayed; current operation halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-02** - Oracle Forms error `50025` or `50026` raised - *"Enter the Date in the proper format (DD-MM-YYYY)"*; current operation stopped.

**Step 3 - Non-numeric character entry error intercepted**
When Oracle Forms raises error code `40209` or `50016`, the system displays the message *"Characters/Special Characters are not allowed here, enter the numeric value"* and raises a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 40209 or 50016 detected | ON-ERROR (Form level) - checks `ERROR_CODE IN (40209, 50016)` | When Oracle Forms raises a character-type or non-numeric entry error | Instructs the user that only numeric values are accepted in the affected field | *"Characters/Special Characters are not allowed here, enter the numeric value"* displayed; current operation halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-03** - Oracle Forms error `40209` or `50016` raised - *"Characters/Special Characters are not allowed here, enter the numeric value"*; current operation stopped.

**Step 4 - Required-field error intercepted**
When Oracle Forms raises error code `40207`, the system displays the native error text from Forms in the standard application message dialog and raises a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 40207 detected | ON-ERROR (Form level) - checks `ERROR_CODE IN (40207)` | When Oracle Forms raises a required-field or mandatory-item error | Displays the standard Forms required-field message in the application message format | Error text displayed; current operation halted |

**Step 5 - Concurrent-update conflict intercepted**
When Oracle Forms raises error codes `40654`, `40655`, `40656`, `40657`, or `40659` (record modified by another user), the system rolls back the pending change and displays the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* then raises a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Error code 40654, 40655, 40656, 40657, or 40659 detected | ON-ERROR (Form level) - checks `ERROR_CODE IN (40654, 40655, 40656, 40657, 40659)` | When another user has modified the record since it was queried | Informs the user that their pending changes cannot be saved because the record has changed; instructs re-query | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* displayed; pending change rolled back; current operation halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-04** - Concurrent-update error raised (`40654`-`40659` range) - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback performed; current operation stopped.

**Step 6 - ON-MESSAGE: informational message interception**
When Oracle Forms raises an internal informational message with code `40209` or `40207`, the system captures the error code, type, and text, then displays it in the standard application message dialog format (`[error type]-[error code]: [error text]`) and raises a trigger failure to halt the operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message code matches interception list | ON-MESSAGE (Form level) - checks `ERROR_CODE IN (40209, 40207)` | When Oracle Forms raises informational message code 40209 or 40207 | Replaces the default system message display with the application's standard message format for these specific codes | Error message shown as `[ERROR_TYPE]-[ERROR_CODE]: [ERROR_TEXT]`; trigger failure raised; current operation halted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-018-ES-05** - Oracle Forms message `40209` or `40207` raised via ON-MESSAGE - the message is shown as `[error type]-[error code]: [error text]` in the application message dialog; current operation is stopped.

**Alternative Flows:**
- **BR-018-AF-01** - (from Steps 1-5) The error code does not match any interception branch: if the Oracle DBMS error code is `-02292` (child-record constraint), a catalogued application error is raised; if the SQL error code is non-zero the SQL error message is displayed and a rollback is performed; error codes `40401` and `40405` are silently suppressed. All other errors are handled by Oracle Forms through its standard error mechanism.
- **BR-018-AF-02** - (from Step 6) The message code is not 40209 or 40207: Oracle Forms handles it through its standard message mechanism.

---

---

#### Requirement ID: BR-019

**Requirement Title:** Background Timer-Driven Processing

**Business Description:**
When an application timer fires while the Form 21 screen is open, the system delegates processing of the timer event to the shared application timer-expiry routine. The original inline timer logic for a printer-queue polling timer - which would have checked report job status and opened the completed report in a browser - is inactive and does not execute.

**Actors:** System

**Preconditions:**
- The Form 21 screen is open and an application timer has fired.

**Main Flow:**

**Step 1 - Timer expiry handled by shared application routine**
When a form timer expires, the system calls the shared general-purpose timer-expiry handler to perform any timer-driven processing defined in that routine.

*Procedures called:*
- **GENERAL.PROC_TIMER_EXPIRED** ([SP-011](#sp-011)) - GENERAL.PROC_TIMER_EXPIRED - handles the timer-expiry event for any active application timer; performs whatever timer-driven action the shared routine is configured to execute.
    * **Step 1** - Validate the input values.
    * **Step 2** - Retrieve the required business data.
    * **Step 3** - Apply business validations.
    * **Step 4** - Update the required records.
    * **Step 5** - Return the processing result.

**Alternative Flows:**
- **BR-019-AF-01** - (from Step 1) The original printer-queue polling logic (checking `PRINTER_QUEUE` timer status, showing a report document in the browser, or displaying *"report has failed"*) is (COMMENTED OUT / INACTIVE - does not execute).

---

---

#### Requirement ID: BR-020

**Requirement Title:** LOV-Driven RTO City Selection

**Business Description:**
The RTO City lookup on the selection criteria screen is populated from a dedicated list of RTO (Road Transport Office) city options maintained in the master data. The list shows the RTO city names for the current dealer and principal, and the user selects the applicable city from this list to associate it with the Form 21 print run.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 selection criteria screen is open.
- The current session is for a principal type that uses RTO city selection.

**Main Flow:**

**Step 1 - User selects RTO City from the lookup list**
The user opens the RTO City lookup, which presents the available RTO city names for the current dealer, location, and principal filtered from the RTO master. The user selects one, and the system populates the RTO City Description field with the selected value and the RTO City Code field with the corresponding code.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RTO Name (`RT_CITY_DESC`) | Conditional - principal type requiring RTO | Character | 2000 | RTO City list (LV_RTO sourced from RG_RTO - RTO_MASTER) | RTO city description | RTO master records configured | Selected from lookup; verified to exist before use | N/A |
| RTO City Code (`RT_CITY_CD`) | Auto-populated | Character | 10 | RTO City list (LV_RTO sourced from RG_RTO - RTO_MASTER) | RTO city code | RTO Name selected | Populated by LOV selection; not user-entered directly | N/A |

---

---

> **Note - Inactive / Non-executing Code**
>
> The following triggers and code blocks exist in the form source but are inactive and do not execute:
>
> - **ON-ERROR (Form level)** - The first DECLARE block in the ON-ERROR trigger body is commented out (`/* ... */`) and does not execute. The second DECLARE block IS active and executes; its full error-interception logic is documented in BR-018.
> - **PRE-TEXT-ITEM (CB_DUMMY.RT_CITY_DESC item level)** - Entire body is block-commented (wrapped in `/*...*/`); does not execute. Previously contained an RTO master existence check for principal type 2; that check now runs inline in the Print button action (WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT).
> - **KEY-UP (CB_DUMMY block level)** - Contains only `NULL;` (COMMENTED OUT / INACTIVE - does not execute).
> - **KEY-DOWN (CB_DUMMY block level)** - Contains only `NULL;` (COMMENTED OUT / INACTIVE - does not execute).
> - **WHEN-VALIDATE-ITEM (CB_DUMMY.INV_TYPE item level)** - Entire body is commented out; only `NULL;` executes (COMMENTED OUT / INACTIVE - does not execute). The commented-out logic would have validated that the Invoice Type field is not blank and shown a hint message if it was.
> - **PRE-INSERT (B_CUSTOMER block level)** - Contains only `NULL;` (COMMENTED OUT / INACTIVE - does not execute).
> - **WHEN-BUTTON-PRESSED (WEBUTIL.DUMMY item)** - Empty body (COMMENTED OUT / INACTIVE - does not execute).
> - **All WEBUTIL.WEBUTIL_* WHEN-CUSTOM-ITEM-EVENT triggers** - Empty bodies (COMMENTED OUT / INACTIVE - do not execute).
> - **Inline printer-queue polling block inside WHEN-TIMER-EXPIRED** - The timer-name check, report-status polling, `web.show_document` call, and "report has failed" message within WHEN-TIMER-EXPIRED are all commented out (COMMENTED OUT / INACTIVE - does not execute); only the `GENERAL.PROC_TIMER_EXPIRED` call executes.
> - **`KEY-LISTVAL` (Form level, active)** - This trigger implements generic LOV invocation for any field with an attached LOV. It contains no additional business logic beyond checking whether the current field has an LOV, displaying it, and moving to the next field on successful selection. Per the no-standalone-BR-for-LOV-invocation rule, it is not documented as a separate business requirement; its effect on the RTO City lookup is captured in BR-020's Data Elements.

---

---

#### Requirement ID: BR-021

**Requirement Title:** Delete Record with Confirmation

**Business Description:**
When the user clicks the Delete button, the system asks for explicit confirmation before removing the current record. If the user confirms the deletion, the system temporarily suspends field-level validation, deletes the record, and then restores validation. If the form has no pending changes the system instead clears the form without deleting a record. The Delete button must be enabled for any action to take effect.

**Actors:** Dealer User

**Preconditions:**
- The Form 21 screen is open.
- The Delete button is enabled.
- A record is loaded and available for deletion.

**Main Flow:**

**Step 1 - Delete confirmation requested**
When the user clicks the Delete button and the button is enabled, the system temporarily disables form-level validation and checks whether the form has any pending changes. If the form has changed data (indicating a record is loaded and ready), the system presents a confirmation dialog asking the user to confirm the delete action. If the user confirms, the current record is deleted. If the user does not confirm, the delete is abandoned and the form remains unchanged.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User must confirm deletion before record is removed | FT_DEL - checks `SYSTEM.FORM_STATUS = 'CHANGED'`; calls `GENERAL.ASK_CONFIRM('Are you sure to Delete')` | When the user clicks the Delete button and a loaded record is available | Prevents accidental deletion of data by requiring explicit user confirmation | User declines confirmation - deletion is abandoned; form remains open with data intact |

*Business outcomes (errors, warnings, success, and status):*
- **BR-021-WS-01** - User clicks Delete with a loaded record and confirms - *"Are you sure to Delete"* confirmation shown; record deleted; form-level validation restored.
- **BR-021-IC-01** - User clicks Delete when form has no pending changes - form cleared immediately; no deletion performed.

**Alternative Flows:**
- **BR-021-AF-01** - (from Step 1) Delete button is disabled: the button press has no effect; the form remains open.
- **BR-021-AF-02** - (from Step 1) User is presented with the confirmation but declines: deletion is abandoned; form data is preserved.

---

## 5. Business Rules Catalogue

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Application Performance Logging - Form Start | Derivation | BR-001 | Application performance logging is active at form open | System starts a performance timer to begin measuring form load time | Enables performance monitoring of form loading duration for the session |
| BRC-002 | Application Performance Logging - Form Load Completion | Derivation | BR-002 | Application performance logging is active when the first field becomes ready | System stops the performance timer and records the elapsed load time against the current user | Captures the form download duration for operational performance reporting |
| BRC-003 | Record Type Drives Filter Availability | Constraint | BR-003 | User selects the allotted-records option for record type | Invoice Type and Print Status filter fields are disabled and made non-navigable | Prevents users from entering invoice-specific filter criteria that do not apply to allotment records |
| BRC-004 | Record Type Restores Filter Availability | Constraint | BR-003 | User selects any record type other than allotted (invoiced-records mode) | Invoice Type and Print Status filter fields are enabled and made navigable | Allows users to apply invoice-specific filter criteria when working in invoiced-records mode |
| BRC-005 | From Date Must Not Be in the Future | Validation | BR-004 | From Date is entered and is later than today's date | Block save; display *"From date cannot be greater then todays date"*; cursor remains on field | Ensures the search date range boundary refers to a historical or current date, preventing meaningless future-date queries |
| BRC-006 | To Date Requires From Date | Validation | BR-005 | To Date is entered but From Date is blank | Clear the To Date field; display *"Enter a valid From date"*; cursor remains on field | Prevents an incomplete date range that would make the search boundary ambiguous |
| BRC-007 | To Date Must Not Precede From Date | Validation | BR-005 | To Date is earlier than From Date | Display *"To date cannot be less than From date"*; cursor remains on field | Prevents an inverted date range that would return no results |
| BRC-008 | Temporary Reg Number Entry Re-checks Date Range | Validation | BR-006 | To Date is present but From Date is absent when the Temporary Registration Number field is exited | Clear the To Date; display *"Enter a valid From date"* | Ensures date range consistency is maintained whenever a related filter field is updated |
| BRC-009 | Temporary Reg Number Entry - Date Order Check | Validation | BR-006 | To Date precedes From Date when the Temporary Registration Number field is exited | Display *"To date cannot be less than From date"* | Reinforces date range integrity when the user moves through the criteria section |
| BRC-010 | RTO Master Must Exist Before Field Entry | Validation | BR-007 | User enters the RTO City field and the session requires RTO verification, but no RTO records exist for the dealership | Display *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"*; return cursor to RTO City field | Prevents Form 21 printing configuration from proceeding without the required RTO master data |
| BRC-011 | RTO Master Required Only for Specific Principal Type | Authorization | BR-007 | Session principal type does not require RTO verification | RTO master existence check is skipped entirely | Limits the RTO prerequisite check to only those dealership types for which it is applicable |
| BRC-012 | RTO City Field Navigation Lock | Constraint | BR-008 | User presses the next-field navigation key while on the RTO City field | Cursor is returned to the RTO City field rather than moving to the next field | Ensures the user selects an RTO city before moving past the field in applicable sessions |
| BRC-013 | Query Result Set Limit | Constraint | BR-009 | More than 500 records match the specified search criteria | Clear all results; display *"More than 500 invoiced/alloted records found.Please specify different query details"*; return cursor to Query button | Prevents screen overload and unmanageably large result sets by enforcing a 500-record cap |
| BRC-014 | Query Must Return at Least One Record | Validation | BR-009 | No matching records are found for the entered search criteria | Display *"No alloted/invoiced records found"*; return cursor to Query button | Confirms the search criteria are valid and relevant before enabling the print actions |
| BRC-015 | Select All Marks All Records for Printing | Derivation | BR-010 | User clicks the Select/Deselect All toggle when labelled "Select All" | All records in the results list are marked as selected for printing; toggle label changes to "Deselect All" | Allows batch selection of all results for printing without individually marking each record |
| BRC-016 | Deselect All Clears All Print Selections | Derivation | BR-010 | User clicks the Select/Deselect All toggle when labelled "Deselect All" | All records in the results list are marked as not selected; toggle label changes to "Select All" | Allows the user to clear all print selections in one action to start over with individual selection |
| BRC-017 | Individual Selection Auto-Deselects Others | Constraint | BR-011 | User checks the print-selection indicator for a specific record | All other records are set to deselected; only the chosen record remains selected | Ensures that only one record at a time can be individually selected; supports single-record printing workflow |
| BRC-018 | Down Navigation Boundary at Last Record | Validation | BR-012 | User presses the down-navigation key and the current row is the last record | Display *"This is the Last Record...."*; navigation prevented | Prevents cursor from moving below the last row in the results list, providing clear boundary feedback |
| BRC-019 | Up Navigation Boundary at First Record | Validation | BR-012 | User presses the up-navigation key and the current row is the first record | Display *"This is the First Record...."*; navigation prevented | Prevents cursor from moving above the first row in the results list, providing clear boundary feedback |
| BRC-020 | RTO Master Required Before Printing | Validation | BR-013 | Print button pressed for principal type requiring RTO and no RTO records exist for the dealer | Display *"First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21"*; printing stopped | Prevents Form 21 from being printed without the mandatory RTO configuration for applicable principals |
| BRC-021 | RTO City Must Be Selected Before Printing | Validation | BR-013 | Print button pressed, RTO records exist for the dealer, but no RTO city has been selected | Display *"Please enter RTO"*; cursor moved to RTO City field; printing stopped | Ensures a specific RTO is identified on the form before the print job is submitted |
| BRC-022 | Invoice Print Lock Must Be Acquired | Validation | BR-013 | A selected invoice or allotment record is already locked by another user session | Record's print selection is cleared; invoice number added to the error list; locked records excluded from print run | Prevents concurrent duplicate Form 21 prints for the same record |
| BRC-023 | Locked Invoice Report on Invoice Records | Constraint | BR-013 | One or more invoices could not be locked and record type is Invoice | Display concatenated invoice numbers followed by *" Invoices Number Has been locked by Another User"* | Informs the user exactly which invoices were excluded from the print run due to concurrent locks |
| BRC-024 | No Duplicate Print Record for Invoice | Validation | BR-013 | A database duplicate-key error occurs while marking an invoice as Form 21 printed | Display *"Trying to create a duplicate record for invoice"*; printing stopped | Prevents the same invoice from being marked as Form 21 printed more than once |
| BRC-025 | Temporary Registration Not Allowed for Allotments in Print | Validation | BR-013 | Print button pressed with temporary-registration-certificate option selected and record type is Allotment | Display *"No Temporary Registration Certificate for alloted numbers"*; form cleared; printing stopped | Prevents an invalid combination of allotment-mode printing with the temporary-registration-certificate output type |
| BRC-026 | Word Conversion Not Allowed for Temporary Registration | Validation | BR-014 | Convert to Word button pressed and the temporary-registration-certificate option is selected | Display *"Conversion is not allowed for Temporary Registration Certificate"*; form cleared; conversion stopped | Prevents the temporary-registration-certificate from being generated in Word format, which is not supported |
| BRC-027 | Pre-commit Validation Must Pass | Validation | BR-015 | A failure is detected after the data validation pass that runs before committing | Raise trigger failure; database commit not attempted | Prevents invalid data from being written to the database |
| BRC-028 | Post-commit Failure Check | Validation | BR-015 | A failure is detected after the database commit | Raise trigger failure; form clear not performed | Detects any database-level commit error and halts further processing |
| BRC-029 | Form Clear Resets Control States | Constraint | BR-017 | User clears the form | Invoice Type and Print Status re-enabled; Select/Deselect All disabled with label "Deselect All"; Print and Convert to Word buttons disabled | Ensures the form returns to a consistent starting state so the next query begins from a clean slate |
| BRC-030 | RTO City Mandatory Style Applied on Clear | Derivation | BR-017 | Form is cleared in a session where the principal type requires RTO entry | RTO City field is styled with the mandatory visual attribute | Provides immediate visual guidance that the RTO City must be populated before printing |
| BRC-031 | Error Code Interception | Constraint | BR-018 | Oracle Forms internal error code 40209 or 40207 is raised | Display error as `[error type]-[error code]: [error text]` via the standard message dialog; raise trigger failure | Ensures specific internal form errors are surfaced to the user in the standard application format rather than as raw system dialogs |

**Total Business Rules Identified: 31**

---

## 6. Data Requirements

*This section covers the business entities referenced and populated by the Form 21 printing screen, the data captured from users, the reference data used to drive filter lookups, and the lifecycle of records as they are queried and updated during Form 21 printing.*

### 6.1 Business Entities and Relationships

*The form queries vehicle allotment and invoice records, enriches them with customer and financier information, and updates the Form 21 print status on invoice records. It also reads RTO master data and dealer configuration parameters.*

#### Vehicle Invoice - SH_INVOICE

The vehicle invoice entity holds the record of each vehicle sale transaction that has been invoiced. The form queries this entity to retrieve invoices for Form 21 printing, filters results by invoice type and print status, and updates the Form 21 print flag once an invoice is selected for printing.

#### Vehicle Allotment - ST_ALLOT

The vehicle allotment entity records the allocation of vehicles to orders before invoicing. The form queries this entity to retrieve allotted records that have not yet been invoiced, so that Form 21 can be printed at the allotment stage.

#### Order Book - SH_ORDBOOK

The order book entity links allotments and invoices to the originating customer order. The form joins this entity to the allotment and invoice tables to resolve the customer and financier associated with each record displayed in the results list.

#### Customer Identity - GM_CIN

The customer identity entity holds the customer's full name. The form reads this entity (via the order book) to display the customer name alongside each allotment record in the results list.

#### Party Master - GM_PARTY

The party master entity holds details of financing institutions (financiers). The form reads this entity to populate the Financier Code and Financier Description fields shown for each record in the results list.

#### RTO Master - RTO_MASTER

The RTO (Road Transport Office) master stores the RTO city records configured for each dealership and principal. The form reads this entity to verify that RTO data has been set up before printing (for applicable principal types) and to populate the RTO City lookup list.

#### Dealer Location Parameters - AM_DEALER_LOC_PARAM

The dealer location parameters entity holds configuration flags for the dealership location. The form reads the price-display flag from this entity when building the parameters for the Form 21 report.

#### Entity Relationships

The invoice and allotment entities each link to the order book through their order number; the order book links to customer identity and to the financier via the party master. The RTO master and dealer location parameters are independent reference entities used for configuration and validation.

```
SH_INVOICE (Vehicle Invoice)
        └── SH_ORDBOOK (Order Book) via ORDER_NUM
                └── GM_PARTY (Financier - Party Master) via FI_CD

ST_ALLOT (Vehicle Allotment)
        └── SH_ORDBOOK (Order Book) via ORDER_NUM
                ├── GM_CIN (Customer Identity) via CUST_CD
                └── GM_PARTY (Financier - Party Master) via FI_CD

RTO_MASTER (RTO Configuration - independent reference)

AM_DEALER_LOC_PARAM (Dealer Configuration - independent reference)
```

### 6.2 Data Capture Requirements

*The form captures search criteria from the user before querying records. No direct data entry of invoice or allotment data occurs; user interaction is limited to filter and selection fields. The print flag on invoice records is updated programmatically when records are submitted for printing.*

#### Search Criteria - Selection Filters (User - before querying)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Record Type (`NB_TYPE`) | Yes | Selects whether the query should retrieve allotted vehicle records or invoiced vehicle records | Must be selected; drives which query branch and which filter fields apply |
| Invoice Type (`INV_TYPE`) | Conditional | Filters invoiced records by their invoice category; not applicable for allotment queries | Required when invoiced-records mode is active; enabled only in that mode |
| Print Status (`NB_PRINT`) | Conditional | Filters invoiced records by whether Form 21 has already been printed (`P`), not yet printed (`N`), or both (`A`) | Applicable only in invoiced-records mode; ignored for allotment queries |
| From Date (`NB_FRM_DATE`) | No | Optional start date for filtering records by their invoice or allotment date | When entered, must not be in the future; must be present when To Date is used |
| To Date (`NB_TO_DATE`) | No | Optional end date for filtering records by their invoice or allotment date | When entered, From Date must already be present; must not be earlier than From Date |
| Temporary Reg No (`NB_TMP_NO`) | No | Optional temporary registration number to include in Form 21 printing for invoice-mode runs | When entered, date range re-validation is triggered; passed to the report as a parameter |
| RTO Name (`RT_CITY_DESC`) | Conditional | RTO city selected from the RTO City lookup; required for applicable principal types | For principal types requiring RTO: at least one RTO record must exist in the master; a city must be selected before printing |
| Print Temporary Registration (`CB_TEMP_REP`) | No | Checkbox indicating that the temporary-registration-certificate variant of Form 21 should be printed instead of the standard version | Not allowed in combination with Word conversion; not applicable for allotment-mode |
| Print Line Option (`CB_LINE`) | No | Checkbox indicating whether the horizontal line should be included in the Form 21 report output | Passed to the report as a formatting parameter |

#### Record Selection - Print Selection (User - after query results are loaded)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Print Flag (`FORM21_YN`) | No | Per-record indicator set by the user to include or exclude that record from the next print run | Toggled individually per record or in bulk via Select/Deselect All; individual selection auto-deselects all others |

#### Session and Global Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application Log Flag (`GLOBAL.APP_LOG`) | Auto-Populated | Indicates whether performance logging is active for the current session (`Y`/`N`) | System-read only; controls whether performance timers are started and stopped |
| Principal (`GLOBAL.PRINCIPAL`) | Auto-Populated | The principal type code for the current session | Determines whether RTO verification is required and which report server/branch is used |
| Dealer (`GLOBAL.DEALER`) | Auto-Populated | The dealer code for the current session | Applied as a filter on all queries and procedure calls |
| Location (`GLOBAL.LOC_CD`) | Auto-Populated | The location code for the current session | Applied as a filter on all queries and procedure calls |
| Parent Group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | The parent-group code for the current session | Applied as a filter on all queries and procedure calls |
| Company (`GLOBAL.COMP_FA`) | Auto-Populated | The company code for the current session | Applied as a filter on all queries and procedure calls |
| User Identity (`GLOBAL.USER_ID`) | Auto-Populated | The user identifier for the current session | Used in performance log entries |
| Selected Invoice Parameter (`PARAMETER.P_INVNUM`) | Auto-Populated | Stores the invoice number of the most recently individually-selected record during the single-record selection logic | Temporary working value; set programmatically during the individual print-selection loop |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| RTO City list (LV_RTO / RG_RTO - RTO_MASTER) | Provides the list of Road Transport Office city names and codes available for the current dealer, location, and principal | When the user opens the RTO City lookup or when the RTO City field is pre-validated before printing |
| RTO Master count (RTO_MASTER - direct query) | Verifies that at least one RTO record has been configured for the dealership before the RTO City field or the Print button is used | When the user enters the RTO City field (pre-text validation) and when the Print button is pressed, for principal types that require RTO verification |
| Dealer Location Parameters (AM_DEALER_LOC_PARAM) | Supplies the price-display configuration flag (`X_F_PRICE_YN`) used as a report parameter when generating Form 21 | When the print or Word-conversion report job is submitted |
| Invoice records (SH_INVOICE) | Source of invoiced vehicle records returned in the query results list | When the user queries invoiced records |
| Allotment records (ST_ALLOT) | Source of allotted vehicle records (not yet invoiced) returned in the query results list | When the user queries allotted records |
| Customer identity (GM_CIN) | Provides the customer's full name for display alongside each allotment record | When allotted-record query results are loaded |
| Order book (SH_ORDBOOK) | Links allotments and invoices to their originating orders for customer and financier resolution | When query results are loaded and when financier details are fetched |
| Financier / party master (GM_PARTY) | Provides the financier name and branch for display alongside each record | When financier details are fetched after the query results are loaded |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- The form does not create new invoice or allotment records. All records displayed are pre-existing database records retrieved by the query.

**Updates**

- When the user submits a print or Word-conversion job for invoiced records that have not yet been marked as printed, the system updates the `FORM21_YN` flag on the matching `SH_INVOICE` records to `Y`, recording that Form 21 has been generated for those invoices. This update is performed within the `FORM_REP_PARAM` program unit and committed to the database before the report job is submitted.
- The print-flag update applies only to Invoice-type records when the Print Status filter is not set to "Already Printed" - records already marked as printed are not updated again.

**Save and Commit**

- Data is committed to the database automatically within `FORM_REP_PARAM` as part of the print/convert workflow for invoice records.
- A user-initiated save action (via the save key) triggers a validation pass, commits any pending changes, and then clears the form. Both pre-commit and post-commit failure checks are applied.
- If application performance logging is active, a performance log commit is also performed after the query results are loaded, as a separate commit within the query-loading flow.

**Retention and Audit**

- The form reads `CREATED_BY`, `CREATED_DATE`, `MODIFIED_BY`, and `MODIFIED_DATE` columns from the `SH_INVOICE` datasource column list, indicating that the invoice entity carries audit stamps. The form does not directly display or update these audit columns - they are part of the underlying entity definition.
- No archival, purge, or retention policy is defined or enforced by this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| Allotment | A vehicle stock allocation record (ST_ALLOT) representing a vehicle assigned to a dealer before invoicing | ALLOT | Invoice, Order |
| AM_DEALER_LOC_PARAM | Dealer location parameters table storing location-specific configuration flags (e.g. price display flag) | - | Dealer, Location |
| B_CUSTOMER | Results data block in st_frm21 displaying the queried invoice or allotment records for selection | - | CB_DUMMY, Block |
| BRD | Business Requirements Document - formal specification of functional and technical requirements | - | Functional Requirements |
| BTN | Booking Token Number - unique identifier for vehicle booking or pre-order reference | Booking Number | Order, Allotment |
| CB_DUMMY | Control block in st_frm21 holding search filter inputs (report type, date range, invoice type, RTO city) | - | B_CUSTOMER, Block |
| COMP_FA | Company Financial Area code - identifies the financial accounting unit of the dealer | - | Dealer, Principal |
| DMS | Dealer Management System - integrated software platform for dealership operations including sales and vehicle registration | - | System |
| DPL | Dealer Program Library - shared Oracle Forms PL/SQL program library (DPL.pld) providing common utility routines | - | PLD, General |
| FORM21_YN | Print selection flag on each result record - Y means the record is selected for Form 21 printing | - | Form 21 |
| Form 21 | Government-prescribed vehicle delivery/registration document required when a vehicle is sold and transferred | - | RTO, Invoice |
| GENERAL | Package name of the DPL shared library routines (e.g. GENERAL.DISP_TEXT, GENERAL.CHECK_FORM_FAILURE) | DPL General | DPL, PLD |
| Invoice | A vehicle sales invoice record (SH_INVOICE/VEH_INVOICE) documenting the vehicle sale to a buyer | INV | Allotment, SH_INVOICE |
| LOV | List of Values - dropdown selection popup in Oracle Forms for selecting from pre-defined values | Dropdown, Picklist | RG_RTO, LV_RTO |
| LOC_CD | Location code identifying the dealer branch within the DMS session | - | Dealer, PARENT_GROUP |
| LV_RTO | LOV object in st_frm21 that uses the RG_RTO record group to let the user select an RTO city | - | RG_RTO, RTO |
| OLB | Object Library - Oracle Forms binary library (DPL.olb) providing inherited property classes and objects | - | DPL, Property Class |
| PARENT_GROUP | Parent group code identifying the dealer group hierarchy in multi-group DMS configurations | - | Dealer, COMP_FA |
| PDF | Portable Document Format - the output format used when generating Form 21 reports for printing | - | Report Server, Form 21 |
| PLD | Program Library Definition - Oracle Forms shared PL/SQL library file (DPL.pld) attached to the form | - | DPL, GENERAL |
| PRINCIPAL | Principal map code identifying the vehicle manufacturer/brand associated with the dealer | - | Dealer, RTO |
| QRY_RECORDS | Form-local PL/SQL package in st_frm21 that defines the cursor and record type used to query invoice/allotment records | - | B_CUSTOMER, SH_INVOICE |
| REP_SERVER | Report server name stored as a global variable; identifies the Oracle Reports Server used for Form 21 generation | - | Report Server |
| RG_RTO | Record group in st_frm21 containing the SQL query that retrieves RTO city records for the LOV | - | LV_RTO, RTO_MASTER |
| RTO | Road Transport Office - government authority responsible for vehicle registration; RTO city is recorded on Form 21 | - | RTO_MASTER, Form 21 |
| RTO_MASTER | Database table storing RTO city master data per dealer, location, and principal | - | RTO, RG_RTO |
| SH_INVOICE | Sales invoice header table (SH_INVOICE) used to query invoiced vehicle records and fetch financier details | - | Invoice, VEH_INVOICE |
| SH_ORDBOOK | Sales order book table storing vehicle order information including financier code and branch details | - | Order, ST_ALLOT |
| ST_ALLOT | Stock allotment table storing vehicle allotment records used when report type is Allotment | - | Allotment, SH_INVOICE |
| ST_FRM21 | Module name of the Oracle Forms application for Form 21 Printing - the subject of this BRD | st_frm21 | Form 21, DMS |
| VEH_INVOICE | Vehicle invoice table used as the data source reference for the CB_DUMMY control block DataSourceColumns | - | Invoice, SH_INVOICE |
| WEBUTIL | Oracle Forms WebUtil library providing client-side utilities; included but no active routines are called in st_frm21 | - | OLB, DPL |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: st_frm21 (ST_FRM21)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Forms21 (inherited from DPL object group)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb
- Source artifacts: `st_frm21_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed at form startup; used for session context tracking |
| APP_LOG | Char | ProgramUnit / Trigger | Application logging flag (Y/N) used to start/stop performance timer |
| COMP_FA | Char | ProgramUnit / Trigger | Company/financial area code of the logged-in dealer context |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Dealer map code identifying the active dealer session |
| LOC_CD | Char | ProgramUnit / RecordGroup / Trigger | Location code of the dealer branch currently active |
| PARENT_GROUP | Char | ProgramUnit / RecordGroup / Trigger | Parent group code used to filter multi-group dealer data |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal (manufacturer) map code controlling RTO and report behaviour |
| PRINTED | Char | Trigger | Flag set at runtime to track whether the current report job has been sent to the printer |
| PRINTOUTPUT | Char | ProgramUnit / Trigger | Report output file name used by the printer queue timer |
| REPORTHANDLE | Char | ProgramUnit / Trigger | Report server job handle for monitoring async report execution |
| REPORT_SERVER | Char | Trigger | Report server name resolved at trigger level for immediate report dispatch |
| REP_SERVER | Char | ProgramUnit | Report server name read from configuration file at form startup |
| USERID | Char | ProgramUnit / Trigger | Application user ID used for logging and report parameter passing |
| USER_ID | Char | Trigger | User identifier set by application logging trigger for stop-watch recording |
| USER_NAME | Char | Trigger | Display name of the logged-in user, set at session initialisation for use in report headers and audit context |

### 8.1.2 Form Parameters

*All 3 ModuleParameter entries from st_frm21_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application identifier passed at form startup; reserved for application-level session context |
| NEW_REC | Char | Y | Controls new-record behaviour at startup; default Y indicates form opens ready for new entries |
| P_INVNUM | Char | - | Incoming invoice number passed when form is called from a parent menu or external context |

**Total Parameters:** 3

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DUMMY | VEH_INVOICE | 1 | N/N/N/N | Default | Control - entry block for search criteria; no direct DML; navigates to B_CUSTOMER |
| B_CUSTOMER | - | 15 | N/N/N/N | Default | - |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from st_frm21_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in st_frm21_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `st_frm21_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DUMMY | 17 | 0 | 17 |
| B_CUSTOMER | 12 | 0 | 12 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **51** | **0** | **51** |

**Item detail (all 51 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | NB_TYPE | false | Radio group - selects report type: Allotment (A) or Invoice (I) |
| CB_DUMMY | INV_TYPE | false | Dropdown list - invoice type filter for the query |
| CB_DUMMY | NB_PRINT | false | Radio group - print status filter: Printed (P) or Not Printed (N) |
| CB_DUMMY | NB_FRM_DATE | false | From date search filter; must not exceed today's date |
| CB_DUMMY | NB_TO_DATE | false | To date search filter; must be entered with a valid from date |
| CB_DUMMY | RTO_CITY | false | RTO city code populated from RTO Name LOV selection |
| CB_DUMMY | PB_QUERY | false | Query button - navigates to B_CUSTOMER block to load matching records |
| CB_DUMMY | NB_TEXT_AREA | false | Text area for additional input or display information |
| CB_DUMMY | NB_CHK_YN | false | Checkbox - controls whether contact numbers are printed on the form |
| CB_DUMMY | NB_SEL_ALL | false | Toggle button - selects or deselects all records in B_CUSTOMER for printing |
| CB_DUMMY | CB_LINE | false | Checkbox - controls whether a separator line is printed on the report |
| CB_DUMMY | NB_TMP_NO | false | Temporary registration number filter for report selection |
| CB_DUMMY | CB_TEMP_REP | false | Checkbox - controls whether temporary registration certificate is printed |
| CB_DUMMY | RT_CITY_CD | false | RTO city code (return value) from the RTO LOV |
| CB_DUMMY | RT_CITY_DESC | false | RTO city description displayed in the LOV lookup field |
| CB_DUMMY | NB_REG_CHECK | false | Radio group - controls permanent/temporary registration type selection |
| CB_DUMMY | NB_CUST_DET | false | Radio group - controls whether customer details are included in the report |
| B_CUSTOMER | NB_INV_NUM | false | Invoice or allotment number for the queried record |
| B_CUSTOMER | NB_IA_DATE | false | Invoice or allotment date for the displayed record |
| B_CUSTOMER | SPA_NAME | false | Customer name associated with the invoice or allotment |
| B_CUSTOMER | FIN_CD | false | Financier code for the vehicle purchase financing |
| B_CUSTOMER | FIN_DESC | false | Financier description (name and branch) for the financed vehicle |
| B_CUSTOMER | FORM21_YN | false | Checkbox - marks whether Form 21 should be printed for this record |
| B_CUSTOMER | PB_PRINT | false | Print button - generates Form 21 report for selected records in PDF or on-screen |
| B_CUSTOMER | PB_CONV_WRD | false | Convert to Word button - generates Form 21 report in Word format |
| B_CUSTOMER | REQUIRED | false | Internal flag field; used for required-state tracking |
| B_CUSTOMER | ORDER_NUM | false | Order number associated with the vehicle allotment or invoice |
| B_CUSTOMER | NB_PRINT_YN | false | Print status flag indicating whether the record has already been printed |
| B_CUSTOMER | NB_CUST_CD | false | Customer code for the party associated with this invoice or allotment |
| PB_BLK | PB_EXIT | false | (inherited) Toolbar Exit button - exits the current form; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_LIST | false | (inherited) Toolbar List button - invokes the LOV for the current item; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_INSERT | false | (inherited) Toolbar Insert button - inserts a new record into the current block; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PM_CONT | false | (inherited) Toolbar context/menu placeholder item; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_DEL | false | (inherited) Toolbar Delete button - deletes the current record; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_CANCEL | false | (inherited) Toolbar Cancel button - cancels pending changes in the current block; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_SAVE | false | (inherited) Toolbar Save button - commits changes to the database; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_PRINT | false | (inherited) Toolbar Print button - triggers the standard DPL print action; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_CUT | false | (inherited) Toolbar Cut button - cuts the selected text or record; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_COPY | false | (inherited) Toolbar Copy button - copies the selected text or record; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_PASTE | false | (inherited) Toolbar Paste button - pastes cut/copied content; inherited from DPL OG_GROUP PB_BLK block |
| PB_BLK | PB_ERR_EXIT | false | (inherited) Toolbar Error-Exit button - exits the form on error condition; inherited from DPL OG_GROUP PB_BLK block |
| CB_ERR | TXT_ERR | false | (inherited) Text item on the error canvas (CN_ERR) used to display runtime error messages; inherited from DPL OG_GROUP CB_ERR block |
| WEBUTIL | DUMMY | false | **INACTIVE** - Inherited stub item from WEBUTIL block; WHEN-BUTTON-PRESSED trigger has an empty body (no logic); does not execute any business logic |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil client-information API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil client-side file-system API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil host-command API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil session-management API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil file-transfer API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil OLE automation API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil C-API calls; inherited from webutil.olb WEBUTIL object group |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | (inherited) Bean-area item that dispatches WebUtil browser-control API calls; inherited from webutil.olb WEBUTIL object group |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_RTO | RTO Master Details | RG_RTO | CB_DUMMY.RT_CITY_DESC |

**Total LOVs:** 1

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Inherited from webutil.olb; invoked by WebUtil infrastructure on client-side errors |
| AL_REPORT | Forms21 | Do you want to ? | ProgramUnit: CALL_REPORT_SR_FORM21; ProgramUnit: CALL_REPORT_SR_FORM21_WRD |
| ALT_TITLE | FORM21 REPORT | Print Report With Title Or Without Title | ProgramUnit: CALL_REPORT_SR_FORM21; ProgramUnit: CALL_REPORT_SR_FORM21_WRD |
| AL_PRINT | Print | (set at runtime) | (inherited) Standard DPL print-confirmation alert; invoked by DPL library print routines |
| AL_ERRINFO | Error | (set at runtime) | (inherited) Standard DPL error-display alert; invoked by GENERAL.DISP_TEXT for error-type messages |
| AL_NOTE | Note | (set at runtime) | (inherited) Standard DPL informational alert; invoked by GENERAL.DISP_TEXT for note-type messages |
| AL_CONFIRM | Caution | (set at runtime) | (inherited) Standard DPL confirmation alert; invoked by GENERAL.ASK_CONFIRM for user-confirmation prompts |

**Total Alerts:** 7

### 8.6 Program Units

*Authoritative catalogue of **7 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| QRY_RECORDS | Package spec | SH_INVOICE, ST_ALLOT, GM_CIN, SH_ORDBOOK | Form-local package that defines a cursor type and QUERY_RECORDS procedure; called from WHEN-NEW-BLOCK-INSTANCE to load invoice or allotment records matching the search criteria |
| CALL_REPORT_SR_FORM21 | Procedure | GENERAL.DISP_TEXT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER, AL_REPORT, ALT_TITLE, AM_DEALER_LOC_PARAM | Builds report parameters and runs the Form 21 report (PDF/screen); invoked by PB_PRINT after parameters are assembled |
| FORM_REP_PARAM | Procedure | GENERAL.DISP_TEXT, SH_INVOICE | Iterates over selected B_CUSTOMER records and builds the invoice or allotment number filter string used in report parameters; called by PB_PRINT and PB_CONV_WRD |
| FETCH_PARTY_DET | Procedure | SH_ORDBOOK, ST_ALLOT, GM_PARTY, SH_INVOICE | Fetches financier code and description for each displayed record from allotment and invoice data; populates FIN_CD and FIN_DESC items |
| CALL_REPORT_SR_FORM21_WRD | Procedure | GENERAL.DISP_TEXT, GENERAL.PROC_REPORT_CALL, GENERAL.PROC_TIMER, AL_REPORT, ALT_TITLE, AM_DEALER_LOC_PARAM | Builds report parameters and runs the Form 21 report in Word format; invoked by PB_CONV_WRD |
| SET_REPORT_SERVER | Procedure | TEXT_IO (file read) | Reads the report server name from a configuration text file and sets :global.rep_server; called with flag 1 for Word and flag 2 for PDF reports |
| CHECK_RTO_CREATED | Procedure | GENERAL.DISP_TEXT, RTO_MASTER | Verifies that an RTO record exists for the current dealer/location when principal is 2; displays error and aborts if RTO master is missing |

**Total Program Units:** 7

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Presents a confirmation alert to the user and returns the button choice; used to confirm destructive or irreversible actions before proceeding |
| GENERAL.DISP_TEXT | Library routine | B_CUSTOMER, B_CUSTOMER.FORM21_YN, B_CUSTOMER.PB_CONV_WRD, B_CUSTOMER.PB_PRINT, CB_DUMMY.INV_TYPE, CB_DUMMY.NB_FRM_DATE, CB_DUMMY.NB_TMP_NO, CB_DUMMY.NB_TO_DATE, CB_DUMMY.RT_CITY_DESC, Form level, ProgramUnit: CALL_REPORT_SR_FORM21, ProgramUnit: CALL_REPORT_SR_FORM21_WRD, ProgramUnit: CHECK_RTO_CREATED, ProgramUnit: FORM_REP_PARAM | Displays a message dialog with the supplied text and title; uses AL_ERRINFO for errors or AL_NOTE for informational messages |
| GENERAL.PROC_REPORT_CALL | Library routine | ProgramUnit: CALL_REPORT_SR_FORM21 | Configures a report object for batch file output, sets report server, runs the report, and returns the job handle and output file name |
| ASK_PRINT | Function | ProgramUnit: CALL_REPORT_SR_FORM21, ProgramUnit: CALL_REPORT_SR_FORM21_WRD | Presents a three-button alert (View/Print/Close) and returns the user's print destination choice |
| CHECK_DATE | Procedure | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_FRM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TO_DATE | Validates that the date field value does not exceed today's date; raises error if future date entered |
| CHECK_FORM_FAILURE | Procedure | Trigger: KEY-COMMIT in Form | Checks Oracle Forms success flag after enter/commit; raises FORM_TRIGGER_FAILURE with error message on failure |
| CHECK_NULL | Procedure | Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_FRM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TO_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TMP_NO | Validates that a field value is not null; displays 'Enter a valid {column_title}' error and stops execution |
| CREATE_RECGRP_ROW | Procedure | ProgramUnit: FORM_REP_PARAM | Creates or updates a row in a named record group; used to build invoice/allotment filter lists |
| DROP_RECGRP | Procedure | ProgramUnit: FORM_REP_PARAM | Deletes an existing record group by name; used to clean up filter record groups after report generation |
| DUP_REC_CHECK | Function | ProgramUnit: FORM_REP_PARAM | Checks whether a value already exists in a named record group; prevents duplicate invoice/allotment numbers in the report parameter list |
| EXC_QUERY | Procedure | Trigger: WHEN-NEW-BLOCK-INSTANCE in B_CUSTOMER | Executes a query with locking on the current block when block status is NEW |
| PROC_TIMER | Procedure | ProgramUnit: CALL_REPORT_SR_FORM21 | Creates a repeating timer named PRINTER_QUEUE that fires every 5 seconds to poll report execution status |
| PROC_TIMER_EXPIRED | Procedure | Trigger: WHEN-TIMER-EXPIRED in Form | Polls report object status on PRINTER_QUEUE timer expiry; opens the report output in browser when finished or shows error if failed |
| RAISE_ERROR | Procedure | Trigger: ON-ERROR in Form | Looks up message text by error code and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |
| RUN_REPORT | Procedure | ProgramUnit: CALL_REPORT_SR_FORM21_WRD | Configures and runs a named report object with specified destination type (cache/screen/file/printer) and parameters |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | FT_DEL | Previously executed a standard DPL delete-record action at the form toolbar level | Logic block-commented; delete action suppressed for this form; records are display-only |
| **Inactive stub** | CB_DUMMY | - | KEY-UP | No keyboard upward navigation behaviour - body is null | Null stub; upward navigation disabled for control block |
| **Inactive stub** | CB_DUMMY | - | KEY-DOWN | No keyboard downward navigation behaviour - body is null | Null stub; downward navigation disabled for control block |
| **Commented out** | CB_DUMMY | INV_TYPE | WHEN-VALIDATE-ITEM | Previously validated that INV_TYPE was not null on item exit, displaying hint text as error | Logic block-commented; superseded by form-level flow control |
| **Inactive stub** | B_CUSTOMER | - | PRE-INSERT | No pre-insert processing - body is null | Null stub; no pre-insert validation required for this display-only block |
| **Commented out** | CB_DUMMY | RT_CITY_DESC | PRE-TEXT-ITEM | Previously checked RTO master records for the current dealer and principal before allowing entry into the RTO City field | Logic block-commented - entire body wrapped in `/*...*/`; this check now executes inline within the Print button action (WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT) |
| **Inactive stub** | Form | - | ON-ERROR | Inherited Oracle Forms error-handling trigger; no custom body defined in this form | Empty body - subclass inherited from DPL with no override text; Oracle default error handling applies |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously called GENERAL.ASK_CONFIRM before exiting the form; confirmation prompt was removed | Logic block-commented; exit now proceeds without confirmation in this form context |
| **Inactive stubs (WEBUTIL - 8 triggers)** | WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_CLIENTINFO_FUNCTIONS | WHEN-CUSTOM-ITEM-EVENT | 8 WebUtil bean-area triggers inherited from the WEBUTIL object group - no body defined in this form | All 8 are subclass-inherited stubs with no TriggerText; WebUtil client-side function dispatching is handled by the WebUtil infrastructure, not by form-level trigger logic |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (51 business triggers):**

*st_frm21_fmb.xml contains Trigger elements. All inactive triggers are identified in Section 8.7.1 above.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **INACTIVE** - Inherited from DPL object group with no custom body; Oracle default error handling applies; does not execute any custom logic |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms messages 40209 and 40207; displays them as error dialogs and raises trigger failure |
| KEY-EXIT | Form | - | Form level | Exits the form without validation when the exit key is pressed |
| KEY-LISTVAL | Form | - | Form level | Displays the LOV associated with the current item when the list key is pressed; navigates to next item on selection |
| KEY-COMMIT | Form | - | Form level | Executes ENTER, checks form success, commits the form, checks success again, then clears the form |
| KEY-CLRFRM | Form | - | Form level | Clears form without validation and resets CB_DUMMY item properties (INV_TYPE, NB_PRINT, NB_SEL_ALL) to enabled state |
| KEY-OTHERS | Form | - | Form level | (inherited) Suppresses unhandled key events at the form level; inherited from DPL OG_GROUP |
| KEY-NEXT-ITEM | Form | - | Form level | (inherited) Navigates to the next item in the tab order; inherited from DPL OG_GROUP |
| KEY-PREV-ITEM | Form | - | Form level | (inherited) Navigates to the previous item in the tab order; inherited from DPL OG_GROUP |
| KEY-NXTBLK | Form | - | Form level | (inherited) Navigates to the next block; inherited from DPL OG_GROUP |
| KEY-PRVBLK | Form | - | Form level | (inherited) Navigates to the previous block; inherited from DPL OG_GROUP |
| KEY-DOWN | Form | - | Form level | (inherited) Moves focus down one record at the form level; inherited from DPL OG_GROUP |
| KEY-UP | Form | - | Form level | (inherited) Moves focus up one record at the form level; inherited from DPL OG_GROUP |
| FT_SAVE | Form | - | Form level | (inherited) Toolbar Save trigger - commits pending changes; inherited from DPL OG_GROUP |
| FT_CANCEL | Form | - | Form level | (inherited) Toolbar Cancel trigger - cancels pending changes; inherited from DPL OG_GROUP |
| FT_INSERT | Form | - | Form level | (inherited) Toolbar Insert trigger - inserts a new record into the current block; inherited from DPL OG_GROUP |
| FT_DEL | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Previously executed a standard DPL delete-record action; logic is block-commented; delete action suppressed for this form |
| FT_LIST | Form | - | Form level | (inherited) Toolbar List trigger - invokes the LOV for the current item; inherited from DPL OG_GROUP |
| FT_PRINT | Form | - | Form level | (inherited) Toolbar Print trigger - invokes the standard DPL print action; inherited from DPL OG_GROUP |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | (inherited) Initialises form-level session globals (DEALER, LOC_CD, USERID, etc.) and sets up the form title and toolbar state; inherited from DPL OG_GROUP |
| PRE-FORM | Form | - | Form level | Starts application performance logging timer if global APP_LOG flag is Y |
| WHEN-TIMER-EXPIRED | Form | - | Form level | Delegates to GENERAL.PROC_TIMER_EXPIRED to poll report print queue status and open completed report output |
| KEY-UP | CB_DUMMY | - | CB_DUMMY | **INACTIVE** - Null stub; no upward navigation in control block |
| KEY-DOWN | CB_DUMMY | - | CB_DUMMY | **INACTIVE** - Null stub; no downward navigation in control block |
| WHEN-RADIO-CHANGED | CB_DUMMY | NB_TYPE | CB_DUMMY.NB_TYPE | Enables or disables INV_TYPE and NB_PRINT items based on selected report type (A=Allotment disables both) |
| WHEN-NEW-ITEM-INSTANCE | CB_DUMMY | NB_TYPE | CB_DUMMY.NB_TYPE | Stops application performance logging timer with form identifier when focus enters NB_TYPE |
| WHEN-VALIDATE-ITEM | CB_DUMMY | INV_TYPE | CB_DUMMY.INV_TYPE | **COMMENTED OUT / INACTIVE** - Previously validated INV_TYPE not null; logic is block-commented |
| WHEN-VALIDATE-ITEM | CB_DUMMY | NB_FRM_DATE | CB_DUMMY.NB_FRM_DATE | Validates that From Date is not in the future; also checks that To Date has a corresponding From Date |
| WHEN-VALIDATE-ITEM | CB_DUMMY | NB_TO_DATE | CB_DUMMY.NB_TO_DATE | Validates To Date is not entered without a From Date; also validates To Date is not before From Date |
| WHEN-BUTTON-PRESSED | CB_DUMMY | PB_QUERY | CB_DUMMY.PB_QUERY | Navigates to the B_CUSTOMER block to execute the data query |
| WHEN-CHECKBOX-CHANGED | CB_DUMMY | NB_SEL_ALL | CB_DUMMY.NB_SEL_ALL | Toggles FORM21_YN for all B_CUSTOMER records between Y and N based on Select All/Deselect All state |
| WHEN-VALIDATE-ITEM | CB_DUMMY | NB_TMP_NO | CB_DUMMY.NB_TMP_NO | Validates that To Date has a From Date when temporary registration number is entered |
| PRE-TEXT-ITEM | CB_DUMMY | RT_CITY_DESC | CB_DUMMY.RT_CITY_DESC | **COMMENTED OUT / INACTIVE** - Previously checked RTO master records for the current dealer; logic is block-commented (entire body wrapped in `/*...*/`); does not execute |
| KEY-NEXT-ITEM | CB_DUMMY | RT_CITY_DESC | CB_DUMMY.RT_CITY_DESC | Forces navigation to RT_CITY_DESC item to prompt RTO selection |
| PRE-INSERT | B_CUSTOMER | - | B_CUSTOMER | **INACTIVE** - Null stub; no pre-insert validation required for this display-only block |
| WHEN-NEW-BLOCK-INSTANCE | B_CUSTOMER | - | B_CUSTOMER | Clears block, calls QRY_RECORDS.QUERY_RECORDS to load matching records, loops through cursor to populate block items, fetches party details, and enables Print/Convert buttons |
| WHEN-CHECKBOX-CHANGED | B_CUSTOMER | FORM21_YN | B_CUSTOMER.FORM21_YN | Resets all FORM21_YN values to N for current invoice, resets P_INVNUM parameter, then loops all records to mark only the selected record Y |
| KEY-DOWN | B_CUSTOMER | FORM21_YN | B_CUSTOMER.FORM21_YN | Moves down one record; displays error if already on last record |
| KEY-UP | B_CUSTOMER | FORM21_YN | B_CUSTOMER.FORM21_YN | Moves up one record; displays error if already on first record |
| WHEN-BUTTON-PRESSED | B_CUSTOMER | PB_PRINT | B_CUSTOMER.PB_PRINT | Validates RTO setup (for principal 2), builds invoice/allotment parameter list, sets report server, and calls CALL_REPORT_SR_FORM21 to generate and print Form 21 |
| WHEN-BUTTON-PRESSED | B_CUSTOMER | PB_CONV_WRD | B_CUSTOMER.PB_CONV_WRD | Validates no temporary registration certificate for Word conversion, builds parameter list, sets report server, and calls CALL_REPORT_SR_FORM21_WRD to generate Form 21 in Word format |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | **COMMENTED OUT / INACTIVE** - Previously called GENERAL.ASK_CONFIRM before exiting; confirmation prompt is block-commented; exit now proceeds without confirmation |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | (inherited) Invokes the LOV for the currently focused item; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | (inherited) Inserts a new record into the current block; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | (inherited) Deletes the current record after confirmation; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | (inherited) Cancels pending changes in the current block; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | (inherited) Commits pending changes to the database; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | (inherited) Invokes the standard DPL print action from the toolbar; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | (inherited) Cuts the selected text or record; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | (inherited) Copies the selected text or record; inherited from DPL OG_GROUP PB_BLK block |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | (inherited) Pastes cut/copied content into the current item; inherited from DPL OG_GROUP PB_BLK block |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Form 21 (Sales Certificate) (Rel 2.1.4) | CN_MAIN |

*WN_MAIN and WIN_ERR are inherited from the DPL OG_GROUP object group (see Section 8.10.3). WN_MAIN hosts the main application UI canvas (CN_MAIN) and the toolbar canvas (CN_TOOL). WIN_ERR hosts the error-display canvas (CN_ERR) used by the DPL error-handling infrastructure.*

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |
| CN_ERR | Content | WIN_ERR |

*CN_MAIN and CN_TOOL are inherited from the DPL OG_GROUP object group. CN_ERR is the error canvas inherited from OG_GROUP, displayed in WIN_ERR when runtime errors are raised.*

### 8.9 Editors

*No editors found in st_frm21_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in st_frm21_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in st_frm21_fmb.xml.*

#### 8.10.3 Object Groups

*The form references 2 object groups: **OG_GROUP** (from parent module DPL_MTPL, contributing 41 inherited child objects listed below) and **WEBUTIL** (from the WEBUTIL object library, contributing the WEBUTIL block and associated items). No form-local object groups are defined.*

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*94 DataSourceColumn elements across 2 blocks - formal query column-to-block mapping from st_frm21_fmb.xml.*

#### CB_DUMMY (46 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| INV_NUM | VARCHAR2 |
| AREA_CD | VARCHAR2 |
| COMP_FA | VARCHAR2 |
| INV_TYPE | VARCHAR2 |
| INV_DATE | DATE |
| INV_PARTY_CD | VARCHAR2 |
| INV_STATUS | VARCHAR2 |
| ORDER_PARTY_CD | VARCHAR2 |
| ORDER_DEALER_CD | VARCHAR2 |
| ORDER_NUM | VARCHAR2 |
| ORDER_DATE | DATE |
| REF_ORDER_NUM | VARCHAR2 |
| DEL_DEALER_CD | VARCHAR2 |
| FI_CD | VARCHAR2 |
| ALLOT_NUM | VARCHAR2 |
| SUFFIX_CD | VARCHAR2 |
| ECOLOR_CD | VARCHAR2 |
| ICOLOR_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| ENGINE_NUM | VARCHAR2 |
| CHASSIS_NUM | VARCHAR2 |
| KEY_NUM | VARCHAR2 |
| SELL_PRICE | NUMBER |
| ACCESSORY_PRICE | NUMBER |
| BOOKING_AMT | NUMBER |
| INTEREST_AMT | NUMBER |
| TDS_AMT | NUMBER |
| INV_AMT | NUMBER |
| ROUND_OFF | NUMBER |
| CANCEL_YN | VARCHAR2 |
| FORM_RECD_YN | VARCHAR2 |
| FORM_CD | VARCHAR2 |
| FORM21_YN | VARCHAR2 |
| FORM16A_YN | VARCHAR2 |
| DN_NUM | VARCHAR2 |
| DN_PRINT_YN | VARCHAR2 |
| VOU_TYPE | VARCHAR2 |
| VOU_NUM | NUMBER |
| VOU_DATE | DATE |
| PRINT_DAY7_YN | VARCHAR2 |
| PRINT_DAY30_YN | VARCHAR2 |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| CANCEL_DATE | DATE |

#### B_CUSTOMER (48 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| LOC_CD | VARCHAR2 |
| COMP_FA | VARCHAR2 |
| PARENT_GROUP | VARCHAR2 |
| INV_TYPE | VARCHAR2 |
| INV_NUM | VARCHAR2 |
| INV_DATE | DATE |
| ORDER_NUM | VARCHAR2 |
| ORDER_DATE | DATE |
| ORDER_PARTY_CD | VARCHAR2 |
| ALLOT_NUM | VARCHAR2 |
| INV_PARTY_CD | VARCHAR2 |
| AREA_CD | VARCHAR2 |
| VARIANT_CD | VARCHAR2 |
| ECOLOR_CD | VARCHAR2 |
| ICOLOR_CD | VARCHAR2 |
| VIN | VARCHAR2 |
| ENGINE_NUM | VARCHAR2 |
| CHASSIS_NUM | VARCHAR2 |
| KEY_NUM | VARCHAR2 |
| SELL_PRICE | NUMBER |
| ACCESSORY_PRICE | NUMBER |
| BOOKING_AMT | NUMBER |
| INTEREST_AMT | NUMBER |
| TDS_AMT | NUMBER |
| INV_AMT | NUMBER |
| ROUND_OFF | NUMBER |
| INV_STATUS | VARCHAR2 |
| FORM21_YN | VARCHAR2 |
| DN_NUM | VARCHAR2 |
| DN_PRINT_YN | VARCHAR2 |
| VOU_TYPE | VARCHAR2 |
| VOU_NUM | VARCHAR2 |
| VOU_DATE | DATE |
| PRINT_DAY7_YN | VARCHAR2 |
| PRINT_DAY30_YN | VARCHAR2 |
| CANCEL_DATE | DATE |
| CREATED_BY | VARCHAR2 |
| CREATED_DATE | DATE |
| MODIFIED_BY | VARCHAR2 |
| MODIFIED_DATE | DATE |
| CHARGE_AMT | NUMBER |
| FI_CD | VARCHAR2 |
| BILL_NATURE | VARCHAR2 |
| WAR_SLAB_CD | VARCHAR2 |
| EXT_WARRANTY_YN | VARCHAR2 |
| DISCOUNT | NUMBER |
| BEF_TAX | VARCHAR2 |

**Total DataSourceColumns:** 94 across 2 blocks

## 9. Object Library

*This form references two Object Library files: `DPL_olb.xml` (the DPL library containing visual attributes and property classes) and `webutil_olb.xml` (the WebUtil library). The DPL library holds 15 Visual Attributes and 27 Property Classes used to standardise the appearance and behaviour of form items across the application. The WebUtil library supplies the WebUtil object group and related configuration. The `VA_MAND` visual attribute from the DPL library is applied programmatically at runtime to the RTO City field for sessions where RTO entry is mandatory.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Gray background, black foreground, Arial 8pt - used for check box items | referenced | N/A |
| VA_RB | VisualAttribute | Gray background, black foreground, Arial 8pt - used for radio button items | referenced | N/A |
| VA_ICONIC_BUTN | VisualAttribute | White background, black foreground - used for iconic push button items | referenced | N/A |
| VA_DESC | VisualAttribute | Gray background, blue foreground, Small Fonts 7pt - used for description/display items | referenced | N/A |
| VA_NUM | VisualAttribute | White background, black foreground, Arial 8pt - used for numeric text items | referenced | N/A |
| VA_MAND | VisualAttribute | Cyan background, black foreground, Arial 9pt - mandatory field indicator | referenced | RT_CITY_DESC (applied at runtime for applicable principal types) |
| VA_OPROMPT | VisualAttribute | Prompt type; white background, black prompt foreground, Arial 8pt - optional prompt label style | referenced | N/A |
| VA_MPROMPT | VisualAttribute | Prompt type; white background, red prompt foreground, Arial 8pt - mandatory prompt label style | referenced | N/A |
| VA_TEXT | VisualAttribute | White background, black foreground, Arial 9pt - standard text item | referenced | N/A |
| VA_BUTN | VisualAttribute | Gray background, black foreground, Arial 10pt bold - push button style | referenced | N/A |
| VA_ALERT | VisualAttribute | Gray background, black foreground, MT Extra 11pt - alert dialog style | referenced | N/A |
| VA_TITLE | VisualAttribute | Gray background, blue foreground, Arial 10pt bold - section title style | referenced | N/A |
| VA_TRNI_DT | VisualAttribute | White background, black foreground, Courier bold - transaction date style | referenced | N/A |
| VA_LOV | VisualAttribute | Gray background, dark-blue foreground, Arial 9pt - LOV field style | referenced | N/A |
| VA_DISP | VisualAttribute | Custom background (r25g75b75), black foreground, Arial 8pt bold - display-only item style | referenced | N/A |
| PC_DESC | PropertyClass | Display item - Left justified, 250 wide, max length 110, white background, Arial 9pt, no bevel, blue foreground | referenced | N/A |
| PC_SC_DATE | PropertyClass | Display item - date format, gray background, Arial 8pt bold, mouse-navigate, format mask for date entry (DD-MM-YY or DD/MM/YY) | referenced | N/A |
| PC_TITLE | PropertyClass | Text item - Center justified, gray background, Arial 10pt bold, uppercase, for section titles | referenced | N/A |
| PC_FORMAT | PropertyClass | Text item - Center justified, 60 wide, max length 12, property class for format items | referenced | N/A |
| PC_MR_BLK | PropertyClass | Multi-record block styling property class | referenced | N/A |
| PC_DISP | PropertyClass | Display item - gray background, Arial 9pt, text display style | referenced | N/A |
| PC_LOV | PropertyClass | List of Values field styling - property class for LOV items | referenced | N/A |
| PC_FORM | PropertyClass | Form-level property class | referenced | N/A |
| PC_DISP_DATE | PropertyClass | Display date item styling | referenced | N/A |
| PC_DISP_NUM | PropertyClass | Display numeric item styling | referenced | N/A |
| PC_DATE | PropertyClass | Date entry item - property class for date fields | referenced | N/A |
| PC_DTTIME | PropertyClass | Date-and-time entry item - property class for datetime fields | referenced | N/A |
| PC_CB | PropertyClass | Check box item property class | referenced | N/A |
| PC_ALERT | PropertyClass | Alert dialog item property class | referenced | N/A |
| PC_MDATE | PropertyClass | Mandatory date field property class | referenced | N/A |
| PC_RB | PropertyClass | Radio button item property class | referenced | N/A |
| PC_WIND | PropertyClass | Window property class | referenced | N/A |
| PC_CANV | PropertyClass | Canvas property class | referenced | N/A |
| PC_BUTN | PropertyClass | Push button property class - standard button style | referenced | N/A |
| PC_TEXT | PropertyClass | Text item property class - standard text field | referenced | N/A |
| PC_MTEXT | PropertyClass | Mandatory text item property class | referenced | N/A |
| PC_UTEXT | PropertyClass | Uppercase text item property class | referenced | N/A |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item property class | referenced | N/A |
| PC_NUM | PropertyClass | Numeric text item property class | referenced | N/A |
| PC_MNUM | PropertyClass | Mandatory numeric text item property class | referenced | N/A |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class | referenced | N/A |
| PC_SCROLL | PropertyClass | Scrollable item property class | referenced | N/A |
| WEBUTILCONFIG | ModuleParameter | WebUtil configuration parameter - supplies the WebUtil configuration to the form at runtime | referenced | WEBUTIL block |
| WEBUTIL | ObjectGroup | WebUtil object group - contains all WebUtil bean items and their associated triggers for browser/client utility functions | referenced | WEBUTIL block |
| WEBUTIL_NO_OLE | ObjectGroup | WebUtil object group variant without OLE support | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_RTO | Query | LV_RTO | RTO_CITY_DESC | RTO_CITY_CD | No | Lists RTO (Road Transport Office) city locations available for the current dealer and principal | LV_RTO -> CB_DUMMY.RT_CITY_DESC |

**Total Record Groups:** 1

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DUMMY | VEH_INVOICE | - | Yes |
| B_CUSTOMER | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC_PARAM` | - | CALL_REPORT_SR_FORM21, CALL_REPORT_SR_FORM21_WRD | Dealer location parameters - configuration table storing location-specific settings such as price flag (X_F_PRICE_YN) |
| `RTO_MASTER` | - | CHECK_RTO_CREATED, RG_RTO, Trigger WHEN-BUTTON-PRESSED | RTO master - Road Transport Office city records per dealer and principal used for Form 21 printing |
| `SH_INVOICE` | - | FETCH_PARTY_DET, FORM_REP_PARAM, QRY_RECORDS | Sales invoice - primary vehicle sales invoice header used to query and filter Form 21 records |
| `SH_ORDBOOK` | - | FETCH_PARTY_DET | Sales order book - vehicle order details including financier code and branch used when fetching party information |
| `ST_ALLOT` | - | QRY_RECORDS | Stock allotment - vehicle allotment records queried when report type is Allotment (A) |
| `VEH_INVOICE` | - | CB_DUMMY | Vehicle invoice - base data source referenced by CB_DUMMY block for DataSourceColumn definitions |

**Total Referenced Objects:** 6

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | STOP_WATCH.STOP_TIMER | Records the elapsed form-load time against the current user and stops the performance timer |
| BR-007 | CHECK_RTO_CREATED | Verifies that at least one RTO record has been configured for the dealer before allowing the user to proceed to the RTO City field |
| BR-009 | QRY_RECORDS.QUERY_RECORDS | Builds and executes the database query to retrieve matching allotment or invoice records based on user-specified filter criteria |
| BR-009 | FETCH_PARTY_DET | Fetches the financier code and name for each record in the results list |
| BR-009 | STOP_WATCH.STOP_TIMER | Records the elapsed query time and stops the performance timer after results are loaded |
| BR-013 | SF_GET_FORM21_LOCK | Acquires a print lock on each selected invoice or allotment record to prevent concurrent duplicate prints |
| BR-013 | FORM_REP_PARAM | Builds the report parameter string and marks eligible invoice records as Form 21 printed in the database |
| BR-013 | SET_REPORT_SERVER | Reads the report server name from the file system and stores it for the report submission call |
| BR-013 | CALL_REPORT_SR_FORM21 | Validates print options, retrieves dealer configuration, and submits the Form 21 print job to the report server |
| BR-014 | FORM_REP_PARAM | Builds the report parameter string and marks eligible invoice records as Form 21 printed in the database |
| BR-014 | SET_REPORT_SERVER | Reads the report server name from the file system and stores it for the report submission call |
| BR-014 | CALL_REPORT_SR_FORM21_WRD | Retrieves dealer configuration, sets RTF output format, and submits the Word-format Form 21 report job to the report server |
| BR-015 | GENERAL.CHECK_FORM_FAILURE | Checks for pre-commit and post-commit failure conditions during the save operation |
| BR-018 | GENERAL.DISP_TEXT | Displays intercepted error messages in the standard application message format |
| BR-018 | GENERAL.RAISE_ERROR | Translates raw Oracle or Forms error codes into user-readable messages and surfaces them via DISP_TEXT |
| BR-019 | GENERAL.PROC_TIMER_EXPIRED | Handles the timer-expiry event for any active application timer |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before discarding changes or deleting a record |
| - | GENERAL.PROC_REPORT_CALL | Configures and submits a Form 21 report object for asynchronous batch printing and returns the job handle |
| - | GENERAL.PROC_TIMER | Creates the PRINTER_QUEUE repeating timer used to poll the report server for job completion |
| - | PKG_PARAM_VARIABLES.RUN_REPORT | Submits a named report to the report server via the higher-level pkg_param_variables package; called from the toolbar FT_PRINT trigger |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Routes client-side WebUtil bean events to the appropriate WebUtil function handler |
| - | WEB.SHOW_DOCUMENT | Opens the generated report output in the browser during the report-output delivery path |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| CALL_REPORT_SR_FORM21 | Form ProgramUnit | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT | Validates printing options, retrieves dealer price-display configuration from AM_DEALER_LOC_PARAM, determines the report file (sr_form21 or sr_form21_trc), presents an output-format alert to the user, and submits the Form 21 PDF or direct-print report job to the report server via GENERAL.PROC_REPORT_CALL; subsequently calls GENERAL.PROC_TIMER to initiate job-completion polling |
| CALL_REPORT_SR_FORM21_WRD | Form ProgramUnit | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_CONV_WRD | Retrieves dealer price-display configuration from AM_DEALER_LOC_PARAM, configures the report for RTF (Word) output, and submits the Form 21 Word-format report job to the report server |
| CHECK_RTO_CREATED | Form ProgramUnit | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT (active); PRE-TEXT-ITEM on CB_DUMMY.RT_CITY_DESC (INACTIVE - block-commented, does not execute) | Queries RTO_MASTER to confirm at least one RTO record exists for the current dealer, location, and principal; for applicable principal types only - displays a note via GENERAL.DISP_TEXT and aborts if no records are found |
| FETCH_PARTY_DET | Form ProgramUnit | WHEN-NEW-BLOCK-INSTANCE on B_CUSTOMER | For each record in the results list, queries SH_ORDBOOK, ST_ALLOT or SH_INVOICE, and GM_PARTY to retrieve the financier code, name, and branch associated with the allotment or invoice order; populates the Financier Code and Financier Description display fields |
| FORM_REP_PARAM | Form ProgramUnit | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT; WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_CONV_WRD | Iterates through all records marked for printing, updates SH_INVOICE.FORM21_YN to `Y` for eligible invoice records, commits the update, builds the parameter string of selected record numbers for the report, and returns an error code if a database error occurs; displays errors via GENERAL.DISP_TEXT |
| SET_REPORT_SERVER | Form ProgramUnit | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT; WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_CONV_WRD | Reads the configured report server name from a text file on the server file system (`/reports/DMS/repservernamenew.txt` for server 1; `/reports/DMS/repservername.txt` for server 2) and stores it in the session global for use by the report submission call |
| QRY_RECORDS.QUERY_RECORDS | Form Package Procedure | WHEN-NEW-BLOCK-INSTANCE on B_CUSTOMER | Determines the applicable print-type flag from the user's print-status selection, then opens the appropriate database cursor over SH_INVOICE (for invoiced records), ST_ALLOT, GM_CIN, and SH_ORDBOOK (for allotted records) filtered by the user's criteria; returns a typed cursor to the calling trigger for row-by-row fetching |
| SF_GET_FORM21_LOCK | External Procedure (.prc) | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT | Attempts to acquire a Form 21 print lock for the specified invoice or allotment record for the current dealer context; returns an error message if the record is currently locked by another user session |
| GENERAL.ASK_CONFIRM | Attached Library (DPL) | Trigger: FT_CANCEL in Form; Trigger: FT_DEL in Form; Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog to the user presenting the supplied message and returns a numeric result indicating the user's choice (OK vs Cancel); called before discarding changes or deleting a record |
| GENERAL.CHECK_FORM_FAILURE | Attached Library (DPL) | KEY-COMMIT | Checks whether the last Oracle Forms statement succeeded; if it failed, reads ERROR_TYPE and displays either the Oracle error message (ORA type) or the Forms error text (FRM type) via GENERAL.DISP_TEXT, then raises FORM_TRIGGER_FAILURE to stop execution |
| GENERAL.DISP_TEXT | Attached Library (DPL) | ProgramUnit: CALL_REPORT_SR_FORM21; ProgramUnit: CALL_REPORT_SR_FORM21_WRD; ProgramUnit: CHECK_RTO_CREATED; ProgramUnit: FORM_REP_PARAM; Trigger: FT_PRINT in Form; Trigger: KEY-DOWN in B_CUSTOMER.FORM21_YN; Trigger: KEY-UP in B_CUSTOMER.FORM21_YN; Trigger: ON-ERROR in Form; Trigger: ON-MESSAGE in Form; Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_CONV_WRD; Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_PRINT; Trigger: WHEN-NEW-BLOCK-INSTANCE in B_CUSTOMER; Trigger: WHEN-NEW-FORM-INSTANCE in Form; Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_FRM_DATE; Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TMP_NO; Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TO_DATE | Displays a message dialog to the user using an inherited alert object; if title_string is `ERROR` shows the AL_ERRINFO alert, otherwise shows the AL_NOTE alert; sets the alert title and message at runtime before displaying; used throughout the form for validation errors, informational notes, and RTO/report messages |
| GENERAL.PROC_REPORT_CALL | Attached Library (DPL) | ProgramUnit: CALL_REPORT_SR_FORM21 | Configures a report object for batch-mode file output to the printer spool directory, sets the report server from `:global.rep_server`, submits the report via RUN_REPORT_OBJECT, and returns the report job handle and the output file name; used by CALL_REPORT_SR_FORM21 to submit Form 21 for asynchronous printing |
| GENERAL.PROC_TIMER | Attached Library (DPL) | ProgramUnit: CALL_REPORT_SR_FORM21 | Creates a repeating timer named PRINTER_QUEUE with a 5-second interval; the timer fires WHEN-TIMER-EXPIRED to poll the report server for job completion; called after submitting a report via GENERAL.PROC_REPORT_CALL |
| GENERAL.PROC_TIMER_EXPIRED | Attached Library (DPL) | Trigger: WHEN-TIMER-EXPIRED in Form | Handles expiry of the PRINTER_QUEUE timer; reads the report job handle from `:global.reporthandle` and checks the report object status; if finished, opens the output file in the browser and deletes the timer; if still running, waits; if failed, displays an error and deletes the timer |
| GENERAL.RAISE_ERROR | Attached Library (DPL) | Trigger: ON-ERROR in Form | Accepts a message code, looks up the corresponding error description, and surfaces it to the user via GENERAL.DISP_TEXT with an `ERROR` title; called from the form-level ON-ERROR trigger to provide a standardised error-reporting path that translates raw Oracle or Forms error codes into user-readable messages |
| PKG_PARAM_VARIABLES.RUN_REPORT | Attached Library (DPL) | Trigger: FT_PRINT in Form | Submits a named report to the specified report server using the supplied destination type, destination name, and parameter string; encapsulates the full report-submission handshake within the `pkg_param_variables` package, providing a higher-level alternative to GENERAL.PROC_REPORT_CALL; called from the FT_PRINT form-level trigger to initiate printing directly from the toolbar print action |
| STOP_WATCH.STOP_TIMER | Attached Library (STOP_WATCH) | WHEN-NEW-ITEM-INSTANCE on CB_DUMMY.NB_TYPE; WHEN-NEW-BLOCK-INSTANCE on B_CUSTOMER; FORM_REP_PARAM | Records the elapsed time for a named performance phase against the current user and stops the timer; used for form-load and query-phase performance logging |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Attached Library (webutil.pld) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS; WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS; WEBUTIL.WEBUTIL_C_API_FUNCTIONS; WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS; WEBUTIL.WEBUTIL_FILE_FUNCTIONS; WEBUTIL.WEBUTIL_HOST_FUNCTIONS; WEBUTIL.WEBUTIL_OLE_FUNCTIONS; WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine that receives the name and serialised parameters of a custom client-side event raised by a WebUtil bean item and routes it to the appropriate WebUtil function handler; ensures all client-to-server callbacks are processed through a single consistent entry point |
| WEB.SHOW_DOCUMENT | Attached Library | ProgramUnit: CALL_REPORT_SR_FORM21; ProgramUnit: CALL_REPORT_SR_FORM21_WRD | Opens the generated report output in the browser; called conditionally in the report-output delivery path after the report server returns a completed job (EXTERNAL / NOT IN BUNDLE - called conditionally in the report-output delivery path) |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in the input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

---

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog to the user presenting the supplied message and returns a numeric result indicating the user's choice (e.g. OK vs Cancel). Called from the FT_CANCEL and FT_DEL form-level triggers to prompt the user before discarding changes or deleting a record, and from the WEBUTIL block's DUMMY item button-pressed trigger. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks whether the last Oracle Forms statement succeeded. If it failed, reads ERROR_TYPE and displays either the Oracle error message (ORA type) or the Forms error text (FRM type) via DISP_TEXT, then raises FORM_TRIGGER_FAILURE to stop execution. Called after ENTER and after COMMIT_FORM in the KEY-COMMIT trigger. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: CALL_REPORT_SR_FORM21, ProgramUnit: CALL_REPORT_SR_FORM21_WRD, ProgramUnit: CHECK_RTO_CREATED, ProgramUnit: FORM_REP_PARAM, Trigger: FT_PRINT in Form, Trigger: KEY-DOWN in B_CUSTOMER.FORM21_YN, Trigger: KEY-UP in B_CUSTOMER.FORM21_YN, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_CONV_WRD, Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_PRINT, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_CUSTOMER, Trigger: WHEN-NEW-FORM-INSTANCE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_FRM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TMP_NO, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TO_DATE | Displays a message dialog to the user using an inherited alert object. If title_string is 'ERROR', shows the AL_ERRINFO alert; otherwise shows the AL_NOTE alert. Sets the alert title and message at runtime before displaying. Used throughout the form for validation errors, informational notes, and RTO/report messages. |
| PROC_REPORT_CALL | Procedure | Procedure(REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) | ProgramUnit: CALL_REPORT_SR_FORM21 | Configures a report object for batch-mode file output to the printer spool directory, sets the report server from :global.rep_server, submits the report via RUN_REPORT_OBJECT, and returns the report job handle and the output file name. Used by CALL_REPORT_SR_FORM21 to submit Form 21 for asynchronous printing. |
| PROC_TIMER | Procedure | Procedure() | ProgramUnit: CALL_REPORT_SR_FORM21 | Creates a repeating timer named PRINTER_QUEUE with a 5-second interval. The timer fires WHEN-TIMER-EXPIRED to poll the report server for job completion. Called after submitting a report via PROC_REPORT_CALL. |
| PROC_TIMER_EXPIRED | Procedure | Procedure() | Trigger: WHEN-TIMER-EXPIRED in Form | Handles expiry of the PRINTER_QUEUE timer. Reads the report job handle from :global.reporthandle and checks the report object status. If finished, opens the output file in the browser and deletes the timer. If still running, waits. If failed, displays an error and deletes the timer. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Accepts a message code, looks up the corresponding error description, and surfaces it to the user via DISP_TEXT with an 'ERROR' title. Called from the form-level ON-ERROR trigger to provide a standardised error-reporting path that translates raw Oracle or Forms error codes into user-readable messages. |

**Total Active Routines:** 7 of 24 in DPL.pld source

---

### DPL.pld (`pkg_param_variables`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| run_report | Procedure | Procedure(p_report_name in varchar2, p_dest_type in varchar2, p_dest_name in varchar, P_parameter in varchar2, p_report_server in varchar2) | Trigger: FT_PRINT in Form | Submits a named report to the specified report server using the supplied destination type, destination name, and parameter string. Encapsulates the full report-submission handshake within the `pkg_param_variables` package, providing a higher-level alternative to the lower-level PROC_REPORT_CALL routine. Called from the FT_PRINT form-level trigger to initiate printing directly from the toolbar print action. |

**Total Active Routines:** 1 of 3 in DPL.pld source

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine within the WEBUTIL_CORE package that receives the name and serialised parameters of a custom client-side event raised by a WebUtil bean item and routes it to the appropriate WebUtil function handler. Each WEBUTIL block item (WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS) registers a WHEN-CUSTOM-ITEM-EVENT trigger that delegates immediately to this procedure, ensuring all client-to-server callbacks are processed through a single, consistent entry point. |

**Total Active Routines:** 1 of 39 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Form21 Invoice Query Service | SH_INVOICE, SH_ORDBOOK | dealer_code, location_code, parent_group, company_code, invoice_type, print_status (Y/N/A), from_date (optional), to_date (optional) | List of invoices: invoice number, invoice date, customer code, Form21 print flag | Retrieves non-cancelled invoices filtered by dealer context, invoice type, print status, and optional date range for display in the Form 21 selection screen | `GET /api/form21/invoices` |
| MS-002 | Form21 Allotment Query Service | ST_ALLOT, SH_ORDBOOK, GM_CIN | dealer_code, location_code, parent_group, company_code, principal_code, from_date (optional), to_date (optional) | List of allotments: allotment number, allotment date, customer name, Form21 status | Retrieves non-cancelled allotments not yet invoiced for the dealer and principal, filtered by optional date range, for display in the Form 21 selection screen | `GET /api/form21/allotments` |
| MS-003 | Form21 Financier Details Service | SH_ORDBOOK, ST_ALLOT, SH_INVOICE, GM_PARTY | dealer_code, location_code, parent_group, company_code, record_type (I/A), record_number | Financier code, financier name, branch name | Retrieves the financier linked to an invoice or allotment order for display alongside each record in the Form 21 results list | `GET /api/form21/financier/{record_type}/{record_number}` |
| MS-004 | RTO Master Verification Service | RTO_MASTER | dealer_code, location_code, parent_group, principal_code | RTO record count (exists: true/false), list of RTO city options (city code, city description) | Checks that at least one RTO record exists for the dealer and principal; also provides the RTO city lookup data for the selection screen | `GET /api/form21/rto-cities` |
| MS-005 | Form21 Print Lock Service | SF_GET_FORM21_LOCK | parent_group, dealer_code, location_code, company_code, record_type, record_number | Lock acquired (true/false), error message if failed | Attempts to acquire an exclusive Form 21 print lock on a specific invoice or allotment record to prevent concurrent duplicate prints | `POST /api/form21/print-lock` |
| MS-006 | Form21 Print Flag Update Service | SH_INVOICE | parent_group, dealer_code, location_code, invoice_type, invoice_number | Updated count, error code | Marks an eligible invoice record as having had Form 21 printed by updating its print flag; validates against duplicates | `PATCH /api/form21/invoices/{invoice_number}/print-flag` |
| MS-007 | Form21 Dealer Configuration Service | AM_DEALER_LOC_PARAM | parent_group, dealer_code, location_code | Price display flag (X_F_PRICE_YN) | Retrieves the dealer's price-display configuration flag for inclusion in Form 21 report parameters | `GET /api/form21/dealer-config` |
| MS-008 | Form21 Report Submission Service | CALL_REPORT_SR_FORM21 / CALL_REPORT_SR_FORM21_WRD | principal, parent_group, dealer_code, location_code, company_code, record_type (I/A), record_number_list, print_line_flag, temp_reg_number, rto_city, output_format (PDF/RTF) | Report job reference / output document URL | Submits a Form 21 print or Word-conversion report job to the report server for the specified set of selected invoice or allotment records | `POST /api/form21/report-jobs` |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form 21 Screen Initialization | Form open (PRE-FORM trigger fires, followed by WHEN-NEW-ITEM-INSTANCE on first field) | 1. Check if performance logging is active. 2. If active, start a performance timer. 3. Form loads and presents selection criteria to the user. 4. If performance logging is active, stop the load-phase timer and record elapsed time. | Is application performance logging active? | Form 21 selection criteria screen ready for user input |
| WF-002 | Selection Criteria Configuration | User interacts with record type, invoice type, print status, date range, and RTO city filters | 1. User selects record type. 2. System enables or disables Invoice Type and Print Status filters based on record type. 3. User optionally enters date range (From Date and To Date), each validated on exit. 4. For applicable principal types, user navigates to the RTO City field - system pre-validates that RTO master data exists. 5. User selects RTO city from the lookup if required. | Is record type Allotted or Invoiced? Are From/To Dates entered and valid? Is the session a principal type requiring RTO? Does an RTO master record exist? | All required criteria entered and validated; Query button ready to be pressed |
| WF-003 | Query and Record Load | User presses the Query button | 1. System navigates to results area. 2. QRY_RECORDS.QUERY_RECORDS executed to retrieve matching records. 3. Up to 500 records fetched and loaded row by row. 4. If > 500 records, error shown and flow aborted. 5. If no records found, error shown and flow aborted. 6. FETCH_PARTY_DET called to populate financier details for all loaded rows. 7. Selection controls and action buttons enabled; Select/Deselect All toggled based on print-status preference. 8. If performance logging is active, query-phase timer stopped and committed. | Did more than 500 records match? Did at least one record match? Was the print-status filter set to "Printed"? Is performance logging active? | Records displayed in results list; Print and Convert to Word buttons enabled |
| WF-004 | Record Selection for Printing | User selects or deselects records after query results are loaded | 1. User may click Select All / Deselect All to bulk-mark or bulk-clear all records. 2. User may individually check a record's print flag - all others are automatically deselected. 3. User may navigate the list using up/down keys; boundary messages shown at first/last record. | Is the toggle labelled "Select All" or "Deselect All"? Is the current row the first or last record? | One or more records marked for printing |
| WF-005 | Print Form 21 | User clicks the Print button | 1. For principal types requiring RTO: check RTO master exists; check RTO city is selected. If either check fails, abort. 2. Iterate records: for each record marked for printing, call SF_GET_FORM21_LOCK; if lock fails, deselect record and accumulate error. 3. After loop: if any lock failures on invoice records, display error with locked invoice numbers. 4. If at least one record locked successfully: call FORM_REP_PARAM to build parameter string and update invoice print flags. If error, abort. 5. Call SET_REPORT_SERVER for appropriate server. 6. Call CALL_REPORT_SR_FORM21 to submit the print job. 7. Clear the form. | Is session a principal type requiring RTO? Does RTO master exist? Is RTO city selected? Did any lock acquisitions fail? Are lock failures for invoice type? Did FORM_REP_PARAM succeed? Was temporary registration selected for allotments? | Form cleared; Form 21 print job submitted to report server |
| WF-006 | Convert Form 21 to Word | User clicks the Convert to Word button | 1. Check if temporary-registration mode is selected - if so, show error, clear form, abort. 2. Call FORM_REP_PARAM to build parameter string and update invoice print flags. If error, abort. 3. Call SET_REPORT_SERVER for appropriate server. 4. Call CALL_REPORT_SR_FORM21_WRD to submit the Word-format report job. 5. Clear the form. | Is temporary-registration-certificate mode active? Did FORM_REP_PARAM succeed? | Form cleared; Form 21 Word-format report job submitted |
| WF-007 | Form Clear and Reset | User presses the clear-form key or form is cleared after print/convert submission | 1. Clear all data from the form without saving. 2. Re-enable Invoice Type and Print Status filter controls. 3. Disable Select/Deselect All (label reset to "Deselect All"); disable Print and Convert to Word buttons. 4. For applicable principal types: apply mandatory visual attribute to RTO City field. | Is session a principal type requiring RTO? | Form returned to initial selection state; ready for new query |
| WF-008 | Form Save and Commit | User initiates a save action | 1. Run field-level validation pass. 2. Check for pre-commit failure; abort if detected. 3. Commit data to database. 4. Check for post-commit failure; abort if detected. 5. Clear the form. | Did pre-commit validation pass? Did database commit succeed? | Data committed; form cleared |
| WF-009 | Form Exit | User presses the exit key | 1. Close the form immediately without saving or validating any pending changes. | None | Form 21 screen closed; all unsaved data discarded |
| WF-010 | Timer-Driven Background Processing | WHEN-TIMER-EXPIRED event fires | 1. Call GENERAL.PROC_TIMER_EXPIRED to handle the timer event. | None | Timer-driven action executed by the shared timer routine |

**Total Workflows Identified: 10**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

*No routines from ``webutil.pld`` are referenced in ``st_frm21_fmb.xml``.*


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When a form operation fails, then execution is stopped and the Oracle or Forms error message is displayed to the user. |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: CALL_REPORT_SR_FORM21, ProgramUnit: CALL_REPORT_SR_FORM21_WRD, ProgramUnit: CHECK_RTO_CREATED, ProgramUnit: FORM_REP_PARAM, Trigger: KEY-DOWN in B_CUSTOMER.FORM21_YN, Trigger: KEY-UP in B_CUSTOMER.FORM21_YN, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_CONV_WRD, Trigger: WHEN-BUTTON-PRESSED in B_CUSTOMER.PB_PRINT, Trigger: WHEN-NEW-BLOCK-INSTANCE in B_CUSTOMER, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_FRM_DATE, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TMP_NO, Trigger: WHEN-VALIDATE-ITEM in CB_DUMMY.NB_TO_DATE | /api/v1/pld/disp_text | When a message or error needs to be shown, then a dialog alert is displayed to the user with the supplied text and title. |
| PLD-003 | PROC_REPORT_CALL | Business Logic | ProgramUnit: CALL_REPORT_SR_FORM21 | /api/v1/pld/proc_report_call | When a Form 21 report is submitted for printing, then the report is configured for batch file output and submitted to the report server, returning the job handle and file name. |
| PLD-004 | PROC_TIMER | Business Logic | ProgramUnit: CALL_REPORT_SR_FORM21 | /api/v1/pld/proc_timer | When a report is submitted asynchronously, then a repeating 5-second timer is created to poll for report completion. |
| PLD-005 | PROC_TIMER_EXPIRED | Business Logic | Trigger: WHEN-TIMER-EXPIRED in Form | /api/v1/pld/proc_timer_expired | When the printer queue timer fires, then the report job status is checked and the completed output is opened in the browser or an error is displayed. |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``st_frm21_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``st_frm21_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| SH_INVOICE - Form 21 Query | Table SELECT | Retrieves non-cancelled invoiced records matching the dealer, location, invoice type, print status, and optional date range for display in the results list | Outbound read: session context -> SH_INVOICE | Caught by WHEN OTHERS in WHEN-NEW-BLOCK-INSTANCE; error message displayed with SQLERRM concatenated with *"Execution failed for fetching the alloted/invoice records "* |
| SH_INVOICE - Form 21 Print Flag Update | Table UPDATE | Marks selected invoice records as Form 21 printed by setting the FORM21_YN flag to `Y` | Outbound write: form selection -> SH_INVOICE.FORM21_YN | DUP_VAL_ON_INDEX caught in FORM_REP_PARAM - *"Trying to create a duplicate record for invoice"* displayed; WHEN OTHERS caught - *"Execution failed for updation of invoice "* with SQLERRM |
| ST_ALLOT - Allotment Query | Table SELECT | Retrieves non-cancelled allotments not yet invoiced for the dealer and principal, with optional date range filter | Outbound read: session context -> ST_ALLOT | Caught by WHEN OTHERS in QRY_RECORDS.QUERY_RECORDS; error propagates to WHEN-NEW-BLOCK-INSTANCE handler |
| SH_ORDBOOK - Order Book Query | Table SELECT | Joins to allotment and invoice queries to resolve customer and financier information | Outbound read: linked via ORDER_NUM from ST_ALLOT / SH_INVOICE | Caught by WHEN OTHERS handlers in FETCH_PARTY_DET and QRY_RECORDS; financier fields left blank on individual record failure |
| GM_CIN - Customer Identity Query | Table SELECT | Retrieves the customer full name for allotment records displayed in the results list | Outbound read: linked via CUST_CD from SH_ORDBOOK | Caught by WHEN OTHERS in QRY_RECORDS.QUERY_RECORDS |
| GM_PARTY - Party (Financier) Query | Table SELECT | Retrieves the financier party name and branch for each record displayed in the results list | Outbound read: linked via FI_CD from SH_ORDBOOK / SH_INVOICE | Caught by WHEN OTHERS in FETCH_PARTY_DET; financier fields set to NULL on failure |
| RTO_MASTER - RTO Existence Check | Table SELECT COUNT | Verifies at least one RTO record is configured for the dealer before allowing RTO City field entry and before printing | Outbound read: session context -> RTO_MASTER | No explicit exception handler - failure propagates as trigger failure |
| RTO_MASTER - RTO City Lookup (RG_RTO) | Table SELECT via Record Group | Populates the RTO City Name lookup list for the current dealer, location, and principal | Outbound read: session context -> RTO_MASTER filtered for principal_map_cd | Standard LOV record group query failure handling |
| AM_DEALER_LOC_PARAM - Dealer Price Config | Table SELECT | Retrieves the dealer location price-display flag (X_F_PRICE_YN) for inclusion in Form 21 report parameters | Outbound read: session context -> AM_DEALER_LOC_PARAM | WHEN OTHERS in CALL_REPORT_SR_FORM21 / CALL_REPORT_SR_FORM21_WRD - SQLERRM displayed via GENERAL.DISP_TEXT; trigger aborted |
| SF_GET_FORM21_LOCK - Print Lock | External Stored Procedure | Acquires an exclusive print lock on a specific invoice or allotment record to prevent concurrent duplicate Form 21 prints | Outbound call: form selection -> SF_GET_FORM21_LOCK with dealer context and record number; inbound: error code and message | Lock failure returned via output parameter; affected record deselected; error accumulated for reporting |

### 20.2 External System Integrations

This form does not integrate with any external systems. All data access is via the local Oracle database. The Oracle Reports server interaction (report job submission via `RUN_REPORT_OBJECT` / `WEB.SHOW_DOCUMENT`) is a platform-level Forms-to-Reports integration, documented under Section 20.3 Report Integrations.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Report Server (Oracle Reports) | Oracle Forms report submission | Submits Form 21 PDF or Word-format print jobs to the Oracle Reports server for generation and delivery | Oracle Forms RUN_REPORT_OBJECT / WEB.SHOW_DOCUMENT | Report server name read at runtime from `/reports/DMS/repservernamenew.txt` (server 1) or `/reports/DMS/repservername.txt` (server 2) | Report parameters: principal, dealer, location, company, record type, selected record numbers, price flag, print-line flag, temp reg number, RTO city; output: PDF or RTF document | ALERT_BUTTON1 = print to printer / direct output; ALERT_BUTTON2 = PDF output; ALERT_BUTTON3 = cancel (inactive - message body only) |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| sr_form21 | Oracle Reports server (name read from `/reports/DMS/repservernamenew.txt` for Invoice mode; `/reports/DMS/repservername.txt` for Allotment mode) | P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_ALLOT_INV, P_FLAG (price flag), P_YN (print-line flag), P_RTO_CITY, P_AND (record number filter clause), P_TMP (temp reg number) - INFERRED from CALL_REPORT_SR_FORM21 parameter composition | PDF or direct printer output (user selects via alert) | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT - via CALL_REPORT_SR_FORM21 [SP-001] |
| sr_form21_trc | Oracle Reports server (as above) | Same parameters as sr_form21 | PDF or direct printer output | WHEN-BUTTON-PRESSED on B_CUSTOMER.PB_PRINT - via CALL_REPORT_SR_FORM21 [SP-001] when Print Temporary Registration is checked (Invoice mode only) |

---

### 20.3.1 Parameters Passed to the Report

Values this form sends when running an Oracle Report. When the selected format is Excel, the form may take an Excel export path instead of building the full report parameter string; lexical SQL fragments (type L/C via lv_default_value) can still apply. The rows below are evidenced submit parameters for this form.

| # | What the user selects on screen | Parameter passed to the report | What is passed |
| --- | --- | --- | --- |
| 1 | Parent | P_PARENT | Passes the form value used for P_PARENT (p_parent). |

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the ST_FRM21 form.

### 21.1 Catalogue Index

77 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--CALL_REPORT_SR_FORM21) | CALL_REPORT_SR_FORM21 |
| [SP-002](#SP-002--CALL_REPORT_SR_FORM21_WRD) | CALL_REPORT_SR_FORM21_WRD |
| [SP-003](#SP-003--CHECK_RTO_CREATED) | CHECK_RTO_CREATED |
| [SP-004](#SP-004--FETCH_PARTY_DET) | FETCH_PARTY_DET |
| [SP-005](#SP-005--FORM_REP_PARAM) | FORM_REP_PARAM |
| [SP-006](#SP-006--SET_REPORT_SERVER) | SET_REPORT_SERVER |
| [SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-012](#SP-012--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-013](#SP-013--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-014](#SP-014--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-015](#SP-015--GENERAL.PROC_REPORT_CALL) | GENERAL.PROC_REPORT_CALL |
| [SP-016](#SP-016--GENERAL.PROC_TIMER) | GENERAL.PROC_TIMER |
| [SP-017](#SP-017--GENERAL.PROC_TIMER_EXPIRED) | GENERAL.PROC_TIMER_EXPIRED |
| [SP-018](#SP-018--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-019](#SP-019--QRY_RECORDS.QUERY_RECORDS) | QRY_RECORDS.QUERY_RECORDS |
| [SP-020](#SP-020--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-021](#SP-021--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-023](#SP-023--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-024](#SP-024--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-026](#SP-026--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-027](#SP-027--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-028](#SP-028--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-029](#SP-029--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-030](#SP-030--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-034](#SP-034--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-035](#SP-035--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-037](#SP-037--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-038](#SP-038--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-039](#SP-039--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-040](#SP-040--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-041](#SP-041--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-042](#SP-042--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-043](#SP-043--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-044](#SP-044--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-045](#SP-045--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-046](#SP-046--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-047](#SP-047--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-048](#SP-048--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-049](#SP-049--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-050](#SP-050--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-051](#SP-051--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-052](#SP-052--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-053](#SP-053--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-054](#SP-054--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-055](#SP-055--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-056](#SP-056--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-057](#SP-057--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-058](#SP-058--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-059](#SP-059--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-060](#SP-060--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-061](#SP-061--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-062](#SP-062--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-063](#SP-063--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-064](#SP-064--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-065](#SP-065--ADD_ERROR) | ADD_ERROR |
| [SP-066](#SP-066--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-067](#SP-067--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-068](#SP-068--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-069](#SP-069--DEBUGLOG) | DEBUGLOG |
| [SP-070](#SP-070--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-071](#SP-071--READ_REGISTRY) | READ_REGISTRY |
| [SP-072](#SP-072--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-073](#SP-073--RUN_REPORT) | RUN_REPORT |
| [SP-074](#SP-074--SETDEBUG) | SETDEBUG |
| [SP-075](#SP-075--SF_GET_FORM21_LOCK) | SF_GET_FORM21_LOCK |
| [SP-076](#SP-076--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-077](#SP-077--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - CALL_REPORT_SR_FORM21

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Generates and delivers the SR Form 21 report (standard or Temporary Registration Certificate variant) for invoice details from the INVOICE DETAILS screen. The procedure resolves the correct report template, retrieves a dealer-location price flag from AM_DEALER_LOC_PARAM, prompts the user to choose a delivery mode (PDF view or character-mode print), assembles all required report parameters, and dispatches the report via the Oracle Reports server.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | varchar2 | IN |
| p_parent | varchar2 | IN |
| p_dealer | varchar2 | IN |
| p_loc | varchar2 | IN |
| p_comp_fa | varchar2 | IN |
| p_allot_inv | varchar2 | IN |
| p_and | varchar2 | IN |
| p_line | varchar2 | IN |
| p_tmp_no | varchar2 | IN |
| p_rto_city | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- GENERAL.PROC_REPORT_CALL ([SP-015](#SP-015--GENERAL.PROC_REPORT_CALL)) - matched by member name (package unresolved)
- GENERAL.PROC_TIMER ([SP-016](#SP-016--GENERAL.PROC_TIMER)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Capture session-level globals: report server name (`:global.rep_server`), registration-check flag (`CB_DUMMY.NB_REG_CHECK`), and customer-details flag (`CB_DUMMY.NB_CUST_DET`).
- Step 2 - Validate alert-button pre-condition: if the report type is 'A' (alert) AND the temporary-registration flag (`CB_DUMMY.CB_TEMP_REP`) is 'Y', display an error message via `GENERAL.DISP_TEXT` stating 'No Temporary Registration Certificate for alloted numbers', clear the form, and raise `FORM_TRIGGER_FAILURE` to abort processing.
- Step 3 - Locate the report object by finding 'REPORT_CALL' using `Find_Report_Object`.
- Step 4 - Determine the report template name: if `CB_DUMMY.CB_TEMP_REP` ≠ 'Y', use `sr_form21`; otherwise use `sr_form21_trc`.
- Step 5 - Display the delivery-mode alert 'AL_REPORT' to the user and capture the selected button response.
- Step 6 - Query AM_DEALER_LOC_PARAM for the `X_F_PRICE_YN` column using the current session's `PARENT_GROUP`, `DEALER`, and `LOC_CD` globals. Store the result in `LV_FLAG` (defaulting to 'N'). If the query fails, display the SQL error via `GENERAL.DISP_TEXT` and raise `FORM_TRIGGER_FAILURE`.
- Step 7 - Branch on the user's alert selection:
  - **Alert Button 1 (PDF view):** Set report output format to PDF. Build the `Report_Other` parameter string using all input parameters plus `LV_FLAG`, `LV_REG_CHECK`, `LV_cust_det`, and - only when `CB_DUMMY.CB_TEMP_REP` = 'Y' - `P_TMP_NO`. Set the report server and filename, run the report object, and open the generated PDF in a new browser window via `web.show_document`.
  - **Alert Button 2 (character-mode print):** Set report output format to 'wided' and destination type to PRINTER in character mode. Build the `Report_Other` parameter string similarly to Button 1 (including `P_TMP_NO` only for the TRC variant, and omitting owner/ship-to/bill-to flags). Set the report server, then delegate report execution and print queuing to `GENERAL.PROC_REPORT_CALL`, storing the returned report handle and print output path in `:global.reporthandle` and `:global.printoutput` respectively. Invoke `GENERAL.PROC_TIMER` to initiate the print-queue timer.
  - **Alert Button 3 (cancel):** Clear any pending message and take no further action.
- Step 8 - Procedure exits; no explicit return value is produced.

---
**Decision Points**

DP-001

Condition:
`CB_DUMMY.NB_TYPE = 'A'` AND `CB_DUMMY.CB_TEMP_REP = 'Y'`

TRUE:
Display error 'No Temporary Registration Certificate for alloted numbers' via `GENERAL.DISP_TEXT`, execute `DO_KEY('CLEAR_FORM')`, and raise `FORM_TRIGGER_FAILURE` - aborting the procedure.

FALSE:
Continue to locate the report object and determine the report template name.

---

DP-002

Condition:
`CB_DUMMY.CB_TEMP_REP != 'Y'`

TRUE:
Assign report filename `sr_form21` (standard Form 21 report).

FALSE:
Assign report filename `sr_form21_trc` (Temporary Registration Certificate variant).

---

DP-003

Condition:
Query on AM_DEALER_LOC_PARAM raises an exception (`WHEN OTHERS`).

TRUE:
Display the SQL error message via `GENERAL.DISP_TEXT` and raise `FORM_TRIGGER_FAILURE`.

FALSE:
`LV_FLAG` is populated with the retrieved `X_F_PRICE_YN` value (or 'N' if NULL); processing continues.

---

DP-004

Condition:
User selects Alert Button 1 (PDF view) from the 'AL_REPORT' alert.

TRUE:
Build PDF-mode report parameters, run the report object, and display the output in a new browser window via `web.show_document`.

FALSE:
Evaluate DP-005.

---

DP-005

Condition:
User selects Alert Button 2 (character-mode print) from the 'AL_REPORT' alert.

TRUE:
Build character-mode/printer report parameters, invoke `GENERAL.PROC_REPORT_CALL` to execute and queue the print job, store handles in globals, and start the timer via `GENERAL.PROC_TIMER`.

FALSE:
User selected Alert Button 3 (cancel); clear any pending message and exit without generating a report.

---

DP-006

Condition:
Within the PDF branch (Alert Button 1): `CB_DUMMY.CB_TEMP_REP != 'Y'`.

TRUE:
Build parameter string without `P_TMP_NO`; include `P_OWNER`, `P_DLR`, `P_SHIP_TO`, and `P_BILL_TO`.

FALSE:
Build parameter string with `P_TMP_NO` appended; include `P_OWNER`, `P_DLR`, `P_SHIP_TO`, and `P_BILL_TO`.

---

DP-007

Condition:
Within the character-print branch (Alert Button 2): `CB_DUMMY.CB_TEMP_REP != 'Y'`.

TRUE:
Build character-mode parameter string without `P_TMP_NO`.

FALSE:
Build character-mode parameter string with `P_TMP_NO` appended.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
**Business Rules**

- BR-001 - A Temporary Registration Certificate (TRC) report cannot be generated when the report type is 'A' (alert); the operation is blocked and the form is cleared.
- BR-002 - The report template used is determined by the temporary-registration flag: `CB_DUMMY.CB_TEMP_REP = 'Y'` routes to the TRC template (`sr_form21_trc`); all other cases use the standard template (`sr_form21`).
- BR-003 - The dealer-location price flag (`X_F_PRICE_YN`) must be successfully retrieved from AM_DEALER_LOC_PARAM using the current session's parent group, dealer code, and location code before any report can be generated; failure to retrieve this value aborts the procedure.
- BR-004 - `X_F_PRICE_YN` defaults to 'N' when the column value is NULL, ensuring the report parameter `P_FLAG` always receives a defined value.
- BR-005 - The `P_TMP_NO` parameter is included in the report parameter string only when generating the TRC variant (`CB_DUMMY.CB_TEMP_REP = 'Y'`); it is omitted for the standard Form 21 report.
- BR-006 - PDF delivery (Alert Button 1) renders the report in BITMAP mode and opens it in a new browser window; no print queue is involved.
- BR-007 - Character-mode print delivery (Alert Button 2) routes the report to a physical printer via `GENERAL.PROC_REPORT_CALL`; the resulting report handle and print output path are stored in session globals (`:global.reporthandle`, `:global.printoutput`) and a print-queue timer is started via `GENERAL.PROC_TIMER`.
- BR-008 - Selecting Alert Button 3 cancels report generation entirely; no report object is run and no globals are updated.
- BR-009 - Principal and dealer codes are cast to numeric (`to_number`) when constructing the report parameter string, enforcing that these identifiers are passed as numbers to the report engine regardless of their VARCHAR2 input type.

---
**Implementation Logic**

```plsql
PROCEDURE CALL_REPORT_SR_FORM21  (p_principal varchar2,p_parent varchar2,p_dealer varchar2,
                                  p_loc varchar2, p_comp_fa varchar2, p_allot_inv varchar2,p_and varchar2,
                                  p_line varchar2,p_tmp_no varchar2,p_rto_city varchar2)IS
                                  
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       VARCHAR2(2000);
	lv_print        VARCHAR2(2000);
	lv_flag         VARCHAR2(3):= 'N';
	LV_REG_CHECK    VARCHAR2(5) := :CB_DUMMY.NB_REG_CHECK;
	LV_cust_det    VARCHAR2(5)  := :CB_DUMMY.NB_CUST_DET;
	
Begin
	
	--Checking The Alert Button
	If (:CB_DUMMY.NB_TYPE = 'A' AND :CB_DUMMY.CB_TEMP_REP = 'Y') Then
			GENERAL.DISP_TEXT ('No Temporary Registration Certificate for alloted numbers ' , 'Error');
			DO_KEY('CLEAR_FORM');
 	   	RAISE FORM_TRIGGER_FAILURE;
	End If;
	repid := Find_Report_Object('REPORT_CALL');
	If :CB_DUMMY.CB_TEMP_REP != 'Y' Then
		lv_report_name := 'sr_form21';
	Else
		lv_report_name := 'sr_form21_trc';
	End If;
	l_AlertId := Find_Alert('AL_REPORT');
	lv_alert := Show_Alert(l_AlertId);
	
 BEGIN	 
	 SELECT NVL(X_F_PRICE_YN,'N')
	 INTO LV_FLAG
	 FROM AM_DEALER_LOC_PARAM
	 WHERE  PARENT_GROUP = :GLOBAL.PARENT_GROUP
	 AND DEALER_MAP_CD = :GLOBAL.DEALER
	 AND   LOC_CD = :GLOBAL.LOC_CD; 
	 
 EXCEPTION
 	 WHEN OTHERS THEN
 	   	 
 	   GENERAL.DISP_TEXT (SQLERRM , 'Error');
 	   RAISE FORM_TRIGGER_FAILURE;
 END;	           
	
	If lv_alert = Alert_Button1 Then
                Clear_Message;

		/*Set_Report_Object_Property(repid,Report_Desformat,'PDF');
	 Set_Report_Object_Property(repid,Report_Other,'P_PARENT='||p_parent||
                                                 ' P_PRINCIPAL='||to_number(p_principal)||
                                                 ' P_COMP_FA='||p_comp_fa||
                                                 ' P_DEALER='||to_number(p_dealer)||
                                                 ' P_LOC='||p_loc||
                                                 ' P_ALLOT_INV='||p_allot_inv||
                                                 ' P_AND='||''''||p_and||''''||
                                                 ' REPORT_DESTYPE =FILE'||
                                                 ' MODE=BITMAP ');

		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
    lv_rep := RUN_REPORT_OBJECT(repid);
    web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');*/
    Set_Report_Object_Property(repid,Report_Desformat,'PDF');
    --Checking Report Type ('Temp Reg or Not)
    If :CB_DUMMY.CB_TEMP_REP != 'Y' Then
		 	Set_Report_Object_Property(repid,Report_Other,'P_PARENT='||p_parent||
	                                                 ' P_PRINCIPAL='||to_number(p_principal)||
	                                                 ' P_COMP_FA='||p_comp_fa||
	                                                 ' P_DEALER='||to_number(p_dealer)||
	                                                 ' P_LOC='||p_loc||
	                                                 ' P_ALLOT_INV='||p_allot_inv||
	                                                 ' P_FLAG='||''''||LV_FLAG||''''||
	                                                 ' P_YN='||''''||p_line||''''||
	                                                 ' P_RTO_CITY='||''''||p_rto_city||''''||
	                                                 ' P_AND='||''''||p_and||''''||
	                                                 ' P_OWNER='||''''||LV_REG_CHECK||''''||
	                                                 ' P_DLR='||''''||LV_REG_CHECK||''''||
	                                                 ' P_SHIP_TO='||''''||LV_cust_det||''''||
	                                                 ' P_BILL_TO='||''''||LV_cust_det||''''||	                                                 
	                                                 ' MODE=BITMAP BLANKPAGES=NO');  -- LV_REG_CHECK
    Else
    	Set_Report_Object_Property(repid,Report_Other,'P_PARENT='||p_parent||
	                                                 ' P_PRINCIPAL='||to_number(p_principal)||
	                                                 ' P_COMP_FA='||p_comp_fa||
	                                                 ' P_DEALER='||to_number(p_dealer)||
	                                                 ' P_LOC='||p_loc||
	                                                 ' P_ALLOT_INV='||p_allot_inv||
	                                                 ' P_FLAG='||''''||LV_FLAG||''''||
	                                                 ' P_YN='||''''||p_line||''''||
	                                                 ' P_RTO_CITY='||''''||p_rto_city||''''||
	                                                 ' P_TMP_NO='||''''||P_TMP_NO||''''||
	                                                 ' P_AND='||''''||p_and||''''||
	                                                 ' P_OWNER='||''''||LV_REG_CHECK||''''||
	                                                 ' P_DLR='||''''||LV_REG_CHECK||''''||	 
	                                                 ' P_SHIP_TO='||''''||LV_cust_det||''''||
	                                                 ' P_BILL_TO='||''''||LV_cust_det||''''||	                                                                                                 
	                                                 ' MODE=BITMAP BLANKPAGES=NO');
		End If;
		Set_Report_Object_Property(repid,Report_Server,lv_server);
		Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
		lv_rep := RUN_REPORT_OBJECT(repid);
		web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank'); 
	Elsif lv_alert = Alert_Button2 Then
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_FILENAME,lv_report_name);
		SET_REPORT_OBJECT_PROPERTY(repid,REPORT_DESFORMAT,'wided');
	  /* code for character begin */
	  If :CB_DUMMY.CB_TEMP_REP != 'Y' Then
	   	Set_Report_Object_Property(repid,Report_Other,'P_PARENT='||p_parent||
	                                                  ' P_PRINCIPAL='||to_number(p_principal)||
	                                                  ' P_COMP_FA='||p_comp_fa||
	                                                  ' P_DEALER='||to_number(p_dealer)||
	                                                  ' P_LOC='||p_loc||
	                                                  ' P_ALLOT_INV='||p_allot_inv||
	                                                  ' P_FLAG='||''''||LV_FLAG||''''||
	                                                  ' P_YN='||''''||p_line||''''||
	                                                  ' P_RTO_CITY='||''''||p_rto_city||''''||
	                                                  ' P_AND='||''''||p_and||''''||
	                                                  ' REPORT_DESTYPE =PRINTER'||
	                                                  ' MODE=CHARACTER BLANKPAGES=NO');
	  Else
	  	Set_Report_Object_Property(repid,Report_Other,'P_PARENT='||p_parent||
	                                                  ' P_PRINCIPAL='||to_number(p_principal)||
	                                                  ' P_COMP_FA='||p_comp_fa||
	                                                  ' P_DEALER='||to_number(p_dealer)||
	                                                  ' P_LOC='||p_loc||
	                                                  ' P_ALLOT_INV='||p_allot_inv||
	                                                  ' P_FLAG='||''''||LV_FLAG||''''||
	                                                  ' P_YN='||''''||p_line||''''||
	                                                  ' P_RTO_CITY='||''''||p_rto_city||''''||
	                                                  ' P_TMP_NO='||''''||P_TMP_NO||''''||
	                                                  ' P_AND='||''''||p_and||''''||
	                                                  ' REPORT_DESTYPE =PRINTER'||
	                                                  ' MODE=CHARACTER BLANKPAGES=NO');
		End If;
	 	SET_REPORT_OBJECT_PROPERTY(repid,REPORT_SERVER,lv_server);
		/*Declare
      hTimer    TIMER;
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
    Begin
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,:global.rep_server); -- 'mulreports
				:global.reporthandle := RUN_REPORT_OBJECT(repid);
				:global.printoutput :=vcFile;
			  hTimer := CREATE_TIMER('PRINTER_QUEUE','15000',REPEAT);
    End;*/
    general.PROC_REPORT_CALL (REPID,lv_report,lv_print);
	 	:global.reporthandle := lv_report;
		:global.printoutput  := lv_print;
    general.PROC_TIMER;	

	Else
		--Message('Alert Button3');
		Clear_Message;
	End If;
END;
```

#### SP-002 - CALL_REPORT_SR_FORM21_WRD

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Generates and streams the SR Form 21 statutory report as an RTF/Word document for the Invoice Details screen. The procedure first retrieves a dealer-location price flag from AM_DEALER_LOC_PARAM, then configures and runs the Oracle Reports object 'REPORT_CALL' (report file sr_form21) with all relevant invoice, dealer, and RTO parameters, finally delivering the output to the user's browser as a Microsoft Word attachment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | varchar2 | IN |
| p_parent | varchar2 | IN |
| p_dealer | varchar2 | IN |
| p_loc | varchar2 | IN |
| p_comp_fa | varchar2 | IN |
| p_allot_inv | varchar2 | IN |
| p_and | varchar2 | IN |
| p_line | varchar2 | IN |
| p_rto_city | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Query AM_DEALER_LOC_PARAM using the current session globals (PARENT_GROUP, DEALER, LOC_CD) to retrieve the X_F_PRICE_YN flag; default to 'N' if the column value is NULL. If any exception occurs, display the database error message via GENERAL.DISP_TEXT and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 2 - Locate the Oracle Reports object named 'REPORT_CALL' within the current form using Find_Report_Object.
- Step 3 - Set the target report filename to 'sr_form21'.
- Step 4 - Configure the report object properties: destination type = CACHE, destination format = RTF.
- Step 5 - Build the report parameter string by concatenating all input parameters (P_PARENT, P_PRINCIPAL, P_COMP_FA, P_DEALER, P_LOC, P_ALLOT_INV, P_FLAG derived from Step 1, P_YN, P_RTO_CITY, P_AND) together with runtime directives MODE=BITMAP and BLANKPAGES=NO, and assign this string to the Report_Other property.
- Step 6 - Assign the report server name (sourced from :global.rep_server) to the report object.
- Step 7 - Execute the report via RUN_REPORT_OBJECT and capture the job identifier returned in lv_rep.
- Step 8 - Extract the numeric job ID from lv_rep (substring after the last underscore) and invoke web.show_document to open the completed report from the Reports servlet URL in a new browser window with MIME type application/msword.

---
**Decision Points**

DP-001

Condition:
The SELECT against AM_DEALER_LOC_PARAM raises an exception (e.g., NO_DATA_FOUND or any other database error).

TRUE:
GENERAL.DISP_TEXT is called with the SQLERRM error message and the label 'Error', then FORM_TRIGGER_FAILURE is raised, halting all further report generation steps.

FALSE:
Processing continues normally; LV_FLAG holds the retrieved (or defaulted) value of X_F_PRICE_YN and is passed as P_FLAG to the report.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
**Business Rules**

- BR-001 - The price-display flag (X_F_PRICE_YN) must be read from AM_DEALER_LOC_PARAM for the combination of the session's PARENT_GROUP, DEALER, and LOC_CD before the report is run; if the column is NULL it defaults to 'N', ensuring the report always receives a defined P_FLAG value.
- BR-002 - Any database error encountered while reading AM_DEALER_LOC_PARAM must be surfaced to the user via GENERAL.DISP_TEXT and must prevent the report from being generated (FORM_TRIGGER_FAILURE is raised).
- BR-003 - The SR Form 21 report must be rendered in RTF format (Report_Desformat = 'RTF') with MODE=BITMAP and BLANKPAGES=NO, ensuring the output is suitable for delivery as a Microsoft Word document.
- BR-004 - The report output must be delivered to the user's browser as a new window with MIME type application/msword, using the Oracle Reports servlet job-ID URL pattern to retrieve the cached result.
- BR-005 - Numeric parameters P_PRINCIPAL and P_DEALER must be cast with TO_NUMBER before being passed to the report, ensuring type-correct parameter binding.

---
**Implementation Logic**

```plsql
PROCEDURE CALL_REPORT_SR_FORM21_WRD  (p_principal varchar2,p_parent varchar2,p_dealer varchar2,
                                  p_loc varchar2, p_comp_fa varchar2, p_allot_inv varchar2,p_and varchar2,
                                  p_line varchar2,p_rto_city varchar2 )IS
                                  
	repid  					REPORT_OBJECT;
	lv_rep  				VARCHAR2(100);
	lv_report_name 	VARCHAR2(50);
	lv_server 			VARCHAR2(20) := :global.rep_server;
	lv_alert 				VARCHAR2(20);
	l_v_Param				VARCHAR2(50);
	l_AlertId				ALERT;
	lv_param				VARCHAR2(100);
	lv_report       VARCHAR2(2000);
	lv_print        VARCHAR2(2000);
	lv_flag         VARCHAR2(3) := 'N';
Begin
	
 BEGIN	 
	 SELECT NVL(X_F_PRICE_YN,'N')
	 INTO LV_FLAG
	 FROM AM_DEALER_LOC_PARAM
	 WHERE  PARENT_GROUP = :GLOBAL.PARENT_GROUP
	 AND DEALER_MAP_CD = :GLOBAL.DEALER
	 AND   LOC_CD = :GLOBAL.LOC_CD; 
		 
 EXCEPTION
 	 WHEN OTHERS THEN
 	 
 	   GENERAL.DISP_TEXT (SQLERRM , 'Error');
 	   RAISE FORM_TRIGGER_FAILURE;
 END;	
 
 	--Checking The Alert Button
	repid := Find_Report_Object('REPORT_CALL');
	lv_report_name := 'sr_form21';
	Set_Report_Object_Property(repid,REPORT_DESTYPE,CACHE);
	Set_Report_Object_Property(repid,Report_Desformat,'RTF');
	Set_Report_Object_Property(repid,Report_Other,' P_PARENT='||p_parent||
                                                 ' P_PRINCIPAL='||to_number(p_principal)||
                                                 ' P_COMP_FA='||p_comp_fa||
                                                 ' P_DEALER='||to_number(p_dealer)||
                                                 ' P_LOC='||p_loc||
                                                 ' P_ALLOT_INV='||p_allot_inv||
                                                 ' P_FLAG='||LV_FLAG||
                                                 ' P_YN='||''''||p_line||''''||
	                                               ' P_RTO_CITY='||''''||p_rto_city||''''||
                                                 ' P_AND='||''''||p_and||''''||
                                                 ' MODE=BITMAP BLANKPAGES=NO');
	Set_Report_Object_Property(repid,Report_Server,lv_server);
	Set_Report_Object_Property(repid,REPORT_FILENAME,lv_report_name);
  lv_rep := RUN_REPORT_OBJECT(repid);
  web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank?mimetype=application/msword'); 
END;
```

#### SP-003 - CHECK_RTO_CREATED

**Invoked From:**

- st_frm21_fmb.xml [Trigger: PRE-TEXT-ITEM]

---

**Screen:**

QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

Validates that at least one RTO Master record exists for the current principal, parent group, dealer, and location before the user can proceed past the triggering text item. If no matching RTO record is found, the procedure alerts the user to create the required RTO configuration and halts further navigation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the current session's principal (`:GLOBAL.PRINCIPAL`) equals 2; if not, no action is taken and the procedure exits silently.
- Step 2 - Query `RTO_MASTER` to count records matching the combination of `:GLOBAL.PARENT_GROUP`, `:GLOBAL.DEALER`, `:GLOBAL.LOC_CD`, and `:GLOBAL.PRINCIPAL`.
- Step 3 - If the count returned is zero, invoke `GENERAL.DISP_TEXT` (SP-014) to display an instructional message directing the user to create an RTO record via the path Common -> Masters -> Dealer Master -> RTO Master before printing Form 21.
- Step 4 - Navigate focus to the item `CB_DUMMY.RT_CITY_DESC` to keep the user on the current screen.
- Step 5 - Raise `FORM_TRIGGER_FAILURE` to prevent the PRE-TEXT-ITEM trigger from completing and block further navigation.

---
**Decision Points**

DP-001

Condition:
`:GLOBAL.PRINCIPAL` equals 2.

TRUE:
Proceed to query `RTO_MASTER` for a matching record (DP-002).

FALSE:
Procedure exits without performing any validation or displaying any message.

---

DP-002

Condition:
The count of `RTO_MASTER` rows matching the current `PARENT_GROUP`, `DEALER_MAP_CD`, `LOC_CD`, and `PRINCIPAL_MAP_CD` equals zero.

TRUE:
Display an instructional alert via `GENERAL.DISP_TEXT`, navigate focus to `CB_DUMMY.RT_CITY_DESC`, and raise `FORM_TRIGGER_FAILURE` to halt processing.

FALSE:
No action is taken; the PRE-TEXT-ITEM trigger completes normally and the user may proceed.

---
**Database Interactions**

- DB-001 - Read RTO_MASTER - Reads data from RTO_MASTER for lookup or validation.
**Business Rules**

- BR-001 - The RTO existence check is enforced exclusively when the session principal is 2; all other principal values bypass this validation entirely.
- BR-002 - A valid RTO configuration must exist in `RTO_MASTER` for the exact combination of parent group, dealer, location, and principal before the user may interact with the triggering text item on the QUERY DETAILS screen.
- BR-003 - If no matching RTO record is found, the user must first create the RTO record through the designated application path (Common -> Masters -> Dealer Master -> RTO Master) before Form 21 can be printed.
- BR-004 - On validation failure, focus is explicitly redirected to `CB_DUMMY.RT_CITY_DESC` and `FORM_TRIGGER_FAILURE` is raised, ensuring the user cannot navigate past the current item until the prerequisite data exists.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_RTO_CREATED IS
BEGIN
  if :global.principal = 2 then
Declare
  lv_cnt number;
Begin
  select count(*)
    into lv_cnt
    FROM rto_master
   WHERE parent_group = :GLOBAL.PARENT_GROUP
     AND DEALER_MAP_CD = :GLOBAL.DEALER
     AND loc_CD = :GLOBAL.LOC_CD
     AND principal_map_cd = :GLOBAL.PRINCIPAL;

  if lv_cnt = 0 then
    General.disp_text('First Create RTO from RTO Master, Path: Common->Masters->Dealer Master->RTO Master and then print forms21',
                      'Note');
  	
       GO_ITEM('CB_DUMMY.RT_CITY_DESC');              
    Raise form_trigger_failure;
  End if;
End;
end if;
END;
```

#### SP-004 - FETCH_PARTY_DET

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Retrieves the financier party details (financier code, name, and branch) for every record in the B_CUSTOMER block on the INVOICE DETAILS screen. The procedure operates in one of two modes depending on the invoice alternate status passed in: 'A' (Allotment-based) derives the financier from the order-booking and allotment tables, while 'I' (Invoice-based) derives it directly from the invoice table. Results are written back to the block items FIN_CD and FIN_DESC for display.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| INV_ALT_STA | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to the B_CUSTOMER block and position the cursor on the first record.
- Step 2 - Evaluate the INV_ALT_STA input parameter to determine the data-retrieval path ('A' for allotment-based, 'I' for invoice-based).
- Step 3 (INV_ALT_STA = 'A') - For each record in the block, query SH_ORDBOOK joined to ST_ALLOT and GM_PARTY, matching on the allotment number (:B_CUSTOMER.NB_INV_NUM) and filtering by dealer, location, company, and parent group globals, with PARTY_TYPE = 'F', to retrieve the financier code (FI_CD), branch (BRANCH), and party name (PARTY_NAME).
- Step 4 (INV_ALT_STA = 'I') - For each record in the block, query SH_INVOICE joined to GM_PARTY, matching on the invoice number (:B_CUSTOMER.NB_INV_NUM) and applying the same dealer, location, company, and parent group filters with PARTY_TYPE = 'F', to retrieve the same three fields.
- Step 5 - After a successful retrieval, populate :B_CUSTOMER.FIN_CD with the financier code. If BRANCH is not null, set :B_CUSTOMER.FIN_DESC to the concatenation of PARTY_NAME, a comma, and BRANCH; otherwise set :B_CUSTOMER.FIN_DESC to PARTY_NAME alone.
- Step 6 - If any exception occurs during the query for a given record, clear :B_CUSTOMER.FIN_CD and :B_CUSTOMER.FIN_DESC to NULL for that record.
- Step 7 - Exit the loop when the current record is the last record in the block; otherwise advance to the next record and repeat from Step 3 or Step 4.
- Step 8 - After the loop completes, return the cursor to the first record in the B_CUSTOMER block.

---
**Decision Points**

DP-001

Condition:
INV_ALT_STA = 'A'

TRUE:
Financier details are fetched by joining SH_ORDBOOK, ST_ALLOT, and GM_PARTY using the allotment number stored in :B_CUSTOMER.NB_INV_NUM.

FALSE:
Proceed to evaluate whether INV_ALT_STA = 'I' (DP-002).

---

DP-002

Condition:
INV_ALT_STA = 'I'

TRUE:
Financier details are fetched by joining SH_INVOICE and GM_PARTY using the invoice number stored in :B_CUSTOMER.NB_INV_NUM.

FALSE:
Neither retrieval path executes; the procedure ends without populating financier fields.

---

DP-003

Condition:
LV_BRANCH_NAME IS NOT NULL (evaluated after a successful SELECT in either path)

TRUE:
:B_CUSTOMER.FIN_DESC is set to LV_FIN_NAME || ',' || LV_BRANCH_NAME (party name concatenated with branch).

FALSE:
:B_CUSTOMER.FIN_DESC is set to LV_FIN_NAME alone (no branch appended).

---

DP-004

Condition:
An exception is raised during the SELECT for a given B_CUSTOMER record

TRUE:
:B_CUSTOMER.FIN_CD and :B_CUSTOMER.FIN_DESC are set to NULL for that record; processing continues with the next record.

FALSE:
Financier code and description are populated as resolved by DP-003.

---

DP-005

Condition:
:SYSTEM.LAST_RECORD = 'TRUE' at the end of each loop iteration

TRUE:
The loop exits; no further records are processed.

FALSE:
NEXT_RECORD is called and the loop continues for the next B_CUSTOMER record.

---
**Database Interactions**

- DB-001 - Read SH_ORDBOOK - Reads data from SH_ORDBOOK for lookup or validation.
- DB-002 - Read SH_INVOICE - Reads data from SH_INVOICE for lookup or validation.
**Business Rules**

- BR-001 - Only parties with PARTY_TYPE = 'F' (financier) are eligible for retrieval; records linked to any other party type are excluded.
- BR-002 - All queries are scoped to the current dealer (:GLOBAL.DEALER), location (:GLOBAL.LOC_CD), company (:GLOBAL.COMP_FA), and parent group (:GLOBAL.PARENT_GROUP) to enforce multi-tenancy and data isolation.
- BR-003 - When INV_ALT_STA = 'A', the financier must be traceable through an allotment record (ST_ALLOT) linked to an order booking (SH_ORDBOOK); direct invoice lookup is not used.
- BR-004 - When INV_ALT_STA = 'I', the financier is resolved directly from the invoice record (SH_INVOICE) without reference to order-booking or allotment data.
- BR-005 - The displayed financier description (FIN_DESC) must include the branch name when one is present, formatted as '<PARTY_NAME>,<BRANCH>'; if no branch exists, only the party name is displayed.
- BR-006 - If financier data cannot be resolved for a record (any database exception), the financier code and description for that record are explicitly cleared to NULL, preventing stale or misleading data from being displayed.
- BR-007 - The procedure processes every record in the B_CUSTOMER block sequentially from first to last; no record is skipped unless an exception forces a NULL assignment and processing resumes on the next record.

---
**Implementation Logic**

```plsql
PROCEDURE FETCH_PARTY_DET (INV_ALT_STA VARCHAR2)
IS
	LV_BRANCH_NAME VARCHAR2(100);
	LV_FIN_NAME    VARCHAR2(100);
BEGIN
	GO_BLOCK('B_CUSTOMER');
	FIRST_RECORD;
	IF INV_ALT_STA = 'A' THEN
		LOOP
			BEGIN
				SELECT SH.FI_CD,SH.BRANCH,GM.PARTY_NAME
				INTO :B_CUSTOMER.FIN_CD,LV_BRANCH_NAME,LV_FIN_NAME
				FROM SH_ORDBOOK SH,ST_ALLOT ST,GM_PARTY GM
				WHERE ST.ALLOT_NUM = :B_CUSTOMER.NB_INV_NUM
				AND ST.ORDER_NUM = SH.ORDER_NUM
				AND SH.FI_CD = GM.PARTY_CD
				AND GM.PARTY_TYPE = 'F'
				AND SH.DEALER_MAP_CD = :GLOBAL.DEALER
				AND ST.DEALER_MAP_CD = SH.DEALER_MAP_CD
				AND GM.DEALER_MAP_CD = ST.DEALER_MAP_CD
				AND SH.LOC_CD = :GLOBAL.LOC_CD
				AND ST.LOC_CD = SH.LOC_CD
				AND SH.COMP_FA = :GLOBAL.COMP_FA
				AND ST.COMP_FA = SH.COMP_FA
				AND SH.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND ST.PARENT_GROUP = SH.PARENT_GROUP
				AND GM.PARENT_GROUP = ST.PARENT_GROUP;
				IF LV_BRANCH_NAME IS NOT NULL THEN
					:B_CUSTOMER.FIN_DESC := LV_FIN_NAME || ',' || LV_BRANCH_NAME;
				ELSE
					:B_CUSTOMER.FIN_DESC := LV_FIN_NAME;
				END IF;	
			EXCEPTION
				WHEN OTHERS THEN
					:B_CUSTOMER.FIN_CD   := NULL;
					:B_CUSTOMER.FIN_DESC := NULL;
			END;
			EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
			NEXT_RECORD;
		END LOOP;
	ELSIF INV_ALT_STA = 'I' THEN
		LOOP
			BEGIN
				SELECT SH.FI_CD,SH.BRANCH,GM.PARTY_NAME
				INTO :B_CUSTOMER.FIN_CD,LV_BRANCH_NAME,LV_FIN_NAME
				FROM SH_INVOICE SH,GM_PARTY GM
				WHERE SH.INV_NUM = :B_CUSTOMER.NB_INV_NUM
				AND SH.FI_CD = GM.PARTY_CD
				AND GM.PARTY_TYPE = 'F'
				AND SH.DEALER_MAP_CD = :GLOBAL.DEALER
				AND GM.DEALER_MAP_CD = SH.DEALER_MAP_CD
				AND SH.LOC_CD = :GLOBAL.LOC_CD
				AND SH.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND GM.PARENT_GROUP = SH.PARENT_GROUP
				AND SH.COMP_FA = :GLOBAL.COMP_FA;
				IF LV_BRANCH_NAME IS NOT NULL THEN
					:B_CUSTOMER.FIN_DESC := LV_FIN_NAME || ',' || LV_BRANCH_NAME;
				ELSE
					:B_CUSTOMER.FIN_DESC := LV_FIN_NAME;
				END IF;	
			EXCEPTION
				WHEN OTHERS THEN
					:B_CUSTOMER.FIN_CD   := NULL;
					:B_CUSTOMER.FIN_DESC := NULL;
			END;	
			EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
			NEXT_RECORD;
		END LOOP;	
	END IF;
	FIRST_RECORD;
END;
```

#### SP-005 - FORM_REP_PARAM

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Iterates over all records in the B_CUSTOMER block to collect invoice numbers flagged for Form 21 processing, conditionally persists the Form 21 flag against matching SH_INVOICE rows, and builds a comma-delimited list of qualifying invoice numbers that is appended to the IN OUT parameter P_PARAM for use by the calling trigger. Any database exception is surfaced to the caller via P_ERR_CD.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARAM | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARAM | VARCHAR2 | IN OUT |
| P_ERR_CD | NUMBER | OUT |

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise P_ERR_CD to 0, indicating no error at the start of execution.
- Step 2 - Navigate to the B_CUSTOMER block and position the cursor on the first record.
- Step 3 - Begin a loop over all records in the B_CUSTOMER block.
- Step 4 - For each record, evaluate whether the FORM21_YN flag is set to 'Y'.
- Step 5 - If FORM21_YN = 'Y' and the notebook type (CB_DUMMY.NB_TYPE) is 'I' and the print status (CB_DUMMY.NB_PRINT) is not 'P', update the corresponding SH_INVOICE row by setting FORM21_YN = 'Y', matching on PARENT_GROUP, DEALER_MAP_CD, LOC_CD, INV_TYPE, and INV_NUM, then commit the transaction.
- Step 6 - If FORM21_YN = 'Y' (regardless of the update condition), append the current invoice number to the local accumulator LV_PARAM; the first qualifying invoice is stored as a quoted literal, and each subsequent invoice is appended with a comma separator.
- Step 7 - Exit the loop when SYSTEM.LAST_RECORD is 'TRUE'; otherwise advance to the next record and repeat from Step 4.
- Step 8 - Append LV_PARAM followed by a closing parenthesis to P_PARAM, delivering the accumulated invoice list back to the caller.
- Step 9 - On a DUP_VAL_ON_INDEX exception, call GENERAL.DISP_TEXT to display a duplicate-record error message and set P_ERR_CD to 1.
- Step 10 - On any other exception, call GENERAL.DISP_TEXT to display a failure message including the Oracle error text (SQLERRM) and set P_ERR_CD to 1.

---
**Decision Points**

DP-001

Condition:
:B_CUSTOMER.FORM21_YN = 'Y'

TRUE:
The current invoice record is eligible for Form 21 processing; proceed to DP-002 and accumulate the invoice number into LV_PARAM.

FALSE:
The current record is skipped; no update is performed and the invoice number is not added to LV_PARAM.

---

DP-002

Condition:
:CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT <> 'P' (evaluated only when DP-001 is TRUE)

TRUE:
Execute the UPDATE on SH_INVOICE to set FORM21_YN = 'Y' for the matching invoice row and commit the transaction.

FALSE:
Skip the database update and commit; the invoice number is still accumulated into LV_PARAM.

---

DP-003

Condition:
LV_PARAM IS NULL (evaluated when appending the current invoice number to the accumulator)

TRUE:
Initialise LV_PARAM with the current invoice number as a single quoted literal.

FALSE:
Append a comma followed by the current invoice number as a quoted literal to the existing LV_PARAM value.

---

DP-004

Condition:
:SYSTEM.LAST_RECORD = 'TRUE' (evaluated at the end of each loop iteration)

TRUE:
Exit the loop and proceed to build the final P_PARAM value.

FALSE:
Advance to the next record and repeat the loop.

---
**Database Interactions**

- DB-001 - Update SH_INVOICE - Updates existing rows in SH_INVOICE (columns: form21 yn).
**Business Rules**

- BR-001 - Only invoices where FORM21_YN = 'Y' in the B_CUSTOMER block are eligible for Form 21 flag persistence and invoice-number accumulation.
- BR-002 - The SH_INVOICE FORM21_YN column is updated to 'Y' only when the notebook type is 'I' (invoice) and the print status is not 'P' (already printed); invoices that do not meet both criteria are excluded from the database update even if flagged.
- BR-003 - The SH_INVOICE update is committed immediately after each qualifying record is processed, ensuring each flag change is persisted before the loop continues.
- BR-004 - The accumulated invoice number list is appended to the caller-supplied P_PARAM value with a closing parenthesis, implying that the caller is responsible for supplying the opening portion of the parameter string (e.g., an IN-list prefix).
- BR-005 - A duplicate index violation during the update causes GENERAL.DISP_TEXT to display a user-facing error message ('Trying to create a duplicate record for invoice') and sets P_ERR_CD to 1 to signal failure to the caller.
- BR-006 - Any unhandled exception causes GENERAL.DISP_TEXT to display a failure message incorporating the Oracle error text and sets P_ERR_CD to 1, ensuring the caller can detect and handle processing failures.

---
**Implementation Logic**

```plsql
PROCEDURE FORM_REP_PARAM (P_PARAM IN OUT VARCHAR2,P_ERR_CD OUT NUMBER) IS
	LV_PARAM VARCHAR2(10000);

BEGIN
	-- Application Logging
	If :global.app_log = 'Y' then
		  stop_watch.start_timer;
	end if;
	P_ERR_CD := 0;
  GO_BLOCK('B_CUSTOMER');
	FIRST_RECORD;
	LOOP
-------------
/*		IF :B_CUSTOMER.FORM21_YN = 'Y' THEN
			declare
						lv_err_cd NUMBER;
						lv_err_msg Varchar2(4000) := null;
					begin
						Sf_Get_FORM21_Lock(:global.parent_group,
						:global.dealer,
						:global.loc_cd,
						:global.comp_fa,
						:CB_DUMMY.NB_TYPE,
						:B_CUSTOMER.NB_INV_NUM,
						lv_err_cd,
						lv_err_msg);												
						if lv_err_msg is not null then
							:B_CUSTOMER.FORM21_YN:='N';
							--set_item_property(:B_CUSTOMER.NB_INV_NUM,VISUAL_ATTRIBUTE,'VA_RB');
							--GENERAL.DISP_TEXT(lv_err_msg,'Error');
							--raise form_trigger_failure;
						end if;
					end ;
    end if;*/
-------------
		
		IF :B_CUSTOMER.FORM21_YN = 'Y' THEN
			IF :CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT <> 'P' THEN
				UPDATE SH_INVOICE SET FORM21_YN = 'Y' 
				WHERE PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND DEALER_MAP_CD = :GLOBAL.DEALER
				AND LOC_CD = :GLOBAL.LOC_CD
				AND INV_TYPE = :CB_DUMMY.INV_TYPE
				AND INV_NUM = :B_CUSTOMER.NB_INV_NUM;
				
				-- Application Logging
				If :global.app_log = 'Y' then
					stop_watch.stop_timer('PSS','ST_FRM21','Forms21','Submit',:global.userid);
				end if;
				COMMIT;
			END IF;
			IF LV_PARAM IS NULL THEN
				LV_PARAM := '''' || :B_CUSTOMER.NB_INV_NUM || '''';
			ELSE
				LV_PARAM := LV_PARAM || ',''' || :B_CUSTOMER.NB_INV_NUM || '''';
			END IF;
		
		END IF;
		EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
		NEXT_RECORD;	
	END LOOP;
	P_PARAM := P_PARAM || LV_PARAM || ')';
	
EXCEPTION
	WHEN DUP_VAL_ON_INDEX	THEN
		GENERAL.DISP_TEXT('Trying to create a duplicate record for invoice','Error');
		P_ERR_CD := 1;
	WHEN OTHERS THEN
		GENERAL.DISP_TEXT('Execution failed for updation of invoice ' || SQLERRM,'Error');
		P_ERR_CD := 1;	
END;
```

#### SP-006 - SET_REPORT_SERVER

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Determines and sets the report server name to be used for report execution by reading the server name from a configuration text file on the file system. The specific file read depends on the value of the input flag, allowing the application to target different report server environments (e.g., new vs. standard) at runtime. The resolved server name is stored in a global variable for downstream use by report-invocation logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| flg | number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-029](#SP-029--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-030](#SP-030--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-043](#SP-043--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input flag (flg) that identifies which report server configuration file to read.
- Step 2 - If flg = 1, open the file '/reports/DMS/repservernamenew.txt' in read mode using WEBUTIL.FOPEN (TEXT_IO.fopen).
- Step 3 - Read a single line from the opened file using WEBUTIL.GET_LINE (TEXT_IO.get_line) and store the value in the local variable v_char.
- Step 4 - Close the file using WEBUTIL.FCLOSE (TEXT_IO.fclose).
- Step 5 - Assign the retrieved server name to the global variable :global.rep_server.
- Step 6 - If flg = 2, repeat Steps 3-5 using the file '/reports/DMS/repservername.txt' instead.
- Step 7 - If flg is neither 1 nor 2, no file operation is performed and :global.rep_server is left unchanged.
- Step 8 - If any exception occurs during file operations, it is silently suppressed and processing ends without updating :global.rep_server.

---
**Decision Points**

DP-001

Condition:
flg = 1

TRUE:
Open '/reports/DMS/repservernamenew.txt', read the first line, close the file, and assign the value to :global.rep_server.

FALSE:
Proceed to evaluate DP-002.

---

DP-002

Condition:
flg = 2

TRUE:
Open '/reports/DMS/repservername.txt', read the first line, close the file, and assign the value to :global.rep_server.

FALSE:
No file is opened and :global.rep_server is not updated.

---

DP-003

Condition:
An exception is raised during file open, read, or close operations.

TRUE:
The exception is caught by the WHEN OTHERS handler and suppressed (NULL); :global.rep_server retains its previous value.

FALSE:
Normal processing completes and :global.rep_server is updated with the server name read from the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server name must be sourced exclusively from a pre-existing configuration text file on the server file system; it is not hard-coded in the procedure.
- BR-002 - A flag value of 1 directs the procedure to the 'new' report server configuration file ('/reports/DMS/repservernamenew.txt'), enabling routing to an alternate report server environment.
- BR-003 - A flag value of 2 directs the procedure to the standard report server configuration file ('/reports/DMS/repservername.txt').
- BR-004 - Only the first line of the configuration file is read; the report server name must therefore appear on the first line of the file.
- BR-005 - The resolved report server name is stored in the global variable :global.rep_server, making it available to all subsequent report-execution calls within the session.
- BR-006 - Any file I/O failure (e.g., file not found, read error) is silently suppressed; no error is raised to the user and :global.rep_server is not modified in such cases.
- BR-007 - If the flag value is neither 1 nor 2, the procedure takes no action and :global.rep_server is not updated.

---
**Implementation Logic**

```plsql
PROCEDURE set_report_server(flg number) IS
	v_file	TEXT_IO.file_type;
	v_char	varchar2(1000);
BEGIN
  	--Added By Manoj for running the report in different report server	
  	if flg=1 then
		  v_file := TEXT_IO.fopen('/reports/DMS/repservernamenew.txt','R');
		  TEXT_IO.get_line(v_file,v_char);
		  text_io.fclose(v_file);
		  :global.rep_server   := v_char;		
  	elsif flg=2 then
		  v_file := TEXT_IO.fopen('/reports/DMS/repservername.txt','R');
		  TEXT_IO.get_line(v_file,v_char);
		  text_io.fclose(v_file);
		  :global.rep_server   := v_char;
  	end if;
  	exception when others then
  		null;
		--End,Added By Manoj for running the report in different report server
END;
```

#### SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given directory path before loading. If the load succeeds and counting is enabled, it increments the module-level DLL load counter and marks the API as enabled. If any failure occurs, it disables the API and returns a null library handle, allowing the caller (REGISTER_FUNCTION_CALL) to handle the unavailable library gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-076](#SP-076--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip path validation and proceed directly to the DLL load attempt.
- Step 2 - Sanitise TargetPath by passing it through STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\') to produce a consistently formatted path. This discards any secondary paths that may have been concatenated into the value.
- Step 3 - Attempt to open the file identified by the concatenation of TargetPath and TargetDLL in read mode using TEXT_IO.FOPEN to confirm the file physically exists at the specified location.
- Step 4 - If the file is opened successfully, close it immediately with TEXT_IO.FCLOSE; the open was purely a presence check.
- Step 5 - If the file open raises any exception, invoke DEBUGLOG (severity 99) to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort the load attempt.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the library into memory and capture the resulting library handle in hDLL.
- Step 7 - If the LoadCount flag is TRUE, increment the module-level DLL_LOAD_COUNT counter by 1 and set the module-level API_ENABLED flag to TRUE.
- Step 8 - Return hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null hDLL handle to the caller.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Sanitise TargetPath via STRIPDIRSEP, append a backslash, and perform a physical file-existence check before attempting the DLL load.

FALSE: Skip path sanitisation and file-existence check; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the concatenated file path (TargetPath || TargetDLL)

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log a debug message via DEBUGLOG recording the DLL name and the path where it was not found, then raise the BadLocation exception to halt processing.

---

DP-003

Condition: LoadCount IS TRUE (after a successful ORA_FFI.LOAD_LIBRARY call)

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI.LOAD_LIBRARY call or surrounding logic

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Return the successfully populated library handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain exactly one directory path; if multiple paths are present in the value, only the first is used and the remainder are discarded by the STRIPDIRSEP normalisation step.
- BR-002 - A trailing backslash directory separator must always be present on TargetPath before the DLL load is attempted; STRIPDIRSEP is called to remove any existing separator before one is appended, ensuring no double-separator condition.
- BR-003 - When TargetPath is provided, the target DLL file must be physically accessible at the specified path before a load is attempted; failure to open the file is treated as a fatal location error (BadLocation) and the load is not attempted.
- BR-004 - A failed file-existence check must be recorded in the debug log via DEBUGLOG at severity level 99, capturing both the DLL name and the path that was searched.
- BR-005 - The module-level DLL_LOAD_COUNT counter must only be incremented on a successful library load and only when the LoadCount parameter is TRUE, ensuring accurate tracking of loaded libraries.
- BR-006 - API_ENABLED must be set to TRUE only upon a successful DLL load where LoadCount is TRUE, and must be set to FALSE whenever the load operation raises an unhandled exception, reflecting the real-time availability of the loaded API.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C-language D2KWUTIL library routine. It is invoked by the WINDEBUG stored procedure within D2kwutil.pld to relay diagnostic or debug messages from the Oracle Forms PL/SQL layer to the native windowing/debug subsystem via the ORA_FFI pragma interface.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function entry point within the D2KWUTIL shared library.
- Step 2 - Receive the debug text string (Text) containing the diagnostic message to be transmitted.
- Step 3 - Invoke the external C routine d2kwutil_DebugString through the ORA_FFI PRAGMA INTERFACE (interface code 11265), passing hFunc and Text directly to the native library.
- Step 4 - Return control to the calling routine (WINDEBUG) upon completion of the external call; no output value is produced.

---
**Decision Points**

No conditional decision points are present in this procedure. The implementation consists solely of a foreign-function interface declaration delegating execution unconditionally to the external C routine.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI.funcHandleType handle (hFunc); the handle must have been obtained prior to invocation by the parent WINDEBUG routine, as no handle resolution is performed within this procedure.
- BR-002 - The Text parameter carries the debug string exactly as supplied by the caller; no transformation, truncation, or validation is applied within this procedure before it is forwarded to the external C function.
- BR-003 - The external C function is bound exclusively via PRAGMA INTERFACE with interface code 11265; this binding is fixed at compile time and cannot be altered at runtime.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-009 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle and a source environment variable name, then returns the expanded (resolved) value of that variable in the ExpandStr output buffer, bounded by the caller-supplied buffer length. The function is invoked indirectly through the GET_ENVIRONMENT_STRING stored procedure in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying OS-level routine responsible for environment variable expansion.
- Step 2 - Accept the source environment variable name via SourceStr (IN OUT), which identifies the variable to be resolved.
- Step 3 - Accept the pre-allocated output buffer ExpandStr (IN OUT) that will receive the expanded/resolved value of the environment variable.
- Step 4 - Accept InBuffLen, which defines the maximum number of characters that may be written into ExpandStr, preventing buffer overrun.
- Step 5 - Delegate execution to the external OS function referenced by hFunc, passing SourceStr and ExpandStr by reference so the OS can populate ExpandStr with the resolved environment variable value.
- Step 6 - Return a PLS_INTEGER result code to the caller (GET_ENVIRONMENT_STRING) indicating the success or failure of the environment variable retrieval.

---
**Decision Points**

No explicit conditional decision points are determinable from the available specification. The function signature indicates a return code is produced, but the branching logic based on that return code is handled by the invoking routine GET_ENVIRONMENT_STRING in D2kwutil.pld, not within this function itself.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must reference the correct OS-level environment expansion routine before this function is called.
- BR-002 - The caller is responsible for supplying InBuffLen accurately reflecting the allocated size of ExpandStr to prevent truncation or overflow of the resolved environment variable value.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the caller must initialise them prior to invocation; the OS routine may read SourceStr and overwrite ExpandStr in place.
- BR-004 - The PLS_INTEGER return value must be evaluated by the calling routine (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully resolved; this function does not raise exceptions internally based on the available specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows Registry key value. Given a registry root, path, and entry name, it calls the underlying native function handle (hFunc) to read the corresponding registry value into RegValue, subject to a maximum buffer length and an optional flag controlling environment-variable expansion within the returned value. The integer return code indicates the success or failure of the registry read operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the native function handle (hFunc) that references the external Windows Registry API routine to be invoked via ORA_FFI.
- Step 2 - Accept the registry root identifier (RegRoot) that specifies the top-level hive (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) under which the target key resides.
- Step 3 - Accept the registry path (RegPath) and entry name (RegEntry) that together identify the specific registry key-value pair to be read.
- Step 4 - Accept the maximum allowable length for the returned value (RegValueLength) to control buffer allocation for RegValue.
- Step 5 - Accept the expansion flag (RegDontExpand) that determines whether environment-variable references embedded in the registry value string are expanded before the value is returned.
- Step 6 - Invoke the external native function via the ORA_FFI function handle (hFunc), passing all registry-location and buffer parameters.
- Step 7 - Populate the IN OUT parameter RegValue with the registry value string retrieved by the native call.
- Step 8 - Return a PLS_INTEGER result code reflecting the outcome of the registry read operation (success or failure) to the calling routine READ_REGISTRY in D2kwutil.pld.

---
**Decision Points**

No decision points can be determined from the available source. Only the function specification is present; no PL/SQL body or conditional logic is exposed in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle is the sole mechanism by which the Oracle Forms layer communicates with the underlying Windows Registry native API.
- BR-002 - RegRoot must be supplied as a valid Windows registry hive constant (PLS_INTEGER); the function does not perform hive defaulting.
- BR-003 - RegValueLength defines the maximum number of characters that may be written into RegValue; callers must allocate RegValue with at least this capacity to prevent buffer overrun.
- BR-004 - When RegDontExpand is set, environment-variable placeholders within the retrieved registry string are returned unexpanded; when not set, expansion is permitted, allowing dynamic resolution of system paths stored in the registry.
- BR-005 - RegPath and RegEntry are declared IN OUT, meaning the native FFI layer may normalise or modify these values during the call; callers must not treat them as read-only after the function returns.
- BR-006 - The integer return value must be evaluated by the caller (READ_REGISTRY) to determine whether the registry read succeeded; no exception handling is visible within this specification, placing error-handling responsibility on the invoking routine.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Translates a string-based C data type name into its corresponding ORA_FFI integer constant. This function acts as a lookup utility within the D2KWUTIL package, enabling REGISTER_FUNCTION_CALL to resolve human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input DataType string and convert it to uppercase to ensure case-insensitive matching.
- Step 2 - Compare the normalised type string against each recognised C data type token in sequence: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT' / '*BYTE', 'SHORT' / 'BYTE', '*DOUBLE', 'DOUBLE', '*VOID'.
- Step 3 - Upon the first matching token, assign the corresponding ORA_FFI integer constant to the return variable (e.g., ORA_FFI.C_CHAR_PTR, ORA_FFI.C_INT, ORA_FFI.C_LONG_PTR, etc.).
- Step 4 - Return the resolved ORA_FFI integer constant to the caller.

---
**Decision Points**

DP-001

Condition: Normalised DataType equals '*CHAR'

TRUE: Assign ORA_FFI.C_CHAR_PTR as the return value.

FALSE: Proceed to DP-002.

---

DP-002

Condition: Normalised DataType equals 'CHAR'

TRUE: Assign ORA_FFI.C_CHAR as the return value.

FALSE: Proceed to DP-003.

---

DP-003

Condition: Normalised DataType equals '*INT'

TRUE: Assign ORA_FFI.C_INT_PTR as the return value.

FALSE: Proceed to DP-004.

---

DP-004

Condition: Normalised DataType equals 'INT'

TRUE: Assign ORA_FFI.C_INT as the return value.

FALSE: Proceed to DP-005.

---

DP-005

Condition: Normalised DataType equals '*LONG'

TRUE: Assign ORA_FFI.C_LONG_PTR as the return value.

FALSE: Proceed to DP-006.

---

DP-006

Condition: Normalised DataType equals 'LONG'

TRUE: Assign ORA_FFI.C_LONG as the return value.

FALSE: Proceed to DP-007.

---

DP-007

Condition: Normalised DataType equals '*SHORT' or '*BYTE'

TRUE: Assign ORA_FFI.C_SHORT_PTR as the return value.

FALSE: Proceed to DP-008.

---

DP-008

Condition: Normalised DataType equals 'SHORT' or 'BYTE'

TRUE: Assign ORA_FFI.C_SHORT as the return value.

FALSE: Proceed to DP-009.

---

DP-009

Condition: Normalised DataType equals '*DOUBLE'

TRUE: Assign ORA_FFI.C_DOUBLE_PTR as the return value.

FALSE: Proceed to DP-010.

---

DP-010

Condition: Normalised DataType equals 'DOUBLE'

TRUE: Assign ORA_FFI.C_DOUBLE as the return value.

FALSE: Proceed to DP-011.

---

DP-011

Condition: Normalised DataType equals '*VOID'

TRUE: Assign ORA_FFI.C_VOID_PTR as the return value.

FALSE: No assignment is made; the return variable remains uninitialised (NULL).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is treated as case-insensitive; it is converted to uppercase before any comparison, so 'int', 'INT', and 'Int' are all treated equivalently.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' maps to ORA_FFI.C_INT_PTR, whereas 'INT' maps to ORA_FFI.C_INT).
- BR-003 - The tokens '*SHORT' and '*BYTE' are treated as aliases and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - If the supplied DataType does not match any recognised token, the function returns NULL (no default or exception is raised), which may cause unexpected behaviour in the calling routine REGISTER_FUNCTION_CALL.
- BR-005 - The function performs a pure in-memory lookup with no database reads or writes; it has no side effects.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-012 - GENERAL.ASK_CONFIRM

**Invoked From:**

- st_frm21_fmb.xml [Trigger: FT_CANCEL]
- st_frm21_fmb.xml [Trigger: FT_DEL]
- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function is used by cancel, delete, and button-pressed triggers on the QUERY DETAILS screen to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the confirm_msg input parameter.
- Step 2 - Set the message text of the AL_CONFIRM alert to the value supplied in confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1, return 1 to indicate confirmation; otherwise return 0 to indicate rejection.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the user pressed the first/confirm button on the AL_CONFIRM alert).

TRUE:
The function returns 1, signalling to the calling trigger that the user has confirmed the action.

FALSE:
The function returns 0, signalling to the calling trigger that the user has declined the action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be AL_CONFIRM; no other alert name is permissible within this function.
- BR-002 - The alert message text must be dynamically set to the value of confirm_msg before the alert is displayed, ensuring the prompt shown to the user is context-specific to the invoking trigger.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response must be treated as a non-confirmation and returns 0.
- BR-004 - The function must always return a numeric value (1 or 0); the calling trigger (FT_CANCEL, FT_DEL, or WHEN-BUTTON-PRESSED) is responsible for acting on the returned value to determine whether to proceed with the requested operation.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-013 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- st_frm21_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Checks whether the most recent Oracle Forms operation succeeded and, if not, surfaces the appropriate error message to the user before halting further trigger processing. It distinguishes between Oracle database errors (ORA) and Oracle Forms runtime errors (FRM), delegating message display to GENERAL.DISP_TEXT (SP-014) and then raising FORM_TRIGGER_FAILURE to abort the KEY-COMMIT trigger.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in FORM_SUCCESS function to determine whether the last Forms operation completed without error.
- Step 2 - If the operation did not succeed, inspect the built-in ERROR_TYPE to classify the failure.
- Step 3 - If ERROR_TYPE is 'ORA' (Oracle database error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to present the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (Oracle Forms runtime error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to present the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to halt execution of the KEY-COMMIT trigger and prevent any uncommitted changes from being processed further.
- Step 6 - If FORM_SUCCESS is TRUE, no action is taken and processing continues normally.

---
**Decision Points**

DP-001

Condition:
FORM_SUCCESS evaluates to FALSE (i.e., the last Forms operation failed).

TRUE:
Proceed to classify the error type (DP-002) and ultimately raise FORM_TRIGGER_FAILURE.

FALSE:
No action is taken; the procedure exits normally and the KEY-COMMIT trigger continues.

---

DP-002

Condition:
ERROR_TYPE = 'ORA' (the failure originated from the Oracle database layer).

TRUE:
Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity label 'Error'.

FALSE:
Evaluate whether ERROR_TYPE = 'FRM' (DP-003).

---

DP-003

Condition:
ERROR_TYPE = 'FRM' (the failure originated from the Oracle Forms runtime layer).

TRUE:
Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms runtime error message) and severity label 'Error'.

FALSE:
No message is displayed; execution falls through to raise FORM_TRIGGER_FAILURE regardless.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A failed Forms operation (FORM_SUCCESS = FALSE) must always result in FORM_TRIGGER_FAILURE being raised, ensuring that the KEY-COMMIT trigger is aborted and no partial or erroneous data is committed.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported to the user using the Oracle-supplied SQLERRM message text, routed through GENERAL.DISP_TEXT with severity 'Error'.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be reported to the user using the Forms-supplied ERROR_TEXT message text, routed through GENERAL.DISP_TEXT with severity 'Error'.
- BR-004 - Error message display is exclusively delegated to GENERAL.DISP_TEXT (SP-014); this procedure must not render error messages through any other mechanism.
- BR-005 - If FORM_SUCCESS is TRUE, the procedure must take no action and must not interfere with normal commit processing.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-014 - GENERAL.DISP_TEXT

**Invoked From:**

- st_frm21_fmb.xml [ProgramUnit: CALL_REPORT_SR_FORM21]
- st_frm21_fmb.xml [ProgramUnit: CALL_REPORT_SR_FORM21_WRD]
- st_frm21_fmb.xml [ProgramUnit: CHECK_RTO_CREATED]
- st_frm21_fmb.xml [ProgramUnit: FORM_REP_PARAM]
- st_frm21_fmb.xml [StoredProcedure: CALL_REPORT_SR_FORM21]
- st_frm21_fmb.xml [StoredProcedure: CALL_REPORT_SR_FORM21_WRD]
- st_frm21_fmb.xml [StoredProcedure: CHECK_RTO_CREATED]
- st_frm21_fmb.xml [StoredProcedure: FORM_REP_PARAM]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.PROC_TIMER_EXPIRED]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- DPL.pld [StoredProcedure: RUN_REPORT]
- st_frm21_fmb.xml [Trigger: FT_PRINT]
- st_frm21_fmb.xml [Trigger: KEY-DOWN]
- st_frm21_fmb.xml [Trigger: KEY-UP]
- st_frm21_fmb.xml [Trigger: ON-ERROR]
- st_frm21_fmb.xml [Trigger: ON-MESSAGE]
- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- st_frm21_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]
- st_frm21_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN); QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a supplied message and title. The procedure selects the appropriate Oracle Forms alert template based on whether the title indicates an error condition, then presents the message text to the user. It is used across multiple triggers and program units within the Invoice Details and Query Details screens to surface informational notes and error notifications.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the alert name variable to the default error alert template 'AL_ERRINFO'.
- Step 2 - Evaluate the title_string parameter: if its upper-case value equals 'ERROR', retain 'AL_ERRINFO' as the alert template; otherwise switch the alert template to 'AL_NOTE' for informational messages.
- Step 3 - Set the Title property of the selected alert template to the value supplied in title_string.
- Step 4 - Set the Message Text property of the selected alert template to the value supplied in text_string.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT and capture the user's response in p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert template 'AL_ERRINFO' is used, indicating an error-severity dialog is required.

FALSE:
The alert template 'AL_NOTE' is used, indicating an informational or non-error dialog is required.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert template selection is driven exclusively by the title_string value; a title of 'ERROR' (case-insensitive) always maps to the error alert 'AL_ERRINFO', while any other title maps to the informational alert 'AL_NOTE'.
- BR-002 - Both the alert title and the alert message text must be set dynamically at runtime from the supplied parameters before the alert is shown; no hard-coded message content is presented to the user.
- BR-003 - The procedure does not evaluate or act upon the user's response to the alert; it serves solely as a display mechanism with no branching logic after SHOW_ALERT returns.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-015 - GENERAL.PROC_REPORT_CALL

**Invoked From:**

- st_frm21_fmb.xml [ProgramUnit: CALL_REPORT_SR_FORM21]
- st_frm21_fmb.xml [StoredProcedure: CALL_REPORT_SR_FORM21]

---

**Screen:**

QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

Configures and submits an Oracle Reports object for batch execution, directing output to a server-side file in the reports printer directory. The procedure returns the report job identifier and the generated output file name to the caller, enabling downstream processing (e.g., printing or status polling) by the invoking form unit.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| REPID | report_object | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| lv_report | varchar2 | OUT |
| lv_print | varchar2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the report server name from the global variable ':global.rep_server' using NAME_IN and store it in a local variable.
- Step 2 - Construct a unique output file name by concatenating the current Oracle Forms application username with the current system date/time formatted as YYYYMMDDHHMISS, then append the '.rrpp' file extension.
- Step 3 - Set the report execution mode to BATCH on the supplied report object (REPID).
- Step 4 - Set the report destination type to FILE on the report object.
- Step 5 - Set the report destination file path to '/iashome/ias/reports/printer/' concatenated with the generated file name.
- Step 6 - Assign the report server name (retrieved in Step 1) to the report object.
- Step 7 - Execute the report by calling RUN_REPORT_OBJECT with the configured report object; store the returned job identifier in the OUT parameter lv_report.
- Step 8 - Assign the generated file name to the OUT parameter lv_print so the caller can reference the output file.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally in sequence.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report server must be pre-populated in the global variable ':global.rep_server' before this procedure is called; the procedure reads but does not validate this value.
- BR-002 - The output file name must be unique per invocation; uniqueness is enforced by combining the application username with the system timestamp (YYYYMMDDHHMISS) to minimise collision risk.
- BR-003 - All reports submitted through this procedure must run in BATCH execution mode with FILE as the destination type; interactive or printer-direct modes are not used.
- BR-004 - The output file must be written to the designated server-side directory '/iashome/ias/reports/printer/'; no alternative output path is permitted.
- BR-005 - The generated output file must carry the '.rrpp' extension, identifying it as a report output file for downstream consumers.
- BR-006 - The calling program unit is responsible for using the returned lv_report job identifier and lv_print file name for any subsequent status checking or print operations; this procedure does not poll or verify job completion.

---
**Implementation Logic**

```plsql

PROCEDURE PROC_REPORT_CALL (REPID report_object, lv_report OUT varchar2, lv_print OUT varchar2) IS
      vcFile    VARCHAR2(225) := 'test';
      vcResult  VARCHAR2(30);
      lv_server VARCHAR2(1000);
    Begin
    	  lv_server := name_in(':global.rep_server');
        vcFile:= Get_Application_Property(UserName)||To_Char(Sysdate,'YYYYMMDDHHMISS');
        vcFile := vcFile||'.rrpp';
         Set_Report_Object_Property(repid,REPORT_EXECUTION_MODE,BATCH);
        Set_Report_Object_Property(repid,REPORT_DESTYPE,FILE);
      	set_report_object_property(repid,REPORT_DESNAME,'/iashome/ias/reports/printer/'||vcFile);
				Set_Report_Object_Property(repid,REPORT_SERVER,lv_server); --'mulreports
			  lv_report:= RUN_REPORT_OBJECT(repid);
			  lv_print := vcFile;			  
End;
```

#### SP-016 - GENERAL.PROC_TIMER

**Invoked From:**

- st_frm21_fmb.xml [ProgramUnit: CALL_REPORT_SR_FORM21]
- st_frm21_fmb.xml [StoredProcedure: CALL_REPORT_SR_FORM21]

---

**Screen:**

QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

Creates a repeating Oracle Forms timer named PRINTER_QUEUE with a 5000-millisecond interval. This procedure is called during report submission processing to establish a polling mechanism that periodically checks the printer queue status on behalf of the CALL_REPORT_SR_FORM21 program unit.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Declare a local TIMER handle variable (hTimer) to hold the reference to the newly created timer.
- Step 2 - Invoke the Oracle Forms built-in CREATE_TIMER to create a timer named 'PRINTER_QUEUE' with a 5000-millisecond (5-second) interval and a REPEAT firing mode, assigning the returned handle to hTimer.

---
**Decision Points**

No conditional decision points exist in this procedure. Execution follows a single unconditional path: declare the timer handle and create the repeating timer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The printer queue polling timer must be named 'PRINTER_QUEUE' to ensure the corresponding WHEN-TIMER-EXPIRED trigger can identify and handle it correctly.
- BR-002 - The timer interval must be set to 5000 milliseconds (5 seconds), defining the frequency at which the printer queue is polled.
- BR-003 - The timer must be created in REPEAT mode so that it fires continuously at the defined interval until explicitly deleted, ensuring ongoing queue monitoring without requiring re-invocation of this procedure.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER IS
  hTimer    TIMER;
 begin
  hTimer := CREATE_TIMER('PRINTER_QUEUE','5000',REPEAT);
 end;
```

#### SP-017 - GENERAL.PROC_TIMER_EXPIRED

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-TIMER-EXPIRED]

---

**Screen:**

N/A

---

**Purpose**

Handles the WHEN-TIMER-EXPIRED trigger for the 'PRINTER_QUEUE' timer. When a background report job completes, this procedure checks the current status of the report object and either waits for completion, opens the finished print output document in a new browser window, or displays an error message and cleans up the timer if the report job has failed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the name of the expired timer using GET_APPLICATION_PROPERTY(TIMER_NAME) and store it in vcTimerName.
- Step 2 - Read the global variables :GLOBAL.REPORTHANDLE and :GLOBAL.PRINTOUTPUT into local variables lv_report_handle and lv_printout respectively.
- Step 3 - Evaluate whether the expired timer is named 'PRINTER_QUEUE'; if not, no action is taken and the procedure exits.
- Step 4 - If the timer is 'PRINTER_QUEUE', call REPORT_OBJECT_STATUS passing lv_report_handle to obtain the current status of the background report job.
- Step 5 - If the status is 'RUNNING', 'OPENING_REPORT', or 'ENQUEUED', take no action (NULL), allowing the timer to continue polling on its next expiry.
- Step 6 - If the status is 'FINISHED', invoke WEB.SHOW_DOCUMENT to open the print output URL ('/printer/' concatenated with lv_printout) in a new browser window ('_blank'), then delete the timer using DELETE_TIMER(vcTimerName).
- Step 7 - If the status is any other value (indicating a report failure), call GENERAL.DISP_TEXT to display the message 'Unable to generate the report' with severity 'Error', then delete the timer using DELETE_TIMER(vcTimerName).

---
**Decision Points**

DP-001

Condition:
vcTimerName = 'PRINTER_QUEUE'

TRUE:
Proceed to check the report object status and handle the result accordingly.

FALSE:
No action is taken; the procedure exits without further processing.

---

DP-002

Condition:
vcStatus IN ('RUNNING', 'OPENING_REPORT', 'ENQUEUED')

TRUE:
Execute NULL - the report job is still in progress; the timer is left active to poll again on its next expiry.

FALSE:
Evaluate the status further via DP-003.

---

DP-003

Condition:
vcStatus = 'FINISHED'

TRUE:
Open the print output document in a new browser window via WEB.SHOW_DOCUMENT('/printer/' || lv_printout, '_blank') and delete the timer.

FALSE:
The report job has ended in an error state; call GENERAL.DISP_TEXT to display 'Unable to generate the report' with severity 'Error' and delete the timer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This procedure only acts when the expired timer is named 'PRINTER_QUEUE'; all other timer names are silently ignored.
- BR-002 - While the report job status is 'RUNNING', 'OPENING_REPORT', or 'ENQUEUED', the procedure takes no action, preserving the timer so that subsequent expiry events continue to poll the report status.
- BR-003 - When the report job status is 'FINISHED', the completed print output must be presented to the user by opening the URL '/printer/' || lv_printout in a new browser window before the timer is deleted.
- BR-004 - Any report job status other than the in-progress statuses or 'FINISHED' is treated as a failure; the user must be notified via GENERAL.DISP_TEXT with the message 'Unable to generate the report' and severity 'Error'.
- BR-005 - The 'PRINTER_QUEUE' timer must be deleted (DELETE_TIMER) upon any terminal outcome - either successful report delivery or report failure - to prevent further polling.

---
**Implementation Logic**

```plsql
PROCEDURE PROC_TIMER_EXPIRED IS
	vcStatus varchar2(50);
	vcTimerName varchar2(30);
	hTimer timer;
	report_id report_object;
  lv_report_handle varchar2(4000);
  lv_printout      varchar2(4000);
begin
	vcTimerName := get_application_property(timer_name);
   			lv_report_handle := name_in(':global.reporthandle');
        lv_printout      := name_in(':GLOBAL.PRINTOUTPUT');
 
	if vcTimerName = 'PRINTER_QUEUE' then
		 vcStatus := REPORT_OBJECT_STATUS(lv_report_handle);
	   if vcStatus in ('RUNNING','OPENING_REPORT','ENQUEUED') THEN
	   	  NULL;
	   ELSIF VCsTATUS = 'FINISHED' THEN
        web.show_document('/printer/'||lv_printout ,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(:global.reporthandle,instr(:global.reporthandle,'_',-1)+1)||'?'||'server=mulreports'||:GLOBAL.PRINTOUTPUT,'_blank');
--        web.show_document('/reports/rwservlet/getjobid'||substr(lv_rep,instr(lv_rep,'_',-1)+1)||'?'||'server='||lv_server,'_blank');
        delete_timer(vcTimerName);
	   ELSE
--	   	  general.disp_text('Unable to generate the report'||vcStatus,'Error');
        general.disp_text('Unable to generate the report','Error');
	   	  delete_timer(vcTimerName);
	   end if;
	end if;   
end;
```

#### SP-018 - GENERAL.RAISE_ERROR

**Invoked From:**

- st_frm21_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

RAISE_ERROR is a centralised error-notification procedure invoked by the ON-ERROR trigger. It accepts a message code, constructs a display string by concatenating the code with any associated message text, determines the severity of the message (Error, Note, or Caution), and presents the appropriate dialog to the user via GENERAL.DISP_TEXT. For error-severity messages it additionally raises FORM_TRIGGER_FAILURE to halt further form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Construct the display message text by concatenating mesg_code, the literal ' : ', and the local variable mesg_text (note: the formerly used GENERAL.get_message call is commented out, so mesg_text remains uninitialised and effectively empty at runtime).
- Step 3 - Evaluate the mesg_type variable to determine message severity.
- Step 4 - If mesg_type is 'E' (Error), set mesg_title to 'Error', invoke GENERAL.DISP_TEXT with the constructed message and title, then raise FORM_TRIGGER_FAILURE to abort the triggering form action.
- Step 5 - If mesg_type is 'N' (Note), set mesg_title to 'Note' and invoke GENERAL.DISP_TEXT with the constructed message and title; no exception is raised and processing continues normally.
- Step 6 - If mesg_type is 'C' (Caution), set mesg_title to 'Caution' and invoke GENERAL.DISP_TEXT with the constructed message and title; no exception is raised and processing continues normally.
- Step 7 - If mesg_type does not match any of the three recognised values ('E', 'N', 'C'), no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition: mesg_type = 'E'

TRUE: Set mesg_title to 'Error', display the message to the user via GENERAL.DISP_TEXT, and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: Proceed to evaluate whether mesg_type is 'N' (DP-002).

DP-002

Condition: mesg_type = 'N'

TRUE: Set mesg_title to 'Note' and display the message to the user via GENERAL.DISP_TEXT; form processing continues.

FALSE: Proceed to evaluate whether mesg_type is 'C' (DP-003).

DP-003

Condition: mesg_type = 'C'

TRUE: Set mesg_title to 'Caution' and display the message to the user via GENERAL.DISP_TEXT; form processing continues.

FALSE: No message is displayed and the procedure exits without further action.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Only three message severity levels are recognised: 'E' (Error), 'N' (Note), and 'C' (Caution). Any mesg_type value outside these three results in silent no-operation behaviour.
- BR-002 - An Error-severity message (mesg_type = 'E') must always terminate the current form action by raising FORM_TRIGGER_FAILURE after the message is displayed; Note and Caution messages must not raise this exception.
- BR-003 - The displayed message text must always be prefixed with the originating message code followed by ' : ', ensuring the user and support staff can identify the specific error reference.
- BR-004 - User notification for all recognised severity levels must be delivered exclusively through GENERAL.DISP_TEXT; no other display mechanism is used by this procedure.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-019 - QRY_RECORDS.QUERY_RECORDS

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-NEW-BLOCK-INSTANCE]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Populates the Invoice Details query cursor (IN_CURSOR) with either allotment records or invoice records based on user-selected filter criteria. The procedure supports six distinct query paths driven by the query type (Allotment or Invoice), the print-status filter (Printed, Not Printed, or All), and whether a date range has been supplied. It is triggered when the CN_MAIN block gains focus via WHEN-NEW-BLOCK-INSTANCE.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| IN_CURSOR | QRY_CURSOR | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| IN_CURSOR | QRY_CURSOR | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the print-type flag: if NB_PRINT is 'P', set local variable PRNT_TYPE to 'Y' (printed); if NB_PRINT is 'N', set PRNT_TYPE to 'N' (not printed). If NB_PRINT is 'A', PRNT_TYPE remains NULL (all records, no print filter applied).
- Step 2 - Evaluate whether a from-date (NB_FRM_DATE) has been provided to determine whether the query should be unrestricted or date-bounded.
- Step 3 (No date range, Allotment type) - If NB_FRM_DATE is NULL and NB_TYPE is 'A', open IN_CURSOR with a query against ST_ALLOT, GM_CIN, and SH_ORDBOOK. Return allotment number, allotment date, and customer full name for non-cancelled allotments (ALLOT_STATUS <> 'C') that do not yet have a corresponding invoice in SH_INVOICE for the current dealer, location, company, and parent group. Filter by the current session's DEALER, LOC_CD, COMP_FA, PARENT_GROUP, and PRINCIPAL globals. Order results by ALLOT_NUM descending.
- Step 4 (No date range, Invoice type, specific print status) - If NB_FRM_DATE is NULL, NB_TYPE is 'I', and NB_PRINT is not 'A', open IN_CURSOR with a query against SH_INVOICE and SH_ORDBOOK. Return invoice number, invoice date, invoice party code, and FORM21_YN for non-cancelled invoices (INV_STATUS <> 'C') matching the resolved PRNT_TYPE (NVL(FORM21_YN,'N') = PRNT_TYPE), the selected INV_TYPE, and the current session globals. Order by INV_NUM descending.
- Step 5 (No date range, Invoice type, all print statuses) - If NB_FRM_DATE is NULL, NB_TYPE is 'I', and NB_PRINT is 'A', open IN_CURSOR with the same SH_INVOICE / SH_ORDBOOK query but without the FORM21_YN filter, returning both printed and unprinted invoices. Order by INV_NUM descending.
- Step 6 (Date range, Allotment type) - If NB_FRM_DATE is NOT NULL and NB_TYPE is 'A', repeat the allotment query from Step 3 with an additional date predicate: TRUNC(ALLOT_DATE) between NB_FRM_DATE and NVL(NB_TO_DATE, SYSDATE).
- Step 7 (Date range, Invoice type, specific print status) - If NB_FRM_DATE is NOT NULL, NB_TYPE is 'I', and NB_PRINT is not 'A', repeat the invoice query from Step 4 with an additional date predicate: TRUNC(INV_DATE) between NB_FRM_DATE and NVL(NB_TO_DATE, SYSDATE).
- Step 8 (Date range, Invoice type, all print statuses) - If NB_FRM_DATE is NOT NULL, NB_TYPE is 'I', and NB_PRINT is 'A', repeat the invoice query from Step 5 with the same date predicate applied to INV_DATE.
- Step 9 - The populated IN_CURSOR is returned to the caller (WHEN-NEW-BLOCK-INSTANCE trigger) for use in rendering the CN_MAIN block.

---
**Decision Points**

DP-001

Condition:
NB_PRINT = 'P'

TRUE:
Set PRNT_TYPE to 'Y' (invoice has been printed).

FALSE:
Evaluate DP-002.

---

DP-002

Condition:
NB_PRINT = 'N'

TRUE:
Set PRNT_TYPE to 'N' (invoice has not been printed).

FALSE:
PRNT_TYPE remains NULL; the 'All' print-status path will be used where applicable.

---

DP-003

Condition:
NB_FRM_DATE IS NULL

TRUE:
Execute the no-date-range query branch (Steps 3-5); no date predicate is applied.

FALSE:
Execute the date-range query branch (Steps 6-8); ALLOT_DATE or INV_DATE must fall between NB_FRM_DATE and NVL(NB_TO_DATE, SYSDATE).

---

DP-004

Condition:
NB_TYPE = 'A' (within either date branch)

TRUE:
Open IN_CURSOR for allotment records from ST_ALLOT joined to GM_CIN and SH_ORDBOOK, excluding allotments that already have an invoice.

FALSE:
Evaluate DP-005 for invoice-type queries.

---

DP-005

Condition:
NB_TYPE = 'I' AND NB_PRINT <> 'A' (within either date branch)

TRUE:
Open IN_CURSOR for invoices from SH_INVOICE filtered by the resolved PRNT_TYPE (printed or not-printed only).

FALSE:
NB_PRINT = 'A'; open IN_CURSOR for invoices from SH_INVOICE without a print-status filter, returning both printed and unprinted records.

---
**Database Interactions**

- DB-001 - Read ST_ALLOT - Reads data from ST_ALLOT for lookup or validation.
- DB-002 - Read SH_INVOICE - Reads data from SH_INVOICE for lookup or validation.
**Business Rules**

- BR-001 - Cancelled allotments (ALLOT_STATUS = 'C') are excluded from all allotment query results.
- BR-002 - An allotment is only presented for Form 21 processing if no invoice already exists for that allotment number within the current dealer, location, company, and parent group context; this is enforced via a NOT EXISTS subquery against SH_INVOICE.
- BR-003 - Cancelled invoices (INV_STATUS = 'C') are excluded from all invoice query results.
- BR-004 - When querying invoices with a specific print status, the FORM21_YN column is treated as 'N' when NULL (NVL(FORM21_YN,'N')), ensuring unprinted invoices with a NULL flag are correctly included in the 'Not Printed' result set.
- BR-005 - When NB_PRINT is 'A', no print-status filter is applied and both printed and unprinted invoices are returned.
- BR-006 - All queries are scoped to the current session context using the global variables DEALER, LOC_CD, COMP_FA, and PARENT_GROUP; allotment queries additionally filter by PRINCIPAL.
- BR-007 - When a date range is specified, the upper bound defaults to SYSDATE if NB_TO_DATE is not provided (NVL(NB_TO_DATE, SYSDATE)), preventing open-ended future queries.
- BR-008 - Date comparisons are performed on truncated dates (TRUNC) to exclude time components and ensure full-day inclusivity.
- BR-009 - All result sets are ordered in descending sequence by ALLOT_NUM or INV_NUM, presenting the most recent records first.

---
**Implementation Logic**

```plsql
  PROCEDURE QUERY_RECORDS (IN_CURSOR IN OUT QRY_CURSOR)
  IS
  	PRNT_TYPE VARCHAR2(1);
  BEGIN
  	IF :CB_DUMMY.NB_PRINT = 'P' THEN
			PRNT_TYPE := 'Y';
		ELSIF :CB_DUMMY.NB_PRINT = 'N' THEN
			PRNT_TYPE := 'N';
		END IF;	
		IF :CB_DUMMY.NB_FRM_DATE IS NULL THEN                    --QUERY NOT BASED ON DATE LIMIT
  		IF :CB_DUMMY.NB_TYPE = 'A' THEN                        --QUERYING FOR ALLOTED STATUS
  			OPEN IN_CURSOR FOR
  			SELECT A.ALLOT_NUM,A.ALLOT_DATE,B.FULL_NAME,NULL
				FROM ST_ALLOT A,GM_CIN B,SH_ORDBOOK C
				WHERE A.ALLOT_STATUS <> 'C'
				AND NOT EXISTS
				(SELECT ALLOT_NUM FROM SH_INVOICE
				WHERE ALLOT_NUM = A.ALLOT_NUM
				AND DEALER_MAP_CD = :GLOBAL.DEALER
				AND LOC_CD = :GLOBAL.LOC_CD
				AND COMP_FA = :GLOBAL.COMP_FA
				AND PARENT_GROUP = :GLOBAL.PARENT_GROUP)
				AND A.ORDER_NUM = C.ORDER_NUM
				AND	C.CUST_CD = B.CUST_CD
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD =A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				AND B.PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL
				ORDER BY A.ALLOT_NUM DESC;
			ELSIF :CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT <> 'A' THEN  --QUERY FOR PRINTED OR NOT PRINTED INVOICE
  			OPEN IN_CURSOR FOR
  			SELECT A.INV_NUM,A.INV_DATE,A.INV_PARTY_CD,A.FORM21_YN
				FROM SH_INVOICE A,SH_ORDBOOK C
				WHERE A.INV_STATUS <> 'C'
				AND NVL(A.FORM21_YN,'N') = PRNT_TYPE
				AND A.INV_TYPE = :CB_DUMMY.INV_TYPE
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD = A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.ORDER_NUM = C.ORDER_NUM
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				ORDER BY A.INV_NUM DESC;
  		ELSIF :CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT = 'A' THEN	  --QUERY FOR BOTH PRINTED AND NOT PRINTED INVOICE
  			OPEN IN_CURSOR FOR
  			SELECT A.INV_NUM,A.INV_DATE,A.INV_PARTY_CD,A.FORM21_YN
				FROM SH_INVOICE A,SH_ORDBOOK C
				WHERE A.INV_STATUS <> 'C'
				AND A.INV_TYPE = :CB_DUMMY.INV_TYPE
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD = A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				AND A.ORDER_NUM = C.ORDER_NUM
				ORDER BY INV_NUM DESC;
  		END IF;	
  	ELSIF :CB_DUMMY.NB_FRM_DATE IS NOT NULL THEN                       --QUERY BASED ON DATE LIMITS
  		IF :CB_DUMMY.NB_TYPE = 'A' THEN	                                 --QUERY FOR ALLOTED RECORDS
  			OPEN IN_CURSOR FOR
  			SELECT A.ALLOT_NUM,A.ALLOT_DATE,B.FULL_NAME,NULL
				FROM ST_ALLOT A,GM_CIN B,SH_ORDBOOK C
				WHERE A.ALLOT_STATUS <> 'C'
				AND NOT EXISTS
				(SELECT ALLOT_NUM FROM SH_INVOICE
				WHERE ALLOT_NUM = A.ALLOT_NUM
				AND DEALER_MAP_CD = :GLOBAL.DEALER
				AND LOC_CD = :GLOBAL.LOC_CD
				AND COMP_FA = :GLOBAL.COMP_FA
				AND PARENT_GROUP = :GLOBAL.PARENT_GROUP)
				AND (TRUNC(A.ALLOT_DATE) >= :CB_DUMMY.NB_FRM_DATE
				AND TRUNC(A.ALLOT_DATE) <= NVL(:CB_DUMMY.NB_TO_DATE,SYSDATE))
				AND A.ORDER_NUM = C.ORDER_NUM
				AND	C.CUST_CD = B.CUST_CD
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD =A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				AND B.PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL
				ORDER BY A.ALLOT_NUM DESC;
			ELSIF :CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT <> 'A' THEN    --QUERY FOR ALL PRINTED OR NOT PRINTED INVOICE
  			OPEN IN_CURSOR FOR
  			SELECT A.INV_NUM,A.INV_DATE,A.INV_PARTY_CD,A.FORM21_YN
				FROM SH_INVOICE A,SH_ORDBOOK C
				WHERE A.INV_STATUS <> 'C'
				AND (TRUNC(INV_DATE) >= :CB_DUMMY.NB_FRM_DATE
				AND TRUNC(INV_DATE) <= NVL(:CB_DUMMY.NB_TO_DATE,SYSDATE))
				AND NVL(A.FORM21_YN,'N') = PRNT_TYPE
				AND A.INV_TYPE = :CB_DUMMY.INV_TYPE
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD = A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				AND A.ORDER_NUM = C.ORDER_NUM
				ORDER BY A.INV_NUM DESC;
  		ELSIF :CB_DUMMY.NB_TYPE = 'I' AND :CB_DUMMY.NB_PRINT = 'A' THEN    --QUERY FOR BOTH PRINTED AND NOT PRINTED INVOICE
  			OPEN IN_CURSOR FOR
  			SELECT A.INV_NUM,A.INV_DATE,A.INV_PARTY_CD,A.FORM21_YN
				FROM SH_INVOICE A,SH_ORDBOOK C
				WHERE A.INV_STATUS <> 'C'
				AND A.INV_TYPE = :CB_DUMMY.INV_TYPE
				AND (TRUNC(INV_DATE) >= :CB_DUMMY.NB_FRM_DATE
				AND TRUNC(INV_DATE) <= NVL(:CB_DUMMY.NB_TO_DATE,SYSDATE))
				AND A.DEALER_MAP_CD = :GLOBAL.DEALER
				AND C.DEALER_MAP_CD = A.DEALER_MAP_CD
				AND A.LOC_CD = :GLOBAL.LOC_CD
				AND C.LOC_CD = A.LOC_CD
				AND A.COMP_FA = :GLOBAL.COMP_FA
				AND C.COMP_FA = A.COMP_FA
				AND A.PARENT_GROUP = :GLOBAL.PARENT_GROUP
				AND C.PARENT_GROUP = A.PARENT_GROUP
				AND A.ORDER_NUM = C.ORDER_NUM
				ORDER BY A.INV_NUM DESC;	
  		END IF;	
		END IF;	
  END;	
END;
```

#### SP-020 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell or system command in blocking mode, meaning the calling process waits for the command to complete before continuing. The procedure delegates execution to WEBUTIL.EXECUTE, passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-028](#SP-028--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) to be executed as an input parameter.
- Step 2 - Invoke WEBUTIL.EXECUTE, passing the command string and the BLOCKING_MODE constant as arguments.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller.

---
**Decision Points**

No conditional decision points exist within this procedure. Execution unconditionally delegates to WEBUTIL.EXECUTE with BLOCKING_MODE; all branching logic, if any, resides within WEBUTIL.EXECUTE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking (synchronous) mode; the BLOCKING_MODE constant is hardcoded and cannot be overridden by the caller.
- BR-002 - The procedure returns a PROCESS_ID, which the caller may use to reference or track the completed process initiated by WEBUTIL.EXECUTE.
- BR-003 - Command execution is fully delegated to WEBUTIL.EXECUTE; WEBUTIL.BLOCKING does not perform any pre-processing, validation, or post-processing of the command string independently.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-021 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the expected version, and downloads any missing or outdated libraries from the configured server location before registering them in the client settings store. It is invoked by WEBUTIL.REGISTERBEAN as a prerequisite step to ensure the client runtime environment is correctly provisioned.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-054](#SP-054--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-055](#SP-055--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-059](#SP-059--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter that identifies the WebUtil package whose required system libraries must be checked.
- Step 2 - Begin an iterative loop, incrementing a library counter (lib) on each pass, to process every library entry defined for the package.
- Step 3 - On each iteration, call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve the library specification using an OS-family- and architecture-specific property key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib>').
- Step 4 - If no specification is found for the architecture-specific key, call WEBUTIL.READFROMPROPERTYBUNDLE again using the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<lib>') as a fallback.
- Step 5 - If neither lookup returns a value, exit the loop; all libraries for the package have been processed.
- Step 6 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (position 1), expected file size in bytes (position 2), required version string (position 3), and a progress-display flag (position 4).
- Step 7 - Call WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>' to retrieve the version of the library currently recorded as installed on the client.
- Step 8 - Compare the installed version against the required version. If the library is absent, at the wrong version, or the REDOWNLOAD_SYSLIB flag is set, proceed to download.
- Step 9 - Resolve the download base URL by calling WEBUTIL.READFROMPROPERTYBUNDLE in order of decreasing specificity: OS-family + architecture key first, then OS-family-only key, then the generic 'install.syslib.location' key.
- Step 10 - Call WEBUTIL.DOWNLOADFROMURLINT with the fully composed URL (base URL + '/' + library file name), the library file name, the syslib install location indicator (1), the expected file size, the progress-display flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE.
- Step 11 - If the download succeeds, call WEBUTIL.SETCLIENTSETTING to record the newly installed library version under the key 'syslib.<libName>'.
- Step 12 - If the download fails, call WEBUTIL.LOG to record a failure message ('Download of system library <libName> failed') and continue to the next library in the loop.

---
**Decision Points**

DP-001

Condition: The architecture-specific property bundle lookup ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib>') returns a non-null library specification.

TRUE: Use the returned specification for the current library entry; skip the OS-family-only fallback lookup.

FALSE: Attempt the OS-family-only fallback lookup ('install.syslib.<OSFamily>.<packageID>.<lib>').

---

DP-002

Condition: The OS-family-only fallback property bundle lookup returns a non-null library specification.

TRUE: Use the returned specification for the current library entry.

FALSE: Exit the loop; no further libraries are defined for this package.

---

DP-003

Condition: The installed version recorded in client settings is null, differs from the required version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Resolve the download URL and proceed to download the library.

FALSE: The library is already installed at the correct version; skip download and advance to the next library.

---

DP-004

Condition: The architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') resolves to a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the OS-family-only download location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key ('install.syslib.location.<OSFamily>') resolves to a non-null URL.

TRUE: Use this URL as the download base.

FALSE: Use the generic download location key ('install.syslib.location') as the final fallback.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Call WEBUTIL.SETCLIENTSETTING to persist the installed library version in the client settings store.

FALSE: Call WEBUTIL.LOG to record a download failure for the named library; continue processing remaining libraries.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications must be defined in the property bundle under a hierarchical key scheme ordered by OS family and architecture; the procedure always attempts the most specific key first and falls back to less specific keys, ensuring platform-appropriate libraries are selected.
- BR-002 - A library is considered to require (re)installation if no installed version is recorded on the client, if the recorded version does not match the version specified in the property bundle, or if the REDOWNLOAD_SYSLIB override flag is active.
- BR-003 - The download base URL must be resolved from the property bundle using the same specificity hierarchy (architecture-specific -> OS-family-only -> generic); the library file name is always appended to the resolved base URL to form the full download path.
- BR-004 - On successful download, the installed version must be immediately persisted to the client settings store under the key 'syslib.<libName>' so that subsequent invocations can detect an up-to-date installation and skip unnecessary downloads.
- BR-005 - A failed library download must be logged via WEBUTIL.LOG with a severity flag of TRUE, but must not halt processing; the procedure continues to evaluate and download remaining libraries in the package.
- BR-006 - Progress dialog labels presented to the user during download must be retrieved from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE (keys INST_PGRS_TITLE and INST_PGRS_SUBTITLE), ensuring all user-facing text is internationalisation-compliant.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up callback trigger registrations that are no longer required, ensuring the collection does not retain stale entries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed from the internal m_callbacks collection.
- Step 2 - Check whether an entry with the supplied callbackKey currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection.
- Step 4 - If the entry does not exist, take no action and return silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - an entry identified by callbackKey is present in the m_callbacks collection.

TRUE: The entry is deleted from m_callbacks via m_callbacks.delete(callbackKey).

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure only attempts to delete a callback entry if it already exists in the m_callbacks collection; deletion of a non-existent key is not performed, preventing runtime errors.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER value that corresponds to a valid index in the m_callbacks collection; the procedure does not validate or transform the key prior to the existence check.
- BR-003 - Cleanup of a callback entry is a silent operation; no exception, notification, or return status is raised regardless of whether the entry was found and deleted or not found.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-023 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure acts as a thin delegation layer within the WEBUTIL package, forwarding the close request to the WebUtil_DB.CloseBlob function and returning a Boolean result indicating whether the operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the Boolean result produced by WebUtil_DB.CloseBlob to the caller (WEBUTIL.SETDATA), indicating success or failure of the close operation.

---
**Decision Points**

No decision points are present in the implementation logic. The function unconditionally delegates to WebUtil_DB.CloseBlob and returns its result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must identify a previously opened BLOB handle; the function passes this value directly to WebUtil_DB.CloseBlob without independent validation.
- BR-002 - The outcome of the close operation is determined entirely by WebUtil_DB.CloseBlob; WEBUTIL.CLOSEBLOB returns that Boolean result unchanged to the caller.
- BR-003 - This function must only be invoked from WEBUTIL.SETDATA, as that is the sole documented invocation site.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-024 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file reader object by invoking the corresponding Java method on the AppServerFileReader class. This procedure is called by WEBUTIL.SETDATA to release the file handle once file-transfer operations are complete, ensuring that server-side resources are properly freed.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing the active AppServerFileReader instance on the application server.
- Step 2 - Clear the argument list by setting args to NULL, as the closeFile Java method requires no arguments.
- Step 3 - Invoke the Java boolean method closeFile on the AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing FALSE as the static-call flag, the object reference, the fully qualified class name, the method name, and the method signature '()Z'.
- Step 4 - Return the boolean result produced by the Java method to the caller, indicating whether the file was successfully closed.

---
**Decision Points**

No conditional decision points exist within this function. The function unconditionally clears arguments and delegates the close operation to the Java layer, returning whatever boolean result the JNI call produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list must be set to NULL before invoking the Java method, as the AppServerFileReader.closeFile() method accepts no parameters.
- BR-002 - The file close operation is performed exclusively through a JNI boolean method call targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class; no direct database or file-system interaction is performed within this function.
- BR-003 - The function returns a BOOLEAN result to the caller (WEBUTIL.SETDATA), allowing the invoking logic to determine whether the server-side file handle was released successfully.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-025 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a specified URL to a client-side destination by constructing a delimited instruction string and dispatching it to the WebUtil Core bean. The function returns TRUE if the download completes successfully and FALSE if a recoverable error occurs. It supports optional progress-indicator parameters and a special destination mode to control where the file is placed on the client.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its string representation. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its string representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate the remaining fields to the submit string in order: sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null), each separated by the pipe delimiter.
- Step 7 - Send the fully assembled submit string to the WebUtil Core bean by calling WebUtil_Core.setProperty with the package constant WUC_PACKAGE, the property key 'WUC_URL_DOWNLOAD', the submit string, and the async flag set to TRUE.
- Step 8 - Retrieve the result from the WebUtil Core bean by calling WebUtil_Core.getProperty with the same package constant and property key.
- Step 9 - Return TRUE if the retrieved result equals the literal string 'TRUE'; otherwise return FALSE.
- Step 10 - On CLIENT_FILE_NULL exception, log error code 130 via WebUtil_Core.Error and return FALSE.
- Step 11 - On URL_NULL exception, log error code 25 via WebUtil_Core.Error and return FALSE.
- Step 12 - On BEAN_NOT_REGISTERED exception, display an alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE.
- Step 13 - On PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise URL_NULL exception; log error code 25 via WebUtil_Core.Error and return FALSE.
FALSE: Proceed to validate clientDestination.

DP-002

Condition: clientDestination IS NULL

TRUE: Raise CLIENT_FILE_NULL exception; log error code 130 via WebUtil_Core.Error and return FALSE.
FALSE: Proceed to build the submit string.

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append '0' to the submit string as the special destination token.
FALSE: Append the string representation of specialDestination to the submit string.

DP-004

Condition: fileSize IS NULL

TRUE: Append '0' to the submit string as the file size token.
FALSE: Append the string representation of fileSize to the submit string.

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' to the submit string, indicating no progress indicator.
FALSE: Append 'Y' to the submit string, indicating a progress indicator should be displayed.

DP-006

Condition: result (returned by WebUtil_Core.getProperty) = 'TRUE'

TRUE: Return TRUE to the caller, indicating a successful download.
FALSE: Return FALSE to the caller, indicating the download did not succeed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is an invalid invocation and causes the function to return FALSE after logging error code 25.
- BR-002 - A client destination path must be provided; a null clientDestination is an invalid invocation and causes the function to return FALSE after logging error code 130.
- BR-003 - The specialDestination value must be 0, 1, or 2; any null, negative, or out-of-range value is normalised to 0 before the download request is submitted.
- BR-004 - A null fileSize is normalised to 0 in the submit string; the bean must receive a numeric token and cannot receive a null value.
- BR-005 - Progress indicator parameters (progressTitle, progressSubTitle, progressMessage) that are null are substituted with a single space character to ensure the pipe-delimited submit string remains structurally complete.
- BR-006 - The download instruction is transmitted to the WebUtil Core bean as a single pipe-delimited string via WebUtil_Core.setProperty; the bean processes the instruction asynchronously (async flag = TRUE).
- BR-007 - If the WebUtil Core bean is not registered, the function raises FORM_TRIGGER_FAILURE after displaying an alert; the download cannot proceed without the bean.
- BR-008 - A PROPERTY_ERROR raised during bean communication results in FORM_TRIGGER_FAILURE, halting further form processing.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-026 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Formats a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then registers that message as the WUC_ERROR_MSG property on the specified WebUtil package instance via Webutil_Core.setProperty. This provides a standardised mechanism for surfacing WebUtil runtime errors back to the calling Oracle Forms session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package instance identifier (packageID), a numeric error code (code), the originating program unit name (pu_name), and up to three optional contextual arguments (arg1, arg2, arg3).
- Step 2 - Initialise the error text string by concatenating the literal prefix 'ERROR', the error code zero-padded to three digits, a pipe delimiter, and the program unit name (e.g. 'ERROR005|MY_PACKAGE').
- Step 3 - Evaluate whether arg1 is not null; if so, append a pipe delimiter followed by the value of arg1 to the error text string.
- Step 4 - Evaluate whether arg2 is not null; if so, append a pipe delimiter followed by the value of arg2 to the error text string.
- Step 5 - Evaluate whether arg3 is not null; if so, append a pipe delimiter followed by the value of arg3 to the error text string.
- Step 6 - Invoke Webutil_Core.setProperty, passing the package instance identifier, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to register the error message against the active WebUtil package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; processing continues to DP-002.

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; processing continues to DP-003.

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append a pipe delimiter and the value of arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; processing continues to Step 6.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the prefix 'ERROR' followed by the numeric error code formatted as exactly three zero-padded digits, ensuring a consistent and parseable message structure across all WebUtil error events.
- BR-002 - The program unit name (pu_name) is mandatory and must always be included in the error text immediately after the error code, separated by a pipe delimiter, to identify the origin of the error.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error text only when they carry a non-null value; null arguments are silently excluded, keeping the message free of empty pipe-delimited segments.
- BR-004 - The fully assembled error text must be stored against the property key 'WUC_ERROR_MSG' on the specified package instance using Webutil_Core.setProperty, making the error accessible to the parent invocation context (WEBUTIL_CORE.CUSTOMEVENTHANDLER).
- BR-005 - The maximum length of the assembled error text string is 1024 characters; any combination of inputs that would exceed this limit is constrained by the declared local variable size.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-027 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the end user. If a pre-configured alert object (m_errorAlert) is available, the procedure populates it with the supplied error text and presents it as a modal alert dialog. If no alert object is registered, it falls back to the Oracle Forms MESSAGE built-in. The procedure is called by WEBUTIL.FOPEN, WEBUTIL.LOG, and WEBUTIL.POPULATEPROPERTYBUNDLE to surface bean-not-registered or bean-not-found errors in a consistent manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error message text (errText) as an input parameter.
- Step 2 - Call WEBUTIL.ID_NULL (SP-045) to test whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If m_errorAlert is valid, set the ALERT_MESSAGE_TEXT property of the alert to the supplied errText value.
- Step 4 - Display the alert to the user by invoking SHOW_ALERT; the return value is captured in the local variable ignore and discarded.
- Step 5 - If m_errorAlert is not valid (ID_NULL returns TRUE), fall back to the Forms MESSAGE built-in, concatenating the literal prefix 'WebUtil Error: ' with errText to form the displayed message.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert references a valid, registered Oracle Forms alert object.

TRUE (alert handle is valid):
Set the ALERT_MESSAGE_TEXT property of m_errorAlert to errText and display the alert dialog via SHOW_ALERT; the user sees a modal alert.

FALSE (alert handle is null / not registered):
Fall back to the Forms MESSAGE built-in, displaying 'WebUtil Error: ' concatenated with errText in the standard Forms message bar.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error messages must always be surfaced to the user; the procedure must never silently suppress the supplied error text regardless of alert registration state.
- BR-002 - When a valid alert handle is available, the alert dialog is the mandatory display mechanism; the alert title is not overridden at runtime because it is already configured in the alert's design-time properties.
- BR-003 - The return value of SHOW_ALERT is intentionally ignored; no branching logic is performed based on the user's alert button selection.
- BR-004 - When no valid alert handle exists, the fallback message must be prefixed with 'WebUtil Error: ' to maintain consistent error identification across both display paths.
- BR-005 - Determination of alert handle validity is delegated exclusively to WEBUTIL.ID_NULL (SP-045); no inline null check is performed independently.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-028 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command from a Forms session by delegating to the WebUtil host-execution bean. The procedure accepts a command string and an execution mode flag, passes both to the WebUtil core layer, and returns a process handle that the caller can use to reference the spawned process. If the required WebUtil bean is not registered on the client, an error alert is raised and no process is launched.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and the execution mode (exemode) as input arguments.
- Step 2 - Evaluate whether cmd is non-null; if it is null, skip execution and return an empty PROCESS_ID record to the caller.
- Step 3 - Set the execution mode on the WebUtil host-execution package by calling WebUtil_Core.setProperty with property key WUH_EXECUTION_MODE and the supplied exemode value.
- Step 4 - Submit the command for execution by calling WebUtil_Core.setProperty with property key WUH_EXECUTE and the supplied cmd value.
- Step 5 - Retrieve the process handle assigned by the WebUtil bean by calling WebUtil_Core.getProperty with property key WUH_EXECUTE, converting the returned value to a number, and storing it in procId.handle.
- Step 6 - Return the populated PROCESS_ID record (containing the numeric process handle) to the caller.
- Step 7 - If a WebUtil_Core.BEAN_NOT_REGISTERED exception is raised at any point during Steps 3-5, display an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class and noting that WEBUTIL_HOST.Execute will not function, then exit without returning a valid process handle.

---
**Decision Points**

DP-001

Condition: cmd IS NOT NULL

TRUE: Set the execution mode property (WUH_EXECUTION_MODE) and the execute property (WUH_EXECUTE) via WebUtil_Core.setProperty, retrieve the resulting process handle via WebUtil_Core.getProperty, and populate procId.handle before returning.

FALSE: Bypass all WebUtil_Core property calls and return an unpopulated PROCESS_ID record immediately.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during WebUtil_Core property interaction

TRUE: Invoke WebUtil_Core.ErrorAlert to display a message identifying the unregistered bean class and stating that WEBUTIL_HOST.Execute will not work; procedure exits without a valid process handle.

FALSE: No exception occurs; execution completes normally and a populated PROCESS_ID record is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A host command will only be dispatched if the cmd parameter is non-null; a null command results in a no-operation return with an empty process handle.
- BR-002 - The execution mode (exemode) must be set on the WebUtil host-execution package before the command is submitted, ensuring the bean honours the correct synchronous or asynchronous execution behaviour for every invocation.
- BR-003 - The numeric process handle returned by the WebUtil bean must be captured immediately after command submission via WebUtil_Core.getProperty and stored in the PROCESS_ID record; this handle is the sole reference the caller receives for the spawned process.
- BR-004 - If the WebUtil host-execution bean is not registered on the client, the procedure must surface a descriptive error alert (identifying the missing bean class) rather than silently failing, and must not return a process handle.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-029 - WEBUTIL.FCLOSE

**Invoked From:**

- st_frm21_fmb.xml [StoredProcedure: SET_REPORT_SERVER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file represented by a FILE_TYPE handle. The procedure instructs the WebUtil core layer to release the file resource on the client machine and then nullifies the in-memory handle to prevent any subsequent access to the closed file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE parameter (file) passed IN OUT by the caller (SET_REPORT_SERVER in st_frm21_fmb.xml).
- Step 2 - Evaluate whether the file handle is currently open by checking that file.handle IS NOT NULL.
- Step 3 - If the handle is not null, invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the active handle value to instruct the WebUtil bean on the client to physically close the file.
- Step 4 - Set file.handle to NULL to invalidate the in-memory reference, ensuring the caller cannot reuse the stale handle.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during the close operation, display an error alert identifying the missing WebUtil implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR to abort processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Call WebUtil_Core.setProperty to close the file on the client and then set file.handle to NULL.

FALSE:
No action is taken; the procedure exits normally without attempting to close or modify the handle.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the FILE_TYPE handle is non-null; a null handle is treated as already closed and requires no action.
- BR-002 - After a successful close, the file handle must be set to NULL to prevent reuse of a stale client-side file reference.
- BR-003 - If the WebUtil bean required to perform the client-side file close is not registered, an error alert must be displayed to the user before the procedure raises TOOL_ERR.TOOL_ERROR.
- BR-004 - A PROPERTY_ERROR raised during the close operation must propagate as TOOL_ERR.TOOL_ERROR, halting further execution in the calling context.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-030 - WEBUTIL.FOPEN

**Invoked From:**

- st_frm21_fmb.xml [StoredProcedure: SET_REPORT_SERVER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file on behalf of the calling Oracle Forms session by delegating to the WebUtil Java bean layer. The function validates the supplied file specification and access mode, transmits the open request to the WebUtil core package via property-set/get calls, and returns a typed file handle for subsequent read, write, or append operations. If the file cannot be opened, or if the required WebUtil bean is not registered, the function raises a tool-level error and optionally surfaces a descriptive alert to the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-027](#SP-027--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-034](#SP-034--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file-open mode: confirm that the `filemode` parameter (case-insensitive) is one of the three permitted values: `r` (read), `w` (write), or `a` (append). Raise `TOOL_ERR.TOOL_ERROR` immediately if the value is outside this set.
- Step 2 - Validate the file specification: confirm that `spec` is neither NULL nor an empty string. Raise `TOOL_ERR.TOOL_ERROR` if the file name is absent.
- Step 3 - Transmit the file name to the WebUtil core layer by calling `WebUtil_Core.setProperty` with the property key `WUF_FILENAME` and the value of `spec`.
- Step 4 - Transmit the file-open mode to the WebUtil core layer by calling `WebUtil_Core.setProperty` with the property key `WUF_TEXTIO_FILEMODE` and the value of `filemode`.
- Step 5 - Transmit the character set to the WebUtil core layer by calling `WebUtil_Core.setProperty` with the property key `WUF_TEXTIO_CHARSET`. If `charSet` is NULL, the literal string `(null)` is passed; otherwise the supplied `charSet` value is passed.
- Step 6 - Trigger the actual file-open operation on the client by calling `WebUtil_Core.getProperty` with the property key `WUF_TEXTIO_OPEN`. The call returns a Java-side file handle as a VARCHAR2 string (`javaHandle`).
- Step 7 - Evaluate the returned handle: if it is NULL, empty, or equal to `-1`, the file was not opened successfully; raise `TOOL_ERR.TOOL_ERROR`.
- Step 8 - Convert the valid string handle to a numeric value, assign it to `clientFile.handle`, and return the populated `file_type` record to the caller.
- Step 9 - Exception handling: if the WebUtil bean is not registered (`BEAN_NOT_REGISTERED`), invoke `WebUtil_Core.ErrorAlert` with a message that includes the implementation class name retrieved via `WebUtil_Core.getImplClass`, then raise `TOOL_ERR.TOOL_ERROR` and return NULL. Re-raise `PROPERTY_ERROR`, `VALUE_ERROR` (as `TOOL_ERR.TOOL_ERROR`), and `TOOL_ERR.TOOL_ERROR` directly.

---
**Decision Points**

DP-001

Condition:
`LOWER(filemode)` is NOT one of `'r'`, `'w'`, or `'a'`.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR`; processing stops.

FALSE:
Continue to the file-specification validation step.

---

DP-002

Condition:
`spec` IS NULL or `spec` equals an empty string.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR`; processing stops.

FALSE:
Continue to transmit properties to the WebUtil core layer.

---

DP-003

Condition:
`charSet` IS NULL.

TRUE:
Pass the literal `'(null)'` as the `WUF_TEXTIO_CHARSET` property value.

FALSE:
Pass the actual `charSet` value as the `WUF_TEXTIO_CHARSET` property value.

---

DP-004

Condition:
`javaHandle` IS NULL, equals an empty string, or equals `'-1'`.

TRUE:
The client file was not opened; raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Convert `javaHandle` to a number, populate `clientFile.handle`, and return the file handle to the caller.

---

DP-005

Condition:
Exception `WebUtil_Core.BEAN_NOT_REGISTERED` is raised during execution.

TRUE:
Call `WebUtil_Core.ErrorAlert` with a message containing the implementation class name (retrieved via `WebUtil_Core.getImplClass`), then raise `TOOL_ERR.TOOL_ERROR` and return NULL.

FALSE:
No action under this branch; other exception handlers (`PROPERTY_ERROR`, `VALUE_ERROR`, `TOOL_ERR.TOOL_ERROR`) apply as appropriate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-open mode must be exactly one of `r`, `w`, or `a` (case-insensitive); any other value is invalid and causes immediate termination with a tool error.
- BR-002 - A non-null, non-empty file specification (`spec`) is mandatory; attempting to open a file without a name is a terminal error.
- BR-003 - When no character set is supplied by the caller, the WebUtil core layer must be explicitly informed by passing the sentinel value `(null)` as the charset property; the absence of a charset is never silently ignored.
- BR-004 - A return value of NULL, empty string, or `-1` from the WebUtil core open operation is treated as a failed file-open and must not be surfaced to the caller as a valid handle.
- BR-005 - The WebUtil Java bean must be registered in the runtime environment before `FOPEN` can succeed; if the bean is absent, the function alerts the user with the missing implementation class name (via `WEBUTIL.ERRORALERT` and `WEBUTIL.GETIMPLCLASS`) before raising a tool error.
- BR-006 - A `VALUE_ERROR` arising from the numeric conversion of the Java handle is treated as a tool-level error, ensuring that malformed handle strings do not propagate as unexpected runtime exceptions.
- BR-007 - `PROPERTY_ERROR` exceptions are re-raised without transformation, preserving the original diagnostic information for upstream error handling.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-031 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given integer key. The function provides a lookup mechanism into the internal callbacks collection, allowing callers such as WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback key at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) supplied by the calling routine.
- Step 2 - Use callbackKey as an index into the package-level collection m_callbacks to retrieve the associated trigger name string.
- Step 3 - Return the resolved trigger name VARCHAR2 value to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup into m_callbacks and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds-checking or default handling is performed within this function, so an invalid key will raise a runtime collection error.
- BR-002 - The function returns a VARCHAR2 value representing the trigger name exactly as it was stored in m_callbacks; no transformation or formatting is applied to the retrieved value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-032 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally stored client OS family code (m_clientOSFamily) to calling routines, enabling the application to determine the client platform context for conditional processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires knowledge of the client operating system family.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client OS family identifier.
- Step 3 - The stored PLS_INTEGER value representing the client OS family is returned directly to the caller.

---
**Decision Points**

No decision points are present. The function unconditionally returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns a PLS_INTEGER value; the client OS family identifier must be stored in m_clientOSFamily prior to invocation, as the function performs no population or defaulting of that variable.
- BR-002 - The function accepts no input parameters; the client OS family code is sourced exclusively from the internal module-level variable m_clientOSFamily.
- BR-003 - The function has no database interactions; the returned value is derived entirely from an in-memory variable within the WEBUTIL package.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-033 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil core bean. Given a property name, the function delegates to WebUtil_Core to set and then read the property on the WUC_PACKAGE bean, returning the resolved string value to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate local client settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input property name (propertyName) as a VARCHAR2 argument.
- Step 2 - Evaluate whether propertyName is non-null; if null, skip all processing and return a null result.
- Step 3 - Call WebUtil_Core.setProperty, targeting the WUC_PACKAGE bean with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName as the value, to request the client-side property lookup.
- Step 4 - Call WebUtil_Core.getProperty on the same WUC_PACKAGE bean and key (WUC_GET_LOCAL_PROPERTY) to retrieve the resolved property value, storing it in the local result variable.
- Step 5 - Return the result VARCHAR2 value (up to 255 characters) to the caller.
- Step 6 - If the WebUtil_Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 7 - If a property interaction error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to set the property on the WUC_PACKAGE bean via WebUtil_Core.setProperty and then retrieve it via WebUtil_Core.getProperty, storing the result for return.

FALSE: Skip the WebUtil_Core interactions entirely and return a null value to the caller.

---

DP-002

Condition: WebUtil_Core raises the BEAN_NOT_REGISTERED exception during property set or get

TRUE: Display an error alert identifying the unregistered implementation class (obtained via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to abort the calling trigger.

FALSE: Continue normal execution; no alert is raised.

---

DP-003

Condition: WebUtil_Core raises the PROPERTY_ERROR exception during property set or get

TRUE: Raise FORM_TRIGGER_FAILURE silently to abort the calling trigger without displaying an additional alert.

FALSE: Continue normal execution; result is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any WebUtil_Core interaction; the function must return null immediately, preventing erroneous bean calls with an undefined property key.
- BR-002 - The property value returned must not exceed 255 characters, as enforced by the result variable declaration (VARCHAR2(255 char)).
- BR-003 - The WebUtil core bean (WUC_PACKAGE) must be registered and available on the client before this function is called; if it is not, the form trigger must be halted via FORM_TRIGGER_FAILURE after notifying the user with an error alert that identifies the missing implementation class.
- BR-004 - Any property interaction error (PROPERTY_ERROR) must cause immediate trigger failure (FORM_TRIGGER_FAILURE) without surfacing an additional alert to the user, ensuring silent but controlled error propagation.
- BR-005 - The function is read-only with respect to the database; it must not perform any database table reads or writes, confining all interactions to the WebUtil client-side bean layer.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-034 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root path with the registered implementation class identifier for the specified package ID.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input representing a specific WebUtil package.
- Step 2 - Look up the implementation class identifier for the given packageID from the internal collection m_implClasses.
- Step 3 - Concatenate the WebUtil Java root path constant (WEBUTIL_JAVA_ROOT) with the retrieved implementation class identifier.
- Step 4 - Return the resulting fully qualified Java class name string to the caller (WEBUTIL.FOPEN).

---
**Decision Points**

No conditional decision points exist in this function. The logic executes unconditionally: it performs a direct collection lookup and string concatenation before returning the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java implementation class name is always composed by prefixing the constant WEBUTIL_JAVA_ROOT to the class identifier stored in m_implClasses at the index corresponding to packageID.
- BR-002 - The packageID supplied must correspond to a valid index within the m_implClasses collection; no bounds-checking or default handling is performed within this function.
- BR-003 - This function has no dependencies on external packages, database tables, or other stored procedures; it relies solely on package-level state (WEBUTIL_JAVA_ROOT and m_implClasses).

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-035 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. This function is called during server-side file transfer operations (specifically within WEBUTIL.SETDATA) to determine whether a preceding file-read action completed successfully or encountered a fault, allowing the calling logic to respond appropriately to error conditions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object instance (obj) as the target of the method invocation.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method getLastError() on the supplied AppServerFileReader object via JNI.CALL_INT_METHOD, targeting the class oracle/forms/webutil/fileTransfer/AppServerFileReader with method signature ()I (no arguments, returns integer).
- Step 4 - Return the integer error code produced by the Java method to the caller (WEBUTIL.SETDATA).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to the Java layer, returning whatever integer value the AppServerFileReader.getLastError() method provides.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly set to NULL before invoking the Java method to prevent unintended argument passing to the AppServerFileReader.getLastError() call.
- BR-002 - The function must target the exact Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and method signature ()I; any deviation would result in an incorrect or failed JNI invocation.
- BR-003 - The returned integer value represents the last error state of the supplied AppServerFileReader object instance; the caller (WEBUTIL.SETDATA) is responsible for interpreting and acting upon the returned error code.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-036 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates the call to the underlying Java Native Interface layer to obtain a descriptive error-argument value that can be used by the caller (WEBUTIL.SETDATA) to interrogate failure details from a server-side file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the calling routine WEBUTIL.SETDATA.
- Step 2 - Reset the local argument variable (args) to NULL to ensure no residual data from a prior call is forwarded to the Java layer.
- Step 3 - Invoke the Java method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the object reference and a NULL argument list, targeting the method signature '()Ljava/lang/String;'.
- Step 4 - Return the VARCHAR2 string result received from the Java method to the caller, representing the error-argument details from the last recorded error on the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method call and returns the result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to prevent stale argument data from being passed to the AppServerFileReader Java method.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader; the function may only retrieve error arguments from this specific class.
- BR-003 - The Java method invoked is getLastErrorArgs with the signature '()Ljava/lang/String;', meaning it accepts no Java-level arguments and always returns a String; the PL/SQL function must honour this contract by passing a NULL args list.
- BR-004 - The function returns whatever string value the Java layer provides, including NULL, without further transformation; interpretation of the returned error-argument string is the responsibility of the calling routine.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-037 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified positional index. The function delegates string extraction to WEBUTIL.GETSTRING and converts the resulting substring to a NUMBER, providing callers with a type-safe numeric value without requiring them to perform an explicit conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-041](#SP-041--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position, the optional UnTerminated flag (defaulting to FALSE), and the optional delimiter character (defaulting to a comma).
- Step 2 - Pass all four arguments unchanged to WEBUTIL.GETSTRING (SP-041), which locates and extracts the raw substring at the specified field position within the delimited source string.
- Step 3 - Apply the Oracle built-in TO_NUMBER conversion to the VARCHAR2 value returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. All branching and delimiter-parsing decisions are fully delegated to WEBUTIL.GETSTRING (SP-041); this function applies a straight-line conversion of the extracted string to a number and returns it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The delimiter parameter defaults to a comma (',') if not supplied by the caller; a different single-character delimiter may be passed to support alternative delimited formats.
- BR-002 - The UnTerminated flag defaults to FALSE; callers must explicitly pass TRUE if the source string is not terminated by a trailing delimiter, ensuring correct extraction of the final field.
- BR-003 - The raw field value extracted by WEBUTIL.GETSTRING must be implicitly convertible to a NUMBER via TO_NUMBER; if the extracted substring is non-numeric, Oracle will raise a standard VALUE_ERROR exception and processing will halt.
- BR-004 - All field-position and delimiter-parsing logic is governed exclusively by WEBUTIL.GETSTRING (SP-041); WEBUTIL.GETNUMBER imposes no additional parsing rules of its own.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-038 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string. The function maps the raw OS name to a predefined platform constant (WIN32, MAC, LINUX, SOLARIS, HP, AIX, or UNKNOWN) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluating the string. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to ensure case-insensitive matching.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all evaluation and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily is null, evaluate l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' was not matched, evaluate l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' was not matched, evaluate l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' was not matched, evaluate l_osName for the substrings 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris variant was matched, evaluate l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' was not matched, evaluate l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, persisting it as the session cache.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name evaluation (Steps 4-10) to determine and cache the platform family.

FALSE: Skip all string evaluation and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next OS family check (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next OS family check (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next OS family check (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next OS family check (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next OS family check (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no further OS checks are performed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison must be case-insensitive; the input string is converted to lowercase before any substring evaluation is performed.
- BR-002 - Platform classification is evaluated as a mutually exclusive, ordered set of conditions; the first matching OS family terminates further evaluation.
- BR-003 - Solaris is recognised by either of two substrings ('solaris' or 'sunos'); both must be checked within the same decision branch.
- BR-004 - If the OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default classification.
- BR-005 - The resolved platform value is cached in the module-level variable m_clientOSFamily after the first successful evaluation; all subsequent calls within the same session return the cached value without re-evaluating the OS name string.
- BR-006 - The function produces no side effects beyond populating the module-level cache variable m_clientOSFamily; it performs no database reads or writes.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-039 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a client-side process by repeatedly polling the WebUtil host bean via WebUtil_Core property calls. Given a process handle and a property identifier, the function accumulates output lines into an array and returns the complete collection to the caller (WEBUTIL.GET_STANDARD_OUTPUT). It also ensures the WebUtil Core component is initialised before any property interaction takes place.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-046](#SP-046--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) and the output property name (VARCHAR2) as inputs.
- Step 2 - Invoke Webutil_Core.Init (via the package initialisation block) to ensure the WebUtil Core component is instantiated before any property calls are made.
- Step 3 - Set the process handle on the WebUtil host package by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key WUH_PROC_ID, and the process handle value.
- Step 4 - Enter a loop: call WebUtil_Core.getProperty with WUH_PACKAGE and the supplied property name to retrieve the next buffered output line.
- Step 5 - Extract the first character of the returned buffer as a status indicator ('Y' = more lines follow, 'N' = last line, 'X' = buffer empty).
- Step 6 - If the status is not 'X' (i.e., the buffer contains data), append the remainder of the buffer (characters from position 2 onward) to the output array and increment the array index.
- Step 7 - Exit the loop when the status is not 'Y' (i.e., the last line has been read or the buffer was empty).
- Step 8 - Return the populated OUTPUT_ARRAY to the caller.
- Step 9 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and indicating that WEBUTIL_HOST.GetOutput will not function.

---
**Decision Points**

DP-001

Condition: The first character of the buffer returned by WebUtil_Core.getProperty is not 'X'.

TRUE: The buffer contains a valid output line; the substring from position 2 is stored in the output array and the index is incremented.

FALSE: The buffer is empty; no data is added to the output array and the loop exit condition is evaluated.

DP-002

Condition: The status character extracted from the buffer is 'Y'.

TRUE: More output lines are expected; the loop continues and WebUtil_Core.getProperty is called again for the next line.

FALSE: The status is 'N' (last line) or 'X' (empty buffer); the loop exits and the accumulated array is returned.

DP-003

Condition: A BEAN_NOT_REGISTERED exception is raised during execution.

TRUE: An error alert is displayed identifying the unregistered bean class and stating that WEBUTIL_HOST.GetOutput will not work; no array is returned.

FALSE: No exception occurs; normal processing continues and the output array is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil Core component must be initialised (via Webutil_Core.Init in the package initialisation block) before any property get or set operation is attempted.
- BR-002 - The process handle must be registered with the WebUtil host package by setting the WUH_PROC_ID property before output lines are retrieved, ensuring the correct process context is active.
- BR-003 - Each value returned by WebUtil_Core.getProperty is a prefixed string; the first character is exclusively reserved as a status flag ('Y', 'N', or 'X') and must be stripped before the content is stored.
- BR-004 - Only buffer values with a status of 'Y' or 'N' (non-empty) are appended to the output array; an 'X' status indicates an empty buffer and is discarded without incrementing the array index.
- BR-005 - The retrieval loop must continue until a status other than 'Y' is received, guaranteeing that all available output lines are collected before the function returns.
- BR-006 - If the required WebUtil host bean is not registered on the client, the function must raise a user-visible error alert and halt processing rather than returning a partial or empty array silently.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-040 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Given a property key, the function calls the standard Java method java.lang.System.getProperty and returns the corresponding string value to the caller. It is used internally by WEBUTIL routines (FOPEN, REGISTERBEAN) that require environment or platform information available through JVM system properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property key string (a0) that identifies the Java system property to be retrieved.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1), storing the handle in the shared args variable.
- Step 3 - Add the property key (a0) to the argument list as a string argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java static method java.lang.System.getProperty through JNI.CALL_STRING_METHOD, passing the class path 'java/lang/System', method name 'getProperty', and the JNI method descriptor '(Ljava/lang/String;)Ljava/lang/String;' along with the prepared argument list.
- Step 5 - Return the string value produced by JNI.CALL_STRING_METHOD directly to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls and unconditionally returns the result of the Java system property lookup.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key supplied in parameter a0 must be a valid Java system property name; the JNI layer delegates resolution entirely to java.lang.System.getProperty, which returns NULL if the property does not exist.
- BR-002 - Exactly one string argument must be registered in the JNI argument list before the Java method is invoked; the argument list is always created with a capacity of 1.
- BR-003 - The function performs no database interaction and has no internal Oracle Forms dependencies; all processing is handled through the JNI bridge to the JVM.
- BR-004 - The function is intended for internal WEBUTIL use and is invoked only by other WEBUTIL stored procedures (FOPEN, REGISTERBEAN); direct external invocation is not part of the defined usage pattern.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-041 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts and returns a single delimited field from a source string based on its positional index. Given a delimiter-separated string, the function locates the Nth field (as specified by Field_position) and returns its value as a VARCHAR2. It is used internally within the WEBUTIL package, notably invoked by WEBUTIL.GETNUMBER, to parse positional tokens from structured string data.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position (1-based), an optional UnTerminated flag (default FALSE), and an optional delimiter (default comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid mutating the original input.
- Step 3 - If the UnTerminated flag is TRUE, append the delimiter to the end of the working copy to ensure the final field is bounded and parseable by the same logic used for all other fields.
- Step 4 - Determine the start pointer (iPtrStart): if Field_position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence number Field_position - 1) and advance the pointer past the delimiter; otherwise set iPtrStart to 1 (the beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the Nth occurrence of the delimiter in the working copy, where N equals Field_position.
- Step 6 - Extract and return the substring between iPtrStart and iPtrEnd (exclusive), representing the content of the requested field.

---
**Decision Points**

DP-001

Condition: UnTerminated = TRUE

TRUE: The delimiter is appended to the end of the working copy of the source string (vcSourceStrCopy || Delimiter) so that the last field is properly terminated and can be located using the same instr/substr logic applied to all other fields.

FALSE: The source string is used as-is; no modification is made to vcSourceStrCopy before parsing begins.

---

DP-002

Condition: Field_position > 1

TRUE: iPtrStart is calculated by finding the (Field_position - 1)th occurrence of the delimiter in the working string and advancing past it by the length of the delimiter, positioning the pointer at the first character of the target field.

FALSE: iPtrStart is set to 1, meaning the target field begins at the very start of the source string (i.e., the first field is being requested).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field positions are 1-based; a Field_position value of 1 targets the first delimited token in the source string.
- BR-002 - The default delimiter is a comma (','). A caller may supply an alternative single- or multi-character delimiter to support non-standard string formats.
- BR-003 - If the source string does not end with the delimiter and the last field is to be extracted, the caller must pass UnTerminated = TRUE so that the function appends the delimiter and correctly bounds the final token.
- BR-004 - The function operates on strings up to 32,000 characters in length, as enforced by the internal working variable declaration (varchar2(32000)).
- BR-005 - The function performs no database interactions; all processing is purely in-memory string manipulation.
- BR-006 - The returned value is derived exclusively via SUBSTR on the working copy; no dependency on WEBUTIL.LENGTH is exercised within this function's own logic - WEBUTIL.LENGTH is a package-level dependency available to the broader WEBUTIL package context.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-042 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.GETVAR retrieves the value of a named configuration or environment variable from the client machine. The resolution strategy is platform-dependent: on Windows clients the procedure first queries the Oracle registry key (HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE) and falls back to the Windows environment string if the registry lookup returns no value; on Unix/Linux clients it executes the 'env' command, captures its output, and parses the result to locate the requested variable; on macOS and unknown platforms no action is taken and the output value remains unchanged. The procedure is invoked during bean registration to supply runtime environment context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-070](#SP-070--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-071](#SP-071--READ_REGISTRY)) - matched by member name
- WEBUTIL.BLOCKING ([SP-020](#SP-020--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTOSFAMILY ([SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-044](#SP-044--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-058](#SP-058--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the variable name (VARNAME) and the current value holder (VARVALUE) as input parameters.
- Step 2 - Determine the client operating-system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 3 - If the client OS family is Windows (CLIENT_PLATFORM_WIN32), attempt to read the variable value from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY, passing VARNAME as the registry value name.
- Step 4 - If the registry lookup returns NULL or an empty string, fall back to retrieving the variable from the Windows environment block using GET_ENVIRONMENT_STRING with VARNAME.
- Step 5 - If the client OS family is macOS (CLIENT_PLATFORM_MAC) or unknown (CLIENT_PLATFORM_UNKNOWN), take no action; VARVALUE is left unchanged.
- Step 6 - For all other OS families (Unix/Linux), execute the shell command 'env' as a blocking host process via WEBUTIL.BLOCKING, capturing the process handle.
- Step 7 - Retrieve the full standard output of the 'env' command as an array using WEBUTIL.GET_STANDARD_OUTPUT.
- Step 8 - Release the host process handle using WEBUTIL.RELEASE_PROCESS.
- Step 9 - Iterate over each line of the captured output; for each line, locate the '=' delimiter using INSTR.
- Step 10 - Extract the key portion (left of '=') and compare it to VARNAME; if a match is found, extract the value portion (right of '=') into VARVALUE and exit the loop.
- Step 11 - If a NO_DATA_FOUND exception is raised at any point during processing, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition: Client OS family equals CLIENT_PLATFORM_WIN32.

TRUE: Attempt registry lookup under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE for VARNAME via READ_REGISTRY; proceed to DP-002.

FALSE: Proceed to DP-003.

---

DP-002

Condition: The value returned by READ_REGISTRY is NULL or empty string.

TRUE: Fall back to retrieving VARVALUE from the Windows environment block using GET_ENVIRONMENT_STRING.

FALSE: Use the registry-returned value as VARVALUE; no further lookup is performed.

---

DP-003

Condition: Client OS family is CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE: Take no action; VARVALUE remains unchanged.

FALSE: Treat the client as a Unix/Linux platform; execute the 'env' command via WEBUTIL.BLOCKING and parse its output.

---

DP-004

Condition: A '=' delimiter is found (INSTR result > 0) in the current line of the 'env' output.

TRUE: Extract the key and compare it to VARNAME; proceed to DP-005.

FALSE: Skip the current line and continue iterating.

---

DP-005

Condition: The extracted key from the current 'env' output line equals VARNAME.

TRUE: Assign the substring after '=' to VARVALUE and exit the loop.

FALSE: Continue iterating to the next output line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows registry lookup is always attempted before the environment-string fallback; the environment string is only consulted when the registry returns no value for the requested variable name.
- BR-002 - The registry search on Windows is scoped exclusively to HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE; no other registry hive or path is queried.
- BR-003 - On macOS and unknown client platforms, GETVAR performs no lookup and returns VARVALUE unmodified; callers must not rely on a resolved value for these platforms.
- BR-004 - On Unix/Linux platforms, environment variable resolution is performed by executing the 'env' command as a blocking host process; the process handle must be released via WEBUTIL.RELEASE_PROCESS immediately after the output is captured, regardless of whether VARNAME is found.
- BR-005 - Unix/Linux parsing treats the first '=' character in each output line as the key-value delimiter; only the portion left of the first '=' is compared against VARNAME, and only the portion right of it is assigned to VARVALUE.
- BR-006 - A NO_DATA_FOUND exception at any stage of execution is handled gracefully by setting VARVALUE to NULL; no exception is propagated to the caller.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-043 - WEBUTIL.GET_LINE

**Invoked From:**

- st_frm21_fmb.xml [StoredProcedure: SET_REPORT_SERVER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open client-side text file and returns it to the caller. The procedure delegates the physical read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, then interprets the returned buffer to distinguish a valid (possibly empty) line from an end-of-file condition. It is invoked indirectly through SET_REPORT_SERVER in st_frm21_fmb.xml.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the open file handle (file_type) passed in by the caller and declare a local VARCHAR2 buffer to hold the raw line content.
- Step 2 - Pass the file handle to the WebUtil PJC by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the next line of text from the PJC by reading the WUF_TEXTIO_GETLINE property via WebUtil_Core.getProperty; the result is stored in the local buffer.
- Step 4 - Evaluate the buffer content: if the buffer equals CHR(10) (a lone newline character), the PJC has signalled end-of-file using its agreed convention, so raise NO_DATA_FOUND to inform the caller that no more data is available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer value to the OUT parameter item and return normally to the caller.
- Step 6 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERROR to halt processing.
- Step 7 - If a property read/write error occurs (PROPERTY_ERROR exception), raise TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition:
The value returned from the PJC into the local buffer equals CHR(10) (a lone newline character).

TRUE:
The end-of-file convention has been triggered; raise NO_DATA_FOUND to signal the caller that there are no more lines to read.

FALSE:
The buffer contains a valid line of text (including the case of a genuinely empty line); assign the buffer to the OUT parameter item and return normally.

---

DP-002

Condition:
The BEAN_NOT_REGISTERED exception is raised during property set or get operations.

TRUE:
Display an error alert identifying the missing WebUtil implementation class, then raise TOOL_ERROR to abort the calling process.

FALSE:
No bean registration error; continue with normal processing or handle other exceptions.

---

DP-003

Condition:
The PROPERTY_ERROR exception is raised during property set or get operations.

TRUE:
Raise TOOL_ERROR immediately to abort the calling process without displaying an additional alert.

FALSE:
No property error; continue with normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle supplied to GET_LINE must already be open; the procedure does not open or validate the file itself - that responsibility belongs to the caller.
- BR-002 - End-of-file is communicated by the PJC by placing a lone CHR(10) newline into the buffer; GET_LINE must treat this sentinel value exclusively as an end-of-file signal and never return it as line content.
- BR-003 - A genuinely empty line read from the file is represented by an empty string in the buffer (not CHR(10)) and must be returned as-is to the caller via the OUT parameter item.
- BR-004 - If the WebUtil PJC bean is not registered in the client JVM, processing must be halted via TOOL_ERROR after presenting a descriptive error alert; the procedure must not silently fail or return partial data.
- BR-005 - Any PROPERTY_ERROR raised during the WebUtil_Core property interaction must cause an immediate TOOL_ERROR raise; no partial result may be returned to the caller in this scenario.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-044 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream captured from a previously executed host process. The function acts as a typed convenience wrapper that delegates to WEBUTIL.GETOUTPUT, passing the fixed stream identifier 'WUH_STDOUT' to isolate standard output from other output streams associated with the given process handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-039](#SP-039--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) that identifies the host process whose standard output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-039), passing the supplied process handle and the hard-coded stream identifier 'WUH_STDOUT' to target the standard output channel specifically.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller without further transformation.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single unconditional path: delegate to WEBUTIL.GETOUTPUT with the fixed stream identifier 'WUH_STDOUT' and return its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; this value is hard-coded and cannot be overridden by the caller, ensuring that this function exclusively returns standard output content.
- BR-002 - The function returns an OUTPUT_ARRAY; the structure and content of that array are governed entirely by WEBUTIL.GETOUTPUT (SP-039) for the given process handle.
- BR-003 - The caller must supply a valid PROCESS_ID; no null-check or validation is performed within this function, so responsibility for providing a meaningful process handle rests with the invoking routine.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-045 - WEBUTIL.ID_NULL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle pointer is uninitialised (null). The function provides a standardised null-check utility used by multiple WEBUTIL routines to guard against operations on invalid or unset handle references before proceeding with further processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the incoming Pointer argument (handle) passed by the calling routine.
- Step 2 - Inspect the internal handle identifier (handle.hnd) to determine whether it holds a null value.
- Step 3 - Return TRUE to the caller if handle.hnd is null, indicating the handle is uninitialised.
- Step 4 - Return FALSE to the caller if handle.hnd is not null, indicating the handle references a valid object.

---
**Decision Points**

DP-001

Condition:
handle.hnd IS NULL

TRUE:
The function returns TRUE, signalling to the caller that the supplied handle is uninitialised and should not be used for further operations.

FALSE:
The function returns FALSE, signalling to the caller that the supplied handle is valid and may be used safely.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal hnd attribute; no additional attributes or external state are evaluated.
- BR-002 - The function must return a BOOLEAN result in all code paths; no exception or default value is permitted as a substitute for an explicit TRUE/FALSE return.
- BR-003 - Calling routines (WEBUTIL.ERRORALERT, WEBUTIL.INITWEBUTIL, WEBUTIL.REGISTER_FUNCTION, WEBUTIL.SHOWBEANS) are responsible for acting on the returned BOOLEAN; ID_NULL itself takes no corrective action on a null handle.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-046 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core library. Although the procedure body performs no explicit processing steps (it executes a null statement), its invocation causes the PL/SQL package to be instantiated in the session, which in turn triggers the package initialisation block that calls WEBUTIL.INITWEBUTIL to set up the WebUtil runtime environment.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-047](#SP-047--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.GETOUTPUT invokes WEBUTIL.INIT to ensure the WebUtil package is loaded into the current session.
- Step 2 - The INIT procedure body executes a null statement; no explicit processing is performed within the procedure itself.
- Step 3 - Entry into the package causes the package initialisation block (BEGIN...END WEBUTIL_CORE) to execute automatically, invoking WEBUTIL.INITWEBUTIL (SP-047) to initialise the WebUtil runtime utility.

---
**Decision Points**

No decision points exist within WEBUTIL.INIT. The procedure contains no conditional logic; it unconditionally executes a null statement and relies entirely on the package initialisation block for its side-effect.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The act of entering (instantiating) the WEBUTIL package within a session is sufficient to trigger initialisation; no explicit setup calls are required inside the INIT procedure body.
- BR-002 - WEBUTIL.INITWEBUTIL (SP-047) must be present and executable as it is called unconditionally by the package initialisation block every time the package is first loaded into a session.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-047 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form by registering the implementation class names for all known WebUtil packages, verifying that the required WebUtil object group (including its error alert and dummy item) is present in the form, optionally navigating to and rendering the bean areas, and determining the server-side file-path separator based on the host operating system. This procedure must complete successfully before any other WebUtil functionality can be used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-062](#SP-062--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) to serve as reference points for subsequent navigation.
- Step 2 - Populate the package implementation-class registry (m_implClasses) by assigning the fully qualified Java bean class name to each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL). WUU_PACKAGE is registered with an empty string, indicating no backing class.
- Step 3 - Check whether the WebUtil error alert object (m_errorAlert) is null by calling WEBUTIL.ID_NULL. If it is null, the WebUtil object group is absent from the form.
- Step 4 - If the error alert is absent, display a message informing the user that the WEBUTIL object group is not available and the framework cannot operate, then pause execution. No further initialisation is performed.
- Step 5 - If the error alert is present, evaluate whether explicit bean instantiation is required: the FLAG_EXPICIT_INSTANCIATE flag must be TRUE and the form must be in NORMAL mode (SYSTEM.MODE = 'NORMAL').
- Step 6 - When both conditions in Step 5 are met, call WEBUTIL.ID_NULL to test whether the dummy item (hDummy) exists.
- Step 7 - If the dummy item exists, navigate to it via GO_ITEM(hDummy). Compare the block of the original cursor position with the block of the dummy item: if they are the same block, move to the next block (NEXT_BLOCK); otherwise return focus to the original cursor position (GO_ITEM(startPoint)).
- Step 8 - After navigation in Step 7, call WEBUTIL.SHOWBEANS(false) to render the bean areas without forcing a repaint.
- Step 9 - If the dummy item does not exist (Step 6 is FALSE), take no action, assuming the developer manages bean area setup independently.
- Step 10 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) is TRUE - the WebUtil error alert object is not found in the form.

TRUE: Display an error message stating that the WEBUTIL object group is unavailable and WebUtil cannot operate, then pause. Initialisation is aborted; Steps 5-9 are skipped.

FALSE: The WebUtil object group is present; proceed with conditional bean instantiation (Steps 5-9).

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Attempt to navigate to the dummy item and render bean areas (proceed to DP-003).

FALSE: Skip bean navigation and rendering entirely; proceed directly to server OS detection (Step 10).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) is FALSE - the standard WebUtil dummy item exists in the form.

TRUE: Navigate to the dummy item, resolve block context to determine whether to move to the next block or return to the original cursor field, then call WEBUTIL.SHOWBEANS(false).

FALSE: Take no action; the developer is assumed to be managing bean area setup independently.

---

DP-004

Condition: After navigation to the dummy item, the block of the original cursor field equals the block of the dummy item.

TRUE: Call NEXT_BLOCK to move focus away from the dummy item's block.

FALSE: Call GO_ITEM(startPoint) to return focus to the original cursor position.

---

DP-005

Condition: The value returned by GET_APPLICATION_PROPERTY(OPERATING_SYSTEM) contains the string 'WIN' (case-insensitive).

TRUE: Set the server file-path separator (m_serverFileSep) to backslash ('\').

FALSE: Set the server file-path separator (m_serverFileSep) to forward slash ('/').

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert object, must be present in the calling form before WebUtil initialisation can proceed; absence of the error alert is treated as a fatal configuration error that prevents all further WebUtil operations.
- BR-002 - All ten WebUtil package constants must be mapped to their corresponding Java bean implementation class names during initialisation; WUU_PACKAGE is intentionally registered with an empty string, indicating it has no backing Java class.
- BR-003 - Bean area navigation and rendering are performed only when the FLAG_EXPICIT_INSTANCIATE flag is enabled and the form is in NORMAL mode; Enter-Query mode must not trigger bean navigation to avoid known form-navigation conflicts.
- BR-004 - When the standard WebUtil dummy item is present and bean instantiation is required, focus must be moved to the dummy item's block before calling WEBUTIL.SHOWBEANS; if the original cursor was already in that block, NEXT_BLOCK is used to avoid leaving focus on the dummy item.
- BR-005 - After bean rendering, focus must be returned to the developer's original cursor position (startPoint) unless a block change via NEXT_BLOCK was sufficient to resolve the navigation context.
- BR-006 - If the dummy item is not found, the framework assumes the developer has implemented custom bean area management and takes no navigation or rendering action.
- BR-007 - The server file-path separator must be determined at initialisation time based on the host operating system and stored in m_serverFileSep; Windows-based servers use a backslash separator and all other platforms use a forward slash.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-048 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal module-level variable `m_lastError` and returns TRUE if a non-zero error code is held, allowing callers such as WEBUTIL.LOG to branch their processing based on the current error state.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the current value of the module-level variable `m_lastError`, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition is active.
- Step 3 - Return TRUE if `m_lastError` is not equal to zero (an error exists), or FALSE if `m_lastError` equals zero (no error).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, signalling to the caller that the last WebUtil operation encountered an error.

FALSE: The function returns FALSE, signalling to the caller that no error is currently recorded for the last WebUtil operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function is read-only; it inspects `m_lastError` without modifying it, ensuring that error-state interrogation does not alter the recorded error condition.
- BR-002 - Any non-zero value of `m_lastError` is treated as an error regardless of its specific numeric value; zero is the sole value that represents a successful (no-error) state.
- BR-003 - The function accepts no input parameters; the error state is derived exclusively from the module-level variable `m_lastError` at the time of invocation.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-049 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to verify file state before attempting file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as an IN parameter.
- Step 2 - Inspect the HANDLE attribute of the FILE_TYPE record to determine whether a valid file handle exists.
- Step 3 - If the HANDLE attribute is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the HANDLE attribute is NOT NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The file handle does not exist; the function returns FALSE, signalling that the file is not open.

FALSE: The file handle exists; the function returns TRUE, signalling that the file is open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its HANDLE attribute is NOT NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs a read-only inspection of the FILE_TYPE record and does not alter the file state or the record itself.
- BR-003 - The function returns a BOOLEAN result; callers must evaluate this result before performing any file operations to avoid operations on an invalid file handle.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-050 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. The function delegates to the native Java method java.io.File.length() via the JNI bridge, providing Oracle Forms PL/SQL routines with a way to determine the size of a file on the client or server file system without direct database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object (obj) that represents the target file whose size is to be determined.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the Java instance method java.io.File.length() on the supplied object via JNI.CALL_LONG_METHOD, passing FALSE (non-static call), the target object, the class path 'java/io/File', the method name 'length', and the descriptor '()J' (no parameters, returns a long).
- Step 4 - Return the numeric result received from the JNI call, representing the file size in bytes, to the calling routine.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method call and returns its result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid ORA_JAVA.JOBJECT reference representing a java.io.File instance; the correctness of the returned byte count depends entirely on the validity of this object.
- BR-002 - The JNI argument list (args) must be reset to NULL before each call to java.io.File.length() to prevent argument contamination from prior JNI invocations.
- BR-003 - The file length is retrieved using the Java long method signature '()J', meaning the return value is treated as a long integer and mapped to an Oracle NUMBER; callers must handle the case where the file does not exist or is inaccessible, as java.io.File.length() returns 0 in those scenarios.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-051 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side log file on behalf of the WebUtil framework. On first invocation it initialises a module-level logging configuration cache by reading three property-bundle settings (logging enabled flag, errors-only flag, and log file path). Subsequent calls use the cached settings to append formatted message lines to the designated log file, optionally prefixing each line with the client IP address and username. The procedure also communicates the active logging mode to any registered WebUtil bean via a WUC_SRV_LOGGING property and raises user-visible alerts when the log file is misconfigured or unwritable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-027](#SP-027--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-048](#SP-048--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-049](#SP-049--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-053](#SP-053--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-054](#SP-054--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - On the first call (m_loggingAllowed IS NULL), initialise the logging configuration cache: read 'logging.enabled', 'logging.errorsonly', and 'logging.file' from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and store the results in module-level variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile.
- Step 2 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE). If no WebUtil bean is registered yet, surface error WUC-008 to the user via WEBUTIL.ERRORALERT; otherwise push the disabled state (WUC_SRV_LOGGING = '0') to the bean and raise the structured error through WebUtil_Core.
- Step 3 - If at least one bean is registered, synchronise the bean's WUC_SRV_LOGGING property to reflect the resolved logging mode: '1' for errors-only, '2' for full logging, or '0' for disabled.
- Step 4 - After the cache is initialised (or on all subsequent calls), check whether logging is currently allowed. If not, exit without writing.
- Step 5 - If logging is allowed, evaluate whether the current message qualifies for writing: write unconditionally when errors-only mode is off, or write only when isError = TRUE when errors-only mode is on.
- Step 6 - Open the log file in append mode using TEXT_IO.FOPEN. Verify the file handle is open via WEBUTIL.IS_OPEN; if it is not, raise NO_DATA_FOUND to trigger the exception handler.
- Step 7 - Write the message line via WEBUTIL.PUT_LINE. If m_clientIP is populated, prefix the line with the client IP address and username in the format '<IP>:<username>: <msg>'; otherwise write the bare message.
- Step 8 - Close the log file with TEXT_IO.FCLOSE.
- Step 9 - In the WHEN OTHERS exception handler, check SQLCODE. If it equals -302000 (file write failure), disable logging permanently (m_loggingAllowed := FALSE) and notify the caller: if no bean is registered, raise alert WUC-007 via WEBUTIL.ERRORALERT; otherwise push WUC_SRV_LOGGING = '0' to the bean and raise the structured error. For any other SQLCODE, re-raise the exception.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging configuration cache has not yet been populated).
TRUE: Read 'logging.enabled', 'logging.errorsonly', and 'logging.file' from the property bundle and populate the module-level cache variables before proceeding.
FALSE: Skip cache initialisation and proceed directly to the write phase using the already-cached values.

DP-002
Condition: m_loggingAllowed = TRUE and m_loggingFile IS NULL (logging is requested but no file path was configured).
TRUE: Set m_loggingAllowed to FALSE to disable logging. Branch to DP-003 to determine how to report the misconfiguration error.
FALSE: Retain the current m_loggingAllowed value and continue.

DP-003
Condition: m_registeredPackages.FIRST IS NULL (no WebUtil bean is registered yet) - evaluated when reporting a missing log file (DP-002 TRUE path).
TRUE: Call WEBUTIL.ERRORALERT with message 'WUC-008: Server side logging was requested but no log file was specified - logging is disabled'.
FALSE: Push WUC_SRV_LOGGING = '0' to the registered bean via WebUtil_Core.setProperty and raise the structured error via WebUtil_Core.error.

DP-004
Condition: m_registeredPackages.FIRST IS NOT NULL (at least one bean is registered) - evaluated after the file-path check during cache initialisation.
TRUE: Set the bean's WUC_SRV_LOGGING property: '1' if logging is allowed and errors-only, '2' if logging is allowed and not errors-only, '0' if logging is disabled.
FALSE: Skip bean property synchronisation.

DP-005
Condition: m_loggingAllowed = TRUE - evaluated at the start of the write phase.
TRUE: Proceed to evaluate whether the message qualifies for writing (DP-006).
FALSE: Exit the procedure without writing anything.

DP-006
Condition: m_loggingErrorsOnly = FALSE OR (m_loggingErrorsOnly = TRUE AND isError = TRUE).
TRUE: Open the log file and write the message.
FALSE: Skip writing this message.

DP-007
Condition: TEXT_IO.IS_OPEN(logFile) returns TRUE after the FOPEN call.
TRUE: Proceed to write the message line.
FALSE: Raise NO_DATA_FOUND to trigger the exception handler.

DP-008
Condition: m_clientIP IS NULL - evaluated immediately before writing the message line.
TRUE: Write the bare message text to the log file.
FALSE: Prefix the message with '<m_clientIP>:<m_clientUserName>: ' before writing.

DP-009
Condition: SQLCODE = -302000 in the WHEN OTHERS exception handler (file write failure).
TRUE: Disable logging (m_loggingAllowed := FALSE) and report error WUC-007 via WEBUTIL.ERRORALERT (if no bean registered) or via WebUtil_Core (if a bean is registered).
FALSE: Re-raise the original exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, log file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in module-level variables; subsequent calls reuse the cache without re-reading the bundle.
- BR-002 - If logging is enabled but the 'logging.file' property returns no value, logging must be disabled immediately; an empty or null log file path is not a valid logging configuration.
- BR-003 - When errors-only mode is active (m_loggingErrorsOnly = TRUE), only messages passed with isError = TRUE are written to the log file; informational messages are silently discarded.
- BR-004 - The log file is always opened in append mode ('A'), preserving previously written entries across multiple invocations.
- BR-005 - If a client IP address is available (m_clientIP IS NOT NULL), every log line must be prefixed with the client IP and username to support auditability and traceability of log entries to specific client sessions.
- BR-006 - The WUC_SRV_LOGGING bean property must reflect the active logging mode: '0' = disabled, '1' = errors only, '2' = full logging; this property is set during cache initialisation whenever a bean is registered.
- BR-007 - A file write failure (SQLCODE -302000) permanently disables logging for the session (m_loggingAllowed := FALSE) and triggers error WUC-007; logging is not retried after such a failure.
- BR-008 - Error reporting when no bean is registered must use WEBUTIL.ERRORALERT to present the error message directly to the user in plain English; the structured WebUtil_Core error mechanism is used only when at least one bean is registered.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-052 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order-a Forms global variable, an environment variable, and a Forms parameter-ensuring the property bundle is populated before any dependent routine attempts to read configuration values.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-027](#SP-027--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to resolve the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global variable is unset, query the operating-system environment using TOOL_ENV.GETVAR with the key WEBUTIL_CONFIG_ENV to obtain the file path.
- Step 3 - If the environment variable also yields no value, fall back to the Forms parameter identified by WEBUTIL_CONFIG_PARAM to obtain the file path.
- Step 4 - If all three sources fail to provide a path, raise NO_DATA_FOUND to trigger the error-handling branch.
- Step 5 - Persist the resolved configuration file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL for reuse by subsequent calls.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For each non-comment line, locate the '=' delimiter using INSTR; skip lines that do not contain a delimiter.
- Step 10 - For lines containing a valid key-value pair, increment the property bundle index, then store the trimmed, lowercased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 11 - Compare the stored key (lowercased) against the lowercased input propertyKey; if they match, capture the corresponding value into the result variable.
- Step 12 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE.
- Step 13 - Return the result value (the matching property value, or NULL if the key was not found in the file).

---
**Decision Points**

DP-001

Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains a value other than '[NOTSET]'.

TRUE: Use the global variable value as the configuration file path and skip environment and parameter lookups.

FALSE: Proceed to check the environment variable WEBUTIL_CONFIG_ENV.

---

DP-002

Condition: The environment variable WEBUTIL_CONFIG_ENV yields a non-null configuration file path.

TRUE: Use the environment variable value as the configuration file path and skip the Forms parameter lookup.

FALSE: Proceed to check the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition: The Forms parameter WEBUTIL_CONFIG_PARAM yields a non-null configuration file path.

TRUE: Use the parameter value as the configuration file path.

FALSE: Raise NO_DATA_FOUND, triggering the no-configuration-file error path.

---

DP-004

Condition: The first character of the current line read from the file is '#'.

TRUE: Skip the line entirely (treated as a comment).

FALSE: Proceed to evaluate the line for a key-value pair.

---

DP-005

Condition: The current non-comment line contains an '=' character (pos > 0).

TRUE: Parse the line into a key-value pair and store it in m_propertyBundle.

FALSE: Skip the line (no valid key-value pair present).

---

DP-006

Condition: The parsed and lowercased property key matches the lowercased input propertyKey.

TRUE: Assign the corresponding property value to the result variable for return.

FALSE: Continue processing remaining lines without updating the result variable.

---

DP-007

Condition: A NO_DATA_FOUND exception is raised (no configuration file path could be resolved) and m_registeredPackages.FIRST is null (no WebUtil bean registered yet).

TRUE: Invoke WEBUTIL.ERRORALERT to display error message 'WUC-005: No WebUtil Configuration File specified' in English, set m_config_error to TRUE, and return NULL.

FALSE: Delegate error reporting to Webutil_Core.Error with code WUC_PACKAGE/5 and set m_config_error to TRUE, then return NULL.

---

DP-008

Condition: An OTHERS exception is raised and SQLCODE equals -302000 (file read failure) and m_registeredPackages.FIRST is null.

TRUE: Invoke WEBUTIL.ERRORALERT to display error message 'WUC-006: Unable to read WebUtil Configuration File' in English, set m_config_error to TRUE, and return NULL.

FALSE (SQLCODE = -302000 but bean registered): Delegate error reporting to Webutil_Core.Error with code WUC_PACKAGE/6 including the configFile name, set m_config_error to TRUE, and return NULL. If SQLCODE is any other value, re-raise the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be obtainable from exactly one of three sources evaluated in strict priority order: (1) the Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) the environment variable WEBUTIL_CONFIG_ENV, (3) the Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, processing cannot continue.
- BR-002 - Once resolved, the configuration file path must be written back to the Forms global variable WEBUTIL_CONFIG_GLOBAL so that subsequent invocations can retrieve it without repeating the resolution sequence.
- BR-003 - Lines in the configuration file that begin with the '#' character are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are treated as valid property definitions; lines without this delimiter are silently skipped.
- BR-005 - Property keys stored in m_propertyBundle must be lowercased and trimmed of leading and trailing whitespace; property values must be trimmed of leading and trailing whitespace and stripped of carriage-return characters (CHR(13)).
- BR-006 - Key matching against the input propertyKey is case-insensitive; both the stored key and the input parameter are lowercased before comparison.
- BR-007 - When no configuration file can be located (WUC-005) or the file cannot be read (WUC-006 / SQLCODE -302000), the module-level flag m_config_error must be set to TRUE and the function must return NULL rather than propagating the exception.
- BR-008 - Error messages for WUC-005 and WUC-006 must be presented via WEBUTIL.ERRORALERT when no WebUtil bean has been registered yet (m_registeredPackages.FIRST is null); otherwise error reporting is delegated to the Webutil_Core framework.
- BR-009 - Any exception other than NO_DATA_FOUND or SQLCODE -302000 must be re-raised, preserving the original error for the calling context.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-053 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by delegating three sequential property-set calls to the WebUtil_Core bean. The procedure appends a newline character after the supplied text item, replicating the behaviour of Oracle's CLIENT_TEXT_IO.PUT_LINE for use in a web-deployed Forms environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, registering which open file is to receive the output.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, passing the text item to be written to the file.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean to the value 1 via WebUtil_Core.setProperty, instructing the bean to append a newline character after the written text.
- Step 5 - If the WebUtil_Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If any property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing without additional alerting.

---
**Decision Points**

DP-001

Condition:
The WebUtil_Core bean for WUF_PACKAGE is not registered at the time any setProperty call is executed (WebUtil_Core.BEAN_NOT_REGISTERED exception raised).

TRUE:
Display an error alert identifying the missing bean class and stating that CLIENT_TEXT_IO.put_line will not work, then raise TOOL_ERR.TOOL_ERROR to halt execution.

FALSE:
Continue processing the remaining setProperty calls normally.

---

DP-002

Condition:
A property-set operation fails during execution of any of the three WebUtil_Core.setProperty calls (WebUtil_Core.PROPERTY_ERROR exception raised).

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to halt execution; no additional alert is displayed.

FALSE:
All three property assignments complete successfully and the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle must be supplied as part of a valid file_type value; the procedure extracts file.handle directly and passes it to the bean without additional validation.
- BR-002 - All three properties (WUF_TEXTIO_HANDLE, WUF_TEXTIO_PUT, and WUF_TEXTIO_NEWLINE) must be set in sequence on the WUF_PACKAGE bean to constitute a complete put_line operation; omitting any one property would result in incomplete or incorrect file output.
- BR-003 - A newline is always appended after the text item (WUF_TEXTIO_NEWLINE is always set to 1); this procedure does not support writing text without a trailing newline.
- BR-004 - The WebUtil_Core bean must be registered in the client environment before this procedure is called; if it is absent, the operation is rejected and the caller receives TOOL_ERR.TOOL_ERROR.
- BR-005 - Any property-set failure is treated as a fatal error; the procedure raises TOOL_ERR.TOOL_ERROR and does not attempt recovery or partial writes.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-054 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle. If the bundle has not yet been loaded, it delegates population to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. This function supports configuration-driven behaviour for routines such as WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN by providing a centralised, cached mechanism for reading named configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-052](#SP-052--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) identifying the configuration value to retrieve.
- Step 2 - Check the module-level error flag (m_config_error). If a configuration file read error was previously recorded, immediately return NULL, bypassing all further processing.
- Step 3 - Evaluate the current count of entries in the in-memory property bundle (m_propertyBundle). If the bundle is empty (count = 0), delegate to WEBUTIL.POPULATEPROPERTYBUNDLE, passing the requested propertyKey, and assign the returned value as the result.
- Step 4 - If the bundle is already populated (count > 0), iterate through each entry in m_propertyBundle, comparing each stored propertyKey (held in lowercase) against the lowercase-normalised input key.
- Step 5 - On the first matching entry, capture the corresponding propertyValue as the result and exit the loop immediately.
- Step 6 - Return the resolved result value to the caller; if no match was found during iteration, the result remains NULL and is returned as such.

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no property lookup is attempted, as a prior configuration file error renders the bundle unreliable.

FALSE: Proceed to evaluate whether the property bundle is populated (DP-002).

---

DP-002

Condition: The property bundle (m_propertyBundle) contains zero entries (propCount = 0).

TRUE: Invoke WEBUTIL.POPULATEPROPERTYBUNDLE with the supplied propertyKey to load the bundle and obtain the result in a single call.

FALSE: The bundle is already loaded; iterate through existing entries to locate the matching key (DP-003).

---

DP-003

Condition: During iteration, the current entry's stored propertyKey matches the lowercase form of the input propertyKey.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop; the matched value will be returned to the caller.

FALSE: Continue iterating to the next entry; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the m_config_error flag is set, the function must return NULL without attempting any property lookup, ensuring that callers are not supplied with stale or partially loaded configuration data following a read failure.
- BR-002 - Property key matching is case-insensitive; stored keys are held in lowercase and the input key is compared in lowercase, guaranteeing consistent retrieval regardless of the case used by the caller.
- BR-003 - When the in-memory bundle is empty, the function must delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to initialise the bundle; direct population by this function is not permitted.
- BR-004 - The function returns only the first matching property value encountered during iteration and exits immediately, enforcing uniqueness of effective key resolution within the bundle.
- BR-005 - The return value is limited to VARCHAR2(1000 char); property values exceeding this length cannot be retrieved through this function.
- BR-006 - If no entry matching the requested key exists in a populated bundle, the function returns NULL; callers are responsible for handling a NULL result.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-055 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by sending a property key and optional arguments to the WebUtil Core layer and reading back the resolved translation. This function is used to obtain localised UI text - currently limited to fetching the progress bar title during library-check processing invoked by WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional arguments string (args) as input.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form the composite message request string.
- Step 3 - Write the composite string to the WebUtil Core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read the resolved (translated) message back from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed set-then-get sequence unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and arguments must be combined using a pipe character ('|') as the delimiter before being submitted to the WebUtil Core property store; this delimiter format is required for the message bundle resolution mechanism to parse the request correctly.
- BR-002 - The args parameter is optional (defaults to NULL); when NULL is passed, the composite string submitted to the property store will be in the form 'propertyKey|', with a trailing pipe delimiter.
- BR-003 - The function relies exclusively on Webutil_Core.setProperty and Webutil_Core.getProperty for all message resolution; no direct database access or additional translation logic is performed within this function.
- BR-004 - The function is currently authorised for use only by WEBUTIL.CHECKLIBS, specifically to resolve the progress bar title text; use outside this context is not supported by the existing design.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-056 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms server-side runtime on first contact. On the initial bean registration it captures client environment details (IP address, OS, architecture, username, path/file separators, language code), resolves the system-library download directory, sets heartbeat and server-logging configuration properties on the client bean, and triggers library-availability checks for both the specific bean package and any user-defined libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-021](#SP-021--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-038](#SP-038--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-042](#SP-042--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-054](#SP-054--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-059](#SP-059--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name (e.g., 'WUC', 'WUT', 'WUF', etc.) from the pipe-delimited clientInfo string using DelimStr.getString at position 1.
- Step 2 - Map the bean short name to its corresponding integer package-ID constant defined in WEBUTIL_CORE (WUC_PACKAGE through WUL_PACKAGE). If the short name does not match any known constant, packageID remains unset.
- Step 3 - Determine whether this is the very first bean registration in the session by checking whether the module-level variable m_clientIP is null. If it is null, set the checkUserLibs flag to TRUE and parse positions 2-8 of clientInfo to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), clientOSArch, m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode. If the OS architecture string contains '64', set m_clientOSArch to 1 (64-bit).
- Step 4 - Check whether the resolved packageID already exists in the m_registeredPackages associative array. If it does not exist, record the current trigger item (NAME_IN('SYSTEM.TRIGGER_ITEM')) against that packageID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - If checkUserLibs is TRUE (first-bean path), reset REDOWNLOAD_SYSLIB to FALSE, then resolve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME'; if null, fall back to 'HOST'.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with a key that includes the OS family and architecture suffix; if null, retry with the OS-family-only key.
- Step 7 - If no client library directory is found in the property bundle, send a WUC_SYSLIB_DIR property to the client (via WebUtil_Core.setProperty) containing only the server host and application CONFIG property, allowing the client JRE to handle placement. If a directory is found, replace the '$(SERVERHOST)' token with the resolved server host name, send the full WUC_SYSLIB_DIR value to the client, then retrieve the previously stored client library directory via WEBUTIL.GETCLIENTSETTING. If the stored value differs from the newly resolved directory, update it via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for 'WUC_BEAN_VERSION'.
- Step 9 - If the property bundle key 'logging.connections' evaluates to 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG recording the current form name, client OS, and locale.
- Step 10 - If the newPackage flag is TRUE, call WEBUTIL.CHECKLIBS passing the string representation of the packageID to verify that all required libraries for that bean package are available on the client.
- Step 11 - If checkUserLibs is TRUE, invoke WEBUTIL.LOG with a null message to initialise the module-level logging-control variables m_loggingAllowed and m_loggingErrorsOnly.
- Step 12 - Read the 'BlockAllowHeartBeat' configuration value from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE. If the value is 'true', 'yes', or '1', send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise send '0'.
- Step 13 - Evaluate the logging state flags and send the WUC_SRV_LOGGING property to the client bean: '1' if logging is allowed but errors-only, '2' if full logging is allowed, or '0' if logging is disabled.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to check for and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL').
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains unassigned; subsequent array and property operations reference an indeterminate value.

DP-002
Condition: m_clientIP IS NULL (i.e., no bean has been registered in this session yet).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are not re-parsed; checkUserLibs remains FALSE.

DP-003
Condition: The OS architecture string extracted from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (indicating a 64-bit client).
FALSE: m_clientOSArch retains its prior value (implicitly 0 / 32-bit).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current trigger item is stored in m_registeredPackages(packageID) and newPackage is set to TRUE.
FALSE: The bean is already registered; no update is made and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.GETVAR returns a non-null value for 'COMPUTERNAME'.
TRUE: serverHost is set to the COMPUTERNAME value.
FALSE: A second call to WEBUTIL.GETVAR is made for 'HOST' to obtain the server host name.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family-and-architecture-specific key ('install.syslib.location.client.{osfamily}.{osarch}').
TRUE: clientLibDir is set to that value; the OS-family-only fallback lookup is skipped.
FALSE: A second WEBUTIL.READFROMPROPERTYBUNDLE call is made using the OS-family-only key.

DP-007
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the client containing only the server host and CONFIG property; client JRE determines the library placement location.
FALSE: The '$(SERVERHOST)' token in clientLibDir is replaced, WUC_SYSLIB_DIR is sent with the full directory path, and the previously stored client library directory is compared via WEBUTIL.GETCLIENTSETTING.

DP-008
Condition: The previously stored client library directory (clientLibDirOld) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING updates the stored directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The stored directory is unchanged; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections') returns 'true' (case-insensitive).
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to verify bean-specific library availability.
FALSE: Bean-specific library check is skipped.

DP-011
Condition: blockAllowHeartBeat (lowercased) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the client bean, instructing it to block heartbeat behaviour.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0', permitting normal heartbeat behaviour.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging) on the client bean.
FALSE: Evaluation continues to DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging) on the client bean.
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled) on the client bean.

DP-014
Condition: checkUserLibs is TRUE (end-of-procedure user-library check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check for and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only recognised bean short names ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') are mapped to package IDs; any unrecognised bean short name results in no packageID assignment.
- BR-002 - Client environment information (IP address, OS name, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per session, on the first bean registration call; subsequent registrations do not overwrite these values.
- BR-003 - Each bean package type may be registered at most once per form session; if the same bean type appears in multiple form items (e.g., a multi-row block), only the first instance is recorded in m_registeredPackages.
- BR-004 - A client OS architecture string containing '64' is classified as 64-bit (m_clientOSArch = 1); all other values are treated as non-64-bit.
- BR-005 - The system-library client directory is resolved with preference for the most specific property bundle key (OS family + architecture); the OS-family-only key is used only when the specific key returns no value.
- BR-006 - When a specific client system-library directory is configured, the placeholder token '$(SERVERHOST)' within that directory value must be replaced with the runtime server host name before the value is transmitted to the client.
- BR-007 - If the resolved client system-library directory differs from the previously stored value, the stored value is updated via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag is set to TRUE to trigger a re-download.
- BR-008 - Connection logging is conditional on the 'logging.connections' property bundle entry evaluating to 'true'; the log entry must include form name, client OS, and locale.
- BR-009 - The 'BlockAllowHeartBeat' configuration value is accepted as 'true', 'yes', or '1' (case-insensitive); any other value disables the heartbeat block.
- BR-010 - Server-side logging state is communicated to the client bean as a single integer property (WUC_SRV_LOGGING): 0 = disabled, 1 = errors only, 2 = full logging.
- BR-011 - Library availability checks for a specific bean package (via WEBUTIL.CHECKLIBS) are performed only when that package is being registered for the first time (newPackage = TRUE).
- BR-012 - User-defined client library checks (WEBUTIL.CHECKLIBS('user')) are performed only during the first-bean registration pass (checkUserLibs = TRUE), and only after at least one bean package has been registered so that a handler bean exists to perform any required download.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-057 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil bean layer and returns a FunctionHandle that can be used by subsequent calls to invoke that function. The procedure communicates with the WebUtil core component by setting the library and function specification as a property, retrieving the resulting handle token, and tracking the total count of successfully registered function handles within the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Concatenate libName and funcName with a pipe delimiter and pass the combined specification to the WebUtil core layer by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 3 - Retrieve the registration result from the WebUtil core layer by reading the WUL_REGISTER_FUNCTION property on the WUL_PACKAGE component; the result is returned as an 8-character string handle (strHnd).
- Step 4 - Convert the string handle to a numeric value and assign it to the hnd field of the FunctionHandle record (funcHnd).
- Step 5 - Evaluate whether the returned FunctionHandle is valid by calling WEBUTIL.ID_NULL. If the handle is not null (i.e., registration succeeded), increment the session-level function handle counter (m_funcHandleCount) by 1.
- Step 6 - Return the populated FunctionHandle to the caller.
- Step 7 - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a property error occurs during the get or set operation, raise FORM_TRIGGER_FAILURE.
- Step 9 - If a VALUE_ERROR occurs during numeric conversion of the string handle, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: The FunctionHandle returned from the WebUtil core layer is evaluated using WEBUTIL.ID_NULL to determine whether it represents a valid (non-null) registration.

TRUE (handle is NOT null - registration is valid): The session-level function handle counter (m_funcHandleCount) is incremented by 1, and the valid FunctionHandle is returned to the caller.

FALSE (handle IS null - registration did not yield a valid handle): The counter is not incremented; the null FunctionHandle is still returned to the caller without error escalation at this point.

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the property set or get operation, indicating the required WebUtil bean implementation class is absent.

TRUE: An error alert is displayed identifying the missing bean class, and FORM_TRIGGER_FAILURE is raised to stop form processing.

FALSE: Processing continues normally to the next step.

DP-003

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during the property set or get operation.

TRUE: FORM_TRIGGER_FAILURE is raised immediately with no additional messaging.

FALSE: Processing continues normally.

DP-004

Condition: A VALUE_ERROR exception is raised when converting the string handle to a number via TO_NUMBER.

TRUE: TOOL_ERR.TOOL_ERROR is raised to signal an unrecoverable data conversion failure.

FALSE: Conversion succeeds and the numeric handle is assigned to the FunctionHandle record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The library name and function name must both be supplied; they are concatenated with a pipe character ('|') as the delimiter when forming the WUL_FUNCTION_SPEC property value sent to the WebUtil core layer.
- BR-002 - A FunctionHandle is only counted as a successfully registered handle if WEBUTIL.ID_NULL confirms it is not null; null handles do not increment the session counter.
- BR-003 - The session-level handle counter (m_funcHandleCount) must be incremented each time a valid FunctionHandle is registered, ensuring accurate tracking of active function registrations within the session.
- BR-004 - If the WebUtil bean implementation class is not available at registration time, the operation must not silently fail; an informative error alert must be presented to the user and form processing must be halted via FORM_TRIGGER_FAILURE.
- BR-005 - A property communication error with the WebUtil core layer is treated as a terminal condition; FORM_TRIGGER_FAILURE is raised without additional user messaging.
- BR-006 - An invalid (non-numeric) handle value returned by the WebUtil core layer is treated as an unrecoverable error and must raise TOOL_ERR.TOOL_ERROR rather than allowing a malformed FunctionHandle to propagate.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-058 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This procedure ensures that process resources managed by the WebUtil host utility are properly deallocated after use, preventing stale or orphaned process handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process property on the WUH_PACKAGE bean, signalling the WebUtil host layer to release its internal reference to the process handle.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger to remove any callback trigger registered against the process handle, ensuring no residual trigger fires after the process is released.
- Step 4 - Set the process.handle attribute to NULL, formally invalidating the caller's reference to the released process.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, present an error alert identifying the missing implementation class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean via WebUtil_Core.

TRUE: WebUtil_Core.ErrorAlert is called with a message that concatenates the implementation class name (retrieved via WebUtil_Core.getImplClass for WUH_PACKAGE) with a notification that the bean was not found and that WEBUTIL_HOST.Release_Process will not work. No further processing occurs.

FALSE: Normal execution continues; the process property is cleared, the callback trigger is removed, and the handle is nullified without error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle passed to this procedure must be an active PROCESS_ID previously obtained through the WebUtil host process mechanism; the procedure unconditionally nullifies the handle upon completion, making it the caller's responsibility not to reuse the handle after invocation.
- BR-002 - The WebUtil bean associated with WUH_PACKAGE must be registered and available at runtime; if the bean is absent, the release operation cannot proceed and an error alert is surfaced to the user.
- BR-003 - Both the property clearing (setProperty) and the callback trigger removal (ClearCallbackTrigger) must be performed before the handle is nullified, ensuring the WebUtil host layer is fully cleaned up before the caller's reference is invalidated.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-059 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named client-side property and its value to the WebUtil core bean running on the client machine. The procedure packages the property name and value into a single delimited string and delegates the call to WebUtil_Core.setProperty, targeting the WUC_SET_LOCAL_PROPERTY action on the WUC_PACKAGE bean. It is invoked by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to configure client-side WebUtil settings during library checking and bean registration workflows.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the client setting to be applied via the input parameters propertyName (the name of the client property) and propertyValue (the value to assign to that property).
- Step 2 - Evaluate whether propertyName is not null; only a non-null property name warrants a call to the client bean.
- Step 3 - If propertyName is not null, concatenate propertyName and propertyValue into the format 'propertyName=propertyValue' and invoke WebUtil_Core.setProperty, passing the WUC_PACKAGE constant as the target bean identifier, the WUC_SET_LOCAL_PROPERTY constant as the action, and the concatenated string as the property payload.
- Step 4 - If the WebUtil_Core bean has not been registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class via WebUtil_Core.ErrorAlert and WebUtil_Core.getImplClass, then raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 5 - If WebUtil_Core.setProperty reports a property error (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue as 'propertyName=propertyValue' and call WebUtil_Core.setProperty to transmit the setting to the client bean.

FALSE: Skip the setProperty call entirely; the procedure exits without performing any action.

DP-002

Condition: WebUtil_Core.setProperty raises the BEAN_NOT_REGISTERED exception (the WUC_PACKAGE bean is not registered on the client).

TRUE: Display an error alert identifying the missing bean class using WebUtil_Core.ErrorAlert and WebUtil_Core.getImplClass, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No bean registration error; processing continues normally or proceeds to DP-003.

DP-003

Condition: WebUtil_Core.setProperty raises the PROPERTY_ERROR exception (the property assignment fails on the client).

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger; no additional alert is displayed.

FALSE: No property error; the procedure completes successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting will only be transmitted to the WebUtil core bean if propertyName is not null; a null property name causes the procedure to exit silently without making any call to WebUtil_Core.setProperty.
- BR-002 - The property name and value must be combined into a single string in the format 'propertyName=propertyValue' before being passed to WebUtil_Core.setProperty; the two values are not passed as separate arguments to the bean action.
- BR-003 - The target bean and action are fixed at WUC_PACKAGE and WUC_SET_LOCAL_PROPERTY respectively; callers cannot override the bean target or action through the parameters of this procedure.
- BR-004 - If the WUC_PACKAGE bean is not registered on the client at the time of the call, the procedure must surface a descriptive error alert (identifying the missing bean class) and then raise FORM_TRIGGER_FAILURE, preventing the form from continuing silently with an unconfigured client environment.
- BR-005 - If the client bean reports a property error, the procedure must raise FORM_TRIGGER_FAILURE immediately, ensuring that a failed client-side property assignment is never silently ignored during form processing.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-060 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Receives a single chunk of upload data (Base64 or raw string) from the client and writes it to either a database BLOB or a server-side file, depending on the active transfer destination. After each chunk is written, the procedure decrements the outstanding-chunk counter; when the final chunk is processed it closes the target resource, marks the upload as succeeded, fires any registered callback trigger, and clears that trigger registration. If the incoming data is null or empty, or if any write or close operation fails, the procedure records the error and raises a read/write exception to halt the transfer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-023](#SP-023--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-024](#SP-024--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-035](#SP-035--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-063](#SP-063--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 parameter representing one chunk of the file being uploaded.
- Step 2 - Validate that uploadData is not null and not an empty string; if it is, set the module-level flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the transfer destination by evaluating the module-level flag m_toDB.
- Step 4 (DB path) - If m_toDB is TRUE, delegate the chunk write to WEBUTIL.WRITEDATA (WebUtil_DB_LOCAL.WriteData) to append the data to the in-progress BLOB.
- Step 5 (File path) - If m_toDB is FALSE, call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file. If the write fails, retrieve the error code via WEBUTIL.GETLASTERROR and the error arguments via WEBUTIL.GETLASTERRORARGS, log the error through WebUtil_core.Error, and raise READWRITE_ERROR.
- Step 6 - Decrement the module-level chunk counter m_chunks by 1.
- Step 7 - Evaluate whether m_chunks has reached zero (i.e., all expected chunks have been received).
- Step 8 (Final chunk - DB path) - If m_toDB is TRUE, call WEBUTIL.CLOSEBLOB (WebUtil_DB_Local.CloseBlob) passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise log the error returned by WEBUTIL.GETLASTERROR.
- Step 9 (Final chunk - File path) - If m_toDB is FALSE, call WEBUTIL.CLOSEFILE (JAVA_APPSERV_WRITER.CloseFile) passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error, delete the global Java object reference, and raise READWRITE_ERROR.
- Step 10 - After successfully closing the resource, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER. If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 11 - Call WEBUTIL.CLEARCALLBACKTRIGGER to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately without writing any data.

FALSE: Proceed to determine the write destination and write the chunk.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk to the database BLOB using WEBUTIL.WRITEDATA (WebUtil_DB_LOCAL.WriteData).

FALSE: Write the chunk to the server-side file using JAVA_APPSERV_WRITER.WriteData; on failure, capture error details via WEBUTIL.GETLASTERROR and WEBUTIL.GETLASTERRORARGS, log the error, and raise READWRITE_ERROR.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failure)

TRUE: Retrieve error code and arguments, log the error via WebUtil_core.Error, and raise READWRITE_ERROR.

FALSE: Continue to decrement the chunk counter.

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the target resource (BLOB or file) and finalise the upload.

FALSE: Return without closing; await subsequent chunk deliveries.

---

DP-005

Condition: m_toDB is TRUE at final-chunk close

TRUE: Call WEBUTIL.CLOSEBLOB; on success set m_uploadSucceeded to TRUE, on failure log the error via WEBUTIL.GETLASTERROR.

FALSE: Call WEBUTIL.CLOSEFILE; on success set m_uploadSucceeded to TRUE, on failure retrieve error details via WEBUTIL.GETLASTERROR and WEBUTIL.GETLASTERRORARGS, log the error, delete the global Java object reference, and raise READWRITE_ERROR.

---

DP-006

Condition: WEBUTIL.GETCALLBACKTRIGGER returns a non-null trigger name after the final chunk is closed

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution.

---

DP-007

Condition: WEBUTIL.CLOSEBLOB returns TRUE (DB close success)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Log the error using the code returned by WEBUTIL.GETLASTERROR; m_uploadSucceeded remains FALSE.

---

DP-008

Condition: WEBUTIL.CLOSEFILE returns TRUE (file close success)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error code and arguments, log the error, delete the global Java object reference, and raise READWRITE_ERROR.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null or empty uploadData chunk is treated as an error condition; the upload is marked as failed (m_uploadSucceeded = FALSE) and no write operation is attempted.
- BR-002 - Every non-empty chunk must be written in full to the designated destination (BLOB or file) before the chunk counter is decremented; a failed write immediately halts processing via READWRITE_ERROR.
- BR-003 - The transfer destination is determined exclusively by the module-level flag m_toDB; the procedure does not re-evaluate or override this flag during execution.
- BR-004 - The chunk counter m_chunks must reach exactly zero before the target resource is closed; partial receipt of chunks does not trigger a close operation.
- BR-005 - The upload is marked as succeeded (m_uploadSucceeded = TRUE) only after the target resource (BLOB or file) is closed successfully; a failed close prevents the success flag from being set.
- BR-006 - On a file-path close failure, the global Java object reference (m_persistObj) must be explicitly deleted before raising READWRITE_ERROR to prevent resource leaks.
- BR-007 - A registered callback trigger, if present, must be fired after the final chunk is successfully closed and before the trigger registration is cleared.
- BR-008 - WEBUTIL.CLEARCALLBACKTRIGGER must always be called after the final chunk is processed, ensuring no stale callback trigger remains registered regardless of whether a trigger was executed.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-061 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a PL/SQL wrapper that sets a named Java system property to a specified value by delegating the call to the native Java method java.lang.System.setProperty via the JNI bridge. The function returns the previous value of the property as a VARCHAR2 string, enabling Oracle Forms to read or overwrite JVM-level runtime properties at the client tier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Initialise a JNI argument list sized for two arguments by calling JNI.CREATE_ARG_LIST(2) and store the handle in the shared variable args.
- Step 3 - Append the property name (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the new property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully-qualified class name, method name, and JNI method signature, together with the prepared argument list.
- Step 6 - Return the VARCHAR2 result, which is the previous value of the named property as reported by the Java runtime (or NULL if the property was not previously set).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the property name (a0) and the new value (a1) must be supplied as VARCHAR2 arguments; the JNI bridge passes them directly to java.lang.System.setProperty without null-guarding within this function.
- BR-002 - The function targets the static Java method java.lang.System.setProperty with the exact JNI signature '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;'; the class, method name, and signature must not be altered to preserve correct JVM dispatch.
- BR-003 - The return value represents the property's previous value as held by the JVM at the time of the call; callers that need to preserve the original value must capture this return before issuing further property changes.
- BR-004 - This function operates exclusively at the JVM/client-tier level via the JNI bridge; it performs no database reads or writes and has no effect on server-side Oracle session parameters.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-062 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil bean components. When called with show = TRUE, the procedure surfaces the hidden window and navigates focus into it so that embedded beans can be interacted with; when called with show = FALSE, it hides the window and restores focus to the item that held the cursor before the window was displayed. The procedure is safety-guarded to execute only when the form is in NORMAL mode, preventing interference with Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-045](#SP-045--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the WebUtil hidden window handle by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the result in a local variable.
- Step 2 - Check SYSTEM.MODE via NAME_IN; if the form is not in NORMAL mode, skip all further processing (guard against Enter Query Mode per Bug 2955789).
- Step 3 - Validate the window handle using WEBUTIL.ID_NULL (SP-045); if the handle is null (window not found), skip all further processing.
- Step 4 - Evaluate the IN parameter 'show' to determine whether the window should be displayed or hidden.
- Step 5 (show = TRUE) - Capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom for later restoration.
- Step 6 (show = TRUE) - Set the hidden window's title to 'WebUtil ' concatenated with WEBUTIL_VERSION to reflect the current version.
- Step 7 (show = TRUE) - Display the hidden window using SHOW_WINDOW, then navigate form focus to WEBUTIL_DUMMY_ITEM inside that window.
- Step 8 (show = FALSE) - Check whether m_infoFrom is non-null using WEBUTIL.ID_NULL (SP-045); if it holds a valid item reference, navigate form focus back to that item.
- Step 9 (show = FALSE) - Hide the window using HIDE_WINDOW regardless of whether focus was restored.

---
**Decision Points**

DP-001

Condition: NAME_IN('SYSTEM.MODE') = 'NORMAL'

TRUE: Proceed with window show/hide processing.

FALSE: Exit the procedure immediately without performing any window or focus operations, preserving Enter Query Mode integrity.

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) evaluates to FALSE (i.e., the WEBUTIL_HIDDEN_WINDOW handle is valid)

TRUE: Proceed with window show/hide processing.

FALSE: Exit the procedure without attempting any window operations, avoiding a runtime error on an unresolvable window.

---

DP-003

Condition: The IN parameter 'show' is TRUE

TRUE: Capture the current cursor item, set the window title, display the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Attempt to restore focus to the previously captured cursor item and hide the window.

---

DP-004

Condition: WEBUTIL.ID_NULL(m_infoFrom) evaluates to FALSE (i.e., a valid prior cursor item was recorded)

TRUE: Navigate form focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus manipulation when the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this restriction exists to prevent corruption of query criteria entry (Bug 2955789).
- BR-002 - Window operations are only permitted when the WEBUTIL_HIDDEN_WINDOW handle resolves to a non-null value; an unresolvable window handle causes the procedure to exit silently.
- BR-003 - When showing the WebUtil window, the cursor item active at the time of the call must be captured and persisted in m_infoFrom so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The WebUtil hidden window title must be set to 'WebUtil ' concatenated with WEBUTIL_VERSION each time the window is shown, ensuring the displayed title reflects the current runtime version.
- BR-005 - Focus restoration on hide is conditional: if m_infoFrom does not hold a valid item reference, the procedure hides the window without attempting a GO_ITEM call, preventing a runtime navigation error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-063 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the Java-layer AppServerFileWriter class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called exclusively by WEBUTIL.SETDATA to perform the physical data-write step during a server-side file transfer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target Java object reference (obj) identifying the active AppServerFileWriter instance, and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string data payload (a0) to the argument list by calling JNI.ADD_STRING_ARG(args, a0).
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class via JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and specifying the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result produced by the JNI call to the caller (WEBUTIL.SETDATA), indicating success or failure of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally constructs the argument list, invokes the Java WriteData method, and returns the Boolean result without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid Java object reference (obj) representing an already-instantiated AppServerFileWriter instance; no object initialisation is performed within this function.
- BR-002 - Exactly one string argument (a0) must be supplied; the JNI argument list is created with a fixed capacity of one, and no additional arguments may be appended.
- BR-003 - The success or failure of the write operation is communicated solely through the Boolean return value; the caller (WEBUTIL.SETDATA) is responsible for handling a FALSE result.
- BR-004 - The target Java class and method are fixed at 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' and 'WriteData' respectively; no dynamic class or method resolution is permitted.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-064 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side Java bean. When a WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multi-part chunking metadata, and routes execution to the appropriate WebUtil subsystem handler (logging, error reporting, bean registration, host-command callback, or file-transfer notification).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-026](#SP-026--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-037](#SP-037--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-051](#SP-051--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-056](#SP-056--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-060](#SP-060--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-061](#SP-061--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming EventName against the five recognised WebUtil event identifiers ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'). If the event is not in this list, raise the local 'unhandled' exception, which is silently caught, and exit without further processing.
- Step 2 - Extract the primary data payload from the EventParameters string by calling the internal helper get_parameter_attr for the key 'WUC_DATA', storing the result in dataPayload.
- Step 3 - Extract the multi-part chunking descriptor from EventParameters using get_parameter_attr for the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 4 - Parse the multi-part descriptor to determine the current chunk sequence number (chunkNumber) and the total number of chunks required to reconstitute the full payload (PayloadChunks) by calling DelimStr.getNumber with the '/' delimiter.
- Step 5 - Route execution based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG (via WebUtil_Core.log) passing dataPayload with the error flag set to FALSE, recording an informational log entry.
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG (via WebUtil_Core.log) passing dataPayload with the error flag set to TRUE, recording an error log entry.
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (via registerBean) passing dataPayload to register the client-side bean.
  - If 'WUH_CALLBACK_EVENT': attempt to convert dataPayload to a number and store it in the package-level variable m_lastCallback. If conversion fails (INVALID_NUMBER), call WEBUTIL.ERROR to report error code 408. If m_lastCallback is populated, execute the trigger stored in the m_callbacks collection at that index. If m_lastCallback is NULL, call WEBUTIL.LOG to record that no callback trigger was specified.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (via WebUtil_File_Transfer.setData) to deliver the payload to the file-transfer subsystem, then call WEBUTIL.SETPROPERTY to mark the transfer item property 'WUT_TRANSFER_EVENT' as 'RECEIVED'.
- Step 6 - On completion of routing, return normally. Any unrecognised event is silently discarded; all other unexpected exceptions are re-raised to the caller.

---
**Decision Points**

DP-001
Condition: EventName is NOT one of 'WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'.
TRUE: Raise the local 'unhandled' exception; the exception handler catches it silently (NULL) and the procedure exits without processing.
FALSE: Continue to payload extraction and event routing.

DP-002
Condition: EventName = 'WUC_LOG_EVENT'.
TRUE: Call WEBUTIL.LOG with dataPayload and error flag FALSE.
FALSE: Evaluate next event condition.

DP-003
Condition: EventName = 'WUC_ERROR_EVENT'.
TRUE: Call WEBUTIL.LOG with dataPayload and error flag TRUE.
FALSE: Evaluate next event condition.

DP-004
Condition: EventName = 'WUC_REGISTER'.
TRUE: Call WEBUTIL.REGISTERBEAN passing dataPayload.
FALSE: Evaluate next event condition.

DP-005
Condition: EventName = 'WUH_CALLBACK_EVENT' and dataPayload is a valid number (no INVALID_NUMBER exception).
TRUE: Store the numeric value in m_lastCallback and proceed to DP-006.
FALSE (INVALID_NUMBER raised): Call WEBUTIL.ERROR with error code 408 and identifier 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains unchanged.

DP-006
Condition: m_lastCallback IS NOT NULL (within 'WUH_CALLBACK_EVENT' branch).
TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback).
FALSE: Call WEBUTIL.LOG to record that the callback trigger for the host command was not specified.

DP-007
Condition: EventName = 'WUT_TRANSFER_EVENT'.
TRUE: Call WEBUTIL.SETDATA with dataPayload, then call WEBUTIL.SETPROPERTY to set the 'WUT_TRANSFER_EVENT' property to 'RECEIVED'.
FALSE: No further routing; end of event dispatch chain.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five predefined WebUtil event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are considered valid. Any other event name must be silently ignored and must not cause an application error.
- BR-002 - The data payload and multi-part chunk metadata must always be extracted from EventParameters before any event-specific processing is attempted, regardless of the event type.
- BR-003 - For 'WUH_CALLBACK_EVENT', the payload must be a valid integer referencing an entry in the m_callbacks collection. If the payload cannot be converted to a number, error code 408 must be raised via WEBUTIL.ERROR and no callback trigger may be executed.
- BR-004 - A callback trigger may only be executed if m_lastCallback is non-NULL after successful numeric conversion; a NULL value must be treated as a missing configuration and logged as an error via WEBUTIL.LOG.
- BR-005 - On receipt of 'WUT_TRANSFER_EVENT', the file-transfer subsystem must be notified of the payload via WEBUTIL.SETDATA and the transfer item's property must be updated to 'RECEIVED' via WEBUTIL.SETPROPERTY in the same execution path, ensuring the two operations are always performed together.
- BR-006 - Unexpected runtime exceptions (other than the locally handled 'unhandled' and INVALID_NUMBER cases) must be re-raised to the calling trigger and must not be silently suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-065 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error by setting a global error flag and composing a standardised error stack entry that combines the calling function name with the error message text. The procedure then forwards the composed error entry to the debug logging facility (DEBUGLOG) at severity level 99 for diagnostic tracing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as inputs.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition has been raised within the current execution context.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, ensuring the entry fits within the permitted stack length.
- Step 4 - Invoke DEBUGLOG (SP-069) via Win_API_Debug.DebugLog, passing severity level 99, the literal identifier 'Add_Error', and the composed ERROR_STACK value, so that the error is written to the debug log for subsequent diagnostic review.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message text stored in ERROR_STACK is truncated to a maximum of 1,968 characters to prevent overflow of the stack variable.
- BR-002 - The ERROR_STACK entry must always be prefixed with the CallingFunction name followed by a colon-space separator, ensuring the originating context is identifiable in every error record.
- BR-003 - Setting ERROR_ENCOUNTERED to TRUE is mandatory on every call, guaranteeing that any upstream logic inspecting this flag is correctly informed of the error condition regardless of the error text content.
- BR-004 - All errors recorded by this procedure are forwarded to DEBUGLOG at severity level 99, classifying them as the highest-priority diagnostic entries.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-066 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single string buffer for return to the calling routine. The function first drains the Oracle Forms tool_err error stack, appending each queued message to the buffer. If no tool_err messages are present but a SQL error condition exists, it captures the current SQLERRM text instead. The resulting concatenated string is returned to the caller for downstream error reporting or display.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local character buffer (vcErrBuff) to accumulate error message text, and declare an integer counter for loop iteration.
- Step 2 - Check whether the tool_err error stack contains one or more queued errors (tool_err.nerrors > 0).
- Step 3 - If errors exist on the stack, iterate from 1 to tool_err.nerrors; for each iteration, append a newline character followed by the current tool_err.message to the buffer.
- Step 4 - During each append attempt, trap a VALUE_ERROR exception; if the buffer would exceed its maximum capacity (1,968 characters), exit the loop immediately to prevent overflow.
- Step 5 - After appending each message, call tool_err.pop to remove the processed error from the stack and advance to the next entry.
- Step 6 - If the tool_err stack is empty but SQLERRM is not null, append a newline character followed by the SQLERRM text to the buffer as the sole error entry.
- Step 7 - Return the fully assembled error buffer string to the caller.

---
**Decision Points**

DP-001

Condition: tool_err.nerrors > 0 (the tool_err error stack contains at least one queued message).

TRUE: Enter the iterative loop to collect and concatenate all tool_err messages into the buffer, popping each entry after it is appended.

FALSE: Skip the loop and evaluate the SQLERRM fallback condition (DP-002).

---

DP-002

Condition: SQLERRM is not null (evaluated only when the tool_err stack is empty).

TRUE: Append a newline followed by the SQLERRM text to the buffer as the error entry.

FALSE: No error text is added; the buffer remains empty and an empty string is returned.

---

DP-003

Condition: A VALUE_ERROR exception is raised during a buffer append operation inside the loop (concatenated string would exceed 1,968 characters).

TRUE: Exit the loop immediately, preserving the messages already accumulated without raising an unhandled error.

FALSE: Continue appending subsequent tool_err messages and popping the stack.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer is capped at 1,968 characters; any tool_err message that would cause the buffer to exceed this limit is silently discarded and loop processing halts to prevent a runtime overflow error.
- BR-002 - The tool_err stack takes precedence over SQLERRM; the SQLERRM fallback is only consulted when tool_err.nerrors equals zero, ensuring that stack-based errors are never mixed with the SQL error state.
- BR-003 - Each tool_err entry must be popped from the stack after its message is read, ensuring the stack is progressively cleared during the collection pass.
- BR-004 - Every appended error message is prefixed with a newline character (chr(10)), producing a line-separated error report suitable for display or logging by the calling routine.
- BR-005 - The function returns a varchar2 value in all execution paths; when no errors are present on either the tool_err stack or SQLERRM, an empty (null) string is returned.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-067 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used by calling routines such as GET_ENVIRONMENT_STRING and READ_REGISTRY, which require a character representation of boolean state for further processing or output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN value (ThisBoolean) passed by the calling routine.
- Step 2 - Evaluate the BOOLEAN value using a conditional check.
- Step 3 - If the value evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If the value evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean evaluates to TRUE.

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 string; the only permissible return values are 'TRUE' and 'FALSE'.
- BR-002 - The conversion is case-fixed: the returned strings are always uppercase literals ('TRUE' / 'FALSE'), ensuring consistent string representation for any downstream consumer.
- BR-003 - The function accepts no parameters other than the single BOOLEAN input; no database interaction or external dependency is involved in producing the result.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-068 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the shared error-state variables used across the utility library. CLEAN_ERROR_STACK clears the ERROR_ENCOUNTERED flag and nullifies the ERROR_STACK accumulator, ensuring that any previously recorded error conditions are discarded before a new operation begins. It is called by GET_ENVIRONMENT_STRING and READ_REGISTRY to guarantee a clean error context at the start of each invocation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently active.
- Step 2 - Set the package-level variable ERROR_STACK to NULL, removing any previously accumulated error messages from the stack.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every call, regardless of its prior value, ensuring callers always start with a clean error state.
- BR-002 - ERROR_STACK must be set to NULL on every call, ensuring no residual error messages from a previous operation are carried forward into a subsequent operation.
- BR-003 - The procedure accepts no input parameters and produces no output parameters; its sole effect is the unconditional reset of the two shared error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-069 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel (either a Windows debug viewer or a flat log file) when the current debug state is active, not paused, and the message's severity level falls within the configured threshold. It is the central logging routine called by multiple D2kwutil procedures to record runtime diagnostic information during form execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-074](#SP-074--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-077](#SP-077--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether debug logging is globally active (iDebugState ≠ 0), not paused (bDebugPaused = FALSE), and whether the incoming DebugLevel does not exceed the configured threshold (iDebugLevel). If any of these conditions fails, exit immediately without logging.
- Step 2 - If the timestamp flag (bDebugTimeStamp) is enabled, retrieve the current system time formatted as HH24:MI:SS and append a '>' separator to form vcDateStamp.
- Step 3 - Construct the full debug string (vcDebugString) by concatenating the zero-padded DebugLevel, the optional timestamp, the calling routine name (LoggingCall) right-padded to 30 characters, and a truncated portion of LogString so the total does not exceed 2,000 characters. WEBUTIL.LENGTH is used implicitly through the package context to determine string boundaries.
- Step 4 - If the debug state is 2 (Windows debug viewer mode), check whether the debug API is available (DEBUG_API_ENABLED). If available, invoke WINDEBUG to write vcDebugString to the Windows debug output.
- Step 5 - If the debug state is 2 but the debug API is unavailable, fall back to file logging by calling SETDEBUG to reconfigure the debug channel to file mode (state 1) targeting the configured log file (vcDebugFile, defaulting to 'd2kwutil.log'), log a notification message, recursively call DEBUGLOG to write the original message, and set the bDebugType2Required flag to TRUE to signal that the Windows debug channel was the intended target.
- Step 6 - If the debug state is not 2 and bDebugType2Required is TRUE and the debug API has since become available, call SETDEBUG to restore the debug channel to Windows debug viewer mode (state 2), log a restoration notification message, reset bDebugType2Required to FALSE, and recursively call DEBUGLOG to write the original message to the now-restored channel.
- Step 7 - If the debug state is not 2 and no API restoration is required, open the configured log file in append mode using TEXT_IO, write vcDebugString as a new line, and close the file.
- Step 8 - If any unhandled exception occurs during any of the above steps, suppress the error by setting iDebugState to 0, preventing debug logging from disrupting normal form operation.

---
**Decision Points**

DP-001

Condition: iDebugState = 0

TRUE: Logging is globally disabled; procedure exits immediately with no action.

FALSE: Proceed to evaluate the paused state (DP-002).

---

DP-002

Condition: bDebugPaused = TRUE

TRUE: Logging is temporarily suspended; procedure exits immediately with no action.

FALSE: Proceed to evaluate the debug level threshold (DP-003).

---

DP-003

Condition: DebugLevel > iDebugLevel

TRUE: The message's severity exceeds the configured verbosity threshold; procedure exits immediately with no action.

FALSE: The message qualifies for logging; proceed to construct the debug string.

---

DP-004

Condition: bDebugTimeStamp = TRUE

TRUE: The current system time (HH24:MI:SS) is formatted and appended to vcDateStamp for inclusion in the log entry.

FALSE: vcDateStamp remains empty; no timestamp is included in the log entry.

---

DP-005

Condition: iDebugState = 2 (Windows debug viewer mode)

TRUE: Attempt to write to the Windows debug output channel; evaluate API availability (DP-006).

FALSE: Attempt to write to the file-based log channel; evaluate API restoration eligibility (DP-007).

---

DP-006

Condition: DEBUG_API_ENABLED = TRUE (within iDebugState = 2 branch)

TRUE: Call WINDEBUG to write vcDebugString to the Windows debug viewer.

FALSE: The Windows debug API is unavailable; call SETDEBUG to switch to file logging mode, log a fallback notification via recursive DEBUGLOG calls, write the original message to the file, and set bDebugType2Required to TRUE.

---

DP-007

Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (within non-state-2 branch)

TRUE: The Windows debug API has become available again; call SETDEBUG to restore state 2, log a restoration notification, reset bDebugType2Required to FALSE, and recursively call DEBUGLOG to write the original message to the restored channel.

FALSE: No API restoration is pending; open the log file in append mode, write vcDebugString, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A log entry is only written when all three gateway conditions are satisfied simultaneously: debug logging is globally active (iDebugState ≠ 0), logging is not paused (bDebugPaused = FALSE), and the message's DebugLevel does not exceed the configured iDebugLevel threshold.
- BR-002 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to fit within this limit after the fixed prefix (level indicator, timestamp, and padded calling routine name) has been accounted for.
- BR-003 - The calling routine name (LoggingCall) is always right-padded to exactly 30 characters in the log entry to ensure consistent column alignment across all log messages.
- BR-004 - When the Windows debug API (state 2) is unavailable, the system automatically degrades to file-based logging via SETDEBUG without losing the original log message; the intended channel preference is preserved in bDebugType2Required for automatic restoration.
- BR-005 - When file-based logging is active and the Windows debug API becomes available again, SETDEBUG is called to restore the Windows debug channel before the pending message is written, ensuring no messages are permanently diverted to the file after the API recovers.
- BR-006 - Any runtime exception raised within DEBUGLOG is silently suppressed by setting iDebugState to 0, ensuring that a failure in the diagnostic subsystem cannot propagate to and disrupt the calling business process.
- BR-007 - The log file is opened in append mode for each individual write operation and immediately closed afterwards, preventing file handle leaks across multiple logging calls.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-070 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library function D2KWUTIL_GETDOSENV. The function is invoked from WEBUTIL.GETVAR and returns the resolved variable value as a VARCHAR2 string. If the Win32 API layer is unavailable, or if the variable cannot be resolved, the function either raises an exception or returns NULL, depending on the caller-supplied flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-065](#SP-065--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-066](#SP-066--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-067](#SP-067--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-068](#SP-068--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-072](#SP-072--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG, recording the input VariableName and the string representation of RaiseExceptions (converted via BOOLTOCHAR).
- Step 2 - Clear any pre-existing error state on the error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Win32 API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL, supplying the function handle, name, and parameter type signature.
- Step 6 - Prepare the input buffer by wrapping VariableName with percent signs (e.g. %VariableName%) and initialise the output buffer vcBuff2 as a 512-character null-padded string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV, passing the function handle, the wrapped variable name, the output buffer, and the buffer length (512). Store the integer return code in iRC.
- Step 8 - Log the result diagnostics via DEBUGLOG, recording the returned value length (iRC) and the content of the output buffer.
- Step 9 - Evaluate the outcome: if iRC equals 0 or the output buffer still equals the input expression (indicating no substitution occurred), the variable was not found; call ADD_ERROR to record the failure message.
- Step 10 - If the variable was not found and RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise return NULL.
- Step 11 - If the variable was resolved successfully, return the populated output buffer vcBuff2.
- Step 12 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, call ADD_ERROR with the NoAPI message then re-raise; for all other exceptions, call ADD_ERROR with the generic unhandled-error message concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function call and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all resolution logic.

---

DP-002

Condition: iRC equals 0 OR the output buffer vcBuff2 equals the formatted input expression vcBuff1 (i.e. the environment variable was not resolved).

TRUE: The variable could not be found; call ADD_ERROR to record the failure, then branch on RaiseExceptions (see DP-003).

FALSE: The variable was resolved successfully; return vcBuff2 to the caller.

---

DP-003

Condition: RaiseExceptions is TRUE (evaluated only when DP-002 is TRUE).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute environment-variable resolution when the Win32 API layer is active (WIN_API.API_ENABLED = TRUE); if the layer is unavailable the function must raise WIN_API.NOT_AVAILABLE and record the NoAPI error message via ADD_ERROR.
- BR-002 - The environment variable name must be submitted to D2KWUTIL_GETDOSENV wrapped in percent signs (e.g. %VariableName%), conforming to the DOS/Windows environment variable substitution convention.
- BR-003 - A result is considered a failure if D2KWUTIL_GETDOSENV returns a length of 0 or if the output buffer is identical to the formatted input expression, indicating no substitution took place.
- BR-004 - On failure to resolve the variable, an error must always be recorded via ADD_ERROR before any return or exception is raised.
- BR-005 - The caller controls error propagation behaviour through the RaiseExceptions flag: TRUE causes the function to raise NO_DATA_FOUND on resolution failure; FALSE causes the function to return NULL, allowing the caller to handle the absence gracefully.
- BR-006 - All unhandled exceptions must be enriched with external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring the full error context is preserved for upstream handlers.
- BR-007 - Entry and exit diagnostic information (input arguments and resolved value with length) must be written to the debug log via DEBUGLOG at verbosity level 99 for traceability.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-071 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows registry for a specified registry path and entry. It translates a human-readable root key name (e.g., HKEY_LOCAL_MACHINE) into the numeric constant expected by the underlying D2KWUTIL platform call, invokes D2KWUTIL.D2KWUTIL_GETREGKEY to perform the actual registry read, and returns the retrieved value as a VARCHAR2 string. The procedure supports an optional exception-raising mode that allows callers to choose between silent NULL returns and hard exceptions on failure. It is invoked indirectly via WEBUTIL.GETVAR to supply runtime configuration values sourced from the Windows registry.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-065](#SP-065--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-066](#SP-066--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-067](#SP-067--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-068](#SP-068--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-072](#SP-072--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the input arguments RegPath, RegEntry, and the Boolean RaiseExceptions flag (converted to character via BOOLTOCHAR) for traceability.
- Step 2 - Clear the error stack: call CLEAN_ERROR_STACK to reset any previously accumulated errors before processing begins.
- Step 3 - Check API availability: evaluate WIN_API.API_ENABLED; if the Windows API layer is not available, raise WIN_API.NOT_AVAILABLE immediately.
- Step 4 - Register the external function handle: call REGISTER_FUNCTION_CALL to bind the iGetRegKey handle to the D2KWUTIL_GETREGKEY external function signature before use.
- Step 5 - Parse and map the registry root key: extract the root portion of RegPath (the segment before the first backslash), convert it to upper case, and map it to its numeric equivalent (HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4). If the root key is unrecognised, call ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare call parameters: isolate the sub-path (RegPath segment after the first backslash) into vcBuff1, assign RegEntry to vcBuff2, initialise the 2000-byte output buffer vcBuff3 padded with CHR(0), and set the buffer length indicator iBuff2 to 2000.
- Step 7 - Apply compatibility flag: check WIN_API.COMPAT_EXPAND_REG_VALUES; if expansion is suppressed, set iBuff3 to 1 and log a compatibility diagnostic via DEBUGLOG; otherwise set iBuff3 to 0.
- Step 8 - Invoke the registry read: call D2KWUTIL.D2KWUTIL_GETREGKEY with the prepared handle, root numeric code, sub-path, entry name, output buffer, buffer length, and expansion flag; capture the integer return code iRC.
- Step 9 - Log the raw result: call DEBUGLOG (severity 99) recording iRC and the raw contents of vcBuff3.
- Step 10 - Evaluate the return code and handle errors:
  - iRC = -1 (entry not found): call ADD_ERROR; return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
  - iRC = -2 (unsupported data type): call ADD_ERROR; return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
  - iRC = -3 (value exceeds buffer length): call ADD_ERROR; return NULL or raise VALUE_ERROR depending on RaiseExceptions.
  - iRC = -4 (environment string expansion failure): call ADD_ERROR; return NULL or raise NO_DATA_FOUND depending on RaiseExceptions.
- Step 11 - Return the value: if iRC indicates success (none of the error codes above), return vcBuff3 containing the retrieved registry value.
- Step 12 - Exception handling: NO_DATA_FOUND and VALUE_ERROR are re-raised as-is; WIN_API.NOT_AVAILABLE triggers ADD_ERROR with the NoAPI message before re-raising; all other exceptions trigger ADD_ERROR with the generic unhandled-error message concatenated with ADD_EXTERNAL_ERRORS output before re-raising.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with registering the function handle and executing the registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all registry access logic.

DP-002
Condition: The root key segment extracted from RegPath matches one of the five recognised Windows registry hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant (0-4) to iBuff1 and continue.
FALSE: Call ADD_ERROR recording the invalid key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (subsequent D2KWUTIL call will likely fail).

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE (expansion is permitted).
TRUE: Set iBuff3 to 0, allowing D2KWUTIL_GETREGKEY to expand environment strings in the registry value.
FALSE: Set iBuff3 to 1, suppressing environment string expansion, and log a compatibility diagnostic via DEBUGLOG.

DP-004
Condition: iRC returned by D2KWUTIL_GETREGKEY equals -1 (registry entry not found).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Proceed to evaluate subsequent return code values.

DP-005
Condition: iRC equals -2 (registry entry exists but holds an unsupported data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Proceed to evaluate subsequent return code values.

DP-006
Condition: iRC equals -3 (registry value length exceeds the 2000-byte buffer).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise VALUE_ERROR.
FALSE: Proceed to evaluate subsequent return code values.

DP-007
Condition: iRC equals -4 (environment string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: No error condition detected; return vcBuff3 as the retrieved registry value.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch DP-004 through DP-007).
TRUE: Raise the appropriate Oracle exception (NO_DATA_FOUND or VALUE_ERROR) to propagate the failure to the caller.
FALSE: Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED = TRUE) before any registry read is attempted; if the API is unavailable the procedure raises WIN_API.NOT_AVAILABLE unconditionally, regardless of the RaiseExceptions flag.
- BR-002 - RegPath must begin with one of exactly five recognised registry hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other root key is treated as an error.
- BR-003 - The registry value buffer is fixed at 2000 bytes; any registry entry whose value exceeds this limit is reported as an error (iRC = -3) and cannot be partially retrieved.
- BR-004 - Only registry entry data types natively supported by D2KWUTIL_GETREGKEY are readable; entries of unsupported types (iRC = -2) are treated as retrieval failures.
- BR-005 - Environment string expansion within registry values is conditionally applied based on the WIN_API.COMPAT_EXPAND_REG_VALUES flag; when the flag suppresses expansion, the raw unexpanded string is returned.
- BR-006 - The RaiseExceptions parameter governs error propagation behaviour uniformly across all retrieval failure modes (entry not found, unsupported type, buffer overflow, expansion failure): FALSE causes a NULL return, TRUE causes an Oracle exception to be raised.
- BR-007 - All errors encountered during execution are recorded via ADD_ERROR before the procedure either returns NULL or raises an exception, ensuring the error stack is populated for upstream inspection.
- BR-008 - The error stack is cleared at the start of every invocation via CLEAN_ERROR_STACK, so errors from prior calls do not contaminate the current operation's error context.
- BR-009 - Unhandled exceptions in the OTHERS handler are enriched with additional external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, ensuring complete diagnostic information is available to the caller.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-072 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

REGISTER_FUNCTION_CALL ensures that a named DLL function is correctly registered with the Oracle FFI (Foreign Function Interface) layer before it is called by the application. It verifies that the target DLL is loaded, registers the function handle along with all its parameter types and return type, and caches the registration against the current DLL load count to avoid redundant re-registration. If the DLL is unavailable or FFI registration fails, the procedure disables the API and raises a controlled exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-065](#SP-065--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-066](#SP-066--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-057](#SP-057--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the already-loaded DLL by calling ORA_FFI.FIND_LIBRARY using the module-level DLL_NAME constant; if the library is found the procedure continues to Step 3.
- Step 2 - If ORA_FFI.FIND_LIBRARY raises an FFI error (DLL not currently loaded), invoke D2KWUTIL.ATTEMPT_DLL_LOAD with DLL_Path and DLL_NAME to reload the DLL and obtain a fresh handle; if this second attempt also raises an FFI error, set API_ENABLED to FALSE, record an error via ADD_ERROR identifying the missing DLL, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Check the FunctionLoad associative array to determine whether the function identified by FunctionID has been registered and whether its cached load count still matches the current DLL_LOAD_COUNT.
- Step 4 - If registration is required (entry absent or load count mismatch), call ORA_FFI.REGISTER_FUNCTION with the current DLL handle, FunctionName, and the C_STD calling convention to obtain and store a function handle in FunctionHandle(FunctionId).
- Step 5 - Unless the function being registered is 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (Win_API_Debug.DebugLog) recording the function name, current DLL load count, and whether this is an initial registration or a re-registration.
- Step 6 - Parse the FunctionArgs string (comma-delimited, terminated with a trailing comma) in a loop: extract each argument type fragment, translate it to an FFI type constant via D2KWUTIL.TRANSLATETYPE, and register it as a parameter on the function handle using ORA_FFI.REGISTER_PARAMETER; continue until the remaining argument string is NULL, a bare comma, or 'VOID,'.
- Step 7 - If FunctionReturn is neither 'VOID' nor NULL, translate the return type via D2KWUTIL.TRANSLATETYPE and register it on the function handle using ORA_FFI.REGISTER_RETURN.
- Step 8 - Store the current DLL_LOAD_COUNT in FunctionLoad(FunctionId) to cache the registration and prevent unnecessary future re-registration.
- Step 9 - If an FFI error is raised at any point during registration, capture the error details via ADD_EXTERNAL_ERRORS, record them through ADD_ERROR against the FunctionName, and raise NO_DATA_FOUND to signal failure to the caller.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating DLL_NAME.

TRUE: DLL handle is obtained and processing continues to the registration check (DP-002).

FALSE: An FFI error is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is invoked to reload the DLL (DP-002 applies after reload, or DP-001b applies if reload also fails).

---

DP-001b

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in reloading the DLL.

TRUE: A fresh DLL handle is obtained and processing continues to the registration check.

FALSE: An FFI error is raised; API_ENABLED is set to FALSE, ADD_ERROR is called with a 'not found' message, and NO_DATA_FOUND is raised to abort.

---

DP-002

Condition: FunctionLoad array contains an entry for FunctionID AND that entry equals the current DLL_LOAD_COUNT.

TRUE: The function is already validly registered for the current DLL load; no registration steps are performed and the procedure exits normally.

FALSE: The function has never been registered or the DLL has been reloaded since last registration; full registration (Steps 4-8) is performed.

---

DP-003

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: The DEBUGLOG diagnostic call is suppressed to avoid recursive logging.

FALSE: DEBUGLOG is called to record either an initial registration or a re-registration event.

---

DP-004

Condition: FunctionLoad.EXISTS(FunctionId) is TRUE at the time of logging (within the registration block, after DP-003 is FALSE).

TRUE: The function was previously registered but the load count has changed; DEBUGLOG records a re-registration message including the prior load count.

FALSE: The function has never been registered; DEBUGLOG records an initial registration message.

---

DP-005

Condition: During argument parsing, the remaining vcArgs string is NULL, equals ',', or equals 'VOID,'.

TRUE: The parameter registration loop exits; no further parameters are registered.

FALSE: A comma delimiter is found; the next argument fragment is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered as a parameter.

---

DP-006

Condition: FunctionReturn is not 'VOID' (case-insensitive) AND is not NULL.

TRUE: The return type is translated via D2KWUTIL.TRANSLATETYPE and registered on the function handle using ORA_FFI.REGISTER_RETURN.

FALSE: No return type is registered (the function is treated as a void procedure).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable via ORA_FFI.FIND_LIBRARY or successfully reloaded via D2KWUTIL.ATTEMPT_DLL_LOAD before any function registration is attempted; failure to satisfy either condition disables the API (API_ENABLED = FALSE) and prevents further calls.
- BR-002 - A function registration is only performed when the FunctionLoad cache does not contain an entry for FunctionID or when the cached load count differs from the current DLL_LOAD_COUNT, ensuring that stale registrations caused by DLL reloads are always refreshed.
- BR-003 - The function argument list must be supplied as a comma-delimited string; each type token is individually translated by D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER, ensuring type-safe FFI registration.
- BR-004 - A return type is registered only when FunctionReturn is explicitly provided and is not 'VOID'; functions with a VOID or NULL return type are registered without a return type declaration.
- BR-005 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG tracing during its own registration to prevent recursive logging.
- BR-006 - On any FFI error raised during the registration phase, the error details are collected via ADD_EXTERNAL_ERRORS and reported via ADD_ERROR before NO_DATA_FOUND is raised, ensuring that the caller receives a meaningful error context rather than a raw FFI exception.
- BR-007 - Upon successful registration, FunctionLoad(FunctionId) is updated to the current DLL_LOAD_COUNT, establishing the cache entry that governs all subsequent registration checks for that function.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-073 - RUN_REPORT

**Invoked From:**

- st_frm21_fmb.xml [Trigger: FT_PRINT]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN); QUERY DETAILS (N/A / CN_MAIN)

---

**Purpose**

RUN_REPORT is a general-purpose report execution procedure invoked from the FT_PRINT trigger on the Invoice Details and Query Details screens. It locates a named Oracle Reports report object, applies destination-type and server configuration, submits the report for execution, and then either displays the output in a browser window (CACHE/SCREEN/PRINTER) or notifies the user that the output has been spooled to a file (FILE). Any runtime exception is caught, surfaced to the user via GENERAL.DISP_TEXT, and the current form trigger is aborted.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_report_name | varchar2 | IN |
| p_dest_type | varchar2 | IN |
| p_dest_name | varchar | IN |
| P_parameter | varchar2 | IN |
| p_report_server | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the report object within the current Oracle Forms session using the supplied report name (p_report_name) via FIND_REPORT_OBJECT.
- Step 2 - Set the report module property on the located report object to the supplied report name.
- Step 3 - Set the report server property on the report object to the supplied server identifier (p_report_server).
- Step 4 - Apply destination-type-specific properties to the report object based on the value of p_dest_type:
  - If p_dest_type is 'CACHE' or 'SCREEN', set the destination type to CACHE and the output format to HTML.
  - If p_dest_type is 'FILE', default the destination file name to p_report_name when p_dest_name is null; set the destination type to FILE, the output format to PDF, and the destination name to the resolved file name.
  - If p_dest_type is 'PRINTER', set the destination type to PRINTER.
- Step 5 - Apply the caller-supplied parameter string (p_parameter) to the report object via the REPORT_OTHER property, overriding the initial module setting.
- Step 6 - Submit the configured report object for execution via RUN_REPORT_OBJECT and capture the resulting job identifier.
- Step 7 - Retrieve the execution status of the submitted job via REPORT_OBJECT_STATUS.
- Step 8 - Synchronise the Oracle Forms display with the current state.
- Step 9 - Deliver the report output to the user:
  - If p_dest_type is 'CACHE', 'SCREEN', or 'PRINTER', open the report output in a new browser window by constructing a URL from the Reports servlet getjobid endpoint, the extracted job ID, and the server name.
  - If p_dest_type is 'FILE', call GENERAL.DISP_TEXT to display a success notification confirming the report has been spooled to the specified file.
- Step 10 - In the event of any unhandled exception, call GENERAL.DISP_TEXT to display the Oracle error message with severity 'Error', then raise FORM_TRIGGER_FAILURE to halt the triggering form action.

---
**Decision Points**

DP-001

Condition: p_dest_type is 'CACHE' or 'SCREEN'

TRUE: Set the report destination type to CACHE and the output format to HTML.

FALSE: Evaluate subsequent destination-type conditions (DP-002, DP-003).

---

DP-002

Condition: p_dest_type is 'FILE'

TRUE: Resolve the destination file name (see DP-004), set destination type to FILE, output format to PDF, and destination name to the resolved value.

FALSE: Evaluate DP-003.

---

DP-003

Condition: p_dest_type is 'PRINTER'

TRUE: Set the report destination type to PRINTER.

FALSE: No destination-type property is applied (none of the recognised destination types matched).

---

DP-004

Condition: p_dest_type is 'FILE' AND lv_dest_name (derived from p_dest_name) is NULL

TRUE: Default the destination file name to p_report_name before setting the FILE destination properties.

FALSE: Use the caller-supplied p_dest_name as the destination file name.

---

DP-005

Condition: p_dest_type is 'CACHE', 'SCREEN', or 'PRINTER' (post-execution output delivery)

TRUE: Open the report output in a new browser window via the Reports servlet getjobid URL.

FALSE: p_dest_type is 'FILE'; call GENERAL.DISP_TEXT to notify the user that the report has been spooled to the specified file successfully.

---

DP-006

Condition: An unhandled exception occurs at any point during execution

TRUE: Call GENERAL.DISP_TEXT with the Oracle error message (SQLERRM) and severity 'Error', then raise FORM_TRIGGER_FAILURE.

FALSE: Procedure completes normally without exception handling.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The report object identified by p_report_name must already exist within the Oracle Forms session; the procedure does not create report objects dynamically.
- BR-002 - When p_dest_type is 'CACHE' or 'SCREEN', the report is always rendered in HTML format and delivered via the Reports servlet in a new browser window; no file is written.
- BR-003 - When p_dest_type is 'FILE', the report is always rendered in PDF format; if no destination file name is provided (p_dest_name is null), the report name (p_report_name) is used as the file name.
- BR-004 - When p_dest_type is 'PRINTER', no output format or destination name is explicitly set; the report server default printer behaviour applies.
- BR-005 - The caller-supplied parameter string (p_parameter) is applied as the final REPORT_OTHER property, superseding the initial module assignment; this ensures runtime parameters take precedence over the module setting.
- BR-006 - For CACHE, SCREEN, and PRINTER destination types, the job ID is extracted from the run_report_object return value by parsing the substring following the last underscore character, and this ID is used to construct the servlet retrieval URL.
- BR-007 - Any runtime exception must be communicated to the user through GENERAL.DISP_TEXT with severity 'Error' before the form trigger is failed; silent failure is not permitted.
- BR-008 - Upon any exception, FORM_TRIGGER_FAILURE is raised to prevent the calling FT_PRINT trigger from continuing execution.

---
**Implementation Logic**

```plsql

PROCEDURE run_report(p_report_name in varchar2, 
										 p_dest_type in varchar2,
										 p_dest_name in varchar,
										 P_parameter  in varchar2,
										 p_report_server in varchar2) IS
	repid  report_object;
	v_rep varchar2(100);
	rep_status varchar2(20);
	v_str varchar2(500);
	lv_dest_name varchar2(50) := p_dest_name;
BEGIN
	repid := find_report_object(p_report_name);
	set_report_object_property(repid, REPORT_OTHER,'module='||p_report_name); 
	set_report_object_property(repid,REPORT_SERVER,p_report_server);
	if p_dest_type IN ('CACHE','SCREEN') then
		set_report_object_property(repid, report_destype, CACHE);
		set_report_object_property(repid, report_desformat, 'HTML');	 	   
	elsif p_dest_type = 'FILE' then
		If lv_dest_name is null then
			lv_dest_name := p_report_name;
		end if;
		set_report_object_property(repid, report_destype, FILE);
		set_report_object_property(repid, report_desformat, 'PDF');	 	   
		set_report_object_property(repid, report_desname, lv_dest_name);
	elsif p_dest_type = 'PRINTER' then
		set_report_object_property(repid, report_destype, PRINTER);
	end if;
	set_report_object_property(repid, REPORT_OTHER,p_parameter); 
	v_rep := run_report_object(repid);
	rep_status := report_object_status(v_rep);
	synchronize;
	IF P_DEST_TYPE IN ('CACHE','SCREEN','PRINTER') THEN
		web.show_document('/reports/rwservlet/getjobid'||substr(v_rep,instr(v_rep,'_',-1)+1)||'?'||'server='||p_report_server,'_blank');
	elsif P_DEST_TYPE IN ('FILE') THEN
		general.disp_text('Report has been spooled to file '||p_dest_name||' successfully','Note');
	End if;
	Exception
		When Others then
			General.disp_text(SQLERRM,'Error');
			Raise form_trigger_failure;
END;
```

#### SP-074 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the active debug mode, target log file, logging level, and timestamp preference. Depending on the requested debug type, the procedure activates file-based logging, activates message-based logging, or deactivates logging entirely, and records the resulting state change via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-069](#SP-069--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the module-level variable bDebugTimeStamp to control whether log entries include timestamps.
- Step 2 - Store the incoming DebugFile value in the module-level variable vcDebugFile to designate the target log file for subsequent logging operations.
- Step 3 - Store the incoming DebugLevel value in the module-level variable iDebugLevel to set the verbosity threshold for subsequent log entries.
- Step 4 - Evaluate the DebugType parameter to determine which logging mode to activate or whether to deactivate logging.
- Step 5 - If DebugType equals 1, set iDebugState to 1 (file-based logging) and call DEBUGLOG to record that logging to the specified file has begun.
- Step 6 - If DebugType equals 2, set iDebugState to 2 (message-based logging) and call DEBUGLOG to record that logging has started.
- Step 7 - If DebugType is any other value, call DEBUGLOG to record that logging has stopped, then set iDebugState to 0 (logging inactive).

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG with the message 'Logging to File' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging mode) and invoke DEBUGLOG with the message 'Logging Started'.

FALSE: Invoke DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, deactivating all logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the DebugFile parameter must carry the target file path, as it is recorded in vcDebugFile and referenced in the DEBUGLOG confirmation message.
- BR-002 - DebugType = 2 designates message-based logging; no file path is required for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a deactivation instruction, setting the debug state to 0 and stopping all subsequent logging.
- BR-004 - The DebugLevel parameter defaults to 98 if not supplied, establishing the verbosity threshold applied to all subsequent DEBUGLOG calls.
- BR-005 - The TimeStamp parameter defaults to FALSE if not supplied; when TRUE, subsequent log entries will include timestamp information.
- BR-006 - A DEBUGLOG entry is always written when SETDEBUG is called, regardless of the resulting debug state, providing an audit trail of every configuration change.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-075 - SF_GET_FORM21_LOCK

**Invoked From:**

- st_frm21_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

INVOICE DETAILS (N/A / CN_MAIN)

---

**Purpose**

Acquires a pessimistic row-level lock on the SH_INVOICE record that matches the supplied key parameters before the user proceeds with an update on the Invoice Details screen. The procedure uses SELECT ... FOR UPDATE NOWAIT to detect contention immediately rather than allowing the session to hang, and returns a structured error code and message to the caller if the lock cannot be obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc | VARCHAR2 | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_doc_type | VARCHAR2 | IN |
| p_doc_num | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_cd | NUMBER | OUT |
| p_err_msg | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the six input parameters that identify the target invoice: parent group (p_parent), dealer map code (p_dealer), location code (p_loc), company FA (p_comp_fa), document type (p_doc_type), and document number (p_doc_num).
- Step 2 - Evaluate the document type. If p_doc_type equals 'I' (Invoice), proceed to attempt the lock; otherwise skip the lock attempt entirely.
- Step 3 - Execute a SELECT ... FOR UPDATE NOWAIT against SH_INVOICE, filtering on parent_group, dealer_map_cd, loc_cd, comp_fa, and inv_num. Capture the ROWID of the matched row.
- Step 4 - If the SELECT succeeds, set p_err_cd to 0 to signal that the lock was acquired successfully.
- Step 5 - If an exception is raised, set p_err_cd to 1 and populate p_err_msg: if SQLCODE is -54 (resource busy), return a user-friendly contention message; for any other error, return a generic failure message that includes SQLERRM.
- Step 6 - If p_doc_type is not 'I', set p_err_cd to 0 and return without interacting with the database.

---
**Decision Points**

DP-001

Condition:
p_doc_type = 'I'

TRUE:
Attempt to acquire a NOWAIT row-level lock on the matching SH_INVOICE row. Proceed to DP-002 to handle the outcome.

FALSE:
Skip the lock attempt; set p_err_cd to 0 and return immediately.

---

DP-002

Condition:
The SELECT ... FOR UPDATE NOWAIT statement succeeds (no exception raised)

TRUE:
Set p_err_cd to 0, indicating the lock was acquired.

FALSE:
An exception is raised; set p_err_cd to 1 and evaluate SQLCODE to determine the appropriate error message (see DP-003).

---

DP-003

Condition:
SQLCODE = -54 (ORA-00054: resource busy)

TRUE:
Set p_err_msg to 'Record is locked by another user. Try again Later'.

FALSE:
Set p_err_msg to 'Execution failed while trying to lock the record ' concatenated with SQLERRM.

---
**Database Interactions**

- DB-001 - Read SH_INVOICE - Reads data from SH_INVOICE for lookup or validation.
- DB-002 - Update NOWAIT - Updates existing rows in NOWAIT.
**Business Rules**

- BR-001 - A lock attempt is only made when the document type is 'I' (Invoice); all other document types are considered non-lockable by this procedure and receive an immediate success response (p_err_cd = 0).
- BR-002 - The lock is acquired using SELECT ... FOR UPDATE NOWAIT, ensuring the session never waits for a held lock; contention is surfaced to the caller immediately rather than causing the form to hang.
- BR-003 - The SH_INVOICE row is identified by the composite key: parent_group, dealer_map_cd, loc_cd, comp_fa, and inv_num; all five key values must match for the lock to be placed on the correct record.
- BR-004 - An ORA-00054 error (SQLCODE -54) is treated as a distinct business condition and returns the message 'Record is locked by another user. Try again Later' to allow the UI to present a meaningful prompt to the end user.
- BR-005 - Any non-contention exception during the lock attempt is captured and returned via p_err_msg with the Oracle error text appended, ensuring the caller can log or display the root cause.
- BR-006 - A successful outcome (lock acquired or document type not 'I') is always communicated by setting p_err_cd to 0; a failure is always communicated by setting p_err_cd to 1.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sf_Get_FORM21_Lock (
      p_parent      IN       VARCHAR2,
      p_dealer      IN       NUMBER,
      p_loc         IN       VARCHAR2,
      p_comp_fa     IN       VARCHAR2,
      p_doc_type    IN       VARCHAR2,
      p_doc_num     IN       VARCHAR2,
      p_err_cd      OUT      NUMBER,
      p_err_msg     OUT      VARCHAR2
)
IS

	  lv_rowid  ROWID := NULL;
/* Created for the purpose of solving lock issues.If the transaction has to wait for lock then it is hangin'in the middle'
   to avoid all the lock will be acquired in the first time itself'*/
BEGIN
if p_doc_type='I' then
      BEGIN
           SELECT ROWID
		   INTO  lv_rowid
		   FROM sh_invoice
		   WHERE parent_group =P_PARENT
		   		 	AND dealer_map_cd =p_dealer
		  			AND loc_cd=p_loc
					AND comp_fa =P_COMP_FA
					AND INV_NUM =P_DOC_NUM
					FOR UPDATE NOWAIT;
            p_err_cd := 0;
      EXCEPTION
            WHEN OTHERS THEN
                  p_err_cd := 1;

                  IF SQLCODE =-54 THEN
                        p_err_msg := 'Record is locked by another user.Try again Later';
                  ELSE
                        p_err_msg := 'Execution failed while trying to lock the record ' || SQLERRM;
                  END IF;
      END;
else
            p_err_cd := 0;
end if;

END;

```

#### SP-076 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a file-system path string supplied by the caller by removing any trailing content after a semicolon and stripping a trailing backslash character. The cleaned path is returned to the caller (D2KWUTIL.ATTEMPT_DLL_LOAD) so that a well-formed, unambiguous directory path is used when attempting to load a DLL.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-050](#SP-050--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local working copy of the input path (InPath) into a VARCHAR2(500) variable.
- Step 2 - Check whether the working path contains a semicolon character. If one is found, truncate the path to retain only the substring that precedes the first semicolon.
- Step 3 - Check whether the last character of the (possibly truncated) working path is a backslash ('\' ). If it is, remove that trailing backslash by taking all characters except the final one.
- Step 4 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition: INSTR(vcPath, ';') > 0 - the path contains at least one semicolon character.

TRUE: Truncate vcPath to the substring from position 1 up to (but not including) the first semicolon, discarding all content from the semicolon onward.

FALSE: vcPath is left unchanged; processing continues to DP-002.

DP-002

Condition: SUBSTR(vcPath, -1, 1) = '\' - the last character of the (possibly truncated) path is a backslash.

TRUE: Remove the trailing backslash by reassigning vcPath to SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE: vcPath is left unchanged; the path is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path that precedes the first semicolon is considered valid; any content from the semicolon onward is discarded. This prevents multi-path or environment-variable-style strings from being passed as a DLL load directory.
- BR-002 - A trailing backslash must be removed from the path before it is returned, ensuring the directory path does not end with a directory-separator character.
- BR-003 - The input path is accepted as-is up to 500 characters; no other whitespace trimming or character substitution is performed beyond the semicolon and backslash rules above.
- BR-004 - The function is read-only with respect to all external state; it performs no database interactions and produces no side-effects, returning solely the sanitised path string.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-077 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output facility by delegating to the external D2KWUTIL library function D2KWUTIL_DEBUGSTRING. It accepts a text string, appends a newline character, registers the required external function handle via REGISTER_FUNCTION_CALL, and forwards the formatted string to the debug output channel. If the underlying Windows API layer is unavailable or any other runtime error occurs, the procedure captures the error through ADD_ERROR and ADD_EXTERNAL_ERRORS before re-raising, ensuring all failures are surfaced consistently to the calling context (DEBUGLOG in D2kwutil.pld).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-065](#SP-065--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-066](#SP-066--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-072](#SP-072--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the output buffer (vcBuff1).
- Step 2 - Check whether the Windows API layer is active by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function D2KWUTIL_DEBUGSTRING against the debug-string function handle (iDebugString) by calling REGISTER_FUNCTION_CALL, specifying the function name 'd2kwutil_DebugString', no module qualifier (NULL), and the return type '*CHAR'.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle and the formatted buffer (vcBuff1) to write the debug string to the external debug output channel.
- Step 5 - If WIN_API.API_ENABLED is FALSE, raise the WIN_API.NOT_AVAILABLE exception to signal that the API layer is not accessible.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception.
- Step 7 - On any other exception, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function handle via REGISTER_FUNCTION_CALL and forward the formatted debug string to D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all debug-output logic.

---

DP-002

Condition: A WIN_API.NOT_AVAILABLE exception is caught in the exception block.

TRUE: Call ADD_ERROR with procedure name 'WinDebug' and the WIN_API.NoAPI error code, then re-raise the exception to the caller.

FALSE: Fall through to the WHEN OTHERS handler if a different exception has been raised.

---

DP-003

Condition: An exception other than WIN_API.NOT_AVAILABLE is caught (WHEN OTHERS).

TRUE: Call ADD_ERROR with procedure name 'WinDebug' and a composite message formed by WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception.

FALSE: Not applicable; this handler captures all remaining exception types.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text string must always be suffixed with a newline character (CHR(10)) before being passed to the external debug function; this formatting is mandatory and applied unconditionally.
- BR-002 - Debug-string output is only permitted when the Windows API layer is active (WIN_API.API_ENABLED = TRUE); any attempt to write a debug string while the API is unavailable must result in a WIN_API.NOT_AVAILABLE exception.
- BR-003 - The external function D2KWUTIL_DEBUGSTRING must be registered via REGISTER_FUNCTION_CALL using the handle iDebugString, the literal function name 'd2kwutil_DebugString', and the return type '*CHAR' before each invocation; no direct call to the external function is permitted without prior registration.
- BR-004 - All exceptions must be re-raised after error recording, ensuring that the calling procedure (DEBUGLOG) receives notification of any failure rather than allowing silent suppression.
- BR-005 - API-unavailability errors must be recorded using ADD_ERROR with the WIN_API.NoAPI error code; all other errors must be recorded using ADD_ERROR with a composite message combining WIN_API.UError and the output of ADD_EXTERNAL_ERRORS.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

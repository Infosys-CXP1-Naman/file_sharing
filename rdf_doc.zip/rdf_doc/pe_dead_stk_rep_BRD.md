# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Business Scenarios - How the field layout differs by report type
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Dead Stock Liquidation Transactions - PS_DEAD_STOCK
    - Dead Stock Inventory - PM_PART_DEAD_STOCK
    - Dealer and Location Master - AM_DEALER_LOC
    - Parts Master - PM_PART
    - Part Category Master - PM_CATEGORY
    - Transaction Type Reference - AM_LIST (MULDMS.AM_LIST)
    - State Master - GM_STATE
    - City Master - GM_CITY
    - Stock Bin Location - PM_STOCK_BIN_LOC (MULDMS.PM_STOCK_BIN_LOC)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (User - report request entry)
    - Session and Parameter Tracking (System - non-database flags)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - VIEW_EXCEL_REP
    - SP-002 - GENERAL.ASK_CONFIRM
    - SP-003 - GENERAL.DISP_TEXT
    - SP-004 - GENERAL.L_POP_LIST_ITEM
    - SP-005 - WEBUTIL.ERRORALERT
    - SP-006 - WEBUTIL.FCLOSE
    - SP-007 - WEBUTIL.FOPEN
    - SP-008 - WEBUTIL.GETIMPLCLASS
    - SP-009 - WEBUTIL.GETPROPERTY
    - SP-010 - WEBUTIL.GET_LINE
    - SP-011 - WEBUTIL.ID_NULL
    - SP-012 - WEBUTIL.PUT_LINE
    - SP-013 - WEBUTIL.SETPROPERTY

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PS_DEAD_STOCK - Business Requirements Document |
| Form Module Name | PS_DEAD_STOCK |
| Document Version | 1.0 |
| Date Created | August 13, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 13, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the ps_dead_stock Dead Stock Report form, its purpose, and roles referenced in the module.*

The **ps_dead_stock** Oracle Forms module is the dealership **Dead Stock Report** screen. Users open the form, select report criteria - including consignee, state, dealer, location, part category, and report type - and generate an Excel-compatible export of either dead stock inventory or liquidation parts activity. The form applies mandatory field checks to ensure all required filter values are entered before the report is produced. Once criteria are confirmed, the report data is assembled and downloaded directly to the user's browser as a spreadsheet file. The form is read-only with respect to parts and stock data; it does not allow any stock record to be created, edited, or deleted.

### Key Stakeholders

*Who uses ps_dead_stock*

| Stakeholder | Role |
| :--- | :--- |
| **Parts Manager / Inventory Analyst** | Primary interactive user of the ps_dead_stock form. Selects report criteria, applies optional part and date filters, chooses the report type and price basis, and generates the dead stock or liquidation report as an Excel export. |
| **Dealer / Consignee** | Business entity whose stock data is reported; represented by the consignee code and dealer name filter values entered by the user. |

---

---

## 3. System Context

*Describes the ps_dead_stock module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **ps_dead_stock** module is the dealership **Dead Stock Report** screen within the Dealer Management System (DMS). It provides authorised users with a self-service reporting tool to identify and analyse parts that are slow-moving, surplus, or subject to liquidation across selected dealers and locations. The form is the front-end entry point for generating Excel-compatible stock reports, connecting the user's filter selections to the underlying parts stock and dealer location data maintained in the DMS.

**System purpose:** Allow authorised users to select dealer, location, and parts filter criteria, choose a report type (dead stock or liquidation, detail or summary), and produce an Excel export of matching stock data - as implemented in the ps_dead_stock Oracle Forms module.

**In scope:**

- Filter dealer data by consignee code, state, dealer name, and location code using validated lookup lists
- Optionally narrow the report by part number, root part number, and part category
- Select the report type: Liquidation Detail, Liquidation Summary, Inventory Detail, or Inventory Summary
- Apply additional filters for sale type (Warranty, Contract, Internal, All, Warranty+Contract) and price basis (Basic, MRP, Landed, DDL) for liquidation reports
- Specify a date range (from-date and to-date) for liquidation activity reports
- Validate all mandatory filter fields before allowing report generation
- Build and execute a dynamic SQL query against the parts stock tables based on selected criteria
- Export the report results as a CSV/Excel file and open it in the user's browser
- Clear the form and reset filter criteria for a new report run

**Process Name:** Dead Stock Report Generation

**Process Owner:** Parts Manager

**Process Objective:** Open the Dead Stock Report screen, select dealer and parts filter criteria, validate all mandatory fields, choose the report type and parameters, and generate an Excel export of dead stock or liquidation parts data.

**Process Trigger:** A Parts Manager or Inventory Analyst requires a report on dead, slow-moving, or liquidation parts for a specific dealer and location.

**Process Flow:**

The complete dead stock report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The Dead Stock Report screen opens and is maximised to full screen.
         The part-category filter list is populated from the parts category master.
         The date range fields are pre-set to today's date.

STEP 2 ── SESSION INITIALISATION
         The application session is registered with the database for monitoring.
         The report type defaults to the first available option.
         Fields controlled by report type (sale type, dates, price basis) are enabled
         or disabled based on the default selection.

STEP 3 ── SELECT CONSIGNEE CODE
         User opens the consignee LOV and selects a consignee/dealer code.
         The list is filtered by the logged-in user's principal and parent group.
         An "ALL" option is available for users with unrestricted access.
         Consignee code is validated as mandatory before the user can proceed.

STEP 4 ── SELECT STATE
         The state LOV opens automatically when the user navigates to the state field.
         User selects a state from the list filtered by consignee code and principal.
         An "ALL" option is available for unrestricted users.
         State code is validated as mandatory.

STEP 5 ── SELECT DEALER NAME
         The dealer LOV opens automatically when the user navigates to the dealer name field.
         User selects a dealer from the list filtered by consignee code and state.
         An "ALL" option is available for applicable users.
         Dealer name is validated as mandatory.

STEP 6 ── SELECT LOCATION
         The location LOV opens automatically when the user navigates to the location field.
         User selects a dealer location filtered by consignee, state, and dealer name.
         On selection, the internal dealer map code is derived from the dealer location master.
         Location code is validated as mandatory.

STEP 7 ── OPTIONAL: ENTER PART NUMBER FILTER
         User optionally enters a specific part number to narrow the report results.
         If left blank, all parts matching other criteria are included.

STEP 8 ── OPTIONAL: ENTER ROOT PART NUMBER FILTER
         User optionally enters a root part number to further restrict results.
         If left blank, all root part numbers are included.

STEP 9 ── OPTIONAL: SELECT PART CATEGORY FILTER
         User optionally selects a part category from the category list.
         The list is populated from the part category master for the current principal.

STEP 10 ── SELECT REPORT TYPE
          User selects the report type from the list:
          ├── Liquidation Detail (L): shows individual liquidation transactions by part
          ├── Liquidation Summary (LS): shows summarised liquidation data by part
          ├── Inventory Detail (I): shows current dead stock inventory by part
          └── Inventory Summary (IS): shows summarised dead stock inventory by part
          The form enables or disables the sale type, date range, and price basis
          fields automatically based on the selected report type.

STEP 11 ── SELECT SALE TYPE - Liquidation reports only
          For Liquidation Detail or Summary, user selects the sale type filter:
          Warranty, Contract, Internal, All, or Warranty+Contract.

STEP 12 ── SELECT PRICE BASIS - Liquidation reports only
          For Liquidation reports, user selects the price unit:
          Basic, MRP, Landed, or DDL.

STEP 13 ── ENTER DATE RANGE - Liquidation reports only
          For Liquidation reports, user confirms or adjusts the from-date and to-date.
          Both date fields are validated as mandatory for liquidation report types.

STEP 14 ── GENERATE EXCEL REPORT
          User presses the "Excel Report" button.
          The form validates that all mandatory filter fields (consignee, state,
          dealer name, location, from-date, to-date where required) are filled.
          A dynamic SQL query is built from all selected criteria.
          The query is executed against the stock and location tables.
          Results are written to a CSV file on the server.
          The file is opened in the user's browser as an Excel-compatible download.

STEP 15 ── REVIEW OR CLEAR
          ├── User reviews the downloaded report in Excel.
          └── To run another report: user presses Cancel or Clear to reset the form.
              Filter criteria are cleared and date fields are reset to today.
              The form is ready for a new report run.

STEP 16 ── EXIT
          User closes the form via the Exit button or keyboard shortcut.
          The application session registration is cleared before exit.
```

**Major process interactions:**

- **Dealer location master** - provides the consignee, state, dealer, and location lookup data used to filter report criteria
- **Geographic state master** - provides state codes and descriptions for the state filter lookup
- **Parts stock bin location data** - source of dead stock and liquidation quantity data included in the generated report
- **Part category master** - provides part category codes and descriptions for the category filter list on form startup
- **File system / report server** - receives the generated CSV file and serves it to the user's browser as an Excel download

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialisation - Window Setup, Part Category List Population, and Default Date Assignment

**Business Description:**
When the Dead Stock report screen is opened, the system automatically maximises the window to fill the display, loads the list of available part categories (filtered to the current dealer organisation) with an "All" option included, sets the Part Category filter to "All" by default, and pre-fills both the From Date and To Date with today's date so the user can begin entering report criteria immediately without additional setup.

**Actors:** Dealer Parts User

**Preconditions:**
- The user has launched the Dead Stock report screen from the application menu.

**Main Flow:**

**Step 1 - Maximise the report window**
The report screen opens and the system automatically expands the main window to fill the available display area, providing the user with maximum working space.

**Step 2 - Load the Part Category selection list**
The system retrieves all part categories associated with the current dealer organisation, including an "All" option that allows the user to run the report across every category. The record group `P_CATG` is built from the part category master for the current principal and the resulting list is made available in the Part Category filter drop-down (`CNTRL_BLK.P_CATG`).

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-004](#sp-004)) - GENERAL.L_POP_LIST_ITEM - builds record group `P_CATG` from the part category data for the current principal and makes it available to the Part Category drop-down field (`CNTRL_BLK.P_CATG`). If the record group already exists it is removed and rebuilt before being applied to the list.
    * **Step 1** - Check whether a record group with the target name already exists; if it does, delete it to ensure a clean rebuild.
    * **Step 2** - Create a new record group by executing the provided query, which retrieves all category descriptions and codes (`CATG_DESC`, `CATG_CD`) for the current dealer organisation from `PM_CATEGORY`, plus an "All" option.
    * **Step 3** - Populate the newly created record group with data from the query result.

**Step 3 - Apply the Part Category list to the filter drop-down**
The system binds the freshly populated record group `P_CATG` to the Part Category drop-down control (`CNTRL_BLK.P_CATG`) on screen, using `POPULATE_LIST`, so the user can pick from the available categories.

**Step 4 - Default the Part Category filter to "All"**
The Part Category filter is set to "All" so that, unless the user explicitly narrows the selection, the report will cover all part categories.

**Step 5 - Default From Date and To Date to today**
Both the From Date and To Date filter fields are automatically populated with the current system date, giving the user a ready-to-use date range that can be adjusted if needed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Category (`P_CATG`) | Auto-populated | List item | N/A | Part Category master (PM_CATEGORY) | Category description / code, plus "ALL" option | Form open | System sets default to "All" on initialisation | N/A |
| From Date (`P_FROMDT`) | Auto-populated | Date | DD/MM/RRRR | N/A | N/A | Form open | System sets default to today's date on initialisation | N/A |
| To Date (`P_TODT`) | Auto-populated | Date | DD/MM/RRRR | N/A | N/A | Form open | System sets default to today's date on initialisation | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Report Type Selection - Automatic Field Enable/Disable Based on Report Category

**Business Description:**
When the user selects a report type, the system automatically adjusts which other filter fields are available. Choosing an inventory-based report type disables the date range, sale type, and price type filters (because inventory reports are always as-of today and cover all sale and price dimensions by default) and resets those fields to today's date and a fixed price basis. Choosing a liquidation-based report type re-enables and makes navigable the date range, sale type, and price type filters so the user can specify the desired reporting period and transaction criteria.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.
- The user has navigated to the Report Type selection field.

**Main Flow:**

**Step 1 - User selects a report type from the drop-down**
The user selects a value from the Report Type drop-down. The system responds immediately when the selected value changes.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - System applies field restrictions appropriate to the selected report type**
The system examines the selected report type and applies one of two behaviours:

- If an inventory-based report type is selected (either the detailed inventory view or the inventory summary view): the From Date and To Date are both reset to today's date; the Price Type is automatically set to the DDL (delivered price) basis; and the Sale Type, From Date, To Date, and Price Type fields are all disabled so the user cannot change them, because inventory reports reflect the current stock position and do not require date-range or sale-type input.

- If a liquidation-based report type is selected (either the detailed liquidation view or the liquidation summary view): the Sale Type, From Date, To Date, and Price Type fields are all enabled and made navigable so the user can enter the desired date range, sale type, and price basis for the liquidation analysis.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report type determines which filter fields are accessible | Report type branch in WHEN-LIST-CHANGED trigger on CNTRL_BLK.REPORT_TYPE | When the user changes the Report Type selection | Ensures that only the filter criteria relevant to the chosen report type are available for input, preventing invalid parameter combinations (e.g. a date range on an inventory report). | N/A - this is automatic system behaviour; if the report type does not match either branch, no fields are changed. |

#### Business Scenarios - How the field layout differs by report type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Inventory report selected (detailed or summary)** | From Date and To Date are reset to today; Price Type is set to the DDL basis; Sale Type, From Date, To Date, and Price Type are disabled so the user cannot alter them. |
| **Liquidation report selected (detailed or summary)** | Sale Type, From Date, To Date, and Price Type are all enabled and made navigable so the user can specify the date range and transaction criteria for the liquidation analysis. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List item | N/A | N/A | Inventory detail / Inventory summary / Liquidation detail / Liquidation summary | Form open | Must be selected before generating the report | N/A |
| From Date (`P_FROMDT`) | Conditional - when liquidation report selected | Date | DD/MM/RRRR | N/A | N/A | Report Type selected | Reset to today's date and disabled when inventory report selected; enabled and navigable when liquidation report selected | N/A |
| To Date (`P_TODT`) | Conditional - when liquidation report selected | Date | DD/MM/RRRR | N/A | N/A | Report Type selected | Reset to today's date and disabled when inventory report selected; enabled and navigable when liquidation report selected | N/A |
| Sale Type (`SALE_TYPE`) | Conditional - when liquidation report selected | List item | N/A | N/A | N/A | Report Type selected | Disabled when inventory report selected; enabled and navigable when liquidation report selected | N/A |
| Price Type (`PRICE_UNIT`) | Conditional - when liquidation report selected | List item | N/A | N/A | N/A | Report Type selected | Set to DDL basis and disabled when inventory report selected; enabled and navigable when liquidation report selected | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Cancel / Clear All Report Criteria

**Business Description:**
When the user clicks the Cancel button, the system checks whether any report criteria have been entered or changed. If changes are present, the user is asked to confirm that unsaved data will be lost before the screen is cleared. If the user confirms, or if no changes were made, all filter fields on the screen are cleared and reset to their initial state: the date filters revert to today's date, and the date range, sale type, and price type fields are re-enabled and made navigable so the user can start fresh.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.
- The Cancel button is active and available for the user to press.

**Main Flow:**

**Step 1 - User presses the Cancel button and the system checks whether it is active**
The user presses the Cancel button. Before taking any action, the system checks whether the Cancel button is currently enabled. If it is not enabled, no action is taken and the form stays exactly as it is.

**Step 2 - System checks whether any report criteria have been entered or changed**
If the Cancel button is enabled, the system checks whether the user has entered or modified any filter criteria since the screen was last cleared or opened. If changes are present, the user is asked to confirm before the screen is cleared. If no changes are present, the screen is cleared immediately without a prompt.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-002](#sp-002)) - GENERAL.ASK_CONFIRM - displays a confirmation dialog asking the user whether to proceed knowing that entered data will not be saved. Returns 1 if the user clicks the first button (confirm) and 0 otherwise.
    * **Step 1** - Set the text of the confirmation dialog to the message passed by the caller - in this case *"Entered data will not be Saved"*.
    * **Step 2** - Display the confirmation alert to the user and wait for a button press.
    * **Step 3** - If the user presses the first (confirm) button, return 1 to indicate confirmation; otherwise return 0 to indicate cancellation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Cancel button must be enabled before any action is taken | `GET_ITEM_PROPERTY('PB_BLK.PB_CANCEL', ENABLED)` check in FT_CANCEL | When the user clicks the Cancel button | Prevents the cancel/clear action from running when the Cancel button is not in an active state. | No action; the screen remains unchanged. |
| User confirms loss of unsaved data when changes are present | User confirmation - GENERAL.ASK_CONFIRM [SP-002] | When the user clicks Cancel and the system detects that filter criteria have been modified | Protects the user from accidentally losing entered criteria without a warning. | User clicks the second button (decline); the clear is aborted and all entered criteria remain on screen. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-WS-01** - Unsaved filter criteria are present when the user clicks Cancel - *"Entered data will not be Saved"*; user must confirm to proceed with clearing the screen.

**Step 3 - Clear all filter criteria and reset the screen to initial state**
Once the clear is confirmed (or no changes were present), the system clears all filter criteria from the screen. The From Date and To Date are immediately reset to today's date. The date range, sale type, and price type fields are set to enabled and navigable so the user can immediately begin entering new criteria. The Part Category filter is reset to "All".

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROMDT`) | Auto-populated | Date | DD/MM/RRRR | N/A | N/A | Cancel confirmed or no changes present | Reset to today's date on clear; field re-enabled and navigable | N/A |
| To Date (`P_TODT`) | Auto-populated | Date | DD/MM/RRRR | N/A | N/A | Cancel confirmed or no changes present | Reset to today's date on clear; field re-enabled and navigable | N/A |
| Sale Type (`SALE_TYPE`) | Mandatory | List item | N/A | N/A | N/A | Cancel confirmed or no changes present | Field re-enabled and navigable on clear | N/A |
| Price Type (`PRICE_UNIT`) | Mandatory | List item | N/A | N/A | N/A | Cancel confirmed or no changes present | Field re-enabled and navigable on clear | N/A |
| Part Category (`P_CATG`) | Auto-populated | List item | N/A | Part Category master (PM_CATEGORY) | Category description / code, plus "ALL" option | Cancel confirmed or no changes present | Reset to "All" on clear | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Report Filter Field Validation - Mandatory Criteria and Location Mapping

**Business Description:**
Before the Dead Stock report can be generated, the user must supply valid values for a set of mandatory filter fields: Consignee Code, State, Dealer Name, Location, From Date, and To Date. When the user leaves any of these fields without a value, the system immediately alerts them and prevents the cursor from moving forward. For the Location filter, the system also performs an additional step: once a specific location (other than "All") is entered, it automatically looks up and derives the internal dealer mapping code associated with that location within the current dealer group, so the downstream report query can use the precise location identifier.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.
- The user is entering report filter criteria on the Dead Stock screen.

**Main Flow:**

**Step 1 - User enters or selects the Consignee Code**
The user enters a value in the Consignee Code field (or selects one from the lookup list). When the user attempts to leave the field, the system checks that a value has been entered.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Consignee Code must not be blank | `CNTRL_BLK.CONSG_CD IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.CONSG_CD; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the Consignee Code field | Ensures the report has a valid consignee scope before it is run; a missing consignee would produce an unscoped or invalid result. | *"consignee code cannot be null"* is displayed; the trigger aborts and the cursor remains on the Consignee Code field. |

**Step 2 - User enters or selects the State**
The user enters or selects a State value. The State lookup is automatically presented when the user navigates into the State field. When the user attempts to leave the field, the system checks that a value has been entered.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| State must not be blank | `CNTRL_BLK.STATE_CD IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.STATE_CD; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the State field | Ensures the report is scoped to a known state; without a state value, the location hierarchy cannot be resolved. | *"State Name cannot be null"* is displayed; the trigger aborts and the cursor remains on the State field. |

**Step 3 - User enters or selects the Dealer Name**
The user enters or selects a Dealer Name. The dealer lookup is automatically presented when the user navigates into the Dealer Name field. When the user attempts to leave the field, the system checks that a value has been entered.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer Name must not be blank | `CNTRL_BLK.DEALER_NAME IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.DEALER_NAME; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the Dealer Name field | Ensures the report is scoped to an identified dealer; without a dealer, the report data cannot be attributed. | *"dealer_name cannot be null"* is displayed; the trigger aborts and the cursor remains on the Dealer Name field. |

**Step 4 - User enters or selects the Location and system derives the dealer mapping code**
The user enters or selects a Location value. The location lookup is automatically presented when the user navigates into the Location field. When the user attempts to leave the field, the system first checks that a value has been entered, then - if the location selected is a specific location (not "All") - looks up the unique dealer mapping code for that location within the current dealer group and the current dealer organisation, and stores it for use in the report query.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Location must not be blank | `CNTRL_BLK.LOC_CD IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.LOC_CD; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the Location field | Ensures the report has a defined location scope; a missing location would make it impossible to resolve the correct dealer site. | *"Location cannot be null"* is displayed; the trigger aborts and the cursor remains on the Location field. |
| Dealer mapping code derived from selected location | `SELECT DISTINCT DEALER_MAP_CD FROM AM_DEALER_LOC` in WHEN-VALIDATE-ITEM on CNTRL_BLK.LOC_CD | After Location passes the null check, when the user leaves the Location field with a specific (non-"All") value | Ensures the internal dealer site identifier is correctly resolved and available for the report query. | If "All" is selected for Location, the dealer mapping code is set to "All" and no database lookup is needed. |

**Step 5 - User enters the From Date**
The user enters a From Date for the report period. When the user attempts to leave the field, the system checks that a value is present.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be blank | `CNTRL_BLK.P_FROMDT IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.P_FROMDT; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the From Date field | Ensures the report has a valid start date for the reporting period. | *"enter from date"* is displayed; the trigger aborts and the cursor remains on the From Date field. |

**Step 6 - User enters the To Date**
The user enters a To Date for the report period. When the user attempts to leave the field, the system checks that a value is present.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must not be blank | `CNTRL_BLK.P_TODT IS NULL` check in WHEN-VALIDATE-ITEM on CNTRL_BLK.P_TODT; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to leave the To Date field | Ensures the report has a valid end date for the reporting period. | *"enter to date"* is displayed; the trigger aborts and the cursor remains on the To Date field. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Consignee Code left blank - *"consignee code cannot be null"*; cursor stays on the Consignee Code field.
- **BR-004-ES-02** - State left blank - *"State Name cannot be null"*; cursor stays on the State field.
- **BR-004-ES-03** - Dealer Name left blank - *"dealer_name cannot be null"*; cursor stays on the Dealer Name field.
- **BR-004-ES-04** - Location left blank - *"Location cannot be null"*; cursor stays on the Location field.
- **BR-004-ES-05** - From Date left blank - *"enter from date"*; cursor stays on the From Date field.
- **BR-004-ES-06** - To Date left blank - *"enter to date"*; cursor stays on the To Date field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consignee Code (`CONSG_CD`) | Mandatory | Text | 15 | Consignee lookup (LV_CONSG / RG_CONSG - AM_DEALER_LOC) | Consignee code | Form open | Must not be blank when leaving the field | *"consignee code cannot be null"* |
| State (`STATE_CD`) | Mandatory | Text | N/A | State lookup (LV_STATE / RG_STATE - GM_STATE, AM_DEALER_LOC); auto-presented on field entry | State code | Consignee Code entered | Must not be blank when leaving the field | *"State Name cannot be null"* |
| Dealer Name (`DEALER_NAME`) | Mandatory | Text | 50 | Dealer lookup (LV_DEALER / RG_DEALER - AM_DEALER_LOC); auto-presented on field entry | Dealer name | State entered | Must not be blank when leaving the field | *"dealer_name cannot be null"* |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LV_LOC / RG_LOC - AM_DEALER_LOC); auto-presented on field entry | Location code | Dealer Name entered | Must not be blank when leaving the field; dealer mapping code derived when a specific location is selected | *"Location cannot be null"* |
| From Date (`P_FROMDT`) | Mandatory | Date | DD/MM/RRRR | N/A | N/A | Report Type selected (enabled for liquidation types) | Must not be blank when leaving the field | *"enter from date"* |
| To Date (`P_TODT`) | Mandatory | Date | DD/MM/RRRR | N/A | N/A | Report Type selected (enabled for liquidation types) | Must not be blank when leaving the field | *"enter to date"* |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Generate and Download Dead Stock Excel Report

**Business Description:**
When the user clicks the Excel Report button, the system compiles the report data matching the selected filter criteria into a CSV-formatted file and makes it available for the user to open or download directly in the browser. The report query is dynamically constructed according to the chosen report type, covering dead stock inventory levels (current on-hand quantity and value) or dead stock liquidation transactions, and filtered by consignee, state, dealer, location, date range (where applicable), sale type (where applicable), price basis, part category, and optionally a specific part number or root part number. The resulting file is written to the report server and then opened in a new browser window.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.
- All mandatory filter fields have been filled and validated: Consignee Code, State, Dealer Name, and Location have values; Report Type has been selected; From Date and To Date are populated (required for liquidation report types).

**Main Flow:**

**Step 1 - Initialise filter parameters and build optional part number conditions**
The user clicks the Excel Report button. The system initialises the four dynamic query filter parameters (for liquidation part stock, inventory part stock, root part number, and sale type) to empty. If the user has entered a specific Part Number, an additional filter clause restricting the report to that part number is appended to both the liquidation and inventory parameter strings. If the user has entered a Root Part Number, an additional clause restricting results to that root part is added to the root part parameter string.

**Step 2 - Build the sale type filter clause based on the selected sale type**
If the Sale Type filter has a value, the system builds the appropriate dynamic SQL clause for the selected transaction category. Wholesale transactions include bill type and billing type list entries; customer sale transactions include specific document type codes for customer sales, returns, and transfers; internal fleet transactions include the internal fleet document type code; "All" includes all document types and billing types. A combined wholesale-and-customer sale option is also available.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

**Step 3 - Construct the data query for the selected report type**
The system constructs the full data retrieval query based on the selected report type:
- **Liquidation detail**: retrieves individual dead stock liquidation transactions including dealer, state, consignee code, location, part number, part description, value (using the selected price basis: Basic, MRP, Landed, or DDL), customer segment, customer details, date of liquidation, and part category.
- **Inventory detail**: retrieves current on-hand dead stock quantities and values per part per location, calculating quantity and value from the current bin stock records.
- **Liquidation summary**: aggregates liquidation values by dealer, state, consignee code, location, and part category.
- **Inventory summary**: aggregates current dead stock values by dealer, state, consignee code, location, and part category.

All queries apply the dealer group, dealer mapping code, location, consignee, state, principal organisation, and part category filters selected by the user.

*Screen: DEAD STOCK (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Generate the output file and open it in the browser**
The system calls the report file generation routine, passing the constructed query and the target filename (based on the logged-in user's identifier and the current date and time). The routine writes the query results to a CSV file on the report server and then opens the file in a new browser window so the user can view or save it.

*Procedures called:*
- **VIEW_EXCEL_REP** ([SP-001](#sp-001)) - VIEW_EXCEL_REP - generates the CSV report file on the server from the supplied query and opens it in a new browser window for the user.
    * **Step 1** - Determine the output filename from the current user ID and timestamp; if the file path contains a space character, redirect the file to the root of the C drive and notify the user that the default storage location is being used instead.
    * **Step 2** - Check whether a record group with the working name already exists; if it does, delete it to ensure a clean rebuild.
    * **Step 3** - Create a new record group by executing the supplied query.
    * **Step 4** - Populate the record group with the query results.
    * **Step 5** - Check the number of rows returned; if the row count exceeds 65,536, notify the user that the output will be truncated and limit the written rows to 65,535.
    * **Step 6** - Determine the server-side output file path; read the base URL path from a configuration file stored on the report server.
    * **Step 7** - Open the output file on the server for writing and write each row from the record group to the file, then close the file.
    * **Step 8** - Open the generated CSV file in a new browser window using the server URL, so the user can view or save the report.
    * **Step 9** - On any unexpected error during the above steps, display the system error code and message and abort further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces | Filename space check (`INSTR(FILENAME,' ') > 0`) in VIEW_EXCEL_REP [SP-001] | When the Excel Report button is clicked and the filename is derived | Ensures the output file can be saved at the derived path; paths with spaces would cause the file write to fail. | File is redirected to C:\ root; user sees *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* and processing continues. |
| Report output must not exceed the maximum supported row count | Row count check (`> 65536`) in VIEW_EXCEL_REP [SP-001] | After the record group is populated from the query results | Prevents the report from producing a file that exceeds the row limit; excess rows would not be written and the user would receive an incomplete report without this warning. | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* is displayed and the output is truncated to 65,535 rows; processing continues with the truncated set. |
| No unexpected errors during file generation | WHEN OTHERS exception handler in VIEW_EXCEL_REP [SP-001] | During any step of the file creation or data retrieval process | Ensures that any unhandled database or file system error is communicated to the user rather than failing silently. | A message combining the system error code and error description text is shown: *"Error  - "* followed by the error code and error text; trigger is aborted. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-IC-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - the file is redirected to C:\ and the report proceeds.
- **BR-005-IC-02** - Row count exceeds limit - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - report output is truncated to 65,535 rows.
- **BR-005-ES-01** - Unexpected error during file generation or query execution - message combining the error code and system error description text (*"Error  - "* + error code + error text); trigger aborts.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 3) Report type is not one of the four supported values: no query is built; `VIEW_EXCEL_REP` is called with an empty or null query string, which may produce an empty output file.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Type (`REPORT_TYPE`) | Mandatory | List item | N/A | N/A | Inventory detail / Inventory summary / Liquidation detail / Liquidation summary | Form open | Determines which query template is used | N/A |
| Consignee Code (`CONSG_CD`) | Mandatory | Text | 15 | Consignee lookup (LV_CONSG / RG_CONSG) | Consignee code | Validated on field exit | Applied as filter in the query | N/A |
| State (`STATE_CD`) | Mandatory | Text | N/A | State lookup (LV_STATE / RG_STATE) | State code | Validated on field exit | Applied as filter in the query | N/A |
| Dealer Name (`DEALER_NAME`) | Mandatory | Text | 50 | Dealer lookup (LV_DEALER / RG_DEALER) | Dealer name | Validated on field exit | Applied as filter in the query | N/A |
| Location (`LOC_CD`) | Mandatory | Text | N/A | Location lookup (LV_LOC / RG_LOC) | Location code | Validated on field exit | Applied as filter; dealer mapping code derived from this value | N/A |
| From Date (`P_FROMDT`) | Conditional - required for liquidation report types | Date | DD/MM/RRRR | N/A | N/A | Report type is liquidation; validated on field exit | Applied as the start date boundary in the liquidation query | N/A |
| To Date (`P_TODT`) | Conditional - required for liquidation report types | Date | DD/MM/RRRR | N/A | N/A | Report type is liquidation; validated on field exit | Applied as the end date boundary in the liquidation query | N/A |
| Sale Type (`SALE_TYPE`) | Conditional - required for liquidation report types | List item | N/A | N/A | Wholesale / Customer sale / Internal fleet / All / Wholesale and customer | Report type is liquidation | Drives the sale type filter clause appended to the liquidation query | N/A |
| Price Type (`PRICE_UNIT`) | Conditional - required for liquidation report types | List item | N/A | N/A | Basic / MRP / Landed / DDL | Report type is liquidation | Determines which price column is used in the value calculation | N/A |
| Part Number (`PART_NUM`) | Optional | Text | N/A | N/A | N/A | N/A | If entered, restricts the report to that specific part number | N/A |
| Root Part Number (`ROOT_PART_NUM`) | Optional | Text | N/A | N/A | N/A | N/A | If entered, restricts the report to parts matching that root part number | N/A |
| Part Category (`P_CATG`) | Optional | List item | N/A | Part Category master (PM_CATEGORY) | Category description / code, plus "ALL" option | Loaded on form open | If "All" is selected, no category filter is applied; otherwise restricts the report to the chosen category | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Insert and Delete Operations Blocked on This Form

**Business Description:**
The Dead Stock report screen is a read-only reporting screen. If a user attempts to use the Insert or Delete toolbar actions while those buttons are enabled, the system immediately displays an error message informing them that the operation cannot be performed on this screen. No data is created or removed as a result.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.

**Main Flow:**

**Step 1 - User attempts an Insert action**
The user clicks the Insert toolbar button or invokes the equivalent action. The system checks whether the Insert button is currently enabled. If it is enabled, the system displays an error message to inform the user that inserting data is not supported on this screen. If the button is not enabled, no action is taken.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert is not permitted on this screen | Insert button enabled check in FT_INSERT; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to insert data | Prevents data entry through the Insert action on a reporting-only screen. | *"This Operation Cannot be performed Here"* is displayed; no data is inserted. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - User attempts an Insert action while the Insert button is enabled - *"This Operation Cannot be performed Here"*; no data is inserted.

**Step 2 - User attempts a Delete action**
The user clicks the Delete toolbar button or invokes the equivalent action. The system checks whether the Delete button is currently enabled. If it is enabled, the system displays an error message to inform the user that deleting data is not supported on this screen. If the button is not enabled, no action is taken.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-003](#sp-003)) - GENERAL.DISP_TEXT - displays an error alert dialog with the supplied message text and title. Determines whether to use the error alert or the informational alert based on the title supplied.
    * **Step 1** - Evaluate the title supplied to determine the correct alert type (error or informational).
    * **Step 2** - Set the title and message text of the selected alert dialog.
    * **Step 3** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Delete is not permitted on this screen | Delete button enabled check in FT_DEL; error shown via GENERAL.DISP_TEXT [SP-003] | When the user attempts to delete data | Prevents data removal through the Delete action on a reporting-only screen. | *"This Operation Cannot be performed Here"* is displayed; no data is deleted. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-02** - User attempts a Delete action while the Delete button is enabled - *"This Operation Cannot be performed Here"*; no data is deleted.

---

---

#### Requirement ID: BR-007

**Requirement Title:** Exit the Dead Stock Report Screen

**Business Description:**
When the user clicks the Exit button or invokes the exit key action, the form closes immediately without validating or saving any entered data. As part of the exit sequence, the system clears the session tracking information it registered when the form was opened, so the database monitoring records correctly reflect that the Dead Stock report module is no longer in use.

**Actors:** Dealer Parts User

**Preconditions:**
- The Dead Stock report screen is open.

**Main Flow:**

**Step 1 - User initiates the exit action**
The user clicks the Exit button or presses the designated exit key. The system immediately closes the form without validating or saving any unsaved filter criteria.

**Step 2 - System clears session tracking on exit**
Upon exiting via the key-exit path, the system clears the client information and module name it had registered in the database session monitoring at form start-up, so the session no longer appears as running the Dead Stock report module.

---

---

#### Requirement ID: BR-008

**Requirement Title:** Register Form Session in Database Monitoring

**Business Description:**
Before the Dead Stock report screen becomes available to the user, the system registers the current database session as running the Dead Stock report module. This registration enables database administrators and monitoring tools to identify which module each active session is executing, supporting performance monitoring and session management across the application.

**Actors:** System (automatic - runs before the form opens)

**Preconditions:**
- The user has launched the Dead Stock report screen.

**Main Flow:**

**Step 1 - Register session client information**
Before the form is displayed, the system sets the client identifier for the current database session to the module name *'pe_dead_stk_rep'*, making the session identifiable in database monitoring views.

**Step 2 - Register the module name in the session**
The system also sets the module name to *'pe_dead_stk_rep'* and clears the action name in the database session monitoring, completing the session registration so monitoring tools can track which form is in use.

---

---

#### Requirement ID: BR-009

**Requirement Title:** Save and Print Actions - Not Implemented on This Form (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
The Dead Stock report screen includes Save and Print toolbar actions; however, neither action is implemented. The Save action is fully inactive and produces no effect when triggered. The Print action is active but its internal logic consists entirely of a no-operation statement, and the Print button is permanently disabled on the screen, so no print behaviour is ever executed. Both actions are documented here for completeness as they are present in the form definition but do not perform any business operation.

**Actors:** N/A - neither action executes

**Preconditions:**
- N/A - neither action executes.

**Main Flow:**

**Step 1 - Save action invoked (COMMENTED OUT / INACTIVE - does not execute)**
The Save toolbar button delegates to the FT_SAVE form trigger. FT_SAVE contains only a null statement (`null;`) and is marked inactive. No save, commit, or data persistence action occurs.

**Step 2 - Print action invoked (no-operation - does not execute)**
The Print toolbar button delegates to the FT_PRINT form trigger. FT_PRINT checks whether the Print button is enabled; as the Print button is permanently disabled (`enabled=false`), the active branch of FT_PRINT is never entered. The original print implementation code is entirely commented out and does not execute.

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Consignee Code is mandatory | Validation | BR-004 | The Consignee Code field is left blank when the user attempts to move to the next field | Show *"consignee code cannot be null"* and keep the cursor on the Consignee Code field | Prevents the report from running without a consignee scope, which would produce an unscoped or invalid result |
| BRC-002 | State is mandatory | Validation | BR-004 | The State field is left blank when the user attempts to move to the next field | Show *"State Name cannot be null"* and keep the cursor on the State field | Ensures the location hierarchy can be correctly resolved and that the report is scoped to a known geographical state |
| BRC-003 | Dealer Name is mandatory | Validation | BR-004 | The Dealer Name field is left blank when the user attempts to move to the next field | Show *"dealer_name cannot be null"* and keep the cursor on the Dealer Name field | Ensures the report data can be attributed to an identified dealer |
| BRC-004 | Location is mandatory | Validation | BR-004 | The Location field is left blank when the user attempts to move to the next field | Show *"Location cannot be null"* and keep the cursor on the Location field | Ensures the report is scoped to a defined dealer site so the dealer mapping code can be resolved |
| BRC-005 | From Date is mandatory | Validation | BR-004 | The From Date field is left blank when the user attempts to move to the next field | Show *"enter from date"* and keep the cursor on the From Date field | Ensures the liquidation report has a valid start date for the reporting period |
| BRC-006 | To Date is mandatory | Validation | BR-004 | The To Date field is left blank when the user attempts to move to the next field | Show *"enter to date"* and keep the cursor on the To Date field | Ensures the liquidation report has a valid end date for the reporting period |
| BRC-007 | Location selection derives the dealer mapping code | Derivation | BR-004 | The user selects a specific location (not "All") and leaves the Location field | Look up the unique dealer mapping code for that location within the current dealer group and principal organisation and store it for use in the report query; if "All" is selected, set the dealer mapping code to "All" | Ensures the downstream report query uses the precise internal identifier for the selected dealer site rather than a display value |
| BRC-008 | Inventory report type disables date, sale type, and price fields | Constraint | BR-002 | The user selects an inventory-based report type (detailed or summary) from the Report Type drop-down | Reset From Date and To Date to today's date; set Price Type to the DDL (delivered price) basis; disable and make non-navigable the Sale Type, From Date, To Date, and Price Type fields | Prevents invalid parameter combinations for inventory reports, which always reflect the current stock position and do not require a date range or sale type |
| BRC-009 | Liquidation report type enables date, sale type, and price fields | Constraint | BR-002 | The user selects a liquidation-based report type (detailed or summary) from the Report Type drop-down | Enable and make navigable the Sale Type, From Date, To Date, and Price Type fields | Ensures the user can provide the date range and transaction criteria required for a liquidation analysis |
| BRC-010 | Insert action is not permitted | Authorization | BR-006 | The user attempts to insert data while the Insert button is enabled | Display *"This Operation Cannot be performed Here"*; no data is inserted | Enforces that the Dead Stock report screen is a read-only reporting screen and cannot be used for data entry |
| BRC-011 | Delete action is not permitted | Authorization | BR-006 | The user attempts to delete data while the Delete button is enabled | Display *"This Operation Cannot be performed Here"*; no data is deleted | Enforces that the Dead Stock report screen is a read-only reporting screen and cannot be used for data removal |
| BRC-012 | Confirm before discarding unsaved criteria | Validation | BR-003 | The user clicks Cancel while filter criteria have been entered or modified | Ask the user to confirm *"Entered data will not be Saved"* before clearing the screen; if the user declines, all entered criteria are preserved | Protects the user from accidentally losing entered report criteria without an opportunity to reconsider |
| BRC-013 | Report file path must not contain spaces | Constraint | BR-005 | The generated output filename contains a space character in the folder path | Redirect the file to the root of the C drive and notify the user *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; processing continues with the redirected path | Prevents file write failure caused by a path that the server cannot resolve due to embedded spaces |
| BRC-014 | Report output is capped at 65,535 rows | Constraint | BR-005 | The number of data rows returned by the report query exceeds 65,536 | Notify the user *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* and limit the output to 65,535 rows | Prevents the generation of a report file that exceeds the maximum supported row count, which would corrupt or fail the Excel-compatible output |

**Total Business Rules Identified: 14**

---

## 6. Data Requirements

*This section describes the data entities queried by the Dead Stock report, the filter criteria the user captures on screen to scope the report, the reference data used for lookups and list values, and the lifecycle of filter data on the screen.*

### 6.1 Business Entities and Relationships

*The form queries a set of master and transactional entities covering dead stock liquidation history, current inventory levels, dealer and location data, parts catalogue, and transaction type classifications.*

#### Dead Stock Liquidation Transactions - PS_DEAD_STOCK

PS_DEAD_STOCK records individual transactions in which previously identified dead-stock parts were sold or liquidated. The form queries this table for the liquidation detail and liquidation summary report types, filtering by dealer, location, consignee, date range, part, part category, and transaction type.

#### Dead Stock Inventory - PM_PART_DEAD_STOCK

PM_PART_DEAD_STOCK identifies parts that have been designated as dead stock at a given dealer location. The form queries this table for the inventory detail and inventory summary report types to identify which parts are currently classified as dead stock at each location.

#### Dealer and Location Master - AM_DEALER_LOC

AM_DEALER_LOC holds the mapping between dealer groups, dealer codes (dealer_map_cd), consignee codes, and individual locations. It is the central joining entity in all four report queries, linking the user's consignee, state, dealer, and location filter selections to the transactional and inventory data.

#### Parts Master - PM_PART

PM_PART holds the catalogue of parts including part number, description, category, and the root part number hierarchy. It is joined to the dead stock and inventory records to supply part description and category in all report types.

#### Part Category Master - PM_CATEGORY

PM_CATEGORY defines the part categories used to classify parts. It is joined through PM_PART's category code and is used both to populate the Part Category filter drop-down at form start-up and to display the category description in report output.

#### Transaction Type Reference - AM_LIST (MULDMS.AM_LIST)

AM_LIST holds reference list values used for classifying transaction document types and billing types. The form joins this table in the liquidation queries to apply the sale type filter, matching the selected sale type to the relevant document type and billing type codes.

#### State Master - GM_STATE

GM_STATE holds state descriptions and codes. It is joined to AM_DEALER_LOC to supply the state description in report output and to apply the state filter.

#### City Master - GM_CITY

GM_CITY holds city/location descriptions. It is joined to AM_DEALER_LOC to supply the location description in report output.

#### Stock Bin Location - PM_STOCK_BIN_LOC (MULDMS.PM_STOCK_BIN_LOC)

PM_STOCK_BIN_LOC holds the current bin-level stock quantities (on-hand, float, allocated, and reserved quantities) for each part at each dealer location. It is used in the inventory detail and inventory summary report queries to calculate the net on-hand quantity and the corresponding value using the current landed-cost price.

#### Entity Relationships

The report queries link the dealer/location master to both the liquidation transaction history and the dead stock inventory register, which are then enriched with part catalogue data, category descriptions, transaction type references, and geographical data.

```
AM_DEALER_LOC (dealer/location master)
        ├── PS_DEAD_STOCK (liquidation transactions - joined by parent_group + dealer_map_cd + loc_cd)
        │       └── AM_LIST (transaction type classification - joined by doc_type / list_code)
        ├── PM_PART_DEAD_STOCK (dead stock inventory register - joined by parent_group + dealer_map_cd + loc_cd)
        │       └── PM_STOCK_BIN_LOC (bin stock quantities - joined by dealer_map_cd + loc_cd + part_num)
        ├── PM_PART (parts catalogue - joined by part_num)
        │       └── PM_CATEGORY (part categories - joined by catg_cd)
        ├── GM_STATE (state master - joined by state_cd + principal_map_cd)
        └── GM_CITY (city master - joined by city_cd + principal_map_cd)
```

### 6.2 Data Capture Requirements

*The form does not persist data to any database table. The user enters filter criteria that scope the report query; these criteria exist only for the duration of the session.*

#### Report Filter Criteria (User - report request entry)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Consignee Code (`CONSG_CD`) | Yes | Identifies the consignee whose dealer locations are included in the report. Selectable from a lookup list filtered to the current dealer group and principal organisation. | Must not be left blank; error shown if blank on field exit |
| State (`STATE_CD`) | Yes | Restricts the report to dealer locations in the selected state. Lookup list is automatically presented on field entry. | Must not be left blank; error shown if blank on field exit |
| Dealer Name (`DEALER_NAME`) | Yes | Identifies the dealer whose dead stock data is reported. Lookup list is automatically presented on field entry, filtered by consignee and state. | Must not be left blank; error shown if blank on field exit |
| Location (`LOC_CD`) | Yes | Identifies the specific dealer site to report on, or "All" to include all sites. Lookup list is automatically presented on field entry. | Must not be left blank; error shown if blank on field exit; selecting a specific location triggers automatic derivation of the internal dealer mapping code |
| Report Type (`REPORT_TYPE`) | Yes | Selects one of four report variants: inventory detail, inventory summary, liquidation detail, or liquidation summary. Controls which data query is used and which other filter fields are active. | Selection determines which other filter fields are enabled or disabled |
| From Date (`P_FROMDT`) | Conditional | Start date of the reporting period. Required for liquidation report types; disabled for inventory report types. Format: DD/MM/RRRR. | Must not be blank when the field is active (liquidation report types); error shown if blank on field exit |
| To Date (`P_TODT`) | Conditional | End date of the reporting period. Required for liquidation report types; disabled for inventory report types. Format: DD/MM/RRRR. | Must not be blank when the field is active (liquidation report types); error shown if blank on field exit |
| Sale Type (`SALE_TYPE`) | Conditional | Specifies which transaction types to include: Wholesale, Customer sale, Internal fleet, All, or Wholesale and customer combined. Required for liquidation report types; disabled for inventory report types. | Field enabled only for liquidation report types |
| Price Type (`PRICE_UNIT`) | Conditional | Selects the price basis for the value column: Basic, MRP, Landed, or DDL (delivered price). Required for liquidation report types; for inventory types, automatically set to DDL and disabled. | Field enabled only for liquidation report types; auto-set to DDL for inventory types |
| Part Number (`PART_NUM`) | No | Optional filter to restrict the report to a single part number. | No mandatory check; if entered, applied as an additional filter clause |
| Root Part Number (`ROOT_PART_NUM`) | No | Optional filter to restrict the report to parts belonging to a root part number group. | No mandatory check; if entered, applied as an additional filter clause |
| Part Category (`P_CATG`) | No | Optional filter to restrict the report to a single part category; defaults to "All". Populated from the part category master at form start-up. | Defaults to "All" on form open and after cancel/clear |

#### Session and Parameter Tracking (System - non-database flags)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Liquidation part stock filter (`P_LIQ_PART_STK`) | Auto-Populated | Dynamic SQL fragment appended to the liquidation query when a specific part number is entered by the user. Initialised to null at the start of each report generation. | System-managed; not directly entered by the user |
| Dead stock part filter (`P_DEAD_PART_STK`) | Auto-Populated | Dynamic SQL fragment appended to the inventory query when a specific part number is entered. Initialised to null at the start of each report generation. | System-managed; not directly entered by the user |
| Root part filter (`P_ROOT_PART`) | Auto-Populated | Dynamic SQL fragment appended to the query when a root part number is entered. Initialised to null at the start of each report generation. | System-managed; not directly entered by the user |
| Sale type filter (`P_SALE_TYPE`) | Auto-Populated | Dynamic SQL fragment appended to the liquidation query based on the selected sale type. Initialised to null at the start of each report generation. | System-managed; not directly entered by the user |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form for lookups and list population.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Consignee lookup (LV_CONSG / RG_CONSG - AM_DEALER_LOC) | Provides the list of available consignee codes and associated dealer names for the current dealer group and principal organisation, including an "All" option | When the user navigates to or enters a value in the Consignee Code field |
| State lookup (LV_STATE / RG_STATE - GM_STATE, AM_DEALER_LOC) | Provides the list of states associated with the selected consignee, including an "All" option for OEM users | When the user navigates into the State field |
| Dealer lookup (LV_DEALER / RG_DEALER - AM_DEALER_LOC) | Provides the list of dealer names filtered by the selected consignee and state, including an "All" option for OEM users | When the user navigates into the Dealer Name field |
| Location lookup (LV_LOC / RG_LOC - AM_DEALER_LOC) | Provides the list of dealer locations for the selected dealer group, consignee, state, and dealer name, including an "All" option | When the user navigates into the Location field |
| Part Category master (PM_CATEGORY) | Provides the list of part category descriptions and codes for the current principal organisation, used to populate the Part Category filter | When the form is opened (WHEN-NEW-FORM-INSTANCE) |
| Transaction type reference (AM_LIST / MULDMS.AM_LIST) | Classifies dead stock liquidation transactions by document type and billing type, used to apply the sale type filter in the liquidation query | When the liquidation report query is executed (WHEN-BUTTON-PRESSED on Excel Report) |
| Report server URL path (excelpath.txt on server) | Provides the base URL used to construct the browser link to the generated CSV report file | When the Excel Report button is clicked and VIEW_EXCEL_REP reads the path from the server configuration file |

### 6.4 Data Lifecycle

*Describes how filter criteria are captured, used, and reset within this form.*

**Creation**

- Filter criteria (Consignee Code, State, Dealer Name, Location, Report Type, From Date, To Date, Sale Type, Price Type, Part Number, Root Part Number, Part Category) are entered by the user on the Dead Stock report screen.
- From Date and To Date are automatically pre-populated with today's date when the form opens (WHEN-NEW-FORM-INSTANCE) and after each cancel/clear action (KEY-CLRFRM).
- Part Category is pre-populated to "All" on form open and after cancel/clear.
- No records are created in the database by this form.

**Updates**

- Filter criteria can be changed freely by the user before the report is generated.
- Selecting a different report type automatically updates the enabled/disabled state of the date range, sale type, and price type fields and may reset their values.
- Entering a specific location triggers an automatic derivation of the internal dealer mapping code from the dealer/location master.
- The dynamic SQL filter parameters are rebuilt each time the Excel Report button is clicked.

**Save and Commit**

- This form does not save or commit any data to the database. No COMMIT or DML operations are performed on any user-entered data.
- The form operates in report-request mode only; all database interaction is read-only (SELECT queries executed when the Excel Report is generated).

**Retention and Audit**

- No audit trail or change history is written by this form.
- Filter criteria exist only for the duration of the user's session on this screen and are discarded when the form is closed or the screen is cleared.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ALL | Sentinel value used in filter lists to indicate no restriction on that dimension; selects all records across the dimension | - | Consignee Code, State Code, Dealer Name, Location Code |
| Bin Stock | Quantity of parts held at a specific bin location within a dealer's parts storage facility | - | Dead Stock, Liquidation Stock, PM_STOCK_BIN_LOC |
| CB_ERR | Control block that holds the error message text displayed in the WIN_ERR error window | Error Block | CNTRL_BLK, WIN_ERR |
| CNTRL_BLK | Main control block on the Dead Stock Report form; holds all report filter criteria entered by the user | Control Block | CB_ERR, PB_BLK |
| Consignee Code | Code identifying the dealership consignee group to which a dealer belongs; used to filter dealer and location lookups | CONSG_CD | Dealer Name, Parent Group |
| CSV | Comma-Separated Values - file format used for the Excel-compatible report export generated by the form | Excel Export | Excel Report, VIEW_EXCEL_REP |
| DDL | Delivered Duty and Landed price basis option for liquidation report pricing; one of four price unit choices | - | Price Unit, MRP, Landed, Basic |
| Dead Stock | Parts held in inventory that have had no sales activity for an extended period and are at risk of becoming obsolete | Slow-Moving Parts | Liquidation Stock, Bin Stock |
| Dealer Map Code | Internal mapping code derived from the dealer location record when a location is selected; used in report queries | DEALER_MAP_CD | Location Code, AM_DEALER_LOC |
| DMS | Dealer Management System - the integrated software platform for dealership operations within which the Dead Stock Report form operates | - | Oracle Forms, Parts Manager |
| DPL | General-purpose Oracle Forms program library attached to the form; provides shared validation and display routines | DPL.pld | PLD, ASK_CONFIRM, DISP_TEXT |
| Excel Report | The CSV file generated and opened in the browser when the user clicks the Excel Report button | CSV Export | VIEW_EXCEL_REP, PB_EXCEL |
| Inventory Detail | Report type showing current dead stock inventory quantities at the part level | I | Report Type, Inventory Summary |
| Inventory Summary | Report type showing summarised dead stock inventory totals per part | IS | Report Type, Inventory Detail |
| Landed | Price basis reflecting the landed cost of a part including freight and import charges | - | Price Unit, Basic, MRP, DDL |
| Liquidation Detail | Report type showing individual liquidation transaction lines by part within the selected date range | L | Report Type, Liquidation Summary |
| Liquidation Stock | Parts that have been identified for disposal or sale at reduced prices to clear surplus inventory | - | Dead Stock, Sale Type |
| Liquidation Summary | Report type showing summarised liquidation activity totals per part within the selected date range | LS | Report Type, Liquidation Detail |
| LOC_CD | Location code identifying a specific dealer outlet or branch within the dealer network | Location Code | AM_DEALER_LOC, Dealer Map Code |
| LOV | List of Values - a popup selection list presented to the user for choosing a valid filter value | Dropdown, Popup | Record Group, CONSG_CD, STATE_CD |
| MRP | Maximum Retail Price - one of four price basis options available for liquidation report pricing | - | Price Unit, Basic, Landed, DDL |
| P_CATG | Part category filter list item on the form; populated from the part category master on startup | Part Category | PM_CATEGORY, CNTRL_BLK |
| P_FROMDT | From-date field on the form specifying the start of the date range for liquidation reports | From Date | P_TODT, Date Range |
| P_TODT | To-date field on the form specifying the end of the date range for liquidation reports | To Date | P_FROMDT, Date Range |
| Parent Group | Dealer parent group code associated with the logged-in user; controls which dealers and consignees are visible | PARENT_GROUP | Consignee Code, Dealer Name |
| PB_BLK | Toolbar block containing all the push-button controls on the form | Button Block | CNTRL_BLK, PB_EXCEL |
| PB_EXCEL | Push button labelled "Excel Report" that triggers the report query build and CSV file generation | Excel Button | VIEW_EXCEL_REP, CSV |
| PLD | Oracle Forms program library (`.pld` file) containing shared PL/SQL routines attached to the form | Program Library | DPL, GENERAL |
| PM_CATEGORY | Part category master table; stores category codes and descriptions per principal; used to populate the part category filter | - | P_CATG, Principal |
| Principal | Organisation or manufacturer identifier that scopes all data in the DMS to a specific business entity | Principal Map Code | CONSG_CD, Parent Group |
| Price Unit | Filter controlling the price basis used for liquidation report values: Basic, MRP, Landed, or DDL | PRICE_UNIT | MRP, Landed, DDL, Basic |
| Record Group | An in-memory data structure in Oracle Forms that stores the results of a SQL query and populates LOV lists | RG | LOV, RG_CONSG, RG_STATE |
| Report Type | Selector controlling which variant of the dead stock report is generated: Liquidation Detail, Liquidation Summary, Inventory Detail, or Inventory Summary | REPORT_TYPE | Liquidation Detail, Inventory Detail |
| Root Part Number | Top-level part number in a parts hierarchy; used as an optional filter to include all variants under a root part | ROOT_PART_NUM | Part Number |
| Sale Type | Filter for liquidation reports specifying the transaction type: Warranty (W), Contract (C), Internal (I), All (A), or Warranty+Contract (WC) | SALE_TYPE | Liquidation Detail, Liquidation Summary |
| State Code | Code identifying the geographic state in which a dealer operates; used to filter dealer and location selections | STATE_CD | GM_STATE, Dealer Name |
| VIEW_EXCEL_REP | Form-local program unit that executes the report query, writes results to a CSV file, and opens it in the browser | Excel Export Procedure | PB_EXCEL, CSV |
| WIN_ERR | Error dialog window displayed when a validation message or error alert must be shown to the user | Error Window | CB_ERR, AL_ERRINFO |
| WN_MAIN | Primary application window hosting the Dead Stock Report form screen | Main Window | CN_MAIN, WINDOW1 |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: ps_dead_stock (PS_DEAD_STOCK)
- Form Module XML Title: MODULE3
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: -
- Attached Libraries: DPL (DPL.pld program library), WEBUTIL (webutil.olb), D2KWUTIL
- First Navigation Block: -
- Console Window: WINDOW1
- Compile Dependencies: Requires DPL.pld, WEBUTIL.olb, menu.mmx, database packages PK_PART_SEARCH_NEW
- Source artifacts: `pe_dead_stk_rep_fmb.xml`; DPL (DPL.pld program library); WEBUTIL (webutil.olb); D2KWUTIL

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| PARENT_GROUP | Char | RecordGroup | Logged-in user's parent group code; controls multi-dealer filtering in record group queries |
| PRINCIPAL | Char | RecordGroup / Trigger | Principal/organisation map code; filters all dealer location and state record group queries |
| USERID | Char | ProgramUnit / Trigger | Oracle Forms login user ID; used to generate the CSV export filename in VIEW_EXCEL_REP |
| USER_NAME | Char | Trigger | Display name of the logged-in user; set at form startup and available for report header labelling |

### 8.1.2 Form Parameters

*All 4 ModuleParameter entries from pe_dead_stk_rep_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_LIQ_PART_STK | Char | - | Dynamic SQL fragment appended to the Liquidation Stock report WHERE clause to filter by part number |
| P_DEAD_PART_STK | Char | - | Dynamic SQL fragment appended to the Dead Stock report WHERE clause to filter by part number |
| P_ROOT_PART | Char | - | Dynamic SQL fragment appended to both report queries to filter by root part number |
| P_SALE_TYPE | Char | - | Dynamic SQL fragment appended to the Liquidation report query to filter by sale/document type |

**Total Parameters:** 4

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CNTRL_BLK | - | 1 | N/N/N/N | Default | Non-database control block; report criteria entry point |
| CB_ERR | - | 15 | N/N/N/N | Default | Non-database block; displays error messages in the error window |
| PB_BLK | - | 1 | N/N/N/N | Default | Non-database toolbar block; contains push buttons for form actions |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pe_dead_stk_rep_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in pe_dead_stk_rep_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `pe_dead_stk_rep_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CNTRL_BLK | 16 | 0 | 16 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 11 | 0 | 11 |
| **Total** | **28** | **0** | **28** |

**Item detail (all 28 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CNTRL_BLK | DEALER_MAP_CD | false | Internal dealer map code; auto-populated from LOC_CD validation |
| CNTRL_BLK | PARENT_GROUP | false | Dealer parent group code; populated from LV_CONSG LOV selection |
| CNTRL_BLK | CONSG_CD | false | Consignee/dealer code filter; entered via LV_CONSG LOV; validated non-null |
| CNTRL_BLK | STATE_CD | false | State code filter; entered via LV_STATE LOV; validated non-null |
| CNTRL_BLK | DEALER_NAME | false | Dealer name filter; entered via LV_DEALER LOV; validated non-null |
| CNTRL_BLK | LOC_CD | false | Location code filter; entered via LV_LOC LOV; triggers DEALER_MAP_CD lookup |
| CNTRL_BLK | PART_NUM | false | Optional part number filter appended to report query WHERE clause |
| CNTRL_BLK | ROOT_PART_NUM | false | Optional root part number filter appended to report query WHERE clause |
| CNTRL_BLK | REPORT_TYPE | false | List item selecting report type: L=Liquidation detail, I=Inventory detail, LS=Liquidation summary, IS=Inventory summary |
| CNTRL_BLK | SALE_TYPE | false | List item selecting sale type: W=Warranty, C=Contract, I=Internal, A=All, WC=Warranty+Contract |
| CNTRL_BLK | PRICE_UNIT | false | List item selecting price basis: B=Basic, M=MRP, L=Landed, D=DDL |
| CNTRL_BLK | P_FROMDT | false | Date range from-date for Liquidation report; validated non-null; defaults to SYSDATE on startup |
| CNTRL_BLK | P_TODT | false | Date range to-date for Liquidation report; validated non-null; defaults to SYSDATE on startup |
| CNTRL_BLK | P_CATG | false | Part category filter list item; populated from PM_CATEGORY on form startup |
| CNTRL_BLK | TEXT_ITEM102 | false | Scratch text item; formerly used for debug display of generated query string |
| CNTRL_BLK | PB_EXCEL | false | "Excel Report" push button; triggers report query build and CSV export |
| CB_ERR | TXT_ERR | false | Text item displaying error messages in the error canvas window |
| PB_BLK | PB_EXIT | false | "Exit" button; exits the form without validation |
| PB_BLK | PB_LIST | false | "List" button; opens the active item's LOV |
| PB_BLK | PB_INSERT | false | "Insert" button; shows "Cannot be performed here" message |
| PB_BLK | PB_DEL | false | "Delete" button; shows "Cannot be performed here" message |
| PB_BLK | PB_CANCEL | false | "Cancel" button; prompts confirmation then clears the form |
| PB_BLK | PB_SAVE | false | "Save" button; executes NULL stub (save not applicable for report form) |
| PB_BLK | PB_PRINT | false | "Print" button; executes NULL stub (print not implemented) |
| PB_BLK | PB_CUT | false | "Cut" button; fires Cut_Region clipboard action |
| PB_BLK | PB_COPY | false | "Copy" button; fires Copy_Region clipboard action |
| PB_BLK | PB_PASTE | false | "Paste" button; fires Paste_Region clipboard action |
| PB_BLK | PB_ERR_EXIT | false | "OK" button on error dialog; closes the WIN_ERR error window |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_CONSG | Consignee codes | RG_CONSG | CNTRL_BLK.CONSG_CD |
| LV_STATE | LV_STATE | RG_STATE | CNTRL_BLK.STATE_CD |
| LV_DEALER | Dealer Name | RG_DEALER | CNTRL_BLK.DEALER_NAME |
| LV_LOC | Location | RG_LOC | CNTRL_BLK.LOC_CD |

**Total LOVs:** 4

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_ERRINFO | Error | (set at runtime) | ProgramUnit: DISP_TEXT (DPL library); called from Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.CONSG_CD, CNTRL_BLK.DEALER_NAME, CNTRL_BLK.LOC_CD, CNTRL_BLK.P_FROMDT, CNTRL_BLK.P_TODT, CNTRL_BLK.STATE_CD; Trigger: FT_INSERT and FT_DEL |
| AL_NOTE | Note | (set at runtime) | ProgramUnit: DISP_TEXT (DPL library); called when title is non-error message type |
| AL_CONFIRM | Caution | (set at runtime) | ProgramUnit: ASK_CONFIRM (DPL library); called from Trigger: FT_CANCEL in Form |
| AL_PRINT | Print | (set at runtime) | ProgramUnit: ASK_PRINT (DPL library); available for print destination selection (not actively called in current trigger code) |

**Total Alerts:** 4

### 8.6 Program Units

*Authoritative catalogue of **1 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VIEW_EXCEL_REP | Procedure | FIND_GROUP, DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, GET_GROUP_ROW_COUNT, FIND_COLUMN, GET_GROUP_CHAR_CELL, TEXT_IO.FOPEN, TEXT_IO.PUT_LINE, TEXT_IO.FCLOSE, WEB.SHOW_DOCUMENT, WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT, WEBUTIL_HOST.HOST | Generates a CSV file from the dead stock or liquidation report query, writes it to the server, and opens it in the browser for download as an Excel-compatible export |

**Total Program Units:** 1

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level (FT_CANCEL), PB_BLK.PB_EXIT | Displays AL_CONFIRM caution alert to ask the user to confirm a cancel or exit action; returns the user's choice so the caller can proceed or abort |
| GENERAL.DISP_TEXT | Library routine | CNTRL_BLK.CONSG_CD, CNTRL_BLK.DEALER_NAME, CNTRL_BLK.LOC_CD, CNTRL_BLK.P_FROMDT, CNTRL_BLK.P_TODT, CNTRL_BLK.STATE_CD, Form level (FT_INSERT, FT_DEL) | Displays AL_ERRINFO (Error) or AL_NOTE (Note) alert with a custom message title and body |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level (WHEN-NEW-FORM-INSTANCE) | Populates a list item at runtime from a database query; used during form startup to load the P_CATG category list from PM_CATEGORY |
| GENERAL.PRINT_REPORT | Library routine | Form level (FT_PRINT - commented-out code) | Configures and submits a report for printing; referenced in the inactive FT_PRINT trigger body that is fully commented out |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers the server-side generated CSV file to the client machine as part of the Excel export download flow |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server (e.g. to move or rename the generated CSV file) during the Excel export process |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | FT_PRINT | Called GENERAL.PRINT_REPORT with table name, field names, labels, and user name to print a zone master report | Commented out; replaced with NULL stub; original sample code was never implemented for this form |
| **Inactive stub** | Form | - | FT_SAVE | No logic implemented; save operation is not applicable to this read-only report form | Body contains only `null;`; form is a reporting screen with no data entry or save capability |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Checked system.mode and form_status; called ASK_CONFIRM before exit when unsaved changes existed | Simplified to unconditional exit_form(no_validate); confirmation check removed |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (31 business triggers):**
*pe_dead_stk_rep_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| FT_CANCEL | Form | - | Form level | Prompts confirmation if form status is CHANGED, then clears the form without saving |
| FT_INSERT | Form | - | Form level | Displays "This Operation Cannot be performed Here" error; insert is not supported on this report form |
| FT_DEL | Form | - | Form level | Displays "This Operation Cannot be performed Here" error; delete is not supported on this report form |
| FT_LIST | Form | - | Form level | Fires DO_KEY('LIST_VALUES') to open the active item's LOV popup |
| FT_PRINT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - executes NULL; original print report logic is commented out |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximises WN_MAIN window; populates P_CATG list from PM_CATEGORY; sets P_FROMDT and P_TODT defaults to SYSDATE (inherited) |
| FT_SAVE | Form | - | Form level | **INACTIVE STUB** - executes NULL; save is not applicable to this read-only report form |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation; resets P_FROMDT/P_TODT to SYSDATE; re-enables date, price, and sale-type fields |
| PRE-FORM | Form | - | Form level | Registers the form with DBMS_APPLICATION_INFO by setting client info and module name to pe_dead_stk_rep |
| KEY-EXIT | Form | - | Form level | Clears DBMS_APPLICATION_INFO client info and module, then exits the form without validation |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | CONSG_CD | CNTRL_BLK.CONSG_CD | Validates CONSG_CD is not null; displays error and raises form_trigger_failure if empty |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | STATE_CD | CNTRL_BLK.STATE_CD | Automatically opens LV_STATE LOV when user navigates to the STATE_CD field |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | STATE_CD | CNTRL_BLK.STATE_CD | Validates STATE_CD is not null; displays error and raises form_trigger_failure if empty |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | DEALER_NAME | CNTRL_BLK.DEALER_NAME | Validates DEALER_NAME is not null; displays error and raises form_trigger_failure if empty |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | DEALER_NAME | CNTRL_BLK.DEALER_NAME | Automatically opens LV_DEALER LOV when user navigates to the DEALER_NAME field |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | LOC_CD | CNTRL_BLK.LOC_CD | Validates LOC_CD is not null; queries AM_DEALER_LOC to derive DEALER_MAP_CD from LOC_CD, PARENT_GROUP, and PRINCIPAL |
| WHEN-NEW-ITEM-INSTANCE | CNTRL_BLK | LOC_CD | CNTRL_BLK.LOC_CD | Automatically opens LV_LOC LOV when user navigates to the LOC_CD field |
| WHEN-LIST-CHANGED | CNTRL_BLK | REPORT_TYPE | CNTRL_BLK.REPORT_TYPE | Enables or disables SALE_TYPE, P_FROMDT, P_TODT, and PRICE_UNIT fields based on selected report type |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | P_FROMDT | CNTRL_BLK.P_FROMDT | Validates P_FROMDT is not null; displays error and raises form_trigger_failure if empty |
| WHEN-VALIDATE-ITEM | CNTRL_BLK | P_TODT | CNTRL_BLK.P_TODT | Validates P_TODT is not null; displays error and raises form_trigger_failure if empty |
| WHEN-BUTTON-PRESSED | CNTRL_BLK | PB_EXCEL | CNTRL_BLK.PB_EXCEL | Builds dynamic report query from filter criteria and calls VIEW_EXCEL_REP to generate and open the CSV export |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT | Exits the form without validation via exit_form(no_validate) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST | Delegates to FT_LIST via EXECUTE_TRIGGER to open the active item's LOV |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT | Delegates to FT_INSERT via EXECUTE_TRIGGER; displays insert-not-permitted message |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL | Delegates to FT_DEL via EXECUTE_TRIGGER; displays delete-not-permitted message |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL | Delegates to FT_CANCEL via EXECUTE_TRIGGER; prompts confirmation then clears the form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE | Delegates to FT_SAVE via EXECUTE_TRIGGER; executes NULL stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT | Delegates to FT_PRINT via EXECUTE_TRIGGER; executes NULL stub |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT | Fires Cut_Region to cut selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY | Fires Copy_Region to copy selected text to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE | Fires Paste_Region to paste clipboard content into the active field |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WINDOW1 | - | - |
| WN_MAIN | Dead Stock Report (Rel : 2.5.1) | CN_MAIN |
| WIN_ERR | Errors | CN_ERR |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Stacked | WIN_ERR |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Vertical Toolbar | WN_MAIN |

---

### 8.9 Editors

*No editors found in pe_dead_stk_rep_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*15 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_DISP |
| VA_LOV |
| VA_TRNI_DT |
| VA_TITLE |
| VA_ALERT |
| VA_BUTN |
| VA_TEXT |
| VA_MPROMPT |
| VA_OPROMPT |
| VA_MAND |
| VA_NUM |
| VA_DESC |
| VA_ICONIC_BUTN |
| VA_RB |
| VA_CB |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pe_dead_stk_rep_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in pe_dead_stk_rep_fmb.xml.*

## 9. Object Library

*The form references Visual Attributes and an Object Group that are defined directly within the form module itself. No separate Object Library (.olb) file was supplied with this form.*

Source OLB file(s): none supplied

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_DISP | VisualAttribute | Display style: bold Arial 8pt, teal background, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_LOV | VisualAttribute | LOV list style: gray background, dark blue foreground, Arial 9pt | 4 (4 LOV objects) | LV_CONSG, LV_STATE, LV_DEALER, LV_LOC |
| VA_TRNI_DT | VisualAttribute | Transaction date style: white background, bold Courier font, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_TITLE | VisualAttribute | Title style: gray background, bold blue Arial 10pt | 0 (defined but not applied to any item in this form) | N/A |
| VA_ALERT | VisualAttribute | Alert dialog style: gray background, MT Extra font, demilight weight | 4 (4 alert objects) | AL_ERRINFO, AL_NOTE, AL_CONFIRM, AL_PRINT |
| VA_BUTN | VisualAttribute | Button style: gray background, bold black Arial 10pt | 0 (defined but not applied to any item in this form) | N/A |
| VA_TEXT | VisualAttribute | Text field style: white background, medium Arial 9pt, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt style: white background, red prompt foreground, Arial | 0 (defined but not applied to any item in this form) | N/A |
| VA_OPROMPT | VisualAttribute | Optional field prompt style: white background, black prompt foreground, Arial | 0 (defined but not applied to any item in this form) | N/A |
| VA_MAND | VisualAttribute | Mandatory input field style: cyan background, medium Arial 9pt, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_NUM | VisualAttribute | Numeric field style: white background, medium Arial 8pt, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_DESC | VisualAttribute | Description field style: gray background, medium Small Fonts 7pt, blue foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button style: white background, black foreground | 7 (toolbar button items) | PB_EXIT, PB_LIST, PB_INSERT, PB_DEL, PB_CANCEL, PB_SAVE, PB_PRINT |
| VA_RB | VisualAttribute | Radio button style: gray background, Arial 8pt, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| VA_CB | VisualAttribute | Checkbox style: gray background, Arial 8pt, black foreground | 0 (defined but not applied to any item in this form) | N/A |
| OG_GROUP | ObjectGroup | Groups all 15 Visual Attributes defined in this form into a single reusable object group | referenced (contains VA_DISP through VA_CB) | All 15 Visual Attributes listed above |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CONSG | Query | LV_CONSG | CONSG_CD | DEALER_CATEGORY | No | Lists consignee/dealer codes and their categories for the logged-in principal; includes an ALL option for unrestricted users | LV_CONSG -> CNTRL_BLK.CONSG_CD |
| RG_DEALER | Query | LV_DEALER | DEALER_NAME | PARENT_GROUP | No | Lists dealer names filtered by the selected consignee code and state; includes ALL option for principal-level users | LV_DEALER -> CNTRL_BLK.DEALER_NAME |
| RG_LOC | Query | LV_LOC | LOC_DESC | LOC_CD | No | Lists dealer location descriptions and codes filtered by consignee, state, and dealer name selection | LV_LOC -> CNTRL_BLK.LOC_CD |
| RG_STATE | Query | LV_STATE | STATE_DESC | STATE_CD | No | Lists states where dealers operate, filtered by consignee code and principal; includes ALL option for unrestricted users | LV_STATE -> CNTRL_BLK.STATE_CD |

**Total Record Groups:** 4

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CNTRL_BLK | - | - | No |
| CB_ERR | - | - | No |
| PB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_CONSG, RG_DEALER, RG_LOC, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-VALIDATE-ITEM | Dealer location master - stores dealer name, consignee code, state, location code, parent group, and principal mapping |
| `DUAL` | - | RG_CONSG, RG_DEALER, RG_LOC, RG_STATE, Trigger KEY-CLRFRM, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-LIST-CHANGED, Trigger WHEN-NEW-FORM-INSTANCE, Trigger WHEN-VALIDATE-ITEM | Oracle system pseudo-table - used for SYSDATE queries and literal UNION ALL rows in record group queries |
| `GM_STATE` | - | RG_STATE | Geographic state master - stores state code, state description, and principal map code |
| `MULDMS.PM_STOCK_BIN_LOC` | - | Trigger WHEN-BUTTON-PRESSED | Parts bin-level stock location - stores on-shelf and liquidation stock quantities, float, allocated, and reserved per dealer/location/part |
| `PM_CATEGORY` | - | Trigger WHEN-NEW-FORM-INSTANCE | Part category master - stores part category codes and descriptions per principal; used to populate the P_CATG filter list on form startup |

**Total Referenced Objects:** 5

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | GENERAL.L_POP_LIST_ITEM | Builds and populates the Part Category record group from the category master at form start-up |
| BR-002 | (none - trigger-only logic) | Report type selection and field enable/disable is handled entirely by the WHEN-LIST-CHANGED trigger with no backend procedure call |
| BR-003 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog when the user cancels with unsaved criteria and returns the user's choice |
| BR-004 | GENERAL.DISP_TEXT | Displays field-level validation error messages (Consignee, State, Dealer, Location, From Date, To Date) |
| BR-005 | VIEW_EXCEL_REP | Executes the report query, writes the result to a CSV file on the report server, and opens the file in the browser |
| BR-005 | WEB.SHOW_DOCUMENT | Opens the generated CSV report file in a new browser window |
| BR-005 | WEBUTIL.FOPEN | Opens the output CSV file on the report server for writing within VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.PUT_LINE | Writes each header and data row to the open CSV file within VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.FCLOSE | Closes the CSV file handle after all rows have been written within VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.GET_LINE | Reads the server base URL from the configuration file within VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.GETPROPERTY | Retrieves a WebUtil file or environment property during CSV generation in VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.SETPROPERTY | Sets a WebUtil file or environment property during CSV generation in VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.GETIMPLCLASS | Retrieves the WebUtil implementation class name during initialisation in VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.ERRORALERT | Displays a WebUtil-level error alert when a file operation fails inside VIEW_EXCEL_REP |
| BR-005 | WEBUTIL.ID_NULL | Validates that a record group handle is non-null before attempting to delete or use it in VIEW_EXCEL_REP |
| BR-006 | GENERAL.DISP_TEXT | Displays the error message when an Insert or Delete action is attempted |
| BR-008 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form module name as the client identifier in the database session |
| BR-008 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the form module name in the database session module tracking |
| BR-007 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the client identifier from the database session when the form exits |
| BR-007 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the module name from the database session when the form exits |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.ASK_CONFIRM | Function (attached library DPL) | FT_CANCEL (Form trigger - Cancel/clear flow) | Displays the AL_CONFIRM caution alert with the supplied message; returns 1 if the user presses the first button (Yes/OK) or 0 otherwise. Called in FT_CANCEL to ask "Entered data will not be Saved" before clearing the form. |
| GENERAL.DISP_TEXT | Procedure (attached library DPL) | WHEN-VALIDATE-ITEM on CNTRL_BLK.CONSG_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.STATE_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.DEALER_NAME; WHEN-VALIDATE-ITEM on CNTRL_BLK.LOC_CD; WHEN-VALIDATE-ITEM on CNTRL_BLK.P_FROMDT; WHEN-VALIDATE-ITEM on CNTRL_BLK.P_TODT; FT_INSERT; FT_DEL | Displays AL_ERRINFO (when title_string is 'Error') or AL_NOTE (any other title) with the supplied message text and title. Called to show validation errors and informational messages across item validation and action triggers. |
| GENERAL.L_POP_LIST_ITEM | Procedure (attached library DPL) | WHEN-NEW-FORM-INSTANCE (Form trigger - initialisation) | Creates a record group from the supplied SQL query (p_select), populates it, and makes it available to the form list item. Called on form startup to populate the P_CATG part-category list from PM_CATEGORY. |
| VIEW_EXCEL_REP | Procedure (form program unit) | WHEN-BUTTON-PRESSED on CNTRL_BLK.PB_EXCEL | Executes the supplied query into a record group, writes the results row by row to a CSV file on the report server, reads the server base URL from a configuration file, and opens the resulting file in a new browser window via WEB.SHOW_DOCUMENT; handles file path spaces by redirecting to C:\ root and row-count overflow by truncating to 65,535 rows. |
| WEB.SHOW_DOCUMENT | Procedure (Oracle Forms Web package) | VIEW_EXCEL_REP (form program unit) | Opens a URL in a new browser window; used to display the generated CSV report file. |
| WEBUTIL.ID_NULL | Function (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Checks whether a supplied WebUtil handle has a NULL (invalid) value; returns TRUE if the handle is null. Called in VIEW_EXCEL_REP to verify that a record group handle is valid before attempting to delete or use it. |
| WEBUTIL.FOPEN | Function (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Opens a file on the report server in the specified mode (read or write) and returns a file handle; used in VIEW_EXCEL_REP to open the output CSV file for writing and the configuration file for reading. |
| WEBUTIL.PUT_LINE | Procedure (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Writes a line of text to an open file handle; used in VIEW_EXCEL_REP to write the CSV header row and each subsequent data row to the output file. |
| WEBUTIL.FCLOSE | Procedure (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Closes an open file handle; called in VIEW_EXCEL_REP after all CSV rows have been written to ensure the file is properly finalised and released. |
| WEBUTIL.GET_LINE | Function (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Reads a single line from an open file handle; used in VIEW_EXCEL_REP to read the server base URL from the configuration file so the correct download link can be constructed. |
| WEBUTIL.GETPROPERTY | Function (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Retrieves a named property value from a WebUtil file or environment object; used in VIEW_EXCEL_REP during CSV file path and environment resolution. |
| WEBUTIL.SETPROPERTY | Procedure (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Sets a named property value on a WebUtil file or environment object; used in VIEW_EXCEL_REP to configure file operation parameters during CSV generation. |
| WEBUTIL.GETIMPLCLASS | Function (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Retrieves the WebUtil implementation class name; used in VIEW_EXCEL_REP during initialisation to confirm the WebUtil runtime environment is available before file operations begin. |
| WEBUTIL.ERRORALERT | Procedure (attached library webutil - WEBUTIL_C_API) | VIEW_EXCEL_REP (form program unit) | Displays a WebUtil-level error alert dialog; called in VIEW_EXCEL_REP when a file open, write, or close operation fails so that the user is informed of the failure. |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Procedure (Oracle system package) | PRE-FORM (Form trigger - session registration); KEY-EXIT (Form trigger - session cleanup) | Sets or clears the client information string for the current database session, making the session identifiable in Oracle database monitoring views. |
| DBMS_APPLICATION_INFO.SET_MODULE | Procedure (Oracle system package) | PRE-FORM (Form trigger - session registration); KEY-EXIT (Form trigger - session cleanup) | Sets or clears the module name and action name for the current database session in Oracle database monitoring views. |

## 13. Package Procedure Specifications

*NO PCK files found - no `*.pck` source files were discovered in the form sources input directory. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*NO PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/e1b64a6a-ed72-461e-b164-570482474a5b/inputs/form_sources`. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form | Displays the AL_CONFIRM caution alert with the supplied message; returns 1 if the user presses the first button (Yes/OK) or 0 otherwise. Called in FT_CANCEL to ask "Entered data will not be Saved" before clearing the form. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: FT_DEL in Form, Trigger: FT_INSERT in Form, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.STATE_CD | Displays AL_ERRINFO (when title_string is 'Error') or AL_NOTE (any other title) with the supplied message text and title. Called to show validation errors and informational messages across item validation and action triggers. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Creates a record group from the supplied SQL query (p_select), populates it, and makes it available to the form list item. Called on form startup to populate the P_CATG part-category list from PM_CATEGORY. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_dead_stk_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| DELETE_RECGRP_ROW | Procedure | Procedure(p_block_name in varchar2, p_rec_num in number) | Trigger: FT_DEL in Form | **COMMENTED OUT / INACTIVE** - Removes the specified row from a named Oracle Forms record group. This call appears only in the commented-out portion of the FT_DEL trigger body and is not executed at runtime. |
| PRINT_REPORT | Procedure | Procedure(TBNAME VARCHAR2, -- Table name C1NAME VARCHAR2, -- Column 1 C2NAME VARCHAR2, -- Column 2 C3NAME VARCHAR2, -- Column 3 LABEL1 VARCHAR2, -- Label for... | Trigger: FT_PRINT in Form | **COMMENTED OUT / INACTIVE** - Submits the GENCODEP report object to the report server with the supplied table, column, label, and user ID parameters after prompting the user for print confirmation. This call appears only in the commented-out FT_PRINT trigger body and is not executed at runtime. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 2

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Checks whether a supplied WebUtil handle has a NULL (invalid) value; returns TRUE if the handle is null. Called in VIEW_EXCEL_REP to verify that a record group handle is valid before attempting to delete or use it. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_dead_stk_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Presents the client-side OS file-save dialog, optionally pre-seeding the directory, file name, file filter, and dialog title; returns the fully qualified path chosen by the user, or NULL if cancelled. This call appears only in the commented-out portion of VIEW_EXCEL_REP and is not executed at runtime. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_dead_stk_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Downloads the resource at sourceURL to the clientDestination path on the end-user's machine; the optional fileSize hint assists progress reporting. Returns TRUE on success. This call appears only in the commented-out portion of VIEW_EXCEL_REP and is not executed at runtime. |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pe_dead_stk_rep_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP | **COMMENTED OUT / INACTIVE** - Executes the supplied operating-system command string on the client machine and returns a PLS_INTEGER exit/status code. This call appears only in the commented-out portion of VIEW_EXCEL_REP and is not executed at runtime. |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Dead Stock Liquidation Report Service | PS_DEAD_STOCK, AM_DEALER_LOC, PM_PART, PM_CATEGORY, AM_LIST (MULDMS.AM_LIST), GM_STATE, GM_CITY | parent_group, dealer_map_cd, loc_cd, consg_cd, state_cd, principal, from_date, to_date, sale_type, price_unit, part_num (optional), root_part_num (optional), part_category (optional) | CSV-formatted rows: dealer, state, code, location, part_num, part_desc, value, customer_segment, customer_id, customer_name, date_of_liquidation, part_category (detail); or aggregated by category (summary) | Retrieves dead stock liquidation transactions within the specified date range and filters, computing part value using the selected price basis; supports both detail and summary views | `GET /api/dead-stock/liquidation/report` |
| MS-002 | Dead Stock Inventory Report Service | PM_PART_DEAD_STOCK, AM_DEALER_LOC, PM_PART, PM_CATEGORY, PM_STOCK_BIN_LOC (MULDMS), GM_STATE, GM_CITY | parent_group, dealer_map_cd, loc_cd, consg_cd, state_cd, principal, part_num (optional), root_part_num (optional), part_category (optional) | CSV-formatted rows: dealer, state, code, location, part_num, part_desc, quantity, value, part_category (detail); or aggregated by category (summary) | Retrieves the current on-hand quantity and value of dead stock parts at each dealer location using bin-level stock data and the landed-cost price function; supports both detail and summary views | `GET /api/dead-stock/inventory/report` |
| MS-003 | Part Category List Service | PM_CATEGORY | principal_map_cd | List of category descriptions and codes plus an "All" option | Provides the available part categories for the report filter drop-down, filtered to the current dealer organisation | `GET /api/parts/categories` |
| MS-004 | Dealer Location Lookup Service | AM_DEALER_LOC, GM_STATE, GM_CITY | principal_map_cd, parent_group (optional), consg_cd (optional), state_cd (optional), dealer_name (optional) | Lists of consignee codes, states, dealer names, and locations for filter selection | Supports the cascading filter lookups on the report screen: consignee -> state -> dealer -> location; returns the "All" option for OEM-level users | `GET /api/dealer-locations/lookup` |
| MS-005 | Dealer Mapping Code Resolution Service | AM_DEALER_LOC | parent_group, loc_cd, principal_map_cd | dealer_map_cd | Resolves the unique internal dealer mapping code for a selected location and dealer group within the current principal organisation | `GET /api/dealer-locations/mapping-code` |
| MS-006 | Report File Export Service | (file system / report server) | filename, query_string, column_name | CSV file written to report server; URL for browser download | Executes a supplied data query, writes the results to a CSV file on the report server, and returns the URL for the user to download or view the file in a browser | `POST /api/reports/export/csv` |

**Total Microservices Identified: 6**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation | WHEN-NEW-FORM-INSTANCE fires when the user opens the Dead Stock report screen | 1. Maximise the main window. 2. Load part categories from the category master into the Part Category filter drop-down. 3. Bind the record group to the Part Category list. 4. Default Part Category to "All". 5. Default From Date and To Date to today's date. | None - all steps execute unconditionally | Dead Stock report screen is displayed with the Part Category list populated and date filters defaulted to today |
| WF-002 | Report Type Selection | WHEN-LIST-CHANGED fires on the Report Type field when the user selects a report type | 1. Detect the selected report type. 2a. If an inventory type is selected: reset From/To Dates to today, set Price Type to DDL, disable Sale Type / From Date / To Date / Price Type. 2b. If a liquidation type is selected: enable and make navigable Sale Type / From Date / To Date / Price Type. | Report type value: inventory-based (I or IS) vs. liquidation-based (L or LS) | Screen filter fields are configured to match the requirements of the selected report type |
| WF-003 | Filter Criteria Entry and Validation | WHEN-VALIDATE-ITEM fires on each mandatory filter field when the user leaves it; WHEN-NEW-ITEM-INSTANCE fires on State, Dealer Name, and Location to auto-show the lookup list | 1. User navigates into State, Dealer Name, or Location field - the relevant lookup list is automatically presented. 2. User enters or selects a value. 3. On field exit, system validates that the field is not blank; if blank, shows an error and keeps the cursor. 4. For Location: if a specific location is entered, the dealer mapping code is derived from the dealer/location master. | Null check on each mandatory field; Location value "ALL" vs. specific value (determines whether dealer mapping code is looked up or set to "ALL") | All mandatory filter fields have valid values and the dealer mapping code has been resolved |
| WF-004 | Excel Report Generation | WHEN-BUTTON-PRESSED fires on the Excel Report button when the user clicks it | 1. Initialise the four dynamic SQL filter parameters to null. 2. Append part number filter clause if a specific part number was entered. 3. Append root part number filter clause if a root part number was entered. 4. Build the sale type filter clause based on the selected sale type. 5. Construct the full data query for the selected report type (liquidation detail, inventory detail, liquidation summary, or inventory summary). 6. Call VIEW_EXCEL_REP to execute the query, write the results to a CSV file on the server, and open the file in a new browser window. | Report type determines which of four query templates is used; part number and root part number entered or not; sale type selection determines the transaction filter clause; file path spaces trigger redirection to C:\; row count exceeding 65,536 triggers truncation warning; WHEN OTHERS exception triggers error message and abort | The generated CSV report file is opened in a new browser window for the user to view or save |
| WF-005 | Cancel and Clear Screen | FT_CANCEL fires (via toolbar Cancel button or WHEN-BUTTON-PRESSED delegating to FT_CANCEL); KEY-CLRFRM fires as the actual form-clear action | 1. Check whether the Cancel button is enabled; if not, do nothing. 2. Check whether filter criteria have been modified; if yes, ask the user to confirm before clearing. 3. If the user confirms (or no changes existed), clear all filter criteria. 4. Reset From Date and To Date to today's date. 5. Re-enable and make navigable the From Date, To Date, Sale Type, and Price Type fields. 6. Reset Part Category to "All". | Cancel button enabled/disabled; form status changed or unchanged; user confirms or declines when data is changed | Screen is cleared and reset to its initial state, ready for new filter criteria |
| WF-006 | Session Registration and Exit | PRE-FORM fires before the form opens; KEY-EXIT fires when the user exits (via toolbar Exit button or KEY-EXIT key) | 1. PRE-FORM: register the session client information and module name in the database as 'pe_dead_stk_rep'. 2. KEY-EXIT / PB_EXIT: close the form immediately without validating unsaved data. 3. Clear the session client information and module name from the database (KEY-EXIT path only). | None | The Dead Stock report screen is closed and the database session monitoring no longer identifies this session as running the Dead Stock report module |

**Total Workflows Identified: 6**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is checked, then its null status is returned to allow safe deletion or use |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form | /api/v1/pld/ask_confirm | When the user initiates a cancel action, then a confirmation alert is displayed before the form is cleared |
| PLD-002 | DELETE_RECGRP_ROW | Business Logic | Trigger: FT_DEL in Form | /api/v1/pld/delete_recgrp_row | **COMMENTED OUT / INACTIVE** - When a row deletion is requested, then the specified row is removed from the named record group |
| PLD-003 | DISP_TEXT | Business Logic | Trigger: FT_DEL in Form, Trigger: FT_INSERT in Form, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.CONSG_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.DEALER_NAME, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.LOC_CD, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CNTRL_BLK.STATE_CD | /api/v1/pld/disp_text | When a validation error or informational message must be shown, then the appropriate alert is displayed with the supplied title and message text |
| PLD-004 | l_pop_list_item | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_pop_list_item | When the form opens, then a record group is created from a SQL query and used to populate a list item with selectable values |
| PLD-005 | PRINT_REPORT | Business Logic | Trigger: FT_PRINT in Form | /api/v1/pld/print_report | **COMMENTED OUT / INACTIVE** - When a print action is triggered, then the report object is submitted to the report server with the supplied parameters |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pe_dead_stk_rep_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/pe_dead_stk_rep-8186e579d3ca/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Dead Stock Liquidation Transactions (PS_DEAD_STOCK) | Database table - SELECT | Supplies liquidation transaction records for the liquidation detail and liquidation summary report queries | Form reads from PS_DEAD_STOCK during Excel report generation (WHEN-BUTTON-PRESSED on PB_EXCEL); no writes | Errors during query execution are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP; user sees the system error code and text and processing aborts |
| Dead Stock Inventory Register (PM_PART_DEAD_STOCK) | Database table - SELECT | Identifies parts classified as dead stock at each dealer location for the inventory detail and inventory summary report queries | Form reads from PM_PART_DEAD_STOCK during Excel report generation | Errors during query execution are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP |
| Dealer and Location Master (AM_DEALER_LOC) | Database table - SELECT | Provides dealer and location data for the cascading filter lookups (consignee, state, dealer, location) and is the central joining entity in all report queries; also used to derive the dealer mapping code when a specific location is selected | Form reads from AM_DEALER_LOC during filter lookup (record groups RG_CONSG, RG_DEALER, RG_LOC, RG_STATE), during location validation (WHEN-VALIDATE-ITEM on LOC_CD), and during Excel report generation | Location validation errors raise FORM_TRIGGER_FAILURE; report query errors caught by WHEN OTHERS in VIEW_EXCEL_REP |
| Parts Master (PM_PART / MULDMS.PM_PART) | Database table - SELECT | Supplies part descriptions, category codes, root part numbers, and the part price function linkage for all four report types | Form reads from PM_PART during Excel report generation as part of the dynamic query | Errors during query execution are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP |
| Part Category Master (PM_CATEGORY / MULDMS.PM_CATEGORY) | Database table - SELECT | Provides part category descriptions and codes for the Part Category filter drop-down and for the category description column in report output | Form reads from PM_CATEGORY at form start-up (WHEN-NEW-FORM-INSTANCE) via GENERAL.L_POP_LIST_ITEM and during Excel report generation | Errors at form start-up would prevent the Part Category list from loading; errors during report generation are caught by WHEN OTHERS in VIEW_EXCEL_REP |
| Transaction Type Reference (AM_LIST / MULDMS.AM_LIST) | Database table - SELECT | Classifies dead stock liquidation transactions by document type and billing type for the sale type filter in the liquidation queries | Form reads from AM_LIST during Excel report generation for liquidation report types | Errors during query execution are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP |
| State Master (GM_STATE / MULDMS.GM_STATE) | Database table - SELECT | Provides state descriptions and codes for the state filter lookup and for the state description column in report output | Form reads from GM_STATE via the RG_STATE record group for the state lookup and during Excel report generation | Errors during report generation are caught by WHEN OTHERS in VIEW_EXCEL_REP |
| City Master (GM_CITY / MULDMS.GM_CITY) | Database table - SELECT | Provides city/location descriptions for the location description column in report output | Form reads from GM_CITY during Excel report generation | Errors during report generation are caught by WHEN OTHERS in VIEW_EXCEL_REP |
| Stock Bin Location (PM_STOCK_BIN_LOC / MULDMS.PM_STOCK_BIN_LOC) | Database table - SELECT | Provides bin-level stock quantities used to calculate net on-hand quantity and value for the inventory detail and inventory summary report types | Form reads from PM_STOCK_BIN_LOC as a subquery during Excel report generation for inventory report types | Errors during query execution are caught by the WHEN OTHERS handler in VIEW_EXCEL_REP |
| Database session monitoring (DBMS_APPLICATION_INFO) | Oracle system package | Registers and clears the form module name in the database session's client information and module name fields, enabling session monitoring tools to identify the active form | Form calls SET_CLIENT_INFO and SET_MODULE at form open (PRE-FORM) and at form exit (KEY-EXIT) | No explicit error handling; Oracle built-in |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Report Server File System | File write (Oracle TEXT_IO via form program unit VIEW_EXCEL_REP) | Writes the generated CSV report data to a file on the Oracle Application Server (IAS) report output directory | Server-side file I/O (TEXT_IO.FOPEN / TEXT_IO.PUT_LINE / TEXT_IO.FCLOSE in VIEW_EXCEL_REP) | `/iashome/ias/reports/printer/<filename>.csv` (INFERRED from hardcoded path in VIEW_EXCEL_REP) | Form writes CSV rows to the server file; each data row from the record group is written as one line | Success: file created and closed normally. Error: WHEN OTHERS handler in VIEW_EXCEL_REP catches failures and displays the system error code and message |
| Report Server URL Configuration | File read (Oracle TEXT_IO via form program unit VIEW_EXCEL_REP) | Reads the base URL used to construct the browser download link for the generated report file | Server-side file I/O (TEXT_IO.FOPEN / TEXT_IO.GET_LINE / TEXT_IO.FCLOSE in VIEW_EXCEL_REP) | `/reports/DMS/excelpath.txt` (hardcoded path in VIEW_EXCEL_REP) | Form reads one line from the configuration file to obtain the base URL; used to build the full download URL | Success: URL read and used to open the file in the browser. Error: any failure is caught by the WHEN OTHERS handler |
| Web Browser (Oracle Forms WEB package) | Browser document open (WEB.SHOW_DOCUMENT) | Opens the generated CSV report file in a new browser tab or window so the user can view or save it | Oracle Forms WEB package call within VIEW_EXCEL_REP | Server report URL constructed from the base URL read from the configuration file plus the generated filename | Form passes the full file URL to WEB.SHOW_DOCUMENT; no data is returned from the browser | Success: report file opens in a new browser window. Error: any failure is caught by the WHEN OTHERS handler in VIEW_EXCEL_REP |

### 20.3 Report Integrations

*No Oracle Reports (.rdf / .rep) integrations are present in this form. The `reference_data.reports` list is empty. Report output is generated by the form's own program unit (VIEW_EXCEL_REP) writing directly to a CSV file on the report server, which is then opened in the browser via WEB.SHOW_DOCUMENT. No Oracle Reports Server calls are made.*

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PS_DEAD_STOCK form.

### 21.1 Catalogue Index

13 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-002](#SP-002--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-003](#SP-003--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-004](#SP-004--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-005](#SP-005--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-006](#SP-006--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-007](#SP-007--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-008](#SP-008--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-009](#SP-009--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-010](#SP-010--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-011](#SP-011--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-012](#SP-012--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-013](#SP-013--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |

---

### 21.2 Detailed Specifications

#### SP-001 - VIEW_EXCEL_REP

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

DEAD STOCK (WN_MAIN / CN_MAIN)

---

**Purpose**

Generates a CSV-formatted report file on the application server from the supplied report query, then opens the file in a new browser window so the user can view or save it as an Excel-compatible spreadsheet. Handles path-space restrictions by redirecting the output to the C drive root, enforces a maximum of 65,535 data rows, and communicates any unexpected failures to the user before aborting.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-006](#SP-006--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-007](#SP-007--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-010](#SP-010--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-011](#SP-011--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-012](#SP-012--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output filename from the current user's login identifier combined with the current date and time, then append the `.csv` extension. If the derived path contains a space character in any folder name, redirect the file to the root of the C drive and inform the user that the default storage location is being used.
- Step 2 - Check whether a record group named `DataRecordSet` already exists in the session; if it does, delete it to ensure the previous run's data does not contaminate the new report.
- Step 3 - Create a new record group by executing the supplied report query against the database, which retrieves the dead stock or liquidation report data matching the user's selected filter criteria.
- Step 4 - Populate the record group with the results returned by the query.
- Step 5 - Count the number of data rows returned. If the count exceeds 65,536, notify the user that the output will be limited to 65,535 rows and set the working row count to 65,535.
- Step 6 - Determine the server-side file path by constructing it as `/iashome/ias/reports/printer/` followed by the output filename.
- Step 7 - Read the base URL for browser download from the server configuration file `/reports/DMS/excelpath.txt` and combine it with the output filename to form the full browser-accessible URL.
- Step 8 - Open the server-side output file for writing, then iterate through each row of the record group and write the row's data as a line to the CSV file. Close the file after all rows have been written.
- Step 9 - Open the generated CSV file in a new browser window using the constructed URL so the user can immediately view or save the report.
- Step 10 - If any unexpected error occurs during the above steps, display the system error code and description text to the user and abort further processing.

---
**Decision Points**

DP-001

Condition:
The derived output file path contains a space character in one of the folder names.

TRUE:
Redirect the output filename to the root of the C drive (stripping the path prefix and using only the filename portion); display the message "File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default." to the user; continue processing with the redirected path.

FALSE:
Use the derived file path as-is without any redirection.

---

DP-002

Condition:
A record group named `DataRecordSet` already exists in the current Oracle Forms session.

TRUE:
Delete the existing record group to ensure a clean rebuild before creating the new one.

FALSE:
Proceed directly to creating a new record group from the supplied query.

---

DP-003

Condition:
The number of data rows returned by the report query exceeds 65,536.

TRUE:
Display the message "Maximum number of rows in excel exceeded. It will truncate to 65535 rows." to the user; limit the number of rows written to the output file to 65,535.

FALSE:
Write all returned rows to the output file without truncation.

---

DP-004

Condition:
An unexpected error occurs at any point during record group creation, file writing, or browser launch (WHEN OTHERS exception).

TRUE:
Display the system error code and error description text in the format "Error  - " followed by the code and text; raise a form trigger failure to abort further processing.

FALSE:
Complete all steps normally and open the generated file in the browser.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The output filename must not contain spaces in any folder name component; if it does, the file is redirected to the C drive root to ensure successful creation.
- BR-002 - The report output is capped at 65,535 rows to remain within the maximum supported row count for an Excel-compatible CSV file; any excess rows are silently dropped after the user is warned.
- BR-003 - Any unhandled system or database error during report generation causes an immediate abort with the system error code and description displayed to the user; partial output is discarded.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, p_query VARCHAR2,p_column_name VARCHAR2) IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_tot_rec    NUMBER (6);
	--po_part_tab   pk_part_search_new.part_tab_10;
	po_part_tab   pk_part_search_new.part_tab_11;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);
	order_by      VARCHAR2 (300);
	vcfile varchar2(150);
	lv_user  varchar2(150);
	l_Old_URL varchar2(500);	
		l_new_URL varchar2(500);	
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
begin
lv_user := name_in(':global.userid');  -- New line added after dpl change
vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS');    -- New line added after dpl change
vcFile := vcFile||'.csv';
if vcFile is null then
	--FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
	null;
else
	filename:=vcFile;
end if;
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;
	
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;

	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	--formserverpath := 'http://10.100.34.230:7778/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	  	--TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
      text_io.fclose(myfile);
   
	 --	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	/* 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);*/
	 	
	 	web.show_document(formserverpath,'_blank');
	exception
		when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
	end;

```

#### SP-002 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [Trigger: FT_CANCEL]

---

**Screen:**

N/A

---

**Purpose**

Displays a caution confirmation alert to the user with the supplied message text and waits for a button response. Returns 1 if the user confirms (presses the first button) or 0 if the user declines (presses any other button). Used by the Cancel flow to give the user an opportunity to confirm before their entered filter criteria are discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the message text of the AL_CONFIRM caution alert to the confirmation message supplied by the caller.
- Step 2 - Display the AL_CONFIRM alert to the user and wait for a button press.
- Step 3 - Evaluate the button the user pressed: if it is the first button (confirm), return 1 to the caller; for any other button, return 0 to indicate the user has declined.

---
**Decision Points**

DP-001

Condition:
The user presses the first button (confirm) on the AL_CONFIRM alert dialog.

TRUE:
Return 1 to the caller, indicating the user has confirmed the action.

FALSE:
Return 0 to the caller, indicating the user has declined and the action should be cancelled.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation dialog displays exactly the message text provided by the caller, allowing any calling trigger to customise the prompt for its specific context.
- BR-002 - Only a press of the first alert button constitutes confirmation; pressing any other button is treated as a cancellation.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-003 - GENERAL.DISP_TEXT

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [Trigger: FT_DEL]
- pe_dead_stk_rep_fmb.xml [Trigger: FT_INSERT]
- pe_dead_stk_rep_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

DEAD STOCK (WN_MAIN / CN_MAIN)

---

**Purpose**

Displays a message alert to the user with the supplied title and message text. Selects the error alert (AL_ERRINFO) when the title indicates an error, or the note alert (AL_NOTE) for any other message type. Used throughout the form to present field-level validation errors and informational notifications in a consistent, user-friendly format.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the title supplied by the caller: if the title (uppercased) equals 'ERROR', select the AL_ERRINFO error alert; for any other title value, select the AL_NOTE informational alert.
- Step 2 - Set the title of the selected alert dialog to the title string supplied by the caller.
- Step 3 - Set the message body of the selected alert dialog to the message text supplied by the caller.
- Step 4 - Display the alert and wait for the user to acknowledge it by pressing the alert button.

---
**Decision Points**

DP-001

Condition:
The title string supplied by the caller, when uppercased, equals 'ERROR'.

TRUE:
Select the AL_ERRINFO error-style alert to display the message.

FALSE:
Select the AL_NOTE informational-style alert to display the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The choice of alert style (error vs. informational) is determined solely by whether the caller passes a title of 'ERROR' (case-insensitive); all other titles produce a note-style alert.
- BR-002 - Both the title and the message body of the displayed alert are set dynamically at runtime from the caller's input, ensuring the alert content always reflects the specific validation context.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-004 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

DEAD STOCK (WN_MAIN / CN_MAIN)

---

**Purpose**

Builds an in-memory record group from a supplied SQL query and makes it available as the data source for a form list item. If a record group with the target name already exists, it is deleted and rebuilt from scratch to ensure the list always reflects the current data. Used at form startup to populate the Part Category filter drop-down from the part category master.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-011](#SP-011--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Look up whether a record group with the name supplied in p_rg_name already exists in the current Oracle Forms session.
- Step 2 - If the record group already exists, delete it to ensure a fresh rebuild; if it does not exist, proceed to creation.
- Step 3 - Create a new record group by executing the SQL query supplied in p_select, which retrieves the list values (category descriptions and codes, plus an "All" option) from the database.
- Step 4 - Populate the record group with the data returned by the query, making the results available for binding to the target list item.

---
**Decision Points**

DP-001

Condition:
A record group with the name p_rg_name already exists in the current Oracle Forms session.

TRUE:
Delete the existing record group before creating a new one from the supplied query.

FALSE:
Proceed directly to creating the new record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The record group is always rebuilt from scratch each time this procedure is called, ensuring the list item always reflects the current state of the source data without retaining stale cached values.
- BR-002 - The SQL query used to populate the list is supplied entirely by the caller, making this a general-purpose list-population utility applicable to any form list item.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-005 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays an error message to the user through the WebUtil error alert (m_errorAlert) when an underlying WebUtil bean or property operation fails. If the error alert handle is available, sets the alert message text and shows the alert; if the handle is not available, falls back to displaying the message via the Oracle Forms message function.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-011](#SP-011--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the WebUtil error alert handle (m_errorAlert) is currently available and valid.
- Step 2 - If the handle is valid, set the alert's message text to the supplied error text and display the alert to the user by calling SHOW_ALERT.
- Step 3 - If the handle is not valid (WebUtil bean not yet registered or handle not initialised), display the error message using the Oracle Forms message function with the prefix 'WebUtil Error: ' followed by the error text.

---
**Decision Points**

DP-001

Condition:
The WebUtil error alert handle (m_errorAlert) is not null (i.e. it is a valid, registered alert handle).

TRUE:
Set the alert message text to errText and show the alert to the user.

FALSE:
Display the error message via the Oracle Forms message function as a fallback.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error messages from WebUtil bean failures are always surfaced to the user, either through a formatted alert dialog or through the Forms message bar, ensuring failures are never silently swallowed.
- BR-002 - The message text presented to the user is the exact error text passed by the calling routine without modification.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-006 - WEBUTIL.FCLOSE

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by invoking WEBUTIL.SETPROPERTY to send a close instruction to the WebUtil file I/O bean for the supplied file handle, then nullifies the handle to prevent accidental reuse. If the WebUtil bean is not registered, WEBUTIL.ERRORALERT displays a descriptive message (using WEBUTIL.GETIMPLCLASS to resolve the bean class name) before raising a tool error. A property communication failure also raises a tool error, ensuring that failed close attempts are never silently ignored.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-005](#SP-005--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-008](#SP-008--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-013](#SP-013--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the supplied file handle is not null, indicating the file is currently open and requires a close operation.
- Step 2 - If the handle is not null, call WEBUTIL.SETPROPERTY with the WUF_PACKAGE constant, the WUF_TEXTIO_CLOSE command, and the current handle value to instruct the WebUtil file I/O bean to flush and close the underlying client-side file.
- Step 3 - Set the file handle to NULL, marking the file object as closed and preventing any further read, write, or close operations against it.
- Step 4 - If a BEAN_NOT_REGISTERED exception is raised during the close operation, call WEBUTIL.ERRORALERT with a message that includes the bean class name resolved by WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to propagate the failure to the caller.
- Step 5 - If a PROPERTY_ERROR exception is raised during the close operation, raise TOOL_ERR.TOOL_ERROR to propagate the failure to the caller without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
The supplied file handle is not null.

TRUE:
Call WEBUTIL.SETPROPERTY to close the file on the client side, then set the handle to NULL.

FALSE:
Take no action - the file is already closed or was never opened.

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is raised during the close operation.

TRUE:
Call WEBUTIL.ERRORALERT with a message containing the class name returned by WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to signal the failure to the caller.

FALSE:
Continue normally.

---

DP-003

Condition:
A PROPERTY_ERROR exception is raised during the close operation.

TRUE:
Raise TOOL_ERR.TOOL_ERROR to signal the property communication failure to the caller.

FALSE:
Continue normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Once a file is successfully closed, its handle is set to NULL so that subsequent calls with the same file object are safely ignored, preventing double-close errors.
- BR-002 - If the WebUtil bean is not registered, WEBUTIL.ERRORALERT must be invoked with a message that identifies the unresolvable bean class (obtained via WEBUTIL.GETIMPLCLASS) before the tool error is raised, ensuring the operator receives an actionable diagnostic message.
- BR-003 - Both BEAN_NOT_REGISTERED and PROPERTY_ERROR conditions must result in TOOL_ERR.TOOL_ERROR being raised, ensuring that any failure to close the file is surfaced to the calling routine rather than silently suppressed.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-007 - WEBUTIL.FOPEN

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a text file on the client for reading, writing, or appending by configuring the WebUtil file I/O bean with the supplied file path, access mode, and optional character set, then retrieving a file handle via WEBUTIL.GETPROPERTY. Returns a file_type object containing the numeric handle that the caller uses for subsequent read or write operations. Validates the mode and filename before attempting the open, and raises a tool error if the open fails or if the WebUtil infrastructure is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-009](#SP-009--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the file mode supplied (case-insensitive) is one of the accepted values ('r' for read, 'w' for write, 'a' for append); if not, raise TOOL_ERR.TOOL_ERROR immediately.
- Step 2 - Validate that a file path (spec) has been supplied and is not null or empty; if not, raise TOOL_ERR.TOOL_ERROR.
- Step 3 - Push the file path to the WebUtil bean by setting the WUF_FILENAME property via WebUtil_Core.setProperty.
- Step 4 - Push the access mode to the WebUtil bean by setting the WUF_TEXTIO_FILEMODE property.
- Step 5 - Push the character set to the WebUtil bean: if charSet is null, set WUF_TEXTIO_CHARSET to the literal '(null)'; otherwise set it to the supplied charSet value.
- Step 6 - Invoke WEBUTIL.GETPROPERTY (via WebUtil_Core.getProperty) to request the WUF_TEXTIO_OPEN property, which instructs the bean to open the file and return a numeric handle string.
- Step 7 - Evaluate the returned handle string: if it is null, empty, or '-1', the file could not be opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid handle string to a number using TO_NUMBER, store it in the file_type record's handle field, and return the file_type object to the caller.
- Step 9 - In the exception block, handle BEAN_NOT_REGISTERED by displaying an alert identifying the missing bean class and then raising TOOL_ERR.TOOL_ERROR; re-raise PROPERTY_ERROR and VALUE_ERROR (as TOOL_ERR.TOOL_ERROR) and TOOL_ERR.TOOL_ERROR as-is.

---
**Decision Points**

DP-001

Condition:
The file mode (lowercased) is not one of 'r', 'w', or 'a'.

TRUE:
Raise TOOL_ERR.TOOL_ERROR - the requested access mode is not supported; no file system operation is attempted.

FALSE:
Continue to validate the file path.

---

DP-002

Condition:
The file path (spec) is null or empty.

TRUE:
Raise TOOL_ERR.TOOL_ERROR - no file path was provided.

FALSE:
Continue to configure the WebUtil bean properties and open the file.

---

DP-003

Condition:
The charSet parameter is null.

TRUE:
Set the WUF_TEXTIO_CHARSET bean property to the literal string '(null)'.

FALSE:
Set the WUF_TEXTIO_CHARSET bean property to the supplied charSet value.

---

DP-004

Condition:
The handle string returned by WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN) is null, empty, or '-1'.

TRUE:
Raise TOOL_ERR.TOOL_ERROR - the bean could not open the file at the specified path.

FALSE:
Convert the handle to a number and return the populated file_type object to the caller.

---

DP-005

Condition:
A BEAN_NOT_REGISTERED exception is raised during bean interaction.

TRUE:
Display an error alert identifying the missing implementation class, then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Not applicable - this branch is only entered on the named exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only 'r' (read), 'w' (write), and 'a' (append) are accepted access modes (evaluated case-insensitively); any other value is rejected before any bean property is set or any file system operation is attempted.
- BR-002 - A null or empty file path is rejected immediately, preventing the system from attempting to open an unspecified file location.
- BR-003 - The character set passed to the WebUtil bean must always be an explicit string; when the caller omits charSet, the literal '(null)' is transmitted to the bean rather than a SQL NULL, ensuring the bean receives a well-formed property value.
- BR-004 - The file handle is obtained exclusively through WEBUTIL.GETPROPERTY (WUF_TEXTIO_OPEN); no direct file system call is made by this procedure.
- BR-005 - If the WebUtil bean cannot open the file (returns a null, empty, or '-1' handle), the caller is notified via TOOL_ERR.TOOL_ERROR so that the invoking process (VIEW_EXCEL_REP) can abort cleanly.
- BR-006 - If the WebUtil bean is not registered in the Forms session, an informational alert identifying the missing bean class is raised before the tool error is propagated, aiding support diagnosis.
- BR-007 - A VALUE_ERROR during handle conversion (TO_NUMBER) is treated as a tool error, ensuring that a malformed handle returned by the bean does not cause an unhandled exception to propagate to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-008 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package identifier. Used internally by the WebUtil infrastructure to construct meaningful error messages when a required WebUtil bean cannot be found or is not registered, by providing the Java class name that was expected to be present.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Combine the WebUtil Java root path constant (WEBUTIL_JAVA_ROOT) with the implementation class name stored in the m_implClasses array at the position identified by the supplied package identifier.
- Step 2 - Return the resulting fully qualified class name string to the caller.

---
**Decision Points**

No conditional branches in the resolved source - this function always returns a concatenated string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The returned class name is composed entirely of static configuration values (the Java root constant and the pre-configured class name array) and is not influenced by any runtime state, ensuring consistent error message construction across all invocations.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-009 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property by invoking the JNI bridge to call the Java `System.getProperty` method. Used internally by the WebUtil infrastructure to read server-side configuration values needed for file I/O and other WebUtil operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Prepare a Java Native Interface (JNI) argument list containing the property name supplied by the caller.
- Step 2 - Invoke the Java `System.getProperty` static method via the JNI bridge, passing the property name, and retrieve the property value as a string.
- Step 3 - Return the property value string to the caller.

---
**Decision Points**

No conditional branches in the resolved source - this function always delegates to the JNI layer and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Property lookup is delegated entirely to the Java Virtual Machine via the JNI bridge; the function does not cache or validate the returned value, passing it directly to the caller for use.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-010 - WEBUTIL.GET_LINE

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads one line of text from an open server-side text file by communicating with the WebUtil Core bean, returning the line content in the output parameter. Signals end-of-file by raising a NO_DATA_FOUND exception when the bean returns a single newline character - the agreed sentinel indicating that reading has passed the end of the file. Raises TOOL_ERR.TOOL_ERROR if the WebUtil Core bean is not registered or if a property communication failure occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the file handle from the input parameter to the WebUtil Core bean by setting the WUF_TEXTIO_HANDLE property, identifying which open file to read from.
- Step 2 - Request the next line of text from the bean by retrieving the WUF_TEXTIO_GETLINE property; the bean returns the line content as a string into a local buffer.
- Step 3 - Evaluate the returned buffer: if the buffer contains only a newline character (chr(10)), the bean has signalled end-of-file - raise NO_DATA_FOUND to notify the caller that no further lines are available.
- Step 4 - If the buffer contains any other content, assign the buffer value to the output parameter and return it to the caller as the next line of file content.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during the operation, invoke WebUtil_Core.ErrorAlert with the implementation class name and a descriptive message, then raise TOOL_ERR.TOOL_ERROR.
- Step 6 - If a PROPERTY_ERROR exception is raised during the operation, raise TOOL_ERR.TOOL_ERROR directly.

---
**Decision Points**

DP-001

Condition:
The buffer returned by the WebUtil Core bean equals a single newline character (chr(10)), which the bean uses as a sentinel to signal that reading has passed the end of the file.

TRUE:
Raise NO_DATA_FOUND to signal to the caller that the end of the file has been reached.

FALSE:
Assign the buffer value to the output parameter and return it to the caller as the next line of file content.

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is raised during the bean property interaction.

TRUE:
Invoke WebUtil_Core.ErrorAlert with the bean implementation class name and a message stating that CLIENT_TEXT_IO.get_line will not work, then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Continue normal processing.

---

DP-003

Condition:
A PROPERTY_ERROR exception is raised during the bean property interaction.

TRUE:
Raise TOOL_ERR.TOOL_ERROR to signal a property communication failure to the caller.

FALSE:
Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - End-of-file is communicated to the caller via a NO_DATA_FOUND exception rather than a return value, matching the Oracle TEXT_IO convention and allowing callers to use a standard exception handler for loop termination.
- BR-002 - A single newline character (chr(10)) is the agreed sentinel between the WebUtil Core bean and this procedure for signalling end-of-file; this convention must be preserved because get_line would never normally return a newline - it uses that character internally to delimit lines during reading.
- BR-003 - If the WebUtil Core bean is not registered, a user-facing alert is raised via WebUtil_Core.ErrorAlert before escalating to TOOL_ERR.TOOL_ERROR, ensuring the operator receives a meaningful diagnostic message.
- BR-004 - A PROPERTY_ERROR during bean communication results in an immediate TOOL_ERR.TOOL_ERROR with no further processing, protecting the caller from acting on an undefined or corrupt buffer value.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-011 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- pe_dead_stk_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil or Oracle Forms handle is null (invalid), returning TRUE if the handle has no value and FALSE if it is a valid, non-null reference. Used as a pre-flight check before attempting to use or delete a handle, preventing errors from operations on uninitialised or already-released objects.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the internal numeric identifier (hnd field) of the supplied handle.
- Step 2 - If the hnd field is null, return TRUE to the caller, indicating the handle is invalid or unset.
- Step 3 - If the hnd field is not null, return FALSE to the caller, indicating the handle references a valid object.

---
**Decision Points**

DP-001

Condition:
The hnd field of the supplied handle is null.

TRUE:
Return TRUE - the handle is null/invalid; the caller should not attempt to use or delete it.

FALSE:
Return FALSE - the handle is valid; the caller may safely proceed with using or deleting it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This function is a pure null-check utility; it does not modify any state and is safe to call at any time as a guard before handle-dependent operations.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-012 - WEBUTIL.PUT_LINE

**Invoked From:**

- pe_dead_stk_rep_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes one line of text to an open server-side text file by sending the file handle, the text content, and a newline instruction to the WebUtil file I/O bean. Used in the report generation loop to write each data row from the record group to the CSV output file. Raises a tool error if the WebUtil bean is not registered or if a property communication failure occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Send the file handle to the WebUtil file I/O bean to identify which open file to write to.
- Step 2 - Send the text content to be written as the next line of the file.
- Step 3 - Send a newline instruction to the bean to append a line terminator after the text, completing the line in the file.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised during the write operation.

TRUE:
Call WEBUTIL.ERRORALERT with the bean-not-found message and raise TOOL_ERR.TOOL_ERROR.

FALSE:
Complete the write operation normally.

---

DP-002

Condition:
A PROPERTY_ERROR exception is raised during the write operation.

TRUE:
Raise TOOL_ERR.TOOL_ERROR to propagate the failure to the caller.

FALSE:
Complete the write operation normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Each call writes exactly one line (the supplied text followed by a newline), ensuring that each data row in the CSV report occupies its own line in the output file.
- BR-002 - If the WebUtil infrastructure is unavailable, the write operation raises a tool error so that the calling report generation routine can abort cleanly rather than producing a silently incomplete output file.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-013 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value by invoking the JNI bridge to call the Java `System.setProperty` static method. This function is used by the WebUtil infrastructure (specifically called from WEBUTIL.FCLOSE) to configure system-level properties required during WebUtil file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list sized for two arguments using JNI.CREATE_ARG_LIST.
- Step 2 - Add the property name (a0) to the argument list as a string argument via JNI.ADD_STRING_ARG.
- Step 3 - Add the property value (a1) to the argument list as a string argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java `System.setProperty` static method via JNI.CALL_STRING_METHOD, passing the constructed argument list, and return the result (the previous value of the property) to the caller.

---
**Decision Points**

No conditional branches exist in the implementation - the function unconditionally constructs the JNI argument list, delegates to the Java layer, and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Property setting is delegated entirely to the Java Virtual Machine via the JNI bridge; no validation of the property name (a0) or value (a1) is performed before passing them to the Java layer.
- BR-002 - The Java `System.setProperty` method returns the previous value of the named property, which this function passes back to the caller, allowing the caller to restore the original value if required.
- BR-003 - This function has no internal or external PL/SQL dependencies; all processing is performed exclusively through the JNI bridge calls (JNI.CREATE_ARG_LIST, JNI.ADD_STRING_ARG, JNI.CALL_STRING_METHOD).

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Extended Warranty Incentive Detail - VD_EW_INCE_DTL
    - Report Configuration - ED_REPORTS
    - Report Server Configuration - EH_REPORTS
    - Financial Company Calendar - FM_COMPANY
    - User-Region Access - AM_USER_REGION
    - Dealer Location Master - AM_DEALER_LOC and AM_DEALER_LOC_PARAM
    - Geography - GM_FOR
    - Region Master - GM_REGN
    - Application List Values - AM_LIST
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (User - report criteria selection)
    - Session and Internal Parameters (System - set at startup and during processing)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - EXCEL_REPORT
    - VIEW_EXCEL_REP
    - POP_LIST_REGION
    - PR_PASS_PARAM
    - PR_REMOVE_ASCII_CHR
    - POPULATE_ERRORS
    - L_POPULATE
    - LIST_POPULATE_ZONE
    - L_POP_LIST_ITEM
    - VALIDATE_CN_MAIN
    - CHECK_BEFORE_DELETE
    - GENERAL (package)
    - DBMS_APPLICATION_INFO (package)
    - WEB (package)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - webutil.pld (`WEBUTIL_C_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - EXCEL_REPORT
    - SP-002 - POP_LIST_REGION
    - SP-003 - PR_PASS_PARAM
    - SP-004 - PR_REMOVE_ASCII_CHR
    - SP-005 - VIEW_EXCEL_REP
    - SP-006 - GENERAL.ASK_CONFIRM
    - SP-007 - GENERAL.DISP_TEXT
    - SP-008 - GENERAL.RAISE_ERROR
    - SP-009 - WEBUTIL.ERRORALERT
    - SP-010 - WEBUTIL.FCLOSE
    - SP-011 - WEBUTIL.FOPEN
    - SP-012 - WEBUTIL.GETIMPLCLASS
    - SP-013 - WEBUTIL.GETPROPERTY
    - SP-014 - WEBUTIL.GET_LINE
    - SP-015 - WEBUTIL.ID_NULL
    - SP-016 - WEBUTIL.PUT_LINE
    - SP-017 - WEBUTIL.SETPROPERTY

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_PENETRATE - Business Requirements Document |
| Form Module Name | VR_PENETRATE |
| Document Version | 1.0 |
| Date Created | October 19, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 19, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_penetrate Extended Warranty Incentive Details form, its purpose, and roles referenced in the module.*

The **vr_penetrate** Oracle Forms module is the **Extended Warranty Incentive Details** reporting screen used within the dealer management system. A service user opens **vr_penetrate**, selects the reporting region, quarter, and financial year, and optionally narrows the results to a specific city or dealer. The user then chooses how the report should be delivered - either as a PDF document through the reports server or as a CSV file for Excel analysis. Before the report is generated, the form checks that all mandatory parameters have been provided and that the region, quarter, and financial year are not left blank. Once the selections are confirmed, the report is produced and opened in the browser. Users authorised as multi-location personnel can filter across multiple regions; dealer-level users are restricted to their assigned region. The report displays extended warranty incentive penetration figures, slab-wise incentive values, and totals by dealer and city for the chosen period.

### Key Stakeholders

*Who uses vr_penetrate*

| Stakeholder | Role |
| :--- | :--- |
| **Service User** | Primary interactive user who selects report parameters (region, quarter, financial year, city, dealer) and initiates report generation or Excel export |
| **Dealer** | Dealer entity whose extended warranty incentive data is reported; dealer users access only their own region's results |
| **Multi-location User** | Multi-location (MUL) personnel who can filter across multiple regions and have access to all-dealer and head-office or regional-office views |

---

---

## 3. System Context

*Describes the vr_penetrate module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_penetrate** module is the **Extended Warranty Incentive Details** reporting screen within the Dealer Management System (DMS). It enables service users to generate incentive penetration reports for dealers by region and financial quarter. The form collects all required report parameters - region, quarter, financial year, and optional city and dealer filters - validates them, and then either submits the job to the reports server (PDF or other formats) or generates a CSV file directly for Excel review.

**System purpose:** Collect extended warranty incentive report parameters from the user, validate mandatory inputs, and generate or export the Extended Warranty Incentive Details report for the selected region, quarter, and financial period - as implemented in the vr_penetrate Oracle Forms module.

**In scope:**

- Loading the region list automatically at form startup based on the logged-in user's access rights
- Selecting a service region, quarter (Q1-Q4), and financial year as mandatory report filters
- Optionally filtering the report by city and by individual dealer within the selected region
- Selecting the report output destination (on-screen cache, printer, file, or email) and format (PDF or character)
- Selecting the report type (where applicable)
- Validating that region, quarter, and financial year are all provided before generating the report
- Validating that the from-date field is populated when date-range filtering is active
- Building the report parameter string from current screen selections and report parameter definitions
- Generating the report via the reports server (PDF or format output to file)
- Alternatively exporting the report data as a CSV file directly from the form using the EXCEL_REPORT procedure
- Viewing the generated report or CSV file in the browser
- Clearing the form to initiate a new parameter selection

**Process Name:** Extended Warranty Incentive Details Reporting

**Process Owner:** Service Manager

**Process Objective:** Open the Extended Warranty Incentive Details screen, select mandatory period and geography parameters, optionally refine by dealer or city, choose output format, validate all inputs, and generate or export the incentive report for the selected quarter and region.

**Process Trigger:** A service user or manager requires extended warranty incentive penetration data for a specific region and financial quarter

**Process Flow:**

The complete extended warranty incentive details reporting process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-015 in Section 4.

```
STEP 1 ── SCREEN OPENS (BR-001)
         The Extended Warranty Incentive Details screen opens in full-screen mode.
         The form initialises session details, sets the report description and name,
         and looks up the report server for the current application and principal.

STEP 2 ── REGION LIST POPULATED (BR-002)
         The region selection list is populated automatically from the accessible
         service regions for the logged-in user based on their assigned access rights.

STEP 3 ── COPYRIGHT DECLARATION LOADED (BR-003)
         The copyright declaration text is fetched from the database and displayed
         at the bottom of the screen for compliance purposes.

STEP 4 ── SELECT REGION (BR-004)
         The user selects a service region from the list.
         Selecting a new region clears all dependent fields (city, dealer,
         quarter, from/to dates) so parameters remain consistent.

STEP 5 ── VALIDATE REGION (BR-005)
         The form confirms that a region code has been selected.
         If the region is left blank, an error message is shown and the user
         must select a valid region before proceeding.

STEP 6 ── SELECT QUARTER (BR-006)
         The user selects a financial quarter (Q1, Q2, Q3, or Q4).
         The quarter selection clears the financial year and date fields to
         prevent stale values carrying forward from a previous selection.

STEP 7 ── VALIDATE QUARTER (BR-007)
         The form confirms that a quarter has been selected.
         If blank, an error message prompts the user to choose a quarter.

STEP 8 ── SELECT FINANCIAL YEAR (BR-008)
         The user selects a financial year from the available open years.
         A quarter-year period code is computed from the selected quarter and year
         and stored for use as the report transaction month parameter.

STEP 9 ── VALIDATE FINANCIAL YEAR (BR-009)
         The form confirms that a financial year has been selected.
         If blank, an error message prompts the user to choose a financial year.
         The quarter-year code is also finalised at this point.

STEP 10 ── SELECT CITY (BR-010) - optional
          The user may optionally select a city within the chosen region from a list
          of available cities for that region.

STEP 11 ── SELECT DEALER (BR-011) - optional
          The user may optionally select a specific dealer within the region and city
          from the dealer list; choosing a dealer populates dealer, location, and parent
          group parameters used in the report.

STEP 12 ── SELECT OUTPUT DESTINATION (BR-012)
          The user selects the report output destination (cache for on-screen viewing,
          printer, file, or email) and the desired format (PDF or character).
          Selecting printer automatically sets the format to character and disables
          manual format selection; other destinations allow PDF or custom format.

STEP 13 ── SELECT REPORT TYPE (BR-013) - when applicable
          The user selects the report sub-type where the report supports multiple
          output variants; the type is passed as a parameter to the report engine.

STEP 14 ── VALIDATE FROM DATE (BR-014) - when date range is used
          If a from-date is required, the form confirms it is not empty.
          An alert is shown if the from-date is missing before the report can proceed.

STEP 15 ── SUBMIT REPORT (BR-015)
          The user clicks Submit.
          The form performs a final check that region, quarter, and financial year
          are all provided, then either:
          ├── EXCEL: Builds a CSV query against the incentive data view, writes
                     the results to a server file with incentive slab headers,
                     and opens the CSV file in the browser.
          └── OTHER FORMATS: Builds the full report parameter string from the
                     screen selections and report parameter definitions, sets report
                     server and output properties, runs the report object, and
                     opens the generated file in the browser.
```

**Major process interactions:**

- **Region access control** - determines which service regions the logged-in user can select based on their assigned user-region mapping
- **Financial year master** - provides available open financial years for the current dealer, location, and company for the financial year selector
- **City/FOR master** - supplies the list of cities (FOR codes) available within the selected region for the city filter
- **Dealer location master** - provides the list of DMS-enabled dealers within the selected region for the dealer filter
- **Report parameter definitions** - provides the ordered list of expected report parameters and their mappings from the reporting configuration table
- **Report server configuration** - looks up the target report server name for the current application and principal at startup
- **Reports server** - receives the built parameter string and report job, generates PDF or other format output, and stores the file for browser retrieval
- **Extended warranty incentive data view** - the data source queried directly when generating CSV/Excel output, containing dealer-level penetration figures and incentive slab values

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Startup - Session Registration and Screen Initialisation

**Business Description:**
When the Extended Warranty Incentive Details reporting screen opens, the system registers the current session for activity tracking, then initialises the screen with a fixed report title, the current financial year, and the list of regions the logged-in user is permitted to access. The copyright declaration is retrieved and displayed, the application is identified for the reporting engine, and the report server address is resolved from the system configuration. The screen's windows are maximised and the user is ready to select filter criteria.

**Actors:** Service User

**Preconditions:**
- The user has an active application session with valid session context (user identity, principal company, financial period, and dealer information available from the session).
- The application is being opened for the first time in this session or after a fresh launch.

**Main Flow:**

**Step 1 - Session activity tracking registered**
Before the screen opens, the application registers the current session with the database activity-information facility, identifying the running module as "vr_penetrate". If the application-level activity logging is switched on for this session, a performance timer is started.

**Step 2 - Report title and financial year displayed**
The screen title is fixed to "Extended Warranty Incentive Details" from the session globals. The current financial year is derived from the session's financial period start and end dates and displayed as a start-year to end-year range (e.g. "2023-2024").

**Step 3 - Application identity and report engine configuration set**
The report name, application identifier, and the application identifier parameter are set to "vr_penetrate". The "All" option availability for the City and Dealer lookup lists is configured based on the application identifier. The report server address is looked up from the system report configuration for this application and the current principal company; if no configuration record is found, or if multiple records exist, or if any other error occurs, the session-level global report server address is used as the fallback.

**Step 4 - Windows maximised**
Both the main application window and the form's primary window are set to maximised state so the reporting screen fills the screen.

**Step 5 - Report description displayed on screen**
The session-stored report description label ("Extended Warranty Incentive Details") is shown on the screen, and the internal report-name field is set to match the application.

**Step 6 - Region drop-down populated**
The Region selection list is populated from the database with all regions that the logged-in user is authorised to access, filtered to service-type user records for the current principal company.

*Procedures called:*
- **POP_LIST_REGION** ([SP-002](#sp-002)) - POP_LIST_REGION - Populates the `P_REGION_CD` list item on the form by refreshing the `RG_REGION` record group from the database, making the region filter drop-down ready for user selection when the form opens.
    * **Step 1** - Refresh the Region record group from the database by executing the configured region query, which returns all regions the current user is authorised to access for service-type activity.
    * **Step 2** - Synchronise the Region drop-down list on screen with the freshly retrieved record group, so the user sees only their permitted regions.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report server configuration lookup | EH_REPORTS query in WHEN-NEW-FORM-INSTANCE | When the screen opens | Determines the correct report server address for this application and principal; falls back to the session default if not configured. | On NO_DATA_FOUND, TOO_MANY_ROWS, or any other error, the session-level global report server address is used silently; no error is shown to the user. |

**Step 7 - Copyright declaration displayed**
The copyright declaration text is retrieved from the database and displayed on the screen.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - `GLOBAL.REPORT_DESC = 'Extended Warranty Incentive Details'` - the report description is set to a fixed label at startup; this governs what the screen title shows throughout the session.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display Item | 200 | N/A | "Extended Warranty Incentive Details" | Session globals available | Read-only; set from session global at startup | N/A |
| Financial Year (`FINANCIAL_YEAR`) | Auto-populated | List Item | N/A | Financial Year LOV (`FINANCIAL_YEAR`) | Year range string (e.g. "2023-2024") | Session financial period dates available | Derived from session global financial period start and end years | N/A |
| Report Name (`REPORT_NAME`) | Auto-populated | Unknown | 2000 | N/A | "vr_penetrate" | N/A | System-set; not user-editable | N/A |
| Report Server (`REP_SERVER`) | Auto-populated | Unknown | N/A | EH_REPORTS | Resolved server address | Application identifier set | Looked up from system configuration; falls back to session global on any exception | N/A |
| Region (`P_REGION_CD`) | Mandatory | List Item | N/A | Region record group (`RG_REGION` / `AM_USER_REGION`) | Region codes permitted for the user | User session active | Only regions the user is authorised to access are shown | N/A - list is populated; empty selection blocked at submission |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Display Item | 100 | N/A | Text from `SF_COPYRIGHT_DECLARATION` | Database accessible | Read-only display | N/A |

---

#### Requirement ID: BR-002

**Requirement Title:** Form-Level Error Handling and User-Friendly Error Messages

**Business Description:**
When any error occurs anywhere in the form - whether from a user entry mistake (such as typing a non-numeric value in a number field or an invalid date), a data conflict (such as another user modifying the same record), or an unexpected database error - the form intercepts the error and presents a clear, human-readable message to the user instead of a raw system error code. Specific common errors are translated into plain business-language explanations; all other database errors display the database's own error text. After the message is shown, the failing operation is cancelled so the user can correct their input without the form closing.

**Actors:** Service User

**Preconditions:**
- The form is open and an operation that raises a form or database error has been attempted.

**Main Flow:**

**Step 1 - Error intercepted and translated**
When the form or database raises an error, the system captures the error number, text, and database-level error details. It then checks the error code against a set of known error categories and responds accordingly:

- If the error indicates an invalid date entry (error code 50004), the message *"Entered Date is not valid Date"* is shown and the operation is cancelled (the form stays open).
- If the error indicates an incorrectly formatted date (error codes 50025 or 50026), the message *"Enter the Date in the proper format (DD-MM-YYYY)"* is shown and the operation is cancelled.
- If the error indicates that non-numeric characters were entered in a numeric field (error codes 40209 or 50016), the message *"Characters/Special Characters are not allowed here, enter the numeric value"* is shown and the operation is cancelled.
- If the error code is 40207, the form's own error text (not a fixed literal) is shown and the operation is cancelled.
- If the database-level error code indicates a referential integrity constraint violation (database error code -02292), the system routes to the configured error-message handler for that constraint violation code.
- If the error indicates a record was modified by another user (error codes 40654, 40655, 40656, 40657, or 40659), the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is shown, any uncommitted changes are rolled back, and the operation is cancelled.
- For any remaining database errors (where the SQL error code is non-zero), the database's own error message text is shown, any uncommitted changes are rolled back, and the operation is cancelled.
- Errors with codes 40401 or 40405 are silently ignored (no message shown, no cancellation).

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine whether to display an error alert (`AL_ERRINFO`) or a note alert (`AL_NOTE`) based on the provided title.
    * **Step 2** - Set the selected alert's title to the provided title string.
    * **Step 3** - Set the selected alert's message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.
- **GENERAL.RAISE_ERROR** ([SP-008](#sp-008)) - GENERAL.RAISE_ERROR - Receives a message code, composes a display message by appending any retrieved message text, and routes the message to the appropriate user-facing dialog with a severity-specific title (`Error`, `Note`, or `Caution`) via `GENERAL.DISP_TEXT`; for error-severity messages the procedure additionally raises `FORM_TRIGGER_FAILURE` to halt the current form operation.
    * **Step 1** - Compose the display message by combining the error code with the message text (note: the message-text lookup call is commented out at runtime, so the message text portion is blank at execution time).
    * **Step 2** - Evaluate the error type to determine severity.
    * **Step 3** - If the error is classified as an Error type, display the message with an "Error" title and cancel the current form operation.
    * **Step 4** - If the error is classified as a Note type, display the message with a "Note" title and allow processing to continue.
    * **Step 5** - If the error is classified as a Caution type, display the message with a "Caution" title and allow processing to continue.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date entry | ON-ERROR (error code 50004) - GENERAL.DISP_TEXT [SP-007] | When a date field contains a value that is not a valid date | Prevents invalid dates from being accepted and explains the problem to the user | *"Entered Date is not valid Date"* is shown; operation cancelled; user remains on the field |
| Incorrectly formatted date | ON-ERROR (error codes 50025, 50026) - GENERAL.DISP_TEXT [SP-007] | When a date field value is not in the required format | Guides the user to enter dates in the correct format (DD-MM-YYYY) | *"Enter the Date in the proper format (DD-MM-YYYY)"* is shown; operation cancelled |
| Non-numeric value in numeric field | ON-ERROR (error codes 40209, 50016) - GENERAL.DISP_TEXT [SP-007] | When a numeric field receives alphabetic or special characters | Prevents invalid characters in numeric fields | *"Characters/Special Characters are not allowed here, enter the numeric value"* is shown; operation cancelled |
| Concurrent update conflict | ON-ERROR (error codes 40654-40657, 40659) - GENERAL.DISP_TEXT [SP-007] | When a save attempt detects another user modified the same record | Prevents data loss from concurrent edits; instructs the user to re-query | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is shown; changes rolled back; operation cancelled |
| Referential integrity constraint violation | ON-ERROR (database error -02292) - GENERAL.RAISE_ERROR [SP-008] | When a save or delete is blocked by a child-record dependency | Provides a business-meaningful explanation of why the operation was refused | Configured error message displayed (note: message text lookup is currently inactive at runtime, so the message text may be blank); operation cancelled |
| General database error | ON-ERROR (any non-zero SQL error code not covered above) - GENERAL.DISP_TEXT [SP-007] | When an unclassified database error occurs | Ensures the user sees the database's own error description rather than a silent failure | The database's own error message text is shown; changes rolled back; operation cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Invalid date value entered - *"Entered Date is not valid Date"*; the operation is cancelled and the user stays on the screen.
- **BR-002-ES-02** - Date not in required format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; the operation is cancelled.
- **BR-002-ES-03** - Non-numeric characters in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; the operation is cancelled.
- **BR-002-ES-04** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; changes rolled back; the operation is cancelled.
- **BR-002-ES-05** - Unclassified database error - the database's own error message text is shown; changes rolled back; the operation is cancelled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROM_DT`) | Conditional | Text Item | 10 / DD-MM-RRRR | N/A | N/A | N/A | Must be a valid date in DD-MM-YYYY format | *"Entered Date is not valid Date"* / *"Enter the Date in the proper format (DD-MM-YYYY)"* |

---

#### Requirement ID: BR-003

**Requirement Title:** Suppression of Non-Essential System Messages

**Business Description:**
The form suppresses certain internal system status messages that Oracle Forms would otherwise display to the user. Specifically, messages that indicate no records are available for query (message codes 40209 and 40207) are intercepted; if they would normally appear, they are instead displayed as errors and the operation is cancelled to prevent the user from seeing confusing technical platform messages. This ensures that only business-relevant messages reach the user.

**Actors:** Service User

**Preconditions:**
- The form is open and a system-generated informational message with code 40209 or 40207 has been raised by Oracle Forms.

**Main Flow:**

**Step 1 - System message intercepted and re-routed**
When Oracle Forms raises a message with code 40209 or 40207, the system captures the message number, text, and type. Rather than displaying it as a standard platform informational message, it is shown as an error alert using the error-display routine, and the current form operation is cancelled. All other system messages not matching those two codes pass through without interception.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine whether to use the error alert (`AL_ERRINFO`) or the note alert (`AL_NOTE`) based on the title provided.
    * **Step 2** - Set the alert's title to the provided title string.
    * **Step 3** - Set the alert's message body to the provided message text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| System message codes 40209, 40207 intercepted | ON-MESSAGE (error codes 40209, 40207) - GENERAL.DISP_TEXT [SP-007] | When Oracle Forms raises a system message with code 40209 or 40207 | Prevents confusing technical platform messages from reaching the user by re-routing them as error alerts | The system message text is shown as an error and the form operation is cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - System message code 40209 or 40207 raised - the system message text is displayed as an error; the current form operation is cancelled.

---

#### Requirement ID: BR-004

**Requirement Title:** Region Selection - Validation and Dependent Field Reset

**Business Description:**
When the user selects a region from the Region drop-down on the report criteria screen, all dependent filter fields - City, Dealer, Quarter, From Date, and To Date - are automatically cleared so they can be re-entered for the newly chosen region. The system also validates that the Region field is not left empty when the user moves off it; if it is empty, an error is shown and the user must select a valid region before proceeding. When the region is confirmed non-empty, the city for-code description field is also cleared.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the Region drop-down has been populated at startup.

**Main Flow:**

**Step 1 - Region changed: dependent fields cleared**
When the user changes the Region selection, the City description, Dealer description, Dealer code, Quarter, From Date, To Date, and City code are all cleared from the screen. This ensures the user must re-select values that are valid for the newly chosen region.

*Screen: `CN_MAIN`.*

**Step 2 - Region validated as non-empty**
When the user moves off the Region drop-down (triggering its item-level validation), the system confirms the region is not blank. If the region is blank, an error is shown and the user is prevented from moving to another field. If the region is not blank, the city for-code description field is cleared.

*Screen: `CN_MAIN`.*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title to the provided title string.
    * **Step 3** - Set the alert message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region must not be empty | WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD - GENERAL.DISP_TEXT [SP-007] | When the user moves off the Region drop-down | Ensures a region is always selected before other criteria can be entered or the report submitted | *"Region Code can not be empty"* is shown; the current operation is cancelled and focus stays on the Region field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Region field left blank when exited - *"Region Code can not be empty"*; the user must select a region before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region (`P_REGION_CD`) | Mandatory | List Item | N/A | Region record group (`RG_REGION`) | Region codes permitted for the user | Region list populated at startup | Must not be blank when the field is exited | *"Region Code can not be empty"* |
| City (`P_CITY_DESC`) | Auto-cleared | Text Item | 500 | City lookup (`LV_CITY`) | City description | N/A | Cleared automatically when region changes | N/A |
| City code (`P_CITY`) | Auto-cleared | Text Item | 20 | City lookup (`LV_CITY`) | City code | N/A | Cleared automatically when region changes | N/A |
| Dealer (`P_DEALER_DESC`) | Auto-cleared | Text Item | 500 | Dealer lookup (`LV_DEALER`) | Dealer name | N/A | Cleared automatically when region changes | N/A |
| Dealer code (`P_DEALER`) | Auto-cleared | Unknown | 5 / Number | Dealer lookup (`LV_DEALER`) | Dealer map code | N/A | Cleared automatically when region changes | N/A |
| Quarter (`QUARTER`) | Auto-cleared | List Item | N/A | N/A | N/A | N/A | Cleared automatically when region changes | N/A |
| From Date (`P_FROM_DT`) | Auto-cleared | Text Item | 10 / DD-MM-RRRR | N/A | N/A | N/A | Cleared automatically when region changes | N/A |
| To Date (`P_TO_DT`) | Auto-cleared | Text Item | 10 / Date | N/A | N/A | N/A | Cleared automatically when region changes | N/A |

---


#### Requirement ID: BR-005

**Requirement Title:** Quarter Selection - Dependent Field Reset and Quarter Navigation Validation

**Business Description:**
When the user selects a fiscal quarter on the report criteria screen, the Financial Year, From Date, and To Date fields are automatically cleared so the user must re-select values that match the new quarter. The system also maps the chosen quarter to its corresponding internal reporting month value (Q1 maps to June, Q2 to September, Q3 to December, Q4 to March) and moves focus to the Financial Year field. When the user tabs off the Quarter field using the keyboard, the system validates that a quarter has been selected; if not, an error is shown and focus returns to the Quarter field.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and a region has been selected.

**Main Flow:**

**Step 1 - Quarter changed: dependent fields cleared and internal period derived**
When the user changes the Quarter selection, the Financial Year, From Date, and To Date are cleared. The system then maps the selected quarter to its corresponding two-digit month code (Q1 -> June, Q2 -> September, Q3 -> December, Q4 -> March) and stores it internally. Focus moves to the Financial Year field.

*Screen: `CN_MAIN`.*

**Step 2 - Quarter validated as non-empty on keyboard navigation**
When the user presses the navigation key to leave the Quarter field, the system checks that a quarter value has been selected. If the Quarter is blank, the error message *"Quarter can not be Blank)"* is shown, focus is returned to the Quarter field, and the navigation is cancelled. If a quarter is selected, navigation proceeds normally.

*Screen: `CN_MAIN`.*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title to the provided title string.
    * **Step 3** - Set the alert message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quarter must not be empty on navigation | KEY-NEXT-ITEM on CB_BLK.QUARTER - GENERAL.DISP_TEXT [SP-007] | When the user presses the navigation key to leave the Quarter field | Prevents the user from proceeding to the Financial Year without first selecting a quarter | *"Quarter can not be Blank)"* is shown; focus returns to the Quarter field; navigation is cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Quarter field is blank when the user tries to navigate away - *"Quarter can not be Blank)"*; focus returns to the Quarter field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quarter (`QUARTER`) | Mandatory | List Item | N/A | N/A | Q1, Q2, Q3, Q4 | Region selected | Must not be blank when navigating past the field | *"Quarter can not be Blank)"* |
| Financial Year (`FINANCIAL_YEAR`) | Auto-cleared | Unknown | N/A | Financial Year LOV (`FINANCIAL_YEAR` / `FM_COMPANY`) | Year range string | N/A | Cleared when quarter changes | N/A |
| From Date (`P_FROM_DT`) | Auto-cleared | Text Item | 10 / DD-MM-RRRR | N/A | N/A | N/A | Cleared when quarter changes | N/A |
| To Date (`P_TO_DT`) | Auto-cleared | Text Item | 10 / Date | N/A | N/A | N/A | Cleared when quarter changes | N/A |

---


#### Requirement ID: BR-006

**Requirement Title:** Financial Year Validation and Quarter-Year Period Computation

**Business Description:**
When the user confirms the Financial Year selection and moves to the next field, the system validates that a financial year has been entered. If it is missing, an error is shown and the user must provide a value. When the financial year is provided, the system computes the complete reporting period identifier - a combined quarter-year key - by combining the financial year with the quarter-month code established in the previous step. For the fourth quarter (Q4), the year used for the computation is advanced by one to reflect that Q4 crosses the financial year boundary. This period identifier is used when the report is submitted to the reporting engine. Focus is then moved to the Destination field.

**Actors:** Service User

**Preconditions:**
- A quarter has been selected and its internal quarter-month code has been set.
- The Financial Year field is accessible.

**Main Flow:**

**Step 1 - Financial Year validated as non-empty**
When the user navigates away from the Financial Year field, the system checks that a financial year has been selected. If the field is empty, the message *"Financial Year can not be Blank)"* is shown, focus is returned to the Financial Year field, and the navigation is cancelled.

*Screen: `CN_MAIN`.*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title to the provided title string.
    * **Step 3** - Set the alert message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Financial Year must not be empty | KEY-NEXT-ITEM on CB_BLK.FINANCIAL_YEAR - GENERAL.DISP_TEXT [SP-007] | When the user presses the navigation key to leave the Financial Year field | Ensures a financial year is always selected before the report period can be computed or the report submitted | *"Financial Year can not be Blank)"* is shown; focus returns to the Financial Year field; navigation is cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - Financial Year is blank when the user tries to navigate away - *"Financial Year can not be Blank)"*; focus returns to the Financial Year field.

**Step 2 - Quarter-year period key computed and focus moved**
With a valid financial year confirmed, the system constructs the internal reporting period key by combining the financial year value with the quarter-month code. For Q4, the year component used is the financial year plus one (since Q4 spans into the following calendar year). The combined key is stored internally and used when the report is submitted. Focus advances to the Destination field.

*Screen: `CN_MAIN`.*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Financial Year (`FINANCIAL_YEAR`) | Mandatory | Unknown | N/A | Financial Year LOV (`FINANCIAL_YEAR` / `FM_COMPANY`) | Four-digit year string (e.g. "2023") | Quarter selected | Must not be blank when field is exited | *"Financial Year can not be Blank)"* |
| Quarter-Year Key (`P_QTR_YEAR`) | Auto-populated | Unknown | N/A | N/A | Combined year-month code derived from financial year and quarter | Financial Year and Quarter both selected | Computed automatically from financial year and quarter-month code; for Q4, year is advanced by one | N/A |

---


#### Requirement ID: BR-007

**Requirement Title:** From Date Mandatory Validation

**Business Description:**
When the user exits the From Date field, the system checks that a value has been entered. If the From Date is blank, an alert is shown with the message "From Date cannot be empty" and the user cannot proceed until a date is provided. A prior version of this form also prevented future dates from being entered, but that restriction was removed and is no longer enforced.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user has navigated to the From Date field.

**Main Flow:**

**Step 1 - From Date validated as non-empty**
When the user moves off the From Date field, the system checks whether a date value has been entered. If the field is blank, an alert is displayed with the message *"From Date cannot be empty"* and the current navigation is cancelled. If a date is present, navigation continues normally.

*(No screen line - P_FROM_DT is not on the CN_MAIN canvas per the slice.)*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be empty | WHEN-VALIDATE-ITEM on CB_BLK.P_FROM_DT - direct alert (AL_ERRINFO via SET_ALERT_PROPERTY / SHOW_ALERT) | When the user moves off the From Date field | Ensures the reporting period start date is always provided before the report can be submitted | Alert *"From Date cannot be empty"* is shown; navigation is cancelled and the user must enter a date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - From Date is blank when the field is exited - alert *"From Date cannot be empty"* is shown; navigation is cancelled.

**Alternative Flows:**
- **BR-007-AF-01** - (from Step 1) Previously, if the From Date was later than today's date, the same alert would be displayed with the message "From Date cannot be greater than Current Date". This check is now commented out and does not execute. (COMMENTED OUT / INACTIVE - does not execute.)

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROM_DT`) | Mandatory | Text Item | 10 / DD-MM-RRRR | N/A | N/A | N/A | Must not be blank when the field is exited | Alert *"From Date cannot be empty"* shown; navigation cancelled |

---


#### Requirement ID: BR-008

**Requirement Title:** Output Destination and Format Selection - Format Availability and File Name Control

**Business Description:**
When the user selects an output destination for the report, the output format field is automatically configured to match the destination: if Printer is selected, the format is fixed to character mode and the format selector is disabled so the user cannot change it; for any other destination, the format defaults to PDF and the selector is enabled. When the user changes the output format, the File Name field is enabled and made navigable only when the format is set to EXCEL; for all other formats the File Name is cleared and disabled. When the user enters the File Name field, its editability is controlled the same way - editable only for EXCEL format, read-only otherwise. Navigating past the Destination field moves focus directly to the Submit button.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user has reached the Destination and Format fields.

**Main Flow:**

**Step 1 - Destination selected: format options configured**
When the user changes the Destination selection (Printer, File, Cache, or Mail), the system checks whether "PRINTER" has been chosen. If so, the output format is set to "CHAR" and the format selector is disabled. For any other destination, the format is set to "PDF" and the format selector is enabled.

*Screen: `CN_MAIN`.*

**Step 2 - Output Format selected: File Name field availability set**
When the user changes the Output Format selection, the system checks whether "EXCEL" has been selected. If EXCEL is chosen, the File Name field is enabled and made navigable so the user can specify a target file name. For any other format, the File Name field is cleared and disabled.

*Screen: `CN_MAIN`.*

**Step 3 - File Name field entered: edit permissions set by format**
When the user moves into the File Name field, the system checks whether the current output format is EXCEL. If it is, the field allows both inserting and updating values. If the format is anything else, both insert and update are blocked - the field effectively becomes read-only.

*Screen: `CN_MAIN`.*

**Step 4 - Destination navigation: focus moves to Submit**
When the user presses the navigation key to leave the Destination field, focus moves directly to the Submit button, bypassing any intervening fields.

*Screen: `CN_MAIN`.*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Format locked for Printer destination | WHEN-LIST-CHANGED on CB_BLK.P_DESTYPE (and CB_BLK.P_REPO_TYPE, CB_BLK.P_DES_TYPE) - direct SET_ITEM_PROPERTY | When the user selects a Destination | Ensures the output format is appropriate for the chosen destination; Printer output requires character mode and cannot use PDF or EXCEL | Format is forced to "CHAR" and the selector is disabled; user cannot override format when Printer is selected |
| File Name field controlled by format | WHEN-LIST-CHANGED on CB_BLK.P_DESFORMAT - direct SET_ITEM_PROPERTY | When the user changes the Output Format | Prevents a file name from being entered when it is not applicable (non-EXCEL formats) | File Name is cleared and disabled for non-EXCEL formats; only enabled and navigable when EXCEL is selected |
| File Name editability by format | WHEN-NEW-ITEM-INSTANCE on CB_BLK.FILENAME - direct SET_ITEM_PROPERTY | When the user enters the File Name field | Enforces that the File Name is only editable for EXCEL-format reports | Field is non-editable (insert and update both blocked) for non-EXCEL formats |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Destination (`P_DESTYPE`) | No | List Item | N/A | N/A | PRINTER, FILE, CACHE, MAIL | N/A | Controls format availability; if PRINTER, format is fixed to CHAR | N/A |
| Report Type (`P_REPO_TYPE`) | No | List Item | N/A | N/A | N/A | N/A | Triggers same format-availability logic as Destination | N/A |
| Destination type flag (`P_DES_TYPE`) | No | Text Item | 1 | N/A | N/A | N/A | Triggers same format-availability logic; separate list item instance | N/A |
| Output Format (`P_DESFORMAT`) | No | List Item | N/A | N/A | PDF, CHAR, EXCEL | N/A | Controls File Name field availability; EXCEL enables File Name | N/A |
| File Name (`FILENAME`) | Conditional | Text Item | 4000 | N/A | N/A | N/A | Enabled and editable only when Output Format is EXCEL; cleared and disabled otherwise | N/A - no error message; field is simply locked |

---


#### Requirement ID: BR-009

**Requirement Title:** Report Submission - Criteria Validation and Report Generation

**Business Description:**
When the user clicks the Submit button, the system validates that the key filter criteria - Region, Quarter, and Financial Year - have all been provided. If any of them is missing, an error message is shown and the submission is blocked. Once all criteria are present, the system determines the output method: if the user has chosen Excel as the output format, an Excel-format report is built directly from the incentive data and delivered as a CSV file in the browser; for all other output destinations (PDF, printer, cache, or mail), the system assembles the report parameters, sets up the Oracle Reports engine with the appropriate destination and format settings, runs the report, and delivers the output to the user via the browser or the chosen delivery channel.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open.
- Region, Quarter, and Financial Year have been entered (the Submit button will validate and enforce these).

**Main Flow:**

**Step 1 - Internal reporting period key finalised before submission**
When the user clicks Submit, the system first recalculates the internal quarter-year identifier by combining the stored financial year value with the stored quarter-month code, ensuring the period key is current before the report parameters are assembled.

*Screen: `CN_MAIN`.*

**Step 2 - Mandatory criteria validated before report is run**
The system checks, in sequence, that Region, Quarter, and Financial Year are all provided. If the Region is blank, the message *"Region can not be Blank)"* is shown, focus returns to the Region field, and submission stops. If the Quarter is blank, *"Quarter can not be Blank)"* is shown and focus returns to the Quarter field. If the Financial Year is blank, *"Financial Year can not be Blank)"* is shown and focus returns to the Financial Year field.

*Screen: `CN_MAIN`.*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title to the provided title string.
    * **Step 3** - Set the alert message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007] | When the user clicks Submit | Ensures the report always has a region filter before it is generated | *"Region can not be Blank)"* shown; focus returns to the Region field; submission cancelled |
| Quarter must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007] | When the user clicks Submit | Ensures the reporting quarter is always specified | *"Quarter can not be Blank)"* shown; focus returns to the Quarter field; submission cancelled |
| Financial Year must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007] | When the user clicks Submit | Ensures the financial year is always specified so the correct period is reported | *"Financial Year can not be Blank)"* shown; focus returns to the Financial Year field; submission cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Region is blank at submission - *"Region can not be Blank)"*; focus returns to the Region field.
- **BR-009-ES-02** - Quarter is blank at submission - *"Quarter can not be Blank)"*; focus returns to the Quarter field.
- **BR-009-ES-03** - Financial Year is blank at submission - *"Financial Year can not be Blank)"*; focus returns to the Financial Year field.

**Step 3 - Excel report generated and delivered when Excel output is chosen**
If the user has selected Excel as the output destination, the system builds and delivers an Excel-format CSV report directly from the Extended Warranty incentive data. The report includes a header row, a slab-heading row using the incentive slab labels for the current principal company, and one data row per dealer showing retail counts, EW Gold and Platinum sales, total EW sales, penetration percentages, and incentive slab amounts. The report is filtered by the selected region, dealer, and city criteria. The CSV file is written to the server and opened in a new browser window.

*Screen: `CN_MAIN`.*

*Procedures called:*
- **EXCEL_REPORT** ([SP-001](#sp-001)) - EXCEL_REPORT - Builds a filtered CSV data extract of EW (Extended Warranty) incentive detail records for the current principal, assembles a multi-section query covering header rows, slab headings, and data rows, and then delegates file creation and browser display to VIEW_EXCEL_REP.
    * **Step 1** - Construct a time-stamped CSV filename using the current user ID and the current date and time.
    * **Step 2** - Build the first sub-query: a static header row defining the column labels for the CSV output.
    * **Step 3** - Build the second sub-query: a dynamic slab-heading row assembled using the incentive slab labels (A through E) for the current principal company.
    * **Step 4** - Build the third sub-query: numbered data rows from the Extended Warranty incentive detail source, filtered by the selected region, dealer, and city, and by the reporting period month.
    * **Step 5** - Combine all three sub-queries into a single report query.
    * **Step 6** - Assign the assembled query for diagnostic reference on the screen.
    * **Step 7** - Call the Excel report generation utility, passing the filename, query, and column alias, to write the CSV file and open it in the browser.
    * **Step 8** - If any unhandled error occurs, suppress it silently.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is not null (within EXCEL_REPORT path via PR_PASS_PARAM) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - PR_PASS_PARAM [SP-003] within EXCEL_REPORT [SP-001] | When the user clicks Submit with Excel output selected | Ensures a From Date is always provided so the incentive report covers a valid period | Alert "Please Enter From Date" shown; focus returns to the From Date field; submission cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-IC-01** - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* - shown when the generated filename contains spaces in the path; the file is redirected to the C:\ root drive and the report continues.
- **BR-009-IC-02** - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* - shown when the incentive data exceeds 65,535 rows; the output is capped at that limit.

**Step 4 - Oracle Reports-based report generated for non-Excel output destinations**
If the output destination is not Excel, the system assembles the report parameter string from the current filter criteria, locates the report definition object, configures the report engine with the chosen destination type (Cache, Printer, File, or Mail), output format (PDF for non-Excel), and server address. The report is run and the output is delivered: for file-based output, the resulting PDF file is opened in a new browser window; the Excel sub-path within the report object is not reachable from this branch (it is a dead code path).

*Screen: `CN_MAIN`.*

*Procedures called:*
- **PR_PASS_PARAM** ([SP-003](#sp-003)) - PR_PASS_PARAM - Builds a URL-style parameter string for the `vr_tat_bshop_det` report by iterating over the report's registered parameters in ED_REPORTS, appending each current form item value in name=value format, and enforcing mandatory validation for the from-date parameter.
    * **Step 1** - Calculate a default date range for reference: three months prior to today through today.
    * **Step 2** - Open the configured report parameter definitions for the current application and principal, ordered by serial number.
    * **Step 3** - Process each defined parameter in turn.
    * **Step 4** - For the Region parameter: add the selected region code to the parameter string.
    * **Step 5** - For the City parameter: add the selected city code; if no city is selected, default to "ALL".
    * **Step 6** - For the Dealer parameter: add the selected dealer code; if no dealer is selected, default to a placeholder value representing all dealers.
    * **Step 7** - For the Parent Group parameter: add the parent group value; if no dealer is selected, default to "ALL".
    * **Step 8** - For the Location parameter: add the location code; if no dealer is selected, default to "ALL".
    * **Step 9** - For the From Date parameter: if no From Date has been entered, display an alert "Please Enter From Date", return focus to the From Date field, and stop processing. Otherwise add the From Date to the parameter string.
    * **Step 10** - For the To Date parameter: add the To Date value to the parameter string.
    * **Step 11** - For the Report Type parameter: add the report type code to the parameter string.
    * **Step 12** - For the Destination Type parameter: add the destination type code to the parameter string.
    * **Step 13** - Return the fully assembled parameter string to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be blank (report object path) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - PR_PASS_PARAM [SP-003] | When the user clicks Submit with a non-Excel destination | Ensures the From Date is always provided before the report parameters are assembled | Alert *"Please Enter From Date"* shown; focus returns to the From Date field; report run is cancelled |

**Business Scenarios - How report delivery differs by output destination**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Excel output** | The report is generated as a CSV file directly from the incentive data view and opened in the browser; the Oracle Reports engine is not used. |
| **PDF / file output** | Report parameters are assembled, the Oracle Reports engine is configured for PDF and file-based output, the report is run on the server, and the PDF is opened in a new browser window. |
| **Printer output** | Report parameters are assembled; the Oracle Reports engine is configured for character-mode printer output; the report is sent to the printer. |
| **Cache or Mail output** | Report parameters are assembled; the Oracle Reports engine is configured for the corresponding output type; the report is directed accordingly. |

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 1) The internal period key computation (combining financial year and quarter month) is always performed before validation; if either value is blank, the result is an empty string. Subsequent validation at Step 2 catches the blank financial year before the report runs.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region (`P_REGION_CD`) | Mandatory | List Item | N/A | Region record group (`RG_REGION`) | Region code | N/A | Must not be blank at submission | *"Region can not be Blank)"* |
| Quarter (`QUARTER`) | Mandatory | List Item | N/A | N/A | Q1-Q4 | Region selected | Must not be blank at submission | *"Quarter can not be Blank)"* |
| Financial Year (`FINANCIAL_YEAR`) | Mandatory | Unknown | N/A | Financial Year LOV (`FINANCIAL_YEAR` / `FM_COMPANY`) | Year string | Quarter selected | Must not be blank at submission | *"Financial Year can not be Blank)"* |
| City (`P_CITY_DESC` / `P_CITY`) | Optional | Text Item | 500 / 20 | City lookup (`LV_CITY`) | City code and name | Region selected | Optional; defaults to all cities if blank | N/A |
| Dealer (`P_DEALER_DESC` / `P_DEALER`) | Optional | Text Item | 500 / 5 | Dealer lookup (`LV_DEALER`) | Dealer map code and name | Region selected | Optional; defaults to all dealers if blank | N/A |
| From Date (`P_FROM_DT`) | Conditional | Text Item | 10 / DD-MM-RRRR | N/A | N/A | N/A | Required by parameter assembly if configured; alert displayed if missing | *"Please Enter From Date"* |
| To Date (`P_TO_DT`) | Optional | Text Item | 10 / Date | N/A | N/A | N/A | Included in parameters if provided | N/A |
| Destination (`P_DESTYPE`) | No | List Item | N/A | N/A | EXCEL, FILE, PRINTER, CACHE, MAIL | N/A | Determines report generation path | N/A |
| File Name (`FILENAME`) | Auto-populated | Text Item | 4000 | N/A | Assembled parameter string (non-Excel path) or system-generated CSV name (Excel path) | Report submitted | Set internally by the report generation logic | N/A |

---


#### Requirement ID: BR-010

**Requirement Title:** Form Clear - Reset Screen to Initial State

**Business Description:**
When the user triggers a form clear action, all entered filter criteria are cleared from the screen without any validation of the current values. The report title is then restored from the session to ensure the description label remains correct after clearing. The copyright declaration is re-read from the database and displayed again. The form returns to a clean state ready for new criteria to be entered.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user has initiated a form clear action.

**Main Flow:**

**Step 1 - All filter criteria cleared without validation**
The system clears all fields on the form immediately, discarding any criteria the user had entered, without prompting for confirmation or validating the current state.

**Step 2 - Report title restored from session**
After clearing, the report description label ("Extended Warranty Incentive Details") is restored from the session so the screen title remains correct.

**Step 3 - Copyright declaration refreshed**
The copyright declaration text is re-read from the database and displayed on the screen to ensure it is current.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display Item | 200 | N/A | "Extended Warranty Incentive Details" (restored from session) | N/A | Read-only; restored from session on form clear | N/A |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Display Item | 100 | N/A | Text from `SF_COPYRIGHT_DECLARATION` | Database accessible | Read-only; re-read from database on form clear | N/A |

---


#### Requirement ID: BR-011

**Requirement Title:** Form Exit - Session Deregistration and Application Close

**Business Description:**
When the user exits the application, the session is deregistered from the database activity tracker by clearing the module and client information that was recorded at startup. The form then closes without validating or saving any unsaved data.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user has initiated an exit action (via the keyboard exit key or the Exit button).

**Main Flow:**

**Step 1 - Session activity information cleared**
The session's activity tracking information - the client identifier and module name - are cleared from the database session register, signalling that this form is no longer active.

**Step 2 - Form closed without validation**
The form closes immediately, discarding any unsaved changes, without prompting for confirmation.

---


#### Requirement ID: BR-012

**Requirement Title:** Toolbar Action Controls - Save, Cancel, Delete, Insert Restriction, and Print

**Business Description:**
The toolbar provides Save, Cancel, Delete, Insert, and Print buttons, each of which performs a controlled action depending on whether that button is currently enabled on the screen. Saving commits all changes and then clears the screen. Cancelling warns the user if unsaved changes exist and, on confirmation, clears the screen; if no changes exist, the screen is cleared immediately. Deleting prompts for confirmation before removing the current record. Inserting is explicitly blocked on this screen and tells the user the operation cannot be performed here. The Print button has no active implementation and performs no action. The LOV (Look Up) button, when enabled, opens the appropriate lookup list for the current field.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user activates one of the toolbar buttons.

**Main Flow:**

**Step 1 - Save: changes committed and screen cleared**
When the user clicks the Save button, the system commits all pending changes to the database and then clears the form. The earlier validation-and-error-reporting logic that would have checked for and displayed validation errors before committing is commented out and does not execute; the commit is performed unconditionally.

**Step 2 - Cancel: unsaved changes confirmed before discarding**
When the user clicks the Cancel button, the system first checks whether the Cancel button is enabled. If it is enabled and there are unsaved changes on the screen, the user is asked to confirm that the entered data should not be saved. If the user confirms, the screen is cleared. If the user does not confirm, nothing happens. If there are no unsaved changes, the screen is cleared immediately without asking.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-006](#sp-006)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation dialog to the user via the `AL_CONFIRM` alert and returns a numeric indicator of the user's choice, so that calling triggers can determine whether the user confirmed or declined a potentially destructive action such as cancellation or deletion.
    * **Step 1** - Set the confirmation alert message to the text provided ("Entered data will not be Saved").
    * **Step 2** - Display the confirmation alert and capture the user's response.
    * **Step 3** - If the user confirmed (pressed the first button), return a confirmation signal.
    * **Step 4** - If the user did not confirm (pressed any other button), return a cancellation signal.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirm discard of unsaved changes | FT_CANCEL - GENERAL.ASK_CONFIRM [SP-006] | When the user clicks Cancel and unsaved changes exist | Prevents accidental loss of data the user has entered | If the user does not confirm, the cancel is abandoned and the screen retains its current state |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-WS-01** - User clicks Cancel with unsaved changes - *"Entered data will not be Saved"* confirmation dialog shown; if confirmed, screen is cleared; if not confirmed, nothing happens.

**Step 3 - Delete: confirmation required before record is removed**
When the user clicks the Delete button, the system checks whether the Delete button is currently enabled. If it is enabled (and the cursor is in the expected block - which in practice is never the case on this form as the expected block does not exist here), the user is asked to confirm the deletion. If confirmed, the current record is deleted. If not confirmed, no action is taken.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-006](#sp-006)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation dialog to the user via the `AL_CONFIRM` alert and returns a numeric indicator of the user's choice, so that calling triggers can determine whether the user confirmed or declined a potentially destructive action such as cancellation or deletion.
    * **Step 1** - Set the confirmation alert message to the text provided ("Are you sure to Delete?").
    * **Step 2** - Display the confirmation alert and capture the user's response.
    * **Step 3** - If the user confirmed, return a confirmation signal.
    * **Step 4** - If the user did not confirm, return a cancellation signal.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Confirm record deletion | FT_DEL - GENERAL.ASK_CONFIRM [SP-006] | When the user clicks Delete and the Delete button is enabled | Prevents accidental deletion of records | If the user does not confirm, the deletion is cancelled and the record is retained |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-WS-02** - User clicks Delete - *"Are you sure to Delete?"* confirmation dialog shown; if confirmed, record is deleted; if not confirmed, nothing changes.

**Step 4 - Insert: operation blocked on this screen**
When the user clicks the Insert button and it is enabled, the system shows an error message and does not perform any insertion. Insert is not a supported operation on this reporting parameter screen.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title to the provided title string.
    * **Step 3** - Set the alert message body to the provided error text.
    * **Step 4** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert not permitted on this screen | FT_INSERT - GENERAL.DISP_TEXT [SP-007] | When the user clicks Insert and it is enabled | Prevents the user from attempting to insert data, which is not a valid operation on a report-criteria screen | *"This Operation Cannot be performed Here"* is shown; no insertion is performed |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - User clicks Insert when enabled - *"This Operation Cannot be performed Here"* is shown; the form stays unchanged.

**Step 5 - Print button: no active implementation**
When the user clicks the Print button and it is enabled, the system performs no action. The print capability placeholder is present but has not been implemented. (COMMENTED OUT / INACTIVE - no print action executes.)

---

#### Requirement ID: BR-013

**Requirement Title:** Report Type and Output Format Selection

**Business Description:**
Before submitting a report, the user selects the output destination (cache, printer, file, e-mail, or direct Excel export) and the report format (PDF or character mode). Selecting "Printer" as the destination automatically sets the format to character mode and prevents the user from changing it. Any other destination activates PDF format by default and allows the user to choose a different format. If the user selects Excel as the format, the file-name field becomes available; for any other format, the file-name field is cleared and disabled.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open with the region, quarter, and financial year already selected.

**Main Flow:**

**Step 1 - Destination selected and format adjusted automatically**
When the user changes the output destination, the system automatically sets the appropriate format. Selecting the printer destination fixes the format to character mode and prevents any change; selecting any other destination enables PDF format and allows the user to switch format if needed.

*Screen: Extended Warranty Incentive Details (WN_MAIN / CN_MAIN).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Printer destination requires character-mode format | WHEN-LIST-CHANGED on CB_BLK.P_DESTYPE - format set to CHAR and disabled | When the user changes the output destination | Ensures the format is always compatible with the chosen destination | Format is automatically set to CHAR and cannot be changed |
| Non-printer destination enables PDF format | WHEN-LIST-CHANGED on CB_BLK.P_DESTYPE - format set to PDF and enabled | When the user changes the output destination | Allows the user to select a format appropriate for non-printer delivery | PDF is set as the default; the user may change it |

*Business outcomes (errors, warnings, success, and status):*
- **BR-013-IC-01** - Destination is "PRINTER" - format automatically set to character mode and locked.
- **BR-013-IC-02** - Destination is non-printer - format set to PDF and the user may select a different output format.

**Step 2 - Excel format enables the file-name field**
When the user selects Excel as the output format, the file-name field becomes enabled and navigable so the user can specify where the output file should be saved. For any other format, the file-name field is cleared and disabled.

*Screen: Extended Warranty Incentive Details (WN_MAIN / CN_MAIN).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Excel format requires a file name | WHEN-LIST-CHANGED on CB_BLK.P_DESFORMAT - FILENAME enabled when EXCEL | When the user changes the output format | Ensures the file-name field is available only when Excel output is selected | File-name field becomes active for entry |
| Non-Excel format disables and clears file name | WHEN-LIST-CHANGED on CB_BLK.P_DESFORMAT - FILENAME cleared and disabled | When the user selects a non-Excel format | Prevents a stale file name from being carried over to a non-Excel report run | File-name field is cleared and locked |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Output Destination (`P_DESTYPE`) | Mandatory | List Item | N/A | N/A | CACHE, PRINTER, FILE, MAIL, EXCEL | Report criteria selected | Must be a valid destination option | N/A (list selection constrained) |
| Output Format (`P_DESFORMAT`) | Mandatory | List Item | N/A | N/A | PDF, CHAR, EXCEL | Destination selected | CHAR when printer; PDF or user choice otherwise | Automatically adjusted based on destination |
| Report Type (`P_REPO_TYPE`) | Optional | List Item | N/A | N/A | (as configured) | N/A | N/A | N/A |
| File Name (`FILENAME`) | Conditional - when Excel format is selected | Text Item | 4000 | N/A | N/A | Excel format selected | Enabled only when EXCEL format is active | Field disabled and cleared for non-Excel format |

---

#### Requirement ID: BR-014

**Requirement Title:** From Date Mandatory Validation

**Business Description:**
When the user moves away from the "From Date" field, the form confirms that a value has been entered. If the field is left empty, the user is shown an alert and cannot proceed until a date is provided. This ensures the report always has a defined start date for its reporting period.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open and the user has navigated to or from the From Date field.

**Main Flow:**

**Step 1 - From Date validated when the user leaves the field**
When the user tabs or navigates away from the From Date field, the system checks that a value is present. If the field is empty, an alert is shown and the navigation is cancelled so the user remains on the field until a date is entered.

*Screen: Extended Warranty Incentive Details (WN_MAIN / CN_MAIN).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must not be empty | WHEN-VALIDATE-ITEM on CB_BLK.P_FROM_DT - IF :P_FROM_DT IS NULL THEN show AL_ERRINFO | When the user leaves the From Date field | Ensures every report run has a valid start date defined before the report can be generated | *"From Date cannot be empty"* alert is shown; focus remains on the From Date field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - From Date is empty when user leaves the field - *"From Date cannot be empty"* is shown; focus returns to the From Date field; navigation is cancelled.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROM_DT`) | Mandatory | Text Item | Date (DD-MM-YYYY) | N/A | N/A | Quarter and financial year selected | Must not be empty when user leaves the field | *"From Date cannot be empty"* - focus returns to the field |

---

#### Requirement ID: BR-015

**Requirement Title:** Report Submission and Output Generation

**Business Description:**
When the user clicks the Submit button, the form performs a final check that the three mandatory parameters - region, quarter, and financial year - have all been provided. If any of these is missing, the user is shown an error and returned to the relevant field. Once all mandatory criteria are confirmed, the form takes one of two paths depending on the output type: for Excel output, it directly queries the incentive data, assembles the results as a CSV file, and opens it in the browser; for all other output types, it assembles the full report parameter string, configures the Oracle Reports engine with the chosen destination and format, runs the report, and delivers the output.

**Actors:** Service User

**Preconditions:**
- The report criteria screen is open with region, quarter, and financial year selected.
- The user has chosen an output destination and format.

**Main Flow:**

**Step 1 - Quarter-year reporting period key recalculated**
When the user clicks Submit, the form first recomputes the internal quarter-year period key from the current financial year and quarter-month values, ensuring the report always uses the latest combination the user has set.

**Step 2 - Mandatory parameter check before report generation**
The form verifies that region, quarter, and financial year are all provided. If any is blank, an error message is shown and the user's focus is moved to the missing field; report generation does not proceed.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#sp-007)) - GENERAL.DISP_TEXT - Displays a message to the user in a modal alert dialog using the error-style alert, so the user understands exactly which mandatory field requires attention.
    * **Step 1** - Determine the alert type based on the title provided ("Error" selects the error alert).
    * **Step 2** - Set the alert title and message body to the provided text.
    * **Step 3** - Display the alert to the user and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007]; IF :cb_blk.p_region_cd IS NULL | When the user clicks Submit | Ensures the report always has a geographic region filter | *"Region can not be Blank)"* shown; focus returns to Region field; submission cancelled |
| Quarter must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007]; ELSIF :cb_blk.quarter IS NULL | When the user clicks Submit | Ensures the reporting quarter is always specified | *"Quarter can not be Blank)"* shown; focus returns to Quarter field; submission cancelled |
| Financial Year must not be blank at submission | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - GENERAL.DISP_TEXT [SP-007]; ELSIF :cb_blk.financial_year IS NULL | When the user clicks Submit | Ensures the financial year is always specified so the correct period is reported | *"Financial Year can not be Blank)"* shown; focus returns to Financial Year field; submission cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-01** - Region is blank when Submit is clicked - *"Region can not be Blank)"* is shown; focus returns to the Region field; submission is cancelled.
- **BR-015-ES-02** - Quarter is blank when Submit is clicked - *"Quarter can not be Blank)"* is shown; focus returns to the Quarter field; submission is cancelled.
- **BR-015-ES-03** - Financial Year is blank when Submit is clicked - *"Financial Year can not be Blank)"* is shown; focus returns to the Financial Year field; submission is cancelled.

**Step 3 - Excel path: CSV file generated and opened in browser**
If the output destination is Excel, the form calls the Excel report generation procedure, which builds a query against the incentive detail data, assembles three sections (column headers, incentive slab headings, and numbered data rows), writes the result to a CSV file on the report server, and opens it in the browser.

*Procedures called:*
- **EXCEL_REPORT** ([SP-001](#sp-001)) - EXCEL_REPORT - Builds a CSV extract of Extended Warranty incentive detail records, assembles a multi-section query covering column headers, slab headings, and data rows, and delegates file creation and browser display to the view procedure.
    * **Step 1** - Construct a timestamped CSV filename using the current user identifier and date/time.
    * **Step 2** - Build the column-header row as a static string from DUAL.
    * **Step 3** - Build the incentive slab-heading row by calling the slab-header function for each slab category and the current company.
    * **Step 4** - Build the data rows from the incentive detail view, applying region, dealer, city, and transaction-month filters.
    * **Step 5** - Combine all three sections and pass the assembled query to the file-writing and browser-display procedure.
    * **Step 6** - If an unhandled exception occurs, suppress it silently.

**Step 4 - Non-Excel path: Oracle Reports parameter assembly and report run**
If the output destination is any format other than Excel, the form assembles the full report parameter string from the current screen selections, configures the report object with the chosen destination (cache, printer, file, or e-mail) and format, sets the report server, runs the report, and opens the output in the browser.

*Procedures called:*
- **PR_PASS_PARAM** ([SP-003](#sp-003)) - PR_PASS_PARAM - Builds the URL-style parameter string for the Oracle Reports engine by iterating over the report's registered parameter definitions and mapping the current screen values, enforcing that the From Date is not empty before proceeding.
    * **Step 1** - Open a cursor over the report parameter definitions for the current application and company.
    * **Step 2** - For each parameter, append the current screen value to the parameter string in name=value format.
    * **Step 3** - If the From Date parameter is encountered and the From Date field is empty, show an alert and stop processing.
    * **Step 4** - Return the fully assembled parameter string.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date required for non-Excel report parameter assembly | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - PR_PASS_PARAM [SP-003]; IF :P_FROM_DT IS NULL | When assembling report parameters for a non-Excel report run | Ensures the report always has a start date parameter defined before the report engine is invoked | *"Please Enter From Date"* alert shown; focus returns to From Date field; report run is cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-04** - From Date is blank during parameter assembly - *"Please Enter From Date"* is shown; focus returns to the From Date field; the non-Excel report run is cancelled.
- **BR-015-SM-01** - All validations pass and Excel output is selected - the incentive CSV file is generated and opened in the browser.
- **BR-015-SM-02** - All validations pass and non-Excel output is selected - the report is submitted to the Oracle Reports engine and the output is delivered to the user.

**Alternative Flows:**
- **BR-015-AF-01** - (from Step 3) Output destination is EXCEL - the form calls the Excel report generation procedure directly, bypassing the Oracle Reports engine entirely.
- **BR-015-AF-02** - (from Step 4) Output destination is PRINTER - the report is configured for printer output in character mode; no browser display.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region (`P_REGION_CD`) | Mandatory | List Item | N/A | Region master | Region code and description | Form open | Must not be blank at submission | *"Region can not be Blank)"* shown; focus to Region field |
| Quarter (`QUARTER`) | Mandatory | List Item | N/A | N/A | Q1, Q2, Q3, Q4 | Region selected | Must not be blank at submission | *"Quarter can not be Blank)"* shown; focus to Quarter field |
| Financial Year (`FINANCIAL_YEAR`) | Mandatory | List Item | N/A | Financial year master | Year range (e.g. 2012-2013) | Quarter selected | Must not be blank at submission | *"Financial Year can not be Blank)"* shown; focus to Financial Year field |
| Submit (`SUBMIT`) | N/A | Push Button | N/A | N/A | N/A | All mandatory fields populated | N/A | N/A |

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Region is mandatory | Validation | BR-004 | The Region field is blank when the user moves off it | Show *"Region Code can not be empty"* and cancel the navigation; keep the user on the Region field | Ensures every report submission has a geographic region filter, preventing unfiltered or unintended report runs |
| BRC-002 | Region change clears dependent filters | Derivation | BR-004 | The user selects a different region | Automatically clear City, City code, Dealer, Dealer code, Quarter, From Date, and To Date | Prevents stale filter combinations (e.g. a city from a previous region) being carried over to a new region selection, ensuring report criteria are always internally consistent |
| BRC-003 | Quarter is mandatory on keyboard navigation | Validation | BR-005 | The Quarter field is blank when the user presses the navigation key to leave it | Show *"Quarter can not be Blank)"* and return focus to the Quarter field; cancel the navigation | Ensures a reporting quarter is always specified before the user can reach downstream fields |
| BRC-004 | Quarter change clears date range and financial year | Derivation | BR-005 | The user selects a different quarter | Automatically clear From Date, To Date, and Financial Year; derive the internal quarter-month code from the new quarter selection | Keeps the date range and financial year in sync with the chosen quarter; a different quarter means a different reporting period and potentially a different financial year |
| BRC-005 | Financial Year is mandatory on keyboard navigation | Validation | BR-006 | The Financial Year field is blank when the user presses the navigation key to leave it | Show *"Financial Year can not be Blank)"* and return focus to the Financial Year field; cancel the navigation | Ensures the financial year is always specified so the reporting period can be fully computed |
| BRC-006 | Q4 year advances by one for period key | Derivation | BR-006 | The selected quarter is Q4 | Use the selected financial year plus one as the year component of the internal quarter-year reporting key | Q4 spans into the following calendar year; using the base year without adjustment would produce an incorrect reporting period key |
| BRC-007 | From Date is mandatory on field exit | Validation | BR-007 | The From Date field is blank when the user moves off it | Show alert *"From Date cannot be empty"* and cancel the navigation | Ensures the report always has a defined start date for its period |
| BRC-008 | Printer destination forces character-mode format | Derivation | BR-008 | The user selects "PRINTER" as the output destination | Set the output format to "CHAR" and disable the format selector so the user cannot change it | Printer output requires character mode; PDF or EXCEL formats are incompatible with direct printer delivery |
| BRC-009 | Non-printer destination enables PDF format | Derivation | BR-008 | The user selects any destination other than "PRINTER" | Set the output format to "PDF" and enable the format selector | All non-printer destinations can accept PDF output; making the selector available allows the user to choose a different format (e.g. EXCEL) if needed |
| BRC-010 | EXCEL format enables File Name field | Derivation | BR-008 | The user selects "EXCEL" as the output format | Enable the File Name field and make it navigable | Excel output requires a target file name to be specified so the CSV can be saved correctly |
| BRC-011 | Non-EXCEL format disables and clears File Name | Derivation | BR-008 | The user selects any format other than "EXCEL" | Clear the File Name field and disable it | A file name is not applicable for non-Excel output; clearing it prevents outdated values from being passed to the report engine |
| BRC-012 | File Name is editable only for EXCEL format | Constraint | BR-008 | The user enters the File Name field while the format is not "EXCEL" | Block both inserting and updating in the File Name field (read-only mode) | Prevents the user from accidentally typing a file name that would not be used or could cause confusion for non-Excel report runs |
| BRC-013 | Region is mandatory at Submit | Validation | BR-009 | The Region field is blank when the user clicks Submit | Show *"Region can not be Blank)"*, move focus to the Region field, and cancel the submission | A report without a region filter cannot be generated; this check provides a final safety net at submission time |
| BRC-014 | Quarter is mandatory at Submit | Validation | BR-009 | The Quarter field is blank when the user clicks Submit | Show *"Quarter can not be Blank)"*, move focus to the Quarter field, and cancel the submission | A report without a specified quarter cannot be correctly scoped; this is the final enforcement before the report engine is invoked |
| BRC-015 | Financial Year is mandatory at Submit | Validation | BR-009 | The Financial Year field is blank when the user clicks Submit | Show *"Financial Year can not be Blank)"*, move focus to the Financial Year field, and cancel the submission | A report without a financial year cannot produce a correct period-based result |
| BRC-016 | Excel output uses direct CSV generation | Constraint | BR-009 | The user selects "EXCEL" as the output destination | Generate the report as a CSV directly from the incentive data view, bypassing the Oracle Reports engine | The Excel report path produces a structured, filtered CSV with dynamic incentive slab headings; this requires a direct data query rather than a formatted report |
| BRC-017 | Non-Excel output uses Oracle Reports engine | Constraint | BR-009 | The user selects any output destination other than "EXCEL" | Assemble report parameters, configure the Oracle Reports engine with the chosen destination and PDF format, run the report, and deliver the output | Oracle Reports handles formatted print-quality output for PDF, printer, and other delivery channels |
| BRC-018 | From Date required for non-Excel report parameter assembly | Validation | BR-009 | The From Date is blank when the report parameter assembly procedure processes the From Date parameter | Display alert *"Please Enter From Date"*, return focus to the From Date field, and cancel the parameter assembly | The report definition requires a From Date parameter; generating the report without it would produce incorrect or incomplete results |
| BRC-019 | Invalid date entry translated to user-friendly message | Validation | BR-002 | The form raises a date-validity error (code 50004) | Show *"Entered Date is not valid Date"* and cancel the failing operation; the form stays open | Replaces a technical Oracle Forms error code with a message that is understandable to a non-technical user |
| BRC-020 | Incorrect date format explained to user | Validation | BR-002 | The form raises a date-format error (code 50025 or 50026) | Show *"Enter the Date in the proper format (DD-MM-YYYY)"* and cancel the failing operation | Guides the user to the correct input format rather than showing a cryptic error code |
| BRC-021 | Non-numeric value in numeric field blocked | Validation | BR-002 | The form raises a numeric-field character error (code 40209 or 50016) | Show *"Characters/Special Characters are not allowed here, enter the numeric value"* and cancel the failing operation | Prevents invalid non-numeric data from being accepted in numeric fields |
| BRC-022 | Concurrent update conflict reported and rolled back | Validation | BR-002 | The form detects that another user modified the same record (codes 40654-40657, 40659) | Show *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back pending changes, and cancel the operation | Protects data integrity in multi-user scenarios by refusing to overwrite another user's changes |
| BRC-023 | Cancel with unsaved changes requires confirmation | Validation | BR-012 | The user clicks Cancel and the form has unsaved changes | Show *"Entered data will not be Saved"* confirmation dialog; clear the screen only if the user confirms | Prevents the user from accidentally losing data they have entered by requiring an explicit acknowledgement before discarding it (WF-001) |
| BRC-024 | Delete requires confirmation | Validation | BR-012 | The user clicks Delete and the Delete button is enabled | Show *"Are you sure to Delete?"* confirmation dialog; delete the record only if confirmed | Prevents accidental deletion by requiring the user to explicitly confirm the action before it is carried out (WF-001) |
| BRC-025 | Insert blocked on this screen | Constraint | BR-012 | The user clicks the Insert button when it is enabled | Show *"This Operation Cannot be performed Here"* and perform no insertion | This is a report criteria screen, not a data-entry screen; insert operations are not applicable here |
| BRC-026 | Report server falls back to session default on config error | Derivation | BR-001 | The report server address lookup from the system configuration fails (no record, multiple records, or any other error) | Use the session-level global report server address silently | Ensures the form can always start and the report engine can always be reached, even if the per-application server configuration is missing or ambiguous |
| BRC-027 | System message codes 40209 and 40207 shown as errors | Validation | BR-003 | Oracle Forms raises a system message with code 40209 or 40207 | Display the message text as an error alert and cancel the current form operation | Prevents confusing platform-level informational codes from reaching the user without context; re-framing them as errors makes the situation clearer |
| BRC-028 | City list populated after region selection | Derivation | BR-010 | The user has selected a region and navigates to the City field | Populate the city drop-down from the city master filtered by the selected region and current principal | Ensures only cities belonging to the selected region are available, preventing the user from combining a city with a mismatched region |
| BRC-029 | Dealer list filtered by region and city selection | Derivation | BR-011 | The user has selected a region and optionally a city, and navigates to the Dealer field | Populate the dealer drop-down from the dealer location master filtered by the selected region, city, and current principal | Ensures only dealers operating in the selected geography are available for selection, maintaining report filter integrity |
| BRC-030 | Printer destination sets character-mode format | Derivation | BR-013 | The user selects "PRINTER" as the output destination | Set the output format to "CHAR" and disable the format selector | Printer output is incompatible with PDF format; character mode is the only valid option for direct printer delivery |
| BRC-031 | Non-printer destination enables PDF format | Derivation | BR-013 | The user selects any destination other than "PRINTER" | Set the output format to "PDF" and enable the format selector | All non-printer destinations can accept PDF output; making the selector available allows the user to choose a different format if needed |
| BRC-032 | Excel format enables the file-name field | Derivation | BR-013 | The user selects "EXCEL" as the output format | Enable the file-name field and make it navigable | Excel output requires a target file name; enabling the field allows the user to specify the destination path |
| BRC-033 | Non-Excel format disables and clears file-name field | Derivation | BR-013 | The user selects any format other than "EXCEL" | Clear the file-name field and disable it | A file name is not applicable for non-Excel output; clearing it prevents stale values from being used |
| BRC-034 | From Date is mandatory before leaving the field | Validation | BR-014 | The From Date field is blank when the user navigates away from it | Show alert *"From Date cannot be empty"* and cancel the navigation | Ensures the report always has a defined start date for its reporting period |
| BRC-035 | Mandatory parameters validated before report generation | Validation | BR-015 | The user clicks Submit and any of Region, Quarter, or Financial Year is blank | Show an error message for the missing field, move focus to that field, and cancel the submission | A report cannot be generated without all three mandatory period and geography filters; this is the final safeguard before the report engine is invoked |
| BRC-036 | Excel output path uses direct CSV generation | Constraint | BR-015 | The user selects Excel as the output destination and clicks Submit | Generate the report as a CSV directly from the incentive data view | The Excel report path produces a structured CSV with dynamic incentive slab headings; this requires a direct data query rather than the Oracle Reports engine |
| BRC-037 | Non-Excel output path uses Oracle Reports engine | Constraint | BR-015 | The user selects any destination other than Excel and clicks Submit | Assemble report parameters, configure the Oracle Reports engine with the chosen destination and format, run the report, and deliver the output | Oracle Reports handles formatted output for PDF, printer, and other delivery channels |
| BRC-038 | From Date required for non-Excel report parameter assembly | Validation | BR-015 | The From Date is blank when the report parameter assembly procedure processes the From Date parameter | Show alert *"Please Enter From Date"*, return focus to the From Date field, and cancel the parameter assembly | The report definition requires a From Date parameter; generating the report without it would produce incorrect or incomplete results |

**Total Business Rules Identified: 38**

---

## 6. Data Requirements

*This section describes the data entities, capture requirements, reference data, and lifecycle that apply to the Extended Warranty Incentive Details report screening form (VR_PENETRATE), which collects user-selected filter criteria to generate incentive penetration reports for dealers and regions.*

### 6.1 Business Entities and Relationships

*The form operates as a parameter-entry screen only; it does not directly persist records to a primary business entity. The data it reads from and the view it drives for report output are described below.*

#### Extended Warranty Incentive Detail - VD_EW_INCE_DTL

This view is the primary data source for the Extended Warranty Incentive Details report generated by this form. It holds, per dealer and region, retail counts, Extended Warranty (EW-Gold and EW-Platinum) sales volumes, total EW sales, penetration percentages, and incentive slab amounts. The form queries this view during Excel report generation to build the CSV data payload. The view is read-only from the form's perspective.

#### Report Configuration - ED_REPORTS

This table holds the parameter definitions for each application report. The form reads it to determine which report parameters must be assembled and passed to the report engine at submission time. Parameters are fetched by application identifier and the current principal company. The table is read-only from the form's perspective.

#### Report Server Configuration - EH_REPORTS

This table supplies the report server address for a given application and principal. The form reads it at startup to resolve where the Oracle Reports server is hosted. On any exception (no record found, multiple records, or other error), the form falls back to the session-level global report server value.

#### Financial Company Calendar - FM_COMPANY

This table drives the Financial Year lookup list. It holds the open financial years for a dealer/location/company combination. The form queries it to populate the Financial Year drop-down with years that are not yet finally closed.

#### User-Region Access - AM_USER_REGION

This table constrains which regions the logged-in user may access. The form reads it to build the Region selection list, filtering to service-type user records matching the current user's identity and the current principal.

#### Dealer Location Master - AM_DEALER_LOC and AM_DEALER_LOC_PARAM

These two related tables supply the Dealer lookup list. `AM_DEALER_LOC` holds dealer location attributes (region, dealer type, city, codes); `AM_DEALER_LOC_PARAM` holds per-dealer parameter flags (e.g. whether DMS is implemented). Only dealer locations that have DMS implemented and are of the correct dealer-type categories are included in the list.

#### Geography - GM_FOR

This table provides city (For) descriptions keyed by region code and principal. It is used to build the City lookup list and to supply city descriptions in the Dealer lookup list.

#### Region Master - GM_REGN

This table is referenced by the zone/region list-population logic to build regional descriptions based on zone codes. It is used when populating zone-based selection lists during form initialisation.

#### Application List Values - AM_LIST

This lookup table stores code-description pairs for various application drop-down lists. The form reads it when the generic list-population utility needs to fill a list item from a named list in this master.

#### Entity Relationships

The form's entities are primarily looked-up reference tables that provide list values; they are not related to each other through master-detail data entry on this form. The relationships that do exist are:

- `AM_USER_REGION` constrains the `AM_DEALER_LOC` and `GM_REGN` lookups by region code.
- `AM_DEALER_LOC` joins to `AM_DEALER_LOC_PARAM` on parent group, dealer map code, and location code.
- `AM_DEALER_LOC` and `GM_FOR` join on `FOR_CD` and `PRINCIPAL_MAP_CD`.
- `FM_COMPANY` is filtered by the session's dealer, location, parent group, and company values.
- `EH_REPORTS` and `ED_REPORTS` are filtered by application identifier and principal.
- `VD_EW_INCE_DTL` is filtered by region, dealer, city, and reporting period at report-run time.

```
AM_USER_REGION
    ├── AM_DEALER_LOC ──── AM_DEALER_LOC_PARAM
    │         └── GM_FOR
    └── GM_REGN

FM_COMPANY            (Financial Year calendar - session-scoped filter)
EH_REPORTS            (Report server config - read at startup)
ED_REPORTS            (Report parameter definitions - read at submission)
VD_EW_INCE_DTL        (Incentive detail view - read at Excel report generation)
AM_LIST               (Generic list values - read on demand)
```

### 6.2 Data Capture Requirements

*The form captures filter/parameter values from the user to drive report generation. No business entity record is created or updated; all inputs are transient parameters passed to the reporting engine.*

#### Report Filter Parameters (User - report criteria selection)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Region (`P_REGION_CD`) | Yes | Geographic region for which the report is to be generated. Selected from the Region drop-down, which is pre-populated at startup from the user's permitted regions. | Must not be left blank; the form prevents navigation and report submission if no region is selected. |
| City (`P_CITY_DESC` / `P_CITY`) | No | Optional filter to restrict the report to a specific city within the selected region. Populated via a lookup list that refreshes when the region changes. | Optional; defaults to all cities if left blank. |
| Dealer (`P_DEALER_DESC` / `P_DEALER`) | No | Optional filter to restrict the report to a specific dealer within the selected region. Populated via a lookup list. | Optional; defaults to all dealers if left blank. |
| Quarter (`QUARTER`) | Yes | Fiscal quarter for which the incentive report is required (Q1 through Q4). Selecting a quarter clears the previously entered date range and financial year, and sets the internal quarter-month code used in the report parameters. | Must not be blank when navigating past the Quarter field; the form raises an error if left empty. |
| Financial Year (`FINANCIAL_YEAR`) | Yes | Financial year corresponding to the selected quarter. Selected from a drop-down populated from the company calendar. The form validates this field is not empty when navigating past it, and it computes the internal quarter-year parameter used in the report. | Must not be blank; the form raises an error and returns focus to the Financial Year field if left empty. |
| From Date (`P_FROM_DT`) | Conditional | Start date of the reporting period. Required by the parameter-assembly procedure at report submission if the configured parameters include a From Date. The format mask is DD-MM-RRRR. | Must not be null at report submission when this parameter is included in the report configuration; an alert is displayed and submission is blocked. |
| To Date (`P_TO_DT`) | Conditional | End date of the reporting period. Included in the assembled report parameters when configured. | Optional at the form level (the active validation for this field is inactive); included in parameters if provided. |
| Report Type (`P_REPO_TYPE`) | No | Selects the type of report variant. Changing the report type updates the output format and destination-format field availability. | No standalone mandatory check at the field level; used to build the report parameter string. |
| Destination (`P_DESTYPE`) | No | Output destination for the report (e.g., FILE, PRINTER, CACHE, MAIL). When set to PRINTER, the output format is fixed to CHAR and the format selector is disabled. Otherwise the format defaults to PDF and the selector is enabled. | Controls the format options available to the user. When navigating past this field, the cursor moves directly to the Submit button. |
| Output Format (`P_DESFORMAT`) | No | Output file format for the report (e.g., PDF, EXCEL, CHAR). When EXCEL is selected, the File Name field is enabled and navigable; for other formats it is cleared and disabled. | Availability is controlled by the Destination selection. |
| File Name (`FILENAME`) | Conditional | Name of the output file for Excel-format reports. Enabled for input only when the output format is set to EXCEL. | Insert and update are allowed only when the format is EXCEL; otherwise the field is read-only and non-editable. |

#### Session and Internal Parameters (System - set at startup and during processing)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Report Description (`REPORT_DESC`) | Auto-Populated | Fixed label "Extended Warranty Incentive Details" set at form startup; displayed on the screen as the report title. | Read-only; set from the session global at startup and on form clear. |
| Application Identifier (`APP_ID`) | Auto-Populated | Internal application code (`vr_penetrate`) set at startup and used to determine report parameters and the "All" option availability in lookup lists. | System-set; not user-editable. |
| Report Name (`REPORT_NAME`) | Auto-Populated | Internal report file name (`vr_penetrate`) set at startup and used as the filename passed to the Oracle Reports engine. | System-set; not user-editable. |
| Report Server (`REP_SERVER`) | Auto-Populated | Report server address resolved from the report configuration table at startup; falls back to the session global if not found. | System-set; not user-editable. |
| Copyright Declaration (`COPYRIGHT_DECLARATION`) | Auto-Populated | Copyright text fetched from the database at startup via `SF_COPYRIGHT_DECLARATION` and displayed on the main screen. | Read-only display item. |
| Quarter-Month Code (`P_QTR`) | Auto-Populated | Internal two-digit month code derived from the selected quarter (Q1->06, Q2->09, Q3->12, Q4->03) used to build the report's period parameter. | Derived automatically when the quarter or financial year is confirmed; not user-editable. |
| Quarter-Year Key (`P_QTR_YEAR`) | Auto-Populated | Combined financial-year-plus-month code assembled from the financial year value and the quarter-month code; passed to the report engine. | Derived automatically; not user-editable. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Region list (`RG_REGION` / `AM_USER_REGION`) | Provides the list of geographic regions the logged-in user is permitted to access, filtered to service-type users matching the current principal. | Populated at form startup to fill the Region drop-down; re-used on form clear. |
| City lookup (`LV_CITY` / `RG_CITY` / `GM_FOR`) | Provides the list of cities (For descriptions) within the currently selected region and principal. Includes an "ALL CITY" option when the P_CHECK parameter permits it. | Refreshed when the user selects a different region, so only cities belonging to the chosen region are shown. |
| Dealer lookup (`LV_DEALER` / `RG_DEALER` / `AM_DEALER_LOC`) | Provides the list of active dealers within the selected region whose DMS has been implemented, including their city, location, and company attributes. Includes an "ALL DEALERS" option when the P_CHECK parameter permits it. | Available for selection after a region is chosen; refreshed as the region filter changes. |
| Financial Year lookup (`FINANCIAL_YEAR` / `LOV801` / `FM_COMPANY`) | Lists open financial years for the current dealer/location/company combination, ordered newest first. | Available for selection after a quarter is chosen, to allow the user to specify the applicable financial year. |
| Report parameter definitions (`ED_REPORTS`) | Defines which parameters are required by the report and in what order, keyed by application identifier and principal. Used to build the parameter string passed to the report engine at submission. | Read during report parameter assembly when the user clicks Submit. |
| Report server address (`EH_REPORTS`) | Supplies the Oracle Reports server address for the current application and principal. | Read at form startup to configure the report engine connection. |
| Application list values (`AM_LIST`) | Generic code-description pairs used by the `L_POPULATE` utility to fill list items from named value sets. | Used when any list item is populated via the generic list-population procedure. |
| Incentive detail view (`VD_EW_INCE_DTL`) | Source of per-dealer, per-region Extended Warranty incentive data including retail counts, EW sales, penetration percentages, and slab amounts. | Queried during Excel report generation to assemble the CSV data rows. |
| Incentive slab headings (`SF_GET_SLAB_HEAD` function) | Provides the incentive slab header labels (A-E) for the current principal, used as column headers in the CSV report. | Called during Excel report header construction. |
| Copyright declaration (`SF_COPYRIGHT_DECLARATION` function) | Returns the copyright text to be displayed on the form and on clear. | Called at form startup and on form clear via `KEY-CLRFRM`. |

### 6.4 Data Lifecycle

*Describes how data is initialised, used, and cleared within this form's evidenced behaviour.*

**Creation**

- No business entity records are created by this form. All data capture is transient: filter values are held in the form's control block and passed as parameters to the Oracle Reports engine or to the Excel report generation procedure at submission.
- At form startup, the report description, application identifier, report name, and report server address are initialised from session globals and the report configuration table. The Region drop-down and the Financial Year drop-down are populated from their respective database queries.

**Updates**

- Filter fields (Region, City, Dealer, Quarter, Financial Year, Destination, Format, File Name) are updated by user selection. Certain field changes cascade to clear or recalculate dependent fields: selecting a new region clears the City, Dealer, Quarter, From Date, and To Date fields; selecting a new quarter clears the Financial Year, From Date, and To Date fields and recalculates the internal quarter-month code; changing the output format or destination updates the availability of the Format selector and File Name field.
- The internal report parameter string is assembled fresh each time the user clicks Submit, by reading the current field values and the report parameter definitions.

**Save and Commit**

- This form does not commit or persist any data. The `FT_SAVE` trigger (invoked by the Save button) calls `COMMIT_FORM` followed by a form clear. However, because no database-backed block is populated with user data, this commit has no effect on any business entity. The form functions purely as a reporting parameter screen.

**Retention and Audit**

- No audit stamps or retention fields are managed by this form. The form does not create, modify, or delete any audited business record. The application activity is registered with the Oracle database application-info facility at startup (module name `vr_penetrate`) and cleared on exit.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Region, City, Dealer, Quarter, Financial Year | S.No. | p_destype=EXCEL |  |  | Shows the S.No. column in this Excel export. |
| 2 | Region, City, Dealer, Quarter, Financial Year | Region | p_destype=EXCEL | VD_EW_INCE_DTL | REGION | Dealer region code read from VD_EW_INCE_DTL.REGION; filtered by :P_REGION_CD in the EXCEL_REPORT query. |
| 3 | Region, City, Dealer, Quarter, Financial Year | Dealer Code | p_destype=EXCEL | VD_EW_INCE_DTL | MUL_DEALER_CD | Shows the Dealer Code column in this Excel export. |
| 4 | Region, City, Dealer, Quarter, Financial Year | Dealer Name | p_destype=EXCEL | VD_EW_INCE_DTL | DEALER_NAME | Dealer name read directly from VD_EW_INCE_DTL.DEALER_NAME in the EXCEL_REPORT query. |
| 5 | Region, City, Dealer, Quarter, Financial Year | Loc_Desc | p_destype=EXCEL | VD_EW_INCE_DTL | LOC_DESC | Location description read from VD_EW_INCE_DTL.LOC_DESC in the EXCEL_REPORT query. |
| 6 | Region, City, Dealer, Quarter, Financial Year | City | p_destype=EXCEL | VD_EW_INCE_DTL | CITY | City name read from VD_EW_INCE_DTL.CITY in the EXCEL_REPORT query; filtered via FOR_CD matching :P_CITY. |
| 7 | Region, City, Dealer, Quarter, Financial Year | Retail | p_destype=EXCEL | VD_EW_INCE_DTL | RETAIL | Total retail vehicle count for the dealer and transaction month read from VD_EW_INCE_DTL.RETAIL. |
| 8 | Region, City, Dealer, Quarter, Financial Year | EW-Gold Sale | p_destype=EXCEL | VD_EW_INCE_DTL | EW1_SALE | Gold-tier Extended Warranty sales count read from VD_EW_INCE_DTL.EW1_Sale in the EXCEL_REPORT query. |
| 9 | Region, City, Dealer, Quarter, Financial Year | EW-Platinum Sale | p_destype=EXCEL | VD_EW_INCE_DTL | EW2_SALE | Platinum-tier Extended Warranty sales count read from VD_EW_INCE_DTL.EW2_Sale in the EXCEL_REPORT query. |
| 10 | Region, City, Dealer, Quarter, Financial Year | Total EW Sale | p_destype=EXCEL | VD_EW_INCE_DTL | TOTAL_EW | Combined Extended Warranty sales (Gold + Platinum) read from VD_EW_INCE_DTL.Total_EW in the EXCEL_REPORT query. |
| 11 | Region, City, Dealer, Quarter, Financial Year | Total Pen% | p_destype=EXCEL | VD_EW_INCE_DTL | EW_PEN | Overall EW penetration percentage (Total EW Sale / Retail) read from VD_EW_INCE_DTL.EW_Pen in the EXCEL_REPORT query. |
| 12 | Region, City, Dealer, Quarter, Financial Year | Platinum Pen% | p_destype=EXCEL | VD_EW_INCE_DTL | EW11_PEN | Platinum EW penetration percentage read from VD_EW_INCE_DTL.EW11_Pen in the EXCEL_REPORT query. |
| 13 | Region, City, Dealer, Quarter, Financial Year | Platinum EW Penetration Incentive Slabs | p_destype=EXCEL | VD_EW_INCE_DTL | SLAB1 | Shows the Platinum EW Penetration Incentive Slabs column in this Excel export. |
| 14 | Region, City, Dealer, Quarter, Financial Year | TOTAL | p_destype=EXCEL | VD_EW_INCE_DTL | TOTAL_INC | Total incentive amount for the dealer read from VD_EW_INCE_DTL.TOTAL_INC in the EXCEL_REPORT query. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| APP_ID | Application identifier - a session-level code set to `vr_penetrate` at form startup; used to identify the current application module to the reporting configuration and server | | Report Name, Application |
| BRD | Business Requirements Document - the formal document describing the functional and technical requirements of an Oracle Forms application module | | Functional Requirements, Technical Inventory |
| CB_BLK | Control block - the single Oracle Forms data block in vr_penetrate that holds all report parameter fields; it has no direct database table binding | Control Block | Block, Parameter |
| CSV | Comma-Separated Values - a text file format used for Excel-compatible report export generated by the EXCEL_REPORT procedure | | Excel, Export |
| Dealer | A DMS-registered service outlet (2S, 3S, or ASSC dealer type) identified by a dealer map code, location, and parent group | Dealer Map Code | Dealer Location, FOR Code |
| DMS | Dealer Management System - the integrated software platform for dealer operations within which vr_penetrate runs | | Principal, Application |
| DPL | DMS Program Library - the shared Oracle Forms PL/SQL library (DPL.pld) attached to vr_penetrate providing common utility routines such as DISP_TEXT, ASK_CONFIRM, and RAISE_ERROR | DPL.pld | GENERAL, Library |
| EW | Extended Warranty - a post-sale warranty product sold alongside new vehicles; the basis of the incentive scheme reported by this form | Extended Warranty | Incentive, Penetration |
| Financial Year | A twelve-month accounting period (e.g. 2012-2013) used to define the scope of the incentive report; derived from the company financial master | Fin Year | Quarter, Period |
| FOR Code | Franchise/Outlet/Region code - the city-level code used in the dealer network to identify a city or franchise area; returned by the city LOV as P_CITY | FOR_CD, City Code | City, Region |
| GENERAL | The package/namespace within DPL.pld that exposes shared utility procedures (DISP_TEXT, ASK_CONFIRM, CHECK_NULL, RAISE_ERROR, L_POPULATE, l_pop_list_item) | | DPL, Library Routine |
| LOV | List of Values - an Oracle Forms pop-up selection list used in vr_penetrate for city (LV_CITY), dealer (LV_DEALER), and financial year (FINANCIAL_YEAR) selection | Dropdown, Picklist | Record Group, Selection |
| MUL | Multi-location user type - a user who can access data across multiple regions and dealer locations, as opposed to a dealer (DLR) user restricted to a single region | Multi-location User | DLR, User Type |
| OLB | Object Library - a shared Oracle Forms object library (DPL.olb) that provides inherited property classes, visual attributes, and object groups used by vr_penetrate | .olb | DPL, Property Class |
| PCK | PL/SQL Package (`.pck`) - a compiled database package containing stored procedures and functions; no PCK files are included in the vr_penetrate bundle | Package | Stored Procedure, Database |
| PDF | Portable Document Format - the default report output format when destination is not PRINTER or EXCEL | | Report, Output Format |
| PLD | Program Library Definition - a shared Oracle Forms PL/SQL library source file (`.pld`) attached to a form module to provide reusable procedures and functions | .pld | DPL, GENERAL, Library |
| Principal | Principal map code - a multi-company identifier (`:GLOBAL.PRINCIPAL`) used across all LOV queries and report parameters to isolate data by automotive principal or manufacturer | Principal Map Code | Multi-company, DMS |
| Quarter | A three-month financial period (Q1-Q4) selected by the user as a mandatory report filter; maps to a month code (06/09/12/03) used as the report transaction month | Q1, Q2, Q3, Q4 | Financial Year, Period |
| RG | Record Group - an Oracle Forms object that holds the result set for a LOV query; used in vr_penetrate for RG_CITY, RG_REGION, RG_DEALER, and LOV801 | Record Group | LOV, Query |
| VD_EW_INCE_DTL | Extended Warranty Incentive Details view - the database view queried directly during Excel/CSV export to retrieve dealer-level EW penetration and incentive slab data | | EW, Incentive, CSV |
| vr_penetrate | The Oracle Forms module name for the Extended Warranty Incentive Details reporting screen | VR_PENETRATE | Form, Module, Application |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_penetrate (VR_PENETRATE)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, D2KWUTIL, DPL (DPL.pld program library), WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Extended Warranty Incentive Details (Rel 1.2.3)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_penetrate_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; D2KWUTIL; DPL (DPL.pld program library); WEBUTIL (webutil.olb)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier set to `vr_penetrate` at form startup; passed as report parameter |
| APP_LOG | Char | Trigger | Application logging flag; when set to `Y`, starts performance timer in PRE-FORM |
| COMP_FA | Char | RecordGroup / Trigger | Company financial account code used in financial year LOV query (LOV801) |
| CUR_DATE | Char | ProgramUnit | Current business date used as a reference date in validation logic |
| DEALER | Char | RecordGroup / Trigger | Dealer map code used to filter LOV801 financial year data for the current dealer |
| FIN_BEG | Char | Trigger | Financial year begin date used to derive the default financial year display value |
| FIN_END | Char | Trigger | Financial year end date used to derive the default financial year display value |
| LOC_CD | Char | RecordGroup / Trigger | Location code used to filter LOV801 financial year query for the current location |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent group code used to filter dealer and financial year LOV data |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code used across all record group queries for multi-company filtering |
| REPORT_DESC | Char | Trigger | Report description label set to `Extended Warranty Incentive Details` at form startup |
| REPORT_NAME | Char | Trigger | Report module name set to `vr_penetrate` at form startup; used in report object property |
| REP_SERVER | Char | Trigger | Report server name loaded from EH_REPORTS at startup; used when running reports |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used in region and dealer LOV queries and as report file name prefix |

### 8.1.2 Form Parameters

*All 5 ModuleParameter entries from vr_penetrate_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_USER_TYPE | Char | DLR | Identifies whether the logged-in user is a dealer (`DLR`) or a multi-location user (`MUL`); controls region and zone list filtering |
| P_CHECK | Char | - | Controls whether `ALL` option is included in city and dealer LOV queries; set to `0` for vr_penetrate at startup |
| P_REGION | Char | - | Incoming region code for dealer-type users; used in LIST_POPULATE_ZONE query filter |
| P_USER_HORO | Char | - | User hierarchy level (`HO` = head office, `RO` = regional office) for MUL users; controls zone list SQL in LIST_POPULATE_ZONE |
| P_APP_ID | Char | - | Application ID passed to the CSV report generation routine; set from `:GLOBAL.APP_ID` at form startup |

**Total Parameters:** 5

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - report parameter entry block; no database source |
| PB_BLK | - | 1 | N/N/N/N | Default | Toolbar push-button block; holds all action buttons (Save, Cancel, Delete, Insert, Exit, List, Print, Paste, Copy, Cut); no database source |
| CB_ERR | - | 1 | N/N/N/N | Default | Error display block; holds TXT_ERR item for error message display; no database source |

**Total Blocks:** 3 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_penetrate_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_penetrate_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_penetrate_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 36 | 0 | 36 |
| PB_BLK | 13 | 0 | 13 |
| CB_ERR | 1 | 0 | 1 |
| **Total** | **50** | **0** | **50** |

**Item detail (all 50 items, excl. WEBUTIL block):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | LOC_DESC | false | Location description - display label populated from dealer LOV selection |
| CB_BLK | REPORT_DESC | false | Report description label loaded from global at form startup |
| CB_BLK | P_REGION_CD | false | Region code parameter - required selection filter for the report |
| CB_BLK | P_FOR_DESC | false | City/FOR description - display name of the selected city; cleared when region changes |
| CB_BLK | P_MONTHYEAR | false | Month-year parameter field for monthly report filtering |
| CB_BLK | P_CITY_DESC | false | City description - display label populated from city LOV selection |
| CB_BLK | P_CITY | false | City FOR code - hidden code returned by city LOV (LV_CITY) |
| CB_BLK | P_DEALER_DESC | false | Dealer name - display label populated from dealer LOV selection |
| CB_BLK | QUARTER | false | Quarter selector (Q1-Q4) - required selection filter used to derive financial period dates |
| CB_BLK | FINANCIAL_YEAR | false | Financial year selector (e.g. 2012-2013) - required; populated from LOV or FIN_BEG/FIN_END |
| CB_BLK | P_DESFORMAT | false | Destination format selector (PDF, CHAR, EXCEL); enabled/disabled based on P_DESTYPE selection |
| CB_BLK | SUBMIT | false | Submit button - triggers parameter validation and executes report or Excel export |
| CB_BLK | YEAR | false | Numeric year portion of financial year returned by FINANCIAL_YEAR LOV |
| CB_BLK | FIN_YEAR | false | Formatted financial year string (e.g. 2012-2013) derived from global FIN_BEG/FIN_END |
| CB_BLK | P_QTR_YEAR | false | Computed quarter-year string (YYYYMM) passed as TRAN_MONTH parameter to report |
| CB_BLK | P_FIN_YEAR | false | Financial year numeric value (YYYY) used in quarter-year date calculation |
| CB_BLK | P_FROM_DT | false | From date parameter; validated as non-null before report execution |
| CB_BLK | P_TO_DT | false | To date parameter; formerly validated for range and currency - **COMMENTED OUT / INACTIVE** |
| CB_BLK | P_REPO_TYPE | false | Report type selector; value passed as P_REPO_TYPE parameter to report |
| CB_BLK | P_DESTYPE | false | Destination type selector (CACHE, PRINTER, FILE, MAIL, EXCEL); controls report output |
| CB_BLK | P_PARENT | false | Parent group code - passed as P_PARENT report parameter |
| CB_BLK | P_DEALER | false | Dealer map code - returned by dealer LOV; passed as P_DEALER report parameter |
| CB_BLK | P_LOC | false | Location code - returned by dealer LOV; passed as P_LOC report parameter |
| CB_BLK | APP_ID | false | Application identifier set to `vr_penetrate`; used as report file and parameter ID |
| CB_BLK | REPORT_NAME | false | Report module name (`vr_penetrate`) set at form startup; used in report object property |
| CB_BLK | REP_SERVER | false | Report server name loaded from EH_REPORTS; used for RUN_REPORT_OBJECT call |
| CB_BLK | P_FOR_CD | false | FOR code parameter passed to report; identifies the city/franchise code |
| CB_BLK | P_T_PARENT | false | Total parent group code parameter for the report |
| CB_BLK | P_T_DEALER | false | Total dealer code parameter for the report |
| CB_BLK | P_T_LOC | false | Total location code parameter for the report |
| CB_BLK | P_DLR | false | Dealer code variant parameter for the report |
| CB_BLK | P_DES_TYPE | false | Destination type code (`E` for Excel, `P` for print) - list-changed trigger sets DESFORMAT |
| CB_BLK | FILENAME | false | Output file path or parameter string; enabled only when P_DESFORMAT = EXCEL |
| CB_BLK | CK | false | Stores the constructed SQL query string for debugging/verification purposes |
| CB_BLK | P_QTR | false | Quarter month code (06/09/12/03) derived from selected quarter; passed to report |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright text fetched from SF_COPYRIGHT_DECLARATION database function at startup |
| PB_BLK | PB_ERR_EXIT | false | Error-exit push button in the toolbar block - not used in current active logic |
| PB_BLK | PB_PASTE | false | Paste button - executes paste_region when clicked (inherited toolbar action) |
| PB_BLK | PB_COPY | false | Copy button - executes copy_region when clicked (inherited toolbar action) |
| PB_BLK | PB_CUT | false | Cut button - executes cut_region when clicked (inherited toolbar action) |
| PB_BLK | PB_PRINT | false | Print button - executes FT_PRINT trigger (no active implementation) |
| PB_BLK | PB_SAVE | false | Save button - executes FT_SAVE trigger to commit and clear the form |
| PB_BLK | PB_CANCEL | false | Cancel button - executes FT_CANCEL trigger for discard-with-confirmation |
| PB_BLK | PB_DEL | false | Delete button - executes FT_DEL trigger for confirmed record deletion |
| PB_BLK | PM_CONT | false | Continue button - navigates to CB_ERR block, clears it, and navigates to B_GM_PROGRAM_MASTER |
| PB_BLK | PB_INSERT | false | Insert button - executes FT_INSERT trigger; insert is blocked on this screen |
| PB_BLK | PB_LIST | false | List button - executes FT_LIST trigger to display the LOV for the current field |
| PB_BLK | PB_EXIT | false | Exit button - exits the form directly; confirmation prompt is commented out and inactive |
| CB_ERR | TXT_ERR | false | Error text display item in the CB_ERR error display block; holds error message text |
| WEBUTIL | DUMMY | false | WEBUTIL infrastructure placeholder item; not part of business logic; excluded from business scope |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Dealer Master | RG_DEALER | CB_BLK.P_DEALER_DESC |
| LV_CITY | City | RG_CITY | CB_BLK.P_CITY_DESC, CB_BLK.P_CITY |
| FINANCIAL_YEAR | Financial_Year | LOV801 | CB_BLK.FINANCIAL_YEAR |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| AL_CONFIRM | (set at runtime) | (set at runtime via GENERAL.ASK_CONFIRM) | Used by GENERAL.ASK_CONFIRM library routine; invoked from FT_CANCEL (confirm discard unsaved changes), FT_DEL (confirm deletion), and PB_BLK.PB_EXIT |
| AL_NOTE | (set at runtime) | (set at runtime via GENERAL.DISP_TEXT) | Used by GENERAL.DISP_TEXT library routine when title is not "Error"; displays informational messages |
| AL_ERRINFO | (set at runtime) | (set at runtime via GENERAL.DISP_TEXT) | Used by GENERAL.DISP_TEXT library routine when title = "Error"; displays all error messages throughout the form; also used directly by PR_PASS_PARAM for "Please Enter From Date" |
| AL_PRINT | (set at runtime) | (set at runtime) | Toolbar print alert; referenced in form definition but FT_PRINT has no active implementation |
| ALERT_BUT | Note | Please select valid region code and for code | Direct form-level alert used by WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD for region validation |
| WEBUTIL_ERROR | (set at runtime) | (set at runtime) | Inherited from WEBUTIL object group - not invoked by active triggers in this form |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **11 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL, GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Entire body is block-commented; formerly validated test-drive fields using CHECK_NULL; current body is NULL |
| CHECK_BEFORE_DELETE | Unknown | GENERAL.DISP_TEXT | **COMMENTED OUT / INACTIVE** - Entire body is block-commented; formerly checked SH_ENQUIRY for dependent records before allowing deletion |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab | Package specification declaring the PL/SQL table V_TAB used to collect validation errors; referenced but body is commented out in FT_SAVE |
| L_POPULATE | Procedure | AM_LIST, GENERAL.L_POPULATE (via DPL.pld) | Populates a list item from the AM_LIST lookup table filtered by list name and principal; used for code list items |
| PR_REMOVE_ASCII_CHR | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT, GENERAL.DISP_TEXT | Reads a CSV report file, removes form-feed characters (ASCII 12), writes a clean output file, and displays it in the browser |
| PR_PASS_PARAM | Procedure | ED_REPORTS, DUAL | Reads report parameter definitions from ED_REPORTS and builds the report parameter string (lv_param) from current block item values |
| LIST_POPULATE_ZONE | Procedure | GM_REGN, AM_USER_REGION | Populates the zone code list item dynamically based on user type (MUL/HO, MUL/RO, DLR) using GM_REGN and AM_USER_REGION |
| POP_LIST_REGION | Procedure | RG_REGION | Populates the P_REGION_CD list item from the RG_REGION record group at form startup |
| VIEW_EXCEL_REP | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT | Executes a dynamic query, writes results to a CSV file on the report server, and opens it in the browser |
| L_POP_LIST_ITEM | Procedure | GENERAL.l_pop_list_item (via DPL.pld) | **COMMENTED OUT / INACTIVE** - Wrapper commented by developer; formerly created and populated a dynamic record group from a SQL query |
| EXCEL_REPORT | Procedure | VD_EW_INCE_DTL, SF_GET_SLAB_HEAD, VIEW_EXCEL_REP | Builds a CSV query against VD_EW_INCE_DTL with incentive slab headers from SF_GET_SLAB_HEAD and exports the result to Excel via VIEW_EXCEL_REP |

**Total Program Units:** 11

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |



**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a confirmation dialog with the supplied message; returns 1 if user clicks Yes, 0 otherwise |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | Validates that a field value is not null; raises FORM_TRIGGER_FAILURE with a descriptive error message if null - **COMMENTED OUT / INACTIVE** (called only from commented VALIDATE_CN_MAIN body) |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.FINANCIAL_YEAR, CB_BLK.P_REGION_CD, CB_BLK.QUARTER, CB_BLK.SUBMIT, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a message dialog using AL_ERRINFO (for Error title) or AL_NOTE (for other titles) with runtime-set message text |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Creates and populates a dynamic record group from a SQL query and assigns it to the specified list item |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error code, formats an error/note/caution message, and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error-type messages |



### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Commit the current form data | Body is `NULL;`; commit is handled by FT_SAVE trigger |
| **Commented out** | Form | - | FT_SAVE | Validated form using POPULATE_ERRORS.V_TAB before committing; collected errors into CB_ERR block; raised FORM_TRIGGER_FAILURE if errors found; then executed COMMIT_FORM and DO_KEY('CLEAR_FORM') | Error collection logic commented out; only `COMMIT_FORM; DO_KEY('CLEAR_FORM');` executes |
| **Commented out** | CB_BLK | P_TO_DT | WHEN-VALIDATE-ITEM | Validated that P_TO_DT was not null, not greater than sysdate, not less than P_FROM_DT, and within one month of P_FROM_DT | Entire body is block-commented; current body is `NULL;` |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Prompted user with ASK_CONFIRM if form status was CHANGED before calling exit_form | Confirmation logic commented out; only `do_key('exit_form');` executes |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*


**Complete trigger inventory (46 business triggers):**
*vr_penetrate_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle Forms errors; maps specific error codes to user-friendly messages via GENERAL.DISP_TEXT; handles date-format, numeric, and record-lock errors; calls GENERAL.RAISE_ERROR for ORA-02292 |
| ON-MESSAGE | Form | - | Form level | Suppresses or re-displays forms messages for error codes 40209 and 40207 via GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Clears DBMS application info and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name for the current item and displays it at position (200,120); navigates to next item on successful selection |
| KEY-COMMIT | Form | - | Form level | **INACTIVE STUB** - Body is `NULL;`; does not commit data |
| KEY-CLRFRM | Form | - | Form level | Clears form without validation, restores report description from global, and re-fetches copyright declaration from the database |
| KEY-OTHERS | Form | - | Form level | Inherited from DPL_MTPL object group - handles unassigned key events |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited from DPL_MTPL object group - navigates to next item |
| KEY-PREV-ITEM | Form | - | Form level | Inherited from DPL_MTPL object group - navigates to previous item |
| KEY-NXTBLK | Form | - | Form level | Inherited from DPL_MTPL object group - navigates to next block |
| KEY-PRVBLK | Form | - | Form level | Inherited from DPL_MTPL object group - navigates to previous block |
| KEY-DOWN | Form | - | Form level | Inherited from DPL_MTPL object group - navigates down a row |
| KEY-UP | Form | - | Form level | Inherited from DPL_MTPL object group - navigates up a row |
| FT_SAVE | Form | - | Form level | Commits the form and clears it; error-collection logic (POPULATE_ERRORS) is commented out |
| FT_CANCEL | Form | - | Form level | If cancel button is enabled and form has changed, prompts user with ASK_CONFIRM before clearing form; otherwise clears directly |
| FT_INSERT | Form | - | Form level | Displays an error message stating insert is not permitted on this form |
| FT_DEL | Form | - | Form level | If delete button is enabled and cursor is on B_GM_PROGRAM_MASTER, prompts with ASK_CONFIRM and deletes the record |
| FT_LIST | Form | - | Form level | If list button is enabled, executes LIST_VALUES key action |
| FT_PRINT | Form | - | Form level | Print action stub - does nothing (both branches return NULL) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Initializes form: sets global report description and name, loads report server from EH_REPORTS, populates region list (POP_LIST_REGION), fetches copyright declaration, and computes default financial year from FIN_BEG/FIN_END |
| PRE-FORM | Form | - | Form level | Sets DBMS application info to `vr_penetrate` and starts the performance timer if APP_LOG = Y |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Validates that region code is not null; if null displays error via GENERAL.DISP_TEXT and raises failure; if valid clears P_FOR_DESC |
| WHEN-LIST-CHANGED | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Clears dependent city, dealer, quarter, from/to date fields when region changes |
| WHEN-LIST-CHANGED | CB_BLK | QUARTER | CB_BLK.QUARTER | Clears P_FROM_DT, P_TO_DT, and FINANCIAL_YEAR; sets P_QTR from the selected quarter; navigates to FINANCIAL_YEAR |
| KEY-NEXT-ITEM | CB_BLK | QUARTER | CB_BLK.QUARTER | Validates QUARTER is not blank before navigating; displays error if blank |
| KEY-NEXT-ITEM | CB_BLK | FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR | Validates FINANCIAL_YEAR is not blank; computes P_QTR_YEAR from quarter and financial year; navigates to P_DESTYPE |
| WHEN-LIST-CHANGED | CB_BLK | P_DESFORMAT | CB_BLK.P_DESFORMAT | Enables/disables FILENAME item based on whether DESFORMAT is EXCEL |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Validates region, quarter, and financial year are not blank; then either runs EXCEL_REPORT or executes the report via RUN_REPORT_OBJECT with parameters built by PR_PASS_PARAM |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROM_DT | CB_BLK.P_FROM_DT | Validates P_FROM_DT is not null; displays AL_ERRINFO alert if empty |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TO_DT | CB_BLK.P_TO_DT | **COMMENTED OUT / INACTIVE** - Entire body is block-commented; current body is `NULL;` |
| WHEN-LIST-CHANGED | CB_BLK | P_REPO_TYPE | CB_BLK.P_REPO_TYPE | Sets DESFORMAT to CHAR and disables it when DESTYPE = PRINTER; otherwise sets DESFORMAT to PDF and enables it |
| WHEN-LIST-CHANGED | CB_BLK | P_DESTYPE | CB_BLK.P_DESTYPE | Sets DESFORMAT to CHAR and disables it when DESTYPE = PRINTER; otherwise sets PDF and enables it |
| KEY-NEXT-ITEM | CB_BLK | P_DESTYPE | CB_BLK.P_DESTYPE | Navigates directly to CB_BLK.SUBMIT |
| WHEN-LIST-CHANGED | CB_BLK | P_DES_TYPE | CB_BLK.P_DES_TYPE | Sets DESFORMAT to CHAR and disables it when DESTYPE = PRINTER; otherwise sets PDF and enables it |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | FILENAME | CB_BLK.FILENAME | Enables or disables insert/update on FILENAME based on whether P_DESFORMAT = EXCEL |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Exits the form directly via do_key('exit_form'); confirmation prompt is commented out |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Executes the FT_LIST trigger to display LOV |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Executes the FT_INSERT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Navigates to CB_ERR block, clears it without validation, and navigates to B_GM_PROGRAM_MASTER |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Executes the FT_DEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Executes the FT_CANCEL trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Executes the FT_SAVE trigger to commit and clear the form |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Executes the FT_PRINT trigger |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts the selected region to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies the selected region to clipboard |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes from clipboard to the current item |

### 8.8 Canvas and Window Inventory

*Canvas and window inventory from vr_penetrate_fmb.xml. WEBUTIL-related canvas (WEBUTIL_CANVAS) and hidden window (WEBUTIL_HIDDEN_WINDOW) are listed for completeness but are excluded from business scope.*

**Window Inventory:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WN_MAIN | Extended Warranty Incentive Details (Rel 1.2.3) | CN_MAIN |
| WIN_ERR | Error Details | CN_ERR |

**Canvas Inventory:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Toolbar | WN_MAIN |
| CN_MAIN | Content | WN_MAIN |
| CN_ERR | Content | WIN_ERR |

*WEBUTIL_CANVAS (Stacked/Hidden, WEBUTIL_HIDDEN_WINDOW) - WEBUTIL infrastructure canvas; excluded from business scope.*

### 8.9 Editors

*No editors found in vr_penetrate_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_penetrate_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger/object |
| KEY-NEXT-ITEM | Inherited trigger/object |
| KEY-PREV-ITEM | Inherited trigger/object |
| KEY-NXTBLK | Inherited trigger/object |
| KEY-PRVBLK | Inherited trigger/object |
| KEY-DOWN | Inherited trigger/object |
| KEY-UP | Inherited trigger/object |
| CN_ERR | Inherited trigger/object |
| VA_DISP | Inherited trigger/object |
| CB_ERR | Inherited trigger/object |
| VA_LOV | Inherited trigger/object |
| VA_TRNI_DT | Inherited trigger/object |
| VA_TITLE | Inherited trigger/object |
| VA_ALERT | Inherited trigger/object |
| VA_BUTN | Inherited trigger/object |
| VA_TEXT | Inherited trigger/object |
| VA_MPROMPT | Inherited trigger/object |
| VA_OPROMPT | Inherited trigger/object |
| VA_MAND | Inherited trigger/object |
| VA_NUM | Inherited trigger/object |
| VA_DESC | Inherited trigger/object |
| VA_ICONIC_BUTN | Inherited trigger/object |
| VA_RB | Inherited trigger/object |
| VA_CB | Inherited trigger/object |
| WN_MAIN | Inherited trigger/object |
| POP_MAIN | Inherited trigger/object |
| CN_MAIN | Inherited trigger/object |
| CN_TOOL | Inherited trigger/object |
| PB_BLK | Inherited trigger/object |
| AL_ERRINFO | Inherited trigger/object |
| AL_NOTE | Inherited trigger/object |
| AL_CONFIRM | Inherited trigger/object |
| WIN_ERR | Inherited trigger/object |
| AL_PRINT | Inherited trigger/object |
| FT_SAVE | Inherited trigger/object |
| FT_CANCEL | Inherited trigger/object |
| FT_INSERT | Inherited trigger/object |
| FT_DEL | Inherited trigger/object |
| FT_LIST | Inherited trigger/object |
| FT_PRINT | Inherited trigger/object |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger/object |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_penetrate_fmb.xml.*

---

## 9. Object Library

*The form subclasses Visual Attributes and Property Classes from the DPL shared Object Library. The catalogue below lists all objects available in the sourced OLB file, with usage counts reflecting the number of form elements in VR_PENETRATE that reference each object.*

Source OLB file(s): DPL.olb, DPL_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual attribute | 3 | Form items inheriting checkbox styling |
| VA_RB | VisualAttribute | Radio button visual attribute | 3 | Form items inheriting radio-button styling |
| VA_ICONIC_BUTN | VisualAttribute | Iconic push-button visual attribute | 3 | Toolbar icon buttons |
| VA_DESC | VisualAttribute | Description field visual attribute | 3 | Text description display items |
| VA_NUM | VisualAttribute | Numeric field visual attribute | 3 | Numeric input/display items |
| VA_MAND | VisualAttribute | Mandatory field visual attribute | 4 | Mandatory input fields (e.g. P_REGION_CD) |
| VA_OPROMPT | VisualAttribute | Optional prompt/label visual attribute | 3 | Optional field labels |
| VA_MPROMPT | VisualAttribute | Mandatory prompt/label visual attribute | 3 | Mandatory field labels |
| VA_TEXT | VisualAttribute | Standard text field visual attribute | 3 | General text input items |
| VA_BUTN | VisualAttribute | Push-button visual attribute | 3 | Standard push buttons (e.g. SUBMIT) |
| VA_ALERT | VisualAttribute | Alert/message visual attribute | 3 | Alert dialog styling |
| VA_TITLE | VisualAttribute | Title/heading visual attribute | 3 | Screen title display items |
| VA_TRNI_DT | VisualAttribute | Transaction date field visual attribute | 3 | Date input items (e.g. P_FROM_DT) |
| VA_LOV | VisualAttribute | LOV-enabled field visual attribute | 3 | Fields backed by a list of values |
| VA_DISP | VisualAttribute | Display-only field visual attribute | 4 | Read-only display items (e.g. REPORT_DESC, COPYRIGHT_DECLARATION) |
| PC_DESC | PropertyClass | Property class for description text items | 0 | Not directly referenced in this form |
| PC_SC_DATE | PropertyClass | Property class for date items | 0 | Not directly referenced in this form |
| PC_TITLE | PropertyClass | Property class for title text items | 0 | Not directly referenced in this form |
| PC_FORMAT | PropertyClass | Property class for formatted text items | 0 | Not directly referenced in this form |
| PC_MR_BLK | PropertyClass | Property class for multi-row blocks | 0 | Not directly referenced in this form |
| PC_DISP | PropertyClass | Property class for display items | 0 | Not directly referenced in this form |
| PC_LOV | PropertyClass | Property class for LOV-backed items | 1 | LOV-enabled fields |
| PC_FORM | PropertyClass | Property class for the form window | 1 | Form-level window object |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items | 0 | Not directly referenced in this form |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items | 0 | Not directly referenced in this form |
| PC_DATE | PropertyClass | Property class for editable date items | 0 | Not directly referenced in this form |
| PC_DTTIME | PropertyClass | Property class for date-and-time items | 0 | Not directly referenced in this form |
| PC_CB | PropertyClass | Property class for check boxes | 0 | Not directly referenced in this form |
| PC_ALERT | PropertyClass | Property class for alert dialogs | 0 | Not directly referenced in this form |
| PC_MDATE | PropertyClass | Property class for mandatory date items | 0 | Not directly referenced in this form |
| PC_RB | PropertyClass | Property class for radio buttons | 0 | Not directly referenced in this form |
| PC_WIND | PropertyClass | Property class for windows | 0 | Not directly referenced in this form |
| PC_CANV | PropertyClass | Property class for canvases | 0 | Not directly referenced in this form |
| PC_BUTN | PropertyClass | Property class for push buttons | 0 | Not directly referenced in this form |
| PC_TEXT | PropertyClass | Property class for standard text items | 5 | General text input items (e.g. P_CITY_DESC, P_DEALER_DESC, FILENAME) |
| PC_MTEXT | PropertyClass | Property class for mandatory text items | 1 | Mandatory text input fields |
| PC_UTEXT | PropertyClass | Property class for uppercase text items | 0 | Not directly referenced in this form |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items | 0 | Not directly referenced in this form |
| PC_NUM | PropertyClass | Property class for numeric items | 0 | Not directly referenced in this form |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items | 0 | Not directly referenced in this form |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons | 0 | Not directly referenced in this form |
| PC_SCROLL | PropertyClass | Property class for scrollable items | 0 | Not directly referenced in this form |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_CITY | Query | LV_CITY | CITY_DESC | FOR_CD | Yes - PARAMETER | Lists cities (FOR codes) available for the selected region so the user can filter the report by city | LV_CITY -> CB_BLK.P_CITY_DESC, CB_BLK.P_CITY |
| RG_REGION | Query | - | REGION_CD | CODE | No | Provides the list of service regions accessible to the logged-in user for populating the region selector | - |
| RG_DEALER | Query | LV_DEALER | DEALER | DEALER_NAME | Yes - CB_BLK, PARAMETER | Lists dealers within the selected region so the user can optionally filter the report to a specific dealer | LV_DEALER -> CB_BLK.P_DEALER_DESC |
| LOV801 | Query | FINANCIAL_YEAR | ICRGGQ_0 | ICRGGQ_1 | No | Lists open financial years for the current dealer and company so the user can select the financial year for the report | FINANCIAL_YEAR -> CB_BLK.FINANCIAL_YEAR |

**Total Record Groups:** 4

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER | Dealer location master - stores dealer codes, names, locations, region, and parent group for each DMS-enabled dealer |
| `AM_LIST` | - | L_POPULATE | Application list master - provides code/description pairs for populating form list items by list name |
| `AM_USER_REGION` | - | RG_REGION | User-region access mapping - stores which service regions each user is authorised to access |
| `DUAL` | - | EXCEL_REPORT, PR_PASS_PARAM, RG_CITY, RG_DEALER, Trigger KEY-CLRFRM, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system pseudo-table - used for scalar expressions and conditional UNION ALL members in LOV queries |
| `ED_REPORTS` | - | PR_PASS_PARAM | Report parameter definitions - stores parameter names, types, and defaults for each application report |
| `EH_REPORTS` | - | Trigger WHEN-NEW-FORM-INSTANCE | Report server configuration - provides the report server name per application ID and principal |
| `FM_COMPANY` | - | RG_LOV801 | Company financial master - provides open financial years for the current dealer, location, and company |
| `GM_REGN` | - | LIST_POPULATE_ZONE | Geography region master - stores region and zone information used to populate the zone list by user type |
| `MULDMS.GM_FOR` | - | RG_CITY | FOR/city master - stores city (FOR) codes and descriptions per region and principal for city LOV population |

**Total Referenced Objects:** 9

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | POP_LIST_REGION | Populates the Region selection list at form startup by fetching the user's permitted regions from the database |
| BR-001 | GENERAL.DISP_TEXT | Displays error and informational alerts to the user |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers the form name with the database session activity tracker at startup |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Registers the module name with the database session activity tracker at startup |
| BR-002 | GENERAL.DISP_TEXT | Displays user-friendly error messages when form or database errors occur |
| BR-002 | GENERAL.RAISE_ERROR | Handles referential-integrity constraint errors by displaying a configured message |
| BR-003 | GENERAL.DISP_TEXT | Re-routes intercepted system messages as user-facing error alerts |
| BR-004 | GENERAL.DISP_TEXT | Displays an error when the Region field is left blank |
| BR-005 | GENERAL.DISP_TEXT | Displays an error when the Quarter field is left blank on navigation |
| BR-006 | GENERAL.DISP_TEXT | Displays an error when the Financial Year field is left blank on navigation |
| BR-009 | GENERAL.DISP_TEXT | Displays errors when mandatory criteria (Region, Quarter, Financial Year) are blank at Submit |
| BR-009 | EXCEL_REPORT | Generates the Extended Warranty incentive CSV report when Excel output is selected |
| BR-009 | VIEW_EXCEL_REP | Writes and delivers the CSV file to the browser; called by EXCEL_REPORT |
| BR-009 | PR_PASS_PARAM | Assembles the report parameter string from the current filter criteria for the Oracle Reports engine |
| BR-009 | PR_REMOVE_ASCII_CHR | Post-processes the generated report file to remove ASCII control characters (dead code path - never reached from current trigger logic) |
| BR-009 | WEB.SHOW_DOCUMENT | Delivers the generated report output file to the user via the browser |
| BR-012 | GENERAL.ASK_CONFIRM | Displays a confirmation dialog before the Cancel or Delete action proceeds |
| BR-012 | GENERAL.DISP_TEXT | Displays an error when the Insert operation is attempted |

### 12.2 Procedure and Package Catalogue

#### EXCEL_REPORT

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| EXCEL_REPORT | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Builds the Extended Warranty incentive CSV report by constructing a UNION ALL query over the incentive detail view, filtered by the selected region, dealer, city, and reporting period, and delivers the result as a CSV file via the browser. Calls VIEW_EXCEL_REP. |

#### VIEW_EXCEL_REP

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| VIEW_EXCEL_REP | Form-local Program Unit (PROCEDURE) | EXCEL_REPORT (form-local) | Executes the supplied query into a record group, writes each row to a server-side CSV file, and opens the file in a new browser window using WEB.SHOW_DOCUMENT. Warns the user if the row count exceeds 65,535. Reads the web-accessible file path from a server configuration file. |

#### POP_LIST_REGION

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| POP_LIST_REGION | Form-local Program Unit (PROCEDURE) | WHEN-NEW-FORM-INSTANCE (form trigger) | Populates the Region drop-down by refreshing the RG_REGION record group from the database and synchronising the Region list item. |

#### PR_PASS_PARAM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PR_PASS_PARAM | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Assembles the Oracle Reports parameter string by querying the ED_REPORTS parameter definitions for the current application and principal, and mapping each parameter to the current screen filter value. Validates that a From Date is present; raises an error if not. |

#### PR_REMOVE_ASCII_CHR

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PR_REMOVE_ASCII_CHR | Form-local Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT (dead code path - the branch that calls this is inside the non-EXCEL block but tests for EXCEL destination, which is never true in that context) | Post-processes a server-side report file by reading it line-by-line, filtering out form-feed characters (CHR(12)), and writing the cleaned content to a new output file. Delivers the cleaned file via the browser. |

#### POPULATE_ERRORS

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| POPULATE_ERRORS | Form-local Program Unit (PACKAGE SPEC - inactive in live code) | Referenced in commented-out block of FT_SAVE | Package specification declaring a PL/SQL collection used to accumulate validation errors before displaying them. The error-collection and display logic in FT_SAVE that uses this package is entirely commented out and does not execute. |

#### L_POPULATE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| L_POPULATE | Form-local Program Unit (PROCEDURE - not invoked from any live code path) | Not called from any active trigger or program unit | Generic utility to populate a list item from a query against the AM_LIST code-description table, filtered by list name and principal. Present in the form as a reusable utility but not invoked in the current live implementation. |

#### LIST_POPULATE_ZONE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| LIST_POPULATE_ZONE | Form-local Program Unit (PROCEDURE - not invoked from any live code path) | Not called from any active trigger or program unit | Populates a zone/region selection list from GM_REGN based on the user type and access level. Builds the SQL query dynamically based on user type (multi-company head office, regional office, or dealer). Present in the form as a utility but not invoked in the current live implementation. |

#### L_POP_LIST_ITEM

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| L_POP_LIST_ITEM | Form-local Program Unit (PROCEDURE - not invoked from any live code path) | Not called from any active trigger or program unit (the original call in WHEN-NEW-FORM-INSTANCE is commented out) | Generic utility to populate a list item from an arbitrary query, using a record group as the intermediary. Present as a utility but replaced by POP_LIST_REGION and direct record-group calls in the current implementation. |

#### VALIDATE_CN_MAIN

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| VALIDATE_CN_MAIN | Form-local Program Unit (COMMENTED OUT / INACTIVE - does not execute) | Not called from any active code path | Contained validation logic for fields from a previous form version (test-drive booking). Entire procedure body is commented out. |

#### CHECK_BEFORE_DELETE

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| CHECK_BEFORE_DELETE | Form-local Program Unit (NULL body - INACTIVE - does not execute) | Not called from any active code path | Placeholder for a delete pre-check that would verify no dependent child records exist. The implementation is entirely commented out; the body executes only a NULL statement. |

#### GENERAL (package)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.DISP_TEXT | Attached Library - DPL (EXTERNAL / BUNDLE PRESENT) | ON-ERROR, ON-MESSAGE, WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD, KEY-NEXT-ITEM on CB_BLK.QUARTER, KEY-NEXT-ITEM on CB_BLK.FINANCIAL_YEAR, FT_INSERT, WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT, ProgramUnit PR_REMOVE_ASCII_CHR | Displays an alert dialog (error or note type) with the specified title and message text. Used throughout the form to show user-facing error and information messages. |
| GENERAL.ASK_CONFIRM | Attached Library - DPL (EXTERNAL / BUNDLE PRESENT) | FT_CANCEL, FT_DEL | Displays a confirmation alert with the specified message and returns 1 if the user confirms or 0 if they decline. Used to prompt the user before destructive actions. |
| GENERAL.RAISE_ERROR | Attached Library - DPL (EXTERNAL / BUNDLE PRESENT) | ON-ERROR | Looks up and displays a configured error message by error code, with severity-based routing (Error aborts the operation; Note and Caution allow processing to continue). |

#### DBMS_APPLICATION_INFO (package)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Records the current form name (at startup) or clears it (on exit) in the database session's client-info slot, enabling database administrators to monitor which form is running. |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Records the module name (at startup) or clears it (on exit) in the database session's module-and-action slots. |

#### WEB (package)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Attached Library - WEBUTIL (EXTERNAL / BUNDLE PRESENT) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT, ProgramUnit VIEW_EXCEL_REP, ProgramUnit PR_REMOVE_ASCII_CHR | Opens the specified URL in a new browser tab/window, used to deliver the generated report file (PDF or CSV) to the user after the report has been written to the server. |

---

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_penetrate-e87e58963266/in``. Package specifications cannot be generated without uploaded PCK sources.*

---

## 14. Database Package Catalogue

*No PCK files were found in the input bundle (`/app/workspace/vr_penetrate-e87e58963266/in`). The catalogue and function-values tables are provided as required structural shells. Rows will be populated when PCK source files are supplied.*

**Package Catalogue:**

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| N/A - no PCK files available | - | - | - | - | - | - |

**Function Return Values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| N/A - no PCK files available | - | - | - |

---

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Sets the AL_CONFIRM alert message to the supplied text, displays it, and returns 1 if the user clicks Button 1 (Yes) or 0 otherwise; used to guard cancel and delete actions |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | Selects AL_ERRINFO (for title = Error) or AL_NOTE (for any other title), sets the message text and title at runtime, then displays the alert; used for all user-facing error and information messages |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Queries AM_LIST for the given list name filtered by the current PRINCIPAL, populates a temporary record group named `list`, and assigns it to the specified list item field |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM | Finds or creates a record group with the given name from the supplied SQL query, then populates it; provides a shared utility for building dynamic list items from any SQL |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Formats the error code into a message string; if message type is E raises FORM_TRIGGER_FAILURE after displaying via DISP_TEXT; if N or C, displays an informational or caution dialog; NOTE: get_message call is commented out, so mesg_text will be empty in live execution |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_penetrate_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - VALIDATE_CN_MAIN body is entirely block-commented; CHECK_NULL is not called in any active code path; it would raise FORM_TRIGGER_FAILURE with an 'Enter a valid {column_title}' message if the value were null |

**Total Active Routines:** 5 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | Checks whether a Forms handle (RecordGroup, Item, etc.) is null/unresolved; returns TRUE if handle is null, FALSE if valid; used to guard against operating on uninitialized group or item handles |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | EW Incentive CSV Report Service | VD_EW_INCE_DTL, SF_GET_SLAB_HEAD | region_cd, dealer_map_cd (optional), city_for_cd (optional), tran_month, principal_map_cd | CSV file (Extended Warranty incentive summary with dealer details, sales, penetration percentages, and incentive slab amounts) | Generates the Extended Warranty Incentive Details CSV report filtered by region, dealer, city, and reporting period month for the specified principal company | POST /api/v1/reports/ew-incentive/csv |
| MS-002 | Report Parameter Assembly Service | ED_REPORTS | app_id, principal_map_cd, region_cd, city_for_cd, dealer_map_cd, p_from_dt, p_to_dt, p_repo_type, p_des_type | Assembled report parameter string for Oracle Reports engine | Assembles the Oracle Reports parameter string by reading the report parameter definitions for the specified application and principal and mapping the supplied filter values | POST /api/v1/reports/parameters/assemble |
| MS-003 | Report Server Lookup Service | EH_REPORTS | app_id, principal_map_cd | Report server address (string) | Resolves the Oracle Reports server address for the specified application and principal; returns a configured fallback if not found | GET /api/v1/config/report-server/{app_id}/{principal_map_cd} |
| MS-004 | Region List Service | AM_USER_REGION | user_id, user_type, principal_map_cd | List of region codes and descriptions the user is permitted to access | Returns the list of regions available to the specified user for report filtering, restricted to the user's authorised regions for service-type access | GET /api/v1/lookups/regions?user_id={user_id}&user_type={user_type}&principal={principal_map_cd} |
| MS-005 | City Lookup Service | GM_FOR | region_cd, principal_map_cd, include_all (boolean) | List of city (For) codes and descriptions within the specified region | Returns the cities available for report filtering within a given region and principal; includes an "ALL CITY" option when include_all is true | GET /api/v1/lookups/cities?region_cd={region_cd}&principal={principal_map_cd} |
| MS-006 | Dealer Lookup Service | AM_DEALER_LOC, AM_DEALER_LOC_PARAM, GM_FOR | region_cd, principal_map_cd, include_all (boolean) | List of eligible dealers (dealer map code, name, location, city, parent group) within the specified region | Returns DMS-implemented dealers of the correct dealer types within a given region and principal; includes an "ALL DEALERS" option when include_all is true | GET /api/v1/lookups/dealers?region_cd={region_cd}&principal={principal_map_cd} |
| MS-007 | Financial Year Lookup Service | FM_COMPANY | parent_group, loc_cd, dealer_map_cd, comp_code | List of open financial years (display string and raw year value) | Returns the list of open (not finally closed) financial years for the specified dealer/location/company combination, for use in financial year selection | GET /api/v1/lookups/financial-years?parent_group={pg}&loc_cd={lc}&dealer_map_cd={dm}&comp_code={cc} |
| MS-008 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION (database function) | (none - function reads from session/database context) | Copyright declaration text string | Returns the current copyright declaration text to be displayed on the reporting screen | GET /api/v1/config/copyright-declaration |

**Total Microservices Identified: 8**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Extended Warranty Incentive Report Generation | User clicks the Submit button on the report criteria screen | 1. Recalculate internal reporting period key from financial year and quarter month. 2. Validate that Region, Quarter, and Financial Year are all provided. 3. Branch on output destination: if Excel, call Excel report generation procedure; otherwise assemble Oracle Reports parameters and run the report object. 4. Deliver output to the user via the browser or configured delivery channel. | (a) Is Region blank? -> Show error, return to Region field, end. (b) Is Quarter blank? -> Show error, return to Quarter field, end. (c) Is Financial Year blank? -> Show error, return to Financial Year field, end. (d) Is output destination EXCEL? -> Use direct CSV generation path. (e) Is From Date blank during parameter assembly? -> Show alert, return to From Date field, end. (f) Is output destination PRINTER? -> PDF format not applicable; use character-mode format. | Report delivered to user (CSV opened in browser for Excel path; PDF or character-mode output delivered via browser or print channel for Oracle Reports path) |
| WF-002 | Form Initialisation | Application opens (WHEN-NEW-FORM-INSTANCE fires after PRE-FORM) | 1. Register session in the database activity tracker. 2. Set report description label to "Extended Warranty Incentive Details". 3. Derive and display the current financial year from session period dates. 4. Set application identity and internal report name. 5. Resolve and store the report server address from the system configuration. 6. Maximise the application and main windows. 7. Restore the report description on screen. 8. Populate the Region drop-down from the user's authorised regions. 9. Fetch and display the copyright declaration. | Is the report server address found in the system configuration? -> If not (or on any error), fall back to the session global report server address silently. | Form displayed in maximised state with Region drop-down populated, report title shown, copyright displayed, and all filter fields empty and ready for input |
| WF-003 | Region Selection and Dependent Filter Reset | User changes the Region drop-down selection | 1. Clear City, City code, Dealer, Dealer code, Quarter, From Date, and To Date. 2. On field exit, validate that Region is not blank. | Is Region blank on exit? -> Show *"Region Code can not be empty"* and cancel navigation. | Region confirmed and set; all dependent fields cleared and available for re-entry |
| WF-004 | Quarter Selection and Period Initialisation | User changes the Quarter drop-down selection | 1. Clear Financial Year, From Date, and To Date. 2. Map the selected quarter to its internal month code (Q1->June, Q2->September, Q3->December, Q4->March). 3. Move focus to the Financial Year field. 4. On field exit, validate Quarter is not blank. | Is Quarter blank on exit? -> Show *"Quarter can not be Blank)"* and return focus. Is Q4 selected during period key computation? -> Use financial year plus one for the year component. | Quarter confirmed; internal quarter-month code set; Financial Year, From Date, and To Date cleared for entry |
| WF-005 | Financial Year Confirmation and Quarter-Year Key Computation | User navigates away from the Financial Year field | 1. Validate that Financial Year is not blank. 2. Compute the internal quarter-year key from financial year and quarter-month code. 3. Move focus to the Destination field. | Is Financial Year blank? -> Show *"Financial Year can not be Blank)"* and return focus. Is quarter Q4? -> Use financial year plus one for year component of the period key. | Financial Year confirmed; quarter-year reporting period key computed and stored; focus moved to Destination |
| WF-006 | Cancel with Change Confirmation | User clicks the Cancel button | 1. Check if Cancel button is enabled. 2. If enabled and form has unsaved changes, show *"Entered data will not be Saved"* confirmation. 3. If user confirms, clear the form. If user declines, do nothing. 4. If enabled but no unsaved changes, clear the form immediately. | Is Cancel button enabled? -> If not enabled, do nothing. Does the form have unsaved changes? -> Yes: show confirmation. -> No: clear immediately. Did the user confirm the discard? -> Yes: clear form. -> No: abandon cancel. | Form cleared (criteria reset) or unchanged (if user declined) |
| WF-007 | Form Exit and Session Deregistration | User activates the exit action (keyboard exit key or Exit button) | 1. Clear the session's client-info and module-name registrations from the database activity tracker. 2. Close the form without validating or saving. | None | Form closed; session activity registration cleared |

**Total Workflows Identified: 7**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | /api/v1/pld/ask_confirm | When a cancel or delete action is requested, then a confirmation dialog is shown and the action proceeds only if the user confirms |
| PLD-002 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field is empty, then an error is displayed and form trigger failure is raised; not executed in current form |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | /api/v1/pld/disp_text | When an error or informational message needs to be shown, then an alert dialog is displayed with the supplied text and title |
| PLD-004 | L_POPULATE | Business Logic | ProgramUnit: L_POPULATE | /api/v1/pld/l_populate | When a list item needs to be populated from the AM_LIST lookup table, then the list is refreshed with codes and descriptions for the specified list name and principal |
| PLD-005 | l_pop_list_item | Business Logic | ProgramUnit: L_POP_LIST_ITEM | /api/v1/pld/l_pop_list_item | When a list item is to be built from a custom SQL query, then a record group is created or replaced and the list item is populated with the query results |
| PLD-006 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is passed, then a formatted message is displayed and FORM_TRIGGER_FAILURE is raised for error-type messages |


---

### webutil.pld (`WEBUTIL_C_API`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Validation | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a Forms object handle is checked before use, then TRUE is returned if the handle is null so the caller can safely skip or create the object |

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/vr_penetrate-e87e58963266/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| AM_USER_REGION | Table (SELECT) | Provides the list of regions the logged-in user is authorised to access, filtered to service-type users matching the current principal | Form <- AM_USER_REGION: fetched at startup to populate the Region drop-down | No explicit error handler; failure during Populate_Group causes a silent empty list |
| EH_REPORTS | Table (SELECT) | Supplies the Oracle Reports server address for the current application and principal | Form <- EH_REPORTS: queried at startup; result stored in report server field | On NO_DATA_FOUND, TOO_MANY_ROWS, or WHEN OTHERS: silently falls back to the session-level global report server address |
| ED_REPORTS | Table (SELECT) | Supplies the report parameter definitions (names, types, order) for the current application and principal | Form <- ED_REPORTS: queried during report parameter assembly when Submit is clicked | Cursor-based read; individual parameter mismatches handled by the per-parameter conditional logic in PR_PASS_PARAM |
| VD_EW_INCE_DTL | View (SELECT) | Provides per-dealer Extended Warranty incentive data (retail counts, EW Gold and Platinum sales, penetration percentages, incentive slab amounts) used in the Excel report | Form <- VD_EW_INCE_DTL: queried during EXCEL_REPORT execution; filtered by region, dealer, city, and reporting period | Exceptions handled with WHEN OTHERS THEN NULL in EXCEL_REPORT; silent failure with no row output |
| FM_COMPANY | Table (SELECT) | Supplies the open financial years for the current dealer/location/company combination | Form <- FM_COMPANY: queried to populate the Financial Year drop-down list (LOV801 record group) | Standard record-group population; Populate_Group return code stored but not evaluated for error |
| AM_DEALER_LOC, AM_DEALER_LOC_PARAM, GM_FOR | Tables (SELECT - joined) | Provides the list of eligible dealers, their location details, city descriptions, and company attributes for the Dealer lookup | Form <- AM_DEALER_LOC / AM_DEALER_LOC_PARAM / GM_FOR: queried to populate the Dealer lookup list (RG_DEALER record group) | Standard record-group population |
| GM_FOR | Table (SELECT) | Provides city (For) descriptions filtered by region and principal for the City lookup | Form <- GM_FOR: queried to populate the City lookup list (RG_CITY record group) | Standard record-group population |
| AM_LIST | Table (SELECT) | Provides generic code-description pairs for application drop-down lists, keyed by list name and principal | Form <- AM_LIST: queried by L_POPULATE utility when populating list items from named value sets (utility not invoked in the current live implementation) | Handled by standard record-group population |
| DUAL | Pseudo-table (SELECT) | Used for date arithmetic (computing default date ranges) and for executing single-value queries (e.g. copyright declaration) | Form <- DUAL: used in PR_PASS_PARAM for date range computation, and in WHEN-NEW-FORM-INSTANCE for copyright declaration fetch | Exceptions handled with WHEN OTHERS THEN NULL in PR_PASS_PARAM; copyright declaration read with implicit error from failed SELECT |
| SF_COPYRIGHT_DECLARATION | Database Function (SELECT from DUAL) | Returns the copyright declaration text to be displayed on the form and refreshed on form clear | Form <- SF_COPYRIGHT_DECLARATION: called at startup and on form clear | No explicit exception handler; failure results in an unhandled error surfaced via ON-ERROR |
| SF_GET_SLAB_HEAD | Database Function | Returns the incentive slab heading label (A-E) for a given slab category and principal, used as column headers in the CSV report | Form <- SF_GET_SLAB_HEAD: called up to five times per report generation (one per slab category) within the EXCEL_REPORT SQL string | Exceptions handled with WHEN OTHERS THEN NULL in EXCEL_REPORT |
| GM_REGN | Table (SELECT) | Provides zone and region descriptions used by the LIST_POPULATE_ZONE utility for zone-based filter population | Form <- GM_REGN: referenced by LIST_POPULATE_ZONE (utility not invoked in the current live implementation) | Handled by standard record-group population |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report Engine (run_report_object) | Executes the Oracle Reports-format report for non-Excel output and delivers it as a PDF or character-mode file to the server | Oracle Reports runtime (RUN_REPORT_OBJECT via Forms) | Server address resolved from EH_REPORTS or session global (:global.rep_server) | Parameters: assembled parameter string from PR_PASS_PARAM; Output: report file written to /iashome/ias/reports/printer/ on the server | Report status captured in lv_rep variable; no explicit failure handler - exceptions propagated to ON-ERROR |
| Web Browser | Document Delivery (WEB.SHOW_DOCUMENT) | Delivers generated report files (PDF or CSV) to the user by opening a URL in a new browser tab | HTTP / browser URL | /printer/<filename> relative path (PDF) or configured web path (CSV) | Outbound: file URL passed to browser; no data returned | WEBUTIL library WEB.SHOW_DOCUMENT; errors propagated to ON-ERROR |
| Server File System (excelpath.txt) | File Read (TEXT_IO) | Reads the web-accessible base path for Excel report files from a server-side configuration file | File I/O via TEXT_IO | /reports/DMS/excelpath.txt on the application server | Inbound: single-line text file containing the URL base path; used to construct the full web-accessible CSV file path | No explicit error handler; failure in VIEW_EXCEL_REP raises FORM_TRIGGER_FAILURE via the exception block |
| Server File System (report output files) | File Write (TEXT_IO) | Writes the generated CSV report content to the server file system for subsequent browser delivery | File I/O via TEXT_IO | /iashome/ias/reports/printer/<filename>.csv on the application server | Outbound: CSV rows written line by line from the record group | Errors in VIEW_EXCEL_REP shown via GENERAL.DISP_TEXT (Oracle error code and text); FORM_TRIGGER_FAILURE raised |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Resolved from EH_REPORTS at startup; falls back to session global rep_server | Assembled parameter string from PR_PASS_PARAM; includes P_REGION_CD, P_CITY, P_DEALER, P_PARENT, P_LOC, P_FROM_DT, P_TO_DT, P_REPO_TYPE, P_DES_TYPE; MODE=BITMAP BLANKPAGES=NO parform=yes prepended for PDF output | PDF (file destination for standard output); CHAR (when destination is PRINTER) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - when the user clicks Submit and the output destination is not EXCEL |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_PENETRATE form.

### 21.1 Catalogue Index

17 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--EXCEL_REPORT) | EXCEL_REPORT |
| [SP-002](#SP-002--POP_LIST_REGION) | POP_LIST_REGION |
| [SP-003](#SP-003--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-004](#SP-004--PR_REMOVE_ASCII_CHR) | PR_REMOVE_ASCII_CHR |
| [SP-005](#SP-005--VIEW_EXCEL_REP) | VIEW_EXCEL_REP |
| [SP-006](#SP-006--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-007](#SP-007--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-008](#SP-008--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-009](#SP-009--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-010](#SP-010--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-011](#SP-011--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-012](#SP-012--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-013](#SP-013--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-014](#SP-014--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-015](#SP-015--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-016](#SP-016--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-017](#SP-017--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |

---

### 21.2 Detailed Specifications

#### SP-001 - EXCEL_REPORT

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Builds a filtered CSV data extract of EW (Extended Warranty) incentive detail records for the current principal, assembles a multi-section query covering header rows, slab headings, and data rows, and then delegates file creation and browser display to VIEW_EXCEL_REP.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- VIEW_EXCEL_REP ([SP-005](#SP-005--VIEW_EXCEL_REP)) - JSON-LD ProgramUnit

---

**Step-by-Step Business Logic**

- Step 1 - Construct a time-stamped CSV filename using the current user ID and the current date/time (format `RRRRMMDDHH24MISS`), appended with `.CSV`.
- Step 2 - Build the first sub-query: a static header row that defines the column labels for the CSV (`S.No., Region, Dealer Code, ...`), selected from DUAL.
- Step 3 - Build the second sub-query: a dynamic slab-heading row assembled by calling `sf_get_slab_head` five times (slabs A-E) for the current principal, selected from DUAL.
- Step 4 - Build the third sub-query: numbered data rows from VD_EW_INCE_DTL, applying filters for region (`region LIKE :p_region_cd`), dealer (`DECODE` on `dealer_map_cd`), city (`DECODE` on `for_cd`), and transaction month (`TRAN_MONTH`).
- Step 5 - Combine all three sub-queries into a single UNION ALL SQL string stored in `lv_query`.
- Step 6 - Assign the assembled query to the form item `:ck` for diagnostic/display purposes.
- Step 7 - Call VIEW_EXCEL_REP, passing the filename, the assembled query, and the column alias `entire_string` to write the CSV file and open it in the browser.
- Step 8 - If any unhandled exception occurs during the procedure, suppress it silently (`WHEN OTHERS THEN NULL`).

---

**Decision Points**

DP-001

Condition:
The `:P_DEALER` parameter value is NULL (no specific dealer selected).

TRUE:
The DECODE in the data query resolves to the row's own `dealer_map_cd`, effectively including all dealers.

FALSE:
The DECODE restricts results to only the rows where `dealer_map_cd` equals the supplied dealer code.

DP-002

Condition:
The `:P_CITY` parameter value is NULL or `'ALL'` (no specific city selected).

TRUE:
The DECODE in the data query resolves to the row's own `for_cd`, effectively including all cities.

FALSE:
The DECODE restricts results to only the rows where `for_cd` equals the supplied city code.

---

**Database Interactions**

- DB-001 - Read DUAL - source for the static column-header row and the dynamic slab-heading row that form the first two sections of the CSV output.
- DB-002 - Read VD_EW_INCE_DTL - retrieve EW incentive detail records filtered by region, dealer, city, and transaction month to form the data rows of the CSV export.

---

**Business Rules**

- SBR-001 - The CSV filename is unique per user and per execution moment, formed by concatenating the current user ID with a timestamp accurate to the second.
- SBR-002 - Data rows are always filtered by the current principal (`GLOBAL.PRINCIPAL`) via the multi-company change applied to the slab-heading sub-query and the VD_EW_INCE_DTL filter.
- SBR-003 - Region filter uses a LIKE operator against `:p_region_cd`, allowing partial-match wildcard queries.
- SBR-004 - When no dealer is specified, the filter uses `DECODE(NVL(...,'99999'),'99999',dealer_map_cd,...)` to include all dealers rather than excluding records.
- SBR-005 - When no city is specified, the filter uses `DECODE(NVL(...,'ALL'),'ALL',for_cd,...)` to include all cities.
- SBR-006 - Any unhandled runtime exception is silently suppressed; no error is surfaced to the user from this procedure.

---

**Implementation Logic**

```plsql
PROCEDURE excel_report IS
BEGIN
  declare
  lv_query    varchar2(10000);
  lv_filename varchar2(9000); 
begin
	lv_filename := :global.userid || '-' ||to_char(sysdate, 'RRRRMMDDHH24MISS') || '.CSV';
      lv_query    := 'select ''S.No.,Region,Dealer Code,Dealer Name,Loc_Desc,City,Retail,EW-Gold Sale,EW-Platinum Sale,Total EW Sale,Total Pen%,Platinum Pen%,Platinum EW Penetration Incentive Slabs,,,,,TOTAL'' entire_string
                      from dual
                  union all
                     select '',,,,,,,,,,,,''||sf_get_slab_head(''A'','''|| :GLOBAL.PRINCIPAL||''')||'',''||sf_get_slab_head(''B'','''|| :GLOBAL.PRINCIPAL||''')||'',''||sf_get_slab_head(''C'','''|| :GLOBAL.PRINCIPAL||''')||'',''||sf_get_slab_head(''D'','''|| :GLOBAL.PRINCIPAL||''')||'',''||sf_get_slab_head(''E'','''|| :GLOBAL.PRINCIPAL||''')||'','' entire_string from dual
							    union all
							  	select rownum||'',''||tbl from (
									select 
								 (replace(region,'','','' '')||'',''||
							    replace(mul_dealer_cd||''-''||for_cd,'','','' '')||'',''||
								  replace(dealer_name,'','','' '')||'',''||
						      replace(loc_desc,'','','' '')||'',''||
						      replace(city,'','','' '')||'',''||
						      retail||'',''||EW1_Sale||'',''||EW2_Sale||'',''||Total_EW||'',''||EW_Pen||'',''||
						      EW11_Pen||'',''||Slab1||'',''||Slab2||'',''||Slab3||'',''||Slab4||'',''||Slab5||'',''||TOTAL_INC
						     )tbl
								  from VD_EW_INCE_DTL
								  where region like '||''''||:p_region_cd||''''||'
								 	and dealer_map_cd =DECODE(nvl('||''''||:P_DEALER||''''||',''99999''), ''99999'',dealer_map_cd,'||''''||:P_DEALER||''''||')
								 	and for_cd =DECODE(nvl('||''''||:P_CITY||''''||',''ALL''), ''ALL'',for_cd,'||''''||:P_CITY||''''||')
					        and	TRAN_MONTH= '||''''||:p_qtr_year||''''||'
								)'; --added by akanksha for multicompany change
					 	  
   
     :ck:=lv_query;
      view_excel_rep(lv_filename, lv_query, 'entire_string'); ---Commented by Aafaq on 26-08-2016---uncommented by Chandan ason 02-7-24
      --view_excel_report_new(:global.principal,lv_filename,lv_query,'entire_string',:parameter.p_app_id);---Commented by Chandan ason 02-7-24
      
end;
exception
  when others then
    null;
end;

--END;
```

#### SP-002 - POP_LIST_REGION

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Populates the `P_REGION_CD` list item on the form by refreshing the `RG_REGION` record group from the database, making the region filter drop-down ready for user selection when the form opens.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Execute `Populate_Group('RG_REGION')` to fetch the latest region data from the database into the pre-defined `RG_REGION` record group; the return code is stored in `errcode` (not evaluated further).
- Step 2 - Call `populate_list('P_REGION_CD', 'RG_REGION')` to synchronise the `P_REGION_CD` list item's visible entries with the freshly populated record group.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The region list is always sourced from the `RG_REGION` record group; the group is repopulated each time this procedure runs, ensuring the list reflects current database values.

---

**Implementation Logic**

```plsql
PROCEDURE POP_LIST_REGION IS
	errcode NUMBER;
begin	
  errcode := Populate_Group('RG_REGION');
  populate_list('P_REGION_CD', 'RG_REGION'); 	
end;

```

#### SP-003 - PR_PASS_PARAM

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Builds a URL-style parameter string for the `vr_tat_bshop_det` report by iterating over the report's registered parameters in ED_REPORTS, appending each current form item value in name=value format, and enforcing mandatory validation for the from-date parameter.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|-------|--------|---------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Calculate a default date range: set `Lv_frm_date` to three months prior to today and `Lv_to_date` to today, using DUAL. This occurs whether or not `:CB_BLK.APP_ID` equals `'vr_tat_bshop_det'`, as both branches of the `IF`/`ELSE` execute the same SELECT.
- Step 2 - Open a cursor (`c1`) over ED_REPORTS, selecting all parameter definitions for `app_id = 'vr_tat_bshop_det'` and the current principal, ordered by serial number.
- Step 3 - Loop over each parameter row returned by the cursor.
- Step 4 - For parameter `P_REGION_CD`: append `P_REGION_CD='<value>'` to `Lv_param`.
- Step 5 - For parameter `P_CITY`: append `P_CITY='<value>'` to `Lv_param`; if `:CB_BLK.P_CITY` is null, additionally append `P_CITY='ALL'`.
- Step 6 - For parameter `P_DEALER`: append `P_DEALER='<value>'` to `Lv_param`; if `:CB_BLK.P_DEALER` is null, additionally append `P_DEALER='99999'`.
- Step 7 - For parameter `P_PARENT`: append `P_PARENT='<value>'` to `Lv_param`; if `:CB_BLK.P_DEALER` is null, additionally append `P_PARENT='ALL'`.
- Step 8 - For parameter `P_LOC`: append `P_LOC='<value>'` to `Lv_param`; if `:CB_BLK.P_DEALER` is null, additionally append `P_LOC='ALL'`.
- Step 9 - For parameter `P_FROM_DT`: if `:P_FROM_DT` is NULL, display an alert (`AL_ERRINFO`) with message "Please Enter From Date", navigate to the `CB_BLK.P_FROM_DT` item, and raise `form_trigger_failure` to stop processing. Otherwise, append `P_FROM_DT='<value>'` to `Lv_param`.
- Step 10 - For parameter `P_TO_DT`: append `P_TO_DT='<value>'` to `Lv_param`.
- Step 11 - For parameter `P_REPO_TYPE`: append `P_REPO_TYPE='<value>'` to `Lv_param`.
- Step 12 - For parameter `P_DES_TYPE`: append `P_DES_TYPE='<value>'` to `Lv_param`.
- Step 13 - After the loop completes, return the fully assembled parameter string via `Lv_param`.

---

**Decision Points**

DP-001

Condition:
`:CB_BLK.APP_ID` equals `'vr_tat_bshop_det'`.

TRUE:
Execute the three-month lookback date query (identical logic in both branches - both paths produce the same result).

FALSE:
Execute the same three-month lookback date query (both branches are functionally equivalent).

DP-002

Condition:
`P_CITY` is the current parameter name in the cursor loop AND `:CB_BLK.P_CITY` is NULL.

TRUE:
Append the city value (NULL) and then also append `P_CITY='ALL'` as a secondary default entry.

FALSE:
Append only the city value as provided.

DP-003

Condition:
`P_DEALER` is the current parameter name AND `:CB_BLK.P_DEALER` is NULL.

TRUE:
Append the dealer value (NULL) and then also append `P_DEALER='99999'` as a sentinel default.

FALSE:
Append only the dealer value as provided.

DP-004

Condition:
`P_PARENT` is the current parameter name AND `:CB_BLK.P_DEALER` is NULL.

TRUE:
Append the parent value and then also append `P_PARENT='ALL'` as a default.

FALSE:
Append only the parent value as provided.

DP-005

Condition:
`P_LOC` is the current parameter name AND `:CB_BLK.P_DEALER` is NULL.

TRUE:
Append the location value and then also append `P_LOC='ALL'` as a default.

FALSE:
Append only the location value as provided.

DP-006

Condition:
`P_FROM_DT` is the current parameter name AND `:P_FROM_DT` is NULL.

TRUE:
Display the "Please Enter From Date" alert, set focus to the from-date field, and raise `form_trigger_failure` - no further parameters are appended.

FALSE:
Append `P_FROM_DT='<value>'` and continue the loop.

---

**Database Interactions**

- DB-001 - Read ED_REPORTS - retrieve the ordered list of parameter definitions (name, type, default value) registered for the `vr_tat_bshop_det` report and the current principal, to drive the parameter-building loop.
- DB-002 - Read DUAL - compute the default date range (three months back to today) used to initialise `Lv_frm_date` and `Lv_to_date`.

---

**Business Rules**

- SBR-001 - Parameters are always appended in the order defined by `serial_no` in ED_REPORTS, ensuring the report receives them in the correct sequence.
- SBR-002 - The parameter list is scoped to `app_id = 'vr_tat_bshop_det'` and the current principal (`GLOBAL.PRINCIPAL`), preventing cross-application or cross-company parameter leakage.
- SBR-003 - A NULL city value is supplemented with the sentinel string `'ALL'` so the downstream report can apply an "all cities" filter.
- SBR-004 - A NULL dealer value is supplemented with the sentinel value `'99999'` so the downstream report can apply an "all dealers" filter.
- SBR-005 - A NULL parent or location value when dealer is also NULL is supplemented with `'ALL'` as the default.
- SBR-006 - The from-date (`P_FROM_DT`) is mandatory; if not supplied, the procedure halts with a user-facing alert and navigation to the relevant field.

---

**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM (Lv_param IN OUT VARCHAR2)
IS
	cursor c1 is 
		select param_type,parameter_name,default_value,parameter_datatype
	    from ed_reports
		 --where  app_id = :CB_BLK.APP_ID
		 where  app_id = 'vr_tat_bshop_det'
		  AND principal_map_cd = :GLOBAL.PRINCIPAL --added by akanksha for multicompany change
		 order by to_number(serial_no);
	Lv_frm_date  DATE;
	Lv_to_date   DATE;	
	L_AlertID		 ALERT;
	L_Alert			 NUMBER;	
BEGIN
	IF 	:CB_BLK.APP_ID IN('vr_tat_bshop_det') THEN
		BEGIN
			SELECT ((Add_Months (Sysdate,(-1) *3))), SYSDATE 
			  INTO Lv_frm_date,Lv_to_date FROM DUAL;
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;   	
	ELSE	
		BEGIN	
			SELECT ((Add_Months (Sysdate,(-1) *3))), SYSDATE 
				INTO Lv_frm_date,Lv_to_date FROM DUAL;
		EXCEPTION WHEN OTHERS THEN
			NULL;
		END;
	END IF;
			
	For cur_val in c1 Loop		
			
	  if cur_val.parameter_name = 'P_REGION_CD'  then
  	   lv_param := lv_param||' '||'P_REGION_CD='''||:CB_BLK.P_REGION_CD||'''';
    end if;  
		if cur_val.parameter_name = 'P_CITY'  then
  	   lv_param := lv_param||' '||'P_CITY='''||:CB_BLK.P_CITY||'''';
		   if :CB_BLK.P_CITY is null then
			      lv_param := lv_param||' '||'P_CITY='''||'ALL'||'''';
			 end if;
    end if;
		if cur_val.parameter_name = 'P_DEALER'  then
  	   lv_param := lv_param||' '||'P_DEALER='''||:CB_BLK.P_DEALER||'''';
		   if :CB_BLK.P_DEALER is null then
			      lv_param := lv_param||' '||'P_DEALER='''||99999||'''';
			 end if;  	   
    end if;

	

		if cur_val.parameter_name = 'P_PARENT'  then
  	   lv_param := lv_param||' '||'P_PARENT='''||:CB_BLK.P_PARENT||'''';
		   if :CB_BLK.P_DEALER is null then
			      lv_param := lv_param||' '||'P_PARENT='''||'ALL'||'''';
			 end if;  	   
	 end if;
				
		if cur_val.parameter_name = 'P_LOC'  then
  	   lv_param := lv_param||' '||'P_LOC='''||:CB_BLK.P_LOC||'''';
		   if :CB_BLK.P_DEALER is null then
			      lv_param := lv_param||' '||'P_LOC='''||'ALL'||'''';
			 end if;  	   
	  end if;

		if cur_val.parameter_name = 'P_FROM_DT'  then
			if :P_FROM_DT IS NULL THEN
		     L_AlertID := Find_Alert('AL_ERRINFO');
		  	 Set_Alert_Property(L_AlertID,Alert_Message_Text,'Please Enter From Date');
		  	 L_Alert	 := Show_Alert(L_AlertID);
		  	 Go_Item('CB_BLK.P_FROM_DT');
		  	 RAISE form_trigger_failure;
			end if;  	 		
  	   lv_param := lv_param||' '||'P_FROM_DT='''||:P_FROM_DT||''''; 
		end if;
		
		if cur_val.parameter_name = 'P_TO_DT'  then
  	   lv_param := lv_param||' '||'P_TO_DT='''||:P_TO_DT||''''; 
		end if;

		if cur_val.parameter_name = 'P_REPO_TYPE'  then
  	   lv_param := lv_param||' '||'P_REPO_TYPE='''||:P_REPO_TYPE||''''; 
		end if;

		if cur_val.parameter_name = 'P_DES_TYPE'  then
  	   lv_param := lv_param||' '||'P_DES_TYPE='''||:P_DES_TYPE||''''; 
		end if;
	End Loop;	
END;

```

#### SP-004 - PR_REMOVE_ASCII_CHR

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Reads a server-side report file line by line, filters out any lines beginning with the ASCII form-feed character (CHR(12)), writes the clean lines to a new output file, and then opens the output file in a new browser window so the user can download an Excel-compatible CSV free of special characters.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| p_filename | VARCHAR2 | IN |
| p_filename1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)
- WEBUTIL.FCLOSE ([SP-010](#SP-010--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-011](#SP-011--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-014](#SP-014--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-016](#SP-016--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Open the source report file at `/iashome/ias/reports/printer/<p_filename>` in read (`'r'`) mode.
- Step 2 - Open the destination output file at `/iashome/ias/reports/printer/<p_filename1>` in write (`'w'`) mode.
- Step 3 - Initialise the line counter `v_cnt` to 1.
- Step 4 - Begin an infinite loop, reading one line at a time from the source file into `linebuf`.
- Step 5 - For each line where the counter is 1 or greater, check whether the first character of the line is CHR(12) (form-feed); if it is not CHR(12), write the line to the output file.
- Step 6 - If `NO_DATA_FOUND` is raised (end of file reached), exit the loop cleanly; any other exception also exits the loop.
- Step 7 - Increment the line counter after each iteration.
- Step 8 - After the loop, close both the source and the output files.
- Step 9 - Construct the web-accessible path for the output file as `/printer/<p_filename1>` and display it in a new browser window (`_blank`) via `web.show_document`.
- Step 10 - If an unhandled exception occurs at the outer level, display the SQL error code and message using `general.disp_text` with the title `'Note'`.

---

**Decision Points**

DP-001

Condition:
The first character of the current line (`SUBSTR(linebuf, 1, 1)`) is not CHR(12) (form-feed).

TRUE:
Write the line to the output file.

FALSE:
Skip the line - it is not written to the output file.

DP-002

Condition:
`NO_DATA_FOUND` or any other exception is raised during `text_io.get_line`.

TRUE:
Exit the read loop immediately.

FALSE:
Continue to the next iteration.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Lines whose first character is the form-feed control character (CHR(12)) are excluded from the output file; all other lines are copied as-is.
- SBR-002 - Both the source and destination files reside under the fixed server path `/iashome/ias/reports/printer/`.
- SBR-003 - The output file is always served to the browser via the `/printer/` virtual path, making it directly accessible for download.
- SBR-004 - Any exception encountered during inner loop processing silently exits the loop without surfacing an error to the user, but outer-level exceptions are reported via `general.disp_text`.

---

**Implementation Logic**

```plsql
---Procedure to generate Excel report without Special Characters
Procedure pr_remove_ascii_chr (p_filename IN VARCHAR2, p_filename1 IN VARCHAR2)
IS
   in_file     text_io.file_type;
   out_file    text_io.file_type;
   linebuf     VARCHAR2 (5000);
   filename    VARCHAR2 (300);
   filename1   VARCHAR2 (300);
   v_cnt       NUMBER (10)       := 0;
BEGIN

   in_file := text_io.fopen ('/iashome/ias/reports/printer/' || p_filename, 'r');
   filename1 := p_filename1;
   out_file := text_io.fopen ('/iashome/ias/reports/printer/' || filename1, 'w');
   v_cnt := 1;
---Writing from one file to another file line by line  
   LOOP
      BEGIN
         text_io.get_line (in_file, linebuf);

         IF v_cnt >= 1
         THEN
            IF SUBSTR (linebuf, 1, 1) <> CHR (12)
            THEN
               text_io.put_line (out_file, linebuf);
            END IF;
         END IF;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            EXIT;
         WHEN OTHERS
         THEN
            EXIT;
      END;

      v_cnt := v_cnt + 1;
   END LOOP;
---Closing file
   text_io.fclose (in_file);
   text_io.fclose (out_file);
   
   filename := '/printer/' || filename1;
   web.show_document (filename, '_blank');
EXCEPTION
   WHEN OTHERS
   THEN
      general.disp_text ('Exception' || SQLCODE || SQLERRM, 'Note');
END;
```

#### SP-005 - VIEW_EXCEL_REP

**Invoked From:**

- vr_penetrate_fmb.xml [ProgramUnit: EXCEL_REPORT]
- vr_penetrate_fmb.xml [StoredProcedure: EXCEL_REPORT]

---

**Screen:**

N/A

---

**Purpose**

Executes a supplied SQL query via a Forms record group, writes each result row to a server-side CSV file, and then opens that file in a new browser window so the user can save or view the Excel-compatible report.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-015](#SP-015--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Derive the output filename by concatenating the current user ID with a timestamp (`YYYYMMDDHHMISS`) and appending `.csv`; if the derived filename is not null, assign it to the `FILENAME` variable.
- Step 2 - Check whether `FILENAME` contains a space anywhere in its path; if so, strip the path and relocate the file to the `C:\` root drive, then display a warning message to the user.
- Step 3 - Attempt to find an existing record group named `DataRecordSet`; if found (`NOT Id_Null`), delete it so it can be recreated cleanly.
- Step 4 - Create a new record group named `DataRecordSet` from the supplied `p_query`.
- Step 5 - Populate the record group and obtain the total row count.
- Step 6 - If the row count exceeds 65,536 rows, display a truncation warning to the user and cap the row count at 65,535.
- Step 7 - Build the server-side file path under `/iashome/ias/reports/printer/` using only the filename portion of `FILENAME`.
- Step 8 - Open and read the URL path configuration file `/reports/DMS/excelpath.txt` to obtain the web-accessible base path (`urlPath`), then close that configuration file.
- Step 9 - Construct the full web-accessible path (`formserverpath`) by concatenating `urlPath` with the filename portion.
- Step 10 - Open the server-side output file for writing.
- Step 11 - Locate the specified column (`p_column_name`) within the record group.
- Step 12 - Iterate over every row (up to the capped row count), read each cell value from the record group column, and write it as a line to the output file.
- Step 13 - Close the output file.
- Step 14 - Open the generated file in a new browser window (`_blank`) using `web.show_document`.
- Step 15 - If any exception occurs, display the Oracle error code and text to the user and raise a form trigger failure.

---

**Decision Points**

DP-001

Condition:
The derived `vcFile` (filename) value is NULL.

TRUE:
No filename assignment is made; `FILENAME` retains its prior value (NULL).

FALSE:
Assign `vcFile` to `FILENAME`.

DP-002

Condition:
`FILENAME` contains a space character anywhere in the string (`INSTR(FILENAME,' ') > 0`).

TRUE:
Strip the path and reset `FILENAME` to `C:\<bare filename only>`, and display a warning message to the user that the file will be saved to the C drive.

FALSE:
Continue using the original `FILENAME` value unchanged.

DP-003

Condition:
A record group named `DataRecordSet` already exists (`NOT Id_Null(rg_id)`).

TRUE:
Delete the existing group before recreating it, to ensure a clean state.

FALSE:
Skip the deletion and proceed directly to creating the new group.

DP-004

Condition:
The row count returned by `Get_Group_Row_Count` exceeds 65,536.

TRUE:
Display a truncation warning and cap processing at 65,535 rows.

FALSE:
Use the actual row count for file generation.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The output filename is always based on the current user ID and execution timestamp; the `p_file_name` input parameter is accepted but overridden by the internally derived filename.
- SBR-002 - A file path containing spaces cannot be used; the system automatically falls back to the `C:\` root and notifies the user.
- SBR-003 - The maximum number of rows that can be exported to a single CSV file is 65,535; rows beyond that limit are silently truncated after a warning is displayed.
- SBR-004 - The web-accessible path for the generated file is not hard-coded but read at runtime from the configuration file `/reports/DMS/excelpath.txt`, making the deployment path configurable.
- SBR-005 - On any unhandled exception, the procedure raises `Form_trigger_failure`, preventing silent failure and ensuring the calling trigger is notified of the error.

---

**Implementation Logic**

```plsql
PROCEDURE view_excel_rep(p_file_name VARCHAR2 DEFAULT NULL, 
 												 p_query VARCHAR2,
 												 p_column_name VARCHAR2) 
IS	
  rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	urlFile1        TEXT_IO.FILE_TYPE;
	the_rowcount 		 		NUMBER;
	po_err_msg    VARCHAR2 (3000);
	po_err_cd     NUMBER (10);
	low           NUMBER (10);
	high          NUMBER (10);
	remainder     NUMBER (10);

	vcfile varchar2(150);
	lv_user  varchar2(150);
	v_string varchar2(5000);
	bin_str varchar2(250);
	errcode 				 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);

begin
	lv_user := name_in(':global.userid'); 
	vcFile:= lv_user||To_Char(Sysdate,'YYYYMMDDHHMISS'); 
	vcFile := vcFile||'.csv';

	if vcFile is null then
		null;
	else
		filename:=vcFile;
	end if;
	
	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
	end if;

	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	
	IF the_rowcount > 65536 THEN  
		Message('Maximum number of rows in excel exceeded. It will truncate to 65535 rows.');
		Message('  ');
		CLEAR_MESSAGE;
		the_rowcount := 65535;
	END IF;
--message('1 '||filename);	
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
--message('2 '||server_file);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
--message('3');	
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
--message('4');	
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
--message('5');	
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
--message('6');
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop ); 
	  	text_io.put_line(myfile,v_string);
	end loop;
    text_io.fclose(myfile);   
	 	web.show_document(formserverpath,'_blank');
--message('7');
exception when others then
		Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
		Raise Form_trigger_failure;
end;

```

#### SP-006 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: FT_CANCEL]
- vr_penetrate_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Presents a configurable confirmation dialog to the user via the `AL_CONFIRM` alert and returns a numeric indicator of the user's choice, so that calling triggers can determine whether the user confirmed or declined a potentially destructive action such as cancellation or deletion.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the message text of the `AL_CONFIRM` alert to the supplied `confirm_msg` text.
- Step 2 - Display the `AL_CONFIRM` alert to the user and capture which button was pressed.
- Step 3 - If the user pressed the first alert button (`ALERT_BUTTON1`), return `1` to signal confirmation.
- Step 4 - If the user pressed any other button, return `0` to signal that the action was not confirmed.

---

**Decision Points**

DP-001

Condition:
The button pressed by the user is `ALERT_BUTTON1` (the first/primary confirmation button).

TRUE:
Return `1` to the caller, indicating the user confirmed the action.

FALSE:
Return `0` to the caller, indicating the user declined the action.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The confirmation dialog always uses the fixed alert named `AL_CONFIRM`; the caller supplies only the message text, not the alert itself.
- SBR-002 - Only `ALERT_BUTTON1` is treated as a positive confirmation; any other button press (e.g. Cancel or No) is treated as a rejection and returns `0`.

---

**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-007 - GENERAL.DISP_TEXT

**Invoked From:**

- vr_penetrate_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_penetrate_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]
- vr_penetrate_fmb.xml [Trigger: FT_INSERT]
- vr_penetrate_fmb.xml [Trigger: KEY-NEXT-ITEM]
- vr_penetrate_fmb.xml [Trigger: ON-ERROR]
- vr_penetrate_fmb.xml [Trigger: ON-MESSAGE]
- vr_penetrate_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_penetrate_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a message to the user in a modal alert dialog, selecting either an error-style alert (`AL_ERRINFO`) or a note-style alert (`AL_NOTE`) based on the supplied title, so that all form-level notifications use a consistent, titled message box.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the `title_string` parameter: if its upper-case value equals `'ERROR'`, select the alert name `AL_ERRINFO`; otherwise, select `AL_NOTE`.
- Step 2 - Set the title of the chosen alert to `title_string`.
- Step 3 - Set the message body of the chosen alert to `text_string`.
- Step 4 - Display the alert to the user and capture the user's response in `p_alert_id`.

---

**Decision Points**

DP-001

Condition:
`UPPER(title_string)` equals `'ERROR'`.

TRUE:
Use the `AL_ERRINFO` alert template for display.

FALSE:
Use the `AL_NOTE` alert template for display.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The alert selection is case-insensitive for the title value `'ERROR'`; any other title (regardless of case) routes to the `AL_NOTE` alert.
- SBR-002 - Both the alert title and the message text are set dynamically at runtime from the supplied parameters, so a single procedure serves all notification scenarios across the form.

---

**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-008 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_penetrate_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Receives a message code, composes a display message by appending any retrieved message text, and routes the message to the appropriate user-facing dialog with a severity-specific title (`Error`, `Note`, or `Caution`) via `GENERAL.DISP_TEXT`; for error-severity messages the procedure additionally raises `FORM_TRIGGER_FAILURE` to halt the current form operation.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Compose the display message text by concatenating `mesg_code`, the literal `' : '`, and the local variable `mesg_text` (note: the `GENERAL.get_message` call that would populate `mesg_text` is commented out, so `mesg_text` remains uninitialised/null at runtime).
- Step 2 - Evaluate `mesg_type` to determine message severity and routing.
- Step 3 - If `mesg_type` is `'E'` (Error), set the title to `'Error'`, call `GENERAL.DISP_TEXT` to display the message, then raise `FORM_TRIGGER_FAILURE` to abort the current form operation.
- Step 4 - If `mesg_type` is `'N'` (Note), set the title to `'Note'` and call `GENERAL.DISP_TEXT` to display the message; processing continues normally.
- Step 5 - If `mesg_type` is `'C'` (Caution), set the title to `'Caution'` and call `GENERAL.DISP_TEXT` to display the message; processing continues normally.

---

**Decision Points**

DP-001

Condition:
`mesg_type` equals `'E'` (Error severity).

TRUE:
Display the message with the title `'Error'` via `GENERAL.DISP_TEXT` and raise `FORM_TRIGGER_FAILURE` to stop the current form operation.

FALSE:
Proceed to evaluate the next severity branch.

DP-002

Condition:
`mesg_type` equals `'N'` (Note severity).

TRUE:
Display the message with the title `'Note'` via `GENERAL.DISP_TEXT`; the form operation is not interrupted.

FALSE:
Proceed to evaluate the next severity branch.

DP-003

Condition:
`mesg_type` equals `'C'` (Caution severity).

TRUE:
Display the message with the title `'Caution'` via `GENERAL.DISP_TEXT`; the form operation is not interrupted.

FALSE:
No branch matches; no display or error-raising action is performed.

---

**Database Interactions**

- DB-001 - Read am_permissions - queried by the commented-out `check_rights` procedure (inactive code - this SELECT is inside a block delimited by `/* ... */` and does not execute at runtime) to verify whether a user's access string grants permission for a given form.

---

**Business Rules**

- SBR-001 - Only `mesg_type` values of `'E'`, `'N'`, and `'C'` result in a message being displayed; any other value causes the procedure to exit silently without displaying a message or raising an error.
- SBR-002 - Error-severity messages (`mesg_type = 'E'`) always raise `FORM_TRIGGER_FAILURE` after display, ensuring the form operation is halted; note and caution messages do not interrupt processing.
- SBR-003 - The `GENERAL.get_message` lookup that would populate `mesg_text` from the message code is commented out; consequently `mesg_text` is always null at runtime and the displayed text consists of `mesg_code` followed by `' : '` only.

---

**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-009 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user, using a pre-registered Oracle Forms alert dialog when one is available, or falling back to the Forms `MESSAGE` built-in when the alert has not been registered. This procedure is specifically used to surface bean-not-registered and bean-not-found errors that arise within the WebUtil layer.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-015](#SP-015--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level alert handle `m_errorAlert` is initialised by calling `ID_NULL`.
- Step 2 - If the alert handle is valid, set the alert's message text property to the supplied error text (`errText`) and display the alert to the user via `SHOW_ALERT`.
- Step 3 - If the alert handle is null (i.e. the alert has not been registered), fall back to displaying the error using the Forms `MESSAGE` built-in, prefixing the text with the literal `'WebUtil Error: '`.

---

**Decision Points**

DP-001

Condition:
The module-level alert handle `m_errorAlert` is not null (i.e. the WebUtil error alert has been registered and is available).

TRUE:
Set the alert's message text to `errText` and display the alert dialog to the user.

FALSE:
Display the error using the Forms `MESSAGE` built-in with the prefix `'WebUtil Error: '` concatenated to `errText`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Error messages are always prefixed with the label `'WebUtil Error'` to distinguish WebUtil-layer failures from other application errors, regardless of which display mechanism is used.
- SBR-002 - The alert-based display path is used only when the error alert handle `m_errorAlert` has been successfully initialised; the `MESSAGE` built-in is the guaranteed fallback to ensure the error is always surfaced to the user.

---

**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-010 - WEBUTIL.FCLOSE

**Invoked From:**

- vr_penetrate_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open WebUtil client-side text file by sending a close request to the WebUtil Java bean and nullifying the internal file handle, so that the file resource is properly released after writing is complete.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN OUT |

**Output Parameters**

| Output | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the file handle (`file.handle`) is not NULL, indicating the file is currently open.
- Step 2 - If open, send a close instruction to the WebUtil Java bean via `WebUtil_Core.setProperty` with the `WUF_TEXTIO_CLOSE` property.
- Step 3 - Set `file.handle` to NULL to mark the handle as released.
- Step 4 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED` exception), display an error alert and raise `TOOL_ERR.TOOL_ERROR`.
- Step 5 - If a property error occurs (`PROPERTY_ERROR`), raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
`file.handle` is not NULL (the file is currently open).

TRUE:
Send the close instruction to the WebUtil bean and set the handle to NULL.

FALSE:
Skip the close operation entirely - the file is already in a closed state.

DP-002

Condition:
The WebUtil bean is not registered at the time of the close call.

TRUE:
Display an error alert identifying the missing bean and raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Proceed normally; the property-set completes successfully.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A file with a NULL handle is treated as already closed; no close request is sent to the WebUtil bean in that case.
- SBR-002 - After a successful close, the handle is always set to NULL, preventing any subsequent operations on the same handle from inadvertently re-using it.

---

**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-011 - WEBUTIL.FOPEN

**Invoked From:**

- vr_penetrate_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file via the WebUtil Java bean using the specified file path and access mode, returning a file handle that callers use for subsequent read or write operations.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that `filemode` is one of the allowed values (`'r'`, `'w'`, or `'a'`); if not, raise `TOOL_ERR.TOOL_ERROR` immediately.
- Step 2 - Validate that `spec` is not NULL and not empty; if it is, raise `TOOL_ERR.TOOL_ERROR` immediately.
- Step 3 - Pass the filename (`spec`), file mode, and character set to the WebUtil bean via `WebUtil_Core.setProperty`, setting all three as synchronous calls.
- Step 4 - If `charSet` is NULL, pass the literal string `'(null)'` as the character set value to the bean; otherwise, pass the supplied `charSet` value.
- Step 5 - Request the WebUtil bean to open the file by reading the `WUF_TEXTIO_OPEN` property; capture the returned Java handle string in `javaHandle`.
- Step 6 - If `javaHandle` is NULL, empty, or equals `'-1'`, the file was not opened; raise `TOOL_ERR.TOOL_ERROR`.
- Step 7 - Convert `javaHandle` to a number and store it in `clientFile.handle`; return `clientFile` to the caller.
- Step 8 - On `BEAN_NOT_REGISTERED`, display an error alert and raise `TOOL_ERR.TOOL_ERROR`.
- Step 9 - On `PROPERTY_ERROR`, re-raise the exception.
- Step 10 - On `VALUE_ERROR` (e.g., handle conversion failure) or `TOOL_ERR.TOOL_ERROR`, re-raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
`filemode` (lowercased) is one of `'r'`, `'w'`, or `'a'`.

TRUE:
Proceed to validate the filename.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately - no file open attempt is made.

DP-002

Condition:
`spec` is NULL or an empty string.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` - no file can be opened without a valid path.

FALSE:
Proceed to configure the WebUtil bean properties.

DP-003

Condition:
`charSet` is NULL.

TRUE:
Pass the literal `'(null)'` as the character set value to the bean, indicating the platform default.

FALSE:
Pass the caller-supplied `charSet` value to the bean.

DP-004

Condition:
The Java handle returned by the bean (`javaHandle`) is NULL, empty, or `'-1'`.

TRUE:
The file could not be opened; raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Convert the handle to a number and return it as the file reference.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Only the access modes `'r'` (read), `'w'` (write), and `'a'` (append) are accepted; any other value immediately aborts the operation.
- SBR-002 - A file path (`spec`) is mandatory; a NULL or empty path is rejected before any communication with the WebUtil bean occurs.
- SBR-003 - A Java handle of NULL, empty string, or `'-1'` is treated as a failed open; the caller receives an error rather than an unusable handle.

---

**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-012 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs and returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the configured Java root path constant (`WEBUTIL_JAVA_ROOT`) with the package-specific class suffix stored in the `m_implClasses` array. This resolved class name is used by callers to identify or report the Java bean associated with a particular WebUtil package.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Look up the implementation class suffix for the supplied `packageID` from the `m_implClasses` associative array.
- Step 2 - Prepend the constant `WEBUTIL_JAVA_ROOT` to the retrieved suffix to form the fully qualified Java class name.
- Step 3 - Return the concatenated fully qualified class name to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The fully qualified Java class name is always constructed by concatenating the shared `WEBUTIL_JAVA_ROOT` root path with the per-package class suffix; no alternative naming convention is applied.

---

**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-013 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property on the client JVM by delegating to `java.lang.System.getProperty` via the Oracle Forms JNI bridge. This allows the form to read runtime environment properties (such as OS name, Java version, or custom system settings) directly from the client machine.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list of size 1.
- Step 2 - Add the property name (`a0`) as a String argument to the argument list.
- Step 3 - Invoke the static Java method `java.lang.System.getProperty(String)` via the JNI bridge, passing the constructed argument list.
- Step 4 - Return the String result (the property value) to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The property lookup is performed on the client JVM via the JNI bridge using the exact property name supplied in `a0`; no name transformation or defaulting is applied within this function.

---

**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-014 - WEBUTIL.GET_LINE

**Invoked From:**

- vr_penetrate_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line from an open WebUtil client-side text file by instructing the WebUtil Java bean to retrieve the line, detecting end-of-file via a sentinel newline, and returning the line content to the caller through an OUT parameter.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN |

**Output Parameters**

| Output | Source | Datatype |
|-------|--------|---------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-009](#SP-009--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-012](#SP-012--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-013](#SP-013--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-017](#SP-017--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Pass the file handle (`file.handle`) to the WebUtil bean via `WebUtil_Core.setProperty` with the `WUF_TEXTIO_HANDLE` property.
- Step 2 - Request the next line from the bean by reading the `WUF_TEXTIO_GETLINE` property; capture the result in the local `buffer` variable.
- Step 3 - Check whether `buffer` equals `CHR(10)` (a bare newline), which the WebUtil PJC uses as an end-of-file sentinel.
- Step 4 - If the buffer is the sentinel value, raise `NO_DATA_FOUND` to signal end-of-file to the caller.
- Step 5 - Otherwise, assign `buffer` to the OUT parameter `item` and return normally.
- Step 6 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED`), display an error alert and raise `TOOL_ERR.TOOL_ERROR`.
- Step 7 - If a property error occurs (`PROPERTY_ERROR`), raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
The value returned by the WebUtil bean (`buffer`) equals `CHR(10)` (bare newline sentinel).

TRUE:
Raise `NO_DATA_FOUND` to indicate end-of-file - `item` is not assigned.

FALSE:
Assign `buffer` to `item` and return the line to the caller.

DP-002

Condition:
The WebUtil bean is not registered at the time of the call.

TRUE:
Display an error alert identifying the missing bean and raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Continue normally with the bean interaction.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - End-of-file is signalled by the PJC placing a bare `CHR(10)` newline into the read buffer; this value can never be returned as actual line content because the PJC normally strips newlines as line terminators.
- SBR-002 - On end-of-file, `NO_DATA_FOUND` is raised rather than returning a NULL or empty string, conforming to the standard Oracle TEXT_IO end-of-file convention expected by callers such as `PR_REMOVE_ASCII_CHR`.

---

**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-015 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_penetrate_fmb.xml [StoredProcedure: VIEW_EXCEL_REP]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil file handle is uninitialised (null), returning TRUE if the handle carries no value so callers can safely check handle validity before attempting file operations.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the `hnd` attribute of the supplied `handle` pointer.
- Step 2 - If `hnd` is NULL, return TRUE (the handle is null/uninitialised).
- Step 3 - Otherwise, return FALSE (the handle is valid and non-null).

---

**Decision Points**

DP-001

Condition:
The `hnd` attribute of the supplied handle is NULL.

TRUE:
Return TRUE - the handle represents no open resource.

FALSE:
Return FALSE - the handle references an active resource.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A handle is considered null solely by inspecting whether its internal `hnd` attribute is NULL; no other attribute or state is evaluated.

---

**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-016 - WEBUTIL.PUT_LINE

**Invoked From:**

- vr_penetrate_fmb.xml [StoredProcedure: PR_REMOVE_ASCII_CHR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side text file by configuring the file handle, the text content, and a newline flag as Java system properties on the WebUtil file-I/O bean, and then raises a descriptive error if the required bean is unavailable or the property write fails.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` bean to the file handle value from the supplied `file` parameter, directing subsequent operations to the correct open file.
- Step 2 - Set the `WUF_TEXTIO_PUT` property on the `WUF_PACKAGE` bean to the text `item` to be written.
- Step 3 - Set the `WUF_TEXTIO_NEWLINE` property on the `WUF_PACKAGE` bean to `1`, instructing the bean to append a newline character after the written text.
- Step 4 - If a `BEAN_NOT_REGISTERED` exception is raised during any of the above steps, display an error alert identifying the missing bean class (via `getImplClass`) with the message that `CLIENT_TEXT_IO.put_line` will not work, then raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation.
- Step 5 - If a `PROPERTY_ERROR` exception is raised, raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation without additional messaging.

---

**Decision Points**

DP-001

Condition:
A `BEAN_NOT_REGISTERED` exception is raised when attempting to set properties on the `WUF_PACKAGE` bean.

TRUE:
Display an error alert naming the missing Java bean class and stating that `CLIENT_TEXT_IO.put_line` will not work, then raise `TOOL_ERR.TOOL_ERROR` to halt processing.

FALSE:
Continue to the next property-set call (no exception, normal flow proceeds).

DP-002

Condition:
A `PROPERTY_ERROR` exception is raised when attempting to set a property on the `WUF_PACKAGE` bean.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` to halt processing.

FALSE:
Property setting succeeded; normal flow continues.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A line written to a client-side file is always terminated with a newline; the `WUF_TEXTIO_NEWLINE` property is unconditionally set to `1` on every call.
- SBR-002 - If the required WebUtil file-I/O bean is not registered on the client, the operation is immediately aborted with a user-visible error identifying the missing bean, and a `TOOL_ERROR` is raised to the caller.
- SBR-003 - A property-write failure (`PROPERTY_ERROR`) also aborts the operation by raising `TOOL_ERROR`, preventing partial or silent file-write failures.

---

**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-017 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property to a specified value on the client JVM by delegating to `java.lang.System.setProperty` via the Oracle Forms JNI bridge. This enables the form to configure or modify client-side runtime environment properties and to pass property-based control values to WebUtil Java beans.

---

**Input Parameters**

| Input | Source | Datatype |
|-------|--------|---------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list of size 2.
- Step 2 - Add the property name (`a0`) as the first String argument to the argument list.
- Step 3 - Add the property value (`a1`) as the second String argument to the argument list.
- Step 4 - Invoke the static Java method `java.lang.System.setProperty(String, String)` via the JNI bridge, passing the constructed argument list.
- Step 5 - Return the previous value of the property (as returned by `System.setProperty`) to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Both the property name (`a0`) and new value (`a1`) are passed unmodified to the Java `System.setProperty` call; no validation or transformation is applied within this function.

---

**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

---

# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
    - Requirement ID: BR-023
    - Requirement ID: BR-024
    - Requirement ID: BR-025
    - Requirement ID: BR-026
    - Requirement ID: BR-027
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Suggested Order Quantity - PT_SOQ_MUL_NEW (via B_SOQ)
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - SOQ Calculation Parameters (Dealership User - before running SOQ)
    - Location Selection (Dealership User - before running SOQ)
    - SOQ Results - Amended Quantities (Dealership User - after SOQ query)
    - PO Details (Dealership User - after reviewing SOQ, before generating PO)
    - Print Parameters (Dealership User - when printing SOQ report)
    - Session and Non-Database Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
    - B_SOQ (18 columns)
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL (attached library DPL)
    - DBMS_APPLICATION_INFO (Oracle built-in package)
    - DEALER_LOC (form-level package)
    - FETCH_LOC (form program unit)
    - GET_LAST_SOQ_DATE (form program unit)
    - BUILD_WHERE (form program unit)
    - LOC_CATEG_POPULATION (form program unit)
    - UPDATE_PO_STOCK (form program unit)
    - SORT_BLOCK (form program unit)
    - VIEW_EXCEL_REP (form program unit)
    - SF_COPYRIGHT_DECLARATION (standalone function)
    - SF_PRINCIPAL_MAP_CD (standalone function)
    - SP_CALCULATE_SOQ_NEW (standalone procedure)
    - SP_GET_CONSUMPTION (standalone procedure)
    - SP_SOQ_POPULATE_CONSUMPTION (standalone procedure)
    - SP_INSERT_PM_PART_VAR (standalone procedure)
    - SP_UPDATE_PART_PRICE (standalone procedure)
    - SP_UPDATE_PO_NUMBER_NEW (standalone procedure)
    - VIEW_EXCEL_REPORT_NEW (standalone procedure)
    - PK_VALIDATE_PARTS (external package)
    - WEBUTIL_CORE (WebUtil library package)
    - WEBUTIL_C_API (WebUtil library package)
    - WEB (Oracle Forms built-in package)
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
  - webutil.pld (`WEBUTIL_FILE`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_FILE_TRANSFER`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_HOST`)
  - Inactive / commented-only PLD call sites
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - BUILD_WHERE
    - SP-002 - FETCH_LOC
    - SP-003 - GET_LAST_SOQ_DATE
    - SP-004 - LOC_CATEG_POPULATION
    - SP-005 - SORT_BLOCK
    - SP-006 - UPDATE_PO_STOCK
    - SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-008 - D2KWUTIL.CHOOSEFILE
    - SP-009 - D2KWUTIL.CREATED_DATE
    - SP-010 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-011 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-012 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-013 - D2KWUTIL.D2KWUTIL_FILEINFO
    - SP-014 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-015 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-016 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-017 - D2KWUTIL.FILE_INFO
    - SP-018 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-019 - D2KWUTIL.SAVE_FILE
    - SP-020 - D2KWUTIL.TRANSLATETYPE
    - SP-021 - GENERAL.ASK_CONFIRM
    - SP-022 - GENERAL.CHECK_FORM_FAILURE
    - SP-023 - GENERAL.CHECK_NULL
    - SP-024 - GENERAL.DISP_TEXT
    - SP-025 - GENERAL.L_POP_LIST_ITEM
    - SP-026 - GENERAL.RAISE_ERROR
    - SP-027 - PK_VALIDATE_PARTS.UPDATE_ON_ORDER
    - SP-028 - WEBUTIL.BLOCKING
    - SP-029 - WEBUTIL.CHECKLIBS
    - SP-030 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-031 - WEBUTIL.CLOSEBLOB
    - SP-032 - WEBUTIL.CLOSEFILE
    - SP-033 - WEBUTIL.DOWNLOADFROMURL
    - SP-034 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-035 - WEBUTIL.ERROR
    - SP-036 - WEBUTIL.ERRORALERT
    - SP-037 - WEBUTIL.EXECUTE
    - SP-038 - WEBUTIL.FCLOSE
    - SP-039 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-040 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-041 - WEBUTIL.FOPEN
    - SP-042 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-043 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-044 - WEBUTIL.GETCLIENTSETTING
    - SP-045 - WEBUTIL.GETIMPLCLASS
    - SP-046 - WEBUTIL.GETLASTERROR
    - SP-047 - WEBUTIL.GETLASTERRORARGS
    - SP-048 - WEBUTIL.GETNUMBER
    - SP-049 - WEBUTIL.GETOSFAMILY
    - SP-050 - WEBUTIL.GETOUTPUT
    - SP-051 - WEBUTIL.GETPROPERTY
    - SP-052 - WEBUTIL.GETSTRING
    - SP-053 - WEBUTIL.GETVAR
    - SP-054 - WEBUTIL.GET_LINE
    - SP-055 - WEBUTIL.GET_RETURN_CODE
    - SP-056 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-057 - WEBUTIL.HOST
    - SP-058 - WEBUTIL.ID_NULL
    - SP-059 - WEBUTIL.INIT
    - SP-060 - WEBUTIL.INITWEBUTIL
    - SP-061 - WEBUTIL.ISERROR
    - SP-062 - WEBUTIL.IS_OPEN
    - SP-063 - WEBUTIL.LENGTH
    - SP-064 - WEBUTIL.LOG
    - SP-065 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-066 - WEBUTIL.PUTF
    - SP-067 - WEBUTIL.PUT_LINE
    - SP-068 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-069 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-070 - WEBUTIL.REGISTERBEAN
    - SP-071 - WEBUTIL.REGISTER_FUNCTION
    - SP-072 - WEBUTIL.RELEASE_PROCESS
    - SP-073 - WEBUTIL.SETCLIENTSETTING
    - SP-074 - WEBUTIL.SETDATA
    - SP-075 - WEBUTIL.SETPROPERTY
    - SP-076 - WEBUTIL.SHOWBEANS
    - SP-077 - WEBUTIL.URL_TO_CLIENT
    - SP-078 - WEBUTIL.WRITEDATA
    - SP-079 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-080 - ADD_ERROR
    - SP-081 - ADD_EXTERNAL_ERRORS
    - SP-082 - BOOLTOCHAR
    - SP-083 - CLEAN_ERROR_STACK
    - SP-084 - DEBUGLOG
    - SP-085 - GET_ENVIRONMENT_STRING
    - SP-086 - GET_TEMP_DIRECTORY
    - SP-087 - GET_WINDOWS_DIRECTORY
    - SP-088 - READ_REGISTRY
    - SP-089 - REGISTER_FUNCTION_CALL
    - SP-090 - SETDEBUG
    - SP-091 - SF_COPYRIGHT_DECLARATION
    - SP-092 - SF_PRINCIPAL_MAP_CD
    - SP-093 - SP_CALCULATE_SOQ_NEW
    - SP-094 - SP_GET_CONSUMPTION
    - SP-095 - SP_INSERT_PM_PART_VAR
    - SP-096 - SP_SOQ_POPULATE_CONSUMPTION
    - SP-097 - SP_UPDATE_PART_PRICE
    - SP-098 - SP_UPDATE_PO_NUMBER_NEW
    - SP-099 - STRIPDIRSEP
    - SP-100 - VIEW_EXCEL_REPORT_NEW
    - SP-101 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | PT_SOQ_NEW - Business Requirements Document |
| Form Module Name | PT_SOQ_NEW |
| Document Version | 1.0 |
| Date Created | August 07, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 07, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the pt_soq_new Suggested Order Quantity / Re-Order Processing form, its purpose, and roles referenced in the module.*

The **pt_soq_new** Oracle Forms module is the dealership **Suggested Order Quantity (SOQ) and Re-Order Processing** screen. A parts manager opens the screen, selects the parts category and ABC classification groups to include, specifies the number of months of sales history to consider, and optionally filters by a specific part class or part number. The form then loads all dealer locations and displays the system-calculated standard order quantities for qualifying parts, showing current stock on hand, open order quantities, average monthly consumption, and the system-suggested replenishment quantity for each part. The parts manager can review and amend individual order quantities, accepting or overriding the system suggestion. Once the review is complete, the manager confirms a supplier and purchase order status, and the form updates the on-order stock figures for all selected parts in a single operation. At any point during the process the manager can export the SOQ data to a CSV file for offline review, or print the SOQ report for a chosen reference date. All quantity amendments are recorded with the user's name and modification timestamp before being saved.

### Key Stakeholders

*Who uses pt_soq_new*

| Stakeholder | Role |
| :--- | :--- |
| **Parts Manager** | **Primary interactive user** of pt_soq_new. Reviews system-suggested order quantities, amends them where necessary, selects the supplier and PO status, and commits the replenishment order. |
| **Dealer / Consignee** | Business entity on whose behalf the SOQ is generated; location codes and stock data are scoped to the dealer throughout the process. |

---

---

## 3. System Context

*Describes the pt_soq_new module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **pt_soq_new** module is the dealership **Suggested Order Quantity (SOQ) and Re-Order Processing** screen within the Dealer Management System. It is the central tool for parts replenishment planning, connecting the parts manager's review and amendment activities with stock inventory records, supplier selection, and on-order quantity updates.

**System purpose:** Allow a parts manager to review system-calculated standard order quantities for qualifying parts across dealer locations, amend quantities where required, confirm a supplier and purchase order status, and commit the replenishment plan - updating on-order stock figures and optionally printing or exporting the SOQ for a chosen reference date.

**In scope:**

- Select parts category, ABC classification groups (A, B, C, unclassified), number of consumption months, and optional part class or part number filters
- Load and select dealer locations to include in the SOQ, including stock-yard locations when applicable
- Display system-generated SOQ records showing current stock, open orders, average consumption, and suggested order quantities for each qualifying part
- Review and amend individual order quantities with validation against minimum order quantities and decimal quantity rules
- Display and sort the SOQ grid by part number, SOQ quantity, amended quantity, purchase price, or total value
- Select a supplier from the appropriate list (standard or multi-location) and set a purchase order status
- Commit amended SOQ quantities and update on-order stock figures for all selected parts in one operation
- Export the SOQ data to a CSV file for offline review
- Print the SOQ report for a chosen reference date via the Oracle Reports engine
- Clear and reset the form for a new SOQ review cycle

**Process Name:** Suggested Order Quantity Review and Re-Order Processing

**Process Owner:** Parts Manager

**Process Objective:** Open the SOQ screen, apply category and location filters, review system-generated order quantities for each part, amend quantities as required, confirm a supplier and PO status, and commit the replenishment order to update on-order stock.

**Process Trigger:** Parts manager initiates the SOQ review cycle to plan parts replenishment for one or more dealer locations

**Process Flow:**

The complete suggested order quantity review and re-order processing process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         The parts manager opens the SOQ screen. Session context is registered,
         dealer locations are loaded, the last SOQ date and category are displayed,
         and the copyright notice is shown.

STEP 2 ── SELECT PARTS CATEGORY
         Manager selects the parts category (e.g. Main, All) to include in the SOQ.
         A category selection is mandatory before proceeding.

STEP 3 ── SELECT ABC CLASSIFICATION GROUPS
         Manager selects one or more ABC groups (A, B, C, unclassified) to include.
         At least one group must be selected to generate the SOQ.

STEP 4 ── SPECIFY CONSUMPTION HISTORY PERIOD
         Manager enters the number of months of sales history (1-12) to use as
         the consumption basis. An out-of-range value is rejected with an error.

STEP 5 ── OPTIONAL FILTERS - PART CLASS AND PART NUMBER
         Manager optionally filters by part class code or specific part number to
         narrow the SOQ to a subset of parts.

STEP 6 ── SELECT LOCATIONS
         Manager reviews the list of dealer locations loaded for the consignee.
         Each location can be selected (checked) or deselected for inclusion.
         ├── STOCK YARD MODE: When stock-yard flag is active, all dealer locations
                              are loaded and the multi-location supplier LOV is used
         └── STANDARD MODE:  Only the primary location is pre-selected

STEP 7 ── TOGGLE STOCK-YARD LOCATIONS - when stock-yard checkbox is changed
         Toggling the stock-yard checkbox reloads the location list to include or
         exclude stock-yard locations accordingly.

STEP 8 ── LOAD SOQ DATA
         Manager initiates the SOQ query (via the Process button or show-consumption
         button). The system queries the SOQ table for the current dealer, selected
         location, and parent group, returning all parts with a non-zero SOQ quantity.

STEP 9 ── SHOW / HIDE CONSUMPTION COLUMNS - optional
         Manager can toggle the show-consumption flag to display or hide the monthly
         consumption columns alongside average consumption figures.

STEP 10 ── REVIEW SOQ LINES
          The SOQ grid displays part number, description, on-hand quantity, on-order
          quantity, average consumption, system SOQ quantity, and amended SOQ quantity
          for each qualifying part. Purchase price and total value are shown per line.

STEP 11 ── SORT SOQ GRID - optional
          Manager selects a sort column (part number, SOQ qty, amended qty, purchase
          price, or value) and sort direction (ascending or descending) to reorder
          the grid for easier review.

STEP 12 ── AMEND SOQ QUANTITY
          Manager reviews each line and may override the system SOQ quantity by
          entering an amended quantity.
          ├── DECIMAL CHECK: If the part does not allow fractional quantities,
                             a decimal value is rejected with an error
          └── MINIMUM ORDER CHECK: If the amended quantity is below the minimum
                                   order pack size, the user is warned or blocked

STEP 13 ── PRE-UPDATE STAMP - on save of any amended line
          Before each line is saved, the system records the modifying user's name
          and the current date and time on the record.

STEP 14 ── EXPORT TO CSV - optional
          Manager can export the current SOQ data to a CSV file. The system generates
          the file on the server and opens it in the browser for download.

STEP 15 ── NAVIGATE TO SUPPLIER SELECTION
          After completing the SOQ review, the manager moves to the supplier and
          PO details screen.

STEP 16 ── SELECT SUPPLIER
          Manager selects a supplier code from the appropriate list. The system
          retrieves the supplier name. If the supplier code is not found in the
          master data, an error is displayed.
          ├── MULTI-LOCATION MODE: LOV shows suppliers with multi-location flag
          └── STANDARD MODE: LOV shows suppliers without multi-location flag

STEP 17 ── SET PO STATUS
          Manager selects the purchase order status (e.g. Open, Closed) for the
          replenishment order. A status must be provided.

STEP 18 ── COMMIT REPLENISHMENT ORDER
          Manager commits the record. The system validates all mandatory fields,
          checks for form errors, and commits the transaction. On success, the
          on-order stock figures in the parts variant master are updated for all
          selected parts in a single operation.

STEP 19 ── ERROR HANDLING DURING COMMIT
          If any part's on-order update fails (lock conflict, data error, or missing
          record), the error is reported to the manager. Missing part variant records
          are created automatically before the update is retried.

STEP 20 ── NAVIGATE TO PRINT OPTIONS - optional
          Manager navigates to the print options screen to print the SOQ report.

STEP 21 ── PRINT SOQ REPORT
          Manager enters the reference date for the report. On confirmation, the
          system invokes the SOQ report (PT_SOQHS) and directs the output as configured.
          The manager can navigate back without printing.

STEP 22 ── CLEAR AND RESET
          Manager can clear the form at any time to start a new SOQ review. The
          form resets all criteria, reloads locations, refreshes the last SOQ date,
          and returns focus to the category selection.
```

**Major process interactions:**

- **Dealer location master** - supplies the list of active locations for the consignee at screen open and after checkbox toggles
- **SOQ data store** - source of system-generated standard order quantities, amended quantities, and as-on-date records for the current dealer, location, and parent group
- **Parts master** - provides part descriptions, part class, minimum order quantities, decimal quantity flags, and purchase prices for each SOQ line
- **Supplier/party master** - provides the list of available suppliers for the selected dealer and mode (standard or multi-location)
- **Parts variant stock master** - receives on-order quantity updates when the replenishment order is committed
- **Oracle Reports engine** - invoked to generate and deliver the SOQ print report (PT_SOQHS)
- **CSV export** - server-side file generation and browser delivery for offline SOQ data review

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialisation, Session Registration, and Default Setup

**Business Description:**
When the Suggested Order Quantity Processing form is opened or reset to its starting state, the system registers the active session for monitoring, records the form identifier as a global application reference, loads the consignee's location attributes, populates the Parts Category dropdown from the parts-category master, loads the list of available dealer locations, retrieves the date of the most recent SOQ run, applies default filter settings, re-populates the category and location pre-selection from any existing SOQ data, enables all editable fields, and moves the cursor to the first data-entry point so the user can begin work immediately. The form also displays a copyright notice at this stage.

**Actors:** Dealership User

**Preconditions:**
- The user has opened the Suggested Order Quantity Processing form.
- The current dealer, principal, and location context have already been set by the calling environment before the form loads.

**Main Flow:**

**Step 1 - Application session is registered for monitoring**
The system records the form's identity in the database session tracking layer so that activity on this form can be attributed and monitored by database administrators. This happens automatically the moment the form is opened, writing the form's identifier to the session client-info register and setting the session module name to the form's name with a blank action-name slot.

**Step 2 - Global application identifier is set**
The system assigns the application identifier `pt_soq_new` to the global variable `global.app_id` and copies the same value to `parameter.p_app_id`. This seed value identifies the running form module throughout the session for any downstream processing that requires a form-identity reference.

**Step 3 - Parts Category dropdown is populated from the parts-category master**
The system builds the Parts Category dropdown list (`sb_title.part_categ`) by querying the parts-category master table filtered to the current principal. The resulting list is loaded using record group `Categ`. Once loaded, the Parts Category is defaulted to the value `M` (the standard category).

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 4 - Consignee location attributes are retrieved**
The system reads the consignee code, stock-yard indicator, and location description for the current dealer, parent group, and location from the dealer location master and stores these values in session parameters (`parameter.p_consg_cd`, `parameter.p_stock_yard`, `parameter.p_loc_desc`). These attributes control which locations are eligible for SOQ calculation.

**Step 5 - Form is cleared to a fresh working state and editable fields are re-enabled**
When the user resets the form (or on first load via the form-clear path), the system discards any previously entered data without asking for confirmation, then explicitly re-enables all fields that may have been locked during a prior session. The parts category filter is set to its default value and the "show zero SOQ" flag is switched off.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **FETCH_LOC** ([SP-001](#SP-001--FETCH_LOC)) - FETCH_LOC (form program unit) - loads the list of dealer locations available for this consignee into the location selection list. The stock-yard indicator retrieved in Step 4 is passed to control which locations are listed. If the form was opened in consignee-level mode, all live locations under the consignee are listed and each is pre-selected; otherwise only the current location is loaded and pre-selected.
    * **Step 1** - Clear any previously held location data from the in-memory location table.
    * **Step 2** - Allow the location list block to be modified so it can be repopulated.
    * **Step 3** - Clear the location list display and move to its first row.
    * **Step 4** - If consignee-level mode is active, query all live dealer locations belonging to this consignee and principal, display each row with its location code and description, store the location details in the in-memory table, and pre-tick every location's selection checkbox.
    * **Step 5** - If standard (single-location) mode is active, populate a single row with the current location's code and description from the session context, store it in the in-memory table, and pre-tick that row's selection checkbox.
    * **Step 6** - Lock the location list against further user modifications and return focus to the main filter block.

**Step 6 - Current system date and last SOQ date are displayed**
The system navigates to the SOQ header block, sets the "To Date" field to the current system date, and then calls the routine to retrieve and display the date of the most recent SOQ run for this dealer/location context.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GET_LAST_SOQ_DATE** ([SP-002](#SP-002--GET_LAST_SOQ_DATE)) - GET_LAST_SOQ_DATE (form program unit) - retrieves the date of the most recent SOQ run for the current dealer/location/company context and displays it in the "Last SOQ Date" field together with the SOQ category. If no previous SOQ exists, both fields are left blank without error.
    * **Step 1** - Query the SOQ header table for the most recent SOQ record matching the current dealer, location, parent group, and company context, and also retrieve the parts-category description for that SOQ.
    * **Step 2** - Populate the Last SOQ Date field and the SOQ category fields on the main screen with the retrieved values.
    * **Step 3** - If no matching SOQ record is found, clear the Last SOQ Date and category fields silently (no error is shown).
    * **Step 4** - If any other error occurs during retrieval, clear both fields silently.

**Step 7 - Category and location pre-selection is applied from any existing SOQ data**
The system temporarily suspends form validation, calls the category and location pre-population routine to pre-select the Parts Category and tick the locations that were used in any previous SOQ for this context, and then restores form validation.

*Procedures called:*
- **LOC_CATEG_POPULATION** ([SP-013](#SP-013--LOC_CATEG_POPULATION)) - LOC_CATEG_POPULATION (form program unit) - reads any existing SOQ records for this dealer/location context and pre-populates the Parts Category filter and pre-selects the matching locations. See BR-022 for full detail.

**Step 8 - Cursor is positioned at the first data-entry field**
After all defaults and data have been loaded, the system automatically places the cursor in the Parts Category filter field (`SB_TITLE.PART_CATEG`) so the user can immediately begin configuring the SOQ run parameters.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-016](#SP-016--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION (standalone function) - returns the copyright text that is displayed in the form's copyright field.
    * **Step 1** - Return the copyright declaration text to the calling form for display.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Parts category default applied | KEY-CLRFRM sets Parts Category to the fixed value 'M' | When the form is cleared/reset | Ensures the parts category filter always starts at the standard default rather than retaining a value from the previous session. | Not applicable - this is a system-applied default, not a user-checked gate. |
| Show Zero SOQ default applied | KEY-CLRFRM sets Show Zero SOQ flag to 'N' | When the form is cleared/reset | Ensures the results grid starts filtered to show only non-zero SOQ quantities by default. | Not applicable - this is a system-applied default. |
| SOQ population flag reset | KEY-CLRFRM sets the SOQ population parameter to 'N' | When the form is cleared/reset | Marks the SOQ as not yet populated so the system knows a fresh calculation is needed. | Not applicable - this is a system-applied flag reset. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - Parts Category defaulted to 'M' - the parts category filter is pre-set to the standard default category on every reset.
- **BR-001-IC-02** - Show Zero SOQ defaulted to 'N' - the results grid is initialised to show only parts with a non-zero suggested quantity.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 5) If no live dealer locations exist for the consignee, the location list is left empty and the user cannot proceed to calculate an SOQ until at least one location becomes available.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Last SOQ Date (`NB_LAST_SOQ_DATE`) | Auto-populated | Date/Time | DD-MM-RRRR HH:MI AM | N/A | Retrieved from SOQ header | Form opened | System-set; read-only; cleared if no prior SOQ exists | N/A |
| Last SOQ Category (`NB_SOQ_CATG`) | Auto-populated | Text | 100 | N/A | Retrieved from parts category master | Form opened | System-set; read-only; cleared if no prior SOQ exists | N/A |
| Parts Category (`PART_CATEG`) | Mandatory | Text | N/A | Parts-category master (record group `Categ`) | Defaulted to 'M' on form reset; dropdown loaded from PM_CATEGORY for current principal | Form opened | Must not be blank - validated on leaving the field | Mandatory field alert if blank |
| Location(s) Considered (`LOC_DESC`) | Auto-populated | Text | 50 | Dealer location master | Loaded from dealer locations for this consignee | Dealer/consignee context set in session | System-populated; not directly editable by user | N/A |
| To Date (`NB_TO_DATE`) | Auto-populated | Date/Time | DD-MM-RRRR | N/A | Set to current system date on form open | Form opened | System-set; read-only | N/A |
| Copyright (`COPYRIGHT`) | Read-only display | Text | 100 | N/A | Returned by copyright function | Form opened | Read-only | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** Parts Category Filter Validation

**Business Description:**
When the user moves away from the Parts Category field on the main filter screen, the system checks that a category value has been entered. If the field is left blank, the user is immediately notified and must supply a value before proceeding.

**Actors:** Dealership User

**Preconditions:**
- The form is open and the user has placed the cursor in the Parts Category field.

**Main Flow:**

**Step 1 - Parts category entry is validated as mandatory**
When the user leaves the Parts Category field, the system confirms that a value has been entered. If the field is empty, the user sees an error and cannot navigate away until a category is provided.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-005](#SP-005--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL (attached library DPL) - checks whether the Parts Category field is blank. If it is blank, the system stops processing and prompts the user to fill in the field.
    * **Step 1** - Receive the current value of the Parts Category field and the field's display label.
    * **Step 2** - If the value is blank or null, display a mandatory-field alert naming the field and abort navigation away from the field.
    * **Step 3** - If the value is present, return control to the form with no action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Parts Category must not be blank | Mandatory-field check - GENERAL.CHECK_NULL [SP-005] | When the user tabs or navigates away from the Parts Category field | Prevents an SOQ calculation run being launched without a parts category selected, which would produce meaningless or unscoped results. | Alert displayed; cursor stays on the Parts Category field until a value is entered. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parts Category (`PART_CATEG`) | Mandatory | Text | N/A | N/A | N/A | N/A | Must not be blank | Mandatory-field alert; cursor returned to field |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Number of Months Consumption Entry and Validation

**Business Description:**
The user enters the number of months of historical consumption data to include when calculating the Suggested Order Quantity. The system validates that a value has been entered. If the field is left blank, the user sees an error message and must provide a value before proceeding. After a valid entry, pressing Tab moves focus directly to the Calculate SOQ button.

**Actors:** Dealership User

**Preconditions:**
- The form is open and the user is configuring the SOQ calculation parameters.

**Main Flow:**

**Step 1 - Number of months is entered and validated as mandatory**
The user types the number of months to include in the SOQ consumption calculation. When the user leaves the field, the system checks that the number of months is not blank. If it is blank, the user sees a message and cannot proceed.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the mandatory-field error message to the user via an alert dialogue.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue with the specified severity title.
    * **Step 3** - Wait for the user to acknowledge the message and then return control to the form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Number of months must not be blank | `IF :SB_TITLE.NO_MONTHS IS NULL` check in WHEN-VALIDATE-ITEM on `SB_TITLE.NO_MONTHS` | When the user leaves the Number of Months field | Ensures a valid consumption period is always specified so the SOQ calculation has a defined time horizon. | *"Enter the Number of months of consumption to be considered"* is displayed; trigger fails and cursor remains on the field. |

**Step 2 - Cursor is advanced to the Calculate SOQ button**
After a valid number-of-months value is confirmed, pressing Tab moves the cursor directly to the Calculate SOQ button.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 1) If the number of months field is blank: *"Enter the Number of months of consumption to be considered"* is displayed; cursor remains on the field until the user provides a value.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider Months Consumption (`NO_MONTHS`) | Mandatory | Numeric | 2 digits | N/A | N/A | N/A | Must not be blank | *"Enter the Number of months of consumption to be considered"* |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Consignee-Level Location Scope Selection

**Business Description:**
The user can choose to expand the SOQ calculation scope from a single dealer location to all live locations under the consignee by toggling the "Consigne Level" checkbox. When this checkbox is changed, the system immediately reloads the list of locations to reflect the new scope - either all active consignee locations or just the single current location.

**Actors:** Dealership User

**Preconditions:**
- The form is open and the user is configuring the SOQ calculation parameters.

**Main Flow:**

**Step 1 - Location scope is toggled and location list is reloaded**
When the user checks or unchecks the Consigne Level checkbox, the system immediately calls the location-loading routine, passing the new checkbox value. If the checkbox is ticked, all live dealer locations under the consignee are loaded and pre-selected. If the checkbox is unticked, only the current single location is loaded.

*Procedures called:*
- **FETCH_LOC** ([SP-001](#SP-001--FETCH_LOC)) - FETCH_LOC (form program unit) - reloads the location list based on the updated scope flag. When called with the consignee-level flag set to 'Y', all live dealer locations for the consignee are listed; when called with 'N', only the current location is shown.
    * **Step 1** - Clear any previously held location data from the in-memory location table.
    * **Step 2** - Allow the location list block to be modified so it can be repopulated.
    * **Step 3** - Clear the location list display and move to its first row.
    * **Step 4** - If consignee-level mode is active, query all live dealer locations belonging to this consignee and principal, display each row with its location code and description, store the location details in the in-memory table, and pre-tick every location's selection checkbox.
    * **Step 5** - If standard (single-location) mode is active, populate a single row with the current location's code and description from the session context, store it in the in-memory table, and pre-tick that row's selection checkbox.
    * **Step 6** - Lock the location list against further user modifications and return focus to the main filter block.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consigne Level (`CHK_STK_YARD`) | Optional | Checkbox | 1 | N/A | Y / N | Form open | N/A | N/A |
| Location(s) Considered (`LOC_DESC`) | Auto-populated | Text | 50 | Dealer location master | Reloaded based on scope flag | Checkbox changed | System-reloaded; not directly editable | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Individual Location Selection and Deselection

**Business Description:**
Within the list of available locations, the user can tick or untick individual location checkboxes to include or exclude specific locations from the SOQ calculation. If the user unchecks a location that has no description, that location row is automatically removed from the list.

**Actors:** Dealership User

**Preconditions:**
- The form is open and the location list has been populated.

**Main Flow:**

**Step 1 - Individual location checkbox is toggled**
The user checks or unchecks the "Consider" checkbox next to a location in the location list. If the checkbox is unticked for a row that has no location description, the system deletes that record row from the list automatically.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Empty location rows are removed when unchecked | `IF :b_loc.loc_desc IS NULL THEN delete_record` in WHEN-CHECKBOX-CHANGED on `B_LOC.CHECK_YN` | When the user unchecks the "Consider" checkbox for a location row | Prevents blank placeholder location rows from being included in the SOQ scope. | Row is silently deleted from the on-screen list. |

**Step 2 - Focus is advanced to the Calculate SOQ button**
After the user changes a location selection, pressing Tab moves focus directly to the Calculate SOQ button.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Consider (`CHECK_YN`) | Optional | Checkbox | 1 | N/A | Y / N | Location list loaded | N/A | N/A |
| Location(s) Considered (`LOC_DESC`) | Auto-populated | Text | 50 | N/A | N/A | Location list loaded | Row deleted if blank when unchecked | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Show Zero SOQ Checkbox - Filter Toggle for Parts With No Suggested Quantity

**Business Description:**
By default the SOQ results grid shows only parts that have a non-zero suggested order quantity. The user can toggle the "Show zero SOQ" checkbox to include parts whose suggested order quantity is zero. When this setting is changed, the system saves any pending amendments, re-applies the filter, and refreshes the results grid.

**Actors:** Dealership User

**Preconditions:**
- The SOQ results grid has been populated with at least one query run.

**Main Flow:**

**Step 1 - Zero-SOQ filter is toggled and results grid is refreshed**
When the user changes the "Show zero SOQ" checkbox, the system first saves any pending changes in the SOQ grid to avoid losing edits. It then updates the underlying query filter: if the checkbox is ticked, the filter includes all parts regardless of their suggested quantity; if it is unticked, the filter restricts results to parts where the suggested quantity is greater than zero. The results grid is cleared and re-queried with the new filter, and the cursor returns to the first row.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Pending changes are saved before the filter is refreshed | `IF GET_BLOCK_PROPERTY('B_SOQ',STATUS) = 'CHANGED' THEN POST` in WHEN-CHECKBOX-CHANGED on `SB_TITLE.SHOW_ZERO_SOQ` | When the user changes the Show Zero SOQ checkbox | Prevents loss of any quantity amendments the user has already entered before the grid is refreshed. | Any unsaved changes are posted before the grid is cleared. |

**Business Scenarios - How the SOQ results grid differs by zero-SOQ setting**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Show zero SOQ off (default)** | The results grid shows only parts where the suggested order quantity is greater than zero; parts with zero suggested quantity are excluded from view. |
| **Show zero SOQ on** | The results grid shows all parts matching the other filters regardless of suggested quantity, including those with a zero suggested order quantity. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Show zero SOQ (`SHOW_ZERO_SOQ`) | Optional | Checkbox | 1 | N/A | Y / N | SOQ results loaded | N/A | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** SOQ Results Loading - Part Pricing and Settings Enrichment After Query

**Business Description:**
When the SOQ results grid is populated following an SOQ calculation run, the system enriches each queried part row with additional details sourced from the parts master: the part's decimal-quantity flag, the minimum pack quantity, and the current purchase price. These values are needed for amended quantity validation and order value calculations. If a part is not found in the master, the system applies safe defaults and continues loading; if a data width error or unexpected database error occurs, a descriptive message is shown and that row's loading aborts while the form remains open.

**Actors:** System (automatic, triggered by each record displayed in the SOQ results grid)

**Preconditions:**
- An SOQ calculation has been run and records exist in the SOQ results table for the current dealer/location/company context.

**Main Flow:**

**Step 1 - Serial number is assigned to each result row**
As each part row is loaded into the grid, the system assigns it a sequential serial number matching its display position in the grid.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 2 - Part-level pricing and settings are retrieved from the parts master**
For each part row, the system queries the parts master and price variant table to retrieve the decimal-quantity allowance flag, the minimum pack quantity, and the current purchase price for this dealer/location. These three values are stored for use by subsequent validation and calculation steps. If the part is not found, the three values default to zero/N silently; if a data width problem or other database error occurs, a descriptive message is shown and that row's loading fails.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part not found in master | `WHEN NO_DATA_FOUND` in POST-QUERY on `B_SOQ` - sets decimal-qty flag to 'N', minimum pack quantity to 0, purchase price to 0 | When each SOQ row is loaded | Ensures that even if a part has no price or settings record, the row is still displayed without crashing the query. | Decimal-qty flag, minimum pack quantity, and purchase price all default to zero/N; row is still shown; no error is displayed. |
| Data width error while loading part details | `WHEN VALUE_ERROR` in POST-QUERY on `B_SOQ` - calls GENERAL.DISP_TEXT with error text and raises trigger failure | When each SOQ row is loaded | Prevents data corruption if a retrieved value is too wide for the display field. | *"Width problem while fetching details for part number "* (part number appended dynamically) is displayed; that row's retrieval aborts and the form stays open. |
| Unexpected database error while loading part details | `WHEN OTHERS` in POST-QUERY on `B_SOQ` - calls GENERAL.DISP_TEXT with database error text and raises trigger failure | When each SOQ row is loaded | Surfaces any unanticipated database failure so the user is informed rather than seeing incorrect data silently. | *"Execution failed while fetching details for part number "* (part number and database error text appended dynamically) is displayed; that row's retrieval aborts and the form stays open. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - Data width problem while loading a part's details - *"Width problem while fetching details for part number "* (part number appended dynamically); price and settings default to zero/N; trigger aborts for that row.
- **BR-007-ES-02** - Unexpected database error while loading a part's details - *"Execution failed while fetching details for part number "* (part number and database error text appended dynamically); trigger aborts for that row; form stays open.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Srl. No. (`NB_SRL_NUM`) | Auto-populated | Numeric | N/A | N/A | Set to current display row number | Query executed | Read-only; system-set | N/A |
| Part Number (`PART_NUM`) | Read-only display | Text | 15 | N/A | Queried from SOQ table | SOQ calculation run | N/A | N/A |
| Purchase Price (`NB_PUR_PRICE`) | Auto-populated | Numeric | 9,99,99,99,990.00 | Parts price variant master | Retrieved from parts price table | Part queried | Defaults to 0 if part not found in price master | Error message shown on data-width or database error |
| Minimum Pack Quantity (`NB_MIN_ORD_QTY`) | Auto-populated | Numeric | 9,99,990.990 | Parts master | Retrieved from parts master | Part queried | Defaults to 0 if part not found | Error message shown on data-width or database error |
| Allow Decimal Qty (`NB_ALLOW_DECIMAL_QTY`) | Auto-populated | Text | 5 | N/A | Retrieved from parts master | Part queried | Defaults to 'N' if part not found | Error message shown on data-width or database error |

---

---

#### Requirement ID: BR-008

**Requirement Title:** Amended SOQ Quantity Entry and Decimal Validation

**Business Description:**
The user can enter an amended quantity for a part's suggested order quantity. The system validates whether decimal quantities are permitted for that specific part. If the part does not allow decimal quantities, the entered value is automatically truncated to a whole number. If the decimal-quantity flag is in an error state (indicating a lookup failure), the user is shown an error and cannot proceed.

**Actors:** Dealership User

**Preconditions:**
- The SOQ results grid has been populated and the user has navigated to the Amended Quantity field for a part.
- The part's decimal-quantity allowance flag has been retrieved (from the parts master enrichment at record load time).

**Main Flow:**

**Step 1 - Amended quantity is entered and decimal allowance is validated**
The user types the amended quantity. When the user leaves the field, the system checks the part's decimal-quantity flag. If the part does not allow decimal quantities, the entered value is automatically truncated to the nearest whole number. If the flag is in an error state, the user sees an error message and cannot proceed.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the decimal-validation error message to the user when the allow-decimal flag is in an error state.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue with the specified severity title.
    * **Step 3** - Wait for the user to acknowledge the message and then return control to the form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Whole-number truncation when decimals not allowed | `IF nvl(:B_SOQ.nb_allow_decimal_qty,'N')='N' THEN :B_SOQ.AMD_SOQ_QTY:=trunc(...)` in WHEN-VALIDATE-ITEM on `B_SOQ.AMD_SOQ_QTY` | When the user leaves the Amended Quantity field | Ensures that parts which are sold only in whole-number pack quantities are not ordered in fractional amounts. | The value is silently truncated to the nearest whole number; no error is shown. |
| Error-state decimal flag prevents entry | `ELSIF nvl(:B_SOQ.nb_allow_decimal_qty,'N')='E' THEN` in WHEN-VALIDATE-ITEM on `B_SOQ.AMD_SOQ_QTY` | When the user leaves the Amended Quantity field | Prevents saving a quantity when the system could not determine whether decimal quantities are allowed, protecting data integrity. | *"Error while judging to allow Amended SOQ Quantity in decimal."* is displayed; trigger fails and cursor remains on the field. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - Decimal allowance flag is in error state - *"Error while judging to allow Amended SOQ Quantity in decimal."*; cursor remains on the Amended Quantity field.

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 1) When the part allows decimal quantities (flag = 'Y' or not set to 'N' or 'E'): the entered value is accepted as-is; no truncation occurs.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Amended Quantity (`AMD_SOQ_QTY`) | Optional | Numeric | 9,99,990.990 (21 characters) | N/A | N/A | SOQ results loaded | Truncated to whole number if part does not allow decimal quantities | *"Error while judging to allow Amended SOQ Quantity in decimal."* if flag is in error state |
| Allow Decimal Qty (`NB_ALLOW_DECIMAL_QTY`) | Auto-populated | Text | 5 | Parts master | 'N' = whole numbers only; 'Y' = decimals allowed; 'E' = error | Part loaded in results | Read-only; used by system validation only | N/A |

---

---

#### Requirement ID: BR-009

**Requirement Title:** SOQ Record Update - Audit Stamp Before Save

**Business Description:**
Before any amended SOQ record is saved to the database, the system automatically stamps the record with the identity of the user who made the change and the date and time of the change. This ensures every modification is traceable.

**Actors:** System (automatic, runs before every save of a changed SOQ record)

**Preconditions:**
- One or more SOQ records have been modified by the user and a save operation has been initiated.

**Main Flow:**

**Step 1 - Modified-by user and date are stamped on each changed SOQ record**
Before any changed SOQ record is written to the database, the system sets the "Modified By" field to the currently logged-in user's identity and the "Modified Date" field to the current system date and time. These values are written automatically; the user does not enter them.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Modified By (`MODIFIED_BY`) | Auto-populated | Text | 8 | N/A | Current logged-in user identity | Record modified | System-set; not user-editable | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated | Date/Time | N/A | N/A | Current system date and time | Record modified | System-set; not user-editable | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** SOQ Results Sorting

**Business Description:**
The user can sort the SOQ results grid by selecting a sort field and sort direction from the Sort By and Sort Type drop-down lists. When either selection is changed, the system immediately re-sorts and refreshes the results grid. Available sort fields include Part Number, SOQ Quantity, Amended Quantity, Purchase Price, and Total Value.

**Actors:** Dealership User

**Preconditions:**
- The SOQ results grid has been populated.

**Main Flow:**

**Step 1 - Sort field or sort direction is changed and results are re-sorted**
When the user changes the Sort By or Sort Type drop-down, the system saves any pending changes in the grid, navigates to the results block, sets the new sort order based on the selected field and direction, clears the grid, and re-executes the query to display the rows in the new order.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **SORT_BLOCK** ([SP-003](#SP-003--SORT_BLOCK)) - SORT_BLOCK (form program unit) - saves pending changes, re-sets the block's sort order according to the selected Sort By field and Sort Type direction, and refreshes the results grid.
    * **Step 1** - Save any pending, unsaved changes in the SOQ results block.
    * **Step 2** - Navigate to the SOQ results block and set the default sort column to "Part Number".
    * **Step 3** - Map the selected Sort By value to the actual sort expression (Part Number, SOQ Quantity, Amended Quantity, Purchase Price formula, or Total Value formula) and record the chosen sort direction (ascending or descending).
    * **Step 4** - Apply the new sort order to the results block, clear the block, and re-execute the query so results are displayed in the new order.

**Business Scenarios - How sorting differs by Sort By selection**

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Sort by Part Number** | Results are ordered alphabetically/numerically by part number. |
| **Sort by SOQ Quantity** | Results are ordered by the system-calculated suggested order quantity. |
| **Sort by Amended Quantity** | Results are ordered by the user-amended quantity. |
| **Sort by Purchase Price** | Results are ordered by the current purchase price looked up from the price master. |
| **Sort by Value** | Results are ordered by the calculated total value (amended quantity × purchase price). |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Sort By (`NB_SORT_BY`) | Optional | List | 100 | N/A | PART_NUM / SOQ_QTY / AMD_SOQ_QTY / PURCHASE_PRICE / VALUE | SOQ results loaded | N/A | N/A |
| Sort Type (`NB_SORT_TYPE`) | Optional | List | 100 | N/A | ASC / DESC | SOQ results loaded | N/A | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Show Monthly Consumption Detail by Location

**Business Description:**
The user can view the historical monthly consumption breakdown for any selected part in the SOQ results grid. When the "Show Consumption" button is pressed for a part, the system retrieves up to the configured number of months of consumption data for each dealer location, together with the current stock and on-order quantity for each location, and displays this breakdown in the consumption detail panel. If no part is selected, or if there are no locations or root part issues, appropriate error messages are shown.

**Actors:** Dealership User

**Preconditions:**
- The SOQ results grid has been populated and the user has selected a part row.

**Main Flow:**

**Step 1 - Part selection is checked before loading consumption detail**
When the user presses the "Show Consumption" button, the system first checks whether a Part Number is currently selected in the SOQ results grid. If no part number is present, the user sees an error and the consumption panel is not loaded.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the "Part Number Not available to show consumption" message if no part is selected.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue.
    * **Step 3** - Return control to the form after the user acknowledges.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Part Number must be selected before showing consumption | `IF :b_soq.part_num IS NULL THEN general.disp_text(...)` in WHEN-BUTTON-PRESSED on `SB_TITLE.SHOW_CON` | When the user presses the Show Consumption button | Prevents the consumption panel from being loaded with no part context, which would produce meaningless results. | *"Part Number Not available to show consumption"* is displayed; consumption panel is not loaded. |

**Step 2 - Reference date is determined based on current-month consumption setting**
The system determines the reference date for consumption calculation. The current-month consumption flag is set to 'N' (do not include current month), so the reference date is set to one month before today. (The alternate current-month paths for 'C' and 'V' are coded but the flag is hardcoded to 'N' and those branches do not execute.)

**Step 3 - Consumption detail panel is cleared and each dealer location is processed**
The system navigates to the consumption detail panel, clears it, and then loops through all locations stored in the in-memory location table. For each location, it retrieves the root part number from the parts master, calls the consumption-population procedure to fill monthly consumption figures, stock, and on-order quantity, and populates the detail rows for that location.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **SP_SOQ_POPULATE_CONSUMPTION** ([SP-017](#SP-017--SP_SOQ_POPULATE_CONSUMPTION)) - SP_SOQ_POPULATE_CONSUMPTION (standalone procedure) - for the given root part and dealer location, retrieves up to the specified number of months of consumption history and the current stock and on-order quantity, and returns these as output arrays/values.
    * **Step 1** - Accept the dealer, principal, parent group, location, company, root part number, number of months, and reference date as inputs.
    * **Step 2** - Retrieve the consumption figures for each of the requested months for this location and part.
    * **Step 3** - Retrieve the current stock quantity and on-order quantity for this location and part.
    * **Step 4** - Return the monthly consumption figures, current stock, on-order quantity, and any error code or message to the caller.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| No locations available | `IF dealer_loc.dloc_tab.count = 0 THEN general.disp_text('No Location available','Note')` in WHEN-BUTTON-PRESSED on `SB_TITLE.SHOW_CON` | After clearing the consumption detail panel | Informs the user when there are no locations in scope for the consumption display. | *"No Location available"* is displayed as a note; consumption panel remains empty. |
| Root part number not found for location | `WHEN NO_DATA_FOUND` in root-part query in WHEN-BUTTON-PRESSED on `SB_TITLE.SHOW_CON` | During the loop through each dealer location | Ensures a missing root-part number mapping is surfaced rather than silently skipped. | *"Root Part Number not found for this Part Number"* followed by the part number is displayed; trigger fails for that location and the form stays open. |
| Data width error retrieving root part number | `WHEN VALUE_ERROR` in root-part query in WHEN-BUTTON-PRESSED on `SB_TITLE.SHOW_CON` | During the loop through each dealer location | Prevents data corruption when the root-part number value is wider than the receiving variable. | *"Width problem/Incompatible Data while fetching Root Part number"* is displayed; trigger fails and the form stays open. |
| Multiple root part numbers found | `WHEN TOO_MANY_ROWS` in root-part query in WHEN-BUTTON-PRESSED on `SB_TITLE.SHOW_CON` | During the loop through each dealer location | Surfaces a data integrity issue where more than one root part exists for the part number. | *" More than one  Root Part Number found "* is displayed; trigger fails and the form stays open. |
| Consumption retrieval failure from procedure | `IF ln_errcd <> 0 THEN general.disp_text(lv_errmsg,'Error')` after SP_SOQ_POPULATE_CONSUMPTION call | After each consumption procedure call | Surfaces any error returned by the consumption-population procedure. | The error message returned by the procedure is displayed; the system returns to the SOQ results block. |
| Unexpected error in WHEN-BUTTON-PRESSED outer handler | `WHEN OTHERS THEN general.disp_text('Error : '||sqlerrm,'Error')` in WHEN-BUTTON-PRESSED outer exception | If any other unanticipated error occurs during consumption loading | Ensures no silent failure occurs when loading consumption data. | *"Error : "* followed by the database error text is displayed. |

**Step 4 - Monthly consumption figures and location totals are populated in the detail panel**
For each location processed, the system copies the returned monthly consumption figures into the corresponding monthly columns (up to the number of months returned), calculates the average consumption for that location by summing all monthly values and dividing by the count, and advances to the next row in the detail panel.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Step 5 - Focus returns to the SOQ results block**
After all locations have been processed, the system moves focus back to the SOQ results grid.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - No part selected - *"Part Number Not available to show consumption"*; consumption panel not loaded.
- **BR-011-WS-01** - No locations available - *"No Location available"* (shown as a note); consumption panel empty.
- **BR-011-ES-02** - Root part not found - *"Root Part Number not found for this Part Number"* (part number appended dynamically); trigger fails.
- **BR-011-ES-03** - Data width error on root part - *"Width problem/Incompatible Data while fetching Root Part number"*; trigger fails.
- **BR-011-ES-04** - Multiple root parts found - *" More than one  Root Part Number found "*; trigger fails.
- **BR-011-ES-05** - Unexpected outer error - *"Error : "* (database error text appended dynamically); trigger fails.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 1) No part number is selected: *"Part Number Not available to show consumption"* is displayed; no further processing occurs.
- **BR-011-AF-02** - (from Step 3) No locations are in scope: *"No Location available"* (note) is displayed; consumption panel is left empty; the flow does not process any location loop.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Read-only display | Text | 15 | N/A | Selected row in SOQ results | SOQ results loaded | Must not be null when Show Consumption is pressed | *"Part Number Not available to show consumption"* |
| Location (`LOCATION`) | Auto-populated | Text | 50 | Dealer location master | Populated per location in consumption loop | Consumption loaded | Read-only; system-set | N/A |
| Current Stock (`CURR_STOCK`) | Auto-populated | Numeric | N/A | N/A | Returned from consumption procedure | Consumption loaded | Read-only; system-set | N/A |
| On Order (`ON_ORDER`) | Auto-populated | Numeric | N/A | N/A | Returned from consumption procedure | Consumption loaded | Read-only; system-set | N/A |
| Average Consumption (`AVER_CONSUMPTION`) | Auto-populated | Numeric | N/A | N/A | Calculated from monthly totals | Consumption loaded | Sum of monthly values divided by count | N/A |
| Monthly Consumption C1-C12 (`C1`-`C12`) | Auto-populated | Numeric | N/A | N/A | Returned from consumption procedure | Consumption loaded | Read-only; system-set for each available month | N/A |
| Consider Months Consumption (`NO_MONTHS`) | Conditional - when Show Consumption is pressed | Numeric | 2 | N/A | Defaults to 12 if blank | Form configured | Passed as input to consumption procedure | N/A |

---

---

#### Requirement ID: BR-012

**Requirement Title:** PO Details Screen - Supplier List Assignment Based on Location Mode

**Business Description:**
When the user navigates to the PO Details panel, the system automatically assigns the correct supplier look-up list based on whether the form is operating in standard (single-location) mode or consignee-level (multi-location) mode. This ensures the supplier selection drop-down shows only suppliers relevant to the current operational mode.

**Actors:** System (automatic, triggered on navigation to the PO Details panel)

**Preconditions:**
- The form is open and the user has navigated to (or the system has navigated to) the PO Details panel.

**Main Flow:**

**Step 1 - Supplier list is assigned based on location scope mode**
When the PO Details block becomes active, the system reads the stock-yard / consignee-level flag. If the form is in consignee-level mode (flag = 'Y'), the multi-location supplier list is assigned to the Supplier field; otherwise the standard single-location supplier list is assigned.

*Screen: PO DETAILS (`CN_PARTY`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Supplier list selection based on location mode | `IF nvl(:parameter.p_stock_yard,'N')='N' THEN set_item_property(...,lov_name,'LV_NON_MUL_PARTY') ELSE set_item_property(...,lov_name,'LV_MUL_PARTY')` in WHEN-NEW-BLOCK-INSTANCE on `B_PARTY` | When the user navigates to the PO Details panel | Ensures the supplier drop-down shows only suppliers applicable to the current operating mode (standard or consignee-level). | Not applicable - this is a system-applied default assignment; no failure path exists. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Supplier (`PARTY_CD`) | Mandatory | Text | N/A | Supplier master (LV_MUL_PARTY or LV_NON_MUL_PARTY depending on mode) | Party code from supplier list | PO Details panel opened | Must be a valid supplier for the current mode | *"Enter a valid Supplier"* |

---

---

#### Requirement ID: BR-013

**Requirement Title:** PO Status Validation

**Business Description:**
When the user enters a PO Status value in the PO Details panel, the system validates that the field is not blank. If the PO Status field is left empty, the user is shown an error and must enter a value before proceeding.

**Actors:** Dealership User

**Preconditions:**
- The user has navigated to the PO Details panel and is entering PO Status.

**Main Flow:**

**Step 1 - PO Status is validated as mandatory**
When the user leaves the PO Status field, the system checks that a value has been entered. If the field is blank, the user sees an error.

*Screen: PO DETAILS (`CN_PARTY`).*

*Procedures called:*
- **GENERAL.CHECK_NULL** ([SP-005](#SP-005--GENERAL.CHECK_NULL)) - GENERAL.CHECK_NULL (attached library DPL) - checks whether the PO Status field is blank and displays an alert if it is.
    * **Step 1** - Receive the current value of the PO Status field and the field's display label.
    * **Step 2** - If the value is blank or null, display a mandatory-field alert and abort navigation.
    * **Step 3** - If the value is present, return control to the form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| PO Status must not be blank | Mandatory-field check - GENERAL.CHECK_NULL [SP-005] in WVI trigger on `B_PARTY.PO_STATUS` | When the user leaves the PO Status field | Ensures a PO cannot be raised without a status value, which is required for order processing and tracking. | Mandatory-field alert; cursor remains on the PO Status field. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| PO Status (`PO_STATUS`) | Mandatory | Text | 10 | N/A | N/A | PO Details panel open | Must not be blank | Mandatory-field alert; cursor returned to field |

---

---

#### Requirement ID: BR-014

**Requirement Title:** Supplier Validation in PO Details

**Business Description:**
When the user enters or selects a supplier code in the PO Details panel, the system looks up the supplier in the party master to confirm it exists and is valid for the current operating mode (standard or consignee-level). If the supplier is found, the supplier's name is automatically populated. If the supplier is not found or a database error occurs, the user sees an error and must provide a valid supplier code.

**Actors:** Dealership User

**Preconditions:**
- The user has navigated to the PO Details panel and has entered or selected a supplier code.

**Main Flow:**

**Step 1 - Supplier code is looked up in the party master**
When the user leaves the Supplier field, the system checks whether a supplier code has been entered. If a code is present, it queries the party master for a matching active supplier of the correct type. If found, the supplier name field is populated automatically. If the supplier is not found, the user sees an error; if any other database error occurs, the database error text is shown and the trigger fails.

*Screen: PO DETAILS (`CN_PARTY`).*

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the validation error message when the supplier code is invalid or a database error occurs.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue.
    * **Step 3** - Return control to the form after the user acknowledges.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Supplier code must exist in party master | `WHEN NO_DATA_FOUND` handler in WHEN-VALIDATE-ITEM on `B_PARTY.PARTY_CD` | When the user leaves the Supplier field | Ensures only known, registered suppliers can be selected for a purchase order. | *"Enter a valid Supplier"* is displayed; trigger fails. |
| Unexpected database error during supplier lookup | `WHEN OTHERS` handler in WHEN-VALIDATE-ITEM on `B_PARTY.PARTY_CD` | When the user leaves the Supplier field | Surfaces any unanticipated database failure during supplier validation. | The database error text (sqlerrm) is displayed; trigger fails. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-014-ES-01** - Supplier not found - *"Enter a valid Supplier"*; trigger fails; cursor remains on Supplier field.
- **BR-014-ES-02** - Database error during supplier lookup - database error text (sqlerrm) is displayed; trigger fails.

**Alternative Flows:**
- **BR-014-AF-01** - (from Step 1) Supplier code field is blank: no lookup is performed; the field is left empty with no error.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Supplier (`PARTY_CD`) | Mandatory | Text | N/A | Supplier master (`GM_PARTY`) | Party code | PO Details panel open; location mode known | Must exist in party master as an active supplier of the correct type | *"Enter a valid Supplier"* |
| Supplier Name (`PARTY_NAME`) | Auto-populated | Text | N/A | N/A | Retrieved from party master on valid supplier entry | Supplier code entered | Read-only; system-set on successful lookup | N/A |

---

---

#### Requirement ID: BR-015

**Requirement Title:** Save and Commit SOQ Amendments

**Business Description:**
When the user commits changes to the SOQ records, the system validates the form state, attempts to write all changes to the database, checks that the commit succeeded, and then refreshes the results grid and re-applies the category and location pre-population so the form reflects the saved data. The toolbar Save button also gates this action - if the Save button is not enabled, the commit does not proceed. The user may also cancel any unsaved changes via the Cancel toolbar button, which prompts for confirmation before discarding; and may delete the current record via the Delete toolbar button after confirming the deletion.

**Actors:** Dealership User

**Preconditions:**
- The form is open.
- For the Save flow: the user has made changes to one or more SOQ records and initiates a save/commit action via the toolbar Save button (PB_SAVE) or the standard keyboard commit.
- For the Cancel flow: the user wishes to discard unsaved changes via the toolbar Cancel button (PB_CANCEL).
- For the Delete flow: the user wishes to delete the current record via the toolbar Delete button (PB_DEL).

**Main Flow:**

**Step 1 - Form state is entered and validated before commit**
The system calls the ENTER function to process all pending form-level input and then checks that no form-level failure has occurred. If a failure is detected at this stage, the commit is aborted.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-004](#SP-004--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE (attached library DPL) - checks whether the form is in a failure state following the ENTER call; if so, raises a form trigger failure to abort the commit.
    * **Step 1** - Check whether the most recent form operation (ENTER) resulted in a failure state.
    * **Step 2** - If the form is in failure, raise a trigger failure to stop processing; otherwise return control.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Form state is valid before commit | GENERAL.CHECK_FORM_FAILURE [SP-004] called after ENTER in KEY-COMMIT | When the user initiates a save | Prevents a database commit from proceeding when the form has detected a pending validation error. | Commit is aborted; the form remains open with the current data. |

**Step 2 - Changes are committed to the database**
The system issues the database commit operation to write all pending changes.

**Step 3 - Commit success is verified**
After the commit, the system checks the form state again. If the commit encountered a failure, the error is surfaced.

*Procedures called:*
- **GENERAL.CHECK_FORM_FAILURE** ([SP-004](#SP-004--GENERAL.CHECK_FORM_FAILURE)) - GENERAL.CHECK_FORM_FAILURE (attached library DPL) - verifies the form state after the commit to confirm it succeeded.
    * **Step 1** - Check whether the most recent form operation (COMMIT_FORM) resulted in a failure state.
    * **Step 2** - If the form is in failure, raise a trigger failure to signal the commit error; otherwise return control.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Commit must succeed | GENERAL.CHECK_FORM_FAILURE [SP-004] called after COMMIT_FORM in KEY-COMMIT | After the database commit is issued | Detects any database-level rejection of the commit and prevents the form from clearing as if the save had succeeded. | Commit failure is raised; the form remains open with uncommitted data. |

**Step 4 - Form is cleared after successful commit**
Once the commit has been verified as successful, the system issues the form-clear action (equivalent to pressing the Clear Form key) to reset the form to its starting state, ready for the next user action.

**Step 5 - Toolbar Save button: results grid is re-queried and filter state is refreshed after save**
When the save is initiated through the toolbar Save button (PB_SAVE) and that button is currently enabled, the system additionally: commits the form via the standard commit key action, re-queries the SOQ results block to reflect the saved data, refreshes the "To Date" display field with the current system date, temporarily suspends form validation, calls the category and location pre-population routine, then restores form validation. If the Save toolbar button is not enabled, no action is taken.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

*Procedures called:*
- **LOC_CATEG_POPULATION** ([SP-013](#SP-013--LOC_CATEG_POPULATION)) - LOC_CATEG_POPULATION (form program unit) - re-populates the Parts Category filter and pre-selects locations from the saved SOQ data after a successful save. See BR-022 for full detail.

**Step 6 - Toolbar Cancel button: user is asked to confirm discarding unsaved changes**
When the user presses the toolbar Cancel button (PB_CANCEL) and that button is currently enabled, the system checks whether any changes have been made to the form. If the form status is CHANGED, the system prompts the user to confirm that the unsaved data will be discarded before clearing the form.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User confirms discarding unsaved changes | `IF :system.form_status = 'CHANGED' THEN lv_al_id := GENERAL.ASK_CONFIRM(...)` in FT_CANCEL (OG_GROUP) | When the user presses the Cancel toolbar button with unsaved changes | Prevents the user from accidentally losing work by requiring explicit confirmation before the form is cleared. | *"Entered data will not be Saved"* is shown; if the user confirms (response = 1), the form is cleared; otherwise the form remains as-is. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-WS-01** - User confirmed cancel - *"Entered data will not be Saved"* was acknowledged; form is cleared and all unsaved amendments are discarded.
- **BR-015-IC-01** - No unsaved changes on cancel - form is cleared immediately without a prompt.

**Step 7 - Toolbar Delete button: user is asked to confirm deletion of the current record**
When the user presses the toolbar Delete button (PB_DEL) and that button is currently enabled, the system temporarily disables form-level validation, checks whether the form has unsaved changes, and prompts the user to confirm the deletion before proceeding.

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User confirms deletion of the current record | `IF :system.form_status = 'CHANGED' THEN lv_al_id := GENERAL.ASK_CONFIRM('Are you sure to Delete')` in FT_DEL (OG_GROUP) | When the user presses the Delete toolbar button with the form in CHANGED state | Prevents accidental deletion of data by requiring explicit confirmation before the record is removed. | *"Are you sure to Delete"* is shown; if the user confirms (response = 1), the record is deleted; otherwise the form is cleared without deletion. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-WS-02** - User confirmed deletion - *"Are you sure to Delete"* was acknowledged; the current record is deleted.
- **BR-015-IC-02** - No unsaved changes on delete - form is cleared without a deletion prompt.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Amended Quantity (`AMD_SOQ_QTY`) | Optional | Numeric | 9,99,990.990 | N/A | User-entered | SOQ results loaded | Saved to database on commit | Error raised if commit fails |
| Modified By (`MODIFIED_BY`) | Auto-populated | Text | 8 | N/A | Current user identity (set in PRE-UPDATE) | Record modified | Stamped automatically before save | N/A |
| Modified Date (`MODIFIED_DATE`) | Auto-populated | Date/Time | N/A | N/A | Current system date/time (set in PRE-UPDATE) | Record modified | Stamped automatically before save | N/A |
| To Date (`NB_TO_DATE`) | Auto-populated | Date/Time | DD-MM-RRRR | N/A | Reset to current system date after save | Save completed | System-refreshed; read-only | N/A |

---

---

#### Requirement ID: BR-016

**Requirement Title:** Form Exit - Clear Session and Close

**Business Description:**
When the user exits the form, the system clears the database session monitoring entries that were set when the form was opened, and then closes the form without validating or saving any unsaved changes.

**Actors:** Dealership User

**Preconditions:**
- The form is open.

**Main Flow:**

**Step 1 - Session tracking is cleared and form is closed without saving**
When the user exits the form, the system clears the session's client-info register (removing the form's identity) and resets the session module name and action name to blank. The form then closes immediately without prompting to save any pending changes.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Session client-info (`dbms_application_info`) | Auto-populated | N/A | N/A | N/A | Cleared to null on exit | Form open | System-managed; not user-visible | N/A |

---

---

#### Requirement ID: BR-017

**Requirement Title:** Form-Level Error Handling

**Business Description:**
When any Oracle Forms error occurs during the user's work session, the system intercepts it and provides a meaningful, user-friendly message where applicable. Specific error codes are mapped to clear business messages (for example, invalid dates, non-numeric characters entered in numeric fields, concurrent update conflicts, and Oracle referential integrity violations). Errors that do not match known codes are surfaced with the underlying database error text, and the database changes for that operation are rolled back. Certain informational errors (query limit notifications) are silently suppressed.

**Actors:** System (automatic, intercepts every form error event)

**Preconditions:**
- The form is open and any form error event fires.

**Main Flow:**

**Step 1 - Invalid date format error is intercepted and described**
If the error code indicates an invalid date entry (code 50004), the system shows a clear message and aborts the current operation.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the date-validation error message.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue.
    * **Step 3** - Return control to the form after the user acknowledges.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Invalid date (error code 50004) | `IF errnum in (50004)` in ON-ERROR (form level) | When an invalid date error is detected | Provides a clear business message instead of a raw Oracle error code when the user enters a date value that Oracle cannot parse. | *"Entered Date is not valid Date"* is displayed; trigger fails; the form stays open. |

**Step 2 - Incorrect date format error is intercepted and described**
If the error code indicates a date format problem (codes 50025 or 50026), the system shows the expected date format and aborts the current operation.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the date-format message.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue.
    * **Step 3** - Return control to the form after the user acknowledges.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date entered in wrong format (50025/50026) | `IF errnum in (50025,50026)` in ON-ERROR (form level) | When a date format error is detected | Instructs the user on the correct date format rather than showing a raw Oracle error. | *"Enter the Date in the proper format (DD-MM-YYYY)"* is displayed; trigger fails; the form stays open. |

**Step 3 - Non-numeric character error is intercepted and described**
If the error code indicates that characters or special characters were entered in a numeric field (codes 40209 or 50016), the system informs the user to enter a numeric value.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Characters in numeric field (40209/50016) | `IF errnum in (40209,50016)` in ON-ERROR (form level) | When a non-numeric entry error is detected | Gives a plain-English explanation instead of an Oracle Forms code when the user types letters or symbols in a numbers-only field. | *"Characters/Special Characters are not allowed here, enter the numeric value"* is displayed; trigger fails; the form stays open. |

**Step 4 - Field-level Oracle error is displayed with its own message text**
If error code 40207 fires, the system displays the error's own text rather than a generic message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Forms item-level error (40207) | `IF errnum in (40207)` in ON-ERROR (form level) | When an item-level Oracle Forms error occurs | Surfaces the item's own error text directly so the user understands what the specific field-level constraint has been violated. | The error's own text (`errtxt`) is displayed; trigger fails; the form stays open. |

**Step 5 - Oracle referential integrity violation is intercepted**
If a database foreign-key constraint violation occurs (database error code -02292), the system calls the standardised error-raising routine with the integrity error code.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-007](#SP-007--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR (attached library DPL) - looks up and displays the business-level error message for error code E0088 (referential integrity violation).
    * **Step 1** - Receive the error message code from the caller.
    * **Step 2** - Look up the corresponding business error message text for that code.
    * **Step 3** - Display the message to the user and raise a trigger failure.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Referential integrity violation (database code -02292) | `IF Derrnum = -02292 THEN GENERAL.RAISE_ERROR('E0088')` in ON-ERROR (form level) | When a foreign-key constraint violation is detected | Provides a standardised business message when a save or delete would violate a database relationship. | Error message E0088 is displayed via GENERAL.RAISE_ERROR; the form stays open. |

**Step 6 - Concurrent update conflict is intercepted and the operation is rolled back**
If the record being saved has been modified by another user since it was last queried (error codes 40654-40659), the system rolls back the pending changes and tells the user to re-query.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update conflict (40654-40659) | `IF ERROR_CODE IN (40654,40655,40656,40657,40659)` in ON-ERROR (form level) | When a save fails due to a concurrent update conflict | Prevents one user's changes from silently overwriting another user's concurrent changes. | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* is displayed; changes are rolled back; trigger fails. |

**Step 7 - Any remaining SQL error is displayed and rolled back**
If any other non-zero SQL error remains unhandled by the steps above, the system displays the database error text, rolls back any pending changes, and aborts the current operation.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Any other SQL error | `IF sqlcode <> 0 THEN GENERAL.DISP_TEXT(sqlerrm,'Error'); Rollback` in ON-ERROR (form level) | When any other database error occurs | Ensures no database error is silently swallowed; the user always sees an explanation and data integrity is preserved by rolling back. | The database error text (sqlerrm) is displayed; changes are rolled back; trigger fails. |

**Step 8 - Informational query-limit messages are silently suppressed**
Error codes 40401 and 40405 (query-limit informational messages) are intercepted and result in no action - they are silently ignored.

*Business outcomes (errors, warnings, success, and status):*
- **BR-017-ES-01** - Invalid date entered - *"Entered Date is not valid Date"*; trigger fails.
- **BR-017-ES-02** - Date in wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*; trigger fails.
- **BR-017-ES-03** - Characters in a numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*; trigger fails.
- **BR-017-ES-04** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback; trigger fails.
- **BR-017-ES-05** - Other SQL error - database error text (sqlerrm) is displayed; rollback; trigger fails.
- **BR-017-IC-01** - Query-limit notifications (codes 40401, 40405) - silently suppressed; no message shown to user.

---

---

#### Requirement ID: BR-018

**Requirement Title:** Print SOQ Report

**Business Description:**
The user can print the SOQ report by navigating to the Print panel, entering a report date, and pressing the Report button. If a date has been entered, the system executes the print trigger to generate the SOQ report. The user can also press the Back button to return to the purchase order generation screen without printing.

**Actors:** Dealership User

**Preconditions:**
- The user has navigated to the Print panel.

**Main Flow:**

**Step 1 - Report date is entered**
The user enters the "As On Date" for the report in the Print panel. The date format is DD-MM-YYYY.

*Screen: `WN_MAIN` / `CN_DATE`.*

**Step 2 - Report button is pressed and report is triggered**
If the As On Date has been entered, pressing the Report button causes the system to execute the form-level print trigger (FT_PRINT, subclassed from the DPL object group). The print trigger generates the SOQ report (PT_SOQHS) using the date and other filter parameters. If the As On Date is not entered, pressing the Report button has no effect.

*Screen: `WN_MAIN` / `CN_DATE`.*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| As On Date must be entered before printing | `IF :b_prn.nb_as_on_date IS NOT NULL THEN Execute_Trigger('Ft_print')` in WHEN-BUTTON-PRESSED on `B_PRN.PB_REP` | When the user presses the Report button | Prevents the print trigger from executing without a report date, which would generate an incomplete or invalid report. | No action is taken; no error message is shown; the print trigger is simply not called. |

**Step 3 - Back button returns focus to PO Generation**
Pressing the Back button moves focus to the purchase order generation button (`pb_blk.pb_genpo`), allowing the user to proceed to PO generation without printing.

*Screen: `WN_MAIN` / `CN_DATE`.*

**Alternative Flows:**
- **BR-018-AF-01** - (from Step 2) As On Date is blank: pressing the Report button has no effect; no error is shown.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| As On Date (`NB_AS_ON_DATE`) | Conditional - when printing | Date | DD-MM-YYYY | N/A | User-entered | Print panel open | Must be entered before the Report button will trigger the print | No error shown; button press is silently no-op if blank |

---

---

#### Requirement ID: BR-019

**Requirement Title:** Excel Export of SOQ Data

**Business Description:**
The form provides the ability to export SOQ data to a CSV file and open it in the browser. The VIEW_EXCEL_REP program unit accepts a query and column name, executes the query to build an in-memory data set, writes the results to a server-side CSV file named with the current user's identifier and a timestamp, and then opens the file in the user's browser. If the data exceeds the Excel row limit of 65,535 rows, the data is truncated with an informational message. If the file path contains spaces, the file is redirected to the C: drive root with a notification. Any unexpected error is reported.

**Actors:** Dealership User / System

**Preconditions:**
- The VIEW_EXCEL_REP program unit is invoked from a calling context that supplies a valid SQL query and column name. (The program unit is defined in the form; the calling button is subclassed from the DPL library and its trigger code is EXTERNAL / NOT IN BUNDLE - the exact button that calls it cannot be verified from available source.)

**Main Flow:**

**Step 1 - File name is generated**
The system generates a unique CSV file name by combining the current user's login identifier with the current date and time (formatted as YYYYMMDDHHMISS), appending the `.csv` extension.

**Step 2 - File path is checked for embedded space characters**
If the generated file path contains a space in any folder name, the file is redirected to the C: drive root and the user is informed with a notification message.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| File path must not contain spaces | `IF instr(FILENAME,' ') > 0 THEN` in VIEW_EXCEL_REP | When the file name is generated | Prevents the file transfer from failing silently due to a path-with-spaces limitation on the server. | *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* is shown; file is saved to C: root instead. |

**Step 3 - In-memory data set is created from the query**
Any pre-existing in-memory data set with the standard name is deleted, and a new one is created by running the supplied query. The number of rows in the result is counted.

**Step 4 - Row count is checked against the Excel row limit**
If the result set contains more than 65,536 rows, the count is capped at 65,535 and the user is informed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Result truncated at 65,535 rows | `IF the_rowcount > 65536 THEN` in VIEW_EXCEL_REP | When the row count is calculated | Prevents the export from attempting to write more rows than Excel can handle, which would cause a file corruption. | *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* is displayed; the row count is capped at 65,535. |

**Step 5 - Data is written to the server file and opened in the browser**
The system reads the export URL path from a configuration file (`/reports/DMS/excelpath.txt`) on the server, opens the server-side file for writing, writes each row of the data set as a line in the CSV file, closes the file, and then opens the file URL in the user's browser in a new tab.

**Step 6 - Any unexpected error is reported**
If any unexpected error occurs during the export, the system displays a message composed of the error code and error text, and the trigger fails.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unexpected export error | `WHEN OTHERS THEN Message('Error  - '||ERROR_CODE||ERROR_TEXT)` in VIEW_EXCEL_REP | If any unhandled error occurs during export | Ensures the user is informed of any export failure rather than seeing a silent crash. | *"Error  - "* followed by the error code and error text is displayed; trigger fails. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-019-IC-01** - File path contains spaces - *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."*; file is saved to C: root.
- **BR-019-IC-02** - Data truncated - *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."*; export continues with capped row count.
- **BR-019-ES-01** - Unexpected export error - *"Error  - "* (error code and error text appended dynamically); trigger fails.

---

---

#### Requirement ID: BR-020

**Requirement Title:** Consumption Detail Panel Auto-Clear on New SOQ Record Navigation

**Business Description:**
When the user moves between rows in the SOQ results grid, the system automatically clears the consumption detail panel so that stale consumption data from a previously selected part is not displayed for the newly selected row.

**Actors:** System (automatic, triggered on navigation between SOQ result rows)

**Preconditions:**
- The SOQ results grid has been populated and the user navigates between rows.

**Main Flow:**

**Step 1 - Consumption detail panel is cleared on new row selection**
When the cursor moves to a new row in the SOQ results grid, the system clears the consumption detail panel of any previously displayed data and returns to the SOQ results grid. (Note: In an earlier version of the form, this trigger also automatically called the consumption-population procedure to load fresh data for the newly selected part. That automatic loading is currently commented out and does not execute - consumption data is only loaded when the user explicitly presses the Show Consumption button as described in BR-011.)

*Screen: PART AND STOCK DETAILS (`CN_SOQ`).*

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Srl. No. (`NB_SRL_NUM`) | Auto-populated | Numeric | N/A | N/A | Set to current row number | SOQ results populated | Read-only; system-set | N/A |
| Monthly Consumption C1-C12 / Current Stock / On Order (`C1`-`C12`, `CURR_STOCK`, `ON_ORDER`) | Auto-populated | Numeric | N/A | N/A | Cleared on new row navigation | SOQ results populated | System-cleared; reloaded only on explicit Show Consumption action | N/A |

---

---

#### Requirement ID: BR-021

**Requirement Title:** SOQ Calculation Parameter Validation and Where-Clause Construction (BUILD_WHERE)

**Business Description:**
Before an SOQ calculation is executed, the system validates that the user has selected at least one dealer location and at least one inventory classification (ABC class) to include in the calculation. If neither is selected, the user is shown an appropriate error and the calculation cannot proceed. When both validations pass, the system builds the internal scope parameters used to filter the SOQ query.

**Actors:** Dealership User

**Preconditions:**
- The user has configured the SOQ filter parameters and is initiating the SOQ calculation.
- (Note: this logic is implemented in the form-level BUILD_WHERE program unit, which is called by the Calculate SOQ button. The exact calling trigger is in the DPL object library - EXTERNAL / NOT IN BUNDLE - and cannot be independently verified from available source.)

**Main Flow:**

**Step 1 - Location selection is validated**
The system checks the location list to confirm that at least one location's "Consider" checkbox is ticked. If no location is selected, the user sees an error and the calculation is blocked.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-006](#SP-006--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT (attached library DPL) - displays the location-validation error message.
    * **Step 1** - Receive the message text and severity label from the caller.
    * **Step 2** - Present the message in a user-visible alert dialogue.
    * **Step 3** - Return control to the form after the user acknowledges.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one location must be selected | `IF NOT lb_flag THEN general.disp_text('Atlease one location should be considered','Error')` in BUILD_WHERE | When the SOQ calculation is initiated | Ensures the SOQ is always scoped to at least one meaningful dealer location; a zero-location scope would produce an empty or invalid calculation. | *"Atlease one location should be considered"* is displayed; trigger fails and the calculation is blocked. |

**Step 2 - Inventory classification selection is validated**
The system checks the inventory classification checkboxes (A, B, C, and Other). If none of the four are ticked, the user sees an error.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| At least one inventory classification must be selected | `IF NVL(:sb_title.check_a,'N') = 'N' AND ... THEN general.disp_text('Atlease one Inventory Clasification should be considered','Error')` in BUILD_WHERE | When the SOQ calculation is initiated | Ensures the SOQ always covers at least one parts classification; calculating an SOQ with no classification filter would produce meaningless or unscoped results. | *"Atlease one Inventory Clasification should be considered"* is displayed; trigger fails and the calculation is blocked. |

**Step 3 - Scope parameters are built for the query**
When both validations pass, the system collects the location codes for all ticked locations and builds the inventory classification filter string from the ticked classification checkboxes. These scope parameters are passed to the SOQ calculation query.

*Business outcomes (errors, warnings, success, and status):*
- **BR-021-ES-01** - No location selected - *"Atlease one location should be considered"*; trigger fails.
- **BR-021-ES-02** - No inventory classification selected - *"Atlease one Inventory Clasification should be considered"*; trigger fails.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Inventory Classification A (`CHECK_A`) | Optional | Checkbox | 1 | N/A | Y / N | Form open | At least one of A, B, C, Other must be checked | *"Atlease one Inventory Clasification should be considered"* |
| Inventory Classification B (`CHECK_B`) | Optional | Checkbox | 1 | N/A | Y / N | Form open | At least one of A, B, C, Other must be checked | *"Atlease one Inventory Clasification should be considered"* |
| Inventory Classification C (`CHECK_C`) | Optional | Checkbox | 1 | N/A | Y / N | Form open | At least one of A, B, C, Other must be checked | *"Atlease one Inventory Clasification should be considered"* |
| Other Classification (`CHECK_NULL`) | Optional | Checkbox | 1 | N/A | Y / N | Form open | At least one of A, B, C, Other must be checked | *"Atlease one Inventory Clasification should be considered"* |

---

---

#### Requirement ID: BR-022

**Requirement Title:** SOQ Category and Location Pre-Population from Existing SOQ Data (LOC_CATEG_POPULATION)

**Business Description:**
When an SOQ has already been calculated, the system can automatically pre-populate the Parts Category filter and pre-select the relevant locations by reading from the existing SOQ data. If SOQ records exist for the current dealer/location context, the category of the first SOQ part is read and placed in the Parts Category filter, and all locations already included in the existing SOQ are pre-ticked in the location list.

**Actors:** System

**Preconditions:**
- An SOQ calculation has previously been performed and SOQ records exist for the current dealer/location context.
- (Note: LOC_CATEG_POPULATION is a form-level program unit. The exact trigger that calls it is in the DPL object library - EXTERNAL / NOT IN BUNDLE - and cannot be independently verified from available source.)

**Main Flow:**

**Step 1 - Existing SOQ record count is checked**
The system queries the SOQ data table for the current dealer/location/parent-group/company context and counts how many SOQ records exist.

**Step 2 - Parts category is pre-populated from the first SOQ part**
If SOQ records exist, the system reads the category code of the first SOQ part and populates the Parts Category filter. If any error occurs during this lookup, the category field is left unchanged (no error is shown to the user).

**Step 3 - Previously included locations are pre-selected**
The system queries the SOQ data for all distinct locations included in the existing SOQ and pre-ticks those locations in the location selection list.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Parts Category (`PART_CATEG`) | Auto-populated | Text | N/A | Parts category master | Derived from first SOQ part | Existing SOQ records present | Silently left unchanged if lookup fails | N/A |
| Location(s) Considered (`CHECK_YN`) | Auto-populated | Checkbox | 1 | SOQ data | Pre-ticked for locations in existing SOQ | Existing SOQ records present | System-set; user can override | N/A |

---

---

#### Requirement ID: BR-023

**Requirement Title:** On-Order Quantity Update for Purchase Order Generation (UPDATE_PO_STOCK)

**Business Description:**
When generating a purchase order from the amended SOQ quantities, the system collects all amended order quantities from the SOQ results grid, passes them to the on-order update procedure with the PO Status and user identity, and updates the on-order quantity for each part accordingly. If the procedure returns an error, the error message is displayed in an error panel and processing is blocked.

**Actors:** System (called when the user generates a purchase order - the exact calling trigger is in the DPL object library, EXTERNAL / NOT IN BUNDLE)

**Preconditions:**
- The user has reviewed and amended SOQ quantities, entered PO details (supplier and PO status), and is generating a purchase order.

**Main Flow:**

**Step 1 - Amended quantities are collected for all SOQ rows**
The system navigates to the SOQ results block, reads every part's part number and amended order quantity from all rows, and assembles this information into an order list.

**Step 2 - On-order update is submitted to the database**
The system calls the on-order update procedure with the assembled order list, the selected PO Status, the current dealer context, and the current user's identity. The procedure updates the on-order quantities and returns a result code and message.

*Procedures called:*
- **PK_VALIDATE_PARTS.UPDATE_ON_ORDER** ([SP-008](#SP-008--PK_VALIDATE_PARTS.UPDATE_ON_ORDER)) - PK_VALIDATE_PARTS.UPDATE_ON_ORDER (standalone package procedure) - receives the ordered list of part numbers and quantities, the PO status, and the dealer/location context, and updates the on-order stock figures in the database.
    * **Step 1** - Accept the parent group, dealer, location, order list, PO status, and user identity as inputs.
    * **Step 2** - Validate each part number and quantity in the order list against the database.
    * **Step 3** - Apply business rules and validations for the on-order update.
    * **Step 4** - Update the on-order quantities for each part in the database if all validations pass.
    * **Step 5** - Return an error code and error message to the caller; a non-zero error code indicates that the update failed.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| On-order update must succeed | `IF lv_err_cd <> 0 THEN` in UPDATE_PO_STOCK after PK_VALIDATE_PARTS.UPDATE_ON_ORDER [SP-008] call | When the on-order update procedure completes | Prevents partial or invalid on-order stock updates from being accepted; any failure from the procedure must be surfaced to the user. | The error message returned by the procedure is displayed in the error panel; the error canvas is shown; trigger fails. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-023-ES-01** - On-order update failed - error message returned by the procedure is displayed in the error detail panel; processing is blocked.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Part Number (`PART_NUM`) | Read-only display | Text | 15 | N/A | From SOQ results | SOQ results loaded | N/A | N/A |
| Amended Quantity (`AMD_SOQ_QTY`) | Optional | Numeric | 9,99,990.990 | N/A | User-entered or defaulted | SOQ results loaded | Validated by on-order update procedure | Error message shown if procedure rejects |
| PO Status (`PO_STATUS`) | Mandatory | Text | 10 | N/A | Entered in PO Details panel | PO Details entered | Passed to on-order update procedure | Error shown if procedure fails |

---

---

#### Requirement ID: BR-024

**Requirement Title:** Form-Level Message Interception for Input-Error Codes

**Business Description:**
A form-level ON-MESSAGE trigger is active on this form. When Oracle Forms raises an informational message with error code 40209 or 40207, the system intercepts the message event, formats and displays it as an explicit error dialogue (error type, error code, and error text), and then raises a form trigger failure to prevent the message from being processed further as an informational event. Messages with any other code are handled by the standard Oracle Forms message mechanism.

**Actors:** System (automatic, intercepts specified Oracle Forms message events)

**Preconditions:**
- The form is open and an Oracle Forms message event fires with error code 40209 or 40207.

**Main Flow:**

**Step 1 - Forms message event is intercepted and checked against known codes**
When any Oracle Forms message event fires, the system reads the error number, error text, and error type from the event context. If the error number is 40209 or 40207, the system formats and displays it as an explicit error message and raises a failure to block further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Known input-error message codes intercepted (40209, 40207) | `IF errnum in (40209,40207)` in ON-MESSAGE (form level) | When Oracle Forms raises a message event with one of these codes | Converts informational message events for codes 40209 (characters not allowed in numeric field) and 40207 (item-level validation error) into explicit error dialogues so the user clearly understands the issue. | The error is formatted and displayed via `GENERAL.DISP_TEXT`; trigger fails; the message event is suppressed. |

*Business outcomes (errors, warnings, success, and status):*
- **BR-024-ES-01** - Forms message event code 40209 or 40207 intercepted - the message is displayed as a formatted error (error type, code, and text); the event is suppressed and the trigger fails.
- **BR-024-IC-01** - Forms message event with any other code - not intercepted; standard Oracle Forms message handling applies.

---

---

#### Requirement ID: BR-025

**Requirement Title:** Custom LOV Invocation via F9 Key (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
A form-level KEY-LISTVAL trigger exists in the form's source code (inherited from the DPL library property class PC_FORM). It is fully commented out and does not execute. When active, it would show the LOV associated with the current field when the user pressed F9, and if the user made a selection, would advance to the next field. This behaviour is currently disabled.

**Actors:** N/A (trigger does not execute)

**Preconditions:** N/A

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)** The KEY-LISTVAL trigger body is fully commented out. Standard LOV invocation via the keyboard does not occur through this trigger.

---

---

#### Requirement ID: BR-026

**Requirement Title:** Navigation Key Overrides on SOQ Header Block

**Business Description:**
KEY-DOWN and KEY-UP triggers are active on the SOQ header block (SB_TITLE) through the OG_GROUP object group. Pressing the Down arrow key moves the cursor to the next record in the block; pressing the Up arrow key moves the cursor to the previous record. These overrides replace the default Forms navigation with explicit record-by-record movement on the header block.

**Actors:** Dealership User

**Preconditions:**
- The form is open and the cursor is positioned within the SOQ header block (SB_TITLE).

**Main Flow:**

**Step 1 - Down arrow key moves cursor to the next record in the header block**
When the user presses the Down arrow key while in the SOQ header block, the system advances the cursor to the next record in that block.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

**Step 2 - Up arrow key moves cursor to the previous record in the header block**
When the user presses the Up arrow key while in the SOQ header block, the system moves the cursor back to the previous record in that block.

*Screen: SUGGESTED ORDER QUANTITY PROCESSING (`WN_MAIN` / `CN_MAIN`).*

---

---

#### Requirement ID: BR-027

**Requirement Title:** WebUtil Component Event Handlers (COMMENTED OUT / INACTIVE - does not execute)

**Business Description:**
The form contains a WEBUTIL block with several WHEN-CUSTOM-ITEM-EVENT triggers (for client-info, file functions, host functions, session functions, file-transfer, OLE, C API, and browser functions) and a WHEN-BUTTON-PRESSED trigger on the DUMMY item. All of these are inactive/commented out and do not execute. They are part of the standard WebUtil integration component included in the form.

**Actors:** N/A (triggers do not execute)

**Preconditions:** N/A

**Main Flow:**

**Step 1 - (COMMENTED OUT / INACTIVE - does not execute)** All WEBUTIL block triggers are inactive. No WebUtil client-side event handling is active in this form.

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Parts Category is mandatory | Validation | BR-002 | Parts Category field is left blank when the user navigates away | Block navigation and alert the user that Parts Category is required | Prevents an SOQ calculation from being launched without a parts category, which would produce unscoped results |
| BRC-002 | Number of months is mandatory | Validation | BR-003 | Number of months field is left blank when the user navigates away | Display *"Enter the Number of months of consumption to be considered"* and block navigation | Ensures every SOQ calculation has a defined historical consumption horizon |
| BRC-003 | Parts Category defaulted on form reset | Derivation | BR-001 | Form is cleared or reset | Set the Parts Category filter to the standard default value automatically | Guarantees a consistent starting category for each new session |
| BRC-004 | Show Zero SOQ defaulted to off on form reset | Derivation | BR-001 | Form is cleared or reset | Set the Show Zero SOQ flag to off automatically | Ensures the SOQ results grid starts showing only meaningful (non-zero) quantities by default |
| BRC-005 | Pending SOQ changes saved before filter toggle | Constraint | BR-006 | Show Zero SOQ checkbox is changed while unsaved amendments exist | Save all pending changes before refreshing the grid | Prevents loss of quantity amendments when the user toggles the zero-SOQ filter |
| BRC-006 | Part not found in price master defaults to zero | Derivation | BR-007 | Part number has no record in the parts price and settings table when the SOQ row is loaded | Set purchase price to 0, minimum pack quantity to 0, and decimal-quantity flag to 'N' | Allows SOQ rows to display and be amended even when the parts master is incomplete |
| BRC-007 | Data width error on part details defaults and aborts row | Validation | BR-007 | A retrieved value for a part row is too wide for the receiving field | Default price and settings to zero/N and abort loading that row with *"Width problem while fetching details for part number "* (part number appended) | Protects data integrity when a parts master value cannot fit in the receiving field |
| BRC-008 | Decimal quantity truncation for non-decimal parts | Constraint | BR-008 | Amended Quantity is entered for a part that does not allow decimal quantities | Truncate the entered value to the nearest whole number | Ensures parts sold only in whole-number pack quantities are not ordered in fractions |
| BRC-009 | Decimal allowance error flag blocks amended quantity entry | Validation | BR-008 | Allow-decimal flag is in error state ('E') when the user leaves the Amended Quantity field | Display *"Error while judging to allow Amended SOQ Quantity in decimal."* and block navigation | Prevents saving an amended quantity when the system cannot determine whether decimals are allowed |
| BRC-010 | Modified-by and modified-date stamped before save | Derivation | BR-009 | An SOQ record has been changed and is about to be saved | Automatically set the Modified By field to the current user's identity and the Modified Date to the current system date/time | Provides a complete audit trail of who changed each SOQ record and when |
| BRC-011 | Sort order applied on Sort By or Sort Type change | Derivation | BR-010 | The Sort By or Sort Type list selection is changed | Save pending changes, reset the sort order for the SOQ results block, clear and re-execute the query | Ensures the user always sees results in their chosen order without losing edits |
| BRC-012 | Part Number must be selected before showing consumption | Validation | BR-011 | Show Consumption button is pressed when no part row is selected | Display *"Part Number Not available to show consumption"* | Prevents the consumption detail panel from being loaded without a part context |
| BRC-013 | Root part number must exist for consumption display | Validation | BR-011 | Root part number lookup returns no row for a dealer location during consumption loading | Display *"Root Part Number not found for this Part Number"* (part number appended) and abort | Ensures consumption data is only shown for parts with a valid root-part mapping |
| BRC-014 | Only one root part number may exist per part | Constraint | BR-011 | Root part number lookup returns more than one row | Display *" More than one  Root Part Number found "* and abort | Prevents ambiguous consumption data from being displayed when a part maps to multiple root parts |
| BRC-015 | Supplier list assigned based on operating mode | Derivation | BR-012 | PO Details block becomes active | Assign the multi-location or single-location supplier list to the Supplier field based on the consignee-level flag | Ensures users can only select suppliers appropriate to the current operating mode |
| BRC-016 | PO Status is mandatory | Validation | BR-013 | PO Status field is left blank when the user navigates away | Block navigation and alert the user that PO Status is required | Prevents a purchase order from being raised without a status value |
| BRC-017 | Supplier code must exist in party master | Validation | BR-014 | Supplier code entered does not match any supplier in the party master for the current mode | Display *"Enter a valid Supplier"* and block navigation | Ensures only registered, valid suppliers can be selected for a purchase order |
| BRC-018 | Form state validated before commit | Validation | BR-015 | User initiates save; form is in a failure state after ENTER | Abort the commit and keep the form open | Prevents a database commit from proceeding when the form has a pending validation error |
| BRC-019 | Commit success verified after save | Validation | BR-015 | COMMIT_FORM completes; form is still in a failure state | Raise failure to signal the commit did not succeed | Surfaces any database-level commit rejection so the user is not misled into thinking data was saved |
| BRC-020 | Invalid date intercepted at form level | Validation | BR-017 | Oracle Forms error code 50004 fires | Display *"Entered Date is not valid Date"* and abort the current operation | Gives the user a clear plain-English message instead of a raw Oracle error code for date entry errors |
| BRC-021 | Incorrect date format intercepted at form level | Validation | BR-017 | Oracle Forms error codes 50025 or 50026 fire | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and abort | Instructs the user on the correct date format rather than showing a raw Oracle error |
| BRC-022 | Non-numeric character in numeric field intercepted | Validation | BR-017 | Oracle Forms error codes 40209 or 50016 fire | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and abort | Provides a plain-English explanation when the user types non-numeric characters in a numbers-only field |
| BRC-023 | Concurrent update conflict rolled back | Constraint | BR-017 | Oracle Forms error codes 40654-40659 fire | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back, and abort | Prevents one user's changes from silently overwriting another user's concurrent changes |
| BRC-024 | Referential integrity violation surfaced with business error | Validation | BR-017 | Database error code -02292 fires | Call GENERAL.RAISE_ERROR with code E0088 to display the corresponding business error message | Provides a standardised business message when a save or delete violates a database relationship constraint |
| BRC-025 | Unexpected SQL error displayed and rolled back | Constraint | BR-017 | Any remaining non-zero SQL error occurs | Display the database error text, roll back, and abort | Ensures no database error is silently ignored; data integrity is preserved by rolling back |
| BRC-026 | At least one location must be selected for SOQ calculation | Validation | BR-021 | SOQ calculation is initiated with no location selected | Display *"Atlease one location should be considered"* and block the calculation | Prevents an SOQ calculation from running against an empty location scope |
| BRC-027 | At least one inventory classification must be selected | Validation | BR-021 | SOQ calculation is initiated with none of A, B, C, or Other classifications checked | Display *"Atlease one Inventory Clasification should be considered"* and block the calculation | Prevents an unscoped SOQ calculation that would produce meaningless or unfiltered results |
| BRC-028 | Excel export truncated at 65,535 rows | Constraint | BR-019 | The Excel export data set contains more than 65,536 rows | Truncate to 65,535 rows and display *"Maximum number of rows in excel exceeded. It will truncate to 65535 rows."* | Prevents the export from attempting to write more rows than Excel can handle |
| BRC-029 | Excel file redirected to C: root if path contains spaces | Constraint | BR-019 | The generated file path contains a space in a folder name | Redirect the file to the C: drive root and display *"File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default."* | Prevents a silent file-transfer failure caused by path-with-spaces limitations on the server |
| BRC-030 | Consumption procedure error surfaces and aborts display | Validation | BR-011 | SP_SOQ_POPULATE_CONSUMPTION returns a non-zero error code | Display the error message returned by the procedure and abort consumption loading for that location | Ensures any consumption-data retrieval failure is surfaced to the user |
| BRC-031 | On-order update failure displays error in error panel | Validation | BR-023 | PK_VALIDATE_PARTS.UPDATE_ON_ORDER returns a non-zero error code | Display the procedure's error message in the error detail panel and block further processing | Prevents a purchase order from being generated when the on-order update has failed |

**Total Business Rules Identified: 31**

---

## 6. Data Requirements

*This section documents the data entities persisted and referenced by the Suggested Order Quantity Processing form, the fields the form captures or displays, the reference data it uses for lookups, and the lifecycle behaviour of its records.*

### 6.1 Business Entities and Relationships

*The form's primary data object is the multi-location SOQ record table. The form reads from and writes to this table and enriches each row with supplementary parts master information.*

#### Suggested Order Quantity - PT_SOQ_MUL_NEW (via B_SOQ)

The SOQ table holds one row per part number per dealer/location/company combination representing the calculated and user-amended suggested order quantity for that part. Each row carries the SOQ quantity as computed by the system, the user's amended quantity, the as-on date of the last SOQ run, and audit stamps. This is the only database table the form directly writes to.

#### Entity Relationships

The SOQ record table is the sole entity the form persists to. Parts master tables (`PM_PART`, `PM_PART_VAR`) are read by the form's POST-QUERY trigger to enrich each SOQ row with pricing and decimal-quantity settings, but the form never writes to them. The dealer location master (`AM_DEALER_LOC`) is read by the FETCH_LOC program unit to populate the location selection list. The party/supplier master (`GM_PARTY`) is read to validate and look up supplier names. None of these lookup tables have a master-detail relationship with the SOQ table as implemented by this form; they are code-to-description lookups.

```
PT_SOQ_MUL_NEW (Suggested Order Quantity)
    - sole entity written by this form -
    reads PM_PART / PM_PART_VAR for part pricing (enrichment, not a child relationship)
    reads AM_DEALER_LOC for location list population
    reads GM_PARTY for supplier validation
    reads PM_CATEGORY for SOQ category description
```

### 6.2 Data Capture Requirements

*The form captures SOQ calculation parameters entered by the user, enriches each SOQ row from the parts master, and accepts user amendments to the suggested quantities. Mandatory status is as evidenced by validation triggers and code.*

#### SOQ Calculation Parameters (Dealership User - before running SOQ)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Parts Category (`PART_CATEG`) | Yes | The parts classification category to include in the SOQ calculation run. Defaulted to the standard category on form reset. | Must not be blank - GENERAL.CHECK_NULL validates on leaving the field. |
| Consider Months Consumption (`NO_MONTHS`) | Yes | The number of months of historical consumption data to consider when calculating suggested quantities. | Must not be blank - validated on leaving the field; displays *"Enter the Number of months of consumption to be considered"* if blank. |
| Consigne Level (`CHK_STK_YARD`) | No | Whether to expand the calculation scope to all live locations under the consignee (Y) or use only the current single location (N). Triggers a location list reload when changed. | No direct validation; system reloads the location list on change. |
| Inventory Classification A (`CHECK_A`) | Conditional | Whether to include Class A parts (high-value/high-movement) in the SOQ. At least one of A, B, C, or Other must be ticked before a calculation can be run. | At least one of A, B, C, or Other required - validated by BUILD_WHERE when the calculation is initiated. |
| Inventory Classification B (`CHECK_B`) | Conditional | Whether to include Class B parts in the SOQ. | Same as CHECK_A. |
| Inventory Classification C (`CHECK_C`) | Conditional | Whether to include Class C parts in the SOQ. | Same as CHECK_A. |
| Other Classification (`CHECK_NULL`) | Conditional | Whether to include parts with no ABC classification in the SOQ. | Same as CHECK_A. |
| Show zero SOQ (`SHOW_ZERO_SOQ`) | No | Toggle to include parts with a suggested order quantity of zero in the results grid. Defaulted to off on form reset. | No direct validation; triggers a results grid refresh when changed. |
| Sort By (`NB_SORT_BY`) | No | The column by which to sort the SOQ results grid (Part Number, SOQ Quantity, Amended Quantity, Purchase Price, or Value). | No validation; triggers a re-sort and grid refresh when changed. |
| Sort Type (`NB_SORT_TYPE`) | No | The sort direction for the results grid (ascending or descending). | No validation; triggers a re-sort and grid refresh when changed. |

#### Location Selection (Dealership User - before running SOQ)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Location(s) Considered (`LOC_DESC`) | Auto-Populated | The dealer location description, loaded by the FETCH_LOC program unit based on the consignee context and scope flag. Not directly editable. | At least one location must be ticked - validated by BUILD_WHERE; *"Atlease one location should be considered"* if none selected. |
| Consider (`CHECK_YN`) | Conditional | Whether this location is included in the SOQ calculation scope. Rows with no description are automatically deleted when unchecked. | At least one location must remain checked before the calculation is initiated. |

#### SOQ Results - Amended Quantities (Dealership User - after SOQ query)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Part Number (`PART_NUM`) | Auto-Populated | The part number as stored in the SOQ table. Read-only; displayed from the query result. | N/A - display only. |
| Part Description (`PART_DESC`) | Auto-Populated | The description of the part. Read-only; displayed from the query result. | N/A - display only. |
| On Hand Quantity (`ON_HAND_QTY`) | Auto-Populated | The current stock on hand for this part at the dealer location. | N/A - display only. |
| On Order Quantity (`ON_ORDER_QTY`) | Auto-Populated | The current quantity on order for this part. | N/A - display only. |
| SOQ Quantity (`SOQ_QTY`) | Auto-Populated | The suggested order quantity calculated by the system. | N/A - display only. |
| Average Consumption (`AVG_CONSUMPTION`) | Auto-Populated | The average monthly consumption figure for this part. | N/A - display only. |
| Amended Quantity (`AMD_SOQ_QTY`) | No | The user's amendment to the suggested order quantity. Can be edited; if the part does not allow decimal quantities, the value is automatically truncated to a whole number. | If the decimal-quantity flag is in error state, displays *"Error while judging to allow Amended SOQ Quantity in decimal."*; otherwise truncated if part is whole-number only. |
| Purchase Price (`NB_PUR_PRICE`) | Auto-Populated | The current purchase price for this part, retrieved from the parts price variant table. | Defaults to 0 if no price record exists. |
| Minimum Pack Quantity (`NB_MIN_ORD_QTY`) | Auto-Populated | The minimum order pack quantity for this part, retrieved from the parts master. | Defaults to 0 if no record exists. |
| Total Value (`NB_TOT_VALUE`) | Auto-Populated | The total order value for this part row (amended quantity × purchase price). | N/A - display only. |

#### PO Details (Dealership User - after reviewing SOQ, before generating PO)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Supplier (`PARTY_CD`) | Yes | The supplier code for the purchase order. Selectable via a look-up list that is automatically assigned based on the operating mode (standard or consignee-level). | Must exist in the supplier master for the current mode; *"Enter a valid Supplier"* if not found. |
| Supplier Name (`PARTY_NAME`) | Auto-Populated | The supplier's name, automatically populated when a valid supplier code is entered. | Read-only; system-set from supplier master. |
| PO Status (`PO_STATUS`) | Yes | The status to assign to the purchase order. | Must not be blank - GENERAL.CHECK_NULL validates on leaving the field. |
| Last SOQ Category (`NB_SOQ_CATG`) | Auto-Populated | The category description of the last SOQ run, displayed for reference. | Read-only; system-set. |
| Total (`TOT_VALUE`) | Auto-Populated | The total order value across all SOQ lines. | Read-only; system-set. |

#### Print Parameters (Dealership User - when printing SOQ report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| As On Date (`NB_AS_ON_DATE`) | Conditional | The report date used as the reference date for the SOQ summary report (PT_SOQHS). The Report button only triggers printing when this date has been entered. | No explicit validation error shown; if blank, pressing the Report button has no effect. |

#### Session and Non-Database Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| SOQ Population Flag (`P_SOQ_POP`) | Auto-Populated | Internal flag indicating whether the SOQ has been populated for the current session. Reset to 'N' on form clear; used by calling contexts to determine form state. | System-managed; not user-editable. |
| Consignee Code (`P_CONSG_CD`) | Auto-Populated | The consignee code passed in at form startup; used by FETCH_LOC to scope the location list. | Passed from the calling environment; not editable within the form. |
| Stock Yard / Consignee Mode Flag (`P_STOCK_YARD`) | Auto-Populated | Whether the form is running in consignee-level (Y) or single-location (N) mode. Controls location loading and supplier list assignment. | Passed from the calling environment; not editable within the form. |
| Inventory Classification Filter (`P_ABC`) | Auto-Populated | The ABC class filter string built by BUILD_WHERE from the ticked classification checkboxes; passed to the SOQ query. | System-built; not directly editable. |
| Print Flag (`P_PRINT`) | Auto-Populated | Controls print behaviour for the report trigger. | Passed from the calling environment. |
| Report ID (`P_REP_ID`) | Auto-Populated | The report identifier passed to the print trigger. | Passed from the calling environment. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by the form for lookups, list population, and validation.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer location master (`AM_DEALER_LOC`) | Provides the list of live dealer locations under the consignee and principal for the current session; used to populate the location selection list. | When the form is initialised, when the Consigne Level checkbox is changed, and when the form is reset. |
| Supplier list - standard mode (`LV_NON_MUL_PARTY` / `RG_NON_MUL_PARTY`) | Provides the list of standard (non-multi-location) suppliers (`GM_PARTY` where `PARTY_TYPE = 'S'` and `MUL_YN != 'Y'`) for selection in the PO Details panel when not in consignee-level mode. | When the user navigates to the PO Details panel in standard mode. |
| Supplier list - consignee mode (`LV_MUL_PARTY` / `RG_MUL_PARTY`) | Provides the list of multi-location suppliers (`GM_PARTY` where `PARTY_TYPE = 'S'` and `MUL_YN = 'Y'`) for selection in the PO Details panel when in consignee-level mode. | When the user navigates to the PO Details panel in consignee-level mode. |
| Parts master (`PM_PART`) | Provides the decimal-quantity flag, minimum pack quantity, and category code for each SOQ part. Also used to look up the root part number for the consumption display. | When each SOQ row is loaded into the results grid (POST-QUERY), and when the Show Consumption button is pressed. |
| Parts price variant master (`PM_PART_VAR`) | Provides the current purchase price for each SOQ part at the dealer/location level. | When each SOQ row is loaded into the results grid (POST-QUERY). |
| Parts category master (`PM_CATEGORY`) | Provides the category description for the last SOQ run, displayed in the Last SOQ Category field. | When the form is initialised (GET_LAST_SOQ_DATE). |
| SOQ header table (`PT_SOQ_MUL_NEW`) | Provides the date and category of the most recently completed SOQ run for the current dealer/location/company context. | When the form is initialised (GET_LAST_SOQ_DATE) and when pre-populating the category filter (LOC_CATEG_POPULATION). |
| SOQ location data (`PT_SOQ_NEW`) | Provides the list of locations previously included in an SOQ, used to pre-tick those locations in the location selection list. EXTERNAL / NOT IN BUNDLE for full schema details. | When LOC_CATEG_POPULATION is called to pre-populate the location and category from existing SOQ data. |

### 6.4 Data Lifecycle

*Describes how SOQ records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- New SOQ records are created by the SOQ calculation process that runs outside this form (via the DPL-subclassed Calculate SOQ button; the exact triggering mechanism is EXTERNAL / NOT IN BUNDLE). This form reads the calculated results from `PT_SOQ_MUL_NEW` via the SOQ results grid query.

**Updates**

- The user can amend the Suggested Order Quantity by entering a value in the Amended Quantity field. These amendments update the existing SOQ rows in `PT_SOQ_MUL_NEW`.
- Before any updated SOQ row is written to the database, the PRE-UPDATE trigger on the SOQ results block automatically sets the Modified By field to the current user's login identity and the Modified Date field to the current system date and time.

**Save and Commit**

- Changes are committed to the database by the KEY-COMMIT trigger. This trigger first calls ENTER to finalise all form input, checks for form failures, issues COMMIT_FORM to write changes to the database, checks that the commit succeeded, and then clears the form to its default state.
- The user can also initiate the save via the Save button (PB_SAVE in the DPL-subclassed button block; the exact trigger is EXTERNAL / NOT IN BUNDLE but inherits from the DPL KEY-COMMIT pattern).

**Retention and Audit**

- Every saved SOQ amendment carries the identity of the user who made the change (Modified By - `MODIFIED_BY`) and the date and time of the change (Modified Date - `MODIFIED_DATE`), stamped automatically by the PRE-UPDATE trigger.
- No archival or purge policy is evidenced in this form.

---

### 6.5 Excel Output Columns

This form does not use Excel download. No Excel export columns were identified in the form sources.

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| ABC Classification | Parts classification system grouping inventory into tiers (A = high value/movement, B = medium, C = low, Null = unclassified) for prioritised replenishment planning | ABC Groups | SOQ, Parts Category |
| AMD_SOQ_QTY | Amended SOQ Quantity - the user-editable override of the system-generated standard order quantity for a part line | Amended Quantity | SOQ_QTY, On-Order Qty |
| AM_DEALER_LOC | Dealer location master table - stores location codes, descriptions, and dealer map codes for each consignee | Dealer Locations | Dealer, Location Code |
| As On Date | The reference date used to define the point-in-time snapshot for SOQ calculation and report printing | Reference Date, Report Date | SOQ, NB_AS_ON_DATE |
| AVG_CONSUMPTION | Average monthly consumption - the calculated average sales or usage rate over the selected history period, used as the SOQ calculation basis | Average Consumption | SOQ, Consumption History |
| B_SOQ | SOQ data block - the main grid displaying SOQ line records from PT_SOQ_MUL_NEW | SOQ Block | PT_SOQ_MUL_NEW, SOQ |
| Consignee | The entity (typically a dealer or branch) on whose behalf parts are ordered and to whom locations are assigned | Dealer Consignee | Dealer, P_CONSG_CD |
| CSV Export | Comma-separated values file export of the current SOQ data, generated on the server and opened in the browser for download | Excel Export | VIEW_EXCEL_REP |
| Dealer | The dealership identity used to scope all SOQ queries, location lookups, and supplier lists throughout the form | Dealer Map Code | GLOBAL.DEALER, Consignee |
| DMS | Dealer Management System - the integrated dealership software platform within which pt_soq_new operates | - | SOQ, Oracle Forms |
| DPL | Shared PL/SQL program library (`DPL.pld`) providing common utility routines (CHECK_NULL, DISP_TEXT, RAISE_ERROR, CHECK_FORM_FAILURE) used across Oracle Forms modules | DPL Library, GENERAL | PLD, Shared Library |
| GM_PARTY | Supplier/party master table - stores party codes, names, party types, and multi-location flags used for PO party selection | Supplier Master | Party Code, RG_MUL_PARTY |
| LOC_CD | Location code - identifies a specific physical stock location within the dealer's operation | Location | GLOBAL.LOC_CD, AM_DEALER_LOC |
| LOV | List of Values - a popup selection list in Oracle Forms used to look up and return valid codes | Dropdown, Picklist | RG_MUL_PARTY, RG_NON_MUL_PARTY |
| Min Order Qty | Minimum order pack quantity - the smallest quantity increment in which a part must be ordered, enforced during SOQ amendment | NB_MIN_ORD_QTY | AMD_SOQ_QTY |
| On-Hand Qty | Current physical stock quantity held at the dealer location at the time of the SOQ review | Current Stock | ON_HAND_QTY, SOQ |
| On-Order Qty | Quantity of a part already on open purchase orders at the time of review | Open Order Qty | ON_ORDER_QTY, PM_PART_VAR |
| Oracle Forms | Oracle application development platform used to build the pt_soq_new transactional screen | Forms | DMS, OLB |
| Parent Group | Organisation or group identifier at the top level of the hierarchy - applied as a filter across all tables and queries | GLOBAL.PARENT_GROUP | Dealer, Principal |
| Parts Category | Classification grouping of parts (e.g. Main, All) used to scope the SOQ query to a subset of the parts catalogue | Part Categ, PART_CATEG | ABC Classification, PM_PART |
| PCK | PL/SQL Package (`.pck` file) - a compiled database package containing stored procedures and functions invoked from the form | Database Package | PK_VALIDATE_PARTS |
| PK_VALIDATE_PARTS | Database package providing the `update_on_order` procedure to update on-order stock figures in PM_PART_VAR after a replenishment order is committed | - | PCK, UPDATE_PO_STOCK, PM_PART_VAR |
| PLD | PL/SQL Library (`.pld` file) - a shared program library attached to the form providing reusable utility routines | Program Library | DPL, GENERAL |
| PM_PART | Parts master table - stores part numbers, descriptions, part class, minimum order quantities, and decimal quantity flags | Part Master | Parts Category, SOQ |
| PM_PART_VAR | Parts variant stock master table - stores on-order quantities per dealer, location, and part; updated when the replenishment order is committed | Part Variant | ON_ORDER_QTY, PK_VALIDATE_PARTS |
| PO | Purchase Order - the business document raised to procure parts from a supplier | Purchase Order | PO_STATUS, PARTY_CD |
| Principal | Manufacturer or brand map code scoped to the dealer - used as a multi-company key in part and price queries | GLOBAL.PRINCIPAL | Dealer, Parent Group |
| PT_SOQ_MUL_NEW | SOQ multi-location data table - stores standard order quantity records per dealer, location, part number, and as-on date | SOQ Table | SOQ, B_SOQ |
| PT_SOQHS | Oracle Report identifier for the Suggested Order Quantity history/print report invoked from B_PRN | SOQ Report | P_REP_ID, Oracle Reports |
| SB_TITLE | Search/criteria control block - the header block where the parts manager sets SOQ filters (category, ABC groups, months, location) before querying | Criteria Block, Header Block | B_SOQ |
| SOQ | Suggested Order Quantity - the system-calculated replenishment quantity recommended for a part based on consumption history and stock levels | Standard Order Quantity, Re-Order Qty | AMD_SOQ_QTY, AVG_CONSUMPTION |
| Stock Yard | A secondary or auxiliary stock holding area; when stock-yard mode is enabled, all dealer locations including stock yards are loaded and multi-location supplier lists are used | CHK_STK_YARD | Location, P_STOCK_YARD |
| WebUtil | Oracle Forms client-side utility library (`webutil.olb`) enabling server-side file operations and browser integration used for CSV export | WEBUTIL | VIEW_EXCEL_REP |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: pt_soq_new (PT_SOQ_NEW)
- Form Module XML Title: MODULE4
- Oracle Forms Version: 12c (Module version 122010400); Runtime compatibility: 5.0
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DPL (DPL.pld program library), D2KWUTIL, DMS_EXCEL_REPORT, WEBUTIL (webutil.olb)
- First Navigation Block: SB_TITLE
- Console Window: WN_MAIN - Suggested Order Quantity/Re-Order Processing (Rel: 2.2.2)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PK_VALIDATE_PARTS
- Source artifacts: `pt_soq_new_fmb.xml`; OLB `DPL.olb`; DPL (DPL.pld program library); D2KWUTIL; DMS_EXCEL_REPORT; WEBUTIL (webutil.olb); PCK `PK_VALIDATE_PARTS.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier carried in session context; mirrors the P_APP_ID parameter value for use in triggers after form initialisation |
| BLOCKS | Char | Trigger | Search-mode flag - `'S'` = searching from temp block, `'O'` = highlight in B_SOQ |
| COMP_FA | Char | ProgramUnit / Trigger | Company/financial area code - used as filter in SOQ queries |
| DEALER | Char | ProgramUnit / RecordGroup / Trigger | Current dealer map code - primary identity of the logged-in dealer location |
| LOC_CD | Char | ProgramUnit / Trigger | Current location code - filters SOQ data by storage location |
| PARENT_GROUP | Char | ProgramUnit / RecordGroup / Trigger | Parent group/organisation identifier - top-level filter applied across all queries |
| PRINCIPAL | Char | ProgramUnit / Trigger | Principal (manufacturer/brand) map code - multi-company key passed to part and price queries |
| P_FIN_YR | Char | Trigger | Current financial year value carried in session context; used when constructing SOQ date-range filters |
| REP_SERVER | Char | Trigger | Report server name resolved at runtime; passed to RUN_REPORT_OBJECT as the destination server for Oracle Reports execution |
| USERID | Char | ProgramUnit / Trigger | Logged-in user ID - used to generate unique CSV export file names |
| USER_NAME | Char | ProgramUnit / Trigger | Logged-in user name - stamped on modified-by field on record update |

### 8.1.2 Form Parameters

*All 8 ModuleParameter entries from pt_soq_new_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_SOQ_POP | Char | N | Flag indicating whether SOQ records have been populated; reset to `'N'` on form clear |
| P_APP_ID | Char | - | Application identifier passed from calling context; identifies the calling module |
| P_LOC_DESC | Char | - | Pre-populated description of the current location, displayed in B_LOC without a database query |
| P_CONSG_CD | Char | - | Consignee code - filters dealer locations in FETCH_LOC; identifies the consignee for SOQ generation |
| P_STOCK_YARD | Char | N | Stock-yard flag - when `'Y'`, controls which supplier LOV is shown and whether all dealer locations are fetched |
| P_ABC | Char | - | ABC classification filter string (e.g. `'A','B','C'`) built dynamically from checkbox selections; passed to the report |
| P_PRINT | Char | - | Print destination flag - controls report output routing |
| P_REP_ID | Char | PT_SOQHS | Report ID identifying which Oracle Report to invoke for the SOQ print; defaults to `'PT_SOQHS'` |

**Total Parameters:** 8

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| SB_TITLE | - | 1 | N/N/N/N | Default | Control - search criteria and header entry block |
| B_LOC | - | 5 | N/N/N/N | Default | Control - dealer locations populated programmatically; standalone |
| B_SOQ | PT_SOQ_MUL_NEW | 10 | Y/N/Y/N | Delayed | Control - main SOQ data entry; standalone |
| DET_BLK | - | 5 | N/N/N/N | Default | Control - consumption detail display; standalone |
| B_PARTY | - | 1 | N/N/N/N | Default | Control - supplier and PO status selection; standalone |
| B_PRN | - | 1 | N/N/N/N | Default | Control - print options entry; standalone |

**Total Blocks:** 6 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from pt_soq_new_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| B_SOQ | Fetches SOQ line records for the current dealer, parent group, and location where SOQ quantity is greater than zero; results ordered by part number | part_num | dealer_map_cd = :global.dealer and parent_group = :global.parent_group and loc_cd = :global.loc_cd and nvl(SOQ_QTY,0) > 0 |

### 8.3 Items Summary

*Complete item inventory from `pt_soq_new_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| SB_TITLE | 29 | 0 | 29 |
| B_LOC | 5 | 0 | 5 |
| B_SOQ | 19 | 6 | 13 |
| DET_BLK | 17 | 0 | 17 |
| B_PARTY | 8 | 0 | 8 |
| B_PRN | 3 | 0 | 3 |
| PB_BLK | 24 | 0 | 24 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **115** | **6** | **109** |

**Item detail (all 115 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| SB_TITLE | NB_LAST_SOQ_DATE | false | Display-only field showing date of the last SOQ generation |
| SB_TITLE | NB_TO_DATE | false | Date input - reference "As On Date" for SOQ calculation |
| SB_TITLE | PART_CATEG | false | List item - selects the parts category to include in SOQ |
| SB_TITLE | PROCESS | false | Internal processing flag - triggers SOQ query/generation |
| SB_TITLE | CHECK_A | false | Checkbox - include ABC class-A parts in SOQ |
| SB_TITLE | CHECK_B | false | Checkbox - include ABC class-B parts in SOQ |
| SB_TITLE | CHECK_C | false | Checkbox - include ABC class-C parts in SOQ |
| SB_TITLE | CHECK_NULL | false | Checkbox - include parts with no ABC classification |
| SB_TITLE | CONSUMPTION | false | Radio group - selects consumption calculation basis |
| SB_TITLE | SHOW_ZERO_SOQ | false | Flag - when `'Y'`, displays parts with zero SOQ quantity |
| SB_TITLE | NO_MONTHS | false | Numeric input - number of months of consumption history to consider |
| SB_TITLE | CHK_STK_YARD | false | Checkbox - include stock-yard locations in SOQ calculation |
| SB_TITLE | DUMMY | false | Hidden placeholder item with no functional role |
| SB_TITLE | SOQ_FACT_1 | false | SOQ calculation multiplier factor 1 |
| SB_TITLE | SOQ_FACT_2 | false | SOQ calculation multiplier factor 2 |
| SB_TITLE | SOQ_FACT_3 | false | SOQ calculation multiplier factor 3 |
| SB_TITLE | SOQ_FACT_4 | false | SOQ calculation multiplier factor 4 |
| SB_TITLE | SOQ_FACT_5 | false | SOQ calculation multiplier factor 5 |
| SB_TITLE | SOQ_FACT_6 | false | SOQ calculation multiplier factor 6 |
| SB_TITLE | NO_OF_MONTHS | false | Display - resolved number of months used in SOQ calculation |
| SB_TITLE | NB_PART_CLASS | false | Text input - filter SOQ by part class code |
| SB_TITLE | NB_PART_NUM | false | Text input - filter SOQ by specific part number |
| SB_TITLE | NB_FINIS | false | Part number search field - formerly drove search navigation (now inactive) |
| SB_TITLE | P | false | Internal single-character hidden field; no active functional role |
| SB_TITLE | SHOW_CON | false | Flag item - controls display of monthly consumption columns |
| SB_TITLE | NB_SOQ_CATG | false | Display-only - shows last SOQ category populated by GET_LAST_SOQ_DATE |
| SB_TITLE | NB_SORT_BY | false | List item - selects the SOQ grid sort column |
| SB_TITLE | NB_SORT_TYPE | false | List item - selects the SOQ grid sort direction (ASC or DESC) |
| SB_TITLE | COPYRIGHT | false | Display-only - shows application copyright string |
| B_LOC | SRL_NO | false | Row serial number within the locations list |
| B_LOC | LOC_CD | false | Location code - dealer location identifier |
| B_LOC | LOC_DESC | false | Location description - human-readable name of the location |
| B_LOC | DEALER_MAP_CD | false | Dealer map code - links location to the dealer/consignee |
| B_LOC | CHECK_YN | false | Checkbox - marks this location as selected for SOQ generation |
| B_SOQ | DEALER_MAP_CD | false | Dealer map code - links this SOQ row to its dealer |
| B_SOQ | PO_CREATED | false | Flag - indicates whether a Purchase Order has been created for this SOQ line |
| B_SOQ | LOC_CD | false | Location code - the location to which this SOQ line belongs |
| B_SOQ | AS_ON_DATE | false | Reference date on which this SOQ record was generated |
| B_SOQ | NB_SRL_NUM | false | Row serial number populated from current record position |
| B_SOQ | PART_NUM | false | Part number identifying the spare or service part |
| B_SOQ | PART_DESC | true | Part description - human-readable name of the part |
| B_SOQ | ON_HAND_QTY | true | Current physical stock quantity at the location |
| B_SOQ | ON_ORDER_QTY | true | Quantity already on open purchase orders |
| B_SOQ | SOQ_QTY | true | System-generated Standard Order Quantity |
| B_SOQ | AVG_CONSUMPTION | true | Average monthly consumption used as SOQ calculation basis |
| B_SOQ | AMD_SOQ_QTY | true | Amended SOQ quantity - user-editable override of system SOQ |
| B_SOQ | NB_PUR_PRICE | false | Purchase price fetched from part variant record in POST-QUERY |
| B_SOQ | NB_TOT_VALUE | false | Total value - AMD_SOQ_QTY multiplied by purchase price |
| B_SOQ | MODIFIED_BY | false | User name of last modifier, stamped on update |
| B_SOQ | MODIFIED_DATE | false | Timestamp of last modification, stamped on update |
| B_SOQ | NB_TOTAL | false | Running total order value for the block |
| B_SOQ | NB_ALLOW_DECIMAL_QTY | false | Flag from part master - whether fractional quantities are permitted |
| B_SOQ | NB_MIN_ORD_QTY | false | Minimum order pack quantity fetched from part master |
| DET_BLK | ITEM172 | false | Internal placeholder item - no active prompt or column |
| DET_BLK | LOCATION | false | Location code or description for which this consumption row applies |
| DET_BLK | CURR_STOCK | false | Current stock quantity at this location |
| DET_BLK | ON_ORDER | false | On-order quantity at this location |
| DET_BLK | AVER_CONSUMPTION | false | Average monthly consumption computed across available months |
| DET_BLK | C1 | false | Monthly consumption figure for month 1 (most recent) |
| DET_BLK | C2 | false | Monthly consumption figure for month 2 |
| DET_BLK | C3 | false | Monthly consumption figure for month 3 |
| DET_BLK | C4 | false | Monthly consumption figure for month 4 |
| DET_BLK | C5 | false | Monthly consumption figure for month 5 |
| DET_BLK | C6 | false | Monthly consumption figure for month 6 |
| DET_BLK | C7 | false | Monthly consumption figure for month 7 |
| DET_BLK | C8 | false | Monthly consumption figure for month 8 |
| DET_BLK | C9 | false | Monthly consumption figure for month 9 |
| DET_BLK | C10 | false | Monthly consumption figure for month 10 |
| DET_BLK | C11 | false | Monthly consumption figure for month 11 |
| DET_BLK | C12 | false | Monthly consumption figure for month 12 (oldest) |
| B_PARTY | PARTY_CLASS | false | List item - selects the part class for the PO batch |
| B_PARTY | PO_DESC | false | Description of the Purchase Order or PO batch |
| B_PARTY | PO_STATUS | false | List item - PO status (`Open`, `Closed`, etc.) passed to the package |
| B_PARTY | PARTY_CD | false | Supplier/party code - selected via LOV |
| B_PARTY | PARTY_NAME | false | Supplier name - populated from LOV alongside party code |
| B_PARTY | MUL_CREATED_YN | false | Flag - indicates whether a multi-location PO has already been created |
| B_PARTY | NB_SOQ_CATG | false | Display-only - last SOQ category mirrored from GET_LAST_SOQ_DATE |
| B_PARTY | TOT_VALUE | false | Display-only total order value across all SOQ lines |
| B_PRN | NB_AS_ON_DATE | false | Date input (DD-MM-YYYY) - As On Date for the SOQ print report |
| B_PRN | PB_REP | false | Push button - executes SOQ report print when As On Date is provided |
| B_PRN | PB_BACK | false | Push button - navigates back to the previous screen |
| PB_BLK | PB_EXIT | false | Inherited toolbar button - exits the form (inherited from DPL.olb) |
| PB_BLK | PB_LIST | false | Inherited toolbar button - activates the LOV for the current field (inherited from DPL.olb) |
| PB_BLK | PB_INSERT | false | Inherited toolbar button - inserts a new record in the current block (inherited from DPL.olb) |
| PB_BLK | PM_CONT | false | Inherited toolbar button - continues or confirms the current operation (inherited from DPL.olb) |
| PB_BLK | PB_DEL | false | Inherited toolbar button - deletes the current record (inherited from DPL.olb) |
| PB_BLK | PB_CANCEL | false | Inherited toolbar button - cancels pending changes and reverts the current record (inherited from DPL.olb) |
| PB_BLK | PB_SAVE | false | Inherited toolbar button - saves/commits the current transaction (inherited from DPL.olb) |
| PB_BLK | PB_PRINT | false | Inherited toolbar button - invokes the print action for the current screen (inherited from DPL.olb) |
| PB_BLK | PB_CUT | false | Inherited toolbar button - cuts the selected text or record (inherited from DPL.olb) |
| PB_BLK | PB_COPY | false | Inherited toolbar button - copies the selected text or record (inherited from DPL.olb) |
| PB_BLK | PB_PASTE | false | Inherited toolbar button - pastes clipboard content into the current field (inherited from DPL.olb) |
| PB_BLK | PB_ERR_EXIT | false | Inherited toolbar button - exits the error window and returns to the main canvas (inherited from DPL.olb) |
| PB_BLK | PB_EDIT_AMD | false | Inherited toolbar button - enables editing of the amended SOQ quantity for the current row (inherited from DPL.olb) |
| PB_BLK | PB_CALC_SOQ | false | Inherited toolbar button - triggers SOQ calculation for the current criteria selections (inherited from DPL.olb) |
| PB_BLK | PB_ESOQ | false | Inherited toolbar button - executes the SOQ generation/export action (inherited from DPL.olb) |
| PB_BLK | PB_GENPO | false | Inherited toolbar button - generates a Purchase Order from the current SOQ lines (inherited from DPL.olb) |
| PB_BLK | PB_BACK | false | Inherited toolbar button - navigates back to the previous screen from the SOQ grid (inherited from DPL.olb) |
| PB_BLK | PB_SOQ_BACK | false | Inherited toolbar button - navigates back from the SOQ detail view to the criteria screen (inherited from DPL.olb) |
| PB_BLK | NB_PART_NUM | false | Inherited display/search field in the toolbar block - holds the part number used for the toolbar search action (inherited from DPL.olb) |
| PB_BLK | PB_SEARCH | false | Inherited toolbar button - initiates a part number search from the toolbar (inherited from DPL.olb) |
| PB_BLK | PB_BACK_PARTY | false | Inherited toolbar button - navigates back from the supplier/party selection screen (inherited from DPL.olb) |
| PB_BLK | PB_OK | false | Inherited toolbar button - confirms the current selection or action (inherited from DPL.olb) |
| PB_BLK | CB_TEMP_SOQ | false | Inherited checkbox in the toolbar block - toggles display of temporary SOQ records (inherited from DPL.olb) |
| PB_BLK | PB_EXCEL | false | Inherited toolbar button - exports the current SOQ grid to Excel/CSV via VIEW_EXCEL_REP (inherited from DPL.olb) |
| CB_ERR | TXT_ERR | false | Inherited text item in the error display block - shows the formatted error message text in the CN_ERR canvas (inherited from DPL.olb) |
| WEBUTIL | DUMMY | false | Placeholder item required by the WebUtil framework to anchor the WEBUTIL block on the canvas |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item providing client machine information functions (OS, hostname, etc.) to the form |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item providing client-side file system access functions |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item providing host/server command execution functions |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item providing session-level utility functions |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item providing file transfer functions between client and server |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item providing OLE automation functions for client-side Office integration |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item providing access to C API functions on the client |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item providing browser control and URL navigation functions |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_MUL_PARTY | Supplier Details | RG_MUL_PARTY | B_PARTY.PARTY_CD |
| LV_NON_MUL_PARTY | Supplier Details | RG_NON_MUL_PARTY | - |

**Total LOVs:** 2

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Invoked internally by the WebUtil framework (inherited from webutil.olb); no direct SHOW_ALERT call in form triggers |
| AL_ERRINFO | Error | (set at runtime) | Displayed by GENERAL.DISP_TEXT when an error-level message must be shown to the user; inherited from DPL.olb via the OG_GROUP object group |
| AL_NOTE | Note | (set at runtime) | Displayed by GENERAL.DISP_TEXT when an informational message must be shown to the user; inherited from DPL.olb via the OG_GROUP object group |
| AL_CONFIRM | Caution | (set at runtime) | Displayed when a confirmation choice is required from the user (e.g. before destructive operations); inherited from DPL.olb via the OG_GROUP object group |
| AL_PRINT | Print | (set at runtime) | Displayed by ASK_PRINT to offer Screen / Printer / Cancel output routing; inherited from DPL.olb via the OG_GROUP object group |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **8 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| FETCH_LOC | Procedure | `am_dealer_loc` (SELECT), `dealer_loc.dloc_tab` (local package) | Populates B_LOC block with dealer locations from `AM_DEALER_LOC`; temporarily enables block DML during population then locks it |
| BUILD_WHERE | Procedure | `general.disp_text` | Iterates B_LOC, collects checked locations, validates at least one location and ABC class selected, builds P_ABC parameter string |
| DEALER_LOC | Package spec | `pk_plsql_table.code_tab3` | Local PL/SQL package declaring `dloc_tab` as a cached table of dealer location codes, descriptions, and dealer map codes |
| LOC_CATEG_POPULATION | Procedure | `pt_soq_mul_new`, `pm_part`, `pt_soq_new`, `general.disp_text` | Queries SOQ tables to populate part category in SB_TITLE and marks locations in B_LOC that have SOQ parts |
| GET_LAST_SOQ_DATE | Procedure | `pt_soq_mul_new`, `pm_category` | Fetches the most recent SOQ as-on date and category for the current dealer/location; populates last SOQ date and category fields |
| UPDATE_PO_STOCK | Procedure | `pk_validate_parts.update_on_order` | Iterates B_SOQ to build part order array and calls `PK_VALIDATE_PARTS.UPDATE_ON_ORDER` to update on-order stock figures |
| SORT_BLOCK | Procedure | `sf_get_price`, `SET_BLOCK_PROPERTY`, `EXECUTE_QUERY` | Re-executes B_SOQ query with a new ORDER BY clause based on the selected sort column and direction |
| VIEW_EXCEL_REP | Procedure | `TEXT_IO`, `WEB.SHOW_DOCUMENT`, `webutil.ID_NULL`, `WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT`, `WEBUTIL_HOST.HOST` | Generates a CSV export from a supplied query, writes to a server-side file, transfers it to the client via WebUtil, and opens the file in the browser |

**Total Program Units:** 8

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.CHECK_NULL | Library routine | B_PARTY.PARTY_CD, B_PARTY.PO_STATUS, B_PRN.NB_AS_ON_DATE, PB_BLK.PB_CALC_SOQ (inherited), SB_TITLE.PART_CATEG | Raises FORM_TRIGGER_FAILURE with "Enter a valid &lt;column&gt;" if the supplied value is null |
| GENERAL.DISP_TEXT | Library routine | B_PARTY.PARTY_CD, B_SOQ, B_SOQ.AMD_SOQ_QTY, DET_BLK, Form level, PB_BLK.PB_CALC_SOQ (inherited), PB_BLK.PB_ESOQ (inherited), PB_BLK.PB_EXCEL (inherited), PB_BLK.PB_OK (inherited), PB_BLK.PB_SEARCH (inherited), ProgramUnit: BUILD_WHERE, ProgramUnit: LOC_CATEG_POPULATION, SB_TITLE.NO_MONTHS, SB_TITLE.SHOW_CON | Displays AL_ERRINFO (Error title) or AL_NOTE (other title) alert with the supplied message and title strings |
| GENERAL.RAISE_ERROR | Library routine | Form level, SB_TITLE.NB_FINIS | Looks up error message by code from the error table; displays via DISP_TEXT and raises FORM_TRIGGER_FAILURE for type `'E'` errors |
| WEBUTIL_FILE_TRANSFER.URL_TO_CLIENT | Library routine | ProgramUnit: VIEW_EXCEL_REP | Transfers a server-side file to the client machine using the WebUtil file-transfer mechanism |
| WEBUTIL_HOST.HOST | Library routine | ProgramUnit: VIEW_EXCEL_REP | Executes a host operating-system command on the server from within the Forms session |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Handled error codes 40209 and 40207 by calling GENERAL.DISP_TEXT and raising FORM_TRIGGER_FAILURE; simpler two-case error handler | Replaced by an expanded active ON-ERROR implementation with multi-case ORA/FRM error handling |
| **Inactive stub** | SB_TITLE | - | KEY-UP | Would have navigated upward between records in SB_TITLE block | Body replaced with `null;` - upward navigation disabled in the criteria block |
| **Inactive stub** | SB_TITLE | - | KEY-DOWN | Would have navigated downward between records in SB_TITLE block | Body replaced with `null;` - downward navigation disabled in the criteria block |
| **Commented out** | SB_TITLE | NB_FINIS | KEY-NEXT-ITEM | If NB_FINIS had a value and GLOBAL.BLOCKS='S', navigated to B_TEMP_SOQ and highlighted the matching part; if BLOCKS='O', navigated to B_SOQ | Commented out on 07-05-2004; B_TEMP_SOQ no longer exists; body replaced with `null;` |
| **Commented out** | SB_TITLE | NB_FINIS | POST-TEXT-ITEM | If NB_FINIS was null, reset search flags and hid CN_SEARCH canvas | Commented out on 07-05-2004 alongside KEY-NEXT-ITEM; body replaced with `null;` |
| **Commented out** | B_SOQ | - | WHEN-NEW-RECORD-INSTANCE | Called SP_SOQ_POPULATE_CONSUMPTION for each dealer location and populated DET_BLK consumption columns C1-C12 and AVER_CONSUMPTION | Consumption population loop commented out; active version only sets serial number and clears DET_BLK |
| **Inactive stub** | DET_BLK | - | WHEN-NEW-BLOCK-INSTANCE | Queried PM_STOCK and PM_PART_VAR by part number to populate per-location stock, on-order, and location into DET_BLK rows | Replaced with `null;` - DET_BLK consumption detail is never populated in current code |
| **Commented out** | B_PRN | NB_AS_ON_DATE | WHEN-VALIDATE-ITEM | Called General.check_null(:B_PRN.NB_AS_ON_DATE, 'As on Date') to enforce mandatory date entry | Commented out; active trigger body only applies DD-MM-YYYY format mask without null validation |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (75 business triggers):**
*pt_soq_new_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Custom error handler - formats and displays ORA/Forms errors; handles FK constraint, lock/concurrent-update errors, and suppresses informational messages |
| ON-MESSAGE | Form | - | Form level | **INACTIVE/COMMENTED OUT** - Body is empty; does not execute. Would have overridden default Forms messages; message interception is currently disabled. |
| KEY-EXIT | Form | - | Form level | Clears DBMS_APPLICATION_INFO session context and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | **INACTIVE/COMMENTED OUT** - Body is empty; does not execute. Would have activated the LOV for the current field; LOV key activation is currently disabled. |
| KEY-COMMIT | Form | - | Form level | Validates form state, checks for failures, commits the transaction, and clears the form on success |
| KEY-CLRFRM | Form | - | Form level | Clears form without validation; resets criteria, reloads locations, refreshes last SOQ date, and navigates to criteria block |
| KEY-OTHERS | Form | - | Form level | Inherited form-level key handler - suppresses unhandled key events to prevent default Forms behaviour; sourced from OG_GROUP (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited form-level next-item navigation handler; sourced from OG_GROUP (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited form-level previous-item navigation handler; sourced from OG_GROUP (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited form-level next-block navigation handler; sourced from OG_GROUP (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited form-level previous-block navigation handler; sourced from OG_GROUP (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited form-level downward navigation handler; sourced from OG_GROUP (inherited) |
| KEY-UP | Form | - | Form level | Inherited form-level upward navigation handler; sourced from OG_GROUP (inherited) |
| FT_SAVE | Form | - | Form level | Inherited toolbar trigger - fires when the Save toolbar button is pressed; sourced from OG_GROUP (inherited) |
| FT_CANCEL | Form | - | Form level | Inherited toolbar trigger - fires when the Cancel toolbar button is pressed; sourced from OG_GROUP (inherited) |
| FT_INSERT | Form | - | Form level | Inherited toolbar trigger - fires when the Insert toolbar button is pressed; sourced from OG_GROUP (inherited) |
| FT_DEL | Form | - | Form level | Inherited toolbar trigger - fires when the Delete toolbar button is pressed; sourced from OG_GROUP (inherited) |
| FT_LIST | Form | - | Form level | Inherited toolbar trigger - fires when the List toolbar button is pressed; sourced from OG_GROUP (inherited) |
| FT_PRINT | Form | - | Form level | Inherited toolbar trigger - fires when the Print toolbar button is pressed; sourced from OG_GROUP (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Inherited form startup trigger - initialises global variables, loads session context, populates locations, and navigates to the criteria block; sourced from OG_GROUP (inherited) |
| PRE-FORM | Form | - | Form level | Sets DBMS_APPLICATION_INFO session client info and module name for monitoring and auditing |
| KEY-UP | SB_TITLE | - | SB_TITLE | **COMMENTED OUT / INACTIVE** - Body is `null;`; disables upward navigation in the criteria block |
| KEY-DOWN | SB_TITLE | - | SB_TITLE | **COMMENTED OUT / INACTIVE** - Body is `null;`; disables downward navigation in the criteria block |
| WHEN-VALIDATE-ITEM | SB_TITLE | PART_CATEG | SB_TITLE.PART_CATEG | Validates part category selection is not null using CHECK_NULL |
| WHEN-CHECKBOX-CHANGED | SB_TITLE | SHOW_ZERO_SOQ | SB_TITLE.SHOW_ZERO_SOQ | Rebuilds B_SOQ query when the show-zero-SOQ checkbox is toggled |
| WHEN-VALIDATE-ITEM | SB_TITLE | NO_MONTHS | SB_TITLE.NO_MONTHS | Validates number of months is between 1 and 12; displays error if out of range |
| KEY-NEXT-ITEM | SB_TITLE | NO_MONTHS | SB_TITLE.NO_MONTHS | Navigates to next item after NO_MONTHS; validates value before leaving field |
| WHEN-CHECKBOX-CHANGED | SB_TITLE | CHK_STK_YARD | SB_TITLE.CHK_STK_YARD | Reloads dealer locations when stock-yard checkbox is toggled |
| KEY-NEXT-ITEM | SB_TITLE | CHK_STK_YARD | SB_TITLE.CHK_STK_YARD | Navigates to next item from CHK_STK_YARD checkbox |
| KEY-NEXT-ITEM | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | **COMMENTED OUT / INACTIVE** - Body is `null;`; formerly navigated to matching part in B_SOQ |
| WHEN-NEW-ITEM-INSTANCE | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | Sets focus properties when NB_FINIS item is entered |
| POST-TEXT-ITEM | SB_TITLE | NB_FINIS | SB_TITLE.NB_FINIS | **COMMENTED OUT / INACTIVE** - Body is `null;`; formerly reset search flags when NB_FINIS was cleared |
| WHEN-BUTTON-PRESSED | SB_TITLE | SHOW_CON | SB_TITLE.SHOW_CON | Executes query on B_SOQ with consumption columns visibility; calls LOC_CATEG_POPULATION to populate criteria |
| WHEN-LIST-CHANGED | SB_TITLE | NB_SORT_BY | SB_TITLE.NB_SORT_BY | Re-sorts B_SOQ grid when the sort column selection changes |
| WHEN-LIST-CHANGED | SB_TITLE | NB_SORT_TYPE | SB_TITLE.NB_SORT_TYPE | Re-sorts B_SOQ grid when the sort direction (ASC/DESC) changes |
| WHEN-CHECKBOX-CHANGED | B_LOC | CHECK_YN | B_LOC.CHECK_YN | Marks or unmarks a dealer location for inclusion in the SOQ generation |
| KEY-NEXT-ITEM | B_LOC | CHECK_YN | B_LOC.CHECK_YN | Navigates to next location row when CHECK_YN is toggled |
| PRE-UPDATE | B_SOQ | - | B_SOQ | Stamps MODIFIED_BY with the logged-in user name and MODIFIED_DATE with SYSDATE before any SOQ record update |
| WHEN-NEW-RECORD-INSTANCE | B_SOQ | - | B_SOQ | Sets row serial number from current record position; clears DET_BLK for the new row |
| POST-QUERY | B_SOQ | - | B_SOQ | For each fetched SOQ row, queries PM_PART and PM_PART_VAR to populate purchase price, decimal quantity flag, and minimum order quantity |
| WHEN-VALIDATE-ITEM | B_SOQ | AMD_SOQ_QTY | B_SOQ.AMD_SOQ_QTY | Validates amended SOQ quantity against minimum order quantity and decimal quantity rules |
| WHEN-NEW-BLOCK-INSTANCE | DET_BLK | - | DET_BLK | **COMMENTED OUT / INACTIVE** - Body is `null;`; formerly populated per-location stock and consumption data |
| WHEN-NEW-BLOCK-INSTANCE | B_PARTY | - | B_PARTY | Sets LOV for PARTY_CD to LV_MUL_PARTY if P_STOCK_YARD is 'Y', otherwise LV_NON_MUL_PARTY |
| WHEN-VALIDATE-ITEM | B_PARTY | PO_STATUS | B_PARTY.PO_STATUS | **INACTIVE** - Body is empty; does not execute. Active PO status validation is performed by the WVI trigger on the same item. |
| WVI | B_PARTY | PO_STATUS | B_PARTY.PO_STATUS | Additional validation trigger - validates PO status field using CHECK_NULL |
| WHEN-VALIDATE-ITEM | B_PARTY | PARTY_CD | B_PARTY.PARTY_CD | Validates supplier party code; queries GM_PARTY to populate supplier name; raises error if not found |
| WHEN-VALIDATE-ITEM | B_PRN | NB_AS_ON_DATE | B_PRN.NB_AS_ON_DATE | Applies DD-MM-YYYY format mask to As On Date field |
| WHEN-BUTTON-PRESSED | B_PRN | PB_REP | B_PRN.PB_REP | Validates As On Date is provided and executes the SOQ report print |
| WHEN-BUTTON-PRESSED | B_PRN | PB_BACK | B_PRN.PB_BACK | Navigates back to the previous screen |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar button trigger - exits the form cleanly, clearing session context (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar button trigger - activates the LOV for the currently focused item (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar button trigger - inserts a new record in the current block (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar button trigger - continues or confirms the current multi-step operation (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar button trigger - marks the current record for deletion and commits (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar button trigger - cancels pending changes and reverts the current record (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar button trigger - commits the current transaction via KEY-COMMIT logic (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar button trigger - invokes the print action for the current screen (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar button trigger - cuts the selected text or field value to the clipboard (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar button trigger - copies the selected text or field value to the clipboard (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar button trigger - pastes clipboard content into the current field (inherited from DPL.olb) |
| KEY-NEXT-ITEM | PB_BLK | PB_EDIT_AMD | PB_BLK.PB_EDIT_AMD (inherited) | Inherited key trigger - handles next-item navigation from the PB_EDIT_AMD button (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EDIT_AMD | PB_BLK.PB_EDIT_AMD (inherited) | Inherited toolbar button trigger - enables editing of the amended SOQ quantity for the current row (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CALC_SOQ | PB_BLK.PB_CALC_SOQ (inherited) | Inherited toolbar button trigger - triggers SOQ calculation using current criteria; calls BUILD_WHERE and executes the SOQ population procedure (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_ESOQ | PB_BLK.PB_ESOQ (inherited) | Inherited toolbar button trigger - executes the SOQ generation/export action for the selected locations and criteria (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_GENPO | PB_BLK.PB_GENPO (inherited) | Inherited toolbar button trigger - generates a Purchase Order from the current SOQ lines by invoking UPDATE_PO_STOCK and navigating to B_PARTY (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK | PB_BLK.PB_BACK (inherited) | Inherited toolbar button trigger - navigates back to the previous screen from the SOQ grid (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SOQ_BACK | PB_BLK.PB_SOQ_BACK (inherited) | Inherited toolbar button trigger - navigates back from the SOQ detail view to the criteria screen (inherited from DPL.olb) |
| KEY-NEXT-ITEM | PB_BLK | PB_SOQ_BACK | PB_BLK.PB_SOQ_BACK (inherited) | Inherited key trigger - handles next-item navigation from the PB_SOQ_BACK button (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SEARCH | PB_BLK.PB_SEARCH (inherited) | Inherited toolbar button trigger - initiates a part number search from the toolbar using NB_PART_NUM (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_BACK_PARTY | PB_BLK.PB_BACK_PARTY (inherited) | Inherited toolbar button trigger - navigates back from the supplier/party selection screen to the SOQ grid (inherited from DPL.olb) |
| KEY-NEXT-ITEM | PB_BLK | PB_BACK_PARTY | PB_BLK.PB_BACK_PARTY (inherited) | Inherited key trigger - handles next-item navigation from the PB_BACK_PARTY button (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_OK | PB_BLK.PB_OK (inherited) | Inherited toolbar button trigger - confirms the current selection or action and proceeds (inherited from DPL.olb) |
| WHEN-CHECKBOX-CHANGED | PB_BLK | CB_TEMP_SOQ | PB_BLK.CB_TEMP_SOQ (inherited) | Inherited checkbox trigger - toggles display of temporary SOQ records in the B_SOQ grid (inherited from DPL.olb) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXCEL | PB_BLK.PB_EXCEL (inherited) | Inherited toolbar button trigger - exports the current SOQ grid to Excel/CSV by calling VIEW_EXCEL_REP (inherited from DPL.olb) |
| KEY-NEXT-ITEM | PB_BLK | PB_EXCEL | PB_BLK.PB_EXCEL (inherited) | Inherited key trigger - handles next-item navigation from the PB_EXCEL button (inherited from DPL.olb) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Suggested Order Quantity/Re-Order Processing (Rel: 2.2.2) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | - |
| CN_PARTY | Stacked | - |
| CN_SOQ | Stacked | - |
| CN_DATE | Stacked | WN_MAIN |
| CN_TOOL | Content | - |
| CN_ERR | Content | - |

---

### 8.9 Editors

*No editors found in pt_soq_new_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*1 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_ROW_SELECT |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in pt_soq_new_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*18 DataSourceColumn elements across 1 blocks - formal query column-to-block mapping from pt_soq_new_fmb.xml.*

#### B_SOQ (18 columns)

| Column (DSCName) | Data Type |
| :--- | :--- |
| DEALER_MAP_CD | NUMBER |
| PART_CLASS | VARCHAR2 |
| PART_NUM | VARCHAR2 |
| AS_ON_DATE | DATE |
| NO_OF_MONTHS | NUMBER |
| AMD_QTY | NUMBER |
| AMD_QTY1 | NUMBER |
| AMD_QTY2 | NUMBER |
| AMD_QTY3 | NUMBER |
| AMD_QTY4 | NUMBER |
| AMD_QTY5 | NUMBER |
| AMD_QTY6 | NUMBER |
| AMD_QTY7 | NUMBER |
| AMD_QTY8 | NUMBER |
| AMD_QTY9 | NUMBER |
| AMD_QTY10 | NUMBER |
| AMD_QTY11 | NUMBER |
| AMD_QTY12 | NUMBER |

**Total DataSourceColumns:** 18 across 1 blocks

## 9. Object Library

*The form references two Object Library files (OLB): the DPL application framework library and the Oracle WebUtil component library. Both are present in the source directory.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_ROW_SELECT | VisualAttribute | Row selection highlight visual attribute for the SOQ results block; sets BackColor and ForegroundColor for selected rows. Defined directly in the form (not from the OLB). | 1 (B_SOQ block RecordVisualAttributeGroupName) | B_SOQ (block-level record highlight) |
| OG_GROUP | ObjectGroup | DPL application object group containing the standard button toolbar block (PB_BLK), standard form triggers (KEY-COMMIT, KEY-EXIT, KEY-CLRFRM, ON-ERROR, ON-MESSAGE, KEY-LISTVAL), common form triggers (FT_SAVE, FT_CANCEL, FT_INSERT, FT_DEL, FT_PRINT, WHEN-NEW-FORM-INSTANCE), and standard alert objects. All items in this group are subclassed from DPL. | 1 (form-level subclass via DPL_MTPL.OG_GROUP) | PB_BLK button block, KEY-COMMIT, KEY-EXIT, KEY-CLRFRM, ON-ERROR, FT_SAVE, FT_PRINT |
| WEBUTIL | ObjectGroup | Oracle WebUtil component object group providing client-side utility functions (file transfer, host execution, client info, browser interaction, OLE, C API). All items are subclassed from the WebUtil library. | 5 (WEBUTIL block and its component items) | WEBUTIL_HIDDEN_WINDOW, WEBUTIL_CANVAS, WEBUTIL block and event items |
| PC_DISP | PropertyClass | Display item property class (DPL): non-editable, grey background, Arial 9pt, no keyboard navigation. Applied to read-only display fields throughout the form. | 28 | PART_DESC, MODIFIED_BY, MODIFIED_DATE, and other display items |
| PC_CANV | PropertyClass | Canvas property class (DPL): defines standard canvas layout, background colour, window name, and viewport dimensions. | 3 | CN_MAIN, CN_SOQ, CN_PARTY canvases |
| PC_TEXT | PropertyClass | Text item property class (DPL): editable, white background, Arial 9pt, mixed case, popup menu. | 4 | PART_CATEG, NB_FINIS, and other editable text items |
| PC_CB | PropertyClass | Checkbox property class (DPL): standard checkbox layout, Arial 9pt. | 2 | CHECK_A, CHECK_B (and similar checkboxes) |
| PC_DATE | PropertyClass | Date field property class (DPL): white background, Arial 9pt, DD-MM-RRRR format mask, mouse-navigable, hint text for date entry format. | 1 | Date entry fields |
| PC_DTTIME | PropertyClass | Date-time field property class (DPL): white background, DD-MM-RRRR HH24:MI format, initialised to current database date-time. | 1 | NB_LAST_SOQ_DATE or similar date-time fields |
| PC_NUM | PropertyClass | Numeric field property class (DPL): right-justified, lowest value 0, Arial 9pt. | 1 | Numeric input fields |
| PC_MNUM | PropertyClass | Mandatory numeric field property class (DPL): right-justified, red prompt, includes WHEN-VALIDATE-ITEM that checks for zero/null and displays a hint-text error. | 1 | Mandatory numeric fields |
| PC_LOV | PropertyClass | List of Values field property class (DPL): standard LOV positioning, auto-select off, dark-blue foreground. | 2 | PARTY_CD and other LOV-linked fields |
| PC_UTEXT | PropertyClass | Uppercase text item property class (DPL): editable, white background, upper-case restriction. | 2 | Uppercase text entry fields |
| PC_MTEXT | PropertyClass | Mandatory text item property class (DPL): editable, red prompt, includes WHEN-VALIDATE-ITEM that checks for null and displays a hint-text error. | 1 | Mandatory text fields |
| PC_DESC | PropertyClass | Description display item property class (DPL): non-editable, blue foreground, Arial 9pt, left-justified, 110-character maximum. | 1 | Description display fields |
| PC_BUTN | PropertyClass | Push button property class (DPL): Arial 9pt bold, grey background, no mouse navigation. | 1 | Push button items |
| PC_MR_BLK | PropertyClass | Multi-record block property class (DPL): defines navigation to the button block (PB_BLK), vertical record orientation, scrollbar width. | 1 | B_SOQ block |
| PC_WIND | PropertyClass | Window property class (DPL): defines standard window dimensions, title, resize/minimize/maximize behaviour, grey background. | 1 | WN_MAIN |
| PC_FORM | PropertyClass | Form-level property class (DPL): defines validation unit as Item, savepoint mode off, console window, and standard form triggers (ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, KEY-CLRFRM). | 1 | Form module |
| VA_CB | VisualAttribute | Checkbox visual attribute (DPL): grey background, Arial 8pt, black foreground, transparent fill. | referenced | Standard checkbox styling |
| VA_DESC | VisualAttribute | Description visual attribute (DPL): grey background, Small Fonts 7pt, blue foreground. | referenced | Description items |
| VA_MAND | VisualAttribute | Mandatory field visual attribute (DPL): cyan background, Arial 9pt bold. | referenced | Mandatory field highlighting |
| VA_TEXT | VisualAttribute | Text item visual attribute (DPL): white background, Arial 9pt. | referenced | Standard text items |
| VA_BUTN | VisualAttribute | Button visual attribute (DPL): grey background, Arial 10pt bold. | referenced | Push buttons |
| VA_NUM | VisualAttribute | Numeric item visual attribute (DPL): white background, Arial 8pt medium. | referenced | Numeric fields |
| VA_DISP | VisualAttribute | Display item visual attribute (DPL): r25g75b75 background, Arial 8pt bold. | referenced | Display-only items |
| VA_TITLE | VisualAttribute | Title visual attribute (DPL): grey background, Arial 10pt bold, blue foreground. | referenced | Block/screen titles |
| VA_LOV | VisualAttribute | LOV visual attribute (DPL): grey background, Arial 9pt, dark-blue foreground. | referenced | LOV items |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute (DPL): white background, Courier bold. | referenced | Transaction date fields |
| VA_ALERT | VisualAttribute | Alert visual attribute (DPL): grey background, MT Extra 11pt demilight. | referenced | Alert dialogs |
| VA_OPROMPT | VisualAttribute (Prompt) | Optional prompt visual attribute (DPL): Arial 8pt medium, black prompt text. | referenced | Non-mandatory field prompts |
| VA_MPROMPT | VisualAttribute (Prompt) | Mandatory prompt visual attribute (DPL): Arial 8pt medium, red prompt text. | referenced | Mandatory field prompts |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual attribute (DPL): white background, black foreground. | referenced | Iconic push buttons |
| VA_RB | VisualAttribute | Radio button visual attribute (DPL): grey background, Arial 8pt, black foreground. | referenced | Radio button items |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_NON_MUL_PARTY | Query | LV_NON_MUL_PARTY | PARTY_NAME | PARTY_CD | No | Lists non-multi-location suppliers for the current dealer when selecting a PO party | LV_NON_MUL_PARTY |
| RG_MUL_PARTY | Query | LV_MUL_PARTY | PARTY_NAME | PARTY_CD | No | Lists multi-location suppliers for the current dealer when stock-yard mode is active | LV_MUL_PARTY -> B_PARTY.PARTY_CD |

**Total Record Groups:** 2

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| SB_TITLE | - | - | No |
| B_LOC | - | - | No |
| B_SOQ | PT_SOQ_MUL_NEW | - | Yes |
| DET_BLK | - | - | No |
| B_PARTY | - | - | No |
| B_PRN | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | FETCH_LOC, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Dealer location master - stores location codes, descriptions, and dealer map codes for each consignee; queried during form initialisation (WHEN-NEW-FORM-INSTANCE), on demand via FETCH_LOC, and within WHEN-BUTTON-PRESSED to resolve or validate dealer location data |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED | Oracle pseudo-table - used to fetch SYSDATE for the As On Date default |
| `GM_PARTY` | - | RG_MUL_PARTY, RG_NON_MUL_PARTY, Trigger WHEN-VALIDATE-ITEM | Supplier/party master - stores party codes, names, and multi-location flags used for PO party selection |
| `PD_PO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase order detail table - queried during WHEN-BUTTON-PRESSED to retrieve line-level PO detail records associated with the current SOQ context |
| `PH_PO` | - | Trigger WHEN-BUTTON-PRESSED | Purchase order header table - queried during WHEN-BUTTON-PRESSED to retrieve header-level PO information (e.g. PO number, date, status) linked to the current SOQ |
| `PM_CATEGORY` | - | Trigger WHEN-NEW-FORM-INSTANCE | Part category master - queried during form initialisation to populate category reference data used for filtering or defaulting category-related fields |
| `PM_NUMBER_GEN` | - | Trigger WHEN-BUTTON-PRESSED | Number generation master - accessed during WHEN-BUTTON-PRESSED to obtain the next system-generated sequence number (e.g. for PO or SOQ document numbering) |
| `PM_PART` | - | GET_LAST_SOQ_DATE, LOC_CATEG_POPULATION, Trigger POST-QUERY, Trigger WHEN-BUTTON-PRESSED | Part master - stores part numbers, descriptions, part class, allow-decimal-qty flag, and minimum order quantity |
| `PT_SOQ_MUL_NEW` | - | B_SOQ, GET_LAST_SOQ_DATE, LOC_CATEG_POPULATION, Trigger WHEN-BUTTON-PRESSED | SOQ multi-location data - stores standard order quantity records per dealer, location, and part number; also accessed directly in WHEN-BUTTON-PRESSED for insert/update/delete operations on SOQ records |
| `PT_SOQ_NEW` | - | LOC_CATEG_POPULATION | SOQ legacy table - queried to identify which locations have parts in the SOQ for location marking |

**Total Referenced Objects:** 10

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | FETCH_LOC | Loads the dealer location list for the current consignee into the on-screen location selection panel |
| BR-001 | GET_LAST_SOQ_DATE | Retrieves the date and category of the most recent SOQ calculation run for display on the main screen |
| BR-001, BR-016 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers (or clears) the form's identity in the database session monitoring layer |
| BR-001, BR-016 | DBMS_APPLICATION_INFO.SET_MODULE | Sets (or clears) the module/action name in the database session monitoring layer |
| BR-001 | SF_COPYRIGHT_DECLARATION | Returns the copyright declaration text for display in the form header |
| BR-001 | SF_PRINCIPAL_MAP_CD | Returns the principal map code for a given dealer/location context; used during form initialisation and location resolution |
| BR-002, BR-013 | GENERAL.CHECK_NULL | Validates that a mandatory field is not blank; raises a user-visible alert if it is |
| BR-003, BR-007, BR-008, BR-011, BR-014, BR-017, BR-019, BR-021 | GENERAL.DISP_TEXT | Displays a message to the user via an alert dialogue with a specified severity title |
| BR-002, BR-013 | GENERAL.ASK_CONFIRM | Displays a confirmation alert and returns the user's response; used before destructive or navigation actions |
| BR-001 | GENERAL.L_POP_LIST_ITEM | Populates a drop-down list item from a named record group during form initialisation |
| BR-004 | FETCH_LOC | Reloads the location list when the consignee-level scope flag is changed |
| BR-010 | SORT_BLOCK | Re-sorts and refreshes the SOQ results grid when the Sort By or Sort Type selection changes |
| BR-011 | SP_SOQ_POPULATE_CONSUMPTION | Retrieves monthly consumption history, current stock, and on-order quantity for a part at a given location |
| BR-015 | GENERAL.CHECK_FORM_FAILURE | Verifies the form is not in a failure state before and after the database commit |
| BR-017 | GENERAL.RAISE_ERROR | Looks up and displays a standardised business error message for a given error code |
| BR-023 | PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Updates on-order quantities for each part in the order list; called when generating a purchase order |
| - | SP_CALCULATE_SOQ_NEW | Executes the SOQ calculation for the selected locations and part categories; core calculation routine invoked from the Calculate SOQ flow |
| - | SP_GET_CONSUMPTION | Retrieves raw consumption data for a part at a location; supporting routine used within the consumption display flow |
| - | SP_INSERT_PM_PART_VAR | Creates a missing part variant record in PM_PART_VAR; called internally by PK_VALIDATE_PARTS.UPDATE_ON_ORDER when no existing row is found |
| - | SP_UPDATE_PART_PRICE | Updates the unit price for a part; called as part of the PO generation or SOQ amendment flow |
| - | SP_UPDATE_PO_NUMBER_NEW | Assigns or updates the PO number on SOQ records after a purchase order is generated |
| - | VIEW_EXCEL_REPORT_NEW | Generates and serves the Excel/CSV export of the SOQ results; server-side reporting routine called from the Excel export flow |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatcher; routes asynchronous client-side bean events to the appropriate WEBUTIL_CORE handler |
| - | WEBUTIL.ID_NULL | Returns TRUE if a WebUtil handle is NULL; used in VIEW_EXCEL_REP to guard against uninitialised handles |

---

### 12.2 Procedure and Package Catalogue

#### GENERAL (attached library DPL)

Package providing utility routines for error display, null checking, confirmation prompting, list population, form-state validation, and error code lookup. All routines are defined in the DPL attached library (DPL.pld / DPL.pll).

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GENERAL.DISP_TEXT | Procedure | WHEN-VALIDATE-ITEM (SB_TITLE.NO_MONTHS, B_SOQ.AMD_SOQ_QTY, B_PARTY.PARTY_CD, B_PARTY.PO_STATUS), WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON, PB_BLK.PB_CALC_SOQ, PB_BLK.PB_ESOQ, PB_BLK.PB_EXCEL, PB_BLK.PB_OK, PB_BLK.PB_SEARCH), ON-ERROR (form level), ON-MESSAGE (form level), BUILD_WHERE, POST-QUERY (B_SOQ) | Displays an alert dialog with the supplied message body and title. Uses AL_ERRINFO when the title is "Error" and AL_NOTE otherwise. Called from a wide range of button-pressed triggers, validation triggers, and error/message handlers to surface both error conditions and informational feedback to the user. |
| GENERAL.CHECK_NULL | Procedure | WHEN-VALIDATE-ITEM (SB_TITLE.PART_CATEG, B_PARTY.PARTY_CD, B_PRN.NB_AS_ON_DATE), WHEN-VALIDATE-ITEM (B_PARTY.PO_STATUS), WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ) | Checks that a field value is not blank; raises FORM_TRIGGER_FAILURE with the message "Enter a valid &lt;column_title&gt;" if it is. Used to enforce mandatory field entry before navigation, commit, or SOQ calculation is allowed. |
| GENERAL.ASK_CONFIRM | Function | Trigger FT_CANCEL (form level), Trigger FT_DEL (form level), WHEN-BUTTON-PRESSED (PB_BLK.PB_CANCEL, PB_BLK.PB_COPY, PB_BLK.PB_CUT, PB_BLK.PB_DEL, PB_BLK.PB_EXIT, PB_BLK.PB_INSERT, PB_BLK.PB_LIST, PB_BLK.PB_PASTE, PB_BLK.PB_SAVE, WEBUTIL.DUMMY) | Displays a confirmation alert containing the supplied message and returns the user's response as a NUMBER (1 = OK/Yes, 2 = Cancel/No). Called before destructive or navigation actions - including toolbar buttons and the form-level FT_CANCEL and FT_DEL triggers - to prompt the user before record deletion, unsaved-change abandonment, or form exit. |
| GENERAL.CHECK_FORM_FAILURE | Procedure | KEY-COMMIT (form level) | After ENTER and after COMMIT_FORM, checks whether the form encountered a failure; retrieves the ORA or Forms error message, displays it via DISP_TEXT with title "Error", and raises FORM_TRIGGER_FAILURE to prevent the commit from being treated as successful. Called twice in KEY-COMMIT. |
| GENERAL.RAISE_ERROR | Procedure | ON-ERROR (form level) - database error code -02292 branch | Looks up a business error message and title by code from the application error table; displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error type 'E'. Used in ON-ERROR to handle specific ORA error codes with user-friendly messages. |
| GENERAL.L_POP_LIST_ITEM | Procedure | WHEN-NEW-FORM-INSTANCE (form level) | Populates a list item from a named record group (`p_rg_name`), optionally pre-selecting the entry identified by `p_select`. Called during WHEN-NEW-FORM-INSTANCE to initialise drop-down list items with their data-driven values before the form is presented to the user. |

---

#### DBMS_APPLICATION_INFO (Oracle built-in package)

Oracle database package for session monitoring and attribution.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Procedure | PRE-FORM (form level), KEY-EXIT (form level) | Sets or clears the client-info register in the current database session, enabling database administrators to identify which application form is active. |
| DBMS_APPLICATION_INFO.SET_MODULE | Procedure | PRE-FORM (form level), KEY-EXIT (form level) | Sets or clears the module name and action name in the current database session for monitoring purposes. |

---

#### DEALER_LOC (form-level package)

In-memory PL/SQL package declared as a form program unit. Provides a three-column table (`dloc_tab`) that stores the location code, description, and dealer map code for each location loaded by FETCH_LOC, making them available to the SHOW_CON trigger loop without re-querying the database.

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DEALER_LOC (package specification) | Package | FETCH_LOC program unit, WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON) | Declares the in-memory location table used across triggers and program units to share location data within a session. |

---

#### FETCH_LOC (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| FETCH_LOC | Procedure | KEY-CLRFRM (form level), WHEN-CHECKBOX-CHANGED (SB_TITLE.CHK_STK_YARD), WHEN-NEW-FORM-INSTANCE (form level) | Queries AM_DEALER_LOC to load the list of active dealer locations for the current consignee and principal into the on-screen location selection block and the in-memory location table (DEALER_LOC.dloc_tab). Populates both all-locations mode (consignee-level) and single-location mode. |

---

#### GET_LAST_SOQ_DATE (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| GET_LAST_SOQ_DATE | Procedure | KEY-CLRFRM (form level) | Queries PT_SOQ_MUL_NEW and PM_PART to retrieve the date and category description of the most recent SOQ record for the current dealer/location context and populates the Last SOQ Date and SOQ Category display fields. Sets both fields to null silently if no SOQ record exists. |

---

#### BUILD_WHERE (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| BUILD_WHERE | Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ) | Validates that at least one location and at least one inventory classification are selected; builds the location array and ABC-class filter string parameters used by the SOQ calculation query. Calls GENERAL.DISP_TEXT to report validation failures to the user. |

---

#### LOC_CATEG_POPULATION (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| LOC_CATEG_POPULATION | Procedure | WHEN-NEW-FORM-INSTANCE (form level) | Queries PT_SOQ_MUL_NEW and PM_PART to check whether an existing SOQ is present; if so, pre-fills the Parts Category filter from the first SOQ part and pre-ticks the locations from PT_SOQ_NEW that were included in the previous SOQ. |

---

#### UPDATE_PO_STOCK (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| UPDATE_PO_STOCK | Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_ESOQ or Generate PO button) | Collects all amended order quantities from the SOQ results block, calls PK_VALIDATE_PARTS.UPDATE_ON_ORDER to update the on-order stock figures, and shows the error canvas with the procedure's error message if the update fails. |

---

#### SORT_BLOCK (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SORT_BLOCK | Procedure | WHEN-LIST-CHANGED (SB_TITLE.NB_SORT_BY), WHEN-LIST-CHANGED (SB_TITLE.NB_SORT_TYPE) | Posts pending changes, maps the selected Sort By value to a sort expression (part number, quantity, price, or value formula), sets the ORDER BY property on the SOQ results block, clears the block, and re-executes the query. |

---

#### VIEW_EXCEL_REP (form program unit)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REP | Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_EXCEL) | Generates a timestamped CSV file from a supplied query, writes it to the server-side IAS reports directory, reads the base URL from /reports/DMS/excelpath.txt, and opens the file in the user's browser via WEB.SHOW_DOCUMENT. Truncates to 65,535 rows if the data exceeds the Excel row limit. Uses WEBUTIL.ID_NULL to guard handle initialisation. |

---

#### SF_COPYRIGHT_DECLARATION (standalone function)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | Function | KEY-CLRFRM (form level) | Returns the copyright declaration text for display in the form header's copyright field. |

---

#### SF_PRINCIPAL_MAP_CD (standalone function)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SF_PRINCIPAL_MAP_CD | Function | WHEN-NEW-FORM-INSTANCE (form level), WHEN-BUTTON-PRESSED (form level) | Returns the principal map code for a given dealer and location context. Used during form initialisation and within button-pressed logic to resolve the correct principal mapping for location-dependent operations. |

---

#### SP_CALCULATE_SOQ_NEW (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_CALCULATE_SOQ_NEW | Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_CALC_SOQ) | Executes the full SOQ calculation for the selected dealer, locations, and part categories, writing results into PT_SOQ_MUL_NEW. This is the core calculation engine invoked after BUILD_WHERE has validated and assembled the input parameters. |

---

#### SP_GET_CONSUMPTION (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_GET_CONSUMPTION | Procedure | WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON) | Retrieves raw consumption data for a specified part at a given dealer location. Supporting routine used within the consumption history display flow alongside SP_SOQ_POPULATE_CONSUMPTION. |

---

#### SP_SOQ_POPULATE_CONSUMPTION (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_SOQ_POPULATE_CONSUMPTION | Procedure | WHEN-BUTTON-PRESSED (SB_TITLE.SHOW_CON) | Retrieves up to the specified number of months of consumption history and the current stock and on-order quantity for a given root part at a given dealer location, returning the results as output arrays for display in the consumption detail panel. |

---

#### SP_INSERT_PM_PART_VAR (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_INSERT_PM_PART_VAR | Procedure | PK_VALIDATE_PARTS.UPDATE_ON_ORDER (internal call) | Creates a new part variant record in PM_PART_VAR when UPDATE_ON_ORDER determines that no existing row is present for the part being processed. Ensures referential integrity before the on-order quantity update is applied. |

---

#### SP_UPDATE_PART_PRICE (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_UPDATE_PART_PRICE | Procedure | WHEN-BUTTON-PRESSED (form level - PO generation or SOQ amendment flow) | Updates the unit price for a part in the relevant price table. Called as part of the purchase order generation or SOQ amendment workflow to ensure that current pricing is recorded against the order. |

---

#### SP_UPDATE_PO_NUMBER_NEW (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| SP_UPDATE_PO_NUMBER_NEW | Procedure | WHEN-BUTTON-PRESSED (form level - PO generation flow) | Assigns or updates the purchase order number on the relevant SOQ records in PT_SOQ_MUL_NEW after a purchase order has been successfully generated, linking the SOQ lines to the created PO document. |

---

#### VIEW_EXCEL_REPORT_NEW (standalone procedure)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| VIEW_EXCEL_REPORT_NEW | Procedure | WHEN-BUTTON-PRESSED (PB_BLK.PB_EXCEL) | Server-side reporting procedure that generates the Excel/CSV export of SOQ results. Constructs the output file on the application server and returns the file path or URL to the calling form program unit for browser delivery. |

---

#### PK_VALIDATE_PARTS (external package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Package Procedure | UPDATE_PO_STOCK form program unit | Iterates the supplied part-order array and updates on-order quantities in PM_PART_VAR for each part. For each part it first locks the existing row for update; if no row is found it calls SP_INSERT_PM_PART_VAR to create one. When p_po_flag = 'R' it increments the on-order quantity; when p_po_flag = 'C' it decrements it. Errors are returned via p_error_code and p_error_msg output parameters and displayed to the user without silent failures. |

---

#### WEBUTIL_CORE (WebUtil library package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | Procedure | WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS) | Central WebUtil event dispatcher. Each WEBUTIL bean item fires a WHEN-CUSTOM-ITEM-EVENT trigger passing the event name and its serialised parameters; CustomEventHandler routes the call to the appropriate WEBUTIL_CORE handler so that asynchronous client-side responses (file transfers, host commands, OLE results, etc.) are processed correctly on the server side. |

---

#### WEBUTIL_C_API (WebUtil library package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEBUTIL.ID_NULL | Function | VIEW_EXCEL_REP form program unit | Returns TRUE if the supplied WebUtil handle is NULL. Called in VIEW_EXCEL_REP to check whether a WebUtil file-transfer or handle object has been initialised before attempting to use it, preventing NULL-pointer failures during CSV export. |

---

#### WEB (Oracle Forms built-in package)

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | Procedure | VIEW_EXCEL_REP form program unit | Opens a URL in the user's web browser in a new tab; used to display the generated CSV export file after it has been written to the server-side IAS reports directory. |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PK-VALIDATE-PARTS | Pk_Validate_Parts | Parts validation and on-order stock update package - provides `update_on_order` to iterate a batch of part-quantity pairs and update on-order stock figures in `PM_PART_VAR`, creating missing part variant records as needed | The form requires a centralised package routine to update on-order quantities for all selected SOQ parts in a single transactional call after PO creation | `update_on_order` locks each PM_PART_VAR row before update; when a part variant record does not exist, it is created via SP_INSERT_PM_PART_VAR; errors are returned via output parameters and displayed to the user without silent failures |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PK_VALIDATE_PARTS.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PK_VALIDATE_PARTS.pck | Pk_Validate_Parts | update_on_order | Procedure | PROCEDURE update_on_order(p_parent IN VARCHAR2, p_dealer IN NUMBER, p_loc_cd IN VARCHAR2, p_part_ordtab part_order_type, p_po_flag IN VARCHAR2, p_created_by IN VARCHAR2, p_error... | ProgramUnit: UPDATE_PO_STOCK | Iterates the supplied part-order array and updates on-order quantities in `PM_PART_VAR` for each part. For each part, it first locks the existing row for update; if no row is found it calls SP_INSERT_PM_PART_VAR to create one. When `p_po_flag = 'R'`, it increments on-order quantity; when `p_po_flag = 'C'`, it decrements it. Errors are returned via `p_error_code` and `p_error_msg` output parameters and displayed to the user. |

**Total Matched Package Routines (called from form XML):** 1

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | *No matched package functions with documented return values in the available PCK sources.* |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CANCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation alert containing `confirm_msg` and returns the user's response as a NUMBER (typically 1 for OK/Yes, 2 for Cancel/No). Called from destructive or navigation actions - including the inherited toolbar buttons (PB_CANCEL, PB_DEL, PB_EXIT, PB_SAVE, etc.) and the form-level FT_CANCEL and FT_DEL triggers - to prompt the user before proceeding with record deletion, unsaved-change abandonment, or form exit. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Checks FORM_SUCCESS after the ENTER built-in; if the last operation did not succeed, retrieves the ORA or Forms error message, displays it via DISP_TEXT with title "Error", and raises FORM_TRIGGER_FAILURE to abort the commit. Called twice in KEY-COMMIT: once after ENTER and once after COMMIT_FORM. |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CALC_SOQ, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PRN.NB_AS_ON_DATE, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.PART_CATEG, Trigger: WVI in B_PARTY.PO_STATUS | Raises FORM_TRIGGER_FAILURE with the message "Enter a valid &lt;column_title&gt;" if `p_value` is NULL. Used to enforce mandatory field entry before navigation or commit is allowed. Also called from PB_BLK.PB_CALC_SOQ to validate required inputs before the SOQ calculation is triggered. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: BUILD_WHERE, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: POST-QUERY in B_SOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CALC_SOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_ESOQ, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXCEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_OK, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SEARCH, Trigger: WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PO_STATUS, Trigger: WHEN-VALIDATE-ITEM in B_SOQ.AMD_SOQ_QTY, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.NO_MONTHS | Displays an alert dialog with `text_string` as the message body and `title_string` as the title. Uses AL_ERRINFO when title is "Error" and AL_NOTE otherwise; calls SHOW_ALERT internally. Called from a wide range of button-pressed triggers (PB_CALC_SOQ, PB_ESOQ, PB_EXCEL, PB_OK, PB_SEARCH) and from ON-MESSAGE to surface informational feedback, as well as from ON-ERROR and validation triggers to report error conditions. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Populates a list item from a named record group (`p_rg_name`), optionally pre-selecting the entry identified by `p_select`. Called during WHEN-NEW-FORM-INSTANCE to initialise drop-down list items with their data-driven values before the form is presented to the user. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message and title by `mesg_code` from the application error table; displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE for error type `'E'`. Used in ON-ERROR to handle specific ORA error codes with user-friendly messages. |

**Total Active Routines:** 6 of 24 in DPL.pld source

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher. Each WEBUTIL bean item fires a WHEN-CUSTOM-ITEM-EVENT trigger passing the event name and its serialised parameters; `CustomEventHandler` routes the call to the appropriate WEBUTIL_CORE handler so that asynchronous client-side responses (file transfers, host commands, OLE results, etc.) are processed on the server side. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Returns TRUE if the supplied WebUtil handle is NULL. Called in VIEW_EXCEL_REP to check whether a WebUtil file-transfer or handle object has been initialised before attempting to use it; prevents NULL-pointer failures during CSV export. |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

### webutil.pld (`WEBUTIL_FILE`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pt_soq_new_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| FILE_SAVE_DIALOG | Function | Function(directory_name Varchar2 := NULL, file_name Varchar2 := NULL, file_filter Varchar2 := NULL, title Varchar2 := NULL) RETURN Varchar2 | ProgramUnit: VIEW_EXCEL_REP | Presents the client-side OS file-save dialog, allowing the user to choose a destination path and filename. Returns the fully qualified path selected by the user, or NULL if the dialog is cancelled. Referenced in VIEW_EXCEL_REP to let the user specify where the exported Excel/CSV file should be saved on the client machine; the call is currently commented out, indicating the save-path selection step has been deferred or replaced by a fixed path. |

**Total Active Routines:** 0 of 25 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_FILE_TRANSFER`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pt_soq_new_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| URL_To_Client | Function | Function(sourceURL in VARCHAR2, clientDestination in VARCHAR2, fileSize in PLS_INTEGER default 0) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Downloads a file from `sourceURL` on the application server to `clientDestination` on the client machine, returning TRUE on success. Referenced in VIEW_EXCEL_REP as part of the Excel export flow to transfer the server-generated CSV/XLS file to the user's local filesystem; the call is currently commented out, suggesting the transfer step is inactive or handled by an alternative mechanism. |

**Total Active Routines:** 0 of 21 in webutil.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_HOST`)

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``pt_soq_new_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| Host | Function | Function(cmd in VARCHAR2) RETURN PLS_INTEGER | ProgramUnit: VIEW_EXCEL_REP | Executes the OS shell command supplied in `cmd` on the application server and returns the process exit code as a PLS_INTEGER. Referenced in VIEW_EXCEL_REP to invoke a server-side command (e.g., opening or converting the generated report file) as part of the Excel export workflow; the call is currently commented out, indicating this server-side execution step is not active in the current build. |

**Total Active Routines:** 0 of 14 in webutil.pld source
**Inactive / commented-only routines:** 1

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Dealer Location Lookup Service | AM_DEALER_LOC | Parent group, consignee code, principal | List of active dealer locations (location code, description, dealer map code) | Retrieves all live dealer locations under a given consignee and principal for scope selection in the SOQ form | `GET /api/dealer-locations?consignee={code}&principal={code}&parentGroup={code}` |
| MS-002 | Last SOQ Date and Category Service | PT_SOQ_MUL_NEW, PM_CATEGORY | Dealer, location, parent group, company | Last SOQ as-on date; last SOQ parts category description | Retrieves the date and parts category of the most recent SOQ run for a given dealer/location/company context | `GET /api/soq/last-run?dealer={code}&location={code}&parentGroup={code}&company={code}` |
| MS-003 | Part Pricing and Settings Service | PM_PART, PM_PART_VAR | Principal, dealer, location, part number, parent group | Allow decimal quantity flag, minimum pack quantity, purchase price | Retrieves pricing and decimal-quantity settings for a given part at a dealer/location, used to enrich each SOQ results row | `GET /api/parts/{partNumber}/pricing?dealer={code}&location={code}&parentGroup={code}&principal={code}` |
| MS-004 | SOQ Consumption Detail Service | SP_SOQ_POPULATE_CONSUMPTION | Dealer map code, principal, parent group, location, company, root part number, number of months, reference date | Monthly consumption figures (array), current stock, on-order quantity, error code, error message | Retrieves historical monthly consumption, current stock, and on-order quantity for a given root part at a dealer location over a specified number of months | `GET /api/soq/consumption?part={rootPartNumber}&dealer={dealerMapCd}&location={code}&months={n}&asOfDate={date}` |
| MS-005 | SOQ Root Part Lookup Service | PM_PART | Dealer map code, principal, part number | Root part number | Resolves a part number to its root part number for the given dealer and principal, used before calling the consumption service | `GET /api/parts/{partNumber}/root-part?dealer={dealerMapCd}&principal={code}` |
| MS-006 | Supplier Validation Service | GM_PARTY | Parent group, dealer, party type, multi-location flag, party code | Party name (if found), error indicator | Validates that a given supplier code exists as an active supplier in the party master for the current operating mode | `GET /api/suppliers/{partyCode}?dealer={code}&parentGroup={code}&mode={single\|multi}` |
| MS-007 | Supplier List Service | GM_PARTY | Parent group, dealer, party type, multi-location flag | List of suppliers (party code, party name) | Provides the list of valid suppliers for the current operating mode; used to populate the Supplier selection list in PO Details | `GET /api/suppliers?dealer={code}&parentGroup={code}&mode={single\|multi}` |
| MS-008 | On-Order Update Service | PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Parent group, dealer, location, order list (part number, quantity per row), PO status, user name | Error code, error message | Updates on-order quantities for a list of parts; used when generating a purchase order from amended SOQ quantities | `POST /api/orders/on-order-update` |
| MS-009 | SOQ Excel Export Service | PT_SOQ_MUL_NEW (and related) | Query parameters (dealer, location, filters), column name | CSV file stream | Executes the SOQ data query and returns the results as a downloadable CSV file; replaces the server-side file-write mechanism of VIEW_EXCEL_REP | `GET /api/soq/export/csv?dealer={code}&location={code}&category={cat}&...` |
| MS-010 | Copyright Declaration Service | SF_COPYRIGHT_DECLARATION | None | Copyright text string | Returns the current copyright declaration text for display in application form headers | `GET /api/system/copyright` |

**Total Microservices Identified: 10**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation and Reset | KEY-CLRFRM (form-level clear/reset key) or form open | 1. Clear the form and re-enable editable fields. 2. Set default filter values (category and zero-SOQ flag). 3. Load dealer locations via FETCH_LOC. 4. Retrieve and display the last SOQ date and category via GET_LAST_SOQ_DATE. 5. Display copyright notice. 6. Position cursor at the Parts Category field. | Consignee-level mode (P_STOCK_YARD) determines whether all locations or only the current location are loaded in step 3. | Form displayed at its default state; cursor at Parts Category field; location list and last SOQ date populated. |
| WF-002 | SOQ Calculation Parameter Setup | User interaction - setting filter fields and location/classification selections | 1. User enters or confirms Parts Category (validated as mandatory). 2. User enters number of months of consumption to consider (validated as mandatory). 3. User selects or deselects locations using the Consider checkboxes; system validates at least one remains selected when the calculation is initiated. 4. User ticks inventory classification checkboxes; system validates at least one is ticked when the calculation is initiated. 5. Optionally toggle Show Zero SOQ; grid is refreshed with new filter. 6. Initiate the SOQ calculation via the Calculate SOQ button (DPL-subclassed). | Location-scope mode (consignee-level vs single-location) determines which locations are loaded. At least one location and one classification must be selected for the calculation to proceed. | SOQ calculation parameters confirmed; BUILD_WHERE constructs the location array and ABC-class filter; SOQ query is executed and results displayed in the grid. |
| WF-003 | SOQ Results Review and Amendment | User interaction - reviewing the SOQ results grid | 1. SOQ results grid is populated; each row is enriched with purchase price, minimum pack quantity, and decimal-quantity flag (POST-QUERY). 2. User reviews each part's suggested quantity, on-hand stock, on-order quantity, average consumption, and purchase price. 3. User optionally presses Show Consumption for a selected part to view monthly consumption detail by location. 4. User enters amended quantities in the Amended Quantity field; system applies decimal-quantity validation and auto-truncation as needed. 5. User optionally changes Sort By or Sort Type; grid re-sorts automatically. | Decimal-quantity flag determines whether decimal values are allowed or truncated. Parts master lookup failure determines whether price/settings default to zero or raise an error. | All desired amendments entered; amended quantities ready for saving or purchase order generation. |
| WF-004 | Save SOQ Amendments | KEY-COMMIT (form-level save key) or Save button (DPL-subclassed) | 1. ENTER is called to finalise all form input. 2. GENERAL.CHECK_FORM_FAILURE confirms no failure after ENTER. 3. COMMIT_FORM writes all changes to the database; PRE-UPDATE stamps Modified By and Modified Date on each changed row before the write. 4. GENERAL.CHECK_FORM_FAILURE confirms the commit succeeded. 5. Form is cleared back to its default state. | If either CHECK_FORM_FAILURE call detects a failure, the commit is aborted and the form remains open with current data. | SOQ amendments committed to PT_SOQ_MUL_NEW; audit stamps applied; form cleared and ready for next session. |
| WF-005 | PO Details Entry and Purchase Order Generation | User navigation to the PO Details panel | 1. On navigation to PO Details, system assigns the correct supplier list based on operating mode (WHEN-NEW-BLOCK-INSTANCE). 2. User selects a supplier from the look-up list; system validates the supplier against the party master. 3. User enters PO Status; system validates as mandatory. 4. User initiates PO generation via the Generate PO button (DPL-subclassed); UPDATE_PO_STOCK collects amended quantities and calls PK_VALIDATE_PARTS.UPDATE_ON_ORDER. | Operating mode determines which supplier list is shown. Supplier validation may fail if the code is not in the master. On-order update procedure may return an error requiring the user to resolve before proceeding. | On-order quantities updated in the database; purchase order generated. |
| WF-006 | Show Consumption Detail | WHEN-BUTTON-PRESSED (Show Consumption button - SB_TITLE.SHOW_CON) | 1. System checks that a part number is selected in the SOQ grid. 2. Reference date is set (current month excluded by default). 3. Consumption detail panel is cleared. 4. For each dealer location in scope, system retrieves the root part number, calls SP_SOQ_POPULATE_CONSUMPTION, and populates the monthly columns, current stock, on-order quantity, and average consumption. 5. Focus returns to the SOQ results block. | If no part is selected, an error is shown and the flow ends. If no locations are in scope, a note is shown and the panel is left empty. If root-part lookup fails, an error is shown and processing halts for that location. | Consumption detail panel displays monthly figures, stock, and on-order quantity per location for the selected part. |
| WF-007 | SOQ Report Printing | WHEN-BUTTON-PRESSED (Report button - B_PRN.PB_REP) | 1. User navigates to the Print panel (CN_DATE). 2. User enters the As On Date for the report. 3. User presses the Report button; if As On Date is present, the FT_PRINT form trigger (DPL-subclassed) is executed to generate the PT_SOQHS report. 4. User can press Back to return to the PO generation screen without printing. | If As On Date is blank, pressing Report has no effect. | SOQ summary report generated and sent to the configured output destination, or user returns to the PO screen. |
| WF-008 | Excel Export of SOQ Data | User action on the Excel export button (DPL-subclassed, EXTERNAL / NOT IN BUNDLE) | 1. VIEW_EXCEL_REP is called with the SOQ query and column name. 2. File name is generated from the current user ID and timestamp. 3. If the file path contains spaces, the file is redirected to C: root with a notification. 4. In-memory record group is created from the query; row count is determined and capped at 65,535 if exceeded. 5. Data is written row by row to the server-side CSV file. 6. File is opened in the user's browser via WEB.SHOW_DOCUMENT. | If row count exceeds 65,535, data is truncated and user is notified. If any error occurs during export, the error is shown and the trigger fails. | CSV file written to server and opened in the user's browser. |
| WF-009 | Form Exit | KEY-EXIT (form-level exit key) | 1. System clears the session client-info register (DBMS_APPLICATION_INFO.SET_CLIENT_INFO to null). 2. System resets the session module name and action name to blank (DBMS_APPLICATION_INFO.SET_MODULE). 3. Form closes without saving or validating pending changes (EXIT_FORM(NO_VALIDATE)). | None - exit always proceeds unconditionally. | Form closed; session monitoring entries cleared; all unsaved changes discarded. |
| WF-010 | Error Interception and Display | ON-ERROR (form-level error handler) | 1. Error code is examined against known codes. 2. For recognised error codes (invalid date, wrong date format, non-numeric input, item-level error, referential integrity violation, concurrent update conflict), a specific business-friendly message is displayed and the operation is aborted. 3. For any remaining SQL error, the database error text is displayed, changes are rolled back, and the operation is aborted. 4. Query-limit notifications are silently suppressed. | Each error code branch produces a different message and outcome (trigger failure, rollback, or suppression). | Error is surfaced with a clear business message; data integrity preserved via rollback where applicable; form remains open for user to correct and retry. |

**Total Workflows Identified: 10**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a WebUtil handle is checked before use, then returns whether it is null to prevent null-pointer failures during CSV export |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-002 | CHECK_FORM_FAILURE | Validation | Trigger: KEY-COMMIT in Form | /api/v1/pld/check_form_failure | When a form operation fails, then the error is displayed and the commit is aborted |
| PLD-003 | CHECK_NULL | Validation | Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_PRN.NB_AS_ON_DATE, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.PART_CATEG, Trigger: WVI in B_PARTY.PO_STATUS | /api/v1/pld/check_null | When a mandatory field is null, then an error message is displayed and navigation is blocked |
| PLD-004 | DISP_TEXT | Business Logic | ProgramUnit: BUILD_WHERE, Trigger: ON-ERROR in Form, Trigger: POST-QUERY in B_SOQ, Trigger: WHEN-BUTTON-PRESSED in SB_TITLE.SHOW_CON, Trigger: WHEN-VALIDATE-ITEM in B_PARTY.PARTY_CD, Trigger: WHEN-VALIDATE-ITEM in B_SOQ.AMD_SOQ_QTY, Trigger: WHEN-VALIDATE-ITEM in SB_TITLE.NO_MONTHS | /api/v1/pld/disp_text | When a message needs to be shown to the user, then an alert dialog is displayed with the supplied text and title |
| PLD-005 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When a known error code is raised, then the corresponding user-friendly message is displayed and execution is halted |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``pt_soq_new_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PK_VALIDATE_PARTS.UPDATE_ON_ORDER | Business Logic | ProgramUnit: UPDATE_PO_STOCK | /api/v1/packages/pk_validate_parts/update_on_order | When SOQ amended quantities are committed, then on-order stock figures in PM_PART_VAR are updated for each selected part, creating missing variant records as required |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Suggested Order Quantity table (PT_SOQ_MUL_NEW) | Oracle Database Table | Primary data store for SOQ records per part per dealer/location/company; the form reads and updates this table. | Read: SOQ results grid query retrieves all SOQ rows for the current dealer/location/company. Write: PRE-UPDATE stamps Modified By and Modified Date; KEY-COMMIT commits amended quantity changes. | Write errors are caught by the ON-ERROR handler and surfaced to the user; COMMIT_FORM failure is detected by GENERAL.CHECK_FORM_FAILURE. |
| Parts master (PM_PART) | Oracle Database Table | Provides part attributes including decimal-quantity flag, minimum pack quantity, and category code; also used for root-part number resolution. | Read only: queried in POST-QUERY (B_SOQ) to enrich each SOQ row, and in WHEN-BUTTON-PRESSED (SHOW_CON) to look up the root part number. | NO_DATA_FOUND applies safe defaults (decimal flag = 'N', min qty = 0, price = 0) and continues; VALUE_ERROR and WHEN OTHERS display descriptive error messages and abort the row. |
| Parts price variant master (PM_PART_VAR) | Oracle Database Table | Provides the current purchase price for each part at the dealer/location level. | Read only: joined with PM_PART in the POST-QUERY enrichment query. | Same error handling as PM_PART; price defaults to 0 on NO_DATA_FOUND. |
| Dealer location master (AM_DEALER_LOC) | Oracle Database Table | Provides the list of live dealer locations for the current consignee and principal; used to populate the location selection list. | Read only: queried by FETCH_LOC program unit when the form initialises or the consignee-level checkbox changes. | No explicit error handler in FETCH_LOC; an empty result set results in an empty location list and no locations available for calculation. |
| Party/supplier master (GM_PARTY) | Oracle Database Table | Provides supplier details for validation and list population in the PO Details panel. | Read only: queried by WHEN-VALIDATE-ITEM (B_PARTY.PARTY_CD) to validate a supplier code, and used as the source for the RG_NON_MUL_PARTY and RG_MUL_PARTY record groups. | NO_DATA_FOUND raises *"Enter a valid Supplier"*; WHEN OTHERS displays sqlerrm; both abort the trigger. |
| Parts category master (PM_CATEGORY) | Oracle Database Table | Provides the category description for the last SOQ run. | Read only: joined in the GET_LAST_SOQ_DATE query to retrieve the category description. | NO_DATA_FOUND and WHEN OTHERS silently clear the category field and continue. |
| On-order update package (PK_VALIDATE_PARTS) | Oracle Package | Updates on-order stock quantities for a list of parts when a purchase order is generated. | Write: UPDATE_PO_STOCK calls PK_VALIDATE_PARTS.UPDATE_ON_ORDER with the order list, PO status, and user context. | Non-zero return code from the procedure surfaces the error message in the error canvas and blocks the trigger. |
| SOQ consumption procedure (SP_SOQ_POPULATE_CONSUMPTION) | Oracle Standalone Procedure | Retrieves monthly consumption history and current stock/on-order figures for a given root part at a dealer location. | Read: called by WHEN-BUTTON-PRESSED (SHOW_CON) for each dealer location in scope; returns consumption array, stock, on-order, error code, and error message. | Non-zero error code from the procedure surfaces the error message and aborts the loop. |
| Oracle Database Application Info (DBMS_APPLICATION_INFO) | Oracle Built-in Package | Session attribution for database monitoring; sets client-info and module/action fields in the current session. | Write: SET_CLIENT_INFO and SET_MODULE are called at form open (PRE-FORM) and at exit (KEY-EXIT). | No error handling; failure is silent. |

### 20.2 External System Integrations

The form has one external file-system integration used for the Excel export feature. No other external system integrations are evidenced.

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| IAS Report Server file system | Server-side file write | The VIEW_EXCEL_REP program unit writes the CSV export file to the Oracle IAS reports server print directory (/iashome/ias/reports/printer/). | Direct file I/O via Oracle Forms TEXT_IO | /iashome/ias/reports/printer/{filename}.csv (server-side path) | CSV rows written sequentially from the in-memory record group | Success: file written and URL opened in browser. Error: WHEN OTHERS displays *"Error  - "* + error code + error text and raises trigger failure. |
| URL path configuration file | Server-side file read | The VIEW_EXCEL_REP program unit reads the base URL path for the CSV file from a configuration text file on the server, then uses this URL to open the file in the user's browser. | Direct file I/O via Oracle Forms TEXT_IO | /reports/DMS/excelpath.txt (server-side configuration file) | URL path string (single line read) | Success: URL read and used to construct the browser-accessible file path. No explicit error handler for read failure - a TEXT_IO failure would be caught by the outer WHEN OTHERS. |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| PT_SOQHS | Runtime (INFERRED - Oracle Reports server) | As On Date (`NB_AS_ON_DATE`), P_PRINT, P_REP_ID, and dealer/location session context (INFERRED) | INFERRED - printed or screen output via Oracle Reports | FT_PRINT form trigger (DPL-subclassed object group trigger), invoked from WHEN-BUTTON-PRESSED on B_PRN.PB_REP when the As On Date has been entered |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the PT_SOQ_NEW form.

### 21.1 Catalogue Index

101 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--BUILD_WHERE) | BUILD_WHERE |
| [SP-002](#SP-002--FETCH_LOC) | FETCH_LOC |
| [SP-003](#SP-003--GET_LAST_SOQ_DATE) | GET_LAST_SOQ_DATE |
| [SP-004](#SP-004--LOC_CATEG_POPULATION) | LOC_CATEG_POPULATION |
| [SP-005](#SP-005--SORT_BLOCK) | SORT_BLOCK |
| [SP-006](#SP-006--UPDATE_PO_STOCK) | UPDATE_PO_STOCK |
| [SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-008](#SP-008--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-009](#SP-009--D2KWUTIL.CREATED_DATE) | D2KWUTIL.CREATED_DATE |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-011](#SP-011--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-012](#SP-012--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-013](#SP-013--D2KWUTIL.D2KWUTIL_FILEINFO) | D2KWUTIL.D2KWUTIL_FILEINFO |
| [SP-014](#SP-014--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-015](#SP-015--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-016](#SP-016--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-017](#SP-017--D2KWUTIL.FILE_INFO) | D2KWUTIL.FILE_INFO |
| [SP-018](#SP-018--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-019](#SP-019--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-020](#SP-020--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-021](#SP-021--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-022](#SP-022--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-023](#SP-023--GENERAL.CHECK_NULL) | GENERAL.CHECK_NULL |
| [SP-024](#SP-024--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-025](#SP-025--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-026](#SP-026--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-027](#SP-027--PK_VALIDATE_PARTS.UPDATE_ON_ORDER) | PK_VALIDATE_PARTS.UPDATE_ON_ORDER |
| [SP-028](#SP-028--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-029](#SP-029--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-030](#SP-030--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-031](#SP-031--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-032](#SP-032--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-033](#SP-033--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-034](#SP-034--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-035](#SP-035--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-036](#SP-036--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-037](#SP-037--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-038](#SP-038--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-039](#SP-039--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-040](#SP-040--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-041](#SP-041--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-042](#SP-042--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-043](#SP-043--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-044](#SP-044--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-045](#SP-045--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-046](#SP-046--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-047](#SP-047--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-048](#SP-048--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-049](#SP-049--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-050](#SP-050--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-051](#SP-051--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-052](#SP-052--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-053](#SP-053--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-054](#SP-054--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-055](#SP-055--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-056](#SP-056--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-057](#SP-057--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-058](#SP-058--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-059](#SP-059--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-060](#SP-060--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-061](#SP-061--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-062](#SP-062--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-063](#SP-063--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-064](#SP-064--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-065](#SP-065--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-066](#SP-066--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-067](#SP-067--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-068](#SP-068--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-069](#SP-069--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-070](#SP-070--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-071](#SP-071--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-072](#SP-072--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-073](#SP-073--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-074](#SP-074--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-075](#SP-075--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-076](#SP-076--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-077](#SP-077--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-078](#SP-078--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-079](#SP-079--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-080](#SP-080--ADD_ERROR) | ADD_ERROR |
| [SP-081](#SP-081--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-082](#SP-082--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-083](#SP-083--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-084](#SP-084--DEBUGLOG) | DEBUGLOG |
| [SP-085](#SP-085--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-086](#SP-086--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-087](#SP-087--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-088](#SP-088--READ_REGISTRY) | READ_REGISTRY |
| [SP-089](#SP-089--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-090](#SP-090--SETDEBUG) | SETDEBUG |
| [SP-091](#SP-091--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-092](#SP-092--SF_PRINCIPAL_MAP_CD) | SF_PRINCIPAL_MAP_CD |
| [SP-093](#SP-093--SP_CALCULATE_SOQ_NEW) | SP_CALCULATE_SOQ_NEW |
| [SP-094](#SP-094--SP_GET_CONSUMPTION) | SP_GET_CONSUMPTION |
| [SP-095](#SP-095--SP_INSERT_PM_PART_VAR) | SP_INSERT_PM_PART_VAR |
| [SP-096](#SP-096--SP_SOQ_POPULATE_CONSUMPTION) | SP_SOQ_POPULATE_CONSUMPTION |
| [SP-097](#SP-097--SP_UPDATE_PART_PRICE) | SP_UPDATE_PART_PRICE |
| [SP-098](#SP-098--SP_UPDATE_PO_NUMBER_NEW) | SP_UPDATE_PO_NUMBER_NEW |
| [SP-099](#SP-099--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-100](#SP-100--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-101](#SP-101--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - BUILD_WHERE

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

BUILD_WHERE validates user selections on the Suggested Order Quantity Processing screen and constructs two filter segments used by downstream processing: (1) an indexed collection of selected location codes and their dealer-map codes, returned via the OUT parameter po_loc, and (2) a comma-delimited inventory-classification string (A, B, C, and/or null-class) stored in the form parameter :parameter.p_abc. The procedure enforces that at least one location and at least one inventory classification are selected before any further processing can proceed.

---
**Input Parameters**

No input parameters.

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_loc | pk_plsql_table.code_tab2 | OUT |

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-024](#SP-024--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to block B_LOC and position the cursor at the first record.
- Step 2 - Iterate through every record in B_LOC; for each record where the check_yn flag equals 'Y', set the location-selected flag (lb_flag) to TRUE, increment the counter ln_cnt, and store the record's loc_cd in po_loc(ln_cnt).col1 and dealer_map_cd in po_loc(ln_cnt).col2.
- Step 3 - Continue the loop until SYSTEM.LAST_RECORD is TRUE, advancing to the next record on each iteration.
- Step 4 - After the loop, evaluate lb_flag; if no location was selected (lb_flag is still FALSE), invoke GENERAL.DISP_TEXT to display the error message 'Atlease one location should be considered' with severity 'Error', then raise FORM_TRIGGER_FAILURE to halt execution.
- Step 5 - Initialise :parameter.p_abc to NULL.
- Step 6 - Evaluate the four inventory-classification checkboxes (check_a, check_b, check_c, check_null) on block SB_TITLE; if all four are 'N' (or NULL), invoke GENERAL.DISP_TEXT to display 'Atlease one Inventory Clasification should be considered' with severity 'Error', then raise FORM_TRIGGER_FAILURE.
- Step 7 - For each classification checkbox that is 'Y', assign the corresponding quoted literal to its local variable: lv_a = '''A''', lv_b = '''B''', lv_c = '''C''', lv_null = ''' ''' (space).
- Step 8 - Build :parameter.p_abc by appending each non-null classification literal in order (A, then B, then C, then null-class), separating successive values with a comma. The first non-null value is assigned directly; each subsequent value is concatenated with a leading comma.

---
**Decision Points**

DP-001

Condition: NVL(:b_loc.check_yn, 'N') = 'Y' for the current B_LOC record.

TRUE: Set lb_flag to TRUE, increment ln_cnt, and populate po_loc(ln_cnt).col1 with loc_cd and po_loc(ln_cnt).col2 with dealer_map_cd.

FALSE: Skip the current record; no entry is added to po_loc.

---

DP-002

Condition: lb_flag is FALSE after the B_LOC loop completes (no location was checked).

TRUE: Call GENERAL.DISP_TEXT with message 'Atlease one location should be considered' and severity 'Error', then raise FORM_TRIGGER_FAILURE to stop processing.

FALSE: Continue to inventory-classification validation.

---

DP-003

Condition: All four inventory-classification flags (check_a, check_b, check_c, check_null) resolve to 'N'.

TRUE: Call GENERAL.DISP_TEXT with message 'Atlease one Inventory Clasification should be considered' and severity 'Error', then raise FORM_TRIGGER_FAILURE to stop processing.

FALSE: Proceed to assign quoted literals for each selected classification.

---

DP-004

Condition: :parameter.p_abc is NOT NULL when appending a subsequent classification literal (lv_b, lv_c, or lv_null).

TRUE: Concatenate a comma followed by the new literal to the existing :parameter.p_abc value.

FALSE: Assign the new literal directly to :parameter.p_abc.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - At least one location record in block B_LOC must have check_yn = 'Y'; failure to select any location is a blocking error that prevents further processing.
- BR-002 - Each selected location contributes exactly one entry to the po_loc collection, storing both the location code (col1) and its associated dealer-map code (col2).
- BR-003 - At least one inventory classification (A, B, C, or null-class) must be selected on the SB_TITLE block; selecting none is a blocking error that prevents further processing.
- BR-004 - Each selected inventory classification is represented as a quoted SQL literal (e.g., 'A') within :parameter.p_abc, enabling the value to be embedded directly in a dynamic WHERE clause.
- BR-005 - The null-class selection (check_null) is treated as a distinct classification represented by a quoted space literal (''' '''), allowing parts with no assigned classification to be included in processing.
- BR-006 - The classification literals in :parameter.p_abc are always ordered A, B, C, null-class, regardless of the sequence in which the user selected the checkboxes.
- BR-007 - Both validation failures (no location selected; no classification selected) are surfaced to the user via GENERAL.DISP_TEXT with severity 'Error' before the form trigger is halted.

---
**Implementation Logic**

```plsql
/*Check that atleast one location is selected. Build the location and part class segments of the where clauses */

PROCEDURE build_where (po_loc OUT pk_plsql_table.code_tab2)--pk_plsql_table.code_tab)
IS
      lb_flag   BOOLEAN := FALSE;
      ln_cnt    NUMBER  := 0;
      lv_a      VARCHAR2(10) := NULL;
      lv_b      VARCHAR2(10) := NULL;
      lv_c      VARCHAR2(10) := NULL;
      lv_null   VARCHAR2(10) := NULL;
      
BEGIN
      GO_BLOCK ('B_LOC');
      FIRST_RECORD;

      LOOP
            IF NVL ( :b_loc.check_yn, 'N') = 'Y' THEN
                  lb_flag := TRUE;
                  ln_cnt := ln_cnt + 1;
                  --po_loc (ln_cnt) := :b_loc.loc_cd;        --commented by Anjiv on 29/11/2006
                  po_loc (ln_cnt).col1 := :b_loc.loc_cd;
                  po_loc (ln_cnt).col2 := :b_loc.dealer_map_cd;
            END IF;
            EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
            NEXT_RECORD;
      END LOOP;

      IF NOT lb_flag THEN
            general.disp_text ('Atlease one location should be considered', 'Error');
            RAISE form_trigger_failure;
      END IF;
/* Build the Part class segment of where clause */
      /*
      IF (NVL ( :sb_title.check_a, 'N') = 'Y'
          AND NVL (:sb_title.check_b, 'N') = 'Y'
          AND NVL (:sb_title.check_c, 'N') = 'Y')
         OR (NVL ( :sb_title.check_a, 'N') = 'N'
             AND NVL (:sb_title.check_b, 'N') = 'N'
             AND NVL (:sb_title.check_c, 'N') = 'N') THEN
            :parameter.p_abc := '''A'',''B'',''C''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'Y'
             AND NVL (:sb_title.check_b, 'N') = 'Y'
             AND NVL (:sb_title.check_c, 'N') = 'N') THEN
            :parameter.p_abc := '''A'',''B''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'Y'
             AND NVL (:sb_title.check_b, 'N') = 'N'
             AND NVL (:sb_title.check_c, 'N') = 'Y') THEN
            :parameter.p_abc := '''A'',''C''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'N'
             AND NVL (:sb_title.check_b, 'N') = 'Y'
             AND NVL (:sb_title.check_c, 'N') = 'Y') THEN
            :parameter.p_abc := '''B'',''C''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'Y'
             AND NVL (:sb_title.check_b, 'N') = 'N'
             AND NVL (:sb_title.check_c, 'N') = 'N') THEN
            :parameter.p_abc := '''A''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'N'
             AND NVL (:sb_title.check_b, 'N') = 'Y'
             AND NVL (:sb_title.check_c, 'N') = 'N') THEN
            :parameter.p_abc := '''B''';
      ELSIF (NVL ( :sb_title.check_a, 'N') = 'N'
             AND NVL (:sb_title.check_b, 'N') = 'N'
             AND NVL (:sb_title.check_c, 'N') = 'Y') THEN
            :parameter.p_abc := '''C''';
      END IF;
      */
      	:parameter.p_abc := NULL;
      IF NVL(:sb_title.check_a, 'N') = 'N' AND
      	 NVL(:sb_title.check_b, 'N') = 'N' AND
      	 NVL(:sb_title.check_c, 'N') = 'N' AND
      	 NVL(:sb_title.check_null, 'N') = 'N' THEN
	      general.disp_text ('Atlease one Inventory Clasification should be considered', 'Error');
	      RAISE form_trigger_failure;
	    ELSE
	      IF NVL(:sb_title.check_a, 'N') = 'Y' THEN
	      	lv_a := '''' || 'A' || '''';
	      END IF;
	      IF NVL(:sb_title.check_b, 'N') = 'Y' THEN
	      	lv_b := '''' || 'B' || '''';
	      END IF;
	      IF NVL(:sb_title.check_c, 'N') = 'Y' THEN
	      	lv_c := '''' || 'C' || '''' ;
	      END IF;
	      IF NVL(:sb_title.check_null, 'N') = 'Y' THEN
	      	lv_null := '''' || ' ' || '''';
	      END IF;
			END IF;      	   
      
      IF lv_a IS NOT NULL THEN
      	:parameter.p_abc := lv_a;
      END IF;
      IF lv_b IS NOT NULL THEN
      	IF :parameter.p_abc IS NOT NULL THEN
      		:parameter.p_abc := :parameter.p_abc || ',' || lv_b;
      	ELSE
      		:parameter.p_abc := lv_b;
      	END IF;
      END IF;
      IF lv_c IS NOT NULL THEN
      	IF :parameter.p_abc IS NOT NULL THEN
      		:parameter.p_abc := :parameter.p_abc || ',' || lv_c;
      	ELSE
      		:parameter.p_abc := lv_c;
      	END IF;
      END IF;
      IF lv_null IS NOT NULL THEN
      	IF :parameter.p_abc IS NOT NULL THEN
      		:parameter.p_abc := :parameter.p_abc || ',' || lv_null;
      	ELSE
      		:parameter.p_abc := lv_null;
      	END IF;
      END IF;
END;
```

#### SP-002 - FETCH_LOC

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_new_fmb.xml [Trigger: WHEN-CHECKBOX-CHANGED]
- pt_soq_new_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Loads the list of dealer locations available for the current session into the location selection panel. When operating in consignee-level mode (all_rec = 'Y'), all live locations under the consignee and principal are fetched from the dealer location master, displayed with their descriptions, stored in an in-memory location table, and pre-selected. When operating in standard single-location mode, only the current session location is loaded and pre-selected. After loading, the location panel is locked against further user modification and focus returns to the criteria block.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| all_rec | CHAR | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The in-memory location table is cleared if it already contains entries from a previous load.
- Step 2 - The location list block is temporarily unlocked to allow the system to insert new rows.
- Step 3 - The location list display is cleared and navigation moves to the first row.
- Step 4 - If operating in consignee-level mode, the procedure queries all live dealer locations belonging to the consignee and principal, populates each row with the location code, description, and dealer map code, stores the data in the in-memory table, and pre-ticks each location's selection checkbox.
- Step 5 - If operating in standard single-location mode, a single row is populated with the current session location code, description, and dealer map code from the session context; it is stored in the in-memory table and pre-ticked.
- Step 6 - The location list block is locked again to prevent further user modifications and focus is returned to the criteria block.

---
**Decision Points**

DP-001

Condition: The in-memory location table already contains rows from a previous load (dealer_loc.dloc_tab.COUNT > 0).

TRUE: The in-memory table is deleted (cleared) before repopulation.

FALSE: No clearing action needed; proceed directly to populating.

DP-002

Condition: The input parameter all_rec = 'Y' (consignee-level mode is active).

TRUE: Query AM_DEALER_LOC for all live locations under the consignee and principal; loop through all results, populate each row in the location block, store in the in-memory table, and pre-select each location.

FALSE: Populate a single location row from the current session context (GLOBAL.LOC_CD, parameter P_LOC_DESC, GLOBAL.DEALER); store in position 1 of the in-memory table and pre-select it.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - Only live dealer locations (those with a service live date) are eligible for selection; inactive or unlaunched locations are excluded from the list.
- BR-002 - In consignee-level mode, all qualifying locations are pre-selected by default; the user may subsequently deselect individual locations.
- BR-003 - In standard single-location mode, exactly one location (the current session location) is loaded and pre-selected; the list is not editable.

---
**Implementation Logic**

```plsql
PROCEDURE fetch_loc (all_rec CHAR DEFAULT 'N')
IS
      CURSOR dealer_cur
      IS
            SELECT loc_cd,
                   loc_desc,
                   dealer_map_cd                /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
            FROM   am_dealer_loc
            WHERE  parent_group = :GLOBAL.parent_group
                   --Commented by Anjiv on 03-03-06 to generate SOQ at the consigne level
                   --and           dealer_map_cd = :global.dealer;
            AND consg_cd = :parameter.p_consg_cd
            AND principal_map_cd = :GLOBAL.PRINCIPAL  --added by akanksha for multicompany change
            and SRV_LIVE_DATE is not null;             /*Added by Anjiv on 19/01/2007 to show live locations only.*/
BEGIN
      IF dealer_loc.dloc_tab.COUNT > 0 THEN                                      --initialise the plsql table of dealer locations
            dealer_loc.dloc_tab.DELETE;
      END IF;
      
      set_block_property('b_loc',insert_allowed,property_true);
      set_block_property('b_loc',update_allowed,property_true);
      set_block_property('b_loc',delete_allowed,property_true);
      
      GO_BLOCK ('b_loc');
      CLEAR_BLOCK (no_validate);
      FIRST_RECORD;
      IF all_rec = 'Y' THEN
            FOR dealer_rec IN dealer_cur
            LOOP
                  :b_loc.srl_no :=:SYSTEM.cursor_record;
                  :b_loc.loc_cd := dealer_rec.loc_cd;
                  :b_loc.loc_desc := dealer_rec.loc_desc;
                  :b_loc.dealer_map_cd := dealer_rec.dealer_map_cd; /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col1 := dealer_rec.loc_cd;
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col2 := dealer_rec.loc_desc;
                  dealer_loc.dloc_tab (:SYSTEM.cursor_record).col3 := dealer_rec.dealer_map_cd;    /*Added by Anjiv on 01/12/2006 to get dealer_map_cd under the consignee */
                  :b_loc.check_yn := 'Y';
                  /*
                  SET_ITEM_INSTANCE_PROPERTY ('b_loc.check_yn', current_record, update_allowed, property_false);
                  SET_ITEM_INSTANCE_PROPERTY ('b_loc.check_yn', current_record, insert_allowed, property_false);
                  */
                  NEXT_RECORD;
            END LOOP;
      ELSE
            :b_loc.check_yn := 'Y';
            :b_loc.srl_no:=1;
            :b_loc.loc_cd := :GLOBAL.loc_cd;
            :b_loc.loc_desc := :parameter.p_loc_desc;
            :b_loc.dealer_map_cd := :GLOBAL.dealer;
            dealer_loc.dloc_tab (1).col1 := :GLOBAL.loc_cd;
            dealer_loc.dloc_tab (1).col2 := :parameter.p_loc_desc;
            dealer_loc.dloc_tab (1).col3 := :GLOBAL.dealer;
      END IF;
      
      set_block_property('b_loc',insert_allowed,property_false);
			set_block_property('b_loc',update_allowed,property_false);
      set_block_property('b_loc',delete_allowed,property_false);
      --GO_BLOCK ('b_loc');
      --FIRST_RECORD;
      GO_BLOCK ('SB_TITLE');
      --go_item('SB_TITLE.PART_CATEG');
END;
```

#### SP-003 - GET_LAST_SOQ_DATE

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_new_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Retrieves the date and parts category of the most recent Suggested Order Quantity run for the current dealer, location, parent group, and company context, and displays them in the header fields. If no previous SOQ record exists, both fields are left blank without raising an error.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query PT_SOQ_MUL_NEW joined with PM_CATEGORY to retrieve the most recent as-on date and the corresponding parts category description for the current session context (dealer, location, parent group, company). Only the first row (ROWNUM < 2) is retrieved.
- Step 2 - Populate the Last SOQ Date field on the criteria panel with the retrieved date.
- Step 3 - Populate the SOQ Category fields on the criteria panel and the PO Details panel with the retrieved category description.
- Step 4 - If no matching SOQ record is found, clear both the Last SOQ Date and the SOQ Category fields silently; no error is raised.
- Step 5 - If any unexpected error occurs, clear both fields silently.

---
**Decision Points**

DP-001

Condition: A SOQ record exists in PT_SOQ_MUL_NEW for the current dealer, location, parent group, and company context.

TRUE: The as-on date and category description are retrieved and displayed in the header fields.

FALSE: WHEN NO_DATA_FOUND - both fields are cleared silently; WHEN OTHERS - both fields are also cleared silently.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_MUL_NEW - Reads data from PT_SOQ_MUL_NEW for lookup or validation.
- DB-002 - Read PM_PART - Reads data from PM_PART for lookup or validation.
**Business Rules**

- BR-001 - Only one SOQ date and category are displayed at a time: the most recent SOQ record (ROWNUM < 2) is used, ignoring any older runs.
- BR-002 - If no prior SOQ exists for the current context, the Last SOQ Date and Category fields are left blank; the form does not treat this as an error.

---
**Implementation Logic**

```plsql
PROCEDURE get_last_soq_date
IS
lv_soq_catg  pm_category.catg_desc%type;
BEGIN
      SELECT pt.as_on_date,
             pm.catg_desc
        INTO :sb_title.nb_last_soq_date,
             lv_soq_catg
        FROM pt_soq_mul_new pt, pm_category pm
       WHERE pt.parent_group = :GLOBAL.parent_group
         AND pt.dealer_map_cd = :GLOBAL.dealer
         AND pt.loc_cd = :GLOBAL.loc_cd
         AND pt.comp_fa = :GLOBAL.comp_fa
         AND pm.catg_cd = (SELECT catg_cd
                             FROM pm_part
                            WHERE part_num = pt.part_num 
                            AND dealer_map_cd IN (:GLOBAL.principal, pt.dealer_map_cd)
                            AND principal_map_cd = :GLOBAL.PRINCIPAL --added by akanksha for multicompany change
                            ) 
         AND pm.principal_map_cd = :GLOBAL.principal
         AND ROWNUM < 2;
         
         :sb_title.NB_SOQ_CATG:=lv_soq_catg;
         :B_PARTY.NB_SOQ_CATG:=lv_soq_catg;
         
EXCEPTION
      WHEN NO_DATA_FOUND THEN
            :sb_title.nb_last_soq_date := NULL;
            lv_soq_catg:=null;
      WHEN OTHERS THEN
            :sb_title.nb_last_soq_date := NULL;
            lv_soq_catg:=null;
END;
```

#### SP-004 - LOC_CATEG_POPULATION

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: FT_SAVE]
- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_new_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Populates the category and location fields on the Suggested Order Quantity Processing screen (CN_MAIN) for the current SOQ context. The procedure retrieves the part category code from PM_PART for the active dealer/principal/location/parent-group/component-FA combination and marks the corresponding location records in the B_LOC block as checked, enabling the screen to display accurate category and location information for the SOQ parts held in PT_SOQ_MUL_NEW.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Count the number of rows in PT_SOQ_MUL_NEW that match the current global context (DEALER, LOC_CD, PARENT_GROUP, COMP_FA) to determine whether any SOQ multi-location records exist for processing.
- Step 2 - If at least one matching row exists, query PM_PART to retrieve the CATG_CD for the first matching part number found in PT_SOQ_MUL_NEW (ROWNUM < 2) for the same global context, filtered additionally by DEALER_MAP_CD (dealer or principal) and PRINCIPAL_MAP_CD, to support multi-company scenarios.
- Step 3 - Assign the retrieved category code to the screen item :SB_TITLE.PART_CATEG, making the part category visible on the form.
- Step 4 - If any exception occurs during the category retrieval (Step 2-3), suppress the error silently and continue processing.
- Step 5 - Open cursor LOC_CUR to select all distinct LOC_CD values from PT_SOQ_NEW where the record matches the current global context (DEALER, GEN_LOC = LOC_CD, PARENT_GROUP, COMP_FA).
- Step 6 - For each distinct location returned by LOC_CUR, navigate to block B_LOC and iterate through all records in the block.
- Step 7 - For each B_LOC record, compare :B_LOC.LOC_CD with the cursor location value; if they match, set :B_LOC.CHECK_YN to 'Y' to mark that location as selected on screen.
- Step 8 - If any exception occurs during the location marking loop (Steps 5-7), suppress the error silently and continue.
- Step 9 - If the initial count from Step 1 is zero, the procedure takes no action and exits.

---
**Decision Points**

DP-001

Condition: The count of rows in PT_SOQ_MUL_NEW matching the current global context (DEALER, LOC_CD, PARENT_GROUP, COMP_FA) is greater than zero.

TRUE: Proceed to retrieve the part category from PM_PART and populate :SB_TITLE.PART_CATEG, then iterate over PT_SOQ_NEW locations to mark matching B_LOC records.

FALSE: Skip all category and location population logic; the procedure exits without updating any screen fields.

DP-002

Condition: The :B_LOC.LOC_CD value of the current B_LOC record matches the LOC_CD value returned by LOC_CUR for the current iteration.

TRUE: Set :B_LOC.CHECK_YN to 'Y', marking that location as checked on the screen.

FALSE: Leave :B_LOC.CHECK_YN unchanged and continue to the next B_LOC record.

DP-003

Condition: :SYSTEM.LAST_RECORD = 'TRUE' during the B_LOC block iteration loop.

TRUE: Exit the inner loop, ending traversal of the B_LOC block for the current LOC_CUR row.

FALSE: Advance to the next B_LOC record via NEXT_RECORD and continue comparison.

---
**Database Interactions**

- DB-001 - Read PT_SOQ_MUL_NEW - Reads data from PT_SOQ_MUL_NEW for lookup or validation.
- DB-002 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-003 - Read PT_SOQ_MUL - Reads data from PT_SOQ_MUL for lookup or validation.
- DB-004 - Read PT_SOQ_NEW - Reads data from PT_SOQ_NEW for lookup or validation.
**Business Rules**

- BR-001 - Category population is only performed when at least one SOQ multi-location record exists in PT_SOQ_MUL_NEW for the combination of the current dealer, location, parent group, and component FA; no screen update occurs if no such records are found.
- BR-002 - The part category code assigned to :SB_TITLE.PART_CATEG is derived from the first available part number in PT_SOQ_MUL_NEW for the current context (ROWNUM < 2), ensuring a single deterministic value is used rather than requiring all parts to share the same category.
- BR-003 - Part category lookup against PM_PART must satisfy both the dealer/principal DEALER_MAP_CD filter and the PRINCIPAL_MAP_CD = :GLOBAL.PRINCIPAL filter, enforcing multi-company data isolation so that only parts belonging to the correct principal are considered.
- BR-004 - Location checking in block B_LOC is driven by distinct LOC_CD values from PT_SOQ_NEW where GEN_LOC matches the current :GLOBAL.LOC_CD, ensuring that only locations physically associated with the current general location are marked as selected.
- BR-005 - Any exception raised during category retrieval or location marking is silently suppressed (WHEN OTHERS THEN NULL), preventing the procedure from interrupting the calling trigger while still completing as much population as possible.

---
**Implementation Logic**

```plsql
PROCEDURE loc_categ_population IS
BEGIN
  --added on 04/06 to display the category of soq parts in screen  which is in pt_soq_mul
DECLARE
 lv_count NUMBER(5):=0;	
 lv_categ varchar2(30);
BEGIN
   SELECT COUNT(1) 
   INTO   lv_count
   FROM   pt_soq_mul_new
   WHERE  dealer_map_cd=:global.dealer
   AND    loc_cd      =:global.loc_cd
   AND    parent_group =:global.parent_group
   AND    comp_fa      =:global.comp_fa;
   IF     lv_count >0  THEN
   		BEGIN
   	      /* Following Query has been commented by Kaushal on 18.08.2006 for the performance Issue 
		   	  SELECT DISTINCT catg_cd 
		   	  INTO  lv_categ -- :sb_title.part_categ 
		   	  FROM   pm_part pm
		   	  WHERE  dealer_map_cd in(:global.dealer,:global.principal)
		   	  AND    part_num= ANY (SELECT PART_NUM
		   	  										 FROM  pt_soq_mul
		   	  										 WHERE  dealer_map_cd=:global.dealer
		   												 AND    loc_cd       =:global.loc_cd
		   												 AND    parent_group =:global.parent_group
		   												 AND    comp_fa      =:global.comp_fa);
		   		*/
		   	  SELECT catg_cd 
		   	  INTO  lv_categ -- :sb_title.part_categ 
		   	  FROM   pm_part pm
		   	  WHERE  dealer_map_cd in(:global.dealer,:global.principal)
		   	  AND    pm.principal_map_cd = :GLOBAL.PRINCIPAL  --added by akanksha for multicompany change
		   	  AND    part_num= (  SELECT PART_NUM
		   	  										  FROM pt_soq_mul_new
		   	  										 WHERE dealer_map_cd=:global.dealer
		   												   AND loc_cd       =:global.loc_cd
		   												   AND parent_group =:global.parent_group
		   												   AND comp_fa      =:global.comp_fa
		   												   AND rownum < 2);
		   	:sb_title.part_categ:=lv_categ;		   												 
   	  EXCEPTION
   	  	WHEN OTHERS THEN
   	--	 general.disp_text(sqlerrm,'Error');
   	  NULL;
   	  END;
  
  --added on 04/06 to display the location of soq parts in screen, which is in pt_soq 	  
   	  DECLARE
   	  	CURSOR LOC_CUR IS
   	  	SELECT DISTINCT loc_cd 
   	  	FROM   pt_soq_new
   	  	WHERE  dealer_map_cd=:global.dealer
   		  AND    gen_loc       =:global.loc_cd
        AND    parent_group =:global.parent_group
        AND    comp_fa      =:global.comp_fa;
   	  BEGIN
   	   	FOR  i IN loc_cur
   	  	LOOP
   	  		    
		   	  		GO_BLOCK('b_loc');
		    	  	FIRST_RECORD;
		          LOOP
		          	  IF :b_loc.loc_cd=i.loc_cd THEN
		          	  	 :b_loc.check_yn:='Y';
		          	  END IF;	
				          EXIT WHEN :system.last_record='TRUE';
				          NEXT_RECORD;
		          END LOOP;	
   	  	END LOOP;	--end of FOR  i IN loc_cur
   	  EXCEPTION
   	  	WHEN OTHERS THEN
   	  null;
   	  END;
   	END IF;	
EXCEPTION
	WHEN OTHERS THEN
	 NULL;
END; --end of catgory 	

END;
```

#### SP-005 - SORT_BLOCK

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-LIST-CHANGED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Re-sorts the SOQ results grid by applying the sort column and direction currently selected by the user in the criteria panel. Saves any pending changes before re-querying, then rebuilds the ORDER BY clause for the results block and re-executes the query so the grid displays in the newly chosen order.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Any pending form changes are saved (POST) before re-sorting to prevent data loss.
- Step 2 - Navigation moves to the SOQ results block.
- Step 3 - The default sort expression is set to Part Number.
- Step 4 - The selected Sort By value is evaluated and the corresponding sort expression is determined: Part Number sorts by PART_NUM; SOQ Quantity by SOQ_QTY; Amended Quantity by AMD_SOQ_QTY; Purchase Price by the purchase-price function applied to the part; Total Value by the product of the price function and the amended quantity.
- Step 5 - The ORDER BY clause for the SOQ results block is updated to combine the resolved sort expression with the chosen sort direction (ascending or descending).
- Step 6 - The results block is cleared and the query is re-executed without validation so the grid refreshes in the new sort order.

---
**Decision Points**

DP-001

Condition: The selected Sort By value is 'PART_NUM'.

TRUE: Sort expression is set to PART_NUM.

FALSE: Evaluate the next condition.

DP-002

Condition: The selected Sort By value is 'SOQ_QTY'.

TRUE: Sort expression is set to SOQ_QTY.

FALSE: Evaluate the next condition.

DP-003

Condition: The selected Sort By value is 'AMD_SOQ_QTY'.

TRUE: Sort expression is set to AMD_SOQ_QTY.

FALSE: Evaluate the next condition.

DP-004

Condition: The selected Sort By value is 'PURCHASE_PRICE'.

TRUE: Sort expression is set to the purchase-price function evaluated per part (sf_get_price with the 'P' price-type indicator).

FALSE: Evaluate the next condition.

DP-005

Condition: The selected Sort By value is 'VALUE'.

TRUE: Sort expression is set to the product of the purchase-price function and the amended SOQ quantity.

FALSE: No match - sort expression remains at the default Part Number.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Pending user changes to the SOQ grid are saved before sorting to prevent loss of amendments.
- BR-002 - The SOQ results grid can be sorted by Part Number, SOQ Quantity, Amended Quantity, Purchase Price, or Total Value; any other selection defaults to Part Number ordering.
- BR-003 - The sort direction (ascending or descending) is applied uniformly across all sort columns.

---
**Implementation Logic**

```plsql
Procedure sort_block
IS
      lv_order_by   VARCHAR2 (2000);
BEGIN
      POST;
      GO_BLOCK ('b_soq');
      lv_order_by := 'PART_NUM';

      IF :sb_title.nb_sort_by = 'PART_NUM' THEN
            lv_order_by := 'PART_NUM';
      ELSIF :sb_title.nb_sort_by = 'SOQ_QTY' THEN
            lv_order_by := 'SOQ_QTY';
      ELSIF :sb_title.nb_sort_by = 'AMD_SOQ_QTY' THEN
            lv_order_by := 'AMD_SOQ_QTY';
      ELSIF :sb_title.nb_sort_by = 'PURCHASE_PRICE' THEN
            lv_order_by := 'sf_get_price(parent_group,dealer_map_cd,loc_cd,:GLOBAL.PRINCIPAL,''P'',part_num)'; --:GLOBAL.PRINCIPAL added by akanksha for multicompany change
            NULL;
      ELSIF :sb_title.nb_sort_by = 'VALUE' THEN
            lv_order_by := 'nvl(sf_get_price(parent_group,dealer_map_cd,loc_cd,:GLOBAL.PRINCIPAL,''P'',part_num),0) * nvl(AMD_SOQ_QTY,0)'; --:GLOBAL.PRINCIPAL added by akanksha for multicompany change
      END IF;

      GO_BLOCK ('b_soq');
      SET_BLOCK_PROPERTY ('b_soq', order_by, lv_order_by || ' ' || :sb_title.nb_sort_type);
      CLEAR_BLOCK;
      EXECUTE_QUERY (no_validate);
      
END;
```

#### SP-006 - UPDATE_PO_STOCK

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

UPDATE_PO_STOCK iterates over all part lines in the B_SOQ block and submits their part numbers and amended order quantities to PK_VALIDATE_PARTS.UPDATE_ON_ORDER, which updates the on-order stock position for the relevant dealer, location, and parent group. If the package call returns an error, the procedure surfaces the error message to the user via the CN_ERR view and halts further form processing.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- PK_VALIDATE_PARTS.UPDATE_ON_ORDER ([SP-027](#SP-027--PK_VALIDATE_PARTS.UPDATE_ON_ORDER)) - PK_VALIDATE_PARTS.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Navigate to the B_SOQ block and position the cursor on the first record.
- Step 2 - Iterate through every record in B_SOQ; for each record, populate an entry in the PL/SQL index-by table TI_PART_ORD_QTY with the part number (:B_SOQ.PART_NUM) and the amended SOQ quantity (:B_SOQ.AMD_SOQ_QTY). The reserve quantity (R_QTY) is explicitly set to NULL. Increment the row counter and continue until the last record is reached.
- Step 3 - Call PK_VALIDATE_PARTS.UPDATE_ON_ORDER, passing the assembled part/quantity collection together with the global context values: parent group, dealer, location code, PO status, and user name. The call returns an error code and an error message.
- Step 4 - Evaluate the returned error code. If it is non-zero, navigate to the CB_ERR block, clear it, write the error message into :CB_ERR.TXT_ERR, display the CN_ERR view to the user, and raise FORM_TRIGGER_FAILURE to stop form processing.
- Step 5 - If the error code is zero, the procedure completes silently, indicating that the on-order stock update was accepted successfully.

---
**Decision Points**

DP-001

Condition: The error code (LV_ERR_CD) returned by PK_VALIDATE_PARTS.UPDATE_ON_ORDER is not equal to zero.

TRUE: Navigate to the CB_ERR block, clear its contents, write the error message (LV_ERR_MSG) into :CB_ERR.TXT_ERR, display the CN_ERR error view, and raise FORM_TRIGGER_FAILURE to abort further processing.

FALSE: No error handling is triggered; the procedure ends normally and the on-order stock update is considered successful.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Every part line present in the B_SOQ block at the time of invocation must be included in the on-order stock update; no lines are selectively skipped during the loop iteration.
- BR-002 - Only the amended SOQ quantity (:B_SOQ.AMD_SOQ_QTY) is submitted as the order quantity for each part; the reserve quantity is always passed as NULL.
- BR-003 - The on-order stock update is executed within the context of a specific parent group, dealer, location code, PO status, and user name, all of which must be present as global or block values before the procedure is called.
- BR-004 - A non-zero error code returned by PK_VALIDATE_PARTS.UPDATE_ON_ORDER is treated as a hard failure: the error message is displayed to the user and the triggering form action is halted via FORM_TRIGGER_FAILURE; partial updates are not silently accepted.
- BR-005 - Error feedback is presented through the dedicated CN_ERR view, ensuring that stock update errors are surfaced through the standard form error-display mechanism rather than suppressed.

---
**Implementation Logic**

```plsql
PROCEDURE update_po_stock
IS
      ti_part_ord_qty   pk_validate_parts.part_order_type;
      to_error          pk_validate_parts.err_tab;
      l_cnt             PLS_INTEGER                       := 1;
      lv_error_cd       NUMBER;
      lv_err_msg        VARCHAR2 (1000);
      lv_err_cd         NUMBER;
BEGIN
      GO_BLOCK ('B_SOQ');
      FIRST_RECORD;

      LOOP
            ti_part_ord_qty (l_cnt).p_part := :b_soq.part_num;
            ti_part_ord_qty (l_cnt).p_qty := :b_soq.amd_soq_qty;
            ti_part_ord_qty (l_cnt).r_qty := null;
            l_cnt := l_cnt + 1;
            EXIT WHEN :SYSTEM.LAST_RECORD = 'TRUE';
            NEXT_RECORD;
      END LOOP;

      pk_validate_parts.update_on_order (:GLOBAL.parent_group,
                                         :GLOBAL.dealer,
                                         :GLOBAL.loc_cd,
                                         ti_part_ord_qty,
                                         :b_party.po_status,
                                         :GLOBAL.user_name,
                                         lv_err_cd,
                                         lv_err_msg);
      IF lv_err_cd <> 0 THEN
            BEGIN
                  GO_BLOCK ('CB_ERR');
                  CLEAR_BLOCK (no_validate);
                  FIRST_RECORD;
                  /*
                          for i in 1..to_error.last
                          loop
                                  :cb_err.txt_err := to_error(i);
                                  next_record;
                          end loop;
                          */
                  :cb_err.txt_err := lv_err_msg;
            END;

            SHOW_VIEW ('CN_ERR');
            RAISE form_trigger_failure;
      END IF;
END;
```

#### SP-007 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a given path before loading. The procedure normalises the target path, confirms the DLL file is accessible, loads the library, and-when instructed-increments the global DLL load counter and enables the API flag. It is invoked by REGISTER_FUNCTION_CALL to establish the FFI library handle required for external function registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-099](#SP-099--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath has been supplied. If it is NULL, skip path normalisation and file-existence checks and proceed directly to the library load attempt.
- Step 2 - If TargetPath is not NULL, pass it to STRIPDIRSEP to remove any trailing directory separator, then append a single backslash ('\') to produce a consistently formatted directory path. This guards against callers who may supply multiple concatenated paths; only the value returned by STRIPDIRSEP is retained.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R'). If the file opens successfully, close it immediately with TEXT_IO.FCLOSE; this confirms the DLL is physically present at the specified location.
- Step 4 - If the file-open attempt raises any exception, call DEBUGLOG (Win_API_Debug.DebugLog) at severity level 99, identifying the routine as 'Attempt_DLL_LOAD' and logging a message stating the DLL was not found at the specified location. Then raise the BadLocation exception to abort processing.
- Step 5 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL and obtain a library handle (hDLL).
- Step 6 - If the LoadCount parameter is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE.
- Step 7 - Return the ORA_FFI library handle (hDLL) to the caller.
- Step 8 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the NULL library handle to the caller, allowing the caller to detect the failure without raising an unhandled error.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise the path via STRIPDIRSEP, append a backslash, and perform a file-existence check before attempting the library load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the NULL path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the concatenated TargetPath || TargetDLL file reference.

TRUE: Close the file handle and continue to the ORA_FFI library load step.

FALSE: Log a severity-99 debug message via DEBUGLOG identifying the missing DLL and its expected location, then raise the BadLocation exception to halt processing.

---

DP-003

Condition: LoadCount parameter is TRUE after a successful ORA_FFI.LOAD_LIBRARY call.

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Leave DLL_LOAD_COUNT and API_ENABLED unchanged.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI.LOAD_LIBRARY call or surrounding logic.

TRUE: Set API_ENABLED to FALSE and return the NULL library handle to the caller.

FALSE: Return the successfully populated library handle to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must be normalised to a single directory path with exactly one trailing backslash before any file-existence check or library load is attempted; any extraneous path segments beyond what STRIPDIRSEP returns are discarded.
- BR-002 - When TargetPath is provided, the DLL file must be physically accessible at the resolved path before ORA_FFI.LOAD_LIBRARY is called; failure to open the file is treated as a hard error (BadLocation) rather than a recoverable condition.
- BR-003 - A failed file-existence check must be recorded via DEBUGLOG at severity level 99, capturing the DLL name and the full resolved path, to support operational diagnostics.
- BR-004 - The global DLL load counter (DLL_LOAD_COUNT) and the API availability flag (API_ENABLED) must only be updated upon a successful library load and only when the caller explicitly requests counting via LoadCount = TRUE.
- BR-005 - If the library load fails for any reason, API_ENABLED must be set to FALSE and a NULL handle returned; the procedure must not propagate an unhandled exception to the caller, ensuring REGISTER_FUNCTION_CALL can assess the failure gracefully.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-008 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (Open or Save) to the end user and returns the selected file path(s) in the in-out buffer. The procedure resolves environment-token initial directories, registers the underlying D2KWUtil DLL entry point, enforces modal or modeless display, and surfaces any API-level or unexpected errors through the standard error stack before returning a result code to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-011](#SP-011--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-018](#SP-018--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-086](#SP-086--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-087](#SP-087--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all incoming arguments (CalledBy, Modal flag, dialog title, initial directory, file filter, flags, separator character, and current buffer value) via DEBUGLOG for diagnostic traceability.
- Step 2 - Clear any residual errors from the error stack by calling CLEAN_ERROR_STACK, then initialise the return code (iRC) to 0.
- Step 3 - Determine the owner window handle: if Modal is TRUE, retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW; otherwise set the handle to 0 (modeless).
- Step 4 - Check whether the Windows API layer is enabled (WIN_API.API_ENABLED). If it is not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the DLL function entry point 'd2kwutil_ChooseFile' with its parameter signature via REGISTER_FUNCTION_CALL, binding it to the internal handle iChooseFile.
- Step 6 - Derive the operation mode integer (iBuff1): set to 1 if CalledBy equals 'Open_File', or 2 for any other caller value (Save mode).
- Step 7 - Resolve the initial directory token: if szInitDir is '$WINDIR$' (case-insensitive), retrieve the Windows directory via GET_WINDOWS_DIRECTORY; if it is '$TEMP$', retrieve the temporary directory via GET_TEMP_DIRECTORY; otherwise use szInitDir as supplied.
- Step 8 - Ensure the resolved initial directory ends with a backslash ('\'); append one if the final character is not already a backslash.
- Step 9 - Determine the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 10 - Pad the input/output buffer (szBuffer) to exactly 4,096 characters with null characters (CHR(0)) to provide the required fixed-length buffer for the DLL call.
- Step 11 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE with the resolved handle, operation mode, owner window handle, title, initial directory, file filter, flags, separator character, and padded buffer; capture the integer return code.
- Step 12 - Log the result code and the returned buffer value via DEBUGLOG.
- Step 13 - Write the returned buffer value back into the in-out parameter szBuffer and return the integer result code to the caller.
- Step 14 - On WIN_API.NOT_AVAILABLE exception, record the error via ADD_ERROR using the WIN_API.NoAPI message and re-raise.
- Step 15 - On any other exception, record the error via ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition: Modal parameter is TRUE.

TRUE: Retrieve the current active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it as the owner window (hwndOwner), making the dialog modal to that window.

FALSE: Set hwndOwner to 0, causing the file-chooser dialog to display without a modal owner (modeless).

---

DP-002

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed with registering the DLL function and invoking the file-chooser dialog.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all dialog logic.

---

DP-003

Condition: CalledBy equals the literal string 'Open_File'.

TRUE: Set the operation mode integer (iBuff1) to 1, indicating an Open File dialog.

FALSE: Set iBuff1 to 2, indicating a Save File dialog.

---

DP-004

Condition: Upper-cased szInitDir equals '$WINDIR$'.

TRUE: Resolve the initial directory by calling GET_WINDOWS_DIRECTORY.

FALSE: Evaluate the next condition (DP-005).

---

DP-005

Condition: Upper-cased szInitDir equals '$TEMP$' (evaluated only when DP-004 is FALSE).

TRUE: Resolve the initial directory by calling GET_TEMP_DIRECTORY.

FALSE: Use szInitDir as supplied without substitution.

---

DP-006

Condition: The last character of the resolved initial directory is not a backslash ('\').

TRUE: Append a backslash to the resolved directory path.

FALSE: Leave the directory path unchanged.

---

DP-007

Condition: szFileFilter is NULL or an empty string.

TRUE: Default the file filter to 'All files(*.*)|*.*|'.

FALSE: Use the caller-supplied szFileFilter value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-chooser dialog can only be presented when the Windows API layer is available (WIN_API.API_ENABLED is TRUE); if the API is unavailable the procedure raises WIN_API.NOT_AVAILABLE and records the error via ADD_ERROR before propagating the exception.
- BR-002 - A modal dialog must be anchored to the currently active window, obtained via D2KWUTIL.GET_ACTIVE_WINDOW; a non-modal dialog uses a null owner handle (0).
- BR-003 - The caller identity string 'Open_File' exclusively maps to Open File mode (iBuff1 = 1); any other CalledBy value maps to Save File mode (iBuff1 = 2).
- BR-004 - The special token '$WINDIR$' in the initial directory parameter is always resolved at runtime to the Windows system directory; '$TEMP$' is resolved to the system temporary directory; all other values are passed through unchanged.
- BR-005 - The resolved initial directory path must always terminate with a backslash; one is appended automatically if absent.
- BR-006 - If no file filter is provided (NULL or empty string), the dialog must default to displaying all files using the filter 'All files(*.*)|*.*|'.
- BR-007 - The file path buffer passed to the DLL must be exactly 4,096 characters, padded with null characters (CHR(0)); the procedure enforces this padding before invoking D2KWUTIL.D2KWUTIL_CHOOSEFILE and writes the DLL-populated buffer back to szBuffer on return.
- BR-008 - All exceptions other than WIN_API.NOT_AVAILABLE are captured, recorded via ADD_ERROR combined with ADD_EXTERNAL_ERRORS, and re-raised to ensure the caller's error-handling chain is fully informed.
- BR-009 - Entry and exit points of the procedure are logged via DEBUGLOG at debug level 99, capturing all input arguments on entry and the result code with returned buffer on exit.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-009 - D2KWUTIL.CREATED_DATE

**Invoked From:**

- SP_CALCULATE_SOQ_NEW.prc [StoredProcedure: SP_CALCULATE_SOQ_NEW]
- SP_INSERT_PM_PART_VAR.prc [StoredProcedure: SP_INSERT_PM_PART_VAR]
- SP_UPDATE_PO_NUMBER_NEW.prc [StoredProcedure: SP_UPDATE_PO_NUMBER_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the creation date and time (including milliseconds) of a specified file by delegating to D2KWUTIL.FILE_INFO. The procedure converts the raw numeric buffer values returned by FILE_INFO into a structured DATE value and a separate millisecond component, providing callers with a precise file creation timestamp for use in business processing such as SOQ calculation, PM part variance insertion, and PO number updates.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ReturnDate | DATE | OUT |
| ReturnMS | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.FILE_INFO ([SP-017](#SP-017--D2KWUTIL.FILE_INFO)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file path (FileName) and an optional exception-handling flag (RaiseExceptions) as input parameters.
- Step 2 - Invoke D2KWUTIL.FILE_INFO, passing the operation identifier 'Created_Date', the FileName, positional indicators 1 and 1, and the RaiseExceptions flag to populate the shared internal numeric buffers (iBuff3 through iBuff9) with the file's creation date/time components.
- Step 3 - Construct the ReturnDate output value by formatting buffers iBuff3 (year), iBuff4 (month), iBuff5 (day), iBuff6 (hour), iBuff7 (minute), and iBuff8 (second) into a concatenated string and converting it to a DATE using the mask 'YYYYMMDDHH24MISS'.
- Step 4 - Assign the value of iBuff9 to the ReturnMS output parameter to expose the millisecond portion of the creation timestamp.
- Step 5 - Return control to the caller with ReturnDate and ReturnMS populated.

---
**Decision Points**

DP-001

Condition: RaiseExceptions is TRUE or FALSE when passed to D2KWUTIL.FILE_INFO.

TRUE: D2KWUTIL.FILE_INFO raises exceptions encountered during file inspection back to the caller, allowing upstream procedures (SP_CALCULATE_SOQ_NEW, SP_INSERT_PM_PART_VAR, SP_UPDATE_PO_NUMBER_NEW) to handle errors explicitly.

FALSE: D2KWUTIL.FILE_INFO suppresses exceptions; the procedure completes silently and ReturnDate/ReturnMS may remain NULL or hold default values if the file cannot be inspected.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file creation timestamp must be derived exclusively through D2KWUTIL.FILE_INFO; no direct database or file-system query is performed within this procedure.
- BR-002 - The creation date is assembled from six discrete numeric buffer fields (year, month, day, hour, minute, second) and must conform to the 'YYYYMMDDHH24MISS' format mask to produce a valid DATE value.
- BR-003 - Milliseconds are captured as a separate numeric output (ReturnMS) and are not incorporated into the DATE value, preserving sub-second precision for callers that require it.
- BR-004 - Exception propagation is caller-controlled via the RaiseExceptions parameter, defaulting to FALSE so that file inspection failures are suppressed unless the invoking procedure explicitly requests error escalation.

---
**Implementation Logic**

```plsql

PROCEDURE Created_Date (  FileName        IN   VARCHAR2,
                          ReturnDate      OUT  DATE,
                          ReturnMS        OUT  NUMBER,
                          RaiseExceptions IN   BOOLEAN DEFAULT FALSE) is
begin 
  File_Info('Created_Date',Filename,1,1,RaiseExceptions);
  ReturnDate := to_date(to_char(iBuff3,'0999')||to_char(iBuff4,'09')||to_char(iBuff5,'09')||to_char(iBuff6,'09')||to_char(iBuff7,'09')||to_char(iBuff8,'09'),'YYYYMMDDHH24MISS');
  ReturnMS   := iBuff9;
end Created_Date;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers and exposes a foreign function interface (FFI) handle that retrieves the currently active window identifier within the Oracle Forms runtime environment. This function serves as a low-level FFI wrapper, accepting a pre-resolved function handle and returning a PLS_INTEGER representing the active window, enabling the parent routine D2KWUTIL.GET_ACTIVE_WINDOW to delegate the native call through the ORA_FFI mechanism.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) passed in by the calling routine D2KWUTIL.GET_ACTIVE_WINDOW, which has already resolved the external library entry point.
- Step 2 - Invoke the foreign function referenced by hFunc via the ORA_FFI framework to obtain the active window identifier from the underlying runtime.
- Step 3 - Return the resulting PLS_INTEGER value, representing the active window handle, to the caller.

---
**Decision Points**

No conditional decision points are present in the available implementation. The function signature indicates a direct FFI invocation with a single input and a single return value; no branching logic is evidenced in the source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts exactly one input parameter (hFunc of type ORA_FFI.funcHandleType); the caller is responsible for supplying a valid, pre-resolved FFI function handle before invoking this routine.
- BR-002 - The return value is of type PLS_INTEGER and represents the active window identifier; no output parameters are used.
- BR-003 - This function contains no direct database interactions; all processing is performed through the ORA_FFI foreign function call mechanism.
- BR-004 - This function is intended to be called exclusively from D2KWUTIL.GET_ACTIVE_WINDOW and should not be invoked directly from other contexts outside that parent routine.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a wrapper interface to an external Windows file-chooser dialog via the Oracle FFI (Foreign Function Interface) mechanism. When invoked, the function delegates to a native OS-level file-selection dialog, allowing the calling Oracle Forms session to present the user with a standard Open or Save file-browser window and capture the selected file path(s) back into the application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered FFI function handle (hFunc) that references the underlying native file-dialog library entry point.
- Step 2 - Accept the dialog configuration inputs: dialog type (Open or Save), owner window handle (hwndOwner), dialog title (szTitle), initial directory (szInitDir), file-type filter string (szFileFilter), advanced behaviour flags (AdvancedFlags), and the separator character (SepChar) used when multiple file selections are returned.
- Step 3 - Pass all parameters through the ORA_FFI function handle to invoke the native Windows file-chooser dialog.
- Step 4 - Receive the user's selection back into the IN OUT parameters: szBuffer is populated with the selected file path(s), and szTitle, szInitDir, and szFileFilter may be updated to reflect the state at dialog close.
- Step 5 - Return a PLS_INTEGER result code to the caller indicating the outcome of the dialog invocation (e.g. user confirmed a selection or cancelled).

---
**Decision Points**

DP-001

Condition: The user either confirms a file selection or cancels/closes the native file-chooser dialog.

TRUE (selection confirmed): The selected file path(s) are written into szBuffer and the function returns a non-zero PLS_INTEGER success code to the caller.

FALSE (dialog cancelled or closed without selection): szBuffer is not populated with a valid path and the function returns a PLS_INTEGER code indicating cancellation or failure, allowing the caller to handle the no-selection scenario.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid, pre-registered ORA_FFI function handle (hFunc); the handle must reference the native file-dialog entry point before this function is called.
- BR-002 - The dialog_type parameter governs whether an Open-file or Save-file dialog is presented; the calling routine is responsible for supplying the correct integer value.
- BR-003 - The szFileFilter parameter must conform to the filter string format expected by the native Windows dialog (paired description and pattern tokens); malformed filter strings are the responsibility of the caller.
- BR-004 - When multiple file selections are permitted, the SepChar parameter defines the delimiter used to separate individual file paths within szBuffer; the caller must parse szBuffer using the same character.
- BR-005 - The IN OUT parameters (szTitle, szInitDir, szFileFilter, szBuffer) must be declared with sufficient length by the caller to accommodate values written back by the native dialog; truncation behaviour is governed by the ORA_FFI layer.
- BR-006 - No database reads or writes are performed; this function is exclusively a UI-integration utility and carries no transactional responsibility.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-012 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge to the native C routine identified by pragma interface code 11265 within the D2KWUTIL library. When invoked by WINDEBUG, it passes a debug text string to the underlying C function referenced by the supplied function handle, enabling debug output to be written outside the standard PL/SQL output mechanism.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target native C debug-string routine and the text string (Text) to be output.
- Step 2 - Delegate execution directly to the C-level implementation via the ORA_FFI pragma interface (code 11265), passing both hFunc and Text as arguments.
- Step 3 - Return control to the caller (WINDEBUG) upon completion of the native call; no return value or output parameter is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a foreign-function interface declaration with a PRAGMA INTERFACE directive; all branching logic, if any, resides within the native C routine invoked at runtime.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI function handle (hFunc) that has been registered against the D2KWUTIL native library; supplying an invalid handle will result in a runtime FFI error.
- BR-002 - The Text parameter carries the debug string to be output; it is passed as-is to the native C routine without transformation or truncation by this procedure.
- BR-003 - This procedure has no database interactions and produces no formal output parameters; its sole effect is the side-effect performed by the native C implementation.
- BR-004 - Invocation is restricted to the WINDEBUG stored procedure within D2kwutil.pld; direct calls from other contexts are not supported by the documented integration design.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-013 - D2KWUTIL.D2KWUTIL_FILEINFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_FILEINFO is a low-level foreign-function interface (FFI) wrapper function within the D2KWUTIL package. It delegates execution to an external native library routine via the supplied ORA_FFI function handle (hFunc) to retrieve file-level metadata for a specified file. The function accepts a file name and two option flags that control the type of information requested, populates up to seven integer output slots with the resulting file attribute values, and returns a PLS_INTEGER status code to the caller (D2KWUTIL.FILE_INFO).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| FileName | VARCHAR2 | IN OUT |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FileName | VARCHAR2 | IN OUT |
| dwOut1 | PLS_INTEGER | IN OUT |
| dwOut2 | PLS_INTEGER | IN OUT |
| dwOut3 | PLS_INTEGER | IN OUT |
| dwOut4 | PLS_INTEGER | IN OUT |
| dwOut5 | PLS_INTEGER | IN OUT |
| dwOut6 | PLS_INTEGER | IN OUT |
| dwOut7 | PLS_INTEGER | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the pre-registered external library entry point responsible for file inspection.
- Step 2 - Accept the target file path/name via the IN OUT parameter FileName, allowing the external routine to normalise or resolve the path and return the canonical form if required.
- Step 3 - Accept Option1 and Option2 integer flags that direct the external routine as to which categories of file information are to be retrieved.
- Step 4 - Invoke the external native function through the ORA_FFI mechanism using hFunc, passing FileName, Option1, Option2, and the seven IN OUT output slots (dwOut1-dwOut7).
- Step 5 - Receive the file attribute results populated by the external routine into dwOut1 through dwOut7 (e.g. file size components, date/time components, or attribute flags, depending on the option flags supplied).
- Step 6 - Return the PLS_INTEGER status code produced by the external function to the calling routine (D2KWUTIL.FILE_INFO), indicating success or a platform-level error condition.

---
**Decision Points**

No explicit decision points are determinable from the available source. The function specification contains no conditional branching; all control-flow and conditional logic reside within the external native library invoked via the ORA_FFI handle. The calling procedure D2KWUTIL.FILE_INFO is responsible for interpreting the returned status code and output values.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid, pre-registered ORA_FFI function handle (hFunc); the handle is the sole mechanism by which the external native file-info routine is located and called.
- BR-002 - FileName is an IN OUT parameter; the external routine may modify the value (e.g. path normalisation), and the resolved form must be preserved and returned to the caller.
- BR-003 - Option1 and Option2 are strictly IN parameters; they govern the category of file attributes retrieved and must not be altered by the function.
- BR-004 - All seven output slots (dwOut1-dwOut7) are IN OUT parameters; any values populated by the external routine must be passed back intact to the caller (D2KWUTIL.FILE_INFO) for further interpretation.
- BR-005 - The function returns a PLS_INTEGER status code; the caller is responsible for evaluating this code to determine whether the file information retrieval succeeded or encountered a platform-level error.
- BR-006 - No database interactions are performed; this function operates exclusively through the ORA_FFI external-library mechanism and carries no transactional side-effects.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
                                                                                                                                                         
FUNCTION d2kwutil_FileInfo ( hFunc      IN      ORA_FFI.funcHandleType,
                             FileName   IN OUT  VARCHAR2,
                             Option1    IN      PLS_INTEGER,
                             Option2    IN      PLS_INTEGER,
                             dwOut1     IN OUT  PLS_INTEGER,
                             dwOut2     IN OUT  PLS_INTEGER,
                             dwOut3     IN OUT  PLS_INTEGER,
                             dwOut4     IN OUT  PLS_INTEGER,
                             dwOut5     IN OUT  PLS_INTEGER,
                             dwOut6     IN OUT  PLS_INTEGER,
                             dwOut7     IN OUT  PLS_INTEGER
                           ) return PLS_INTEGER;
```

#### SP-014 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. Given a function handle and a source environment variable name, the routine delegates the call to the underlying OS layer via ORA_FFI and returns the expanded (resolved) environment variable string along with an integer status code indicating the outcome of the retrieval.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the pre-registered external OS function responsible for environment variable expansion.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the external function.
- Step 3 - Accept the output buffer (ExpandStr) as an IN OUT parameter that will be populated with the resolved/expanded value of the environment variable.
- Step 4 - Accept the input buffer length (InBuffLen) to define the maximum allowable size of the expanded result string.
- Step 5 - Invoke the external OS function via the supplied ORA_FFI function handle, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld) indicating success or failure of the environment variable retrieval.

---
**Decision Points**

No explicit decision points are determinable from the available specification. The function signature indicates a single execution path: invoke the external FFI function and return the integer result. No conditional branching is evidenced in the implementation logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must be pre-registered by the caller before this function is called, as no handle initialisation occurs within this routine.
- BR-002 - The InBuffLen parameter must accurately reflect the allocated size of the ExpandStr buffer to prevent buffer overrun when the OS writes the expanded environment variable value.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the caller must supply initialised variables; the resolved environment variable value is returned through ExpandStr rather than as a direct function return value.
- BR-004 - The integer return value must be evaluated by the caller (GET_ENVIRONMENT_STRING) to determine whether the environment variable was successfully retrieved; this routine does not raise exceptions internally based on the available specification.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-015 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry data and returns an integer status code indicating success or failure of the registry read operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld to support registry-based configuration lookups from Oracle Forms.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows registry API, along with the registry root identifier (RegRoot), registry path (RegPath), and entry name (RegEntry).
- Step 2 - Accept the maximum allowable length for the registry value string (RegValueLength) and a flag (RegDontExpand) indicating whether environment-variable expansion within the registry value should be suppressed.
- Step 3 - Invoke the native Windows registry read operation via the ORA_FFI function handle, passing all supplied parameters to retrieve the value stored at the specified registry root, path, and entry.
- Step 4 - Populate the IN OUT parameter RegValue with the registry data returned by the native call, up to the limit defined by RegValueLength.
- Step 5 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) reflecting the outcome of the registry read attempt.

---
**Decision Points**

No decision points can be determined from the available source. Only the function specification is present; no PL/SQL body or conditional logic is exposed in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid ORA_FFI function handle (hFunc); the handle is the mechanism by which Oracle Forms delegates the registry read to the native Windows API layer.
- BR-002 - RegRoot must be supplied as a valid Windows registry root constant (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) expressed as a PLS_INTEGER; the correct root is the caller's responsibility.
- BR-003 - RegValueLength must accurately reflect the maximum buffer size allocated for RegValue to prevent truncation of the retrieved registry data.
- BR-004 - The RegDontExpand flag controls whether REG_EXPAND_SZ environment-variable references within the registry value are expanded before being returned; callers must set this flag deliberately based on whether raw or expanded values are required.
- BR-005 - RegPath and RegEntry are declared IN OUT; callers must supply populated values on entry and should treat their state on exit as defined by the underlying FFI call behaviour.
- BR-006 - The integer return value must be evaluated by the calling routine (READ_REGISTRY) to determine whether the registry read succeeded or failed; no exception is raised internally by this specification alone.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-016 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level FFI (Foreign Function Interface) wrapper function that retrieves a Windows directory path (either the Windows system directory or a temporary directory) by invoking an external native function handle. The result is written back to the caller-supplied buffer parameter, and the function returns an integer status code indicating the outcome of the native call. It is consumed exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the native function handle (hFunc) that identifies which Windows API entry point to invoke (e.g., GetWindowsDirectory or GetTempPath).
- Step 2 - Accept the pre-allocated output buffer (WindowsDir) passed IN OUT, which will hold the directory path string returned by the native call.
- Step 3 - Accept the buffer length value (InBuffLen) that communicates the maximum number of characters the native function may write into WindowsDir.
- Step 4 - Delegate execution to the external native function referenced by hFunc, passing WindowsDir and InBuffLen as arguments per the ORA_FFI calling convention.
- Step 5 - Receive the integer return value from the native function, which typically represents the number of characters written or an error/status code.
- Step 6 - Return the PLS_INTEGER result to the calling procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY), which uses it to determine success or failure and to read the populated WindowsDir value.

---
**Decision Points**

No conditional decision points are present in the available implementation. The function acts as a direct FFI pass-through; all branching logic based on the returned status code is handled by the invoking procedures (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must have been registered and loaded by the caller before this function is called.
- BR-002 - The WindowsDir buffer must be pre-allocated by the caller to a size of at least InBuffLen characters to prevent truncation of the directory path written by the native function.
- BR-003 - InBuffLen must accurately reflect the allocated capacity of the WindowsDir buffer; passing a value larger than the actual buffer size may cause undefined behaviour in the native layer.
- BR-004 - The integer return value is passed back to the caller as-is and must be interpreted by the invoking procedure (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY); this function does not raise exceptions or perform its own status validation.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-017 - D2KWUTIL.FILE_INFO

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CREATED_DATE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves file system metadata for a specified file by invoking the external Windows API function D2KWUTIL.D2KWUTIL_FILEINFO. The procedure populates a set of package-level integer buffers with file attribute data, logs diagnostic information at entry and exit, and enforces consistent error handling - optionally raising an exception to the caller when the file does not exist, the API is unavailable, or any other system-level failure occurs.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| FileName | VARCHAR2 | IN |
| Option1 | PLS_INTEGER | IN |
| Option2 | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_FILEINFO ([SP-013](#SP-013--D2KWUTIL.D2KWUTIL_FILEINFO)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG (Win_API_Debug.DebugLog) at verbosity level 99, recording the CalledBy context, FileName, Option1, Option2, and the string representation of RaiseExceptions produced by BOOLTOCHAR.
- Step 2 - Clear any previously accumulated error state by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack).
- Step 3 - Initialise the return code (iRC) and all nine package-level integer output buffers (iBuff1-iBuff9) to zero, ensuring no stale values are carried forward.
- Step 4 - Check whether the Windows API layer is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function signature with REGISTER_FUNCTION_CALL (win_api.Register_function_call), binding the handle iFileInfo to the entry point 'd2kwutil_FileInfo' with its typed parameter list.
- Step 6 - Prepare the file name buffer by right-padding FileName to 512 characters with a null terminator (CHR(0)), and assign Option1 and Option2 to iBuff1 and iBuff2 respectively.
- Step 7 - Invoke the external function D2KWUTIL.D2KWUTIL_FILEINFO via the registered function handle, passing the padded file name, the two option buffers, and the seven remaining output buffers (iBuff3-iBuff9); capture the integer return code in iRC.
- Step 8 - Log exit diagnostics by calling DEBUGLOG again at verbosity level 99, recording iRC and the values of all nine output buffers.
- Step 9 - Evaluate iRC: if it equals 0, -1074255551, or -1074245406, record a 'file does not exist' error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 10 - If iRC is any other value except 1 (success), record a system error message including the numeric return code via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging the no-API message via ADD_ERROR then re-raising; handle all other exceptions by composing an error message from the unexpected-error prefix and ADD_EXTERNAL_ERRORS output via ADD_ERROR, then re-raising.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function, prepare the file name buffer, and invoke D2KWUTIL.D2KWUTIL_FILEINFO.

FALSE: Raise WIN_API.NOT_AVAILABLE, bypassing all file-info retrieval logic.

---

DP-002

Condition: iRC is one of the known 'file not found' codes (0, -1074255551, or -1074245406).

TRUE: Record a 'File <FileName> does not exist' error via ADD_ERROR, then evaluate RaiseExceptions (see DP-003).

FALSE: Proceed to DP-004 to check for other non-success codes.

---

DP-003

Condition: RaiseExceptions is TRUE (evaluated after a file-not-found or system-error condition is detected).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return silently after recording the error; allow the caller to inspect the error stack without an exception.

---

DP-004

Condition: iRC is not equal to 1 (i.e., the external call did not return the success indicator) and the code was not already handled as a file-not-found case.

TRUE: Record a system error message including the numeric iRC value via ADD_ERROR, then evaluate RaiseExceptions (see DP-003).

FALSE: iRC equals 1; no error is recorded and execution completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be enabled (WIN_API.API_ENABLED) before any attempt is made to retrieve file information; if the API is unavailable the procedure must not proceed and must surface the WIN_API.NOT_AVAILABLE condition to the caller.
- BR-002 - The file name passed to the external API must be null-terminated and padded to exactly 512 characters using CHR(0) to satisfy the external function's character-buffer contract.
- BR-003 - All nine package-level integer output buffers (iBuff1-iBuff9) and the return code (iRC) must be reset to zero at the start of every invocation to prevent stale data from a prior call from being treated as current results.
- BR-004 - Return codes 0, -1074255551, and -1074245406 are treated as equivalent indicators that the specified file does not exist; any of these values must result in a descriptive error message that includes the file name.
- BR-005 - Any return code other than 1 (success) and the three file-not-found codes must be treated as a system-level failure; the error message must include the numeric return code to support diagnostics.
- BR-006 - The RaiseExceptions flag governs whether detected errors (file not found or system error) are propagated as a NO_DATA_FOUND exception or silently recorded on the error stack for the caller to inspect; this choice is entirely caller-controlled.
- BR-007 - All errors must be attributed to the CalledBy context string when recorded via ADD_ERROR, ensuring traceability back to the originating caller in the error stack.
- BR-008 - Unexpected exceptions must be enriched with supplementary detail from ADD_EXTERNAL_ERRORS before being re-raised, ensuring that any external error information is preserved in the error record.

---
**Implementation Logic**

```plsql

Procedure File_info ( CalledBy         IN  VARCHAR2,  
                      FileName         IN  VARCHAR2,
                      Option1          IN  PLS_INTEGER,
                      Option2          IN  PLS_INTEGER,
                      RaiseExceptions  IN BOOLEAN) is
 vcBuff1  varchar2(512);
 iRC      pls_integer;
begin
  Win_API_Debug.DebugLog(99,'File_Info','Args:  CalledBy="'||CalledBy||'", FileName="'||FileName||'", Option1='||to_char(Option1)||', Option2='||to_char(Option2)||', RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  	
  WIN_API.Clean_Error_Stack;
  iRC    := 0;
  iBuff1 := 0;
  iBuff2 := 0;
  iBuff3 := 0;
  iBuff4 := 0;
  iBuff5 := 0;
  iBuff6 := 0;
  iBuff7 := 0;
  iBuff8 := 0;
  iBuff9 := 0;
  
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iFileInfo,'d2kwutil_FileInfo','LONG','*CHAR,INT,INT,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG,*LONG');
    vcBuff1 := RPAD(Filename,512,CHR(0));
    iBuff1  := Option1;
    iBuff2  := Option2;
    iRC     := d2kwutil_FileInfo(win_api.FunctionHandle(iFileInfo),vcBuff1,iBuff1,iBuff2,iBuff3,iBuff4,iBuff5,iBuff6,iBuff7,iBuff8,iBuff9);
    Win_API_Debug.DebugLog(99,'File_Info','Result:  RC='||to_char(iRC)||', iBuff1='||to_char(iBuff1)||', iBuff2='||to_char(iBuff2)||', iBuff3='||to_char(iBuff3)||', iBuff4='||to_char(iBuff4)||', iBuff5='||to_char(iBuff5)||', iBuff6='||to_char(iBuff6)||', iBuff7='||to_char(iBuff7)||', iBuff8='||to_char(iBuff8)||', iBuff9='||to_char(iBuff9));
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;
  if iRC in (0, -1074255551, -1074245406) then
    WIN_API.Add_error(CalledBy,'File '||FileName||' does not exist');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC <> 1 then 
    WIN_API.Add_error(CalledBy,'Gathering Information about '||FileName||' generated system error '||to_char(iRC));
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end;
```

#### SP-018 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the handle of the currently active window by invoking the external Windows API function D2KWUTIL_ACTIVEWIN. The function returns a non-zero integer handle on success, enabling the calling routine (D2KWUTIL.CHOOSEFILE) to identify and interact with the active window. Error conditions are recorded on the error stack and, where instructed by the caller, surfaced as exceptions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry point and the value of the RaiseExceptions input parameter to the debug log via DEBUGLOG (Win_API_Debug.DebugLog).
- Step 2 - Clear any previously accumulated errors from the error stack by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack).
- Step 3 - Check whether the Windows API layer is available (WIN_API.API_ENABLED).
- Step 4 - If the API is available, register the external function call for D2KWUTIL_ACTIVEWIN using REGISTER_FUNCTION_CALL, supplying the function name, return type ('INT'), and a NULL argument list.
- Step 5 - Invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN via the registered function handle to obtain the active window handle, storing the result in the local return-code variable (iRC).
- Step 6 - Log the numeric result returned by D2KWUTIL_ACTIVEWIN to the debug log via DEBUGLOG.
- Step 7 - If the API is not available, raise the WIN_API.NOT_AVAILABLE exception, bypassing the external call entirely.
- Step 8 - Evaluate the return code: if iRC equals 0, the active window handle could not be obtained; record an error message via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 9 - If iRC is non-zero (success), return the active window handle integer to the caller.
- Step 10 - In the exception block, handle NO_DATA_FOUND by re-raising it; handle WIN_API.NOT_AVAILABLE by logging the 'API not available' message via ADD_ERROR and re-raising; handle all other exceptions by appending a generic error plus any external error details via ADD_ERROR and ADD_EXTERNAL_ERRORS, then re-raising.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL, invoke D2KWUTIL.D2KWUTIL_ACTIVEWIN to retrieve the active window handle, and log the result.

FALSE: Raise WIN_API.NOT_AVAILABLE immediately, bypassing the external call.

---

DP-002

Condition: The return code (iRC) returned by D2KWUTIL.D2KWUTIL_ACTIVEWIN equals 0.

TRUE: Record an error message ('Unable to obtain active window handle') via ADD_ERROR, then evaluate DP-003.

FALSE: Return the non-zero window handle integer to the caller as a successful result.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Suppress the exception; execution continues and the function returns 0 to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must clear the error stack before attempting any external API call, ensuring error state from prior operations does not contaminate the result of this invocation.
- BR-002 - The external Windows API (WIN_API.API_ENABLED) must be available before D2KWUTIL.D2KWUTIL_ACTIVEWIN is called; if the API layer is unavailable the function must not attempt the call and must raise WIN_API.NOT_AVAILABLE.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_ACTIVEWIN is treated as a failure condition, indicating that no active window handle could be obtained; this must be recorded as an error via ADD_ERROR.
- BR-004 - Exception propagation on a zero return code is caller-controlled: the function raises NO_DATA_FOUND only when the RaiseExceptions parameter is explicitly passed as TRUE; otherwise the error is recorded silently and the zero value is returned.
- BR-005 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be re-raised after error recording, ensuring the calling routine (D2KWUTIL.CHOOSEFILE) can apply its own error-handling strategy.
- BR-006 - Unhandled exceptions must incorporate both a generic error prefix and any additional external error detail retrieved via ADD_EXTERNAL_ERRORS before being re-raised, providing a complete diagnostic record on the error stack.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-019 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a Save File As dialog to the user and returns the file path selected. The procedure delegates to D2KWUTIL.CHOOSEFILE to render the dialog with the supplied title, starting directory, file filter, modal flag, and advanced flags. If the user cancels or makes no selection, an error is recorded via ADD_ERROR and, when configured to do so, a NO_DATA_FOUND exception is raised to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-008](#SP-008--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return file variable (vcReturnedFile) with the SampleName input, providing a default pre-populated filename in the dialog.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE, passing the operation context ('Save_File'), Modal flag, Title, StartDirectory, FileFilter, AdvancedFlags, a space delimiter, and the initialised file variable (by reference) to display the Save File As dialog and capture the user's selection.
- Step 3 - Evaluate the integer return code (iLRC) from D2KWUTIL.CHOOSEFILE to determine whether a file was selected.
- Step 4 - If iLRC equals 1 (no file selected), call ADD_ERROR to record the message 'No file was selected' against the 'Save_File' context.
- Step 5 - If RaiseExceptions is TRUE and no file was selected, raise NO_DATA_FOUND to propagate the failure to the calling routine.
- Step 6 - If iLRC does not equal 1 (a file was successfully selected), return the value of vcReturnedFile to the caller as the chosen save file path.

---
**Decision Points**

DP-001

Condition: iLRC (return code from D2KWUTIL.CHOOSEFILE) equals 1.

TRUE: No file was selected by the user; ADD_ERROR is called to register the error message 'No file was selected', and processing continues to DP-002.

FALSE: A file path was selected; the function returns vcReturnedFile to the caller.

---

DP-002

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iLRC = 1).

TRUE: The NO_DATA_FOUND exception is raised, propagating the failure to the calling routine.

FALSE: The procedure exits without raising an exception; control returns to the caller silently after the error has been logged.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The SampleName parameter serves as the pre-populated filename presented in the Save File As dialog; it must be supplied by the caller to seed the dialog's filename field.
- BR-002 - A return code of 1 from D2KWUTIL.CHOOSEFILE is the definitive indicator that no file was selected (e.g., the user cancelled); any other return code is treated as a successful selection.
- BR-003 - When no file is selected, an error must always be recorded via ADD_ERROR with the context 'Save_File' and the message 'No file was selected', regardless of the RaiseExceptions setting.
- BR-004 - Exception propagation is optional and controlled exclusively by the RaiseExceptions parameter; when FALSE, the caller receives no exception and must rely on the absence of a return value or the logged error to detect cancellation.
- BR-005 - Default values are defined for Title ('Save File As'), StartDirectory ('$WINDIR$'), FileFilter ('All files(*.*)|*.*|'), Modal (TRUE), AdvancedFlags (WIN_API.OFN_FLAG_DEFAULT), and RaiseExceptions (FALSE), ensuring the dialog can be invoked with only a SampleName if required.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-020 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data-type name supplied by the caller into the corresponding ORA_FFI integer constant. It is used internally by REGISTER_FUNCTION_CALL to resolve parameter and return-type descriptors before registering an external C function through the Oracle Foreign Function Interface (ORA_FFI).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, producing a normalised type token (vcType).
- Step 2 - Evaluate vcType against each supported C data-type name in sequence using an IF/ELSIF chain.
- Step 3 - When a match is found, assign the corresponding ORA_FFI integer constant to the local return variable iRC (e.g., '*CHAR' maps to ORA_FFI.C_CHAR_PTR, 'CHAR' maps to ORA_FFI.C_CHAR, '*INT' maps to ORA_FFI.C_INT_PTR, 'INT' maps to ORA_FFI.C_INT, '*LONG' maps to ORA_FFI.C_LONG_PTR, 'LONG' maps to ORA_FFI.C_LONG, '*SHORT' or '*BYTE' maps to ORA_FFI.C_SHORT_PTR, 'SHORT' or 'BYTE' maps to ORA_FFI.C_SHORT, '*DOUBLE' maps to ORA_FFI.C_DOUBLE_PTR, 'DOUBLE' maps to ORA_FFI.C_DOUBLE, '*VOID' maps to ORA_FFI.C_VOID_PTR).
- Step 4 - Return iRC to the caller. If no branch matched, iRC remains uninitialised (NULL) and that NULL value is returned.

---
**Decision Points**

DP-001
Condition: Normalised input (vcType) equals '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR.
FALSE: Evaluation continues to the next branch.

DP-002
Condition: vcType equals 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR.
FALSE: Evaluation continues to the next branch.

DP-003
Condition: vcType equals '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR.
FALSE: Evaluation continues to the next branch.

DP-004
Condition: vcType equals 'INT'
TRUE: iRC is set to ORA_FFI.C_INT.
FALSE: Evaluation continues to the next branch.

DP-005
Condition: vcType equals '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR.
FALSE: Evaluation continues to the next branch.

DP-006
Condition: vcType equals 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG.
FALSE: Evaluation continues to the next branch.

DP-007
Condition: vcType equals '*SHORT' OR vcType equals '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR.
FALSE: Evaluation continues to the next branch.

DP-008
Condition: vcType equals 'SHORT' OR vcType equals 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT.
FALSE: Evaluation continues to the next branch.

DP-009
Condition: vcType equals '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR.
FALSE: Evaluation continues to the next branch.

DP-010
Condition: vcType equals 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE.
FALSE: Evaluation continues to the next branch.

DP-011
Condition: vcType equals '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR.
FALSE: No branch matches; iRC remains NULL and a NULL value is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is case-insensitive; the function normalises it to uppercase before comparison, so 'char', 'CHAR', and 'Char' are all treated identically.
- BR-002 - Pointer variants of a type are denoted by prefixing the type name with an asterisk (e.g., '*INT' for a pointer to integer); the function maps these to the corresponding ORA_FFI pointer constant, distinct from the non-pointer constant.
- BR-003 - The type tokens '*SHORT' and '*BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT_PTR; similarly, 'SHORT' and 'BYTE' both resolve to ORA_FFI.C_SHORT.
- BR-004 - The function supports exactly eleven recognised type tokens: '*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT'/'*BYTE', 'SHORT'/'BYTE', '*DOUBLE', 'DOUBLE', and '*VOID'. Any DataType value outside this set causes the function to return NULL.
- BR-005 - The function performs no database access and raises no exceptions; responsibility for handling an unrecognised type (NULL return) rests with the calling routine REGISTER_FUNCTION_CALL.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-021 - GENERAL.ASK_CONFIRM

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: FT_CANCEL]
- pt_soq_new_fmb.xml [Trigger: FT_DEL]
- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator of the button pressed. The function is used across cancel, delete, and button-pressed triggers in the sales order quotation screen to obtain explicit user confirmation before proceeding with a potentially destructive or irreversible action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user using show_alert and capture the button pressed in the local variable p_albtn_pressed.
- Step 4 - Evaluate the captured button response: if the user pressed ALERT_BUTTON1 (the affirmative/confirm button), return 1 to the caller; otherwise return 0 to indicate the action was not confirmed.

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1 (the user pressed the first/affirmative button on the AL_CONFIRM alert)

TRUE: The function returns 1, signalling to the calling trigger that the user has confirmed the action.

FALSE: The function returns 0, signalling to the calling trigger that the user declined or dismissed the confirmation prompt.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be AL_CONFIRM; no other alert name is permissible within this function.
- BR-002 - The alert message text must be set dynamically at runtime from the confirm_msg parameter, allowing each calling trigger (FT_CANCEL, FT_DEL, WHEN-BUTTON-PRESSED) to supply a context-specific message.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response must be treated as non-confirmation and returns 0.
- BR-004 - The function must always return a numeric value (1 or 0); the trailing RETURN NULL is unreachable and must never be relied upon by calling code.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-022 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Checks whether the most recent form operation succeeded and, if not, identifies the error type (Oracle database error or Oracle Forms error), displays the appropriate error message to the user, and raises a form trigger failure to abort the current operation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-024](#SP-024--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - After a form operation, the form success state is checked.
- Step 2 - If the form is not in a successful state, the error type is evaluated: if the error is an Oracle database error (ORA type), the database error message is displayed; if it is a Forms error (FRM type), the Forms error text is displayed.
- Step 3 - After displaying the error, a form trigger failure is raised to abort the current operation and prevent the commit from completing.
- Step 4 - If the form is in a successful state, the procedure exits without action.

---
**Decision Points**

DP-001

Condition: The form operation succeeded (FORM_SUCCESS is true).

TRUE: The procedure exits without displaying any message or raising a failure.

FALSE: The error type is evaluated and an appropriate error message is displayed, then a trigger failure is raised.

DP-002

Condition: The error type is 'ORA' (Oracle database error).

TRUE: The database error message (SQLERRM) is displayed in an error alert.

FALSE: The error type is 'FRM' (Oracle Forms error) - the Forms error text (ERROR_TEXT) is displayed in an error alert.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If the form is not in a successful state after an operation, the error must be displayed to the user before the failure is raised.
- BR-002 - Oracle database errors and Oracle Forms errors are handled separately to ensure the appropriate error message is shown.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-023 - GENERAL.CHECK_NULL

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_new_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]
- pt_soq_new_fmb.xml [Trigger: WVI]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN); PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

Validates that a mandatory field is not null. If the supplied value is null, it composes a descriptive error message using the field title, displays it to the user, and raises a form trigger failure to prevent navigation away from the field.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_value | VARCHAR2 | IN |
| column_title | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-024](#SP-024--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - The supplied field value is checked to determine whether it is null.
- Step 2 - If the value is null, an error message is composed as "Enter a valid " followed by the column title supplied by the caller.
- Step 3 - The error message is displayed to the user as an error alert.
- Step 4 - A form trigger failure is raised to block navigation away from the field.
- Step 5 - If the value is not null, the procedure exits without action.

---
**Decision Points**

DP-001

Condition: The supplied field value (p_value) is null.

TRUE: An error message is composed and displayed; a form trigger failure is raised to prevent the user from leaving the field.

FALSE: The procedure exits without action; the field value is acceptable.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A mandatory field must contain a value before the user can navigate away; if it is blank, a descriptive "Enter a valid \<field name\>" error is shown.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_NULL( P_value IN VARCHAR2, column_title  IN VARCHAR2) IS
mesg_text        varchar2(80) := 'Enter a valid '||column_title ;
BEGIN
   IF p_value IS null  THEN
      GENERAL.DISP_TEXT(mesg_text,'Error');
      raise form_trigger_failure;
   END IF;
END;
```

#### SP-024 - GENERAL.DISP_TEXT

**Invoked From:**

- pt_soq_new_fmb.xml [ProgramUnit: BUILD_WHERE]
- pt_soq_new_fmb.xml [StoredProcedure: BUILD_WHERE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- DPL.pld [StoredProcedure: GENERAL.CHECK_NULL]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- pt_soq_new_fmb.xml [Trigger: ON-ERROR]
- pt_soq_new_fmb.xml [Trigger: ON-MESSAGE]
- pt_soq_new_fmb.xml [Trigger: POST-QUERY]
- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- pt_soq_new_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN); PO DETAILS (N/A / CN_PARTY); PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Displays a standardised alert dialog to the user with a supplied message text and title. When the title is "Error", the error alert template (AL_ERRINFO) is used; for any other title, the note alert template (AL_NOTE) is used. The alert title and message are set dynamically before the alert is shown.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The alert template name is defaulted to AL_ERRINFO (the error alert).
- Step 2 - If the title is "Error" (case-insensitive), the error alert template AL_ERRINFO is confirmed; otherwise the note alert template AL_NOTE is selected.
- Step 3 - The title property of the selected alert is updated with the supplied title string.
- Step 4 - The message text property of the selected alert is updated with the supplied message string.
- Step 5 - The alert dialog is displayed to the user.

---
**Decision Points**

DP-001

Condition: The title string is 'ERROR' (case-insensitive).

TRUE: The error alert template AL_ERRINFO is used.

FALSE: The note alert template AL_NOTE is used.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error-severity messages are shown using the AL_ERRINFO alert; all other messages (notes, cautions) are shown using the AL_NOTE alert.
- BR-002 - Both the title and the message text of the alert are set dynamically at runtime from the caller-supplied parameters; no static message text is hard-coded in this routine.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-025 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Populates a named Oracle Forms record group from a dynamic SQL query. The procedure ensures a clean record group state by removing any pre-existing group with the same name before recreating it from the supplied SELECT statement and populating it with current data. It is called during form initialisation (WHEN-NEW-FORM-INSTANCE) on the Suggested Order Quantity Processing screen to load list-item data.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the record group name (p_rg_name) and the SQL SELECT statement (p_select) as input parameters; assign the group name to a local variable.
- Step 2 - Attempt to locate an existing Oracle Forms record group with the supplied name using Find_Group.
- Step 3 - Evaluate whether a matching record group was found by testing the returned group ID with WEBUTIL.ID_NULL (Id_Null). If the group already exists, delete it via Delete_Group to ensure no stale data remains.
- Step 4 - Create a new record group from the supplied SQL query using Create_Group_From_Query, assigning the resulting group ID to the local variable.
- Step 5 - Populate the newly created record group by executing Populate_Group against the group ID, loading it with the rows returned by the SQL query.

---
**Decision Points**

DP-001

Condition: The record group identified by p_rg_name already exists in the current Oracle Forms session (i.e., Find_Group returns a non-null group ID, confirmed by WEBUTIL.ID_NULL / Id_Null evaluating to FALSE).

TRUE: The existing record group is deleted via Delete_Group before a fresh group is created, preventing duplicate or stale group definitions.

FALSE: No deletion is performed; processing continues directly to create the record group from the supplied query.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A record group with the name supplied in p_rg_name must not persist from a previous session or prior call; any pre-existing group of that name is unconditionally deleted before the group is recreated.
- BR-002 - The record group must always be (re)created from the SQL statement provided in p_select, ensuring the group structure and data reflect the query at the time of invocation.
- BR-003 - The procedure does not expose or validate the error code returned by Populate_Group; the caller is responsible for any downstream validation of the populated list item data.

---
**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-026 - GENERAL.RAISE_ERROR

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Looks up a business error message by code and displays it to the user via a standardised alert. Depending on the message type returned, the message is shown with the appropriate severity title (Error, Note, or Caution), and if the type is Error, a form trigger failure is raised to abort the current operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-024](#SP-024--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - The message type and message text are initialised. The message code is concatenated with the message text variable as the basis for the displayed message (note: the get_message lookup call is commented out in the current implementation, so only the error code is shown).
- Step 2 - The message type is evaluated: if it is 'E' (Error), the title is set to "Error", the message is displayed via DISP_TEXT, and a form trigger failure is raised to abort the operation.
- Step 3 - If the message type is 'N' (Note), the title is set to "Note" and the message is displayed without raising a failure.
- Step 4 - If the message type is 'C' (Caution), the title is set to "Caution" and the message is displayed without raising a failure.

---
**Decision Points**

DP-001

Condition: The message type is 'E' (Error).

TRUE: The error message is displayed with title "Error" and a form trigger failure is raised to abort the calling operation.

FALSE: Evaluate the next condition.

DP-002

Condition: The message type is 'N' (Note).

TRUE: The message is displayed with title "Note"; execution continues without raising a failure.

FALSE: Evaluate the next condition.

DP-003

Condition: The message type is 'C' (Caution).

TRUE: The message is displayed with title "Caution"; execution continues without raising a failure.

FALSE: No matching type - no message is displayed and no failure is raised.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - Error-severity messages result in a form trigger failure being raised after display; Note and Caution messages are displayed without aborting the calling operation.
- BR-002 - The get_message lookup that would retrieve the full message text by code is commented out in the current implementation; only the error code is shown in the message display.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-027 - PK_VALIDATE_PARTS.UPDATE_ON_ORDER

**Invoked From:**

- pt_soq_new_fmb.xml [ProgramUnit: UPDATE_PO_STOCK]
- pt_soq_new_fmb.xml [StoredProcedure: UPDATE_PO_STOCK]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Updates the on-order quantity in PM_PART_VAR for each part in a supplied order list, either incrementing (when a purchase order is raised) or decrementing (when a purchase order is closed or cancelled) the quantity. If a part variant record does not yet exist, SP_INSERT_PM_PART_VAR is called automatically to create it before the quantity update is applied.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_part_ordtab | part_order_type | IN |
| p_po_flag | VARCHAR2 | IN |
| p_created_by | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_error_code | NUMBER | OUT |
| p_error_msg | VARCHAR2 | OUT |

---

**Dependencies**

- SP_INSERT_PM_PART_VAR ([SP-095](#SP-095--SP_INSERT_PM_PART_VAR)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - For each part in the supplied order list, attempt to lock the corresponding PM_PART_VAR row (filtered by parent group, dealer, location, and part number) for update of on_order_qty using a NOWAIT lock.
- Step 2 - If no matching PM_PART_VAR row exists (NO_DATA_FOUND), call SP_INSERT_PM_PART_VAR to create the missing part variant record, passing the parent group, dealer, location, part number, and created-by values. Capture the returned error code and message in the output parameters.
- Step 3 - If SP_INSERT_PM_PART_VAR returns an error code of 1, exit the processing loop immediately.
- Step 4 - If a data width or incompatibility error (VALUE_ERROR) occurs during the lock attempt, set the error code to 1 with a descriptive width-problem message and exit the loop.
- Step 5 - If any other unexpected error occurs during the lock attempt (WHEN OTHERS), set the error code to 1 with the database error message and exit the loop.
- Step 6 - If the PO flag is 'R' (raise - new purchase order), update PM_PART_VAR by incrementing on_order_qty by the ordered quantity (p_qty) for the current part.
- Step 7 - If the PO flag is 'C' (close or cancel purchase order), update PM_PART_VAR by decrementing on_order_qty by the net quantity difference (p_qty minus r_qty) for the current part.
- Step 8 - If any error occurs during either update operation, set the error code to 1 with the database error message and exit the loop.
- Step 9 - After all parts are processed, return control to the caller with the error code and message output parameters set; a code of zero indicates success.

---
**Decision Points**

DP-001

Condition: The PM_PART_VAR row for the current part exists and can be locked for update.

TRUE: Proceed to the PO flag evaluation to update the on-order quantity.

FALSE (NO_DATA_FOUND): Call SP_INSERT_PM_PART_VAR to create the missing part variant record; if the insert returns error code 1, exit the loop immediately.

DP-002

Condition: SP_INSERT_PM_PART_VAR returns an error code of 1.

TRUE: Propagate the error code and message to the output parameters and exit the processing loop.

FALSE: Continue to the PO flag evaluation for the current part.

DP-003

Condition: A data width or incompatible data error (VALUE_ERROR) occurs during the row lock attempt.

TRUE: Set error code to 1 and a descriptive width-problem message; exit the loop.

FALSE: Evaluate the next error condition.

DP-004

Condition: Any other unexpected error occurs during the row lock attempt (WHEN OTHERS).

TRUE: Set error code to 1 and the database error message; exit the loop.

FALSE: Continue to the PO flag evaluation.

DP-005

Condition: The PO flag is 'R' (raise - new purchase order).

TRUE: Increment on_order_qty in PM_PART_VAR by adding the ordered quantity (p_qty) to the current value.

FALSE: Evaluate whether the flag is 'C'.

DP-006

Condition: The PO flag is 'C' (close or cancel purchase order).

TRUE: Decrement on_order_qty in PM_PART_VAR by subtracting the net quantity difference (p_qty minus r_qty).

FALSE: No update is performed for this part.

---
**Database Interactions**

- DB-001 - Read PM_PART_VAR - Reads data from PM_PART_VAR (columns: on order qty) for lookup or validation.
- DB-002 - Update OF - Updates existing rows in OF.
- DB-003 - Update PM_PART_VAR - Updates existing rows in PM_PART_VAR (columns: on order qty).
**Business Rules**

- BR-001 - If a part variant record does not yet exist in PM_PART_VAR when a purchase order is processed, SP_INSERT_PM_PART_VAR is called automatically to create it before the on-order quantity is updated.
- BR-002 - Raising a purchase order ('R') increments the on-order quantity by the full ordered quantity; closing or cancelling a purchase order ('C') decrements it by the net quantity difference (ordered quantity minus reference quantity).
- BR-003 - NULL on-order quantities are treated as zero during both increment and decrement operations via NVL, preventing arithmetic errors on uninitialised values.
- BR-004 - Any error during processing (insert failure, lock failure, data width error, or unexpected exception) is returned to the caller via the output parameters and the processing loop terminates immediately, leaving subsequent parts unprocessed.

---
**Implementation Logic**

```plsql
  PROCEDURE update_on_order(p_parent      IN VARCHAR2,
                            p_dealer      IN NUMBER,
                            p_loc_cd      IN VARCHAR2,
                            p_part_ordtab part_order_type,
                            p_po_flag     IN VARCHAR2,
                            p_created_by  IN VARCHAR2,
                            p_error_code  OUT NUMBER,
                            p_error_msg   OUT VARCHAR2) IS
    lv_part    PM_PART.part_num%TYPE;
    lv_err_msg VARCHAR2(2000); -- Added by sanjeev for sp_insert_pm_part_var
    lv_err_cd  NUMBER := 0; -- Added by sanjeev for sp_insert_pm_part_var
  BEGIN
    FOR i IN 1 .. p_part_ordtab.LAST LOOP
      BEGIN
        SELECT part_num
          INTO lv_part
          FROM PM_PART_VAR
         WHERE parent_group = p_parent
           AND dealer_map_cd = p_dealer
           AND loc_cd = p_loc_cd
           AND part_num = p_part_ordtab(i).p_part
           FOR UPDATE OF on_order_qty NOWAIT;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          Sp_Insert_Pm_Part_Var(p_parent,
                                p_dealer,
                                p_loc_cd,
                                p_part_ordtab(i).p_part,
                                p_created_by,
                                lv_err_msg,
                                lv_err_cd);
          p_error_code := lv_err_cd;
          p_error_msg  := lv_err_msg;

          IF p_error_code = 1 THEN
            -- If there is an error
            EXIT;
          END IF;
        WHEN VALUE_ERROR THEN
          p_error_code := 1;
          p_error_msg  := 'Width problem/Incompatible data while updating on order quantity for part : ' || p_part_ordtab(i)
                         .p_part;
          EXIT;
        WHEN OTHERS THEN
          p_error_code := 1;
          p_error_msg  := 'Execution failed while updating on order quantity for part : ' || p_part_ordtab(i)
                         .p_part || ' : ' || SQLERRM;
          EXIT;
      END;

      IF p_po_flag = 'R' THEN
        BEGIN
          UPDATE PM_PART_VAR
             SET on_order_qty = NVL(on_order_qty, 0) + p_part_ordtab(i)
                               .p_qty
           WHERE parent_group = p_parent
             AND dealer_map_cd = p_dealer
             AND loc_cd = p_loc_cd
             AND part_num = p_part_ordtab(i).p_part;
        EXCEPTION
          WHEN OTHERS THEN
            p_error_code := 1;
            p_error_msg  := SQLERRM;
            EXIT;
        END;
      ELSIF p_po_flag = 'C' THEN
        BEGIN
          UPDATE PM_PART_VAR
             SET on_order_qty = NVL(on_order_qty, 0) -
                                (NVL(p_part_ordtab(i).p_qty, 0) -
                                 NVL(p_part_ordtab(i).r_qty, 0))
           WHERE parent_group = p_parent
             AND dealer_map_cd = p_dealer
             AND loc_cd = p_loc_cd
             AND part_num = p_part_ordtab(i).p_part;
        EXCEPTION
          WHEN OTHERS THEN
            p_error_code := 1;
            p_error_msg  := SQLERRM;
            EXIT;
        END;
      END IF;
    END LOOP;
  END;
```

#### SP-028 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the Oracle Forms session waits for the command to complete before resuming. The procedure delegates execution to WEBUTIL.EXECUTE (SP-037), passing the supplied command string together with the BLOCKING_MODE constant to enforce synchronous behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-037](#SP-037--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the host command string (cmd) as input.
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-037) with cmd and the BLOCKING_MODE constant as arguments.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller (WEBUTIL.HOST).

---
**Decision Points**

No conditional decision points exist within this procedure. The function unconditionally delegates to WEBUTIL.EXECUTE with BLOCKING_MODE; all branching logic resides within WEBUTIL.EXECUTE (SP-037).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The host command must be executed synchronously; BLOCKING_MODE is always passed to WEBUTIL.EXECUTE, ensuring the calling session does not proceed until the OS process has completed.
- BR-002 - The procedure returns a PROCESS_ID to the caller, allowing the invoking routine (WEBUTIL.HOST) to reference or track the completed process.
- BR-003 - No direct database interactions are performed; all execution responsibility is delegated entirely to WEBUTIL.EXECUTE (SP-037).

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-029 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

CHECKLIBS verifies that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library defined in the property bundle for the package, the procedure compares the installed version against the expected version and, where a mismatch or absence is detected, downloads the library from the configured URL to the client. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-034](#SP-034--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-044](#SP-044--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-064](#SP-064--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-068](#SP-068--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-069](#SP-069--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-073](#SP-073--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Begin iterating through sequentially numbered library entries in the property bundle using the key pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>', incrementing the index counter (lib) on each iteration.
- Step 2 - If no entry is found for the OS-family/architecture-specific key, fall back to the OS-family-only key pattern 'install.syslib.<OSFamily>.<packageID>.<index>'.
- Step 3 - If both lookups return NULL, exit the loop; no further libraries are defined for this package.
- Step 4 - Parse the retrieved library specification string (pipe-delimited) to extract: library file name (position 1), expected file size in bytes (position 2), expected version string (position 3), and a progress-display flag (position 4).
- Step 5 - Query the client settings store via WEBUTIL.GETCLIENTSETTING using the key 'syslib.<libName>' to retrieve the currently installed version of the library.
- Step 6 - Evaluate whether a download is required: the installed version is absent, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set.
- Step 7 - If a download is required, resolve the download base URL by attempting three progressively less specific property bundle lookups in order: OS-family + architecture, OS-family only, then the generic 'install.syslib.location' key.
- Step 8 - Invoke WEBUTIL.DOWNLOADFROMURLINT to download the library file from the resolved URL, passing the file name, size, progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 9 - If the download succeeds, record the newly installed version on the client by calling WEBUTIL.SETCLIENTSETTING with key 'syslib.<libName>' and the expected version value.
- Step 10 - If the download fails, write a failure message to the WebUtil log via WEBUTIL.LOG and continue processing any remaining libraries in the loop.

---
**Decision Points**

DP-001

Condition: The OS-family + architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL library specification.

TRUE: Use the returned specification for the current library entry.

FALSE: Attempt the fallback lookup using the OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>').

---

DP-002

Condition: The OS-family-only fallback key also returns NULL.

TRUE: Exit the loop; all library entries for this package have been processed.

FALSE: Use the returned specification and continue processing the current library entry.

---

DP-003

Condition: The installed version retrieved from the client settings store is NULL, differs from the expected version defined in the property bundle, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip to the next iteration.

---

DP-004

Condition: The OS-family + architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the OS-family-only location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Use the generic location key ('install.syslib.location') as the final fallback.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the expected version against the library name in the client settings store via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message for the library via WEBUTIL.LOG and continue to the next library entry.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package are defined in the property bundle under sequentially indexed keys and must include at minimum a library name, file size, and version string; processing stops at the first index that returns no entry.
- BR-002 - Library lookup is OS-sensitive: the procedure first attempts to match on both OS family and CPU architecture; only if that yields no result does it fall back to OS family alone, ensuring platform-appropriate libraries are selected.
- BR-003 - A library must be downloaded if and only if its installed version is absent from the client settings store, its installed version does not match the version defined in the property bundle, or the REDOWNLOAD_SYSLIB override flag is active.
- BR-004 - The download base URL is resolved with the same OS-specificity hierarchy (family + architecture -> family only -> generic), ensuring the most platform-specific source location is preferred.
- BR-005 - The client settings store entry ('syslib.<libName>') is updated to the expected version only upon confirmed successful download; a failed download must not update the version record.
- BR-006 - A failed library download must be recorded in the WebUtil log with the library name and a failure indicator; processing continues with remaining libraries rather than aborting the loop.
- BR-007 - Progress dialog text displayed during download must be sourced from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE (keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE'), ensuring localised user-facing strings.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-030 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is called by WEBUTIL.SETDATA to clean up a specific callback trigger once it is no longer needed, preventing stale entries from persisting in the collection.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed from the internal m_callbacks collection.
- Step 2 - Check whether an entry with the supplied key currently exists in the m_callbacks collection.
- Step 3 - If the entry exists, delete it from the m_callbacks collection using the provided key.
- Step 4 - If the entry does not exist, take no action and return silently.

---
**Decision Points**

DP-001

Condition: m_callbacks.exists(callbackKey) - the supplied key is present in the m_callbacks collection.

TRUE: The entry identified by callbackKey is deleted from the m_callbacks collection.

FALSE: No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to delete a callback entry if the key already exists in the m_callbacks collection; deletion of a non-existent key is not permitted and is silently bypassed.
- BR-002 - The callbackKey parameter must be a PLS_INTEGER and uniquely identifies the callback entry to be cleared within the m_callbacks collection.
- BR-003 - The procedure produces no output and raises no exception regardless of whether the supplied key exists or not, ensuring safe invocation by WEBUTIL.SETDATA without requiring prior existence checks by the caller.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-031 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by the supplied checksum value. The procedure delegates the close operation entirely to the WebUtil_DB package, ensuring that any server-side BLOB resource previously opened and tracked under the given checksum is properly released.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points exist within this function. All conditional logic is encapsulated inside WebUtil_DB.CloseBlob; this function acts solely as a pass-through wrapper and returns whatever BOOLEAN value that subordinate call produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a BLOB handle that was previously opened and registered; the validity of the checksum is enforced by WebUtil_DB.CloseBlob.
- BR-002 - The function must return a BOOLEAN result to its caller (WEBUTIL.SETDATA) indicating success or failure of the close operation; no silent suppression of the result is permitted.
- BR-003 - No direct database table interactions are performed within this function; all resource-management logic is owned by WebUtil_DB.CloseBlob.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-032 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file handle represented by the supplied Java object. The procedure delegates to the underlying Java class oracle/forms/webutil/fileTransfer/AppServerFileReader by invoking its closeFile method via the JNI bridge, returning a boolean result that indicates whether the file was closed successfully. It is called by WEBUTIL.SETDATA to release file resources after data transfer operations are complete.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that represents the open AppServerFileReader file handle on the application server.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the closeFile method on the AppServerFileReader Java class through the JNI bridge (JNI.CALL_BOOLEAN_METHOD), passing the object reference and an empty argument list.
- Step 4 - Return the boolean result produced by the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the close operation.

---
**Decision Points**

DP-001

Condition: The JNI call to oracle/forms/webutil/fileTransfer/AppServerFileReader.closeFile returns TRUE or FALSE.

TRUE: The file handle was closed successfully; the boolean value TRUE is returned to the calling routine (WEBUTIL.SETDATA).

FALSE: The file handle could not be closed; the boolean value FALSE is returned to the calling routine, signalling that the close operation failed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list (args) must be reset to NULL before invoking the Java closeFile method to prevent unintended argument values from a prior call from being passed to the JNI bridge.
- BR-002 - The file close operation is performed exclusively through the JNI bridge against the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class; no direct database or file-system interaction is performed within this function.
- BR-003 - The function must return the raw boolean result of the Java method call unchanged to the caller, preserving the success or failure status of the underlying close operation.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-033 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified interface for downloading a file from a specified URL to a client-side destination path. The procedure delegates all processing to the internal implementation routine WEBUTIL.DOWNLOADFROMURLINT, passing fixed default values for parameters not exposed at this level, thereby abstracting the complexity of the full download operation from its callers.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-034](#SP-034--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL, the client destination path, and an optional file size (defaulting to 0 if not supplied by the caller).
- Step 2 - Invoke WEBUTIL.DOWNLOADFROMURLINT, forwarding the source URL and client destination path directly, and supplying fixed internal defaults: offset position 0, the caller-provided file size, overwrite flag FALSE, and three NULL optional arguments.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT to the caller (WEBUTIL.URL_TO_CLIENT), indicating whether the download operation succeeded or failed.

---
**Decision Points**

No decision points are present in this procedure. All conditional logic is encapsulated within WEBUTIL.DOWNLOADFROMURLINT; this procedure acts purely as a pass-through wrapper with fixed parameter defaults.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file size parameter is optional; if not provided by the caller, it defaults to 0, and this default value is forwarded to WEBUTIL.DOWNLOADFROMURLINT.
- BR-002 - The byte offset passed to WEBUTIL.DOWNLOADFROMURLINT is always fixed at 0, meaning the download always begins from the start of the source file.
- BR-003 - The overwrite flag forwarded to WEBUTIL.DOWNLOADFROMURLINT is always fixed at FALSE, meaning this interface does not permit overwriting an existing client-side file without explicit handling at the internal level.
- BR-004 - All extended or optional download parameters (the three NULL arguments) are not exposed through this interface; callers requiring those capabilities must invoke WEBUTIL.DOWNLOADFROMURLINT directly.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-034 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DownLoadFromURLInt is the internal worker function that performs the actual file download from a specified URL to a client-side destination. It constructs a pipe-delimited command string encoding all download parameters (special destination type, expected file size, progress indicator flag, and optional progress dialog text), submits it to the WebUtil Java bean via WebUtil_Core.setProperty, and retrieves the boolean outcome via WebUtil_Core.getProperty. It is invoked by WEBUTIL.CHECKLIBS and WEBUTIL.DOWNLOADFROMURL and returns TRUE if the download succeeded, FALSE otherwise.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its character representation. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0'; otherwise append its character representation. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N'; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Concatenate sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) into the submit string, each separated by the pipe delimiter.
- Step 7 - Submit the fully assembled command string to the WebUtil Java bean by calling WebUtil_Core.setProperty with property key WUC_URL_DOWNLOAD on the WUC_PACKAGE component.
- Step 8 - Retrieve the execution result by calling WebUtil_Core.getProperty with the same package and property key.
- Step 9 - Return TRUE if the retrieved result equals the string 'TRUE', otherwise return FALSE.
- Step 10 - On CLIENT_FILE_NULL exception, log error code 130 via WebUtil_Core.Error and return FALSE.
- Step 11 - On URL_NULL exception, log error code 25 via WebUtil_Core.Error and return FALSE.
- Step 12 - On BEAN_NOT_REGISTERED exception, display an alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE.
- Step 13 - On PROPERTY_ERROR exception, raise FORM_TRIGGER_FAILURE.

---
**Decision Points**

DP-001

Condition: sourceURL IS NULL

TRUE: Raise the URL_NULL exception, which is caught in the exception block, logs error code 25, and returns FALSE.

FALSE: Continue processing to validate clientDestination.

---

DP-002

Condition: clientDestination IS NULL

TRUE: Raise the CLIENT_FILE_NULL exception, which is caught in the exception block, logs error code 130, and returns FALSE.

FALSE: Continue building the submit string.

---

DP-003

Condition: specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE: Append the default value '0' to the submit string.

FALSE: Append the actual specialDestination value (converted to character) to the submit string.

---

DP-004

Condition: fileSize IS NULL

TRUE: Append '0' to the submit string.

FALSE: Append the actual fileSize value (converted to character) to the submit string.

---

DP-005

Condition: withProgress IS NULL OR withProgress = FALSE

TRUE: Append 'N' to the submit string, indicating no progress dialog is required.

FALSE: Append 'Y' to the submit string, indicating a progress dialog should be displayed.

---

DP-006

Condition: result (returned from WebUtil_Core.getProperty) = 'TRUE'

TRUE: Function returns TRUE, indicating the download completed successfully.

FALSE: Function returns FALSE, indicating the download did not complete successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be provided; a null sourceURL is invalid and will cause the function to log error code 25 and return FALSE without attempting the download.
- BR-002 - A client destination path must be provided; a null clientDestination is invalid and will cause the function to log error code 130 and return FALSE without attempting the download.
- BR-003 - The specialDestination parameter must be an integer in the range 0-2 inclusive; any null, negative, or out-of-range value is silently normalised to 0 before submission.
- BR-004 - A null fileSize is normalised to 0, ensuring the bean always receives a numeric value for this field.
- BR-005 - A null or FALSE withProgress flag is transmitted as 'N'; only an explicit TRUE value transmits 'Y', enabling the progress dialog on the client.
- BR-006 - Null progress text parameters (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character so that the pipe-delimited command string remains structurally consistent for the bean parser.
- BR-007 - The WebUtil Java bean identified by WebUtil_Core.WUC_PACKAGE must be registered in the Forms session; if it is not, the function raises FORM_TRIGGER_FAILURE after alerting the user with the missing bean class name.
- BR-008 - A PROPERTY_ERROR raised during bean communication results in immediate FORM_TRIGGER_FAILURE, preventing silent data corruption or partial downloads.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-035 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Formats a structured error message string from a numeric error code, a program unit name, and up to three optional argument values, then registers that message against the identified WebUtil package instance by setting the WUC_ERROR_MSG property via Webutil_Core.setProperty. This provides a standardised mechanism for propagating error information back to the calling context (WEBUTIL_CORE.CUSTOMEVENTHANDLER) in a pipe-delimited format.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text variable by concatenating the literal prefix 'ERROR' with the zero-padded three-digit representation of the supplied numeric code and a pipe delimiter followed by the program unit name (pu_name), producing the base token 'ERRORnnn|pu_name'.
- Step 2 - Evaluate whether the first optional argument (arg1) has been supplied; if it is not null, append a pipe delimiter and the value of arg1 to the error text string.
- Step 3 - Evaluate whether the second optional argument (arg2) has been supplied; if it is not null, append a pipe delimiter and the value of arg2 to the error text string.
- Step 4 - Evaluate whether the third optional argument (arg3) has been supplied; if it is not null, append a pipe delimiter and the value of arg3 to the error text string.
- Step 5 - Call Webutil_Core.setProperty, passing the packageID, the property key 'WUC_ERROR_MSG', and the fully assembled error text string to register the error message against the relevant WebUtil package instance.

---
**Decision Points**

DP-001

Condition: arg1 IS NOT NULL

TRUE: Append '|' || arg1 to the error text string.

FALSE: arg1 is omitted from the error text string; no change is made.

---

DP-002

Condition: arg2 IS NOT NULL

TRUE: Append '|' || arg2 to the error text string.

FALSE: arg2 is omitted from the error text string; no change is made.

---

DP-003

Condition: arg3 IS NOT NULL

TRUE: Append '|' || arg3 to the error text string.

FALSE: arg3 is omitted from the error text string; no change is made.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the fixed prefix 'ERROR' followed immediately by the numeric error code zero-padded to exactly three digits, ensuring a consistent, parseable token format (e.g. 'ERROR042').
- BR-002 - The program unit name (pu_name) is a mandatory component of the error message and must always appear as the second pipe-delimited segment after the error code token.
- BR-003 - Optional arguments arg1, arg2, and arg3 are appended to the message only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - Arguments must be appended in strict positional order (arg1 before arg2, arg2 before arg3); no argument may be included if a preceding positional argument is null, as inclusion is conditional on the preceding null-check sequence.
- BR-005 - The assembled error text must not exceed 1024 characters, as enforced by the declared size of the errText local variable.
- BR-006 - The finalised error message must be persisted to the WebUtil package instance identified by packageID under the reserved property key 'WUC_ERROR_MSG' via Webutil_Core.setProperty, making it available to the invoking context.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-036 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user. If the WebUtil error alert object has been initialised, the alert's message is set to the error text and the alert is shown. If the alert object is not available, the error is displayed as a standard Forms message.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the WebUtil error alert object handle is initialised (not null).
- Step 2 - If the alert object is available, set the alert message text to the supplied error text and display the alert.
- Step 3 - If the alert object is not available, display the error text as a standard Forms message prefixed with "WebUtil Error: ".

---
**Decision Points**

DP-001

Condition: The WebUtil error alert object handle (m_errorAlert) is not null (alert is initialised).

TRUE: Set the alert message text and display the alert.

FALSE: Display the error as a standard Forms message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WebUtil error alert is the preferred display mechanism; the Forms message fallback is used only when the alert object has not been initialised.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-037 - WEBUTIL.EXECUTE

**Invoked From:**

- SP_CALCULATE_SOQ_NEW.prc [StoredProcedure: SP_CALCULATE_SOQ_NEW]
- SP_SOQ_POPULATE_CONSUMPTION.prc [StoredProcedure: SP_SOQ_POPULATE_CONSUMPTION]
- SP_UPDATE_PART_PRICE.prc [StoredProcedure: SP_UPDATE_PART_PRICE]
- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host command on the client workstation via the WebUtil framework, returning a process identifier for the launched process. The execution mode and command are passed to the WebUtil host component using WebUtil_Core.setProperty; the resulting process handle is retrieved via WEBUTIL.GETPROPERTY. If the WebUtil bean is not registered, an error alert is displayed through WEBUTIL.ERRORALERT, identifying the missing component class obtained via WEBUTIL.GETIMPLCLASS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-036](#SP-036--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-045](#SP-045--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-051](#SP-051--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the command string (cmd) is not null before attempting execution.
- Step 2 - If cmd is not null, set the execution mode on the WebUtil host component by passing the WUH_EXECUTION_MODE property and the exemode value via WebUtil_Core.setProperty.
- Step 3 - Submit the command to the WebUtil host component by setting the WUH_EXECUTE property with the cmd value via WebUtil_Core.setProperty.
- Step 4 - Retrieve the process handle returned by the WebUtil host component by reading the WUH_EXECUTE property via WEBUTIL.GETPROPERTY (WebUtil_Core.getProperty) and store it as the numeric handle of the PROCESS_ID record.
- Step 5 - Return the populated PROCESS_ID record (or an empty record if cmd was null) to the caller.
- Step 6 - If a BEAN_NOT_REGISTERED exception is raised at any point, invoke WEBUTIL.ERRORALERT to display an informative error message that includes the implementation class name obtained via WEBUTIL.GETIMPLCLASS, indicating that WEBUTIL_HOST.Execute will not work.

---
**Decision Points**

DP-001

Condition: The command string (cmd) is not null.

TRUE: The execution mode is set on the WebUtil host component, the command is submitted for execution, and the process handle is retrieved via WEBUTIL.GETPROPERTY and stored in the PROCESS_ID record.

FALSE: No properties are set and no process handle is retrieved; an empty PROCESS_ID record is returned to the caller.

DP-002

Condition: The WebUtil host bean is registered on the client (no BEAN_NOT_REGISTERED exception is raised).

TRUE: Processing completes normally and the PROCESS_ID record is returned.

FALSE: WEBUTIL.ERRORALERT is called with a message composed using WEBUTIL.GETIMPLCLASS to identify the unregistered bean class, informing the user that WEBUTIL_HOST.Execute will not work.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The host command is only submitted for execution if the cmd parameter is not null; a null command results in a no-operation and an empty process identifier is returned.
- BR-002 - The execution mode must be set on the WebUtil host component before the command is submitted, ensuring the host process is launched with the correct mode.
- BR-003 - If the WebUtil host bean is not registered on the client, the operation must fail visibly by invoking WEBUTIL.ERRORALERT with a descriptive message that includes the bean implementation class name (obtained via WEBUTIL.GETIMPLCLASS) rather than failing silently.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-038 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file that was previously opened through the WebUtil file I/O framework. The procedure releases the file handle on the client tier by instructing the WebUtil bean to close the file, then nullifies the handle reference to prevent further use. It is invoked as part of Excel report generation in VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file IN OUT file_type) representing an open client-side text file.
- Step 2 - Check whether the file handle is currently active (file.handle IS NOT NULL).
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the handle value to instruct the WebUtil bean to physically close the file on the client.
- Step 4 - Set file.handle to NULL to invalidate the handle reference and signal that the file is no longer open.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 6 - If a property interaction error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing.

---
**Decision Points**

DP-001

Condition: file.handle IS NOT NULL

TRUE: The WebUtil bean is instructed to close the file via WebUtil_Core.setProperty, and file.handle is set to NULL.

FALSE: No close operation is performed; the procedure exits without taking any action.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call.

TRUE: An error alert is displayed identifying the missing WebUtil implementation class, and TOOL_ERR.TOOL_ERROR is raised to halt execution.

FALSE: Normal processing continues; no alert is raised.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call.

TRUE: TOOL_ERR.TOOL_ERROR is raised to halt execution.

FALSE: Normal processing continues without error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is non-null; a null handle is treated as already closed and no action is taken.
- BR-002 - After a successful close, the file handle must be set to NULL to prevent any subsequent operations from referencing a stale or invalid handle.
- BR-003 - The WebUtil bean responsible for client-side text I/O (identified by WebUtil_Core.WUF_PACKAGE) must be registered and available on the client; if it is not, the procedure raises a terminal error (TOOL_ERR.TOOL_ERROR) and the calling process is aborted.
- BR-004 - Any property interaction failure reported by the WebUtil framework during the close operation is treated as a terminal error, and TOOL_ERR.TOOL_ERROR is raised to ensure the failure is not silently ignored.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-039 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the user with a native file-save dialog box, allowing them to browse to a target directory and specify a file name under which a file (typically an Excel report) will be saved. The function delegates to the internal file-selection dialog routine, enforcing save-mode behaviour, and returns the fully qualified file path chosen by the user.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-019](#SP-019--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-040](#SP-040--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: target directory name, default file name, file type filter, and dialog title.
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT, passing through all four caller-supplied parameters together with the D2KWUTIL.SAVE_FILE mode constant, a TRUE flag (indicating save mode), and a FALSE flag (indicating that multi-selection is not permitted).
- Step 3 - Return the Varchar2 result produced by WEBUTIL.FILE_SELECTION_DIALOG_INT to the calling routine (VIEW_EXCEL_REPORT_NEW), which represents the file path selected or confirmed by the user in the dialog.

---
**Decision Points**

No explicit conditional decision points exist within FILE_SAVE_DIALOG itself. All branching logic based on the dialog mode, save flag, and multi-select flag is encapsulated within WEBUTIL.FILE_SELECTION_DIALOG_INT and is not exposed at this level.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - All four input parameters (directory_name, file_name, file_filter, title) are optional; NULL values are accepted and passed directly to the internal dialog routine, which is responsible for applying any defaults.
- BR-002 - The dialog is always opened in save-file mode, enforced by passing the D2KWUTIL.SAVE_FILE constant as the dialog-mode argument to WEBUTIL.FILE_SELECTION_DIALOG_INT.
- BR-003 - Multi-file selection is explicitly prohibited; the FALSE multi-select flag passed to WEBUTIL.FILE_SELECTION_DIALOG_INT ensures the user can confirm only a single target file path.
- BR-004 - The function returns the user-selected file path as a Varchar2 value; the calling routine (VIEW_EXCEL_REPORT_NEW) is responsible for handling a NULL or empty return value (e.g., when the user cancels the dialog).

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-040 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file-selection dialog to the end user via the WebUtil client-side bean and returns the user's selection as a string. Depending on the dialog_type and select_file flags supplied by the caller (WEBUTIL.FILE_SAVE_DIALOG), the function renders either a Save File dialog, an Open Directory dialog, or an Open File dialog. It also normalises any escaped backslash sequences introduced by the underlying JFileChooser component before returning the resolved path.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-019](#SP-019--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept all input parameters: directory_name, file_name, file_filter, title, dialog_type, select_file, and multiselect.
- Step 2 - Push the dialog configuration to the WebUtil client bean by setting the following bean properties via WebUtil_Core.setProperty: WUF_GFN_DIRNAME (initial directory), WUF_FILENAME (default file name, cleared on each call), WUF_FILTER (file-type filter), WUF_GFN_MESSAGE (dialog title), and WUF_GFN_MULTISELECT (multi-selection flag, cleared on each call).
- Step 3 - Determine which dialog variant to invoke based on dialog_type and select_file (see Decision Points) and retrieve the user's selection from the corresponding bean property via WebUtil_Core.getProperty, storing it in the local variable result.
- Step 4 - Inspect result for a leading double-backslash sequence ('\\') using INSTR. If the string starts at position 1 with '\\', prepend an additional '\\' to result so that the subsequent replace step produces the correct UNC-path output.
- Step 5 - Replace all occurrences of '\\\\' with '\\' in result to normalise the escaped backslash sequences produced by JFileChooser.
- Step 6 - Return the normalised file-path string to the caller (WEBUTIL.FILE_SAVE_DIALOG).
- Step 7 - If the WebUtil bean is not registered, raise an error alert identifying the missing bean class and then raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a property error occurs during bean interaction, raise FORM_TRIGGER_FAILURE to halt processing.

---
**Decision Points**

DP-001

Condition: dialog_type equals the constant SAVE_FILE.

TRUE: Retrieve the user's selected path from the bean property WUF_GFN_SAVEFILE, presenting a Save File dialog.

FALSE: Proceed to DP-002 to determine the correct Open dialog variant.

---

DP-002

Condition: select_file is FALSE (evaluated only when dialog_type is not SAVE_FILE).

TRUE: Retrieve the user's selected path from the bean property WUF_GFN_OPENDIR, presenting an Open Directory dialog.

FALSE: Retrieve the user's selected path from the bean property WUF_GFN_OPENFILE, presenting an Open File dialog.

---

DP-003

Condition: The position of the first occurrence of '\\\\' in result equals 1 (i.e., result begins with a double-backslash, indicating a UNC path).

TRUE: Prepend '\\\\' to result before executing the replace step, ensuring the UNC prefix is preserved correctly after normalisation.

FALSE: Proceed directly to the replace step without modifying the start of result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog_type parameter governs the top-level dialog mode; a value equal to the SAVE_FILE constant mandates use of the Save File dialog regardless of the select_file flag.
- BR-002 - When dialog_type is not SAVE_FILE, the select_file flag exclusively determines whether a directory-picker or a file-picker is presented; FALSE yields a directory dialog, TRUE yields a file dialog.
- BR-003 - The WUF_FILENAME and WUF_GFN_MULTISELECT bean properties must be cleared on every invocation (setProperty called with the clear flag set to true) to prevent stale values from a prior dialog call from influencing the current dialog.
- BR-004 - Backslash sequences in the returned path must be normalised by replacing every '\\\\' with '\\' to correct the escaped output produced by the JFileChooser component; UNC paths beginning with '\\\\' require an additional '\\' prefix before normalisation to preserve the leading double-backslash.
- BR-005 - If the required WebUtil client bean is not registered on the client, the function must not return a partial result; it must issue an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to abort the calling form trigger.
- BR-006 - Any property-level error raised during bean interaction must cause the function to raise FORM_TRIGGER_FAILURE immediately, preventing the form from continuing with an indeterminate file-path value.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-041 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the client machine for text I/O operations and returns a file handle for subsequent read, write, or append processing. The function is invoked by VIEW_EXCEL_REPORT_NEW to establish a client-side file channel required for Excel report generation via the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the supplied file mode is one of the three permitted values ('r', 'w', 'a'); raise TOOL_ERR.TOOL_ERROR immediately if the value is invalid.
- Step 2 - Validate that a file path/name (spec) has been provided and is not null or empty; raise TOOL_ERR.TOOL_ERROR if the specification is absent.
- Step 3 - Transmit the file path to the WebUtil client bean by setting the WUF_FILENAME property via WebUtil_Core.setProperty.
- Step 4 - Transmit the requested file mode to the WebUtil client bean by setting the WUF_TEXTIO_FILEMODE property via WebUtil_Core.setProperty.
- Step 5 - Transmit the character set to the WebUtil client bean by setting the WUF_TEXTIO_CHARSET property via WebUtil_Core.setProperty; if no character set was supplied, the literal '(null)' is passed to signal the absence of a charset preference.
- Step 6 - Instruct the WebUtil client bean to open the file by retrieving the WUF_TEXTIO_OPEN property via WebUtil_Core.getProperty; the bean returns a Java file handle string.
- Step 7 - Validate the returned Java handle; if it is null, empty, or '-1', raise TOOL_ERR.TOOL_ERROR to indicate that the file could not be opened.
- Step 8 - Convert the valid Java handle string to a numeric value, assign it to the clientFile.handle attribute, and return the populated file_type record to the caller.

---
**Decision Points**

DP-001

Condition: The supplied filemode (case-insensitive) is not one of the permitted values 'r', 'w', or 'a'.

TRUE: TOOL_ERR.TOOL_ERROR is raised immediately; file open processing is aborted.

FALSE: Processing continues to the file specification validation step.

---

DP-002

Condition: The supplied spec parameter is null or an empty string.

TRUE: TOOL_ERR.TOOL_ERROR is raised immediately; file open processing is aborted.

FALSE: Processing continues to transmit parameters to the WebUtil client bean.

---

DP-003

Condition: The charSet parameter is null.

TRUE: The literal string '(null)' is passed as the WUF_TEXTIO_CHARSET property value, signalling no charset preference to the client bean.

FALSE: The actual charSet value is passed as the WUF_TEXTIO_CHARSET property value.

---

DP-004

Condition: The Java handle returned by WebUtil_Core.getProperty for WUF_TEXTIO_OPEN is null, empty, or equal to '-1'.

TRUE: TOOL_ERR.TOOL_ERROR is raised, indicating the client-side file could not be opened.

FALSE: The handle is valid; it is converted to a number, assigned to clientFile.handle, and the file_type record is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append), evaluated case-insensitively; any other value is treated as an unrecoverable error.
- BR-002 - A non-null, non-empty file path specification must be provided; the function will not attempt to open an unnamed file.
- BR-003 - The character set parameter is optional; when omitted, the WebUtil client bean is explicitly informed of the absence of a charset preference via the sentinel value '(null)'.
- BR-004 - A Java handle value of null, empty string, or '-1' is treated as a failed file-open attempt and results in TOOL_ERR.TOOL_ERROR being raised; no partial file_type record is returned.
- BR-005 - If the WebUtil bean is not registered on the client, an error alert is displayed identifying the missing bean class before TOOL_ERR.TOOL_ERROR is raised, ensuring the operator receives a diagnostic message.
- BR-006 - VALUE_ERROR during handle conversion (e.g., non-numeric Java handle) is re-raised as TOOL_ERR.TOOL_ERROR, maintaining a consistent error contract for the caller.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-042 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given numeric key. The function provides a lookup mechanism into the internal callbacks collection, allowing callers such as WEBUTIL.SETDATA to resolve which trigger string corresponds to a specific callback key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer callback key (callbackKey) supplied by the calling routine.
- Step 2 - Use callbackKey as an index into the package-level collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct index lookup against m_callbacks and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds checking or default handling is performed within this function, so an invalid key will raise a runtime collection error.
- BR-002 - The function returns the trigger name exactly as stored in m_callbacks, with no transformation or validation applied to the retrieved value.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-043 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family identifier of the client machine as a PLS_INTEGER value. This function exposes the internally held client OS family constant (m_clientOSFamily) to callers, enabling the application to determine the client platform category for conditional processing or display logic.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked with no input parameters.
- Step 2 - The function reads the module-level variable m_clientOSFamily, which holds the pre-populated client operating system family identifier.
- Step 3 - The function returns the PLS_INTEGER value of m_clientOSFamily directly to the caller.

---
**Decision Points**

No decision points are present in this function. The implementation unconditionally returns the value of m_clientOSFamily without branching logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function returns a PLS_INTEGER representing the client OS family; no transformation or validation is applied to the stored value before it is returned.
- BR-002 - The function accepts no input parameters; the client OS family value must already be populated in m_clientOSFamily prior to invocation.
- BR-003 - The function is read-only and produces no side effects; it does not modify any variables or interact with any database objects.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-044 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration setting from the WebUtil core bean. Given a property name, the function delegates to WebUtil_Core to set and then read back the requested local property, returning its current value to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2) identifying the client-side setting to be retrieved.
- Step 2 - Evaluate whether propertyName is non-null; if null, skip all processing and return a null result.
- Step 3 - Invoke WebUtil_Core.setProperty, targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and passing propertyName as the value, to request the local property from the WebUtil bean.
- Step 4 - Invoke WebUtil_Core.getProperty on the same WUC_PACKAGE component and WUC_GET_LOCAL_PROPERTY key to read back the resolved property value into the local variable result.
- Step 5 - Return result (up to 255 characters) to the caller.
- Step 6 - If a BEAN_NOT_REGISTERED exception is raised during processing, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form execution.
- Step 7 - If a PROPERTY_ERROR exception is raised during processing, raise FORM_TRIGGER_FAILURE to halt form execution without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to call WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client setting value.

FALSE: Skip all bean interaction and return a null value to the caller.

DP-002

Condition: WebUtil_Core raises BEAN_NOT_REGISTERED during property access

TRUE: Display an error alert identifying the unregistered WebUtil_Core implementation class, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal processing.

DP-003

Condition: WebUtil_Core raises PROPERTY_ERROR during property access

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger (no alert is displayed).

FALSE: Continue normal processing and return the retrieved value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not be passed to the WebUtil bean; the function silently returns null without invoking any bean operations when propertyName is null.
- BR-002 - The returned client setting value is limited to a maximum of 255 characters.
- BR-003 - The WebUtil core bean (WUC_PACKAGE) must be registered before this function is called; if it is not registered, the function raises a user-facing error alert and terminates the form trigger via FORM_TRIGGER_FAILURE.
- BR-004 - Any property resolution error reported by WebUtil_Core (PROPERTY_ERROR) causes immediate termination of the form trigger via FORM_TRIGGER_FAILURE, with no partial result returned to the caller.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-045 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package identifier. Used internally by the WebUtil framework to identify the bean class associated with a component when reporting registration errors.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the WebUtil Java root path with the implementation class name stored for the given package identifier.
- Step 2 - Return the resulting fully qualified class name to the caller.

---
**Decision Points**

No decision points - single execution path.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The implementation class name is stored in an internal array indexed by the package identifier; the Java root path is prepended to produce the fully qualified class name.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-046 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. The function delegates to the underlying JNI layer to call the native Java method getLastError on the supplied object instance, returning an integer error code that the caller (WEBUTIL.SETDATA) can inspect to determine whether a preceding file-transfer operation completed successfully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) as the target of the method call.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the Java instance method getLastError on the supplied obj via JNI.CALL_INT_METHOD, targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader class with method signature ()I (no parameters, returns int).
- Step 4 - Return the integer error code obtained from the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to JNI.CALL_INT_METHOD, returning whatever integer value the Java method produces.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be reset to NULL before invoking the JNI call to prevent unintended arguments from being forwarded to the Java method.
- BR-002 - The target Java class is fixed as oracle/forms/webutil/fileTransfer/AppServerFileReader and the method signature is ()I; no variation in class or signature is permitted.
- BR-003 - The function returns the raw integer error code as reported by the Java layer without transformation; interpretation of the code is the responsibility of the calling routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-047 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates to the JNI layer to invoke the native Java method and returns the error argument details as a VARCHAR2 string, enabling the caller (WEBUTIL.SETDATA) to interrogate error context following a failed file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents the active AppServerFileReader instance on which the last error occurred.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java instance method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing the object reference, the fully-qualified class name, the method name, and its JNI signature '()Ljava/lang/String;'.
- Step 4 - Return the VARCHAR2 string produced by the JNI call to the caller, representing the error argument details from the last error recorded by the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single deterministic JNI method invocation and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args local variable must be set to NULL before the JNI call to prevent stale argument data from a previous invocation from being passed to the Java method.
- BR-002 - The target Java method must be resolved against the fully-qualified class oracle/forms/webutil/fileTransfer/AppServerFileReader using the exact JNI method signature '()Ljava/lang/String;'; any deviation would cause the JNI call to fail.
- BR-003 - The function operates solely on the Java object instance supplied by the caller; it does not perform any database reads or writes, and it does not maintain its own state between calls.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-048 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified position and returns its value as a NUMBER. The procedure delegates string extraction to WEBUTIL.GETSTRING and applies a TO_NUMBER conversion to the result, providing callers with a strongly-typed numeric value without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-052](#SP-052--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position, an optional flag indicating whether the final field in the string is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Invoke WEBUTIL.GETSTRING, passing all four arguments unchanged, to extract the raw VARCHAR2 token located at the specified field position within the delimited source string.
- Step 3 - Apply the Oracle built-in TO_NUMBER function to the VARCHAR2 token returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No conditional decision points exist within this function. All branching logic related to field extraction (e.g., handling of unterminated fields, delimiter matching, and position resolution) is fully delegated to WEBUTIL.GETSTRING. WEBUTIL.GETNUMBER itself executes a single, unconditional conversion and return.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field extraction logic is entirely governed by WEBUTIL.GETSTRING; WEBUTIL.GETNUMBER does not duplicate or override any parsing behaviour.
- BR-002 - The delimiter parameter defaults to a comma (',') when not supplied by the caller, consistent with the default applied by WEBUTIL.GETSTRING.
- BR-003 - The UnTerminated parameter defaults to FALSE when not supplied, indicating that the source string is expected to be fully terminated; this default is passed through to WEBUTIL.GETSTRING without modification.
- BR-004 - The extracted field value must be implicitly convertible to a NUMBER by the Oracle TO_NUMBER function; if the token returned by WEBUTIL.GETSTRING is non-numeric, a runtime conversion error will be raised.
- BR-005 - No database interactions are performed; the function operates entirely in memory on the supplied string arguments.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-049 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the provided OS name string. The function maps the raw OS name to a predefined platform constant (e.g., WIN32, MAC, LINUX, SOLARIS, HP, AIX) and stores the result in the module-level variable m_clientOSFamily for reuse across subsequent calls, avoiding redundant re-evaluation. It is invoked during bean registration to establish the client platform context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing it in the local variable l_osName to enable case-insensitive comparison.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all classification logic and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If m_clientOSFamily is null, evaluate whether l_osName contains the substring 'windows'; if true, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If the Windows check is false, evaluate whether l_osName contains 'mac'; if true, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If the Mac check is false, evaluate whether l_osName contains 'linux'; if true, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If the Linux check is false, evaluate whether l_osName contains 'solaris' or 'sunos'; if either is true, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If the Solaris check is false, evaluate whether l_osName contains 'hp-ux'; if true, set result to CLIENT_PLATFORM_HP.
- Step 9 - If the HP-UX check is false, evaluate whether l_osName contains 'aix'; if true, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, persisting it for future calls.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name classification logic (DP-002 through DP-007) to determine the platform family, then cache and return the result.

FALSE: Skip all classification logic and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Proceed to DP-003.

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Proceed to DP-004.

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Proceed to DP-005.

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Proceed to DP-006.

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Proceed to DP-007.

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN (no recognised OS pattern matched).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is performed in a case-insensitive manner; the input osName is converted to lowercase before any substring matching is applied.
- BR-002 - Platform classification is mutually exclusive and evaluated in strict priority order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX; the first matching condition wins and no further checks are performed.
- BR-003 - If the provided OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform family.
- BR-004 - Solaris platform detection covers both the 'solaris' and 'sunos' substrings, treating them as equivalent identifiers for the same platform family.
- BR-005 - The resolved platform family is cached in the module-level variable m_clientOSFamily after the first successful evaluation; subsequent calls return the cached value without re-evaluating the OS name, ensuring the platform family is determined only once per session context.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-050 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output from a host process by repeatedly polling the WebUtil client-side bean for buffered output associated with the given process handle and output property. The function accumulates each returned line into an array and returns the complete output collection to the caller (WEBUTIL.GET_STANDARD_OUTPUT).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-059](#SP-059--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the WebUtil Core layer by executing the package initialisation block, which calls WebUtil_Core.Init to ensure the Core bean is instantiated before any property interactions occur.
- Step 2 - Set the process context on the WebUtil Core package by writing the process handle (process.handle) to the WUH_PROC_ID property of WUH_PACKAGE, identifying which host process output is to be retrieved.
- Step 3 - Enter a polling loop: call WebUtil_Core.getProperty for WUH_PACKAGE using the caller-supplied property name (prop) to retrieve the next buffered output line.
- Step 4 - Inspect the first character of the returned buffer as a status indicator: 'Y' signals that more lines follow, 'N' signals this is the last line, and 'X' signals the buffer was empty.
- Step 5 - If the status is not 'X' (i.e., a line is present), strip the status character and store the remaining text as the next element in the output array, then increment the array index.
- Step 6 - Exit the loop when the status is not 'Y' (i.e., the last line has been read or the buffer was empty), terminating the polling cycle.
- Step 7 - Return the populated output array to the caller.
- Step 8 - If the WebUtil bean is not registered, catch the BEAN_NOT_REGISTERED exception and display an error alert identifying the missing bean class, preventing silent failure.

---
**Decision Points**

DP-001

Condition: Status character extracted from the buffer is not 'X'.

TRUE: The buffer contains a valid output line; strip the status character, append the remaining text to the output array, and increment the index.

FALSE: The buffer is empty; do not add any entry to the output array.

DP-002

Condition: Status character extracted from the buffer is not 'Y' (evaluated as the loop-exit condition).

TRUE: No further lines are pending (status is 'N' - last line - or 'X' - empty buffer); exit the polling loop and return the accumulated array.

FALSE: Status is 'Y', indicating additional output lines remain; continue the polling loop to retrieve the next line.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be set on the WebUtil Core package (WUH_PROC_ID) before any output retrieval is attempted, ensuring all subsequent property reads are scoped to the correct host process.
- BR-002 - Each polled buffer value is interpreted by its leading status character: 'Y' means more lines follow, 'N' means this is the final line, and 'X' means no data is present; only 'Y' and 'N' statuses result in a line being stored.
- BR-003 - Output lines are stored in the array with the single-character status prefix removed; only the content from the second character onward is recorded.
- BR-004 - If the WebUtil bean required by this function is not registered on the client, the function must raise an error alert identifying the missing bean class and must not return partial or misleading output.
- BR-005 - WebUtil_Core.Init must be executed at package initialisation to guarantee the Core layer is available before GetOutput or any other package function is called.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-051 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.EXECUTE]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named system property from the Java runtime environment. Used internally by the WebUtil framework to query Java system properties via the JNI bridge.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - An argument list is created with one argument (the property name).
- Step 2 - The property name is added as a string argument to the argument list.
- Step 3 - The JNI bridge is called to invoke the Java System.getProperty method, passing the property name.
- Step 4 - The retrieved property value is returned to the caller.

---
**Decision Points**

No decision points - single execution path.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property value is retrieved from the Java system properties via the JNI bridge; no Oracle database lookup is performed.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-052 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited field from a source string by position. Given a delimiter-separated string, a target field position, and an optional delimiter character, the function returns the substring occupying that positional slot. It is used internally by WEBUTIL.GETNUMBER to isolate individual tokens from a composite string value.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the 1-based field position to extract, a Boolean flag indicating whether the string lacks a trailing delimiter (UnTerminated), and the delimiter character (defaulting to comma).
- Step 2 - Copy the source string into a working variable (vcSourceStrCopy) to avoid modifying the original input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the working copy so that the last field is bounded and can be located consistently using INSTR.
- Step 4 - Determine the start pointer (iPtrStart): if Field_Position is greater than 1, locate the delimiter occurrence immediately before the target field (occurrence Field_Position-1) and advance past it by adding the length of the delimiter; otherwise set iPtrStart to 1 (the beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the delimiter at occurrence Field_Position within the working copy.
- Step 6 - Return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which isolates the requested field value without including the surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string, ensuring the final field is properly terminated and can be located by INSTR.

FALSE: The source string is used as-is; no modification is made to the working copy before parsing begins.

---

DP-002

Condition: Field_Position is greater than 1.

TRUE: iPtrStart is calculated by finding the (Field_Position-1)th occurrence of the delimiter and advancing past it by the length of the delimiter, positioning the pointer at the first character of the target field.

FALSE: iPtrStart is set to 1, meaning extraction begins at the very start of the string (first field).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function treats field positions as 1-based; a Field_Position value of 1 always refers to the content before the first delimiter occurrence.
- BR-002 - If the source string does not end with a delimiter and the caller knows this, UnTerminated must be passed as TRUE so that the function appends the delimiter internally, ensuring the last field is extractable without special-case logic.
- BR-003 - The delimiter defaults to a comma if not explicitly supplied; any single- or multi-character delimiter passed by the caller is supported, and its full length is accounted for when calculating iPtrStart.
- BR-004 - The function returns no output parameters; the extracted field value is returned solely as the function's return value (VARCHAR2).
- BR-005 - No database interactions occur; all processing is performed entirely in memory against the supplied string.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-053 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named configuration variable from the client environment by applying a platform-specific lookup strategy. On Windows clients the procedure first queries the Oracle registry key (HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE) and falls back to the Windows environment string if no registry value is found. On Unix/Linux clients it executes the 'env' command, parses its output, and extracts the matching variable. Mac OS and unknown platforms are explicitly excluded from any lookup, returning no value.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-085](#SP-085--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-088](#SP-088--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-043](#SP-043--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-056](#SP-056--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Determine the client operating system family by calling WEBUTIL.GETCLIENTOSFAMILY.
- Step 2 - If the client is Windows (CLIENT_PLATFORM_WIN32), attempt to read the named variable from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY, passing the supplied VARNAME and requesting a non-expanded value.
- Step 3 - If the registry lookup returns NULL or an empty string, fall back to reading the named variable from the Windows environment using GET_ENVIRONMENT_STRING, passing VARNAME.
- Step 4 - If the client is Mac OS (CLIENT_PLATFORM_MAC) or an unrecognised platform (CLIENT_PLATFORM_UNKNOWN), take no action and leave VARVALUE unchanged.
- Step 5 - If the client is any other platform (Unix/Linux), execute the operating-system 'env' command in blocking mode to capture all environment variables.
- Step 6 - Retrieve the standard output of the 'env' process using WEBUTIL.GET_STANDARD_OUTPUT and release the process handle.
- Step 7 - Iterate over each line of the captured output; for each line locate the '=' delimiter, extract the key portion, and compare it to VARNAME.
- Step 8 - When a matching key is found, extract the value portion (text after '=') into VARVALUE and exit the loop immediately.
- Step 9 - If a NO_DATA_FOUND exception is raised at any point during execution, set VARVALUE to NULL and allow processing to complete gracefully.

---
**Decision Points**

DP-001

Condition: Client OS family equals CLIENT_PLATFORM_WIN32.

TRUE: Attempt to retrieve the variable value from the Windows registry under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE using READ_REGISTRY.
FALSE: Proceed to DP-002.

DP-002

Condition: Registry value returned by READ_REGISTRY is NULL or empty string (Windows path only).

TRUE: Fall back to retrieving the variable value from the Windows environment using GET_ENVIRONMENT_STRING.
FALSE: Use the registry value already retrieved as VARVALUE; no further lookup is performed.

DP-003

Condition: Client OS family equals CLIENT_PLATFORM_MAC or CLIENT_PLATFORM_UNKNOWN.

TRUE: Perform no lookup; VARVALUE remains unchanged (effectively NULL or its prior value).
FALSE: Treat the client as a Unix/Linux platform and proceed to the 'env' command path (DP-004).

DP-004

Condition: A '=' delimiter is found at a positive position within the current 'env' output line.

TRUE: Extract the key (text before '=') and compare it to VARNAME; if equal, extract the value (text after '=') into VARVALUE and exit the loop.
FALSE: Skip the current line and continue iterating.

DP-005

Condition: The extracted key from the current 'env' output line equals VARNAME.

TRUE: Assign the substring after '=' to VARVALUE and exit the loop immediately.
FALSE: Continue to the next line in the output array.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - On Windows clients, the Oracle registry path HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE is always the primary source for variable resolution; the Windows environment is only consulted when the registry yields no value.
- BR-002 - On Windows clients, a NULL result and an empty-string result from the registry lookup are treated equivalently, both triggering the environment-string fallback.
- BR-003 - Mac OS and unrecognised client platforms are explicitly unsupported; no variable resolution is attempted and VARVALUE is not populated for these platforms.
- BR-004 - On Unix/Linux clients, variable resolution is performed exclusively by parsing the full output of the 'env' command; no registry or direct API call is used.
- BR-005 - On Unix/Linux clients, only the first matching environment variable name terminates the search; the loop exits immediately upon the first match, ensuring the first occurrence takes precedence.
- BR-006 - Lines in the Unix 'env' output that do not contain a '=' character are silently ignored and do not affect the result.
- BR-007 - A NO_DATA_FOUND exception anywhere in the procedure results in VARVALUE being set to NULL, preventing unhandled errors from propagating to the caller.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-054 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure uses the WebUtil PJC (Pluggable Java Component) bridge to retrieve the next available line from the file identified by the supplied file handle, enabling Oracle Forms to consume client-side flat-file content line by line during operations such as Excel report generation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file handle (file_type) that identifies the open client-side text file to be read.
- Step 2 - Pass the file handle to the WebUtil PJC by setting the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the next line of text from the client file by calling WebUtil_Core.getProperty with the WUF_TEXTIO_GETLINE property key; the result is stored in a local VARCHAR2 buffer (up to 4 000 characters).
- Step 4 - Inspect the buffer value: if it equals CHR(10) (a newline character), treat this as the end-of-file sentinel placed by the PJC exception handler and raise NO_DATA_FOUND to signal that no further data is available.
- Step 5 - If the buffer does not equal CHR(10), assign the buffer content to the OUT parameter 'item' and return it to the caller.
- Step 6 - If the WebUtil bean is not registered on the client, display an error alert identifying the missing implementation class and raise TOOL_ERROR to halt processing.
- Step 7 - If a property error occurs during the PJC interaction, raise TOOL_ERROR to halt processing.

---
**Decision Points**

DP-001

Condition: The value returned in the buffer by WebUtil_Core.getProperty equals CHR(10) (newline character).

TRUE: The end-of-file sentinel has been detected; NO_DATA_FOUND is raised to inform the caller that there are no more lines to read.

FALSE: The buffer contains a valid line of text; the buffer value is assigned to the OUT parameter 'item' and returned to the caller.

---

DP-002

Condition: A WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the PJC property interaction.

TRUE: An error alert is displayed identifying the missing WebUtil bean class, and TOOL_ERROR is raised to terminate processing.

FALSE: Processing continues normally; no alert is displayed for this condition.

---

DP-003

Condition: A WebUtil_Core.PROPERTY_ERROR exception is raised during the PJC property interaction.

TRUE: TOOL_ERROR is raised immediately to terminate processing.

FALSE: Processing continues normally; no error is raised for this condition.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A CHR(10) (newline) value returned by the WebUtil PJC is exclusively reserved as the end-of-file sentinel; it is never treated as valid line content, because the PJC uses it to distinguish end-of-file from an empty line.
- BR-002 - The maximum length of a single line that can be read from the client file is 4 000 characters, as defined by the internal buffer size.
- BR-003 - If the required WebUtil bean is not registered on the client, the procedure must alert the user with the missing bean's implementation class name before raising a fatal TOOL_ERROR; silent failure is not permitted.
- BR-004 - Any property-level error returned by the WebUtil PJC must result in an immediate TOOL_ERROR being raised; partial or incomplete line data must not be returned to the caller.
- BR-005 - The file handle supplied to the procedure must already be open; this procedure performs no file-open or file-close operations.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-055 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the integer return code produced by a previously executed host process. Given a PROCESS_ID handle, the function communicates with the WebUtil client-side bean to obtain the exit/return code of that process and returns it as a PLS_INTEGER to the caller (WEBUTIL.HOST).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID of the host process whose return code is to be retrieved.
- Step 2 - Set the process handle on the WebUtil bean by calling WebUtil_Core.setProperty, passing the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the process handle value (process.handle).
- Step 3 - Read the return code from the WebUtil bean by calling WebUtil_Core.getProperty with the WUH_PACKAGE constant and the property key 'WUH_RC', converting the result to a number.
- Step 4 - Return the numeric return code as a PLS_INTEGER to the caller.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any bean interaction, display an error alert via WebUtil_Core.ErrorAlert indicating that the required WebUtil bean class (resolved via WebUtil_Core.getImplClass) was not found and that Get_Return_Code will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to set or get properties on the WebUtil bean.

TRUE: Display an error alert identifying the missing bean class and informing the user that WEBUTIL_HOST.Get_Return_Code will not work; function exits without returning a value.

FALSE: The bean interaction succeeds; the numeric return code is returned to the caller as a PLS_INTEGER.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function requires a valid PROCESS_ID (containing a non-null handle) to correctly identify the target host process when communicating with the WebUtil bean.
- BR-002 - The WebUtil client-side bean corresponding to WUH_PACKAGE must be registered and available at runtime; if it is not, the function cannot retrieve the return code and must raise an error alert instead of returning a value.
- BR-003 - The return code is read from the bean property 'WUH_RC' after first setting the process context via property 'WUH_PROC_ID'; both property interactions must succeed for a valid result to be returned.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-056 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (STDOUT) stream captured from a previously executed host process. It acts as a named convenience wrapper that calls WEBUTIL.GETOUTPUT with the fixed stream identifier 'WUH_STDOUT', returning the collected output lines as an OUTPUT_ARRAY for the invoking routine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-050](#SP-050--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the PROCESS_ID of the host process whose standard output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-050), passing the supplied PROCESS_ID and the hard-coded stream identifier 'WUH_STDOUT'.
- Step 3 - Return the OUTPUT_ARRAY produced by WEBUTIL.GETOUTPUT directly to the caller.

---
**Decision Points**

No conditional decision points exist in this procedure. The function unconditionally delegates to WEBUTIL.GETOUTPUT with the fixed stream identifier 'WUH_STDOUT' and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve output is always 'WUH_STDOUT'; this procedure is exclusively concerned with the standard output stream and does not retrieve any other stream type.
- BR-002 - The caller must supply a valid PROCESS_ID; the function passes it unmodified to WEBUTIL.GETOUTPUT (SP-050), which is solely responsible for resolving and returning the output data.
- BR-003 - No transformation or filtering is applied to the OUTPUT_ARRAY; the result returned to the caller is exactly what WEBUTIL.GETOUTPUT provides.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-057 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command synchronously on the client machine and returns the process exit/return code to the caller. It is invoked by VIEW_EXCEL_REPORT_NEW to launch external processes (e.g., opening an Excel report file) from within Oracle Forms via the WebUtil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-028](#SP-028--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-055](#SP-055--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-072](#SP-072--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the host command string (cmd) to be executed on the client.
- Step 2 - Invoke WEBUTIL.BLOCKING to launch the command on the client and block until the process completes, returning a PROCESS_ID handle.
- Step 3 - Check whether the returned PROCESS_ID is null using WEBUTIL.ID_NULL to determine if the process was successfully created.
- Step 4 - If the process ID is valid (not null), call WEBUTIL.GET_RETURN_CODE with the process handle to retrieve the integer exit/return code produced by the completed process.
- Step 5 - Release the client-side process object by calling WEBUTIL.RELEASE_PROCESS to free associated resources.
- Step 6 - Return the captured return code (RC) to the caller; if the process was never created, return the default value of -1.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(procId) evaluates to TRUE - the process ID returned by WEBUTIL.BLOCKING is null, indicating the host command failed to launch.

TRUE: Skip retrieval of the return code and release of the process; return the default return code of -1 to signal failure.

FALSE: Proceed to retrieve the process return code via WEBUTIL.GET_RETURN_CODE and release the process handle via WEBUTIL.RELEASE_PROCESS, then return the actual exit code.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The host command must be executed in blocking mode; the function waits for the client-side process to complete before retrieving its result, ensuring the return code reflects the final process outcome.
- BR-002 - A default return code of -1 is used to represent a failed or unlaunched process; any value other than -1 indicates the process was created and its actual exit code was captured.
- BR-003 - Client-side process resources must always be released via WEBUTIL.RELEASE_PROCESS after a successful process creation, regardless of the return code value, to prevent resource leaks on the client machine.
- BR-004 - The return code retrieved from the completed process is passed back unchanged to the caller, preserving the native exit status for upstream logic (e.g., VIEW_EXCEL_REPORT_NEW) to interpret.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-058 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Checks whether a WebUtil object handle is null (uninitialised). Returns TRUE if the handle's internal reference is null, FALSE otherwise. Used throughout the WebUtil framework to guard against operations on uninitialised component handles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The internal handle reference (handle.hnd) is evaluated.
- Step 2 - If the internal reference is null, TRUE is returned to indicate the handle is uninitialised.
- Step 3 - If the internal reference is not null, FALSE is returned to indicate the handle is valid.

---
**Decision Points**

DP-001

Condition: The internal handle reference (handle.hnd) is null.

TRUE: Returns TRUE - the handle is uninitialised (null).

FALSE: Returns FALSE - the handle references a valid object.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Callers must check the return value before using a WebUtil handle to avoid operating on an uninitialised object reference.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-059 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT serves as the package-level entry point for the WebUtil core utility. Its sole responsibility is to trigger the package initialisation block, which automatically invokes WEBUTIL.INITWEBUTIL to set up the WebUtil environment. The procedure body itself performs no additional processing; entering the package is sufficient to complete initialisation.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-060](#SP-060--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - WEBUTIL.INIT is called by WEBUTIL.GETOUTPUT to ensure the WebUtil core package is initialised before any utility operations are performed.
- Step 2 - The procedure body executes a NULL statement, performing no direct processing, as entering the package scope is sufficient to trigger initialisation.
- Step 3 - The package-level BEGIN block executes automatically upon first entry into the package, calling WEBUTIL.INITWEBUTIL (SP-060) to complete the WebUtil environment setup.

---
**Decision Points**

No decision points exist within this procedure. The procedure body contains only a NULL statement and delegates all initialisation logic unconditionally to the package-level BEGIN block via WEBUTIL.INITWEBUTIL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Entering the WEBUTIL package is sufficient to trigger initialisation; no explicit setup logic is required within the INIT procedure body itself.
- BR-002 - WEBUTIL.INITWEBUTIL must be called as part of the package initialisation block to establish the WebUtil environment before any dependent utility operations can execute.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-060 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework within an Oracle Form session. The procedure registers the Java implementation classes for all known WebUtil packages, verifies that the mandatory WebUtil object group (including its error alert and dummy item) is present in the calling form, optionally navigates to the WebUtil bean area to force bean instantiation, and determines the server-side file-path separator based on the operating system. It must be called once, via WEBUTIL.INIT, before any other WebUtil functionality is used.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-076](#SP-076--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) for later use.
- Step 2 - Populate the m_implClasses associative array by mapping each WebUtil package constant (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to its corresponding Java implementation class name, establishing the full set of available WebUtil capabilities.
- Step 3 - Check whether the WebUtil error alert (m_errorAlert) exists in the form by calling WEBUTIL.ID_NULL. If the alert is absent, display an error message stating that the WEBUTIL object group is not available and halt execution with PAUSE; no further initialisation is performed.
- Step 4 - If the error alert is present and the FLAG_EXPICIT_INSTANCIATE flag is enabled and the form is in NORMAL mode, attempt explicit bean instantiation: locate the dummy item via WEBUTIL.ID_NULL and, if found, navigate to it with GO_ITEM.
- Step 5 - After navigating to the dummy item, compare its block with the block of the original cursor field. If they are the same block, call NEXT_BLOCK to move focus away; otherwise, return focus to the original cursor field with GO_ITEM(startPoint).
- Step 6 - Call WEBUTIL.SHOWBEANS(false) to render the bean areas without making them visible to the end user, completing the explicit instantiation path.
- Step 7 - If the dummy item is not found (WEBUTIL.ID_NULL returns true), take no action, assuming the developer manages bean setup independently.
- Step 8 - Determine the server operating system by inspecting GET_APPLICATION_PROPERTY(OPERATING_SYSTEM). If the OS name contains 'WIN' (case-insensitive), set the server file-path separator (m_serverFileSep) to backslash; otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition: WEBUTIL.ID_NULL(m_errorAlert) is TRUE - the WebUtil error alert object is not present in the current form.

TRUE: Display the message 'The WEBUTIL object group is not available in this Form. WebUtil cannot work', execute PAUSE, and exit without completing any further initialisation.

FALSE: The WebUtil object group is confirmed present; proceed with optional bean instantiation and OS detection (DP-002 onwards).

---

DP-002

Condition: FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE: Attempt explicit bean instantiation by evaluating the dummy item (DP-003).

FALSE: Skip explicit bean instantiation entirely; proceed directly to server OS detection (Step 8).

---

DP-003

Condition: WEBUTIL.ID_NULL(hDummy) is FALSE - the standard WebUtil dummy item exists in the form.

TRUE: Navigate to the dummy item, resolve block context (DP-004), and call WEBUTIL.SHOWBEANS(false).

FALSE: Take no action; the developer is assumed to manage bean area setup independently.

---

DP-004

Condition: The BLOCK_NAME of the original cursor field equals the BLOCK_NAME of the dummy item.

TRUE: Call NEXT_BLOCK to move focus out of the shared block, preventing focus from remaining on the dummy item's block.

FALSE: Return focus to the original cursor field by calling GO_ITEM(startPoint).

---

DP-005

Condition: INSTR(UPPER(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)), 'WIN') > 0 - the server operating system name contains 'WIN'.

TRUE: Set m_serverFileSep to '\' (Windows backslash separator).

FALSE: Set m_serverFileSep to '/' (Unix/Linux forward slash separator).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert (m_errorAlert), must be present in the calling form before WebUtil can be initialised; absence of the error alert is treated as a fatal configuration error and processing is halted.
- BR-002 - Explicit bean instantiation (navigation to the dummy item and invocation of WEBUTIL.SHOWBEANS) is performed only when both the FLAG_EXPICIT_INSTANCIATE flag is enabled and the form is in NORMAL mode, preventing navigation conflicts in Enter-Query mode.
- BR-003 - When explicit instantiation is performed and the dummy item resides in the same block as the original cursor position, the procedure must navigate to a different block (NEXT_BLOCK) to avoid leaving focus on the bean block; otherwise focus is restored to the original cursor field.
- BR-004 - If the dummy item is not found in the form, the procedure takes no corrective action, delegating full responsibility for bean area setup to the developer.
- BR-005 - The server file-path separator (m_serverFileSep) is derived solely from the server operating system reported by GET_APPLICATION_PROPERTY(OPERATING_SYSTEM); a Windows OS sets the separator to '\', and all other operating systems default to '/'.
- BR-006 - All ten WebUtil package-to-Java-class mappings must be registered in m_implClasses during every initialisation call, regardless of which WebUtil packages the form subsequently uses.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-061 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns a Boolean indicator of whether the most recent WebUtil operation resulted in an error. It evaluates the internal module-level variable `m_lastError` and signals TRUE if a non-zero error code is held, allowing callers such as WEBUTIL.LOG to branch on error state without directly inspecting the error variable.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the current value of the module-level variable `m_lastError`, which holds the error code set by the most recently executed WebUtil operation.
- Step 2 - Compare `m_lastError` against zero to determine whether an error condition is active.
- Step 3 - Return TRUE if `m_lastError` is not equal to zero (an error exists), or FALSE if `m_lastError` equals zero (no error).

---
**Decision Points**

DP-001

Condition: `m_lastError <> 0`

TRUE: The function returns TRUE, indicating that the last WebUtil operation recorded a non-zero error code and an error condition is present.

FALSE: The function returns FALSE, indicating that `m_lastError` is zero and no error condition is currently recorded.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-zero value in `m_lastError` is the sole criterion for classifying the last WebUtil operation as having failed; any non-zero code, regardless of its specific value, is treated as an error.
- BR-002 - The function is read-only; it does not modify `m_lastError` or any other state, ensuring that calling ISERROR has no side effects on the error condition being evaluated.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-062 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied FILE_TYPE record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to verify file state before attempting file operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FILE_TYPE record passed by the caller as an IN parameter.
- Step 2 - Inspect the handle attribute of the FILE_TYPE record to determine whether it holds a value.
- Step 3 - If the handle attribute is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle attribute is NOT NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition: file.handle IS NULL

TRUE: The function returns FALSE, signalling to the caller that the file is not currently open.

FALSE: The function returns TRUE, signalling to the caller that the file is currently open.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A FILE_TYPE record is considered open if and only if its handle attribute is NOT NULL; a NULL handle unconditionally indicates a closed or uninitialised file.
- BR-002 - The function performs a read-only inspection of the FILE_TYPE record and does not alter file state or the record itself.
- BR-003 - The function returns a BOOLEAN result; callers must evaluate this return value to determine whether it is safe to proceed with file operations.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-063 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- SP_SOQ_POPULATE_CONSUMPTION.prc [StoredProcedure: SP_SOQ_POPULATE_CONSUMPTION]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the file size (in bytes) of a Java File object via the JNI bridge. Used internally by the WebUtil framework to determine the length of a file on the client workstation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The JNI bridge is called with no arguments to invoke the Java File.length() method on the supplied file object.
- Step 2 - The resulting file length (as a long integer) is returned to the caller as a NUMBER.

---
**Decision Points**

No decision points - single execution path.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file length is retrieved from the Java runtime via JNI; the result represents the file size in bytes as returned by java.io.File.length().

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-064 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.LOG writes diagnostic and error messages to a server-side log file on behalf of the WebUtil framework. On its first invocation it reads logging configuration from the property bundle (enabled flag, errors-only flag, and target file path), caches those settings for the session, and communicates the active logging mode to the registered WebUtil bean. On subsequent calls it appends the supplied message-optionally prefixed with the client IP address and username-to the configured log file, subject to the cached mode settings.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-036](#SP-036--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-061](#SP-061--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-062](#SP-062--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-067](#SP-067--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-068](#SP-068--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Read the three logging configuration properties from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE: 'logging.enabled' (mapped to m_loggingAllowed), 'logging.errorsonly' (mapped to m_loggingErrorsOnly), and 'logging.file' (mapped to m_loggingFile).
- Step 3 - If logging is enabled but no log file path was returned, disable logging (m_loggingAllowed := FALSE). If no WebUtil bean is registered yet, surface error WUC-008 via WEBUTIL.ERRORALERT; otherwise push the disabled state ('WUC_SRV_LOGGING' = '0') to the bean and raise error 8 through WebUtil_Core.
- Step 4 - If at least one WebUtil bean is registered, communicate the resolved logging mode to the bean: errors-only mode sets 'WUC_SRV_LOGGING' to '1'; full logging sets it to '2'; disabled sets it to '0'.
- Step 5 - Evaluate whether the current call is eligible for writing: logging must be allowed (m_loggingAllowed = TRUE) and either errors-only mode is off, or errors-only mode is on and the isError parameter is TRUE.
- Step 6 - Open the log file in append mode using TEXT_IO.FOPEN. If the file cannot be opened (TEXT_IO.IS_OPEN returns FALSE), raise NO_DATA_FOUND.
- Step 7 - Write the message to the log file via TEXT_IO.PUT_LINE. If m_clientIP is populated, prefix the message with the client IP address and username; otherwise write the message as supplied.
- Step 8 - Close the log file with TEXT_IO.FCLOSE.
- Step 9 - If an exception is raised and SQLCODE equals -302000 (file write failure), disable logging (m_loggingAllowed := FALSE) and report error WUC-007: if no bean is registered, call WEBUTIL.ERRORALERT; otherwise push 'WUC_SRV_LOGGING' = '0' to the bean and raise error 7 through WebUtil_Core. All other exceptions are re-raised.

---
**Decision Points**

DP-001
Condition: m_loggingAllowed IS NULL (logging configuration has not yet been cached for this session).
TRUE: Read configuration from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the session-level cache variables.
FALSE: Skip configuration initialisation and proceed directly to the write eligibility check.

DP-002
Condition: Logging is enabled (m_loggingAllowed = TRUE) AND the log file path (m_loggingFile) is NULL.
TRUE: Set m_loggingAllowed to FALSE and report error WUC-008 (no log file specified).
FALSE: Retain the enabled state and continue.

DP-003
Condition: At least one WebUtil bean is registered (m_registeredPackages.FIRST IS NOT NULL) at the point of reporting the missing-file error.
TRUE: Push 'WUC_SRV_LOGGING' = '0' to the bean and raise error 8 via WebUtil_Core.
FALSE: Surface error WUC-008 directly to the user via WEBUTIL.ERRORALERT.

DP-004
Condition: At least one WebUtil bean is registered after the full configuration cache has been built.
TRUE: Communicate the resolved logging mode ('0', '1', or '2') to the bean via WebUtil_Core.setProperty.
FALSE: Skip bean notification.

DP-005
Condition: m_loggingAllowed = TRUE AND (m_loggingErrorsOnly = FALSE OR (m_loggingErrorsOnly = TRUE AND isError = TRUE)).
TRUE: Proceed to open the log file and write the message.
FALSE: Take no action; the message is silently discarded.

DP-006
Condition: TEXT_IO.IS_OPEN returns FALSE after attempting to open the log file.
TRUE: Raise NO_DATA_FOUND, which is handled by the exception block.
FALSE: Continue to write the message.

DP-007
Condition: m_clientIP IS NULL at the time of writing.
TRUE: Write the message text alone to the log file.
FALSE: Prefix the message with the client IP address and username before writing.

DP-008
Condition: An exception is caught and SQLCODE = -302000 (file write error).
TRUE: Disable logging, report error WUC-007 (via WEBUTIL.ERRORALERT if no bean is registered, or via WebUtil_Core if a bean is registered), and suppress the exception.
FALSE: Re-raise the exception to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and log file path) is read from the property bundle exactly once per session; the resolved values are cached in package-level variables and reused on all subsequent calls.
- BR-002 - If logging is enabled but no log file path is configured, logging must be disabled immediately and error WUC-008 must be reported; the absence of a file path is treated as an invalid configuration that prevents any logging activity.
- BR-003 - When errors-only mode is active, only calls where isError = TRUE result in a log entry; informational messages are silently discarded.
- BR-004 - Log entries for sessions where a client IP address is available must be prefixed with the client IP address and username to ensure traceability of the originating client.
- BR-005 - The log file must be opened in append mode on every write operation and closed immediately after the write, ensuring that concurrent or sequential calls do not corrupt or truncate existing log content.
- BR-006 - A file write failure (SQLCODE -302000) must disable logging for the remainder of the session (m_loggingAllowed := FALSE) and report error WUC-007; this prevents repeated failed write attempts.
- BR-007 - The active logging mode must be communicated to the registered WebUtil bean as a numeric property ('0' = disabled, '1' = errors only, '2' = full logging) whenever at least one bean is registered at configuration time.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-065 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value property pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The procedure resolves the configuration file path from three sources in priority order: a Forms global variable, an environment variable, and a Forms parameter. It is invoked by WEBUTIL.READFROMPROPERTYBUNDLE to support property-driven WebUtil configuration at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-036](#SP-036--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global is unset ('[NOTSET]'), set it to null and proceed to the next resolution source.
- Step 2 - If the global variable did not yield a path, attempt to retrieve the configuration file path from the operating-system environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also did not yield a path, attempt to retrieve the configuration file path from the Forms parameter identified by WEBUTIL_CONFIG_PARAM; if this too is null, raise NO_DATA_FOUND to trigger error handling.
- Step 4 - Persist the resolved configuration file path back into the Forms global variable WEBUTIL_CONFIG_GLOBAL so that subsequent calls do not need to re-resolve the path.
- Step 5 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 6 - Read the file line by line in a loop using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 7 - For each line read, skip it if its first character is '#' (comment line).
- Step 8 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that do not contain '='
- Step 9 - For lines containing '=', increment the property index, then store the trimmed, lower-cased left-hand side as the property key and the trimmed, carriage-return-stripped right-hand side as the property value in the next slot of m_propertyBundle.
- Step 10 - Compare the stored property key (lower-case) against the lower-cased input parameter propertyKey; if they match, capture the corresponding value into the result variable.
- Step 11 - After the loop completes, close the configuration file using TEXT_IO.FCLOSE and return the result value (which is null if the key was not found).
- Step 12 - On NO_DATA_FOUND (configuration file path could not be resolved): if no WebUtil bean package is registered yet, call WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error; set m_config_error to true and return null.
- Step 13 - On SQLCODE -302000 (file cannot be read): if no WebUtil bean package is registered yet, call WEBUTIL.ERRORALERT to display error 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error; set m_config_error to true and return null. All other exceptions are re-raised.

---
**Decision Points**

DP-001
Condition: The Forms global variable WEBUTIL_CONFIG_GLOBAL contains a value other than '[NOTSET]'.
TRUE: Use the global variable value as the configuration file path; skip environment variable and Forms parameter resolution.
FALSE: Set the path to null and proceed to attempt resolution via the environment variable (DP-002).

DP-002
Condition: TOOL_ENV.GETVAR returns a non-null value for WEBUTIL_CONFIG_ENV.
TRUE: Use the environment variable value as the configuration file path; skip Forms parameter resolution.
FALSE: Proceed to attempt resolution via the Forms parameter WEBUTIL_CONFIG_PARAM (DP-003).

DP-003
Condition: The Forms parameter WEBUTIL_CONFIG_PARAM yields a non-null configuration file path.
TRUE: Use the Forms parameter value as the configuration file path.
FALSE: Raise NO_DATA_FOUND, triggering the error-handling branch.

DP-004
Condition: The first character of a line read from the configuration file is '#'.
TRUE: Skip the line entirely (treated as a comment).
FALSE: Proceed to check for a key-value delimiter (DP-005).

DP-005
Condition: The line contains an '=' character (INSTR returns a position greater than zero).
TRUE: Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches the requested propertyKey (DP-006).
FALSE: Skip the line (not a valid key-value pair).

DP-006
Condition: The lower-cased parsed property key equals the lower-cased input parameter propertyKey.
TRUE: Assign the corresponding property value to the result variable for return.
FALSE: Continue processing remaining lines without updating the result variable.

DP-007
Condition: A NO_DATA_FOUND or SQLCODE -302000 exception is raised, and m_registeredPackages.FIRST is null (no WebUtil bean package registered).
TRUE: Call WEBUTIL.ERRORALERT to display the appropriate English-language error message (WUC-005 or WUC-006), set m_config_error to true, and return null.
FALSE: Delegate error reporting to Webutil_Core.Error, set m_config_error to true, and return null.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from at least one of three sources in strict priority order: Forms global variable WEBUTIL_CONFIG_GLOBAL, operating-system environment variable WEBUTIL_CONFIG_ENV, or Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a value, the procedure treats this as a fatal configuration error.
- BR-002 - Once the configuration file path is successfully resolved, it must be written back to the Forms global variable WEBUTIL_CONFIG_GLOBAL to ensure consistent reuse across subsequent invocations without re-resolution.
- BR-003 - Lines in the configuration file that begin with '#' are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are treated as valid key-value pairs; lines without '=' are silently skipped.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed; property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped.
- BR-006 - When a configuration error occurs (file not specified or unreadable) and no WebUtil bean package is yet registered, the error must be surfaced to the user in English via WEBUTIL.ERRORALERT using the designated error codes WUC-005 or WUC-006 respectively.
- BR-007 - Upon any handled configuration error (WUC-005 or WUC-006), the module-level flag m_config_error must be set to true and the function must return null, preventing further property lookups from proceeding silently.
- BR-008 - Exceptions other than NO_DATA_FOUND and SQLCODE -302000 are not suppressed; they must be re-raised to allow upstream error handling to respond appropriately.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-066 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side text file by delegating the operation to the WebUtil client bean. The procedure sets the target file handle and the text argument as properties on the WebUtil core package, causing the bean to perform the actual write on the client machine. It is invoked as part of Excel report generation in VIEW_EXCEL_REPORT_NEW.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file reference (file_type handle) and the text string (arg) to be written.
- Step 2 - Pass the file handle to the WebUtil core layer by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_HANDLE property key, registering which open file is the write target.
- Step 3 - Pass the formatted text argument to the WebUtil core layer by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_PUTF property key, instructing the client bean to write the string to the registered file.
- Step 4 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 5 - If a property set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: The WebUtil client bean required by WUF_PACKAGE is registered and available on the client at the time of the setProperty calls.

TRUE: Both setProperty calls complete successfully; the formatted text string is written to the specified client-side file and the procedure exits normally.

FALSE: A BEAN_NOT_REGISTERED exception is raised; an error alert is displayed stating that the implementation class bean was not found and that CLIENT_TEXT_IO.putf will not work, after which TOOL_ERR.TOOL_ERROR is raised to terminate execution.

DP-002

Condition: The setProperty calls succeed without a property-level error (PROPERTY_ERROR).

TRUE: The write operation completes and the procedure exits normally.

FALSE: A PROPERTY_ERROR exception is raised; TOOL_ERR.TOOL_ERROR is raised immediately to terminate execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the file handle and the text argument must be supplied; the procedure signature accepts no optional parameters, and both are required for the WebUtil core property calls to function correctly.
- BR-002 - The WebUtil client bean for WUF_PACKAGE must be registered on the client before this procedure is called; if it is not, the write operation is entirely blocked and an error is surfaced to the user.
- BR-003 - Any failure during the property-set interaction with the WebUtil core layer (PROPERTY_ERROR) must immediately terminate the calling process by raising TOOL_ERR.TOOL_ERROR, ensuring that partial or failed writes do not go undetected.
- BR-004 - The procedure does not perform direct database interactions; all file I/O is executed on the client side through the WebUtil bean, consistent with the client-side file handling model used in Excel report generation.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-067 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil client bean. It is called by WEBUTIL.LOG to append log entries to a file on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file handle (file.handle extracted from the file_type parameter) and the text string (item) to be written.
- Step 2 - Set the WUF_TEXTIO_HANDLE property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, identifying which open client file will receive the output.
- Step 3 - Set the WUF_TEXTIO_PUT property on the WUF_PACKAGE bean via WebUtil_Core.setProperty, passing the text content (item) to be written to the file.
- Step 4 - Set the WUF_TEXTIO_NEWLINE property on the WUF_PACKAGE bean to 1 via WebUtil_Core.setProperty, instructing the bean to append a newline character after the written text.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any property-set call, display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 6 - If a PROPERTY_ERROR exception is raised during any property-set call, raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition: The WUF_PACKAGE bean is registered and all three WebUtil_Core.setProperty calls (handle, put, newline) complete without raising WebUtil_Core.BEAN_NOT_REGISTERED.

TRUE: The text line and newline are successfully transmitted to the client bean for writing; the procedure exits normally.

FALSE: A BEAN_NOT_REGISTERED exception is caught; an error alert is displayed identifying the missing implementation class, and TOOL_ERR.TOOL_ERROR is raised to abort the calling process.

DP-002

Condition: All three WebUtil_Core.setProperty calls complete without raising WebUtil_Core.PROPERTY_ERROR.

TRUE: Processing continues normally and the procedure exits without error.

FALSE: A PROPERTY_ERROR exception is caught; TOOL_ERR.TOOL_ERROR is raised immediately to abort the calling process.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the file handle and the text item must be supplied; the procedure passes them directly to the client bean without null-checking, so the caller (WEBUTIL.LOG) is responsible for providing valid values.
- BR-002 - A newline is always appended after the written text (WUF_TEXTIO_NEWLINE is unconditionally set to 1); the procedure does not support writing partial lines without a terminating newline.
- BR-003 - If the WebUtil client bean is not registered on the client, the operation is considered unrecoverable: an error alert is raised and execution is terminated via TOOL_ERR.TOOL_ERROR, preventing silent data loss.
- BR-004 - A property-set failure (PROPERTY_ERROR) is treated as an unrecoverable error and propagates immediately as TOOL_ERR.TOOL_ERROR, ensuring that partial or incomplete writes do not go undetected.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-068 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle cache. If the bundle has not yet been loaded, it delegates population to WEBUTIL.POPULATEPROPERTYBUNDLE before performing the lookup. The function is used by WEBUTIL infrastructure routines (CHECKLIBS, LOG, REGISTERBEAN) to resolve configuration properties at runtime without repeated file reads.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-065](#SP-065--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and record the current count of entries in the in-memory property bundle collection (m_propertyBundle).
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, immediately return NULL, bypassing all further processing.
- Step 3 - If no configuration error exists but the property bundle collection is empty (count = 0), call WEBUTIL.POPULATEPROPERTYBUNDLE passing the property key to load the bundle and obtain the result value in a single operation.
- Step 4 - If the property bundle collection is already populated, iterate through each entry in the collection and compare its stored key (case-normalised to lower-case) against the lower-case equivalent of the supplied propertyKey.
- Step 5 - On the first matching entry, capture the corresponding propertyValue into the result variable and exit the loop immediately.
- Step 6 - Return the resolved property value (or NULL if no match was found or a configuration error was present).

---
**Decision Points**

DP-001

Condition: m_config_error flag is TRUE.

TRUE: Return NULL immediately; no property lookup is attempted.

FALSE: Proceed to evaluate the state of the property bundle collection.

---

DP-002

Condition: The property bundle collection (m_propertyBundle) contains zero entries (COUNT = 0).

TRUE: Delegate to WEBUTIL.POPULATEPROPERTYBUNDLE to load the bundle and retrieve the value for the supplied key in one call; assign the returned value to the result variable.

FALSE: The bundle is already loaded; iterate through existing entries to find a matching key.

---

DP-003

Condition: During iteration, the current entry's propertyKey (stored in lower-case) matches the lower-case form of the supplied propertyKey.

TRUE: Assign the entry's propertyValue to the result variable and exit the loop.

FALSE: Continue to the next entry; if the loop completes without a match, the result variable remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has been recorded in a prior operation (m_config_error = TRUE), the function must return NULL without attempting any property resolution, preventing further processing against a known-bad configuration state.
- BR-002 - Property key comparisons are performed in lower-case on both sides; the supplied propertyKey is implicitly normalised via LOWER() before matching against the stored lower-case keys, ensuring case-insensitive lookup.
- BR-003 - The property bundle is loaded on demand: WEBUTIL.POPULATEPROPERTYBUNDLE is called only when the in-memory collection is empty, avoiding redundant population on subsequent calls.
- BR-004 - The function returns the value of the first matching entry and exits the loop immediately, meaning that if duplicate keys exist in the bundle the first occurrence takes precedence.
- BR-005 - The return value is limited to a maximum of 1 000 characters (VARCHAR2(1000 char)); property values exceeding this length cannot be fully returned by this function.
- BR-006 - If the bundle is populated but contains no entry matching the supplied key, the function returns NULL rather than raising an error, allowing callers to handle missing configuration gracefully.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-069 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by combining a property key and optional arguments, then returning the resolved translation. The function is used to obtain localised UI text - currently limited to fetching the progress bar title during library validation in WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the mandatory propertyKey and optional args input parameters that together identify the desired message bundle entry.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form the composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil core property store by calling Webutil_Core.setProperty, targeting the WUC_PACKAGE package identifier and the WUC_TRANS_MSG property name.
- Step 4 - Read back the resolved (translated) message string from the same property store by calling Webutil_Core.getProperty with the same WUC_PACKAGE and WUC_TRANS_MSG identifiers.
- Step 5 - Return the retrieved translated string to the caller.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: set the property and immediately retrieve the resolved value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The propertyKey parameter is mandatory; args defaults to NULL when not supplied, resulting in a trailing pipe delimiter in the composite lookup value (propertyKey||'|'||NULL).
- BR-002 - The message bundle lookup is performed exclusively through the Webutil_Core property mechanism using the fixed identifiers WUC_PACKAGE and WUC_TRANS_MSG; no direct database or file access is performed.
- BR-003 - The function must be used only for retrieving translated UI text strings; as noted in the source, its current sanctioned use is limited to obtaining the progress bar title within WEBUTIL.CHECKLIBS.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-070 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the server-side Forms session during initialisation. On the first bean registration it captures client environment details (IP address, OS, architecture, username, path/file separators, language code), resolves the system-library download directory, logs the connection if configured, and propagates server configuration (heartbeat blocking, logging level) to the client bean. On every registration it records the bean's trigger item in the package registry and triggers library availability checks for both the specific package and, on first call, for user libraries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-029](#SP-029--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-044](#SP-044--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-049](#SP-049--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-051](#SP-051--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-053](#SP-053--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-064](#SP-064--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-068](#SP-068--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-073](#SP-073--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) to identify which WebUtil package is registering.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant.
- Step 3 - If the client IP has not yet been captured (first bean to register), set the checkUserLibs flag to TRUE and parse clientInfo positions 2-8 to populate session-level client attributes: IP address, OS name, OS family (via WEBUTIL.GETOSFAMILY), OS architecture (64-bit detection), username, path separator, file separator, and language code.
- Step 4 - If the resolved packageID does not already exist in the registered-packages array, record the current trigger item (SYSTEM.TRIGGER_ITEM) against that package ID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - If checkUserLibs is TRUE, determine the server host name by calling WEBUTIL.GETVAR for COMPUTERNAME then HOST as a fallback.
- Step 6 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with an OS-family/architecture-specific key, then with an OS-family-only key if the first lookup returns null.
- Step 7 - If no client library directory is configured, send a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config, allowing the client JRE to handle placement. If a directory is configured, substitute the $(SERVERHOST) token with the resolved server host name and send the full path. Compare the new directory against the previously stored value via WEBUTIL.GETCLIENTSETTING; if they differ, persist the new value via WEBUTIL.SETCLIENTSETTING and set the REDOWNLOAD_SYSLIB flag to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version from the WUC_BEAN_VERSION property via WEBUTIL.GETPROPERTY.
- Step 9 - If the 'logging.connections' property bundle entry evaluates to 'true', write a connection log entry (form name, client OS, locale) via WEBUTIL.LOG.
- Step 10 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS with the package ID string to verify and download any required libraries for that bean package.
- Step 11 - If checkUserLibs is TRUE, invoke WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly session flags.
- Step 12 - Read the BlockAllowHeartBeat configuration entry via WEBUTIL.READFROMPROPERTYBUNDLE and send WUC_BLOCK_ALLOW_HEART_BEAT = '1' or '0' to the registering bean package accordingly.
- Step 13 - Evaluate the server logging flags and send WUC_SRV_LOGGING = '2' (full logging), '1' (errors only), or '0' (disabled) to the registering bean package.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal 'user' to check for and download any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known bean codes (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: The corresponding WEBUTIL_CORE package-ID constant is assigned to packageID.
FALSE: No packageID is assigned; subsequent logic that depends on packageID will operate with an uninitialised value.

DP-002
Condition: m_clientIP IS NULL (no bean has previously registered in this session).
TRUE: checkUserLibs is set to TRUE and client environment attributes (IP, OS, architecture, username, separators, language code) are parsed from clientInfo.
FALSE: Client environment attributes are not re-parsed; checkUserLibs remains FALSE.

DP-003
Condition: The OS architecture string parsed from clientInfo contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch remains at its default (not set to 1).

DP-004
Condition: m_registeredPackages does not already contain an entry for packageID.
TRUE: The current trigger item is stored in m_registeredPackages for packageID and newPackage is set to TRUE.
FALSE: The package is already registered; no update is made and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.GETVAR returns a non-null value for 'COMPUTERNAME'.
TRUE: serverHost is set to the COMPUTERNAME value.
FALSE: A second call to WEBUTIL.GETVAR is made for 'HOST' to obtain the server host name.

DP-006
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for the OS-family/architecture-specific syslib location key.
TRUE: clientLibDir is set to that value; the OS-family-only fallback lookup is skipped.
FALSE: A second lookup is attempted using the OS-family-only key.

DP-007
Condition: clientLibDir is NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is set to ':serverHost:CONFIG' with no client path, delegating directory resolution to the client JRE.
FALSE: The configured client directory path is used; $(SERVERHOST) is substituted and WUC_SYSLIB_DIR is set with the full path.

DP-008
Condition: clientLibDirOld (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The stored directory is unchanged; no update is made and REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: The 'logging.connections' property bundle entry (lowercased) equals 'true'.
TRUE: A connection log entry is written via WEBUTIL.LOG including form name, client OS, and locale.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to verify package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-011
Condition: blockAllowHeartBeat (lowercased) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '1' on the registering bean package.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is set to '0' on the registering bean package.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging) on the registering bean package.
FALSE: Evaluate DP-013.

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging) on the registering bean package.
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled) on the registering bean package.

DP-014
Condition: checkUserLibs is TRUE (after newPackage library check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to check and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - The bean short name extracted from clientInfo must correspond to a recognised WebUtil package code (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL); unrecognised codes do not receive a packageID assignment.
- BR-002 - Client environment attributes (IP, OS, architecture, username, path/file separators, language code) are captured exactly once per Forms session, on the first bean registration; subsequent bean registrations do not overwrite these values.
- BR-003 - Only the first instance of each bean type is registered per form session; if the same bean appears in a multi-row block or is otherwise duplicated, only the first trigger item is stored and subsequent instances are ignored.
- BR-004 - The system-library client directory is resolved with specificity priority: OS-family plus architecture key takes precedence over OS-family-only key; if neither is configured, directory resolution is delegated to the client JRE.
- BR-005 - The $(SERVERHOST) token within a configured client library directory path must be replaced with the runtime server host name before the path is transmitted to the client.
- BR-006 - If the resolved client system-library directory differs from the previously persisted value, the new value must be saved via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag must be set to TRUE to force a re-download.
- BR-007 - Connection logging is conditional on the 'logging.connections' property bundle entry being explicitly set to 'true' (case-insensitive); it is not performed by default.
- BR-008 - Library availability for a newly registered bean package is checked via WEBUTIL.CHECKLIBS only when that package is being registered for the first time in the session.
- BR-009 - User library checks via WEBUTIL.CHECKLIBS('user') are performed only once per session, on the first bean registration, and must occur after at least one bean package has been registered so that a handler bean exists to perform any required download.
- BR-010 - The BlockAllowHeartBeat configuration accepts only the values 'true', 'yes', or '1' (case-insensitive) as affirmative; any other value results in heartbeat blocking being disabled.
- BR-011 - Server logging level communicated to the client bean is derived from two session flags: errors-only logging takes precedence over full logging, and both require m_loggingAllowed to be TRUE; if logging is not allowed the client is instructed to suppress unnecessary server messages.
- BR-012 - The logging session flags (m_loggingAllowed, m_loggingErrorsOnly) must be initialised before the server logging level is sent to the client; this is achieved by invoking WEBUTIL.LOG with a null message during the first-registration path.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-071 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil client-side bean, obtaining a numeric handle that uniquely identifies the function for subsequent invocations. The handle is tracked internally to maintain a count of successfully registered functions, enabling the Oracle Forms session to reference and call client-side library functions through the WebUtil framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the library name (libName) and function name (funcName) as input parameters.
- Step 2 - Compose a pipe-delimited function specification string (libName || '|' || funcName) and transmit it to the WebUtil client-side bean by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component via WebUtil_Core.setProperty.
- Step 3 - Retrieve the registration result from the WebUtil bean by reading the WUL_REGISTER_FUNCTION property via WebUtil_Core.getProperty; the bean returns a string representation of the assigned function handle.
- Step 4 - Convert the returned string handle to a numeric value using TO_NUMBER and assign it to the FunctionHandle record field (funcHnd.hnd).
- Step 5 - Evaluate the validity of the returned handle by calling ID_NULL(funcHnd); if the handle is not null (i.e., registration succeeded), increment the module-level function handle counter (m_funcHandleCount) by 1.
- Step 6 - Return the populated FunctionHandle to the caller.
- Step 7 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt processing.
- Step 8 - If a property communication error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt processing.
- Step 9 - If the string-to-number conversion fails (VALUE_ERROR exception), raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition: ID_NULL(funcHnd) evaluates to FALSE (i.e., the handle returned by the WebUtil bean is a valid, non-null numeric value).

TRUE (handle is NOT null): Increment the module-level registered function handle counter (m_funcHandleCount) by 1 and proceed to return the handle.

FALSE (handle IS null): Skip the counter increment and return the null handle to the caller without error.

---

DP-002

Condition: A BEAN_NOT_REGISTERED exception is raised during the setProperty or getProperty call.

TRUE: Display an error alert identifying the missing WebUtil implementation class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal processing.

---

DP-003

Condition: A PROPERTY_ERROR exception is raised during the setProperty or getProperty call.

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Continue normal processing.

---

DP-004

Condition: A VALUE_ERROR exception is raised during TO_NUMBER conversion of the string handle.

TRUE: Raise TOOL_ERR.TOOL_ERROR to signal a data conversion failure to the calling context.

FALSE: Continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function specification passed to the WebUtil bean must be formatted as a pipe-delimited string combining the library name and function name (libName || '|' || funcName); no other delimiter or format is permitted.
- BR-002 - A function handle is only counted as a successfully registered handle if ID_NULL returns FALSE; null handles do not increment the registration counter.
- BR-003 - The module-level counter m_funcHandleCount must be incremented by exactly 1 for each valid (non-null) handle registration, maintaining an accurate tally of active registered functions within the session.
- BR-004 - If the WebUtil client-side bean is not registered, the procedure must not silently fail; it must present an error alert identifying the missing bean class and terminate the triggering operation via FORM_TRIGGER_FAILURE.
- BR-005 - A VALUE_ERROR during handle conversion must be escalated as TOOL_ERR.TOOL_ERROR, distinguishing a data conversion failure from a bean communication failure.
- BR-006 - The function returns a FunctionHandle type; callers must treat a returned handle where ID_NULL evaluates to TRUE as an unsuccessful registration.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-072 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This procedure ensures that process resources managed by the WebUtil host integration layer are properly deallocated after use, preventing stale or orphaned process handles from persisting in the session.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle (IN OUT) representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the process registration on the WUH_PACKAGE bean, passing the WUH_CLEAR_PROC property key and the current process handle value.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger to remove any callback trigger associated with the process handle, ensuring no residual trigger references remain.
- Step 4 - Set the process handle to NULL, signalling to the caller that the process reference is no longer valid.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert identifying the missing implementation class and informing the user that WEBUTIL_HOST.Release_Process will not function.

---
**Decision Points**

DP-001

Condition: A BEAN_NOT_REGISTERED exception is raised when attempting to interact with the WUH_PACKAGE bean via WebUtil_Core.

TRUE: WebUtil_Core.ErrorAlert is called, displaying the implementation class name retrieved via WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE) concatenated with a message stating the bean was not found and that WEBUTIL_HOST.Release_Process will not work. No further processing occurs.

FALSE: The procedure completes normally - the process property is cleared, the callback trigger is removed, and the handle is nullified.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be passed as IN OUT; the procedure unconditionally sets it to NULL upon successful completion, and the caller must treat the handle as invalid after this procedure returns.
- BR-002 - The WUH_PACKAGE bean must be registered in the WebUtil_Core layer before Release_Process is called; if the bean is absent, the release operation cannot proceed and an error alert is raised.
- BR-003 - Both the property clear (WUH_CLEAR_PROC) and the callback trigger removal must be performed together as part of a complete release; partial cleanup is not permitted by the procedure design.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-073 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Stores a named client-side setting by delegating to the WebUtil Core bean. Given a property name and value, the procedure concatenates them into a key=value string and passes it to the WebUtil Core package as a local property. This allows Oracle Forms to persist or communicate configuration settings to the WebUtil client-side bean at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if it is null, no action is taken and the procedure exits silently.
- Step 3 - Concatenate propertyName and propertyValue into a single string in the format 'propertyName=propertyValue'.
- Step 4 - Invoke WebUtil_Core.setProperty, passing the WebUtil Core package identifier (WebUtil_Core.WUC_PACKAGE), the local property action constant (WUC_SET_LOCAL_PROPERTY), and the concatenated key=value string to register the setting with the client-side bean.
- Step 5 - If the WebUtil Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 6 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Concatenate propertyName and propertyValue and call WebUtil_Core.setProperty to store the client setting.

FALSE: Skip the property assignment entirely; the procedure exits without performing any action or raising an error.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Display an error alert identifying the missing WebUtil Core bean class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: Continue normal execution; no alert is raised.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: Continue normal execution; the property has been set successfully.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting is only stored when propertyName is not null; a null property name is silently ignored and no update is made to the client-side bean.
- BR-002 - The property is transmitted to the WebUtil Core bean as a single concatenated string in the format 'propertyName=propertyValue'; no other delimiter or encoding is applied.
- BR-003 - The WebUtil Core bean identified by WebUtil_Core.WUC_PACKAGE must be registered before this procedure is called; if it is not registered, the procedure raises FORM_TRIGGER_FAILURE after alerting the user, preventing further form processing.
- BR-004 - Any property error returned by WebUtil_Core.setProperty causes an immediate FORM_TRIGGER_FAILURE, ensuring that an invalid or rejected property assignment does not allow form processing to continue silently.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-074 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB or a server-side file - depending on the active transfer mode. It tracks the number of remaining chunks and, when the final chunk is processed, closes the destination resource, marks the upload as succeeded or failed, fires any registered callback trigger, and clears that trigger. It is invoked by WEBUTIL_CORE.CUSTOMEVENTHANDLER as part of the WebUtil file-transfer mechanism.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-030](#SP-030--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-031](#SP-031--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-032](#SP-032--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-042](#SP-042--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-046](#SP-046--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-047](#SP-047--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-078](#SP-078--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the uploadData VARCHAR2 parameter representing one chunk of the file being uploaded.
- Step 2 - Validate that uploadData is not NULL and not an empty string; if it is, set the module-level flag m_uploadSucceeded to FALSE and exit without further processing.
- Step 3 - Determine the transfer destination using the module-level flag m_toDB.
- Step 4 (m_toDB = TRUE) - Delegate the write operation to WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 5 (m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.WriteData to write the chunk to the server-side file. If the call fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception to abort processing.
- Step 6 - Decrement the module-level chunk counter m_chunks by 1.
- Step 7 - Evaluate whether m_chunks has reached zero (i.e., all chunks have been received).
- Step 8 (Final chunk, m_toDB = TRUE) - Call WebUtil_DB_Local.CloseBlob, passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error via WebUtil_DB_Local.getLastError, log it, and leave m_uploadSucceeded as FALSE.
- Step 9 (Final chunk, m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.CloseFile, passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error code and arguments, log the error, delete the global Java reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 10 (Final chunk, any destination) - Check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER with argument -1. If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 11 - Call WEBUTIL.CLEARCALLBACKTRIGGER with argument -1 to deregister the callback trigger regardless of whether one was fired.

---
**Decision Points**

DP-001

Condition: uploadData IS NULL OR uploadData = ''

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no write or close operations are performed.

FALSE: Proceed to write the chunk to the designated destination.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the chunk using WebUtil_DB_LOCAL.WriteData (database BLOB path).

FALSE: Write the chunk using JAVA_APPSERV_WRITER.WriteData (server-side file path).

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (m_toDB = FALSE path only)

TRUE: Retrieve last error code and arguments, log the error via WebUtil_Core.Error, and raise READWRITE_ERROR.

FALSE: Continue processing; decrement m_chunks.

---

DP-004

Condition: m_chunks = 0 after decrement (all chunks received)

TRUE: Proceed to close the destination resource and finalise the upload.

FALSE: No further action for this chunk; procedure exits normally awaiting the next chunk.

---

DP-005

Condition: m_toDB is TRUE (within the final-chunk close block)

TRUE: Call WebUtil_DB_Local.CloseBlob to finalise the BLOB.

FALSE: Call JAVA_APPSERV_WRITER.CloseFile to finalise the server-side file.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob succeeds (m_toDB = TRUE, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve the error via WebUtil_DB_Local.getLastError, log it via WebUtil_Core.Error, and leave m_uploadSucceeded as FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile succeeds (m_toDB = FALSE, final chunk)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error code and arguments, log the error, delete the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name (final chunk only)

TRUE: Execute the named trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - An empty or NULL data chunk is treated as an error condition; the upload is immediately marked as failed (m_uploadSucceeded = FALSE) and no write or close operation is attempted.
- BR-002 - The write destination is determined exclusively by the module-level flag m_toDB: TRUE routes data to a database BLOB via WebUtil_DB_LOCAL; FALSE routes data to a server-side file via JAVA_APPSERV_WRITER.
- BR-003 - Any failure during a server-side file write (JAVA_APPSERV_WRITER.WriteData) must be logged with the full error code and error arguments before raising READWRITE_ERROR; partial writes are not silently ignored.
- BR-004 - The chunk counter m_chunks must be decremented by exactly 1 for every successfully written chunk, ensuring the procedure can detect when the final chunk has been received.
- BR-005 - Resource closure (CloseBlob or CloseFile) is performed only after all expected chunks have been received (m_chunks reaches zero), guaranteeing the destination is not closed prematurely.
- BR-006 - A successful close of the destination resource (either CloseBlob or CloseFile) is the definitive condition for setting m_uploadSucceeded to TRUE; a failed close leaves the flag FALSE and logs an error.
- BR-007 - On a CloseFile failure, the Java persistent object reference (m_persistObj) must be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR to prevent resource leaks.
- BR-008 - After all chunks are processed, any registered callback trigger (identified by WEBUTIL.GETCALLBACKTRIGGER with key -1) must be fired before it is cleared, ensuring downstream form logic is notified of upload completion.
- BR-009 - WEBUTIL.CLEARCALLBACKTRIGGER(-1) must always be called after the final chunk is processed, regardless of whether a callback trigger was present, to leave the callback slot in a clean state.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-075 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named system property in the Java runtime environment and returns the previous value. Used internally by the WebUtil framework to pass execution mode and command parameters to the WebUtil host component via the JNI bridge.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - An argument list is created with two arguments (the property name and the new value).
- Step 2 - The property name (a0) is added as the first string argument.
- Step 3 - The property value (a1) is added as the second string argument.
- Step 4 - The JNI bridge is called to invoke the Java System.setProperty method, passing both arguments.
- Step 5 - The previous value of the property is returned to the caller.

---
**Decision Points**

No decision points - single execution path.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - System properties are set in the Java runtime via the JNI bridge; the previous property value is returned but typically ignored by callers in this codebase.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-076 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil bean components. When called with show = TRUE, the procedure surfaces the window and navigates focus into it; when called with show = FALSE, it restores focus to the previously active item and hides the window. This mechanism is only engaged while the form is in NORMAL mode to avoid interference with Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Boolean parameter 'show', which determines whether the WebUtil hidden window should be displayed or hidden.
- Step 2 - Locate the WebUtil hidden window by resolving the constant WEBUTIL_HIDDEN_WINDOW using FIND_WINDOW; store the handle in the local variable hWin.
- Step 3 - Check whether the form is currently in NORMAL system mode (SYSTEM.MODE = 'NORMAL'). If not in NORMAL mode, exit immediately without performing any action.
- Step 4 - Validate that hWin is a non-null window handle using WEBUTIL.ID_NULL (SP-058). If the window handle is null, exit without performing any action.
- Step 5 - If 'show' is TRUE: capture the current cursor item by calling FIND_ITEM against SYSTEM.CURSOR_ITEM and store it in the module-level variable m_infoFrom; set the window title to 'WebUtil ' concatenated with WEBUTIL_VERSION; call SHOW_WINDOW to make the hidden window visible; navigate focus to WEBUTIL_DUMMY_ITEM within the window.
- Step 6 - If 'show' is FALSE: check whether m_infoFrom is a non-null item handle using WEBUTIL.ID_NULL (SP-058); if valid, navigate focus back to m_infoFrom; call HIDE_WINDOW to conceal the WebUtil hidden window.

---
**Decision Points**

DP-001

Condition: SYSTEM.MODE = 'NORMAL'

TRUE: Proceed to evaluate the window handle and perform show/hide processing.

FALSE: Exit the procedure immediately; no window visibility changes are made (guard against Enter Query Mode interference).

---

DP-002

Condition: WEBUTIL.ID_NULL(hWin) returns FALSE (i.e., the hidden window handle is valid and non-null)

TRUE: Proceed to evaluate the 'show' parameter and perform the appropriate show or hide action.

FALSE: Exit the procedure without attempting any window operation.

---

DP-003

Condition: 'show' parameter is TRUE

TRUE: Capture the current cursor item into m_infoFrom, set the window title, show the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE: Evaluate whether m_infoFrom is a valid item handle before restoring focus, then hide the window.

---

DP-004

Condition: 'show' is FALSE AND WEBUTIL.ID_NULL(m_infoFrom) returns FALSE (i.e., a previously captured cursor item exists)

TRUE: Navigate focus back to the item stored in m_infoFrom before hiding the window.

FALSE: Skip focus restoration and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not alter window visibility or focus when the form is in any mode other than NORMAL; Enter Query Mode must not be disrupted.
- BR-002 - The WebUtil hidden window must exist as a valid, non-null window object before any show or hide operation is attempted; the procedure silently aborts if the window handle is null.
- BR-003 - When showing the WebUtil window, the currently active form item (SYSTEM.CURSOR_ITEM) must be recorded in m_infoFrom so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The WebUtil hidden window title must be set to the string 'WebUtil ' concatenated with WEBUTIL_VERSION each time the window is shown, ensuring the displayed version is always current.
- BR-005 - Focus restoration to m_infoFrom on hide is conditional; it is only performed if m_infoFrom holds a valid, non-null item handle, preventing navigation errors when no prior cursor item was captured.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-077 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-side URL to a specified destination path on the client machine. The procedure acts as a named wrapper that delegates the actual download operation to WEBUTIL.DOWNLOADFROMURL, providing a semantically clear entry point for initiating URL-based file delivery to the client. It is invoked during Excel report viewing to stream the generated report file to the end user's local file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-033](#SP-033--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL identifying the file to be downloaded, the client-side destination path where the file is to be saved, and an optional file size hint (defaulting to 0 if not supplied).
- Step 2 - Delegate the download operation to WEBUTIL.DOWNLOADFROMURL (SP-033), passing through all three arguments (sourceURL, clientDestination, fileSize) unchanged.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURL to the calling routine, indicating whether the file transfer completed successfully.

---
**Decision Points**

DP-001

Condition: fileSize parameter is provided by the caller.

TRUE: The supplied fileSize value is forwarded to WEBUTIL.DOWNLOADFROMURL to assist in managing the download operation.

FALSE: fileSize defaults to 0 and is forwarded to WEBUTIL.DOWNLOADFROMURL, which handles the absence of a known file size.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return the BOOLEAN result from WEBUTIL.DOWNLOADFROMURL; no independent success or failure determination is made within this wrapper.
- BR-002 - All three parameters (sourceURL, clientDestination, fileSize) must be forwarded to WEBUTIL.DOWNLOADFROMURL without modification; no transformation or validation of input values is performed at this layer.
- BR-003 - The fileSize parameter is optional; when omitted by the caller, a default value of 0 is passed to WEBUTIL.DOWNLOADFROMURL.
- BR-004 - The actual file transfer logic is entirely owned by WEBUTIL.DOWNLOADFROMURL (SP-033); this function serves solely as a named delegation wrapper and must not duplicate or override that logic.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-078 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the Java-layer AppServerFileWriter class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called by WEBUTIL.SETDATA to physically write data to a server-side file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) identifying the active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string payload (a0) to the argument list by calling JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter instance via JNI.CALL_BOOLEAN_METHOD, passing the argument list and specifying the fully qualified class path 'oracle/forms/webutil/fileTransfer/AppServerFileWriter' and method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result received from the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally constructs the JNI argument list, invokes the Java WriteData method, and returns the Boolean result supplied by the JNI layer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data payload must be supplied as a VARCHAR2 string (a0); no transformation or validation of the payload is performed before it is passed to the Java layer.
- BR-002 - The Java object reference (obj) must represent a valid, pre-initialised AppServerFileWriter instance; the function does not create or validate the object itself.
- BR-003 - The success or failure of the write operation is determined solely by the return value of the Java WriteData method; a return value of TRUE indicates the data was written successfully, and FALSE indicates a failure.
- BR-004 - The JNI argument list is scoped to exactly one string argument, matching the Java method signature '(Ljava/lang/String;)Z'; passing any additional or differently typed arguments is not supported by this procedure.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-079 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events fired from the WHEN-CUSTOM-ITEM-EVENT trigger. It receives an event name and its associated parameters from the WebUtil Java bean client, extracts the data payload and multipart chunking metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer data receipt) based on the event name supplied.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-035](#SP-035--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-048](#SP-048--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-064](#SP-064--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-070](#SP-070--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-074](#SP-074--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-075](#SP-075--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the incoming EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); if it is not, raise the local unhandled exception, which is silently caught, and exit without further processing.
- Step 2 - Extract the primary data payload from EventParameters by calling the internal helper get_parameter_attr with the key 'WUC_DATA', storing the result in dataPayload.
- Step 3 - Extract the multipart chunking descriptor from EventParameters by calling get_parameter_attr with the key 'WUC_DATA_MULTIPART', storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using DelimStr.getNumber to derive chunkNumber (position 1, delimiter '/') and PayloadChunks (position 2, delimiter '/'), establishing how many client messages compose the full payload.
- Step 5 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the informational flag set to false.
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the error flag set to true.
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (registerBean) passing dataPayload to register the bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a number and store it in m_lastCallback; if conversion fails, call WEBUTIL.ERROR to report error code 408; if m_lastCallback is populated, execute the corresponding trigger stored in m_callbacks; if m_lastCallback is null, call WEBUTIL.LOG to record that no callback trigger was specified.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to store the transferred file data, then call WEBUTIL.SETPROPERTY to mark the 'WUT_TRANSFER_EVENT' property as 'RECEIVED' on the WUT package.
- Step 6 - On any unhandled exception other than the locally defined unhandled exception, re-raise to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of the five recognised values ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: Continue processing - extract payload and multipart metadata, then route to the appropriate handler.

FALSE: Raise the local unhandled exception, which is silently swallowed; procedure exits without any action.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and the informational (non-error) flag.

FALSE: Evaluate next event branch.

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and the error flag set to true.

FALSE: Evaluate next event branch.

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload.

FALSE: Evaluate next event branch.

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number and assign to m_lastCallback; evaluate DP-006 and DP-007.

FALSE: Evaluate next event branch.

---

DP-006

Condition: Conversion of dataPayload to NUMBER succeeds (no INVALID_NUMBER exception).

TRUE: Assign the numeric value to m_lastCallback and proceed to DP-007.

FALSE: Call WEBUTIL.ERROR to report error code 408 for 'WEBUTIL_CORE.CustomEventHandler'; m_lastCallback remains unset.

---

DP-007

Condition: m_lastCallback IS NOT NULL after the conversion attempt.

TRUE: Execute the trigger identified by m_callbacks(m_lastCallback).

FALSE: Call WEBUTIL.LOG to record that no callback trigger was specified for the host command.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload, then call WEBUTIL.SETPROPERTY to set the transfer event status to 'RECEIVED'.

FALSE: No further branches; end of routing logic.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five explicitly whitelisted event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; any unrecognised event is silently ignored with no error raised to the caller (Bug 2839033 guard).
- BR-002 - The data payload and multipart chunking information must always be extracted from EventParameters before any event-specific routing is attempted, regardless of which event is being handled.
- BR-003 - For the 'WUH_CALLBACK_EVENT' event, the dataPayload must be convertible to a valid number representing a callback index; if conversion fails, error code 408 is reported via WEBUTIL.ERROR and the callback is not executed.
- BR-004 - A 'WUH_CALLBACK_EVENT' with a null or unresolvable callback index must not silently succeed; the condition is logged as a warning via WEBUTIL.LOG.
- BR-005 - On receipt of a 'WUT_TRANSFER_EVENT', the transferred data must be stored via WEBUTIL.SETDATA and the transfer status property must be immediately updated to 'RECEIVED' via WEBUTIL.SETPROPERTY before the procedure exits.
- BR-006 - Any unexpected runtime exception other than the locally defined unhandled event exception is re-raised to the calling trigger, ensuring that unforeseen errors are not suppressed.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-080 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a single error condition encountered during D2KWUTIL utility processing. The procedure sets a module-level error flag, builds a formatted error message by combining the calling function name with the supplied error text, and writes the resulting entry to the debug log via DEBUGLOG. It provides a centralised, consistent mechanism for all D2KWUTIL stored procedures to register errors without raising exceptions.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the module-level boolean flag ERROR_ENCOUNTERED to TRUE, signalling that at least one error has occurred in the current processing context.
- Step 3 - Construct the ERROR_STACK message by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, ensuring the stored message does not exceed the target field length.
- Step 4 - Invoke DEBUGLOG (SP-084) with severity level 99, the literal identifier 'Add_Error', and the formatted ERROR_STACK value to persist the error entry in the debug log.

---
**Decision Points**

No conditional decision points are present in this procedure. All steps execute unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, regardless of the content of the error text, ensuring the error state is always flagged.
- BR-002 - The error message stored in ERROR_STACK must follow the format '<CallingFunction>: <ErrorText>', preserving the originating function name for traceability.
- BR-003 - The error text portion of ERROR_STACK is capped at 1,968 characters (via SUBSTR) to prevent overflow of the ERROR_STACK variable.
- BR-004 - Every error registered through this procedure must be written to the debug log via DEBUGLOG at severity level 99, guaranteeing a persistent audit trail of all errors encountered during D2KWUTIL utility execution.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-081 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single string buffer for return to the calling context. The function first drains the Oracle Forms tool-level error stack (TOOL_ERR); if no tool errors are present but a SQL error exists, it captures the current SQLERRM message instead. The resulting concatenated string is returned to the caller for downstream display or logging.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local counter (iCounter) and an empty varchar2 buffer (vcErrBuff, maximum 1968 characters) to accumulate error text.
- Step 2 - Check whether the TOOL_ERR error stack contains one or more entries (TOOL_ERR.NERRORS > 0).
- Step 3 - If tool errors exist, iterate from 1 to TOOL_ERR.NERRORS; on each iteration, append a newline character (CHR(10)) followed by the current TOOL_ERR.MESSAGE to vcErrBuff.
- Step 4 - After appending each message, call TOOL_ERR.POP to remove the processed entry from the error stack.
- Step 5 - If the concatenation causes vcErrBuff to exceed its declared size, a VALUE_ERROR exception is raised; the exception handler exits the loop immediately, preserving the messages already accumulated.
- Step 6 - If no tool errors are present (TOOL_ERR.NERRORS = 0) but SQLERRM is not null, append a newline character followed by SQLERRM to vcErrBuff.
- Step 7 - Return vcErrBuff to the caller.

---
**Decision Points**

DP-001

Condition: TOOL_ERR.NERRORS > 0

TRUE: Enter the loop and iteratively append each tool error message to vcErrBuff, popping each entry from the stack after it is appended.

FALSE: Skip the loop and evaluate whether a SQL error message is available (DP-002).

---

DP-002

Condition: SQLERRM IS NOT NULL (evaluated only when TOOL_ERR.NERRORS = 0)

TRUE: Append a newline character and the SQLERRM text to vcErrBuff.

FALSE: vcErrBuff remains empty; the function returns NULL.

---

DP-003

Condition: VALUE_ERROR exception raised during string concatenation inside the loop

TRUE: The accumulated buffer has reached its 1968-character limit; exit the loop immediately, discarding any remaining unprocessed tool error messages.

FALSE: Concatenation succeeds; continue iterating through remaining tool error entries.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message buffer is capped at 1,968 characters; any tool error messages that would cause the buffer to exceed this limit are silently discarded, and only the messages accumulated up to that point are returned.
- BR-002 - The TOOL_ERR error stack takes precedence over the SQL error context; SQLERRM is only captured when TOOL_ERR.NERRORS equals zero.
- BR-003 - Each tool error message is separated from the previous content by a newline character (CHR(10)), ensuring individual messages remain distinguishable in the returned string.
- BR-004 - Each processed TOOL_ERR entry is popped from the stack during iteration, meaning the stack is consumed (cleared) as part of error collection.
- BR-005 - If neither tool errors nor a SQL error is present, the function returns NULL.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-082 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

BOOLTOCHAR is a utility function that converts a PL/SQL BOOLEAN value into its VARCHAR2 string equivalent ('TRUE' or 'FALSE'). It is used across multiple D2KWUTIL stored procedures (CHOOSEFILE, FILE_INFO, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, and READ_REGISTRY) where a boolean result must be represented as a character string for further processing or output.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean.
- Step 2 - Evaluate the value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition: ThisBoolean IS TRUE

TRUE: The function returns the VARCHAR2 string 'TRUE'.

FALSE: The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; the only permitted return values are the literals 'TRUE' and 'FALSE'.
- BR-002 - A BOOLEAN input that evaluates to TRUE maps exclusively to the string 'TRUE'; any other evaluation (FALSE or NULL falling to the ELSE branch) maps to the string 'FALSE'.
- BR-003 - The function has no database interactions and no external dependencies; its output is determined solely by the value of the input parameter ThisBoolean.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-083 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the error flag and discarding any accumulated error messages. This procedure is called at the start of utility operations within D2KWUTIL to ensure no residual error information from a previous execution affects the current processing context.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error condition is currently active.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any error messages accumulated during prior processing.

---
**Decision Points**

No decision points. The procedure executes unconditionally; both variables are always reset regardless of their current state.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on invocation, unconditionally clearing any previously recorded error flag.
- BR-002 - ERROR_STACK must be set to NULL on invocation, unconditionally purging any previously accumulated error message content.
- BR-003 - The procedure accepts no input and produces no output; its sole effect is the side-effect reset of the two shared module-level error-state variables.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-084 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes formatted diagnostic messages to either a Windows debug output channel or a flat log file, depending on the active debug state and API availability. It is the central logging utility for the D2KWUTIL library, called by all major procedures to record execution trace information at a configurable verbosity level.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-090](#SP-090--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-101](#SP-101--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Check whether debug logging is active (iDebugState = 0); if inactive, exit immediately without processing.
- Step 2 - Check whether debug logging is paused (bDebugPaused = TRUE); if paused, exit immediately without processing.
- Step 3 - Compare the incoming DebugLevel against the configured threshold (iDebugLevel); if the message level exceeds the threshold, exit immediately without processing.
- Step 4 - If a timestamp is enabled (bDebugTimeStamp = TRUE), format the current system time as HH24:MI:SS and append a '>' separator to form vcDateStamp.
- Step 5 - Construct the full debug string by combining the DebugLevel (left-padded to 2 digits), the optional timestamp, the calling procedure name (right-padded to 30 characters with a colon suffix), and a truncated portion of LogString so the total does not exceed 2,000 characters. WEBUTIL.LENGTH is used in the length calculation of the composite string.
- Step 6 - If iDebugState = 2 (Windows debugger mode), check whether the DEBUG_API_ENABLED flag is TRUE.
  - Step 6a - If the API is available, call WINDEBUG to write the formatted string to the Windows debug output.
  - Step 6b - If the API is not available, call SETDEBUG to switch logging to file mode targeting the configured log file (defaulting to 'd2kwutil.log'), recursively call DEBUGLOG to record the mode-switch event, recursively call DEBUGLOG to re-log the original message under file mode, and set bDebugType2Required to TRUE to signal that debugger mode should be reinstated when the API becomes available.
- Step 7 - If iDebugState is not 2 (file logging mode), check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED is now TRUE.
  - Step 7a - If both conditions are met, call SETDEBUG to reinstate Windows debugger mode, recursively call DEBUGLOG to record the restoration event, reset bDebugType2Required to FALSE, and recursively call DEBUGLOG to re-log the original message under debugger mode.
  - Step 7b - Otherwise, open the log file in append mode using TEXT_IO, write the formatted debug string, and close the file.
- Step 8 - If any exception occurs during logging, suppress the error by setting iDebugState to 0, disabling further debug output to prevent logging failures from disrupting the parent application.

---
**Decision Points**

DP-001
Condition: iDebugState = 0
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to the next check.

DP-002
Condition: bDebugPaused = TRUE
TRUE: Procedure exits immediately; no logging is performed.
FALSE: Processing continues to the next check.

DP-003
Condition: DebugLevel > iDebugLevel
TRUE: Message verbosity exceeds the configured threshold; procedure exits immediately without logging.
FALSE: Message meets the threshold; processing continues to construct the log entry.

DP-004
Condition: bDebugTimeStamp = TRUE
TRUE: Current system time (HH24:MI:SS) is prepended to the debug string.
FALSE: No timestamp is included in the debug string.

DP-005
Condition: iDebugState = 2 (Windows debugger output mode)
TRUE: Attempt to write to the Windows debug channel via WINDEBUG.
FALSE: Proceed with file-based logging logic.

DP-006
Condition: DEBUG_API_ENABLED = TRUE (evaluated when iDebugState = 2)
TRUE: Call WINDEBUG to write the formatted message to the Windows debugger.
FALSE: Call SETDEBUG to fall back to file logging, log the mode-switch event, re-log the original message, and set bDebugType2Required to TRUE.

DP-007
Condition: bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (evaluated during file logging mode)
TRUE: Call SETDEBUG to reinstate Windows debugger mode, log the restoration event, reset bDebugType2Required to FALSE, and re-log the original message under debugger mode.
FALSE: Open the log file in append mode, write the formatted string via TEXT_IO, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug logging is suppressed entirely when iDebugState equals 0; no message of any level is written under this condition.
- BR-002 - Debug logging is temporarily suppressed when bDebugPaused is TRUE, allowing the calling application to pause and resume trace output without disabling the debug configuration.
- BR-003 - Only messages whose DebugLevel does not exceed the configured iDebugLevel threshold are logged; higher-level (more verbose) messages are silently discarded.
- BR-004 - The composite debug string must not exceed 2,000 characters; LogString is truncated to enforce this limit after the level prefix, timestamp, and padded caller name have been prepended.
- BR-005 - The calling procedure name (LoggingCall) is always right-padded with a colon to a fixed width of 30 characters in the log entry, ensuring consistent columnar alignment across all log lines.
- BR-006 - When Windows debugger output (iDebugState = 2) is requested but the debug API is unavailable, the procedure automatically falls back to file logging via SETDEBUG and records the mode-switch event before re-logging the original message; this prevents silent loss of diagnostic output.
- BR-007 - Once the Windows debug API becomes available again after a fallback, the procedure automatically reinstates debugger-mode logging via SETDEBUG and records the restoration event, ensuring the preferred output channel is used as soon as it is accessible.
- BR-008 - Any runtime exception raised within DEBUGLOG is silently caught and handled by setting iDebugState to 0, ensuring that a logging failure never propagates an error to the calling business procedure.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-085 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating to the D2KWUTIL native library call D2KWUTIL_GETDOSENV. The function is invoked by WEBUTIL.GETVAR and returns the resolved variable value as a VARCHAR2 string. If the Win32 API layer is unavailable, or if the variable cannot be resolved, the function either raises an exception or returns NULL, depending on the caller-supplied RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-014](#SP-014--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (via Win_api_debug.DebugLog) at trace level 99, recording the input VariableName and the string representation of RaiseExceptions (produced by BOOLTOCHAR via Win_api_debug.BoolToChar).
- Step 2 - Reset the error stack: call CLEAN_ERROR_STACK (via WIN_API.Clean_Error_Stack) to clear any previously recorded errors before processing begins.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check API availability: evaluate WIN_API.API_ENABLED to determine whether the Win32 API layer is active.
- Step 5 - Register the native function: if the API is available, call REGISTER_FUNCTION_CALL (via win_api.Register_function_call) to bind the internal handle iGetDOSEnv to the external function signature 'd2kwutil_GetDOSEnv' with argument types 'LONG','*CHAR,*CHAR,LONG'.
- Step 6 - Prepare call arguments: wrap VariableName in percent signs to form the environment variable token (vcBuff1), initialise a 512-character null-padded output buffer (vcBuff2), and set the buffer length indicator iBuff1 to 512.
- Step 7 - Invoke the native environment lookup: call D2KWUTIL.D2KWUTIL_GETDOSENV (via d2kwutil_GetDOSEnv) passing the registered function handle, the variable token, the output buffer, and the buffer length; capture the integer return code in iRC.
- Step 8 - Log the result: call DEBUGLOG again at trace level 99, recording the returned value length (iRC) and the resolved buffer content (vcBuff2).
- Step 9 - Evaluate the lookup outcome: if iRC equals 0 or vcBuff2 still equals the input token (indicating the variable was not expanded), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - Return the resolved value: if the lookup succeeded, return vcBuff2 containing the environment variable value.
- Step 11 - Exception handling: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, record an error via ADD_ERROR using WIN_API.NoAPI and re-raise; for all other exceptions, record an error via ADD_ERROR concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED evaluates to TRUE.
TRUE: Register the native function handle, prepare call arguments, invoke D2KWUTIL.D2KWUTIL_GETDOSENV, and log the result.
FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is caught by the exception block, logged via ADD_ERROR, and re-raised to the caller.

DP-002
Condition: The native call return code iRC equals 0, OR the output buffer vcBuff2 is unchanged from the input token vcBuff1 (i.e., the environment variable could not be resolved).
TRUE: Record an error via ADD_ERROR indicating the variable value could not be retrieved, then branch on RaiseExceptions (see DP-003).
FALSE: Return vcBuff2 as the resolved environment variable value.

DP-003
Condition: RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).
TRUE: Raise NO_DATA_FOUND to signal the failure to the caller.
FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the environment variable lookup when the Win32 API layer is active (WIN_API.API_ENABLED is TRUE); if the API is unavailable the function must raise WIN_API.NOT_AVAILABLE and record a corresponding error via ADD_ERROR before propagating the exception.
- BR-002 - The environment variable name must be wrapped in percent signs (e.g., %VariableName%) when passed to D2KWUTIL.D2KWUTIL_GETDOSENV, conforming to the Windows environment variable expansion convention.
- BR-003 - The output buffer allocated for the resolved value must be exactly 512 characters, null-padded, ensuring the native call has a fixed-length target buffer.
- BR-004 - A lookup is considered failed if the native return code is 0 or if the output buffer value equals the unexpanded input token; in either case an error must be registered via ADD_ERROR before any return or raise action is taken.
- BR-005 - The caller controls error-propagation behaviour through the RaiseExceptions flag: when TRUE, a failed lookup raises NO_DATA_FOUND; when FALSE (the default), a failed lookup returns NULL without raising an exception.
- BR-006 - NO_DATA_FOUND exceptions must be re-raised as-is without additional error logging, preserving the original exception context for the caller.
- BR-007 - All unhandled exceptions must be captured, enriched with ADD_EXTERNAL_ERRORS output concatenated to WIN_API.UError, recorded via ADD_ERROR, and then re-raised, ensuring a complete error record is available on the error stack.
- BR-008 - Entry and exit diagnostic information (input arguments and resolved value with length) must be written to the debug log via DEBUGLOG at trace level 99 to support runtime tracing without impacting normal execution flow.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-086 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

GET_TEMP_DIRECTORY is a function that retrieves the operating-system temporary directory path for the current Windows session by invoking the external D2KWUTIL Windows API utility. It returns the resolved directory path as a VARCHAR2 string, stripped of any trailing directory separator, and provides controlled error handling based on whether the caller requires exceptions to be raised on failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-016](#SP-016--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-099](#SP-099--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the function entry and the value of the RaiseExceptions input parameter using DEBUGLOG (Win_API_Debug.DebugLog at debug level 99).
- Step 2 - Clear any previously accumulated errors from the error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Windows API layer is available (Win_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external Windows API function call via REGISTER_FUNCTION_CALL, binding the internal handle iTmpDir to the external entry point 'd2kwutil_TmpDir' with the signature INT / *CHAR, INT.
- Step 6 - Initialise the output buffer vcBuff1 as a 512-character space-padded, null-terminated string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and the buffer length (512), and capture the integer return code in iRC.
- Step 8 - Log the result, including the return code and the raw buffer value returned by the API, using DEBUGLOG.
- Step 9 - Evaluate the return code iRC. If iRC equals 0 (no value returned), record an error via ADD_ERROR and either raise NO_DATA_FOUND (if RaiseExceptions is TRUE) or return NULL (if RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), pass the populated buffer vcBuff1 to STRIPDIRSEP to remove any trailing directory separator and return the cleaned path to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by recording an error via ADD_ERROR and re-raising; handle all other exceptions by recording a combined error message via ADD_ERROR and ADD_EXTERNAL_ERRORS and re-raising.

---
**Decision Points**

DP-001

Condition: Win_API.API_ENABLED is TRUE.

TRUE: Register the external function call, allocate the output buffer, invoke D2KWUTIL.D2KWUTIL_WINDIR, and proceed to evaluate the return code.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing the API call entirely.

---

DP-002

Condition: The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR equals 0 (indicating no directory value was returned by the API).

TRUE: Log an error via ADD_ERROR ('No Value Returned') and branch on RaiseExceptions (see DP-003).

FALSE: Pass the populated buffer to STRIPDIRSEP and return the cleaned temporary directory path to the caller.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC = 0).

TRUE: Raise the NO_DATA_FOUND exception to propagate the failure to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function may only execute the Windows API call when the API layer is active (Win_API.API_ENABLED). If the API layer is unavailable, the function must raise WIN_API.NOT_AVAILABLE and record the corresponding error; it must never attempt the external call in an unavailable state.
- BR-002 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition meaning no temporary directory value was obtained; this must be recorded as an error regardless of the RaiseExceptions flag.
- BR-003 - The caller controls failure-propagation behaviour through the RaiseExceptions parameter: when TRUE, a failure (iRC = 0) results in a raised NO_DATA_FOUND exception; when FALSE, the function returns NULL without raising, allowing the caller to handle the absence of a value gracefully.
- BR-004 - The returned directory path must always be stripped of its trailing directory separator character via STRIPDIRSEP before being returned to the caller, ensuring a consistent path format.
- BR-005 - All exceptions (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled others) must be re-raised after error recording so that upstream callers receive notification of the failure; the function must never suppress exceptions silently.
- BR-006 - Unhandled exceptions must be recorded using both ADD_ERROR and ADD_EXTERNAL_ERRORS to capture both the internal error context and any externally accumulated error detail before re-raising.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-087 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows system directory path for the current environment by invoking the external D2KWUtil utility function D2KWUTIL_WINDIR. The result is cleaned of any trailing directory separator before being returned to the caller. The procedure supports optional exception raising to allow calling routines to control error-handling behaviour.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-016](#SP-016--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-099](#SP-099--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the function entry, including the value of the RaiseExceptions input parameter, using DEBUGLOG.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Check whether the Win API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function call for D2KWUTIL_WINDIR via REGISTER_FUNCTION_CALL, supplying the function handle reference, function name, and parameter type signature.
- Step 5 - Initialise a 512-character null-padded buffer (vcBuff1) to receive the directory path.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_WINDIR with the registered function handle, the output buffer, and the buffer length (512). Capture the integer return code (iRC).
- Step 7 - Log the raw return code and the contents of the output buffer using DEBUGLOG.
- Step 8 - Evaluate the return code. If iRC equals 0, the external call returned no value; record an error via ADD_ERROR with the message 'No Value Returned'.
- Step 9 - If iRC equals 0 and RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise return NULL.
- Step 10 - If iRC is non-zero (success), strip any trailing directory separator from the buffer using STRIPDIRSEP and return the cleaned path string.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR using WIN_API.NoAPI and re-raise; for all other exceptions, log the error via ADD_ERROR appending ADD_EXTERNAL_ERRORS detail and re-raise.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED is TRUE.

TRUE: Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the Windows directory path.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, bypassing all retrieval logic.

---

DP-002

Condition: The return code iRC from D2KWUTIL.D2KWUTIL_WINDIR equals 0.

TRUE: The external call returned no directory value; record an error via ADD_ERROR and proceed to DP-003.

FALSE: The external call succeeded; strip the trailing directory separator from the buffer using STRIPDIRSEP and return the resulting path.

---

DP-003

Condition: RaiseExceptions input parameter is TRUE (evaluated only when iRC equals 0).

TRUE: Raise NO_DATA_FOUND to propagate the failure to the caller.

FALSE: Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows directory path may only be retrieved when the Win API layer is active (WIN_API.API_ENABLED); if the API is unavailable the function must not attempt the external call and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition, meaning no directory path was returned; this must be recorded as an error regardless of the RaiseExceptions setting.
- BR-003 - The caller controls whether a missing directory value results in an exception (NO_DATA_FOUND) or a NULL return by supplying the RaiseExceptions parameter; the default behaviour (RaiseExceptions = FALSE) is to return NULL.
- BR-004 - The returned directory path must always have any trailing directory separator removed via STRIPDIRSEP before being passed back to the caller, ensuring a consistent path format.
- BR-005 - All error conditions (no value returned, API unavailable, unexpected exceptions) must be recorded on the error stack via ADD_ERROR before any exception is re-raised, preserving a complete audit trail of the failure.
- BR-006 - Unexpected exceptions must append external error detail obtained from ADD_EXTERNAL_ERRORS to the error message before re-raising, ensuring full diagnostic context is captured.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-088 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

READ_REGISTRY retrieves a named value from the Windows Registry for a given registry path and entry key. It translates a human-readable root hive name (e.g., HKEY_LOCAL_MACHINE) into the numeric constant expected by the underlying D2KWUTIL platform call, invokes D2KWUTIL.D2KWUTIL_GETREGKEY to perform the actual read, and returns the value as a VARCHAR2 string. The caller may optionally request that failures raise PL/SQL exceptions rather than silently returning NULL, making the routine suitable for both fault-tolerant lookups and strict configuration validation scenarios.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-082](#SP-082--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-083](#SP-083--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-015](#SP-015--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG with the supplied RegPath, RegEntry, and the character representation of RaiseExceptions (via BOOLTOCHAR), providing a full audit trail of every invocation.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK, ensuring error reporting for this call is isolated.
- Step 3 - Verify that the WIN_API layer is available; if WIN_API.API_ENABLED is FALSE, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL, binding the function signature so the D2KWUTIL bridge can dispatch the call correctly.
- Step 5 - Parse the root hive from RegPath by extracting the substring before the first backslash and converting it to uppercase, then map it to its numeric constant: HKEY_LOCAL_MACHINE=0, HKEY_CLASSES_ROOT=1, HKEY_CURRENT_USER=2, HKEY_USERS=3, HKEY_CURRENT_CONFIG=4.
- Step 6 - If the root hive string does not match any recognised value, record an error via ADD_ERROR and, when RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise continue (the subsequent D2KWUTIL call will use an uninitialised buffer integer).
- Step 7 - Prepare the call buffers: extract the sub-path after the first backslash into vcBuff1, assign RegEntry to vcBuff2, initialise the 2000-byte result buffer vcBuff3 as a NUL-padded string, and set the compatibility flag iBuff3 to 1 (suppress environment-variable expansion) when WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE, or 0 to allow expansion; log the compatibility decision via DEBUGLOG.
- Step 8 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the function handle, numeric root constant, sub-path, entry name, result buffer, buffer length (2000), and compatibility flag; capture the integer return code iRC.
- Step 9 - Log the return code and the raw buffer content via DEBUGLOG for post-call diagnostics.
- Step 10 - Evaluate iRC: if -1 (entry not found), record an error via ADD_ERROR and return NULL or raise NO_DATA_FOUND; if -2 (unsupported data type), record an error and return NULL or raise NO_DATA_FOUND; if -3 (value exceeds buffer), record an error and return NULL or raise VALUE_ERROR; if -4 (environment-string expansion failure), record an error and return NULL or raise NO_DATA_FOUND. The choice between returning NULL and raising an exception is governed by the RaiseExceptions parameter.
- Step 11 - If iRC indicates success (none of the error codes above), return vcBuff3 containing the retrieved registry value.
- Step 12 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE, record the no-API message via ADD_ERROR then re-raise; for all other exceptions, record an error combining the unexpected-error prefix with ADD_EXTERNAL_ERRORS output via ADD_ERROR, then re-raise.

---
**Decision Points**

DP-001
Condition: WIN_API.API_ENABLED is TRUE.
TRUE: Proceed with function registration, root-hive parsing, and the D2KWUTIL registry read.
FALSE: Raise WIN_API.NOT_AVAILABLE immediately, bypassing all registry access logic.

DP-002
Condition: The uppercase root-hive token extracted from RegPath matches one of the five recognised hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).
TRUE: Assign the corresponding numeric constant (0-4) to iBuff1 and continue buffer preparation.
FALSE: Call ADD_ERROR to record an invalid-key message; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue execution with iBuff1 uninitialised.

DP-003
Condition: WIN_API.COMPAT_EXPAND_REG_VALUES is FALSE.
TRUE: Set iBuff3 to 1 to suppress environment-variable expansion in the registry value, and log the suppression via DEBUGLOG.
FALSE: Set iBuff3 to 0 to allow environment-variable expansion.

DP-004
Condition: iRC returned by D2KWUTIL.D2KWUTIL_GETREGKEY equals -1 (registry entry not found).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Evaluate subsequent error-code conditions (DP-005 through DP-007).

DP-005
Condition: iRC equals -2 (registry value is an unsupported data type).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: Evaluate DP-006.

DP-006
Condition: iRC equals -3 (registry value exceeds the 2000-byte buffer).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise VALUE_ERROR.
FALSE: Evaluate DP-007.

DP-007
Condition: iRC equals -4 (environment-string expansion failed).
TRUE: Call ADD_ERROR; if RaiseExceptions is FALSE return NULL, otherwise raise NO_DATA_FOUND.
FALSE: No error condition applies; return vcBuff3 as the retrieved registry value.

DP-008
Condition: RaiseExceptions is TRUE (evaluated within each error-code branch DP-002 through DP-007).
TRUE: Raise the appropriate PL/SQL exception (NO_DATA_FOUND or VALUE_ERROR) after recording the error.
FALSE: Return NULL to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows Registry root hive must be specified as the leading segment of RegPath, delimited by a backslash; only the five standard hive names HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, and HKEY_CURRENT_CONFIG are valid. Any other value is treated as an error.
- BR-002 - The result buffer for the registry value is fixed at 2000 bytes. Registry values whose content exceeds this limit cannot be returned and are treated as an error condition (iRC = -3).
- BR-003 - Only string-compatible registry data types are supported. Registry entries stored as unsupported binary or numeric types (iRC = -2) cannot be retrieved by this routine.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES flag. When this flag is FALSE, expansion is suppressed (iBuff3 = 1) to maintain backward compatibility; when TRUE, the D2KWUTIL layer is permitted to expand embedded environment strings.
- BR-005 - Every invocation must be logged at debug level 99 both on entry (with all input arguments) and after the D2KWUTIL call (with the return code and retrieved value), ensuring a complete audit trail regardless of outcome.
- BR-006 - The error stack must be cleared at the start of each invocation via CLEAN_ERROR_STACK so that error messages reported by ADD_ERROR relate exclusively to the current call.
- BR-007 - When RaiseExceptions is FALSE (the default), all error conditions return NULL to the caller rather than propagating an exception, allowing callers to perform their own NULL checks without exception handling.
- BR-008 - When RaiseExceptions is TRUE, all error conditions terminate the function by raising a PL/SQL exception (NO_DATA_FOUND for entry-not-found, unsupported-type, and expansion-failure conditions; VALUE_ERROR for buffer-overflow), enabling strict validation workflows.
- BR-009 - If the WIN_API layer is unavailable, the routine must not attempt any registry access; it records the unavailability via ADD_ERROR and re-raises WIN_API.NOT_AVAILABLE unconditionally, regardless of the RaiseExceptions setting.
- BR-010 - Unexpected runtime exceptions are captured, enriched with additional context from ADD_EXTERNAL_ERRORS, recorded via ADD_ERROR, and then re-raised, ensuring that unhandled failures are always surfaced with diagnostic detail.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-089 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.FILE_INFO]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native DLL function and its parameter/return-type signature with the Oracle FFI layer so that subsequent calls to that function can be dispatched correctly. The procedure ensures the target DLL is loaded, detects whether the function has already been registered under the current DLL load cycle, and (re-)registers the function handle, each individual parameter type, and the return type only when necessary. It is a prerequisite utility invoked by multiple D2KWUTIL procedures before any foreign-function call is made.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-007](#SP-007--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-020](#SP-020--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-071](#SP-071--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the already-loaded DLL by calling ORA_FFI.FIND_LIBRARY using the package-level DLL_NAME constant. If the library is found, execution continues; if an FFI error is raised, control falls to Step 2.
- Step 2 - On FFI error from Step 1, attempt to load the DLL from scratch via D2KWUTIL.ATTEMPT_DLL_LOAD using DLL_Path and DLL_NAME. If this also raises an FFI error, set the package-level flag API_ENABLED to FALSE, record a descriptive error via ADD_ERROR (reporting that the DLL was not found), and raise NO_DATA_FOUND to abort the caller.
- Step 3 - Compare the cached load-count entry for FunctionID in the FunctionLoad associative array against the current DLL_LOAD_COUNT. If no entry exists for FunctionID, or if the stored count differs from DLL_LOAD_COUNT (indicating the DLL was reloaded), proceed to Steps 4-8. If the counts match, skip to the end; no re-registration is needed.
- Step 4 - Register the function with the loaded DLL handle by calling ORA_FFI.REGISTER_FUNCTION, passing the DLL handle, FunctionName, and the C_STD calling convention. Store the resulting function handle in FunctionHandle(FunctionID).
- Step 5 - If FunctionName is not 'd2kwutil_DebugString', write a diagnostic entry via DEBUGLOG (Win_API_Debug.DebugLog at level 99). Log whether this is an initial registration (FunctionLoad entry did not previously exist) or a re-registration, including FunctionName, DLL_LOAD_COUNT, and the prior load-count value.
- Step 6 - Parse the FunctionArgs string by appending a trailing comma delimiter and iterating through comma-separated type tokens. For each token, call D2KWUTIL.TRANSLATETYPE to convert the textual type name to its ORA_FFI type constant, then call ORA_FFI.REGISTER_PARAMETER against the function handle. Continue until the remaining argument string is NULL, a bare comma, or 'VOID,'.
- Step 7 - If FunctionReturn is not 'VOID' (case-insensitive) and is not NULL, call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type via ORA_FFI.REGISTER_RETURN against the function handle.
- Step 8 - Record FunctionID's current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to mark this function as registered for the current DLL load cycle, preventing redundant re-registration on future calls.
- Step 9 - If an FFI error is raised at any point outside the inner DLL-load subblock, invoke ADD_ERROR with FunctionName and a combined error message built from UError and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to abort the caller.

---
**Decision Points**

DP-001

Condition: ORA_FFI.FIND_LIBRARY succeeds in locating the DLL by name.

TRUE: DLL_HANDLE is set; execution proceeds to the registration check (DP-002).

FALSE: An ORA_FFI.FFI_ERROR exception is raised; D2KWUTIL.ATTEMPT_DLL_LOAD is invoked to attempt a fresh DLL load (DP-002 is deferred until load succeeds).

---

DP-002

Condition: D2KWUTIL.ATTEMPT_DLL_LOAD succeeds in loading the DLL when FIND_LIBRARY failed.

TRUE: DLL_HANDLE is set from the load attempt; execution proceeds to the registration check.

FALSE: An ORA_FFI.FFI_ERROR exception is raised; API_ENABLED is set to FALSE, ADD_ERROR is called, and NO_DATA_FOUND is raised to abort.

---

DP-003

Condition: FunctionLoad does not contain an entry for FunctionID, OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.

TRUE: The function has not been registered in the current DLL load cycle; proceed with full registration (Steps 4-8).

FALSE: The function is already registered for the current DLL load cycle; skip registration entirely.

---

DP-004

Condition: FunctionName equals 'd2kwutil_DebugString'.

TRUE: Diagnostic logging via DEBUGLOG is suppressed to avoid recursive logging.

FALSE: A DEBUGLOG entry is written, indicating either initial registration or re-registration with the relevant counts.

---

DP-005

Condition: FunctionLoad does not contain an entry for FunctionID at the time of logging (within DP-004 FALSE branch).

TRUE: Log message indicates 'Initial Reg' for the function.

FALSE: Log message indicates 'Re-Registration' and includes the prior load-count value.

---

DP-006

Condition: The remaining FunctionArgs string (after appending a trailing comma) is NULL, equals ',', or equals 'VOID,'.

TRUE: Parameter registration loop exits; no further parameters are registered.

FALSE: The next comma-delimited type token is extracted, translated via D2KWUTIL.TRANSLATETYPE, and registered as a parameter; the loop continues.

---

DP-007

Condition: FunctionReturn is not 'VOID' (case-insensitive) AND FunctionReturn is not NULL.

TRUE: D2KWUTIL.TRANSLATETYPE is called on FunctionReturn and ORA_FFI.REGISTER_RETURN is called to register the return type.

FALSE: No return type is registered (procedure is treated as returning VOID or has no return value).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable or loadable before any function registration can proceed; if neither ORA_FFI.FIND_LIBRARY nor D2KWUTIL.ATTEMPT_DLL_LOAD succeeds, the entire D2KWUTIL API is disabled (API_ENABLED = FALSE) and the calling procedure is aborted via NO_DATA_FOUND.
- BR-002 - A function is registered with the FFI layer only once per DLL load cycle, identified by matching FunctionLoad(FunctionID) to DLL_LOAD_COUNT; if the DLL has been reloaded (counts differ) or the function has never been registered (no entry exists), full re-registration is mandatory.
- BR-003 - All parameter type tokens in FunctionArgs must be passed through D2KWUTIL.TRANSLATETYPE before being supplied to ORA_FFI.REGISTER_PARAMETER, ensuring textual type names are converted to valid FFI type constants.
- BR-004 - The return type is registered only when FunctionReturn is neither NULL nor 'VOID' (case-insensitive); procedures or void-returning functions must not have a return type registered.
- BR-005 - Diagnostic logging via DEBUGLOG is explicitly suppressed for the function named 'd2kwutil_DebugString' to prevent recursive or circular log entries.
- BR-006 - On any unhandled ORA_FFI.FFI_ERROR outside the DLL-load subblock, ADD_ERROR must be called with the FunctionName and a combined error string from ADD_EXTERNAL_ERRORS before NO_DATA_FOUND is raised, ensuring the error context is captured for the calling procedure.
- BR-007 - FunctionArgs is parsed as a comma-delimited list with a synthetic trailing comma appended; a token value of 'VOID' signals that the function accepts no parameters and terminates the registration loop without registering any parameter.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-090 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging session by recording the desired output mode, target file, verbosity level, and timestamp preference into module-level state variables. Depending on the requested debug type, the procedure activates file-based logging, activates message-based logging, or deactivates logging entirely, and confirms the resulting state by invoking DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-084](#SP-084--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Store the incoming TimeStamp flag in the module-level variable bDebugTimeStamp to control whether subsequent log entries include a timestamp.
- Step 2 - Store the incoming DebugFile value in the module-level variable vcDebugFile to record the target log file path for the session.
- Step 3 - Store the incoming DebugLevel value in the module-level variable iDebugLevel to set the verbosity threshold for the session.
- Step 4 - Evaluate DebugType to determine the logging mode to activate (see Decision Points).
- Step 5 - If DebugType = 1, set iDebugState to 1 (file logging) and call DEBUGLOG to confirm 'Logging to File' together with the DebugFile name.
- Step 6 - If DebugType = 2, set iDebugState to 2 (message logging) and call DEBUGLOG to confirm 'Logging Started'.
- Step 7 - For any other DebugType value, call DEBUGLOG to confirm 'Logging Stopped' and then set iDebugState to 0, deactivating logging.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG at level 0 with the message 'Logging to File' concatenated with the DebugFile parameter value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging mode) and invoke DEBUGLOG at level 0 with the message 'Logging Started'.

FALSE: Invoke DEBUGLOG at level 0 with the message 'Logging Stopped', then set iDebugState to 0, disabling all logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 designates file-based logging; the DebugFile parameter must carry the intended file path, as it is stored directly and referenced in the confirmation log entry.
- BR-002 - DebugType = 2 designates message-based logging; no file path is required for this mode.
- BR-003 - Any DebugType value other than 1 or 2 is treated as a request to stop logging; iDebugState is set to 0 and no file or message destination is used.
- BR-004 - The DebugLevel parameter defaults to 98 when not supplied, establishing the verbosity ceiling for the session unless explicitly overridden.
- BR-005 - The TimeStamp parameter defaults to FALSE; timestamp inclusion in log entries is opt-in and must be explicitly requested by the caller.
- BR-006 - The confirmation log entry (via DEBUGLOG) is always written at severity level 0 and attributed to the source identifier 'SetDebug', regardless of the configured DebugLevel.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-091 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: KEY-CLRFRM]
- pt_soq_new_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Returns the current financial year copyright declaration text for display in the form header. The copyright year is determined from the current date: calendar months January through March belong to the previous financial year; all other months use the current calendar year. The returned string is in the format "© YYYY Maruti Suzuki India Limited ".

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The current system date is retrieved.
- Step 2 - If the current month is January, February, or March, the copyright year is set to the previous calendar year (the preceding financial year).
- Step 3 - For all other months, the copyright year is set to the current calendar year.
- Step 4 - The copyright string is assembled in the format "© YYYY Maruti Suzuki India Limited " and returned.

---
**Decision Points**

DP-001

Condition: The current month is January, February, or March (the first quarter of the calendar year, belonging to the previous Indian financial year).

TRUE: The copyright year is set to the current calendar year minus one.

FALSE: The copyright year is set to the current calendar year.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The financial year for copyright purposes runs from April to March; months January through March are attributed to the preceding financial year.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '- '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '- '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-092 - SF_PRINCIPAL_MAP_CD

**Invoked From:**

- SP_GET_CONSUMPTION.prc [StoredProcedure: SP_GET_CONSUMPTION]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

SF_PRINCIPAL_MAP_CD is a scalar function that resolves the principal mapping code (principal_map_cd) for a given dealer mapping code and location. It is invoked by SP_GET_CONSUMPTION to determine the correct principal map code to use during consumption processing, applying a two-level fallback strategy when an exact dealer-and-location match is unavailable.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_dealer_map | number | IN |
| p_loc | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept two input parameters: p_dealer_map (the dealer mapping code) and p_loc (the location code).
- Step 2 - Attempt a precise lookup in AM_DEALER_LOC using both p_dealer_map and p_loc to retrieve principal_map_cd into the local variable lv_pmc.
- Step 3 - If the precise lookup succeeds, proceed directly to Step 6.
- Step 4 - If the precise lookup raises any exception (e.g., no data found), attempt a fallback lookup in AM_DEALER_LOC using p_dealer_map alone, ignoring the location filter, to retrieve principal_map_cd.
- Step 5 - If the fallback lookup also raises any exception, assign the default value 1 to lv_pmc.
- Step 6 - Return lv_pmc to the calling routine (SP_GET_CONSUMPTION).

---
**Decision Points**

DP-001

Condition: A row exists in AM_DEALER_LOC where dealer_map_cd = p_dealer_map AND loc_cd = p_loc.

TRUE: Retrieve principal_map_cd from that row and assign it to lv_pmc; proceed to return.

FALSE: The exact match query raises an exception; proceed to DP-002.

DP-002

Condition: A row exists in AM_DEALER_LOC where dealer_map_cd = p_dealer_map (location filter removed).

TRUE: Retrieve principal_map_cd from that row and assign it to lv_pmc; proceed to return.

FALSE: The fallback query also raises an exception; assign the hard-coded default value 1 to lv_pmc and proceed to return.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
**Business Rules**

- BR-001 - The function first attempts to resolve principal_map_cd using the combination of dealer_map_cd and loc_cd; the location-specific record takes precedence over a dealer-level record.
- BR-002 - If no dealer-and-location record exists, the function falls back to any record in AM_DEALER_LOC matching dealer_map_cd alone, effectively treating the dealer-level principal map code as the default for all unmatched locations.
- BR-003 - If neither a location-specific nor a dealer-level record can be found in AM_DEALER_LOC, the function returns the hard-coded default principal map code of 1, ensuring the calling process always receives a valid, non-null value.
- BR-004 - The function returns a numeric principal_map_cd; the return value is sourced exclusively from AM_DEALER_LOC or the hard-coded default; no other tables or routines are consulted.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_principal_map_cd(p_dealer_map in number,p_loc in varchar2) return number is
lv_pmc am_dealer_loc.principal_map_cd%type;
begin
  begin
  select principal_map_cd into lv_pmc from am_dealer_loc
  where dealer_map_cd=p_dealer_map
  and loc_cd=p_loc;
  exception
  when others then
    BEGIN
    select principal_map_cd into lv_pmc from am_dealer_loc
     where dealer_map_cd=p_dealer_map;
    EXCEPTION WHEN OTHERS THEN
    lv_pmc:=1;
    END;
  end;
  return lv_pmc;
end;

```

#### SP-093 - SP_CALCULATE_SOQ_NEW

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

SUGGESTED ORDER QUANTITY PROCESSING (N/A / CN_MAIN)

---

**Purpose**

Calculates and persists the Suggested Order Quantity (SOQ) for a dealer location. The procedure clears any previously staged SOQ data for the parent group and location, then rebuilds it in two passes: a bulk insert for non-seasonal parts sourced from PM_PART_DTL, followed by a row-by-row calculation for seasonal parts that calls SP_GET_CONSUMPTION to derive demand from prior-year consumption windows. Finally, it aggregates the per-location SOQ rows into a consolidated multi-location SOQ record in PT_SOQ_MUL_NEW, applying stock-on-hand, on-order, reorder-level, and minimum-order-quantity rounding rules before committing the results.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_principal | NUMBER | IN |
| pi_dealer | NUMBER | IN |
| pi_parent | VARCHAR2 | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_user | VARCHAR2 | IN |
| pi_ason_dt | DATE | IN |
| pi_consg_cd | am_dealer_loc.consg_cd%TYPE | IN |
| pi_abc_str | VARCHAR2 | IN |
| pi_months | NUMBER | IN |
| pi_consump_type | VARCHAR2 | IN |
| pi_part_categ | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_errmsg | VARCHAR2 | OUT |
| po_errcd | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-009](#SP-009--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- SP_GET_CONSUMPTION ([SP-094](#SP-094--SP_GET_CONSUMPTION)) - standalone source file
- WEBUTIL.EXECUTE ([SP-037](#SP-037--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise output parameters (po_errcd = 0) and delete all existing PT_SOQ_NEW rows for the supplied parent group, then delete PT_SOQ_MUL_NEW rows for the specific dealer, parent group, and location, ensuring a clean slate before recalculation.
- Step 2 - Retrieve the Service Level Factor (SLF), Lead Time, and Order Cycle from AM_DEALER_LOC_PARAM for the dealer/parent-group/location combination; raise a descriptive error and abort if any of the three values is missing or if the query returns no row, multiple rows, or a value-error.
- Step 3 - Perform a dynamic bulk INSERT into PT_SOQ_NEW for all non-seasonal, non-VOR, multi-location-eligible parts (mul_yn = 'Y', seasonal_yn = 'N', vor_yn = 'N') whose ABC class matches the supplied pi_abc_str filter. If pi_consg_cd is not null the source query joins PM_PART_DTL to AM_DEALER_LOC on consignment code; otherwise it filters PM_PART_DTL directly by dealer and location. SOQ quantity and on-hand quantity are seeded as zero at this stage; order cycle and lead time retrieved in Step 2 are written into each row.
- Step 4 - Open a dynamic cursor over PM_PART_DTL for seasonal parts (seasonal_yn = 'Y', soq_yn = 'Y', mul_yn = 'Y', avg_consumption > 0) applying the same ABC-class and category filters, again branching on whether pi_consg_cd is populated.
- Step 5 - For each seasonal part fetched, query PM_PART_VAR to determine the season window (season_from, season_to). If season_from <= season_to the season is within a single calendar year; if season_from > season_to the season spans a year boundary. A fallback query handles the cross-year case when the first query returns no data.
- Step 6 - Calculate the season duration in months (MONTHS_BETWEEN + 1) using AM_DUAL, then check whether pi_ason_dt falls within the two-month pre-season ordering window (ld_from to ld_to).
- Step 7 - Based on the combination of season direction (from < to, from > to, from = to) and whether the as-on date is inside the ordering window (ln_cnt > 0 or <= 0), adjust ld_seas_from and ld_seas_to to the corresponding prior-year consumption period and call SP_GET_CONSUMPTION to retrieve historical stock consumption for the part. For out-of-season scenarios, ln_months is recalculated to reflect non-seasonal months (12 - season length).
- Step 8 - Derive the seasonal SOQ as ln_avg_demand / ln_order_cycle and INSERT the result into PT_SOQ_NEW with the calculated SOQ, stock, on-order, and season-duration values.
- Step 9 - Open cursor cur_soq over PT_SOQ_NEW joined to AM_DEALER_LOC, grouping by part number and root part number for the parent group and generating location, filtered to rows with avg_consumption > 0 and matching the consignment code where applicable.
- Step 10 - For each aggregated part row, fetch the current on-hand stock from PM_PART_VAR joined to PM_PART via root_part_num; use the consignment-code path when pi_consg_cd is not null, otherwise filter by principal and dealer. Default to zero on any exception.
- Step 11 - Retrieve the ABC class and FSN indicator for the latest part number from PM_PART_VAR for the generating location; suppress NO_DATA_FOUND (part may not exist at the generating location) but raise on TOO_MANY_ROWS, VALUE_ERROR, or other exceptions.
- Step 12 - If avg_consumption is zero, set SOQ, min, max, reorder, and inventory levels all to zero. Otherwise compute the Order Cycle Factor (1 / ln_order_cycle), derive the effective inventory position (ln_xfact = stock + on_order - backorder_qty), and calculate SOQ as max_stock - stock - on_order + backorder_qty when the order cycle factor is less than 1 and the inventory position is at or below the reorder level. Round SOQ to the nearest whole number.
- Step 13 - If the inventory position exceeds the reorder level, set SOQ to zero. Otherwise round SOQ up to the nearest multiple of the minimum order quantity (lv_pack_qty) using ROUND(ln_soq / lv_pack_qty, 0) × lv_pack_qty.
- Step 14 - INSERT the consolidated SOQ row into PT_SOQ_MUL_NEW with all computed stock, demand, and SOQ values.
- Step 15 - COMMIT on successful completion. On any ex_error exception, set po_errcd = 1 and ROLLBACK. On unhandled exceptions, populate po_errmsg with diagnostic context (part number, step, SQLERRM), set po_errcd = 1, and ROLLBACK.

---
**Decision Points**

DP-001
Condition: pi_consg_cd IS NOT NULL
TRUE: The dynamic INSERT into PT_SOQ_NEW (non-seasonal pass) uses a query that joins PM_PART_DTL to AM_DEALER_LOC on consignment code and filters by pi_consg_cd, allowing multi-dealer consignment scenarios.
FALSE: The dynamic INSERT filters PM_PART_DTL directly by pi_dealer and pi_loc_cd without a consignment join.

DP-002
Condition: Any of ln_slf, ln_lead_time, or ln_order_cycle IS NULL after reading AM_DEALER_LOC_PARAM
TRUE: A descriptive error message is set in po_errmsg and ex_error is raised, aborting the procedure.
FALSE: Processing continues with the retrieved parameter values.

DP-003
Condition: pi_consg_cd IS NOT NULL (seasonal cursor open)
TRUE: The seasonal parts cursor query filters PM_PART_DTL by pi_consg_cd.
FALSE: The seasonal parts cursor query filters PM_PART_DTL by pi_dealer, pi_loc_cd.

DP-004
Condition: season_from <= season_to (season within same calendar year)
TRUE: Season is treated as an intra-year window; ordering window and prior-year consumption dates are calculated accordingly.
FALSE: Falls through to the season_from > season_to or season_from = season_to branches for cross-year or single-month seasons.

DP-005
Condition: ln_cnt > 0 (pi_ason_dt falls within the two-month pre-season ordering window)
TRUE: The prior-year seasonal consumption period is used for SP_GET_CONSUMPTION; ln_months retains the season duration.
FALSE: The non-seasonal consumption period is used; ln_months is recalculated as 12 - season length for applicable branches.

DP-006
Condition: lv_seas_from < lv_seas_to AND ln_cnt > 0
TRUE: Shift ld_seas_from back one month and ld_seas_to back 12 months; call SP_GET_CONSUMPTION for the seasonal window.
FALSE: Evaluate next branch (lv_seas_from < lv_seas_to AND ln_cnt <= 0).

DP-007
Condition: lv_seas_from < lv_seas_to AND ln_cnt <= 0
TRUE: Set ld_seas_from to one day before current season start and ld_seas_to back 12 months; recalculate ln_months as non-seasonal duration; call SP_GET_CONSUMPTION.
FALSE: Evaluate next branch (lv_seas_from > lv_seas_to AND ln_cnt > 0).

DP-008
Condition: lv_seas_from > lv_seas_to AND ln_cnt > 0
TRUE: Shift both ld_seas_from and ld_seas_to back 12 months; call SP_GET_CONSUMPTION.
FALSE: Evaluate next branch (lv_seas_from > lv_seas_to AND ln_cnt <= 0).

DP-009
Condition: lv_seas_from > lv_seas_to AND ln_cnt <= 0
TRUE: Set ld_seas_from to one day before current season start, ld_seas_to back 12 months; recalculate ln_months as 12 - season length; call SP_GET_CONSUMPTION.
FALSE: Evaluate next branch (lv_seas_from = lv_seas_to).

DP-010
Condition: lv_seas_from = lv_seas_to AND ln_cnt > 0
TRUE: Shift both dates back 12 months; call SP_GET_CONSUMPTION.
FALSE: Evaluate final branch (lv_seas_from = lv_seas_to AND ln_cnt <= 0): shift ld_seas_from back 12 months and ld_seas_to back 12 months minus one day; call SP_GET_CONSUMPTION.

DP-011
Condition: ln_avg_demand = 0 (aggregated part has no consumption)
TRUE: SOQ, min stock, max stock, reorder level, and inventory level are all set to zero; no PT_SOQ_MUL_NEW row is inserted for this part.
FALSE: Proceed with SOQ calculation using order cycle factor, reorder level, and stock position.

DP-012
Condition: ln_xfact (stock + on_order - backorder) > ln_reorder_lvl
TRUE: SOQ is set to zero (inventory position is above reorder level; no replenishment needed).
FALSE: SOQ is retained and rounded to the nearest multiple of lv_pack_qty before insertion into PT_SOQ_MUL_NEW.

DP-013
Condition: ln_oc_fact < 1 AND ln_xfact <= ln_reorder_lvl
TRUE: SOQ is calculated as max_stock - stock - on_order + backorder_qty.
FALSE: SOQ retains the value carried from the PT_SOQ_NEW aggregation (ln_soq from cursor fetch).

DP-014
Condition: (ln_soq MOD lv_pack_qty) <> 0
TRUE: SOQ is rounded to the nearest whole multiple of lv_pack_qty using ROUND(ln_soq / lv_pack_qty, 0) × lv_pack_qty.
FALSE: SOQ is already an exact multiple of lv_pack_qty; no adjustment is made.

DP-015
Condition: pi_consg_cd IS NOT NULL (on-hand stock fetch in consolidated SOQ loop)
TRUE: On-hand stock is summed from PM_PART_VAR joined to PM_PART and AM_DEALER_LOC, filtered by pi_consg_cd.
FALSE: On-hand stock is summed from PM_PART_VAR joined to PM_PART, filtered by pi_principal, pi_dealer, and pi_loc_cd.

---
**Database Interactions**

- DB-001 - Delete from PT_SOQ_NEW - Deletes rows from PT_SOQ_NEW.
- DB-002 - Delete from PT_SOQ_MUL_NEW - Deletes rows from PT_SOQ_MUL_NEW.
- DB-003 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-004 - Insert into SOQ - Persists a new row into SOQ.
- DB-005 - Insert into PT_SOQ_NEW - Persists a new row into PT_SOQ_NEW using columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 20 more column(s).
- DB-006 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
- DB-007 - Read PM_PART_DTL - Reads data from PM_PART_DTL for lookup or validation.
- DB-008 - Read AM_DUAL - Reads data from AM_DUAL for lookup or validation.
- DB-009 - Read PT_SOQ_NEW - Reads data from PT_SOQ_NEW (columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 20 more column(s)) for lookup or validation.
- DB-010 - Insert into PT_SOQ_MUL_NEW - Persists a new row into PT_SOQ_MUL_NEW using columns: dealer map cd, part class, part num, as on date, no of months, soq qty, on hand qty, on order qty, and 18 more column(s).
**Business Rules**

- BR-001 - All existing PT_SOQ_NEW rows for the parent group and all PT_SOQ_MUL_NEW rows for the dealer/parent-group/location are purged before recalculation, ensuring the SOQ reflects only the current run's inputs.
- BR-002 - SLF factor, Lead Time, and Order Cycle must all be defined and non-null in AM_DEALER_LOC_PARAM for the dealer/parent-group/location; absence of any one value is a hard error that aborts processing.
- BR-003 - Only parts flagged as non-VOR (vor_yn = 'N') and eligible for multi-location SOQ (mul_yn = 'Y') are included in the SOQ calculation.
- BR-004 - Non-seasonal parts (seasonal_yn = 'N') are bulk-inserted into PT_SOQ_NEW with SOQ and on-hand quantities initialised to zero; their final SOQ is derived in the consolidated aggregation pass.
- BR-005 - Seasonal parts (seasonal_yn = 'Y') are included only when they have a positive average consumption (avg_consumption > 0) and are marked for SOQ generation (soq_yn = 'Y').
- BR-006 - For seasonal parts, the consumption reference period is always shifted to the equivalent window in the prior year; the specific prior-year window depends on whether the season spans a single calendar year or crosses a year boundary, and whether the as-on date falls within the two-month pre-season ordering window.
- BR-007 - The seasonal SOQ is calculated as average demand divided by the order cycle (ln_avg_demand / ln_order_cycle).
- BR-008 - The consolidated SOQ is only computed and written to PT_SOQ_MUL_NEW for parts with positive aggregated average consumption; parts with zero consumption receive zero SOQ and are excluded from PT_SOQ_MUL_NEW.
- BR-009 - The effective inventory position used in SOQ calculation is stock on hand plus on-order quantity minus customer back-order quantity (ln_xfact = ln_stock + ln_on_order - lv_backorder_qty).
- BR-010 - When the order cycle factor is less than 1 and the inventory position is at or below the reorder level, SOQ is set to max_stock - stock - on_order + backorder_qty, rounded to the nearest whole number.
- BR-011 - When the inventory position exceeds the reorder level, SOQ is forced to zero regardless of other calculated values.
- BR-012 - The final SOQ must be a whole multiple of the part's minimum order quantity (lv_pack_qty); if it is not, it is rounded to the nearest multiple using ROUND(ln_soq / lv_pack_qty, 0) × lv_pack_qty.
- BR-013 - On-hand stock for the consolidated SOQ is derived from PM_PART_VAR aggregated across all part variants sharing the same root part number, scoped to the correct consignment or dealer/location context.
- BR-014 - If the ABC class and FSN indicator cannot be found in PM_PART_VAR for the generating location, processing continues with null values rather than raising an error, because the generating location may not stock every part.
- BR-015 - The entire calculation is atomic: a successful run ends with a COMMIT, while any business or system error triggers a ROLLBACK and returns po_errcd = 1 with a descriptive po_errmsg.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE Sp_Calculate_Soq_New
/*
$Log: SP_CALCULATE_SOQ_NEW.SQL,v $
*/
(
      pi_principal      IN       NUMBER,
      pi_dealer         IN       NUMBER,
      pi_parent         IN       VARCHAR2,
      pi_loc_cd         IN       VARCHAR2,
      pi_comp_fa        IN       VARCHAR2,
      pi_user           IN       VARCHAR2,
      pi_ason_dt        IN       DATE,
      --pi_loc_tab        IN       Pk_Plsql_Table.code_tab2,  --Commented by Anjiv on 18/07/2007
      --Pk_Plsql_Table.code_tab, --Changed by Anjiv on 29/11/2006 to pass dealer_map_cd along with loc_cd
      pi_consg_cd       IN       am_dealer_loc.consg_cd%TYPE,
      pi_abc_str        IN       VARCHAR2,
      pi_months         IN       NUMBER,
      pi_consump_type   IN       VARCHAR2,
      pi_part_categ     IN       VARCHAR2,
      po_errmsg         OUT      VARCHAR2,
      po_errcd          OUT      NUMBER
)
AS
      lv_sql             VARCHAR2 (4000);
      cur_part           sys_refcursor;
      cur_soq            sys_refcursor;
      lv_part_num        pm_part.part_num%TYPE;
      lt_consumption     Pk_Plsql_Table.num_tab;
      lv_latest_part     pm_part.part_num%TYPE;
      ln_part_price      pm_part.sell_price%TYPE                   := 0;
      lv_pack_qty        pm_part.min_ord_qty%TYPE;                     --added on 24-dec to make soq to multiple of min order qty
      lv_backorder_qty   pm_part_var.cust_order_qty%TYPE;                               --added on 24-dec  to consider back order
      lv_part_desc       pm_part.part_desc%TYPE;
      lv_part_class      pm_part_var.abc_ind%TYPE;
      lv_fsn_ind         pm_part_var.fsn_ind%TYPE;
      ln_stock           pm_stock.ls_stock_qty%TYPE                := 0;
      ln_on_order        pm_part_var.on_order_qty%TYPE             := 0;
      ld_date            DATE;
      lv_errmsg          VARCHAR2 (1000);
      ln_errcd           NUMBER                                    := 0;
      ex_error           EXCEPTION;
      ln_day             NUMBER                                    := 0;
      ln_year            NUMBER                                    := 0;
      ln_mth             NUMBER                                    := 0;
      ln_rem             NUMBER                                    := 0;
      ln_trunc_val       pm_soq_factor.VALUE%TYPE                  := 0;
      ln_alpha_val       pm_soq_factor.VALUE%TYPE                  := 0;
      ln_beta_val        pm_soq_factor.VALUE%TYPE                  := 0;
      ln_avg_demand      NUMBER (11, 2)                            := 0;
      ln_max_demand      NUMBER (11, 2)                            := 0;
      ln_std_deviation   NUMBER (11, 2)                            := 0;
      ln_slf             am_dealer_loc_param.sp_slf_factor%TYPE    := 0;
      ln_lead_time       am_dealer_loc_param.sp_lead_time%TYPE     := 0;
      ln_order_cycle     am_dealer_loc_param.sp_order_cycle%TYPE   := 0;
      ln_oc_fact         NUMBER                                    := 0;                                     --Order Cycle Factor
      ln_min_lvl         pt_soq.min_stock%TYPE                     := 0;
      ln_max_lvl         pt_soq.max_stock%TYPE                     := 0;
      ln_reorder_lvl     pt_soq.safety_stock%TYPE                  := 0;
      ln_inv_lvl         pt_soq.inv_qty%TYPE                       := 0;
      ln_xfact           pm_stock.ls_stock_qty%TYPE                := 0;
      ln_soq             pt_soq.soq_qty%TYPE                       := 0;
      ln_tmax_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_tmax_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      ln_tmin_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_tmin_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      ln_amax_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_amax_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      ln_amin_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_amin_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      ln_bmax_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_bmax_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      ln_bmin_cost       pm_soq_factor.COST%TYPE                   := 0;
      ln_bmin_dbar       pm_soq_factor.dbar%TYPE                   := 0;
      l_max_seq_num      pm_part.seq_num%TYPE                      := 0;
      cur_seas_part      sys_refcursor;
      ld_from            DATE;
      ld_to              DATE;
      ln_cnt             NUMBER                                    := 0;
      ld_seas_from       DATE;
      ld_seas_to         DATE;
      lv_seas_from       NUMBER;
      lv_seas_to         NUMBER;
      ln_months          NUMBER                                    := 0;
      lv_count           NUMBER                                    := 0;
      lv_step            VARCHAR2 (1000)                           := 'Start';
      lv_dealer          am_dealer_loc.dealer_map_cd%TYPE;
      lv_loc_cd          am_dealer_loc.loc_cd%TYPE;
      lv_root_part_num   pm_part.root_part_num%TYPE;
BEGIN
      po_errcd := 0;

      --  DBMS_OUTPUT.PUT_LINE('AS ON DATE'||pi_ason_dt);/* Deleting existing rows of current dealer from soq tables */
/*      IF pi_consg_cd IS NOT NULL THEN
            DELETE FROM pt_soq_new
                  WHERE --dealer_map_cd = pi_dealer AND
          parent_group = pi_parent AND gen_loc = pi_loc_cd;
      ELSE
            DELETE FROM pt_soq_new
                  WHERE dealer_map_cd = pi_dealer AND parent_group = pi_parent AND loc_cd = pi_loc_cd;
      END IF;*/

      DELETE FROM pt_soq_new
                  WHERE parent_group = pi_parent;

      DELETE FROM pt_soq_mul_new
            WHERE dealer_map_cd = pi_dealer AND parent_group = pi_parent AND loc_cd = pi_loc_cd;

      /* Get the SLF,Lead Time, Order Cycle from the system parameters table */
       --In the following query on 07/06,location reference is changed from p_loc_tab(i) to pi_loc_cd
              --because ,only soq generating location will have alpha,beta,cost,demand values
      BEGIN
            SELECT sp_slf_factor,
                   sp_lead_time,
                   sp_order_cycle
              INTO ln_slf,
                   ln_lead_time,
                   ln_order_cycle
              FROM am_dealer_loc_param
             WHERE dealer_map_cd = pi_dealer AND parent_group = pi_parent AND loc_cd = pi_loc_cd;

            IF ln_slf IS NULL THEN
                  po_errmsg := 'SLF factor is not defined in the location' || pi_loc_cd;
                  RAISE ex_error;
            ELSIF ln_lead_time IS NULL THEN
                  po_errmsg := 'Lead Time is not defined in the location' || pi_loc_cd;
                  RAISE ex_error;
            ELSIF ln_order_cycle IS NULL THEN
                  po_errmsg := 'Order Cycle is not defined in the location' || pi_loc_cd;
                  RAISE ex_error;
            END IF;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_errmsg := 'SLF, Lead Time, and Order Cycle are not defined for ' || pi_loc_cd;
                  RAISE ex_error;
            WHEN TOO_MANY_ROWS THEN
                  po_errmsg := 'More than one order cycle found for location' || pi_loc_cd;
                  RAISE ex_error;
            WHEN VALUE_ERROR THEN
                  po_errmsg := 'Width problem/Incompatible Data while fetching order cycle for location' || pi_loc_cd;
                  RAISE ex_error;
            WHEN ex_error THEN
                  RAISE ex_error;
            WHEN OTHERS THEN
                  po_errmsg := 'Execution failed for fetching order cycle -' || SQLERRM || pi_loc_cd;
                  RAISE ex_error;
      END;

      --pi_abc_str := '('||pi_abc_str ||')';
                  /* insert into soq table */
      BEGIN
            --IF pi_loc_tab.COUNT > 0 THEN
            IF pi_consg_cd IS NOT NULL THEN
                  lv_sql :=
                           'INSERT INTO pt_soq_new
                          (dealer_map_cd,
                           part_class,
                           part_num,
                           as_on_date,
                           no_of_months,
                           soq_qty,
                           on_hand_qty,
                           on_order_qty,
                           safety_stock,
                           order_cycle,
                           min_stock,
                           max_stock,
                           fsn_ind,
                           lead_time,
                           cust_order_qty,
                           created_by,
                           created_date,
                           part_desc,
                           parent_group,
                           loc_cd,
                           inv_qty,
                           amd_soq_qty,
                           gen_loc,
                           comp_fa,
                           avg_consumption,
                           stock_qty,
                     min_ord_qty,
                     ROOT_PART_NUM
                          )
                    SELECT ppd.dealer_map_cd,
                           ppd.abc_ind,
                           ppd.latest_part_num,
                           :pi_ason_dt,
                           :pi_months,
                           0,
                           0,/*NVL ( (SELECT SUM ( on_hand_qty)
                                    FROM PM_PART_VAR pmv1, PM_PART pm1
                                   WHERE pmv1.parent_group = ppd.parent_group
                                     AND pmv1.dealer_map_cd = ppd.dealer_map_cd
                                     AND pmv1.loc_cd = ppd.loc_cd
                                     AND pmv1.part_num = pm1.part_num
                                     AND pm1.root_part_num = ppd.root_part_num
                                     AND pm1.dealer_map_cd = 1                                                       --IN (1, pmv.dealer_map_cd)
                                                              ),
                                 0
                               ) on_hand_qty,
                       */
                           NVL ( ppd.on_order_qty, 0),
                           NVL ( ppd.reorder_lvl, 0),
                           :order_cycle,
                           NVL ( ppd.min_lvl, 0),
                           NVL ( ppd.max_lvl, 0),
                           ppd.fms_ind,
                           :lead_time,
                           NVL ( ppd.cust_order_qty, 0),
                           :pi_user,
                           SYSDATE,
                           ppd.part_desc,
                           :pi_parent,
                           ppd.loc_cd,
                           NVL ( ppd.inv_lvl, 0),
                           0,
                           :pi_loc_cd,
                           :pi_comp_fa,
                           NVL ( ppd.avg_consumption, 0) avg_consumption,
                           0,
                     ppd.min_ord_qty,
                     PPD.ROOT_PART_NUM
                      FROM PM_PART_DTL ppd, AM_DEALER_LOC am
                     WHERE ppd.parent_group = :pi_parent
                       AND ppd.catg_cd = :pi_part_categ
                   AND ppd.consg_cd =:pi_consg_cd
                       AND ppd.vor_yn = ''N''
                       AND ppd.seasonal_yn = ''N''
                       AND NVL ( ppd.abc_ind, '' '') IN ('
                        || pi_abc_str
                        || '            )
                       AND ppd.mul_yn = ''Y''
                   AND ppd.parent_group=am.parent_group
                   AND ppd.dealer_map_cd=am.dealer_map_cd
                   AND ppd.loc_cd=am.loc_cd
                   AND ppd.consg_cd=am.consg_cd ';

                  EXECUTE IMMEDIATE lv_sql
                              USING pi_ason_dt,
                                    pi_months,
                                    ln_order_cycle,
                                    ln_lead_time,
                                    pi_user,
                                    pi_parent,
                                    pi_loc_cd,
                                    pi_comp_fa,
                                    pi_parent,
                                    pi_part_categ,
                                    pi_consg_cd;
            ELSE
                  lv_sql :=
                           'INSERT INTO pt_soq_new
                        (dealer_map_cd,
                         part_class,
                         part_num,
                         as_on_date,
                         no_of_months,
                         soq_qty,
                         on_hand_qty,
                         on_order_qty,
                         safety_stock,
                         order_cycle,
                         min_stock,
                         max_stock,
                         fsn_ind,
                         lead_time,
                         cust_order_qty,
                         created_by,
                         created_date,
                         part_desc,
                         parent_group,
                         loc_cd,
                         inv_qty,
                         amd_soq_qty,
                         gen_loc,
                         comp_fa,
                         avg_consumption,
                         stock_qty,
                   min_ord_qty,
                   ROOT_PART_NUM
                        )
                  SELECT ppd.dealer_map_cd,
                         ppd.abc_ind,
                         ppd.latest_part_num,
                         :pi_ason_dt,
                         :pi_months,
                         0,
                   0,
                         /*NVL ( (SELECT SUM ( on_hand_qty)
                                  FROM PM_PART_VAR pmv1, PM_PART pm1
                                 WHERE pmv1.parent_group = ppd.parent_group
                                   AND pmv1.dealer_map_cd = ppd.dealer_map_cd
                                   AND pmv1.loc_cd = ppd.loc_cd
                                   AND pmv1.part_num = pm1.part_num
                                   AND pm1.root_part_num = ppd.root_part_num
                                   AND pm1.dealer_map_cd = 1                                                       --IN (1, pmv.dealer_map_cd)
                                                            ),
                               0
                             ) on_hand_qty,
                  */
                         NVL ( ppd.on_order_qty, 0),
                         NVL ( ppd.reorder_lvl, 0),
                         :order_cycle,
                         NVL ( ppd.min_lvl, 0),
                         NVL ( ppd.max_lvl, 0),
                         ppd.fms_ind,
                         :lead_time,
                         NVL ( ppd.cust_order_qty, 0),
                         :pi_user,
                         SYSDATE,
                         ppd.part_desc,
                         :pi_parent,
                         ppd.loc_cd,
                         NVL ( ppd.inv_lvl, 0),
                         0,
                         :pi_loc_cd,
                         :pi_comp_fa,
                         NVL ( ppd.avg_consumption, 0) avg_consumption,
                         0,
                   ppd.min_ord_qty,
                   PPD.ROOT_PART_NUM
                    FROM PM_PART_DTL ppd
                   WHERE ppd.parent_group = :pi_parent
                     AND ppd.catg_cd = :pi_part_categ
                     AND ppd.dealer_map_cd = :pi_dealer
                     AND ppd.loc_cd = :pi_loc_cd
                     AND ppd.vor_yn = ''N''
                     AND ppd.seasonal_yn = ''N''
                     AND NVL ( ppd.abc_ind, '' '') IN ('
                        || pi_abc_str
                        || '            )
                     AND ppd.mul_yn = ''Y''';

                  EXECUTE IMMEDIATE lv_sql
                              USING pi_ason_dt,
                                    pi_months,
                                    ln_order_cycle,
                                    ln_lead_time,
                                    pi_user,
                                    pi_parent,
                                    pi_loc_cd,
                                    pi_comp_fa,
                                    pi_parent,
                                    pi_part_categ,
                                    pi_dealer,
                                    pi_loc_cd;
            END IF;
      EXCEPTION
            WHEN ex_error THEN
                  RAISE ex_error;
            WHEN OTHERS THEN
                  po_errmsg := 'Error in inserting into SOQ for part ' || lv_part_num || ' :' || SQLERRM;
                  RAISE ex_error;
      END;

      lv_step := 'After PT SOQ Insert';
      lv_step := 'Before Seasonal Part';
      -- for each location

      /*-- Seasonal Soq process --*/
      ln_part_price := 0;
      ln_stock := 0;
      ln_on_order := 0;
      ln_soq := 0;
      ln_avg_demand := 0;

      --IF pi_loc_tab.COUNT > 0 THEN
      IF pi_consg_cd IS NOT NULL THEN
            lv_sql :=
                     'SELECT   ppd.dealer_map_cd,
                     ppd.loc_cd,
                     ppd.root_part_num,
                   ppd.latest_part_num,
                   ppd.part_desc,
                   ppd.min_ord_qty,
                 ppd.purchase_price,
                   ppd.abc_ind,
                   ppd.fms_ind,
                 NVL ( ppd.avg_consumption, 0) avg_consumption,
                            NVL ( ppd.on_order_qty, 0) on_order_qty,
                 NVL ( ppd.std_dev, 0) std_dev,
                 NVL ( ppd.cust_order_qty, 0) cust_order_qty,
                 NVL ( ppd.min_lvl, 0) min_lvl,
                 NVL ( ppd.max_lvl, 0) max_lvl,
                 NVL ( ppd.inv_lvl, 0) inv_lvl,
                 NVL ( ppd.reorder_lvl, 0) reorder_lvl,
                 ppd.min_ord_qty
              FROM PM_PART_DTL ppd
             WHERE ppd.parent_group = :p_parent
               AND ppd.catg_cd = :p_part_categ
               AND ppd.consg_cd=:p_consg_cd
               AND ppd.vor_yn =''N''
               AND ppd.seasonal_yn =''Y''
               AND NVL(ppd.abc_ind,'' '') IN ('
                  || pi_abc_str
                  || ')
               AND NVL ( ppd.avg_consumption, 0) > 0
               AND ppd.soq_yn = ''Y''
               AND ppd.mul_yn=''Y''';

            OPEN cur_seas_part
             FOR lv_sql USING pi_parent, pi_part_categ, pi_consg_cd;
      ELSE
            lv_sql :=
                     'SELECT   ppd.dealer_map_cd,
                     ppd.loc_cd,
                     ppd.root_part_num,
                   ppd.latest_part_num,
                   ppd.part_desc,
                   ppd.min_ord_qty,
                 ppd.purchase_price,
                   ppd.abc_ind,
                   ppd.fms_ind,
                 NVL ( ppd.avg_consumption, 0) avg_consumption,
                            NVL ( ppd.on_order_qty, 0) on_order_qty,
                 NVL ( ppd.std_dev, 0) std_dev,
                 NVL ( ppd.cust_order_qty, 0) cust_order_qty,
                 NVL ( ppd.min_lvl, 0) min_lvl,
                 NVL ( ppd.max_lvl, 0) max_lvl,
                 NVL ( ppd.inv_lvl, 0) inv_lvl,
                 NVL ( ppd.reorder_lvl, 0) reorder_lvl,
                 ppd.min_ord_qty
              FROM PM_PART_DTL ppd
             WHERE ppd.dealer_map_cd = :p_dealer
               AND ppd.parent_group = :p_parent
               AND ppd.loc_cd = :p_loc
               AND ppd.catg_cd = :p_part_categ
               AND ppd.vor_yn =''N''
               AND ppd.seasonal_yn =''Y''
               AND NVL(ppd.abc_ind,'' '') IN ('
                  || pi_abc_str
                  || ')
               AND NVL ( ppd.avg_consumption, 0) > 0
               AND ppd.soq_yn = ''Y''
               AND ppd.mul_yn=''Y''';

            OPEN cur_seas_part
             FOR lv_sql USING pi_dealer, pi_parent, pi_loc_cd, pi_part_categ;
      END IF;

      LOOP
            FETCH cur_seas_part
             INTO lv_dealer,
                  lv_loc_cd,
                  lv_part_num,
                  lv_latest_part,
                  lv_part_desc,
                  lv_pack_qty,
                  ln_part_price,
                  lv_part_class,
                  lv_fsn_ind,
                  ln_avg_demand,
                  ln_on_order,
                  ln_std_deviation,
                  lv_backorder_qty,
                  ln_min_lvl,
                  ln_max_lvl,
                  ln_inv_lvl,
                  ln_reorder_lvl,
                  lv_pack_qty;

            EXIT WHEN cur_seas_part%NOTFOUND OR cur_seas_part%FOUND IS NULL;

            IF cur_seas_part%FOUND THEN
                  /*Get the seasonStart, seasonEnd and other details of latest part
                  --ld_from is 2 months before seasonStart, ld_to is 2 months before seasonEnd
                  -- if seasonFrom is greater than seasonTo then seasonFrom belongs to previous year*/
                  BEGIN
                        SELECT ADD_MONTHS (TO_DATE (season_from, 'MM'), -2),
                               ADD_MONTHS (TO_DATE (season_to, 'MM'), -1) - 1,
                               TO_DATE (season_from, 'MM'),
                               TO_DATE (season_to, 'MM'),
                               abc_ind,
                               fsn_ind,
                               season_from,
                               season_to
                          INTO ld_from,
                               ld_to,
                               ld_seas_from,
                               ld_seas_to,
                               lv_part_class,
                               lv_fsn_ind,
                               lv_seas_from,
                               lv_seas_to
                          FROM pm_part_var
                         WHERE dealer_map_cd = lv_dealer
                           AND parent_group = pi_parent
                           AND loc_cd = lv_loc_cd
                           AND part_num = lv_latest_part
                           AND season_from <= season_to;
                  EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                              BEGIN
                                    SELECT ADD_MONTHS (TO_DATE (season_from, 'MM'), -2),
                                           ADD_MONTHS (TO_DATE (season_to, 'MM'), 11) - 1,
                                           ADD_MONTHS (TO_DATE (season_from, 'MM'), -12),
                                           TO_DATE (season_to, 'MM'),
                                           abc_ind,
                                           fsn_ind,
                                           season_from,
                                           season_to
                                      INTO ld_from,
                                           ld_to,
                                           ld_seas_from,
                                           ld_seas_to,
                                           lv_part_class,
                                           lv_fsn_ind,
                                           lv_seas_from,
                                           lv_seas_to
                                      FROM pm_part_var
                                     WHERE dealer_map_cd = lv_dealer
                                       AND parent_group = pi_parent
                                       AND loc_cd = lv_loc_cd
                                       AND part_num = lv_latest_part;
                              EXCEPTION
                                    WHEN NO_DATA_FOUND THEN
                                          po_errmsg := 'Latest seasonal part details not found for ' || lv_part_num;
                                          RAISE ex_error;
                                    WHEN OTHERS THEN
                                          po_errmsg :=
                                                   'Error in getting latest seasonal part details for '
                                                || lv_part_num
                                                || ' :'
                                                || SQLERRM;
                                          RAISE ex_error;
                              END;
                        WHEN OTHERS THEN
                              po_errmsg := 'Error in getting latest seasonal part details for ' || lv_part_num || ' :' || SQLERRM;
                              RAISE ex_error;
                  END;

                  --Get the duration of the season
                  SELECT ABS ( MONTHS_BETWEEN (ld_seas_to, ld_seas_from))
                    INTO ln_months
                    FROM am_dual;

                  ln_months := ln_months + 1;

                  --  DBMS_OUTPUT.PUT_LINE('DIFFERENCE BETWEEN FROM AND TO'||ln_months);
                  /*To check whether the order is raised between 2 months before seasonStart and
                  -- 2 months before seasonEnd. If yes, consumption during the season is considered.
                  -- If no, consumption during the rest of the year is considered.*/
                  SELECT COUNT (1)
                    INTO ln_cnt
                    FROM am_dual
                   WHERE pi_ason_dt BETWEEN TO_DATE (TO_CHAR (ld_from, 'DD-MM-RRRR'), 'DD-MM-RRRR')
                                        AND TO_DATE (TO_CHAR (ld_to, 'DD-MM-RRRR'), 'DD-MM-RRRR');

                  -- dbms_output.put_line('u r in process period(1) or zero'||ln_cnt);
                            -- To get consumption of previous year
                  IF lv_seas_from < lv_seas_to AND ln_cnt > 0 THEN
--                            order placed within two months and season start and end in same year
                        SELECT ADD_MONTHS (ld_seas_from, -1),
                               ADD_MONTHS (ld_seas_to, -12)
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );
                  ELSIF lv_seas_from < lv_seas_to AND ln_cnt <= 0 THEN
                        -- order placed not within seasonal months and season start and end in same year
                        ln_months := 12 - ln_months;

                        --ln_months indicate the non-seasonal months in year
                        --So if we processing on non seasonal month then we should prefer what is the consumption
                        --in non seasonal months
                        -- To get consumption of previous year
                        SELECT ADD_MONTHS (ld_seas_from, 0) - 1,
                               ADD_MONTHS (ld_seas_to, -12)
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        --To be checked
                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );

                        IF ln_errcd <> 0 THEN
                              po_errmsg :=
                                         'Error in getting seasonal consumption details for ' || lv_part_num || ' :' || lv_errmsg;
                              RAISE ex_error;
                        END IF;
                  ELSIF lv_seas_from > lv_seas_to AND ln_cnt > 0 THEN
                        --oredr placed within two months but from and to date is in different year
                          --At present ln_months has non seasonal months
                          --ln_months := 12 - ln_months;
                        --here ln_month will take seasonal months.
                        SELECT ADD_MONTHS (ld_seas_from, -12),
                               ADD_MONTHS (ld_seas_to, -12)
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );
                  ELSIF lv_seas_from > lv_seas_to AND ln_cnt <= 0 THEN
                        --from_date >to_date and  order not within that month
                        SELECT ADD_MONTHS (ld_seas_from, 0) - 1,
                               ADD_MONTHS (ld_seas_to, -12)
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        --dbms_output.put_line('season tooo222222'||ld_seas_from);
                                    --alredy  ld_seas_from is 12 months back
                        ln_months := 12 - ln_months;
                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );
                  ELSIF lv_seas_from = lv_seas_to AND ln_cnt > 0 THEN
                        SELECT ADD_MONTHS (ld_seas_from, -12),
                               ADD_MONTHS (ld_seas_to, -12)
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );
                  ELSIF lv_seas_from = lv_seas_to AND ln_cnt <= 0 THEN
                        SELECT ADD_MONTHS (ld_seas_from, -12),
                               ADD_MONTHS (ld_seas_to, -12) - 1
                          INTO ld_seas_from,
                               ld_seas_to
                          FROM am_dual;

                        Sp_Get_Consumption (pi_parent,
                                            lv_dealer,                                                                --pi_dealer,
                                            lv_loc_cd,                                                           --pi_loc_tab (i),
                                            pi_comp_fa,
                                            lv_part_num,
                                            ln_stock,
                                            lv_errmsg,
                                            ln_errcd
                                           );
                  END IF;

                        --Commented by Anjiv on 23/08/2006
                  --after getting cust_order_qty from pm_part_dtl table
                  /*
                  ln_avg_demand := 0;

                  FOR j IN 1 .. lt_consumption.LAST
                        LOOP
                              ln_avg_demand := ln_avg_demand + lt_consumption (j);
                        END LOOP;

                        IF lt_consumption.COUNT > 0 THEN
                              ln_avg_demand := ln_avg_demand / lt_consumption.COUNT;             --Total consumption/no of months
                        END IF;
                  */
                  ln_soq := ln_avg_demand / ln_order_cycle;

                  /* insert into soq table */
                  BEGIN
                        INSERT INTO pt_soq_new
                                    (dealer_map_cd,
                                     part_class,
                                     part_num,
                                     as_on_date,
                                     no_of_months,
                                     soq_qty,
                                     on_hand_qty,
                                     on_order_qty,
                                     order_cycle,
                                     fsn_ind,
                                     lead_time,
                                     cust_order_qty,
                                     created_by,
                                     created_date,
                                     part_desc,
                                     parent_group,
                                     loc_cd,
                                     amd_soq_qty,
                                     gen_loc,
                                     comp_fa,
                                     avg_consumption,
                                     stock_qty,
                                     min_ord_qty,
                                     root_part_num
                                    )
                             VALUES (lv_dealer,                                                                       --pi_dealer,
                                     lv_part_class,
                                     lv_latest_part,
                                     pi_ason_dt,
                                     ln_months,
                                     ln_soq,
                                     ln_stock,
                                     ln_on_order,
                                     ln_order_cycle,
                                     lv_fsn_ind,
                                     ln_lead_time,
                                     NULL,
                                     pi_user,
                                     SYSDATE,
                                     lv_part_desc,
                                     pi_parent,
                                     lv_loc_cd,                                                                  --pi_loc_tab (i),
                                     ln_soq,
                                     pi_loc_cd,
                                     pi_comp_fa,
                                     ln_avg_demand,
                                     ln_stock,
                                     lv_pack_qty,
                                     lv_part_num
                                    );
                  EXCEPTION
                        WHEN VALUE_ERROR THEN
                              po_errmsg := 'Width problem/Incompatible Data for seasonal part ' || lv_part_num || ' :' || SQLERRM;
                              RAISE ex_error;
                        WHEN OTHERS THEN
                              po_errmsg := 'Error in inserting into SOQ for seasonal part ' || lv_part_num || ' :' || SQLERRM;
                              RAISE ex_error;
                  END;
            END IF;                                                                                   --seasonal part found or not

            EXIT WHEN cur_seas_part%NOTFOUND;
      END LOOP;                                                                                     -- for each part(Seasonal Soq)

      /* ----Generating a common SOQ for all selected locations -----*/
      /* Get the Lead Time, Order Cycle from the system parameters table for the user's location*/
      DECLARE
            CURSOR cur_soq
            IS
                  /*
                          SELECT   part_num,
                           part_desc,
                           NVL ( SUM ( soq_qty), 0),
                           NVL ( SUM ( on_hand_qty), 0),
                           NVL ( SUM ( on_order_qty), 0),
                           NVL ( SUM ( safety_stock), 0),
                           NVL ( SUM ( min_stock), 0),
                           NVL ( SUM ( max_stock), 0),
                           NVL ( SUM ( inv_qty), 0),
                           NVL ( SUM ( avg_consumption), 0),
                           --NVL ( SUM ( stock_qty), 0),
                           NVL ( SUM ( cust_order_qty), 0),
                           MAX ( min_ord_qty)
                      FROM PT_SOQ_NEW
                     WHERE
                               --dealer_map_cd = pi_dealer AND
                               parent_group = pi_parent AND gen_loc = pi_loc_cd
                  GROUP BY part_num, part_desc
                    HAVING NVL ( SUM ( avg_consumption), 0) > 0;*/
                  SELECT   pt.part_num,
                           MAX(pt.part_desc),
                           pt.root_part_num,
                           NVL ( SUM ( pt.soq_qty), 0),
                           NVL ( SUM ( pt.on_hand_qty), 0),
                           NVL ( SUM ( pt.on_order_qty), 0),
                           NVL ( SUM ( pt.safety_stock), 0),
                           NVL ( SUM ( pt.min_stock), 0),
                           NVL ( SUM ( pt.max_stock), 0),
                           NVL ( SUM ( pt.inv_qty), 0),
                           NVL ( SUM ( pt.avg_consumption), 0),
                           --NVL ( SUM ( stock_qty), 0),
                           NVL ( SUM ( pt.cust_order_qty), 0),
                           MAX ( pt.min_ord_qty)
                      FROM pt_soq_new pt, am_dealer_loc am
                     WHERE pt.parent_group = pi_parent
                       AND pt.gen_loc = pi_loc_cd
                       AND pt.parent_group = am.parent_group
                       AND pt.dealer_map_cd = am.dealer_map_cd
                       AND pt.loc_cd = am.loc_cd
                       AND am.consg_cd = NVL (pi_consg_cd, am.consg_cd)
                  GROUP BY part_num, part_desc, root_part_num
                    HAVING NVL ( SUM ( avg_consumption), 0) > 0;
      BEGIN
            OPEN cur_soq;

            LOOP
                  FETCH cur_soq
                   INTO lv_latest_part,
                        lv_part_desc,
                        lv_root_part_num,
                        ln_soq,
                        ln_stock,
                        ln_on_order,
                        ln_reorder_lvl,
                        ln_min_lvl,
                        ln_max_lvl,
                        ln_inv_lvl,
                        ln_avg_demand,
                        --ln_stock,
                        lv_backorder_qty,
                        lv_pack_qty;

                  IF cur_soq%FOUND THEN
                        BEGIN
                              IF pi_consg_cd IS NOT NULL THEN
                                    SELECT NVL ( SUM ( on_hand_qty), 0)
                                      INTO ln_stock
                                      FROM pm_part_var pmv1, pm_part pm1, am_dealer_loc am
                                     WHERE pmv1.parent_group = pi_parent
                                       AND pmv1.part_num = pm1.part_num
                                       AND pm1.root_part_num = lv_root_part_num
                                       AND pm1.dealer_map_cd = am.principal_map_cd
                                       and pm1.principal_map_cd=am.principal_map_cd
                                       AND pmv1.consg_cd = pi_consg_cd
                                       AND am.parent_group = pmv1.parent_group
                                       AND am.dealer_map_cd = pmv1.dealer_map_cd
                                       AND am.loc_cd = pmv1.loc_cd
                                       AND am.parent_group = pi_parent
                                       AND am.consg_cd = pi_consg_cd; /*Changed by Dp Swain for multi org*/
                              ELSE
                                     SELECT /*+ index(pm1 IDX_PM_PART$1)*/NVL ( SUM ( on_hand_qty), 0)/** query tunned by rohit on 26/05/2017**/
                                       INTO ln_stock
                                       FROM pm_part_var pmv1, pm_part pm1
                                      WHERE pm1.root_part_num   = lv_root_part_num
                                        AND pm1.dealer_map_cd   = pi_principal
                                        AND pm1.principal_map_cd=pi_principal
                                        AND pmv1.parent_group   = pi_parent
                                        AND pmv1.dealer_map_cd  = pi_dealer
                                        AND pmv1.loc_cd         = pi_loc_cd
                                        AND pmv1.part_num       = pm1.part_num; /*Changed by Dp Swain for multi org*/
                              END IF;
                        EXCEPTION
                              WHEN OTHERS THEN
                                    ln_stock := 0;
                        END;

                        /* Get part class and fsn indicator of latest part, for the user's location*/
                        BEGIN
                              SELECT abc_ind,
                                     fsn_ind
                                INTO lv_part_class,
                                     lv_fsn_ind
                                FROM pm_part_var
                               WHERE parent_group = pi_parent
                                 AND dealer_map_cd = pi_dealer
                                 AND part_num = lv_latest_part
                                 AND loc_cd = pi_loc_cd;
                        EXCEPTION
                              WHEN NO_DATA_FOUND THEN
                                    --MODIFIED AS NULL on 07/06 ,because the soq generationg location might not have this part
                                    --it may exist in some other location
                                    NULL;
                              --  po_errmsg := 'Part details not found for '||lv_latest_part;
                              --RAISE ex_error;
                              WHEN TOO_MANY_ROWS THEN
                                    po_errmsg := 'More than one Inventory class details found for location' || pi_loc_cd;
                                    RAISE ex_error;
                              WHEN VALUE_ERROR THEN
                                    po_errmsg :=
                                             'Width problem/Incompatible Data while fetching Inventory class details for location'
                                          || pi_loc_cd;
                                    RAISE ex_error;
                              WHEN OTHERS THEN
                                    po_errmsg := 'Error in getting part details for ' || lv_latest_part || ' :' || SQLERRM;
                                    RAISE ex_error;
                        END;

                        IF ln_avg_demand = 0 THEN                                            -- if the part is not consumed at all
                              ln_soq := 0;
                              ln_min_lvl := 0;
                              ln_max_lvl := 0;
                              ln_reorder_lvl := 0;
                              ln_inv_lvl := 0;
                        ELSE
                              -- Calcualate Order Cycle Factor
                              IF NVL ( ln_order_cycle, 0) = 0 THEN
                                    po_errmsg := 'Order cycle not set for location ' || pi_loc_cd;
                                    RAISE ex_error;
                              ELSE
                                    ln_oc_fact := 1 / ln_order_cycle;
                              END IF;

                              ----added on 24-jan-2005 to consider customer back order
                              ln_xfact := ln_stock + ln_on_order - lv_backorder_qty;

                              /* Calculate the SOQ */
                              IF ln_oc_fact < 1 AND ln_xfact <= ln_reorder_lvl THEN
                                    --added on 24-jan-2005 to consider customer back order
                                    ln_soq := ln_max_lvl - ln_stock - ln_on_order + lv_backorder_qty;
                              --  dbms_output.put_line('soq='||ln_soq);
                              END IF;
        ln_soq := ROUND(ln_soq,0);
                              IF ln_xfact > ln_reorder_lvl THEN
                                    ln_soq := 0;
                              ELSE
                                    --make soq as multiple of min order qty
                                    IF (ln_soq MOD lv_pack_qty) <> 0 THEN
                                          --ln_soq := ln_soq + (lv_pack_qty - (ln_soq MOD lv_pack_qty));
                                      ln_soq := ROUND(ln_soq/lv_pack_qty,0)*lv_pack_qty;
                                    END IF;
                              -- dbms_output.put_line('with pack soq='||ln_soq);
                              END IF;

                              --END IF;

                              /* Insert the common SOQ */
                              BEGIN
                                    INSERT INTO pt_soq_mul_new
                                                (dealer_map_cd,
                                                 part_class,
                                                 part_num,
                                                 as_on_date,
                                                 no_of_months,
                                                 soq_qty,
                                                 on_hand_qty,
                                                 on_order_qty,
                                                 safety_stock,
                                                 order_cycle,
                                                 min_stock,
                                                 max_stock,
                                                 fsn_ind,
                                                 lead_time,
                                                 --cust_order_qty,
                                                 created_by,
                                                 created_date,
                                                 part_desc,
                                                 parent_group,
                                                 loc_cd,
                                                 --inv_qty,
                                                 amd_soq_qty,
                                                 comp_fa,
                                                 avg_consumption,
                                                 stock_qty,
                                                 root_part_num
                                                )
                                         VALUES (pi_dealer,
                                                 lv_part_class,
                                                 lv_latest_part,
                                                 pi_ason_dt,
                                                 pi_months,
                                                 ln_soq,
                                                 ln_stock,
                                                 ln_on_order,
                                                 ln_reorder_lvl,
                                                 ln_order_cycle,
                                                 ln_min_lvl,
                                                 ln_max_lvl,
                                                 lv_fsn_ind,
                                                 ln_lead_time,
                                                 --null,
                                                 pi_user,
                                                 SYSDATE,
                                                 lv_part_desc,
                                                 pi_parent,
                                                 pi_loc_cd,
                                                 --ln_inv_lvl,
                                                 ln_soq,
                                                 pi_comp_fa,
                                                 ln_avg_demand,
                                                 ln_stock,
                                                 lv_root_part_num
                                                );
                              EXCEPTION
                                    WHEN VALUE_ERROR THEN
                                          po_errmsg :=
                                                   'Width problem/Incompatible Data in inserting common SOQ for part '
                                                || lv_latest_part
                                                || ' :'
                                                || SQLERRM;
                                          RAISE ex_error;
                                    WHEN OTHERS THEN
                                          po_errmsg :=
                                                      'Error inserting common SOQ for part ' || lv_latest_part || ' :' || SQLERRM;
                                          RAISE ex_error;
                              END;
                        END IF;
                  END IF;

                  EXIT WHEN cur_soq%NOTFOUND;
            END LOOP;
      EXCEPTION
            WHEN ex_error THEN
                  RAISE ex_error;
            WHEN OTHERS THEN
                  po_errmsg := 'Error in insertion of  part in common SOQ ' || SQLERRM;
                  RAISE ex_error;
      END;

      COMMIT;
EXCEPTION
      WHEN ex_error THEN
            po_errcd := 1;
            ROLLBACK;
      WHEN OTHERS THEN
            po_errmsg :=
                       'SOQ process interrupted as -' || lv_part_num || ' - ' || lv_count || ' - ' || lv_step || ' - ' || SQLERRM;
            po_errcd := 1;
            ROLLBACK;
END Sp_Calculate_Soq_New;

```

#### SP-094 - SP_GET_CONSUMPTION

**Invoked From:**

- SP_CALCULATE_SOQ_NEW.prc [StoredProcedure: SP_CALCULATE_SOQ_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

SP_GET_CONSUMPTION retrieves the current on-hand stock quantity for a given part within a specific dealer, location, parent group, and principal organisation. It resolves the applicable principal mapping code for the dealer/location combination and then aggregates on-hand quantity from the parts variant and part master tables, returning the result to the calling procedure SP_CALCULATE_SOQ_NEW for use in stock-of-quantity calculations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_parent | VARCHAR2 | IN |
| pi_dealer | NUMBER | IN |
| pi_loc_cd | VARCHAR2 | IN |
| pi_comp_fa | VARCHAR2 | IN |
| pi_root_part | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_stock | NUMBER | OUT |
| po_errmsg | VARCHAR2 | OUT |
| po_errcd | NUMBER | OUT |

---

**Dependencies**

- SF_PRINCIPAL_MAP_CD ([SP-092](#SP-092--SF_PRINCIPAL_MAP_CD)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the principal mapping code for the supplied dealer (pi_dealer) and location (pi_loc_cd) by invoking the scalar function SF_PRINCIPAL_MAP_CD; the result is stored in the local variable lv_principal.
- Step 2 - Query PM_PART_VAR joined to PM_PART to aggregate the total on-hand quantity (SUM of on_hand_qty) for records matching the input parent group (pi_parent), dealer (pi_dealer), location (pi_loc_cd), root part number (pi_root_part), a fixed dealer map code of 1 on the part master, and the resolved principal mapping code (lv_principal).
- Step 3 - Assign the aggregated NVL-protected sum to the output parameter po_stock; if no rows are found or too many rows are returned, po_stock is set to 0.
- Step 4 - Set po_errcd to 0 to signal successful completion.
- Step 5 - If any unhandled exception occurs at any step, set po_errcd to 1 and populate po_errmsg with the Oracle error message (SQLERRM).

---
**Decision Points**

DP-001

Condition: The SELECT against PM_PART_VAR / PM_PART returns NO_DATA_FOUND.

TRUE: po_stock is set to 0; processing continues normally to the success exit.

FALSE: The aggregated on-hand quantity is assigned to po_stock as returned by the query.

DP-002

Condition: The SELECT against PM_PART_VAR / PM_PART raises TOO_MANY_ROWS.

TRUE: po_stock is set to 0; processing continues normally to the success exit.

FALSE: Normal result assignment applies (see DP-001).

DP-003

Condition: Any OTHERS exception is raised within the stock retrieval block.

TRUE: The local raise_exp exception is raised, propagating to the outer WHEN OTHERS handler, which sets po_errcd to 1 and po_errmsg to SQLERRM.

FALSE: Processing completes without error and po_errcd is set to 0.

---
**Database Interactions**

- DB-001 - Read PM_PART_DTL - Reads data from PM_PART_DTL for lookup or validation.
- DB-002 - Read PM_STOCK - Reads data from PM_STOCK for lookup or validation.
- DB-003 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
**Business Rules**

- BR-001 - The principal mapping code used to filter the part master must be derived at runtime via SF_PRINCIPAL_MAP_CD using the supplied dealer and location; it must not be hard-coded, supporting multi-organisation dealer structures.
- BR-002 - On-hand stock is sourced exclusively from PM_PART_VAR joined to PM_PART; the part master join is restricted to dealer_map_cd = 1, ensuring that only the canonical (global) part master records are used for root-part resolution.
- BR-003 - The part master join must additionally match the resolved principal mapping code (lv_principal), ensuring that stock quantities are scoped to the correct principal organisation for the dealer/location.
- BR-004 - The aggregated on-hand quantity must be NULL-protected using NVL; a result of NULL is treated as zero stock.
- BR-005 - When the stock query yields no matching rows or raises TOO_MANY_ROWS, po_stock must default to 0 rather than propagating an error, ensuring the calling SOQ calculation receives a valid numeric value.
- BR-006 - Any unhandled database exception must be surfaced to the caller via po_errcd = 1 and a descriptive po_errmsg, preventing silent failures in the SOQ calculation chain.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE Sp_Get_Consumption (
      pi_parent      IN       VARCHAR2,
      pi_dealer      IN       NUMBER,
      pi_loc_cd      IN       VARCHAR2,
      pi_comp_fa     IN       VARCHAR2,
      pi_root_part   IN       VARCHAR2,
      /*po_avg_cons         OUT      NUMBER,
      po_on_order_qty     OUT      NUMBER,
      */
      po_stock       OUT      NUMBER,
      /*po_std_dev          OUT      NUMBER,
      po_cust_order_qty   OUT      NUMBER,
      po_min_lvl          OUT      NUMBER,
      po_max_lvl          OUT      NUMBER,
      po_inv_lvl          OUT      NUMBER,
      po_reorder_lvl      OUT      NUMBER,
      */
      po_errmsg      OUT      VARCHAR2,
      po_errcd       OUT      NUMBER
)
IS
      raise_exp   EXCEPTION;
      lv_principal am_dealer_loc.principal_map_cd%type; --Added by Neha for multi org changes
BEGIN

   --Added by Neha for multi org changes
    lv_principal := sf_principal_map_cd(pi_dealer,pi_loc_cd);

--Avg Consumption and on order quantity
      /*
        BEGIN
            SELECT NVL ( ppd.avg_consumption, 0),
                   NVL ( ppd.on_order_qty, 0),
                   NVL ( ppd.std_dev, 0),
                   NVL ( ppd.cust_order_qty, 0),
                   NVL ( ppd.min_lvl, 0),
                   NVL ( ppd.max_lvl, 0),
                   NVL ( ppd.inv_lvl, 0),
                   NVL ( ppd.reorder_lvl, 0)
              INTO po_avg_cons,
                   po_on_order_qty,
                   po_std_dev,
                   po_cust_order_qty,
                   po_min_lvl,
                   po_max_lvl,
                   po_inv_lvl,
                   po_reorder_lvl
              FROM pm_part_dtl ppd, pm_part pm
             WHERE ppd.parent_group = pi_parent
               AND ppd.dealer_map_cd = pi_dealer
               AND ppd.loc_cd = pi_loc_cd
               AND ppd.latest_part_num = pm.part_num
               AND ppd.root_part_num = pm.root_part_num
               AND ppd.root_part_num = pi_root_part
               AND pm.dealer_map_cd = 1;                                                              --IN (1, ppd.dealer_map_cd);
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_avg_cons := 0;
                  po_on_order_qty := 0;
                  po_std_dev := 0;
                  po_cust_order_qty := 0;
            WHEN TOO_MANY_ROWS THEN
                  po_avg_cons := 0;
                  po_on_order_qty := 0;
                  po_std_dev := 0;
                  po_cust_order_qty := 0;
            WHEN OTHERS THEN
                  RAISE raise_exp;
      END;
*/
      --Stock
      BEGIN
            /*SELECT NVL ( SUM (   NVL ( ps.ls_stock_qty, 0)
                               + NVL ( ps.os_stock_qty, 0)
                               - NVL ( ps.alloc_qty, 0)
                               - NVL ( ps.ls_float_qty, 0)
                               - NVL ( ps.os_float_qty, 0)
                             ),
                         0
                       )
              INTO po_stock
              FROM pm_stock ps, pm_part pm
             WHERE ps.parent_group = pi_parent
               AND ps.dealer_map_cd = pi_dealer
               AND ps.loc_cd = pi_loc_cd
               AND ps.comp_fa = pi_comp_fa
               AND pm.part_num = ps.part_num
               AND pm.root_part_num = pi_root_part
               AND pm.dealer_map_cd = 1;                                                               --IN (1, ps.dealer_map_cd);
                     */
            SELECT NVL ( SUM ( on_hand_qty), 0)
              INTO po_stock
              FROM pm_part_var ps, pm_part pm
             WHERE ps.parent_group = pi_parent
               AND ps.dealer_map_cd = pi_dealer
               AND ps.loc_cd = pi_loc_cd
               AND pm.part_num = ps.part_num
               AND pm.root_part_num = pi_root_part
               AND pm.dealer_map_cd = 1
               and pm.PRINCIPAL_MAP_CD=lv_principal;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  po_stock := 0;
            WHEN TOO_MANY_ROWS THEN
                  po_stock := 0;
            WHEN OTHERS THEN
                  RAISE raise_exp;
      END;

      po_errcd := 0;
EXCEPTION
      WHEN OTHERS THEN
            po_errcd := 1;
            po_errmsg := SQLERRM;
END;

```

#### SP-095 - SP_INSERT_PM_PART_VAR

**Invoked From:**

- PK_VALIDATE_PARTS.pck [StoredProcedure: PK_VALIDATE_PARTS.UPDATE_ON_ORDER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Creates a new part variant record in PM_PART_VAR for a given dealer, location, and part number, enriching the insert with GST-related attributes (HS code and tax category) resolved from AM_DEALER_LOC and PM_PART, and subsequently triggers a price update for the newly created part variant via SP_UPDATE_PART_PRICE. The procedure runs as an autonomous transaction to isolate its commit from the calling context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_PARENT_GROUP | VARCHAR2 | IN |
| P_DEALER | NUMBER | IN |
| P_LOC_CD | VARCHAR2 | IN |
| P_PART_NUM | VARCHAR2 | IN |
| P_CREATED_BY | VARCHAR2 | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| P_ERR_MSG | VARCHAR2 | OUT |
| P_ERR_CD | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-009](#SP-009--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)
- SP_UPDATE_PART_PRICE ([SP-097](#SP-097--SP_UPDATE_PART_PRICE)) - standalone source file

---

**Step-by-Step Business Logic**

- Step 1 - Resolve the Principal Map Code (LN_PMC) by querying AM_DEALER_LOC using the combination of P_DEALER, P_LOC_CD, and P_PARENT_GROUP. If no matching row is found or any exception occurs, LN_PMC remains NULL and processing continues.
- Step 2 - Retrieve the HS code (LV_HSN_CODE) and tax category (LV_TAX_CATG) from PM_PART where PART_NUM matches P_PART_NUM and DEALER_MAP_CD is either the dealer (P_DEALER) or the principal map code (LN_PMC).
- Step 3 - If Step 2 returns no data, attempt a fallback lookup on PM_PART using ROOT_PART_NUM equal to P_PART_NUM with the same DEALER_MAP_CD filter, restricting to a single row (ROWNUM <= 1).
- Step 4 - If neither PM_PART lookup yields a result (NO_DATA_FOUND, TOO_MANY_ROWS, or any other exception in either attempt), default LV_TAX_CATG to 'A'; LV_HSN_CODE remains NULL.
- Step 5 - Insert a new row into PM_PART_VAR populated with: P_PARENT_GROUP, P_DEALER (as DEALER_MAP_CD), P_LOC_CD, P_PART_NUM, P_CREATED_BY, SYSDATE (as CREATED_DATE), a hard-coded ORDER_REASON_CD of 1, LV_HSN_CODE, and LV_TAX_CATG.
- Step 6 - Call SP_UPDATE_PART_PRICE passing P_PARENT_GROUP, P_DEALER, P_LOC_CD, LV_TAX_CATG, and P_PART_NUM to synchronise pricing for the newly inserted part variant.
- Step 7 - Issue a COMMIT to persist both the PM_PART_VAR insert and any price updates made by SP_UPDATE_PART_PRICE.
- Step 8 - If any unhandled exception occurs, capture the error message in P_ERR_MSG and set P_ERR_CD to 1; no commit is issued in the exception path.

---
**Decision Points**

DP-001

Condition: Does AM_DEALER_LOC contain exactly one row matching P_DEALER, P_LOC_CD, and P_PARENT_GROUP?

TRUE: LN_PMC is populated with the retrieved PRINCIPAL_MAP_CD and used in subsequent PM_PART lookups.

FALSE: LN_PMC remains NULL (NO_DATA_FOUND, TOO_MANY_ROWS, or other exception is silently suppressed); PM_PART lookups proceed with LN_PMC as NULL.

DP-002

Condition: Does PM_PART contain a row where PART_NUM = P_PART_NUM and DEALER_MAP_CD IN (P_DEALER, LN_PMC)?

TRUE: LV_HSN_CODE and LV_TAX_CATG are populated from the matched PM_PART row and used in the PM_PART_VAR insert and the SP_UPDATE_PART_PRICE call.

FALSE: A fallback lookup is attempted using ROOT_PART_NUM (see DP-003).

DP-003

Condition: Does PM_PART contain at least one row where ROOT_PART_NUM = P_PART_NUM and DEALER_MAP_CD IN (P_DEALER, LN_PMC)?

TRUE: LV_HSN_CODE and LV_TAX_CATG are populated from the first matching row (ROWNUM <= 1).

FALSE: LV_TAX_CATG is defaulted to 'A' and LV_HSN_CODE remains NULL; processing continues to the insert step.

---
**Database Interactions**

- DB-001 - Update PRICE - Updates existing rows in PRICE.
- DB-002 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-003 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-004 - Insert into PM_PART_VAR - Persists a new row into PM_PART_VAR using columns: parent group, dealer map cd, loc cd, part num, created by, created date, order reason cd, hs code, and 1 more column(s).
**Business Rules**

- BR-001 - A new PM_PART_VAR record must always be created with ORDER_REASON_CD set to 1, representing the standard order reason for a newly registered part variant.
- BR-002 - The CREATED_DATE of the PM_PART_VAR record is always set to SYSDATE at the time of insert; no externally supplied creation date is accepted.
- BR-003 - The HS code and tax category stored on PM_PART_VAR must be sourced from PM_PART, resolved first by exact PART_NUM match and then by ROOT_PART_NUM match, both constrained to the dealer's own DEALER_MAP_CD or the associated PRINCIPAL_MAP_CD from AM_DEALER_LOC.
- BR-004 - When neither PM_PART lookup resolves a tax category, LV_TAX_CATG defaults to 'A', ensuring the insert and the subsequent price update always carry a valid tax category value.
- BR-005 - Immediately after inserting the PM_PART_VAR row, SP_UPDATE_PART_PRICE must be invoked with the resolved tax category (LV_TAX_CATG) to ensure pricing is synchronised for the new part variant before the transaction is committed.
- BR-006 - The procedure executes as an autonomous transaction (PRAGMA AUTONOMOUS_TRANSACTION), meaning its COMMIT is independent of the calling transaction in PK_VALIDATE_PARTS.UPDATE_ON_ORDER.
- BR-007 - On any unhandled exception, the procedure returns the Oracle error message in P_ERR_MSG and sets P_ERR_CD to 1; no partial data is committed in the error path.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE SP_INSERT_PM_PART_VAR
/*
  $LOG: SP_INSERT_PM_PART_VAR.SQL,V $
  REVISION 1.2 2006/05/10 ANJIV
  ADDED PROCEDURE TO UPDATE PRICE AFTER CREATING PRICE

  REVISION 1.1  2004/08/21 06:00:45  SANJEEVKN
  AS OF 21 AUG, 04

  */
(P_PARENT_GROUP IN VARCHAR2,
 P_DEALER       IN NUMBER,
 P_LOC_CD       IN VARCHAR2,
 P_PART_NUM     IN VARCHAR2,
 P_CREATED_BY   IN VARCHAR2,
 P_ERR_MSG      OUT VARCHAR2,
 P_ERR_CD       OUT NUMBER) IS
  PRAGMA AUTONOMOUS_TRANSACTION; --ADDED BY ANJIV ON 10/05/2007
  LV_HSN_CODE PM_PART.HS_CODE%TYPE;---------Added against Gst Changes by Ravi
  LV_TAX_CATG PM_PART.PART_TAX_CD%TYPE;---------Added against Gst Changes by Ravi
  LN_PMC      AM_DEALER_LOC.PRINCIPAL_MAP_CD%TYPE;---------Added against Gst Changes by Ravi
BEGIN
  ---------begin---------------added BY Ravi for GST changes----------

  BEGIN
    SELECT PRINCIPAL_MAP_CD
      INTO LN_PMC
      FROM AM_DEALER_LOC
     WHERE DEALER_MAP_CD = P_DEALER
       AND LOC_CD = P_LOC_CD
       AND PARENT_GROUP = P_PARENT_GROUP;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      NULL;
    WHEN TOO_MANY_ROWS THEN
      NULL;
    WHEN OTHERS THEN
      NULL;
  END;
  BEGIN
    SELECT HS_CODE, PART_TAX_CD
      INTO LV_HSN_CODE, LV_TAX_CATG
      FROM PM_PART
     WHERE PART_NUM = P_PART_NUM
       AND DEALER_MAP_CD IN (P_DEALER, LN_PMC);
  EXCEPTION
        WHEN NO_DATA_FOUND THEN
          BEGIN
             SELECT HS_CODE, PART_TAX_CD
            INTO LV_HSN_CODE, LV_TAX_CATG
            FROM PM_PART
           WHERE ROOT_PART_NUM = P_PART_NUM
             AND DEALER_MAP_CD IN (P_DEALER, LN_PMC)
             AND ROWNUM<=1;
           EXCEPTION
                WHEN NO_DATA_FOUND THEN
                   LV_TAX_CATG:='A';
               WHEN TOO_MANY_ROWS THEN
                 LV_TAX_CATG:='A';
               WHEN OTHERS THEN
                 LV_TAX_CATG:='A';
           END;
   WHEN TOO_MANY_ROWS THEN
       LV_TAX_CATG:='A';
    WHEN OTHERS THEN
       LV_TAX_CATG:='A';
  END;
  ----------End ----------
  INSERT INTO PM_PART_VAR
    (PARENT_GROUP,
     DEALER_MAP_CD,
     LOC_CD,
     PART_NUM,
     CREATED_BY,
     CREATED_DATE,
     ORDER_REASON_CD,
     HS_CODE,---------Added against Gst Changes by Ravi
     PART_TAX_CD---------Added against Gst Changes by Ravi
     )
  VALUES
    (P_PARENT_GROUP,
     P_DEALER,
     P_LOC_CD,
     P_PART_NUM,
     P_CREATED_BY,
     SYSDATE,
     1,
     LV_HSN_CODE,
     LV_TAX_CATG);

  --PROCEDURE ADDED BY ANJIV ON 10-05-2006 TO UPDATE PRICE FOR NEWLY CREATED PART
  SP_UPDATE_PART_PRICE(P_PARENT_GROUP,
                       P_DEALER,
                       P_LOC_CD,
                       --NULL,----Comment by Ravi against GST changes
                       LV_TAX_CATG,
                       P_PART_NUM);
  COMMIT;
EXCEPTION
  WHEN OTHERS THEN
    P_ERR_MSG := SQLERRM;
    P_ERR_CD  := 1;
END;

```

#### SP-096 - SP_SOQ_POPULATE_CONSUMPTION

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Retrieves consumption history, current stock level, and on-order quantity for all parts belonging to the same root part family as the supplied part number, scoped to a given dealer, principal, location, parent group, and component FA. Results are returned as output parameters for display in the SOQ form's consumption analysis panel. Dynamic SQL is used throughout to accommodate the variable-length part family list assembled at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| pi_dealer | number | IN |
| pi_principal | number | IN |
| pi_parent | varchar2 | IN |
| pi_loc | varchar2 | IN |
| pi_comp_fa | varchar2 | IN |
| pi_part_num | varchar2 | IN |
| pi_months | number | IN |
| pi_date | date | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| po_consumption | pk_plsql_table.num_tab | OUT |
| po_stock | number | OUT |
| po_on_order | number | OUT |
| po_errmsg | varchar2 | OUT |
| po_errcd | number | OUT |

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-037](#SP-037--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - The error output code (po_errcd) is initialised to zero (success).
- Step 2 - A dynamic SQL query is constructed and executed via a REF CURSOR (cur_root) to retrieve all part numbers from PM_PART whose root_part_num matches pi_part_num, where the dealer_map_cd matches either pi_dealer or pi_principal, and where principal_map_cd matches pi_principal (multi-company filter).
- Step 3 - Each fetched part number is appended to a comma-separated string (lv_part_str), with each value enclosed in single quotes; the loop exits when no further rows are found.
- Step 4 - The trailing comma is removed from lv_part_str using SUBSTR/LENGTH.
- Step 5 - If lv_part_str is not null (at least one part was found), consumption data is retrieved: for each month j from 1 to pi_months, the month-year identifier is calculated by calling ADD_MONTHS against pi_date offset by -(j-1) and formatted as MMYY via DUAL; a dynamic SQL statement then sums net_qty from PT_MONTHLY_CONSUMPTION for the assembled part family filtered by pi_parent, pi_dealer, pi_loc, and the calculated month-year; the result is stored in po_consumption(j).
- Step 6 - A dynamic SQL statement sums available stock (ls_stock_qty + os_stock_qty - alloc_qty - ls_float_qty - os_float_qty) from PM_STOCK for the part family, filtered by pi_parent, pi_dealer, pi_loc, and pi_comp_fa; the result is stored in po_stock.
- Step 7 - A dynamic SQL statement sums on_order_qty from PM_PART_VAR for the part family, filtered by pi_parent, pi_dealer, and pi_loc; the result is stored in po_on_order.
- Step 8 - If lv_part_str is null (no parts found for the given root part number), po_errmsg is set to 'Root Part number [pi_part_num] not found' and po_errcd is set to 1.
- Step 9 - If any unexpected exception occurs at any step, the SQLERRM message is placed in po_errmsg and po_errcd is set to 1.

---
**Decision Points**

DP-001

Condition: lv_part_str is not null after the REF CURSOR loop - i.e., at least one part exists in PM_PART with root_part_num = pi_part_num for the given dealer/principal scope.

TRUE: Proceed to retrieve per-month consumption from PT_MONTHLY_CONSUMPTION, aggregate stock from PM_STOCK (including comp_fa filter), and aggregate on-order quantity from PM_PART_VAR for the assembled part family.

FALSE: Set po_errmsg to 'Root Part number [pi_part_num] not found' and po_errcd to 1; no data retrieval is performed.

DP-002

Condition: An unexpected runtime error occurs during any database operation (WHEN OTHERS).

TRUE: Set po_errcd to 1 and populate po_errmsg with the SQLERRM database error message.

FALSE: Processing completes normally with po_errcd = 0 and all output parameters populated.

---
**Database Interactions**

- DB-001 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-002 - Read DUAL - Reads data from DUAL for lookup or validation.
- DB-003 - Read PT_MONTHLY_CONSUMPTION - Reads data from PT_MONTHLY_CONSUMPTION for lookup or validation.
- DB-004 - Read PM_STOCK - Reads data from PM_STOCK for lookup or validation.
- DB-005 - Read PM_PART_VAR - Reads data from PM_PART_VAR for lookup or validation.
**Business Rules**

- BR-001 - Consumption, stock, and on-order figures are aggregated across all parts belonging to the same root part family (root_part_num = pi_part_num), not just the single supplied part number.
- BR-002 - The root part family lookup applies a multi-company filter: a part is included only if its dealer_map_cd matches pi_dealer or pi_principal AND its principal_map_cd matches pi_principal.
- BR-003 - If no parts are found for the given root part number, the procedure returns an error (po_errcd = 1) rather than returning empty data.
- BR-004 - Stock availability is calculated as ls_stock_qty + os_stock_qty minus alloc_qty, ls_float_qty, and os_float_qty; the comp_fa dimension (pi_comp_fa) is applied as an additional filter on PM_STOCK.
- BR-005 - Consumption history is retrieved month by month for pi_months periods, working backwards from pi_date; each period's month-year key is derived dynamically using ADD_MONTHS and formatted as MMYY.
- BR-006 - Dynamic SQL is used for all queries against PT_MONTHLY_CONSUMPTION, PM_STOCK, and PM_PART_VAR to allow the variable-length IN-list of part numbers (lv_part_str) to be embedded at runtime.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
procedure sp_soq_populate_consumption
/*
  $Log: SP_SOQ_POPULATE_CONSUMPTION.sql,v $
  Revision 1.3  2004/09/02 10:18:52  pankajj
  As on 02 Sep 2004, due to pm_stock comp_fa addition

  Revision 1.2  2004/08/25 08:51:05  pankajj
  As on Aug 25,2004

  Revision 1.1  2004/08/23 04:09:45  pankajj
  As on Aug 21,2004

  */
(pi_dealer      in number,
 pi_principal   in number,
 pi_parent      in varchar2,
 pi_loc         in varchar2,
 pi_comp_fa     in varchar2,
 pi_part_num    in varchar2,
 pi_months      in number,
 pi_date        in date,
 po_consumption out pk_plsql_table.num_tab,
 po_stock       out number,
 po_on_order    out number,
 po_errmsg      out varchar2,
 po_errcd       out number) is

  ln_mth      number := 0;
  ln_qty      number := 0;
  lv_sql      varchar2(2000);
  cur_root    sys_refcursor;
  lv_part_num pm_part.part_num%type;
  lv_part_str varchar2(1000);

BEGIN

  po_errcd := 0;

  /* Get all the parts belonging to the root part */

  lv_sql := 'select part_num from pm_part
              where (dealer_map_cd = :pi_dealer or
                               dealer_map_cd = :pi_principal)
                and root_part_num = :pi_part_num
                and principal_map_cd = :pi_principal  --Added by Rajeev for multi company changes
                ';
  open cur_root for lv_sql
    using pi_dealer, pi_principal, pi_part_num, pi_principal; --Added by Rajeev for multi company changes
  loop
    fetch cur_root
      into lv_part_num;
    if cur_root%found then
      lv_part_str := lv_part_str || '''' || lv_part_num || '''' || ',';
    end if;
    exit when cur_root%notfound;
  end loop;

  lv_part_str := substr(lv_part_str, 1, length(lv_part_str) - 1); --remove last comma

  if lv_part_str is not null then

    /* Get the consumption of all the parts of the family */
    for j in 1 .. pi_months loop
      select to_number(to_char(add_months(pi_date, - (j - 1)), 'MMYY'))
        into ln_mth
        from dual;

      lv_sql := 'select nvl(sum(net_qty),0)
          from pt_monthly_consumption
          where parent_group = :p_parent
        and dealer_map_cd = :p_dealer
        and loc_cd = :p_loc
        and part_num in (' || lv_part_str || ')
        and month_year = :ln_mth';

      execute immediate lv_sql
        into ln_qty
        using pi_parent, pi_dealer, pi_loc, ln_mth;
      po_consumption(j) := ln_qty;

    end loop;

    /* Get the stock of all the parts of the family */
    lv_sql := 'select nvl(sum(nvl(ls_stock_qty,0) + nvl(os_stock_qty,0) - nvl(alloc_qty,0)
                           - nvl(ls_float_qty,0) - nvl(os_float_qty,0)),0)
            from pm_stock
         where parent_group = :p_parent
         and dealer_map_cd = :p_dealer
         and loc_cd = :p_loc
         and comp_fa = :p_comp_fa
         and part_num in (' || lv_part_str || ')';

    execute immediate lv_sql
      into po_stock
      using pi_parent, pi_dealer, pi_loc, pi_comp_fa;

    /* Get the on hand qty of all the parts of the family */
    lv_sql := 'select nvl(sum(on_order_qty),0) from pm_part_var
           where parent_group = :p_parent
         and dealer_map_cd = :p_dealer
         and loc_cd = :p_loc
         and part_num in (' || lv_part_str || ')';

    execute immediate lv_sql
      into po_on_order
      using pi_parent, pi_dealer, pi_loc;
  else
    po_errmsg := 'Root Part number ' || pi_part_num || ' not found';
    po_errcd  := 1;
  end if;

EXCEPTION
  when others then
    po_errmsg := sqlerrm;
    po_errcd  := 1;
END;

```

#### SP-097 - SP_UPDATE_PART_PRICE

**Invoked From:**

- SP_INSERT_PM_PART_VAR.prc [StoredProcedure: SP_INSERT_PM_PART_VAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Updates the part price variant record in PM_PART_VAR for a given parent group, dealer, location, and part number. The procedure resolves the applicable purchase price and MRP from principal price master tables, determines the correct tax code, and applies the values to the part variant row. Behaviour differs based on whether the dealer location is classified as a mass-update ('M') dealer type.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent | VARCHAR2 | IN |
| p_dealer | NUMBER | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_part_tax_cd | VARCHAR2 | IN |
| p_part_num | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-037](#SP-037--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Retrieve the consignment code (consg_cd), dealer type (dealer_type), and principal map code (principal_map_cd) from AM_DEALER_LOC for the combination of p_dealer, p_loc_cd, and p_parent. Exceptions (NO_DATA_FOUND, TOO_MANY_ROWS, OTHERS) are suppressed and leave the local variables NULL.
- Step 2 - Evaluate whether a consignment code was found (lv_consg_cd IS NOT NULL) to determine the pricing source path.
- Step 3 - If a consignment code exists and the dealer type is NOT 'M', query PI_PART_PRICE_MASTER for the most recent revision (MAX revision_date) matching the part number, consignment code, and principal map code. Retrieve purchase_price and mrp_1. Any exception defaults both values to 0.
- Step 4 - If a consignment code exists and the dealer type IS 'M', query PI_PM_PART_MRP for the most recent effective date (MAX EFF_FROM_DT) matching the part number and principal map code. Retrieve mrp as lv_mrp_1. Any exception defaults lv_mrp_1 to 0. Purchase price is not retrieved for mass-update dealers.
- Step 5 - If no consignment code was found, default both lv_purchase_price and lv_mrp_1 to 0.
- Step 6 - Determine the tax code. If p_part_tax_cd is NULL, look up part_tax_cd from PM_PART where dealer_map_cd matches either the dealer or the principal map code and part_num matches p_part_num. Any exception sets lv_tax_cd to NULL.
- Step 7 - Proceed with the update only if lv_mrp_1 is greater than 0.
- Step 8 - For non-'M' dealer type, build and execute a dynamic SQL statement (EXECUTE IMMEDIATE) that updates PM_PART_VAR setting purchase_price, mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE for the matching parent group, dealer, location, and part number.
- Step 9 - For 'M' dealer type, build and execute a dynamic SQL statement (EXECUTE IMMEDIATE) that updates PM_PART_VAR setting mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE (purchase_price is excluded). Additionally, update PI_PM_PART_MRP setting mass_update = 'Y' for the matching part number and principal map code.

---
**Decision Points**

DP-001
Condition: lv_consg_cd IS NOT NULL (consignment code was successfully retrieved from AM_DEALER_LOC).
TRUE: Proceed to look up pricing data from PI_PART_PRICE_MASTER or PI_PM_PART_MRP depending on dealer type.
FALSE: Default lv_purchase_price and lv_mrp_1 to 0; skip price master lookups.

DP-002
Condition: lv_dlr_type != 'M' (dealer location is not a mass-update type).
TRUE: Query PI_PART_PRICE_MASTER for purchase_price and mrp_1 using the latest revision_date.
FALSE (lv_dlr_type = 'M'): Query PI_PM_PART_MRP for mrp using the latest EFF_FROM_DT; purchase_price is not retrieved.

DP-003
Condition: p_part_tax_cd IS NULL (no tax code supplied by the caller).
TRUE: Derive the tax code by querying PM_PART for the part_tax_cd matching the part number and dealer/principal map code.
FALSE: Use the caller-supplied p_part_tax_cd as lv_tax_cd without further lookup.

DP-004
Condition: lv_mrp_1 > 0 (a valid MRP was resolved).
TRUE: Proceed to build and execute the dynamic UPDATE statement against PM_PART_VAR (and PI_PM_PART_MRP for 'M' type).
FALSE: Skip all UPDATE operations; no changes are made to PM_PART_VAR.

DP-005
Condition: lv_dlr_type != 'M' at the point of executing the update (within the lv_mrp_1 > 0 block).
TRUE: Update PM_PART_VAR including purchase_price, mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE.
FALSE (lv_dlr_type = 'M'): Update PM_PART_VAR with mrp_1, part_tax_cd, warranty_tax_cd, and UPDATED_DATE (purchase_price excluded); additionally flag the PI_PM_PART_MRP row with mass_update = 'Y'.

---
**Database Interactions**

- DB-001 - Read AM_DEALER_LOC - Reads data from AM_DEALER_LOC for lookup or validation.
- DB-002 - Read PI_PART_PRICE_MASTER - Reads data from PI_PART_PRICE_MASTER for lookup or validation.
- DB-003 - Read PI_PM_PART_MRP - Reads data from PI_PM_PART_MRP (columns: mass update) for lookup or validation.
- DB-004 - Read PM_PART - Reads data from PM_PART for lookup or validation.
- DB-005 - Read AM_DEALER_LOC_PARAM - Reads data from AM_DEALER_LOC_PARAM for lookup or validation.
- DB-006 - Update PM_PART_VAR - Updates existing rows in PM_PART_VAR (columns: purchase price, ls sell price, os sell price, mrp 1, part tax cd, warranty tax cd, updated date).
- DB-007 - Update PI_PM_PART_MRP - Updates existing rows in PI_PM_PART_MRP (columns: mass update).
**Business Rules**

- BR-001 - The dealer location record in AM_DEALER_LOC must be identified by the combination of dealer_map_cd, loc_cd, and parent_group. If no matching record exists or multiple rows are returned, pricing defaults to zero and no consignment-based lookup is performed.
- BR-002 - Purchase price and MRP are sourced from PI_PART_PRICE_MASTER only for non-mass-update dealer locations (dealer_type != 'M'). The most recent price is determined by the maximum revision_date scoped to the same part number, consignment code, and principal map code.
- BR-003 - For mass-update dealer locations (dealer_type = 'M'), MRP is sourced exclusively from PI_PM_PART_MRP using the maximum EFF_FROM_DT scoped to the same part number and principal map code. Purchase price is not updated for this dealer type.
- BR-004 - If price master lookups fail for any reason (no data, too many rows, or other exceptions), pricing values default to 0 to prevent null propagation into PM_PART_VAR.
- BR-005 - The tax code applied to both part_tax_cd and warranty_tax_cd in PM_PART_VAR is the caller-supplied value. If no tax code is provided, it is derived from PM_PART using the part number and the dealer or principal map code. If the derivation also fails, the tax code is set to NULL.
- BR-006 - PM_PART_VAR is updated only when the resolved MRP is greater than zero; a zero or unresolved MRP suppresses all updates.
- BR-007 - For mass-update dealer locations, after updating PM_PART_VAR, the corresponding row in PI_PM_PART_MRP is flagged with mass_update = 'Y' to record that the mass-update pricing cycle has been applied for that part and principal map code.
- BR-008 - All UPDATE statements against PM_PART_VAR record the current system date and time in the UPDATED_DATE column, formatted as DD-MON-RRRR HH24:MI:SS, to maintain an audit trail of the last price refresh.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
PROCEDURE        Sp_Update_Part_Price (
                                                  p_parent        VARCHAR2,
                                                  p_dealer        NUMBER,
                                                  p_loc_cd        VARCHAR2,
                                                  p_part_tax_cd   VARCHAR2,
                                                  p_part_num      VARCHAR2
                                                 )
IS
      lv_ls               NUMBER;
      lv_os               NUMBER;
      TYPE t IS REF CURSOR;
      t1                  t;
      lv_parent           VARCHAR2 (2000)                   := p_parent;
      lv_dealer           NUMBER                            := p_dealer;
      lv_loc_cd           VARCHAR2 (2000)                   := p_loc_cd;
      lv_sql              VARCHAR2 (2500);
      lv_tax_cd           VARCHAR2 (100)                    := p_part_tax_cd;
      lv_created_date     DATE;
      lv_modified_date    DATE;
      lv_updated_date     DATE;
      lv_consg_cd         am_dealer_loc.consg_cd%TYPE;
      lv_purchase_price   pm_part_var.purchase_price%TYPE;
      lv_mrp_1            pm_part_var.mrp_1%TYPE;
      lv_dlr_type         am_dealer_loc.dealer_type%type; -- Added by Rajeev
      ln_pmc              am_dealer_loc.principal_map_cd%type; --Added by Rajeev for multi company changes
BEGIN
      BEGIN
            SELECT consg_cd, dealer_type, principal_map_cd
              INTO lv_consg_cd, lv_dlr_type, ln_pmc
              FROM am_dealer_loc
             WHERE dealer_map_cd = p_dealer
               AND loc_cd = p_loc_cd
               AND parent_group = p_parent;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                  NULL;
            WHEN TOO_MANY_ROWS THEN
                  NULL;
            WHEN OTHERS THEN
                  NULL;
      END;
      IF lv_consg_cd IS NOT NULL THEN
        IF lv_dlr_type != 'M' then -- If conditin added by rajeev
            BEGIN
                  SELECT purchase_price,
                         mrp_1
                    INTO lv_purchase_price,
                         lv_mrp_1
                    FROM PI_PART_PRICE_MASTER pi
                   WHERE consg_cd = lv_consg_cd
                     AND part_num = p_part_num
                     AND pi.principal_map_cd = ln_pmc  --Added by Rajeev for multi company changes
                     AND revision_date = (SELECT MAX ( revision_date)
                                            FROM PI_PART_PRICE_MASTER
                                           WHERE part_num = pi.part_num
                                             AND consg_cd = pi.consg_cd
                                             AND principal_map_cd = pi.principal_map_cd --Added by Rajeev for multi company changes
                                           );
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 := 0;
                  WHEN TOO_MANY_ROWS THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 :=0;
                  WHEN OTHERS THEN
                        lv_purchase_price := 0;
                        lv_mrp_1 := 0;
            END;
         ELSIF lv_dlr_type = 'M' THEN -- below else block added by rajeev for updated mrp for mass location
            BEGIN
                  SELECT mrp
                    INTO lv_mrp_1
                    FROM pi_pm_part_mrp pi
                   WHERE part_num = p_part_num
                     AND principal_map_cd = ln_pmc  --Added by Rajeev for multi company changes AND EFF_FROM_DT =
                    /****begin********below code added by added by ravi 0411201 **/
										 AND EFF_FROM_DT=(SELECT MAX(EFF_FROM_DT)
                        FROM PI_PM_PART_MRP
                       WHERE PART_NUM = PI.PART_NUM
                         AND PRINCIPAL_MAP_CD = PI.PRINCIPAL_MAP_CD)
											/***end********added by ravi 0411201 **/
                     --AND nvl(mass_update,'N') = 'N'
                     ;
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_mrp_1 := 0;
                  WHEN TOO_MANY_ROWS THEN
                        lv_mrp_1 :=0;
                  WHEN OTHERS THEN
                        lv_mrp_1 := 0;
            END;
         END IF;
      ELSE
            lv_purchase_price := 0;
            lv_mrp_1 := 0;
      END IF;

     IF p_part_tax_cd IS NULL THEN
            BEGIN
              select part_tax_cd
              into lv_tax_cd
              from pm_part
              where dealer_map_cd in (lv_dealer,ln_pmc)
                and part_num=p_part_num;
   /*                SELECT sp_stax_cd
                    INTO lv_tax_cd
                    FROM am_dealer_loc_param
                   WHERE parent_group = lv_parent
                     AND dealer_map_cd = lv_dealer
                     AND loc_cd = lv_loc_cd;*/ ---Commented by Ravi against gst changes
            EXCEPTION
                  WHEN NO_DATA_FOUND THEN
                        lv_tax_cd := NULL;
                  WHEN TOO_MANY_ROWS THEN
                        lv_tax_cd := NULL;
                  WHEN OTHERS THEN
                        lv_tax_cd := NULL;
            END;
      END IF;
--      DBMS_OUTPUT.put_line (lv_parent || lv_dealer || lv_loc_cd || lv_tax_cd || p_part_num);
   --   Sp_Get_Selling_Price (lv_parent, lv_dealer, lv_loc_cd, lv_tax_cd, lv_mrp_1,lv_ls, lv_os);
 --     DBMS_OUTPUT.put_line ('LS factor ' || lv_ls || ' - ' || 'OS factor ' || lv_os);
     IF lv_mrp_1>0 then-----------22072017
     IF lv_dlr_type != 'M' then
      lv_sql :=
               'UPDATE PM_PART_VAR SET purchase_price =nvl('
            || lv_purchase_price || ',0)'
           /* || ',0),LS_SELL_PRICE='         -----------blocked by rohit 12.06.2017(GST chages)------
            || lv_ls
            || ',OS_SELL_PRICE='
            || lv_os  */                       ----------------------
            || ',mrp_1=nvl('---------rohit 01/07/2017
            || lv_mrp_1
            || ',0)'
            ||',part_tax_cd='''
            || lv_tax_cd
            ||''',warranty_tax_cd='''
            || lv_tax_cd
            || ''',UPDATED_DATE=TO_DATE('''
            || TO_CHAR (SYSDATE, 'DD-MON-RRRR HH24:MI:SS')
            || ''','
            || '''DD-MON-RRRR HH24:MI:SS'')
          WHERE PARENT_GROUP='''
            || lv_parent
            || ''' AND DEALER_MAP_CD='
            || lv_dealer
            || ' AND LOC_CD='''
            || lv_loc_cd
            || ''''
            || ' and part_num='''
            || p_part_num
            || '''';
	-- dbms_output.put_line(lv_sql);
       EXECUTE IMMEDIATE lv_sql;
     ELSIF lv_dlr_type = 'M' THEN
      lv_sql :=
              'UPDATE PM_PART_VAR SET'
         /*  || 'LS_SELL_PRICE='              -----------blocked by rohit 12.06.2017(GST chages)------
            || lv_ls
            || ',OS_SELL_PRICE='
           || lv_os
            || ',mrp_1=nvl('  */              ----------------
            || ' mrp_1=nvl('  ---- rohit 01/07/2017
            || lv_mrp_1
            || ',0), part_tax_cd='''
            || lv_tax_cd
            ||''',warranty_tax_cd='''     -- Modified by Anand on 06-11-2017
            || lv_tax_cd
            || ''',UPDATED_DATE=TO_DATE('''
            || TO_CHAR (SYSDATE, 'DD-MON-RRRR HH24:MI:SS')
            || ''','
            || '''DD-MON-RRRR HH24:MI:SS'')
          WHERE PARENT_GROUP='''
            || lv_parent
            || ''' AND DEALER_MAP_CD='
            || lv_dealer
            || ' AND LOC_CD='''
            || lv_loc_cd
            || ''''
            || ' and part_num='''
            || p_part_num
            || '''';
	 dbms_output.put_line(lv_sql);
       EXECUTE IMMEDIATE lv_sql;
        UPDATE pi_pm_part_mrp
           SET mass_update = 'Y'
         WHERE part_num = p_part_num
           AND principal_map_cd = ln_pmc;  --Added by Rajeev for multi company changes
     END IF;
     END IF;
		-- dbms_output.put_line(lv_sql);
END;

```

#### SP-098 - SP_UPDATE_PO_NUMBER_NEW

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PO DETAILS (N/A / CN_PARTY)

---

**Purpose**

Maintains the Purchase Order (PO) voucher number sequence in PM_NUMBER_GEN for document type 'SPO'. When a PO number generation record already exists for the given combination of parent group, principal, dealer, location, financial year/month, and PO type, the procedure increments its running counter by one. When no such record exists, it inserts a new seed row initialising the counter to 1. The procedure is triggered from the PO Details screen (pt_soq_new_fmb.xml) on a button press and returns a structured error code and message to the caller on any failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_parent_group | VARCHAR2 | IN |
| p_principal_cd | NUMBER | IN |
| p_comp_fa | VARCHAR2 | IN |
| p_dealer | VARCHAR2 | IN |
| p_loc_cd | VARCHAR2 | IN |
| p_user_name | VARCHAR2 | IN |
| p_po_type | VARCHAR2 | IN |
| p_po_desc | VARCHAR2 | IN |
| p_fin_year | NUMBER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_err_msg | VARCHAR2 | OUT |
| p_err_cd | NUMBER | OUT |

---

**Dependencies**

- D2KWUTIL.CREATED_DATE ([SP-009](#SP-009--D2KWUTIL.CREATED_DATE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive all input parameters: parent group, principal code, company FA, dealer, location code, user name, PO type, PO description, and financial year.
- Step 2 - Construct the voucher month key by concatenating p_fin_year with the current calendar month, left-padded to two digits (e.g. '202405'), using SYSDATE for the month portion.
- Step 3 - Attempt to UPDATE PM_NUMBER_GEN, incrementing vou_num_gen by 1, where the row matches parent_group, principal_map_cd, dealer_map_cd, loc_cd, doc_type = 'SPO', comp_fa, vou_month (as constructed in Step 2), and vou_type.
- Step 4 - Evaluate SQL%ROWCOUNT to determine whether the UPDATE affected any row.
- Step 5 - If SQL%ROWCOUNT = 0 (no existing record), INSERT a new row into PM_NUMBER_GEN with vou_num_gen initialised to 1, doc_type = 'SPO', doc_desc set from p_po_desc, created_by set from p_user_name, and created_date set to SYSDATE.
- Step 6 - If any exception occurs during the INSERT (VALUE_ERROR, DUP_VAL_ON_INDEX, or OTHERS), populate p_err_msg with a prefixed '1 ...' message and set p_err_cd to 1.
- Step 7 - If any exception occurs at the outer block level during the UPDATE phase (VALUE_ERROR, DUP_VAL_ON_INDEX, or OTHERS), populate p_err_msg with a prefixed '2 ...' message and set p_err_cd to 1.
- Step 8 - On successful completion (no exceptions), p_err_cd and p_err_msg remain unpopulated (implying success to the caller).

---
**Decision Points**

DP-001

Condition: SQL%ROWCOUNT = 0 after the UPDATE on PM_NUMBER_GEN.

TRUE: No matching voucher number generation record exists for the given key; proceed to INSERT a new seed row into PM_NUMBER_GEN with vou_num_gen = 1.

FALSE: A matching record was found and successfully incremented; skip the INSERT block and complete normally.

---

DP-002

Condition: A VALUE_ERROR exception is raised during the INSERT block (inner exception handler).

TRUE: Set p_err_msg to '1 Width problem/Incompatible data while updating vou_num_gen' and p_err_cd to 1; terminate the INSERT block.

FALSE: Exception is not VALUE_ERROR; evaluate subsequent exception handlers (DP-003, DP-004).

---

DP-003

Condition: A DUP_VAL_ON_INDEX exception is raised during the INSERT block (inner exception handler).

TRUE: Set p_err_msg to '1 Trying to create duplicate data' and p_err_cd to 1; terminate the INSERT block.

FALSE: Exception is not DUP_VAL_ON_INDEX; fall through to the OTHERS handler (DP-004).

---

DP-004

Condition: Any other (OTHERS) exception is raised during the INSERT block (inner exception handler).

TRUE: Set p_err_msg to '1 Execution failed while updating vou_num_gen ' concatenated with SQLERRM, and set p_err_cd to 1.

FALSE: No exception; normal completion of the INSERT block.

---

DP-005

Condition: A VALUE_ERROR exception is raised at the outer block level (during the UPDATE phase).

TRUE: Set p_err_msg to '2 Width problem/Incompatible data while updating vou_num_gen' and p_err_cd to 1.

FALSE: Exception is not VALUE_ERROR at the outer level; evaluate subsequent outer handlers (DP-006, DP-007).

---

DP-006

Condition: A DUP_VAL_ON_INDEX exception is raised at the outer block level.

TRUE: Set p_err_msg to '2 Trying to create duplicate data' and p_err_cd to 1.

FALSE: Exception is not DUP_VAL_ON_INDEX at the outer level; fall through to the outer OTHERS handler (DP-007).

---

DP-007

Condition: Any other (OTHERS) exception is raised at the outer block level.

TRUE: Set p_err_msg to '2 Execution failed while updating vou_num_gen ' concatenated with SQLERRM, and set p_err_cd to 1.

FALSE: No exception at the outer level; procedure completes successfully.

---
**Database Interactions**

- DB-001 - Update PM_NUMBER_GEN - Updates existing rows in PM_NUMBER_GEN (columns: dealer map cd, principal map cd, loc cd, comp fa, doc type, vou type, vou month, vou num gen, and 4 more column(s)).
- DB-002 - Insert into PM_NUMBER_GEN - Persists a new row into PM_NUMBER_GEN using columns: dealer map cd, principal map cd, loc cd, comp fa, doc type, vou type, vou month, vou num gen, and 4 more column(s).
**Business Rules**

- BR-001 - The document type for all records managed by this procedure is fixed as 'SPO' (Supplier Purchase Order); no other doc_type value is used.
- BR-002 - The voucher month key is always derived by concatenating the supplied financial year (p_fin_year) with the current calendar month obtained from SYSDATE, left-padded to two digits. This means the record is always scoped to the actual calendar month in which the procedure executes, not a user-supplied month.
- BR-003 - The voucher number sequence follows an increment-or-initialise pattern: if a counter row already exists for the unique key (parent group, principal, dealer, location, comp FA, doc type 'SPO', vou month, PO type), it is incremented by exactly 1; if no row exists, a new row is created with vou_num_gen = 1, ensuring the sequence starts at 1 and has no gaps caused by missing seed rows.
- BR-004 - The unique key governing both the UPDATE filter and the INSERT uniqueness constraint comprises: parent_group, principal_map_cd, dealer_map_cd, loc_cd, comp_fa, doc_type ('SPO'), vou_month, and vou_type. A DUP_VAL_ON_INDEX error during INSERT indicates a race condition or concurrent insert on this key and is treated as a hard error.
- BR-005 - The created_date column on a newly inserted PM_NUMBER_GEN row is always set to SYSDATE at the time of insertion; no external date dependency (e.g. D2KWUTIL.CREATED_DATE) is invoked within this procedure's implementation logic.
- BR-006 - Error reporting uses a dual-prefix convention: errors originating in the inner INSERT exception block are prefixed '1 ', while errors originating in the outer UPDATE exception block are prefixed '2 ', allowing the caller to distinguish the phase in which the failure occurred.
- BR-007 - A non-zero p_err_cd (value 1) signals failure to the calling form trigger; the caller is responsible for interpreting p_err_msg and taking appropriate action. Successful execution leaves both output parameters unpopulated.

---
**Implementation Logic**

```plsql
CREATE OR REPLACE
Procedure Sp_Update_Po_Number_New
/*
$Log: SP_UPDATE_PO_NUMBER.sql,v $
Revision 1.3  2005/02/23 11:30:07  vidyah
exception handling
Revision 1.1  2004/08/21 05:50:58  sanjeevkn
As of 21 Aug, 04
*/
(
      p_parent_group         VARCHAR2,
      p_principal_cd         NUMBER,
      p_comp_fa              VARCHAR2,
      p_dealer               VARCHAR2,
      p_loc_cd               VARCHAR2,
      p_user_name            VARCHAR2,
      p_po_type              VARCHAR2,
      p_po_desc              VARCHAR2,
      p_fin_year             NUMBER,
      p_err_msg        OUT   VARCHAR2,
      p_err_cd         OUT   NUMBER
)
IS
BEGIN
      UPDATE pm_number_gen
         SET vou_num_gen = vou_num_gen + 1
       WHERE parent_group = p_parent_group
         AND principal_map_cd = p_principal_cd
         AND dealer_map_cd = p_dealer
         AND loc_cd = p_loc_cd
         AND doc_type = 'SPO'
         AND comp_fa = p_comp_fa
         AND vou_month = p_fin_year || LPAD (TO_CHAR (SYSDATE, 'MM'), 2, 0)
         AND vou_type = p_po_type;

      IF SQL%ROWCOUNT = 0 THEN

	  BEGIN
            INSERT INTO pm_number_gen
                        (dealer_map_cd,
                         principal_map_cd,
                         loc_cd,
                         comp_fa,
                         doc_type,
                         vou_type,
                         vou_month,
                         vou_num_gen,
                         parent_group,
                         doc_desc,
                         created_by,
                         created_date
                        )
                 VALUES (p_dealer,
                         p_principal_cd,
                         p_loc_cd,
                         p_comp_fa,
                         'SPO',
                         p_po_type,
                         p_fin_year || LPAD (TO_CHAR (SYSDATE, 'MM'), 2, 0),
                         1,
                         p_parent_group,
                         p_po_desc,
                         p_user_name,
                         SYSDATE
                        );
   EXCEPTION
      WHEN VALUE_ERROR THEN
            p_err_msg := '1 Width problem/Incompatible data while updating vou_num_gen ';
            p_err_cd := 1;
      WHEN DUP_VAL_ON_INDEX THEN
            p_err_msg := '1 Trying to create duplicate data';
            p_err_cd := 1;
      WHEN OTHERS THEN
            p_err_msg := '1 Execution failed while updating vou_num_gen ' || SQLERRM;
            p_err_cd := 1;
	  END;
      END IF;
EXCEPTION
      WHEN VALUE_ERROR THEN
            p_err_msg := '2 Width problem/Incompatible data while updating vou_num_gen ';
            p_err_cd := 1;
      WHEN DUP_VAL_ON_INDEX THEN
            p_err_msg := '2 Trying to create duplicate data';
            p_err_cd := 1;
      WHEN OTHERS THEN
            p_err_msg := '2 Execution failed while updating vou_num_gen ' || SQLERRM;
            p_err_cd := 1;
END;

```

#### SP-099 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw directory path string by removing any semicolon-delimited suffix and stripping a trailing backslash, returning a clean, single-path value. This function is called by directory-resolution routines (ATTEMPT_DLL_LOAD, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY) to ensure that path strings passed to downstream logic are well-formed and contain no extraneous separators.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-063](#SP-063--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input path string (InPath) and assign it to a local working variable (vcPath, max 500 characters).
- Step 2 - Search vcPath for the first occurrence of a semicolon (';'). If one is found, truncate vcPath to the substring preceding that semicolon, discarding any additional path entries that follow it.
- Step 3 - Inspect the last character of the (possibly truncated) vcPath. If it is a backslash ('\'), remove it by taking the substring up to but not including the final character.
- Step 4 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition:
The working path string (vcPath) contains at least one semicolon character - INSTR(vcPath, ';') > 0.

TRUE:
vcPath is truncated to the substring before the first semicolon, retaining only the first path entry and discarding everything from the semicolon onward.

FALSE:
vcPath is left unchanged and processing continues to DP-002.

---

DP-002

Condition:
The last character of vcPath is a backslash - SUBSTR(vcPath, -1, 1) = '\'.

TRUE:
The trailing backslash is removed by taking SUBSTR(vcPath, 1, LENGTH(vcPath) - 1).

FALSE:
vcPath is left unchanged and the current value is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - When a path string contains one or more semicolons, only the portion before the first semicolon is treated as the valid path; all subsequent entries are discarded.
- BR-002 - A path string must not end with a backslash ('\'); if a trailing backslash is present it is unconditionally removed before the value is returned.
- BR-003 - The input path is processed in the order: semicolon stripping first, then trailing-backslash stripping, ensuring both sanitisations are applied to the same working value.
- BR-004 - The function does not raise an error for a NULL or empty input; it applies the same substring logic, which safely returns NULL or an empty string respectively.
- BR-005 - The maximum supported path length is 500 characters; input values exceeding this limit will be subject to implicit truncation by the local variable declaration.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-100 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- pt_soq_new_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

PART AND STOCK DETAILS (N/A / CN_SOQ)

---

**Purpose**

Generates and delivers a CSV-formatted Excel report to the client workstation from the PART AND STOCK DETAILS screen (CN_SOQ). The procedure determines the appropriate report-generation path based on whether a report server is configured for the given principal and application, either invoking a remote database procedure to produce the CSV file or building it locally from an Oracle Forms record group, then transferring the resulting file to the client via WebUtil and opening it automatically.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-038](#SP-038--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-039](#SP-039--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-041](#SP-041--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-054](#SP-054--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-057](#SP-057--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-058](#SP-058--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-066](#SP-066--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-077](#SP-077--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS to retrieve the report server identifier (rep_server) for the supplied principal (p_principal) and application ID (p_app_id); if no matching row exists, rep_server is set to NULL.
- Step 2 - Evaluate whether a report server is configured (rep_server IS NOT NULL) to select the server-side or client-side generation path.
- Step 3 (both paths) - Determine the output file name: if p_file_name is NULL, prompt the user with WEBUTIL.FILE_SAVE_DIALOG to choose a save location; otherwise use p_file_name directly, then append the '.csv' extension.
- Step 4 (both paths) - Validate the resolved file path for embedded spaces; if any folder name in the path contains a space, override the path to 'C:\<filename>' and display an informational message to the user.
- Step 5a (server path) - Call the remote procedure sp_csv_report_generate via the database link dms1_db3_lnk, passing the file name and query, to generate the CSV on the database server.
- Step 6a (server path) - Execute a UNIX shell command via WEBUTIL.HOST to move the generated file from the UTL directory (/utl_dir/) to the reports printer directory (/iashome/ias/reports/printer/).
- Step 5b (client path) - Locate or clear an existing Forms record group named 'DataRecordSet', create a new record group from p_query, populate it, and obtain the row count.
- Step 6b (client path) - Open a server-side file for writing in the reports printer directory, iterate over every row in the record group, write the value of the specified column (p_column_name) followed by a newline using WEBUTIL.PUTF, then close the file with WEBUTIL.FCLOSE.
- Step 7 (both paths) - Read the base URL path from the configuration file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN and WEBUTIL.GET_LINE, then close the file with WEBUTIL.FCLOSE.
- Step 8 (both paths) - Construct the full server URL by concatenating the URL path with the file name, then transfer the file to the client workstation using WEBUTIL.URL_TO_CLIENT; if the transfer fails, display a 'File Transfer failed' message and pause.
- Step 9 (both paths) - Open the transferred CSV file on the client by issuing a 'cmd /c <filename>' command via WEBUTIL.HOST.
- Step 10 - If any unhandled exception occurs, display the Oracle error code and error text and raise FORM_TRIGGER_FAILURE to halt processing.

---
**Decision Points**

DP-001

Condition:
rep_server retrieved from EH_REPORTS IS NOT NULL (a report server is configured for the given principal and application).

TRUE:
Use the server-side path: generate the CSV via the remote database procedure sp_csv_report_generate, move the file using a UNIX shell command, read the URL base path, transfer the file to the client, and open it.

FALSE:
Use the client-side path: build the CSV locally using an Oracle Forms record group populated from p_query, write column values row by row to a server file, read the URL base path, transfer the file to the client, and open it.

DP-002

Condition:
p_file_name IS NULL.

TRUE:
Prompt the user with WEBUTIL.FILE_SAVE_DIALOG to interactively select the save location and file name.

FALSE:
Use the value supplied in p_file_name as the base file name.

DP-003

Condition:
The resolved file path contains at least one space character in a folder name (INSTR(FILENAME, ' ') > 0).

TRUE:
Override the file path to 'C:\<filename_only>' and display an informational message advising the user that the file will be saved to the C drive.

FALSE:
Retain the originally resolved file path without modification.

DP-004

Condition:
The Boolean result of WEBUTIL.URL_TO_CLIENT (file_transfer_bool) is FALSE.

TRUE:
Display a 'File Transfer failed' message and pause execution.

FALSE:
Continue processing and open the transferred file on the client via WEBUTIL.HOST.

DP-005

Condition:
(Client-side path only) A Forms record group named 'DataRecordSet' already exists, evaluated using WEBUTIL.ID_NULL.

TRUE:
Delete the existing record group before creating a new one from p_query.

FALSE:
Proceed directly to creating the record group from p_query.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report server to be used is determined exclusively by the combination of principal (p_principal) and application ID (p_app_id) as stored in EH_REPORTS; if no matching record exists the procedure falls back to local record-group-based CSV generation.
- BR-002 - The output file must always carry a '.csv' extension; the extension is appended programmatically to p_file_name regardless of any extension already present in the supplied value.
- BR-003 - File paths containing spaces in any folder name are not permitted; the procedure automatically redirects the output to the root of the C drive ('C:\') and notifies the user, ensuring the file can be saved and transferred without error.
- BR-004 - The base URL used to construct the server-side download path must be read at runtime from the configuration file located at /reports/DMS/excelpath.txt; no hardcoded URL is permitted.
- BR-005 - In the client-side path, any pre-existing Forms record group named 'DataRecordSet' must be deleted before a new one is created, preventing stale data from being included in the report.
- BR-006 - Each data row written to the CSV file must be terminated with a newline character (CHR(10)) to ensure correct line separation when the file is opened in Excel.
- BR-007 - If the file transfer to the client workstation fails, the user must be explicitly notified with a 'File Transfer failed' message and execution must pause, preventing a silent failure.
- BR-008 - Upon successful transfer, the CSV file must be opened automatically on the client workstation using a Windows command shell invocation ('cmd /c'), providing immediate access to the report.
- BR-009 - Any unhandled exception must surface the Oracle error code and error text to the user and raise FORM_TRIGGER_FAILURE, ensuring the calling trigger is aware of the failure and no partial state is silently committed.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-101 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a debug-string output facility by delegating to the external D2KWUtil debug string function via the WIN_API framework. It accepts a text string, appends a newline character, registers the required external function call, and invokes D2KWUTIL.D2KWUTIL_DEBUGSTRING to emit the debug output. If the WIN_API layer is unavailable or an unexpected error occurs, it captures and surfaces a structured error before re-raising.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-080](#SP-080--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-081](#SP-081--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-012](#SP-012--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-089](#SP-089--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter Text (VARCHAR2) and initialise a local buffer (vcBuff1) by appending a newline character (CHR(10)) to the supplied text.
- Step 2 - Evaluate whether the WIN_API framework is active by checking WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for 'D2KWUTIL_DEBUGSTRING' with the WIN_API framework by invoking REGISTER_FUNCTION_CALL, passing the debug-string function handle (iDebugString), the function name literal, a NULL placeholder, and the '*CHAR' type descriptor.
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer (vcBuff1), to emit the debug string through the external utility.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - On a WIN_API.NOT_AVAILABLE exception, call ADD_ERROR with the procedure name 'WinDebug' and the WIN_API.NoAPI error code to record the unavailability, then re-raise the exception to the caller.
- Step 7 - On any other exception, call ADD_ERROR with the procedure name 'WinDebug' and a composite error message built from WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS, then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition: WIN_API.API_ENABLED evaluates to TRUE.

TRUE: Register the external function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to emit the debug string.

FALSE: Raise the WIN_API.NOT_AVAILABLE exception, which is subsequently caught by the dedicated exception handler.

---

DP-002

Condition: The WIN_API.NOT_AVAILABLE exception is raised (either explicitly from DP-001 FALSE branch or propagated from the API call).

TRUE: Call ADD_ERROR with the 'WinDebug' context and the WIN_API.NoAPI error code, then re-raise the exception.

FALSE: Exception is not WIN_API.NOT_AVAILABLE; fall through to the OTHERS handler.

---

DP-003

Condition: An unexpected (non-WIN_API.NOT_AVAILABLE) exception is raised during processing.

TRUE: Call ADD_ERROR with the 'WinDebug' context and a composite error message formed by concatenating WIN_API.UError with the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

FALSE: No unexpected exception; procedure completes normally after emitting the debug string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure may only execute its debug-string output logic when the WIN_API framework is active (WIN_API.API_ENABLED is TRUE); execution without an available API is treated as an error condition.
- BR-002 - The input text must always be suffixed with a newline character (CHR(10)) before being passed to the external debug string function, ensuring consistent line termination in debug output.
- BR-003 - The external function 'D2KWUTIL_DEBUGSTRING' must be registered via REGISTER_FUNCTION_CALL before it is invoked; the registration uses the '*CHAR' type descriptor and the iDebugString handle.
- BR-004 - A WIN_API.NOT_AVAILABLE error must be recorded through ADD_ERROR using the WIN_API.NoAPI error code before the exception is re-raised, ensuring the unavailability is logged in the error stack.
- BR-005 - All unexpected errors must be recorded through ADD_ERROR using a composite message that combines WIN_API.UError with any additional external error details retrieved via ADD_EXTERNAL_ERRORS before the exception is re-raised.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

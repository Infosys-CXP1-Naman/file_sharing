# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
    - Business Scenarios - How the report output differs by Report Type
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
    - Requirement ID: BR-015
    - Requirement ID: BR-016
    - Requirement ID: BR-017
    - Requirement ID: BR-018
    - Requirement ID: BR-019
    - Requirement ID: BR-020
    - Requirement ID: BR-021
    - Requirement ID: BR-022
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Pre-Enquiry Campaign - MULDMS.PRE_ENQ_CAMPAIGN
    - Dealer Location - MULDMS.AM_DEALER_LOC
    - Regional Master - MULDMS.GM_REGN
    - Enquiry Header - MULDMS.RH_ENQ
    - Enquiry Detail - MULDMS.RD_ENQ
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (Reporting User - before submitting the report)
    - Session / Application Parameters
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
    - GENERAL (DPL.pld / DPL.pll)
    - DBMS_APPLICATION_INFO (Built-in Oracle Package)
    - VIEW_EXCEL_REPORT_NEW (DMS_EXCEL_REPORT.pld / .pll)
    - WEB (DPL.pld / DPL.pll)
    - SF_COPYRIGHT_DECLARATION (DPL.pld / DPL.pll)
    - Form-Local Program Units
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - DPL.pld (`general`)
  - webutil.pld (`WEBUTIL_C_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - D2KWUTIL.CHOOSEFILE
    - SP-002 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-003 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-004 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-005 - D2KWUTIL.SAVE_FILE
    - SP-006 - GENERAL.ASK_CONFIRM
    - SP-007 - GENERAL.DISP_TEXT
    - SP-008 - GENERAL.L_POP_LIST_ITEM
    - SP-009 - GENERAL.RAISE_ERROR
    - SP-010 - WEBUTIL.ADD_PARAMETER
    - SP-011 - WEBUTIL.BLOCKING
    - SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-013 - WEBUTIL.CREATE_PARAMETER_LIST
    - SP-014 - WEBUTIL.DESTROY_PARAMETER_LIST
    - SP-015 - WEBUTIL.DOWNLOADFROMURL
    - SP-016 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-017 - WEBUTIL.ERROR
    - SP-018 - WEBUTIL.ERRORALERT
    - SP-019 - WEBUTIL.EXECUTE
    - SP-020 - WEBUTIL.FCLOSE
    - SP-021 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-022 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-023 - WEBUTIL.FOPEN
    - SP-024 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-025 - WEBUTIL.GETIMPLCLASS
    - SP-026 - WEBUTIL.GETOUTPUT
    - SP-027 - WEBUTIL.GETPROPERTY
    - SP-028 - WEBUTIL.GETVAR
    - SP-029 - WEBUTIL.GET_LINE
    - SP-030 - WEBUTIL.GET_PARAMETER_STRING
    - SP-031 - WEBUTIL.GET_RETURN_CODE
    - SP-032 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-033 - WEBUTIL.HOST
    - SP-034 - WEBUTIL.ID_NULL
    - SP-035 - WEBUTIL.INIT
    - SP-036 - WEBUTIL.INITWEBUTIL
    - SP-037 - WEBUTIL.INVOKE_INT
    - SP-038 - WEBUTIL.INVOKE_INTEGRAL
    - SP-039 - WEBUTIL.INVOKE_WU
    - SP-040 - WEBUTIL.ISERROR
    - SP-041 - WEBUTIL.IS_OPEN
    - SP-042 - WEBUTIL.LENGTH
    - SP-043 - WEBUTIL.LOG
    - SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-045 - WEBUTIL.PUTF
    - SP-046 - WEBUTIL.PUT_LINE
    - SP-047 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-048 - WEBUTIL.REGISTER_FUNCTION
    - SP-049 - WEBUTIL.RELEASE_PROCESS
    - SP-050 - WEBUTIL.SETPROPERTY
    - SP-051 - WEBUTIL.SHOWBEANS
    - SP-052 - WEBUTIL.URL_TO_CLIENT
    - SP-053 - ADD_ERROR
    - SP-054 - ADD_EXTERNAL_ERRORS
    - SP-055 - BOOLTOCHAR
    - SP-056 - CLEAN_ERROR_STACK
    - SP-057 - DEBUGLOG
    - SP-058 - GET_ENVIRONMENT_STRING
    - SP-059 - GET_TEMP_DIRECTORY
    - SP-060 - GET_WINDOWS_DIRECTORY
    - SP-061 - READ_REGISTRY
    - SP-062 - REGISTER_FUNCTION_CALL
    - SP-063 - SF_COPYRIGHT_DECLARATION
    - SP-064 - STRIPDIRSEP
    - SP-065 - VIEW_EXCEL_REPORT_NEW

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | RR_PRE_ENQ - Business Requirements Document |
| Form Module Name | RR_PRE_ENQ |
| Document Version | 1.0 |
| Date Created | October 16, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | October 16, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the rr_pre_enq Pre-Enquiry Detail/Summary Report form, its purpose, and roles referenced in the module.*

The **rr_pre_enq** Oracle Forms module is the **Pre-Enquiry Detail/Summary Report** screen used within the Dealer Management System. A dealer user opens **rr_pre_enq**, selects their zone, region, and dealer outlet from guided pick-lists, and then specifies a reporting date range of up to one calendar month. The user chooses a campaign, a report type (Detail or Summary), and an output destination before clicking the submit button to generate the report as an Excel file. The form validates all mandatory criteria - ensuring the zone and dealer are selected, the from-date is not in the future, and the to-date falls within one month of the from-date - before building the report. Once submitted, the report output is cleaned and displayed to the user. All criteria lists are scoped to the user's authorised zones and the principal they are operating under.

### Key Stakeholders

*Who uses rr_pre_enq*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User** | Primary interactive user of rr_pre_enq. Selects zone, region, dealer outlet, campaign, and date range criteria, then submits the report for generation. |

---

---

## 3. System Context

*Describes the rr_pre_enq module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **rr_pre_enq** module is the **Pre-Enquiry Detail/Summary Report** screen within the Dealer Management System. It provides dealer users with a structured way to configure and generate pre-enquiry activity reports filtered by zone, region, dealer outlet, campaign, and date range. The generated Excel report connects dealer-facing enquiry activity with back-office reporting and analytical workflows.

**System purpose:** Allow a dealer user to select zone, region, dealer, campaign, and date range criteria, validate the inputs, and generate a pre-enquiry Detail or Summary Excel report - as implemented in the rr_pre_enq Oracle Forms module.

**In scope:**

- Load and display the report screen, set the default date range, and restrict the zone selection to the user's authorised zones
- Select a zone from the authorised zone list to filter region and dealer options
- Select a region from a zone-filtered list of available regions
- Select a dealer outlet from a zone-and-region-filtered list of dealer locations
- Specify a reporting from-date, with validation that it is not in the future and automatic defaulting of the to-date to the end of the from-date's month
- Specify a reporting to-date, with validation that it is within one calendar month of the from-date and not in the future
- Select a campaign from a list filtered by dealer, region, and zone
- Choose report type (Detail or Summary) and output destination
- Submit the criteria to generate a parameterised Excel report
- Clean the report output file and display it to the user

**Process Name:** Pre-Enquiry Report Generation

**Process Owner:** Dealer Management System Administrator

**Process Objective:** Open the report criteria screen, select zone, region, dealer, campaign, and date range, validate all mandatory inputs, and generate a pre-enquiry Excel report for the selected criteria.

**Process Trigger:** A dealer user opens the Pre-Enquiry Detail/Summary Report screen to analyse pre-enquiry activity for a specific period

**Process Flow:**

The complete pre-enquiry report generation process follows this sequence. Each step corresponds to Functional Requirements BR-001 through BR-010 in Section 4.

```
STEP 1 ── SCREEN OPENS (BR-001)
         The dealer user opens the Pre-Enquiry Detail/Summary Report screen.
         The zone selection list is loaded with only the zones authorised for the logged-in user.
         The report title is set, and the current date is applied as the default from-date.

STEP 2 ── ZONE SELECTION (BR-002)
         The user selects a zone from the authorised zone list.
         Selecting a zone clears any previously chosen region and dealer values,
         and refreshes the region and dealer selection lists for the chosen zone.

STEP 3 ── REGION SELECTION (BR-003)
         The user selects a region from the zone-filtered region list.
         The region code is recorded internally for use in subsequent dealer and campaign filtering.

STEP 4 ── DEALER OUTLET SELECTION (BR-004)
         The user selects a dealer outlet from the list filtered by zone and region.
         ├── SPECIFIC DEALER: A single dealer outlet is chosen; dealer code and location are recorded.
         └── ALL DEALERS: The 'ALL' option is selected to include all outlets in the report.

STEP 5 ── FROM-DATE ENTRY AND VALIDATION (BR-005)
         The user enters or selects the report from-date.
         The system validates that the from-date is not in the future.
         The to-date is automatically set to the last day of the from-date's month.

STEP 6 ── TO-DATE ENTRY AND VALIDATION (BR-006)
         The user confirms or adjusts the report to-date.
         The system validates that the to-date is on or after the from-date,
         is not in the future, and is within one calendar month of the from-date.

STEP 7 ── CAMPAIGN SELECTION (BR-007)
         The user selects a campaign from the list filtered by dealer, region, and zone.
         ├── SPECIFIC CAMPAIGN: A single campaign is chosen; campaign code is recorded.
         └── ALL CAMPAIGNS: The 'ALL' option is selected to include all campaigns.

STEP 8 ── REPORT TYPE SELECTION (BR-008)
         The user selects Detail or Summary report type.
         The report type controls the level of data included in the generated Excel report.

STEP 9 ── OUTPUT DESTINATION SELECTION (BR-009)
         The user selects the output destination (screen display or file output).

STEP 10 ── SUBMIT AND GENERATE REPORT (BR-010)
          The user clicks the Submit Report button.
          The system validates that zone, dealer, and date range inputs are complete.
          A parameterised report query is built for the chosen Detail or Summary report type.
          The Excel report is generated with the filtered pre-enquiry data.
          The output file is cleaned of any formatting artefacts and displayed to the user.
```

**Major process interactions:**

- **User authorisation data** - restricts the zone selection list to zones the logged-in user is permitted to access
- **Region master data** - provides the list of regions available for the selected zone
- **Dealer outlet master data** - provides dealer locations filtered by zone and region for selection
- **Campaign reference data** - provides pre-enquiry campaign codes filtered by dealer and region
- **List-of-values reference data** - provides dynamic picklist values for additional selection fields
- **Excel report engine** - receives the parameterised report criteria and generates the output file
- **Report output display** - cleaned output file is opened and displayed in the browser for the user

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Registration and Application Logging Initialisation

**Business Description:**
Before the Pre-Enquiry report screen opens, the system registers the current form session with the database so that database administrators and performance monitoring tools can identify which application module the user is running. If the organisation has enabled application-level performance logging for the current session, the system also starts a timing counter so that the form's overall execution time can be measured and reported.

**Actors:** Reporting User

**Preconditions:**
- The user has launched the Pre-Enquiry Detail/Summary Report form from the application menu.

**Main Flow:**

**Step 1 - Database session labelled with module identity**
Before the form becomes visible, the system writes the module identifier "rr_pre_enq" and an empty action label into the current database session's application info. This allows database administrators to identify the running report module through standard Oracle session-monitoring tools.

**Step 2 - Performance logging timer started when enabled**
If the organisation has activated application-level performance logging for this session (controlled by an application session flag), the system starts a timing counter immediately. This counter is used to measure how long the form session runs.

---

#### Requirement ID: BR-002

**Requirement Title:** Form Startup: Window Maximisation, Default Date Range, Zone List Population, and Copyright Display

**Business Description:**
When the Pre-Enquiry report screen first opens, the system maximises both the application window and the report screen so that the full parameter entry area is visible. It then displays the report title on screen, sets the Campaign From Date to the first day of the current month and the To Date to today's date as convenient defaults, populates the Zone selection list with the zones the logged-in user is authorised to access, pre-selects the application identifier from the current session, and shows the current copyright notice at the bottom of the screen.

**Actors:** Reporting User

**Preconditions:**
- Session registration has completed (the form's pre-open actions have executed).

**Main Flow:**

**Step 1 - Application and report windows maximised**
The system maximises both the main application container window and the report's own window so that the full parameter entry area is visible to the user without manual resizing.

**Step 2 - Report title displayed on screen**
The system writes the fixed label "Pre-Enquiry Detail/Summary Report" into the report description display field at the top of the screen.

*Screen: `CN_MAIN`*

**Step 3 - Default date range applied**
The system automatically sets the Campaign From Date field to the first day of the current calendar month and the To Date field to today's date, giving the user a ready-made one-month reporting window to review or adjust before submitting.

*Screen: `CN_MAIN`*

**Step 4 - Application identifier captured from session**
The system reads the application identifier from the current session and stores it as a report parameter so that it is available to the report generation function when the user submits the report.

**Step 5 - Zone selection list populated with user's authorised zones**
The system queries the geographic zone master filtered to the zones the logged-in user is permitted to access (by user ID and principal map code), prepends an "ALL" option, and loads the resulting list into the Zone drop-down field. The user sees all zones they may report on, plus the option to select all of them at once.

*Screen: `CN_MAIN`*

*Procedures called:*
- **GENERAL.L_POP_LIST_ITEM** ([SP-008](#SP-008--GENERAL.L_POP_LIST_ITEM)) - GENERAL.L_POP_LIST_ITEM - Builds or rebuilds a named record group from a caller-supplied SQL query at form initialisation time, ensuring that any stale version of the group is replaced before the new query results are loaded into it.
    * **Step 1** - Look for an existing temporary data set with the supplied name; if one already exists, remove it to prevent stale data from a previous population.
    * **Step 2** - Create a new temporary data set from the caller-supplied query and execute it against the database.
    * **Step 3** - Load the query results into the on-screen list field so the user sees the updated choices.
    * **Step 4** - Make the populated results available in the list field for user selection.

**Step 6 - Zone list rendered from populated record group**
Immediately after the zone data is retrieved by the above operation, the system transfers the loaded data into the Zone drop-down control so it is ready for the user to select from.

*Screen: `CN_MAIN`*

**Step 7 - Copyright notice displayed**
The system calls the copyright function to determine the current financial year and writes the resulting copyright notice string to the copyright display field at the bottom of the screen.

*Screen: `CN_MAIN`*

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-063](#SP-063--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - Generates the copyright notice string for Maruti Suzuki India Limited, adjusted to reflect the current Indian financial year, so that the displayed copyright year correctly spans April-March boundaries rather than the calendar year.
    * **Step 1** - Capture today's date to determine which financial year is currently in progress.
    * **Step 2** - Check whether today's month falls in January, February, or March - the closing months of the Indian financial year.
    * **Step 3** - If the month is January, February, or March, use the previous calendar year as the start of the financial year for the copyright string.
    * **Step 4** - If the month is April through December, use the current calendar year as the start of the financial year.
    * **Step 5** - Return the formatted copyright string to the caller for display on screen.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-IC-01** - Zone list loaded - the Zone drop-down is populated with all zones the logged-in user is authorised to access, ready for selection.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Report Description (`REPORT_DESC`) | Auto-populated | Display Item | 200 / N/A | N/A | N/A | Form open | Read-only; system-assigned fixed label "Pre-Enquiry Detail/Summary Report" | N/A |
| Campaign From Date (`P_FROMDT`) | Auto-populated | Text Item - Date | 10 / DD/MM/RRRR | N/A | First day of current month | Form open | System default; user may override before submitting | N/A |
| To Date (`P_TODT`) | Auto-populated | Text Item - Date | 10 / DD/MM/RRRR | N/A | Current date (today) | Form open | System default; user may override before submitting | N/A |
| Zone (`P_ZONE`) | Auto-populated | List Item | N/A | Zone list (dynamic, from user authorisation and zone master) | Zone code | Form open | List populated from user's authorised zones; user must confirm or change before submitting | N/A |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display Item | 100 / N/A | N/A | Financial year copyright string | Form open | Read-only; system-generated copyright notice | N/A |

---

#### Requirement ID: BR-003

**Requirement Title:** Zone Selection: Dependent Filter Reset and Mandatory Value Validation

**Business Description:**
When the user changes the Zone selection on the report filter screen, the system immediately clears all downstream geographic filters - Region, Dealer, and Location - because those filters are only meaningful within a specific zone and must be re-selected for the newly chosen zone. When the user navigates away from the Zone field, the system also validates that a zone has been chosen; if the field is empty, the user is shown an error and prevented from continuing.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open and the Zone list has been populated.

**Main Flow:**

**Step 1 - Downstream geographic filters cleared on zone change**
Each time the user changes the Zone selection in the drop-down list, the system immediately clears the Region description field, the internal region code, the Dealer field, the Location description field, the internal dealer code, the internal parent group code, and the internal location code. This ensures that any previously selected region, dealer, or location values belonging to the old zone are not carried forward as a filter mismatch into the new zone's data.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dependent filter reset on zone change | WHEN-LIST-CHANGED on CB_BLK.P_ZONE - clears P_REGION_DESC, P_REGION_CD, P_DEALER_DESC, LOC_DESC, P_DEALER, P_PARENT, P_LOC | When the user changes the Zone drop-down selection | Prevents stale region, dealer, or location filter values from an earlier zone choice from being submitted with a new zone | Fields are cleared silently; the user must re-select a region and dealer before submitting the report |

**Step 2 - Zone value required for navigation**
When the user moves focus away from the Zone field, the system confirms that a zone has been selected. If no zone has been chosen, the system shows an error message and prevents the user from moving to another field until a valid zone is selected.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Zone must be selected | WHEN-VALIDATE-ITEM on CB_BLK.P_ZONE - checks that P_ZONE is not null | When the user attempts to move focus away from the Zone field | The Zone filter is required to scope report output to an authorised geographic area; a blank zone would allow an undefined report scope | *"Zone Code can not be empty"* is shown; the user is held on the Zone field (trigger failure raised) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Zone field left empty - *"Zone Code can not be empty"*; the user remains on the Zone field and must select a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Zone (`P_ZONE`) | Mandatory | List Item | N/A | Zone list (dynamic, from user authorisation and zone master) | Zone code ("ALL" or a specific zone code) | Zone list populated on form open | Must not be empty when user leaves the field | *"Zone Code can not be empty"* |
| Region Code (`P_REGION_DESC`) | Conditional - cleared when Zone changes | Text Item | N/A | Region LOV (`LV_REGION`) | Region description | Zone selected | Cleared automatically when Zone changes; user must re-select | N/A |
| Dealer (`P_DEALER_DESC`) | Conditional - cleared when Zone changes | Text Item | 500 | Dealer LOV (`LV_DEALER`) | Dealer name | Zone and Region selected | Cleared automatically when Zone changes | N/A |
| Location (`LOC_DESC`) | Conditional - cleared when Zone changes | Text Item | 500 | N/A | Location description | Dealer selected | Cleared automatically when Zone changes | N/A |

---

#### Requirement ID: BR-004

**Requirement Title:** Region Selection: Dependent Dealer and Location Reset, and Mandatory Region Validation

**Business Description:**
When the user selects or changes the Region on the filter screen, the system validates that the internal region code has been resolved from the lookup. If the region code is missing (meaning no valid region was actually selected), the user is shown an error and prevented from continuing. Once a valid region is confirmed, the system also clears the Dealer and Location fields, since those selections are specific to a region and must be re-chosen for the newly selected region.

**Actors:** Reporting User

**Preconditions:**
- A Zone has been selected.
- The user has opened the Region lookup or typed a region value in the Region field.

**Main Flow:**

**Step 1 - Internal region code validated and dependent fields cleared on navigation**
When the user moves focus away from the Region field, the system first confirms that the internal region code (resolved behind the scenes when a region is picked from the lookup) is not blank. If the code is missing, the system shows an error and prevents navigation. If the region code is present, the system clears the Dealer description field, the Location description field, the internal dealer code, the internal parent group code, and the internal location code - ensuring that any dealer or location previously selected under a different region is not carried forward.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region code must be resolved | WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_DESC - checks that P_REGION_CD is not null | When the user attempts to move focus away from the Region field | Ensures that a genuine, database-recognised region has been selected and its internal code captured, preventing an invalid or blank region from being submitted as a report filter | *"Region Code can not be empty"* is shown; the user is held on the Region field (trigger failure raised) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Region not resolved - *"Region Code can not be empty"*; the user remains on the Region field and must pick a valid region from the lookup before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region Code (`P_REGION_DESC`) | Mandatory | Text Item | N/A | Region LOV (`LV_REGION`) | Region description | Zone selected | Internal region code must be resolved on navigation away from field | *"Region Code can not be empty"* |
| Dealer (`P_DEALER_DESC`) | Conditional - cleared when Region changes | Text Item | 500 | Dealer LOV (`LV_DEALER`) | Dealer name | Region selected | Cleared automatically when Region changes; user must re-select | N/A |
| Location (`LOC_DESC`) | Conditional - cleared when Region changes | Text Item | 500 | N/A | Location description | Dealer selected | Cleared automatically when Region changes | N/A |

---

#### Requirement ID: BR-005

**Requirement Title:** Dealer Selection Mandatory Validation

**Business Description:**
When the user moves away from the Dealer field on the filter screen, the system checks that a dealer has been selected. A dealer selection is required before the report can be scoped to a specific outlet or submitted for "all dealers" in the region; leaving the field blank is not permitted. If the Dealer field is empty, the user is shown an error and must make a selection before continuing.

**Actors:** Reporting User

**Preconditions:**
- A Zone and Region have been selected.
- The user has opened the Dealer lookup or entered a dealer value.

**Main Flow:**

**Step 1 - Dealer description validated as non-blank on navigation**
When the user moves focus away from the Dealer field, the system checks whether the dealer description field contains a value. If the field is blank, the system shows an error message and prevents the user from navigating away until a dealer has been selected from the lookup.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer must be selected | WHEN-VALIDATE-ITEM on CB_BLK.P_DEALER_DESC - checks that P_DEALER_DESC is not null | When the user attempts to move focus away from the Dealer field | The Dealer filter is required to scope the report to a specific dealer outlet or to confirm an "All Dealers" selection; a blank dealer would leave the report unscoped | *"Dealer can not be empty"* is shown; the user is held on the Dealer field (trigger failure raised) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Dealer field left empty - *"Dealer can not be empty"*; the user remains on the Dealer field and must select a value before proceeding.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text Item | 500 | Dealer LOV (`LV_DEALER`) | Dealer name ("All Dealers" or a specific dealer name) | Zone and Region selected | Must not be blank when user leaves the field | *"Dealer can not be empty"* |

---






#### Requirement ID: BR-006

**Requirement Title:** Campaign From Date Entry, Validation, and Automatic To Date Recalculation

**Business Description:**
When the user enters or changes the Campaign From Date filter, the system validates it against several business rules: the date must be provided, must not be in the future, and must not be later than the To Date. If the date passes all checks, the system automatically recalculates the To Date to the last calendar day of the month containing the new From Date (or to today's date if that end-of-month falls in the future), keeping the date range within a single calendar month and avoiding a future To Date.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The user has entered or changed a value in the Campaign From Date field.

**Main Flow:**

**Step 1 - Campaign From Date validated against business rules**
When the user moves focus away from the Campaign From Date field, the system performs three sequential checks in order:

1. If the date is blank, the system shows *"From Date can not be empty"* and prevents navigation.
2. If the date is in the future (later than today), the system shows the alert message *"From Date cannot be greater than Current Date"* and prevents navigation.
3. If the date is later than the current To Date value, the system shows *"From Date cannot be greater than To Date"* and prevents navigation.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date must be provided | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - checks P_FROMDT is not null | When the user moves away from the Campaign From Date field | A date range is required to scope the report; an empty From Date would produce an unbounded query | *"From Date can not be empty"* shown; user held on the field (trigger failure raised) |
| From Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - checks P_FROMDT is not greater than SYSDATE | When the user moves away from the Campaign From Date field | Campaign data only exists for dates up to today; a future From Date would yield an empty report | Alert message *"From Date cannot be greater than Current Date"* shown; user held on the field (trigger failure raised) |
| From Date must not exceed To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_FROMDT - checks P_FROMDT is not greater than P_TODT | When the user moves away from the Campaign From Date field (after the future-date check passes) | The From Date must precede the To Date for a valid date range | Alert message *"From Date cannot be greater than To Date"* shown; user held on the field (trigger failure raised) |

**Step 2 - To Date automatically recalculated to end of month**
After the From Date passes all three checks, the system calculates the last calendar day of the month that contains the new From Date. If that last day falls in the future, the system sets the To Date to today's date instead. If the last day has already passed, the system sets the To Date to that last calendar day. This ensures the reporting window always covers exactly one month at most and never extends into the future.

*Screen: `CN_MAIN`*

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-ES-01** - From Date blank - *"From Date can not be empty"*; user must enter a date before proceeding.
- **BR-006-ES-02** - From Date is in the future - alert shown with message *"From Date cannot be greater than Current Date"*; user must enter a past or current date.
- **BR-006-ES-03** - From Date is after To Date - alert shown with message *"From Date cannot be greater than To Date"*; user must adjust the date.
- **BR-006-IC-01** - To Date recalculated - the To Date is automatically adjusted to the last day of the From Date's month (or today if that day is in the future).

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Campaign From Date (`P_FROMDT`) | Mandatory | Text Item - Date | 10 / DD/MM/RRRR | N/A | N/A | Form open | Must not be blank; must not be a future date; must not be after the To Date | *"From Date can not be empty"*; *"From Date cannot be greater than Current Date"*; *"From Date cannot be greater than To Date"* |
| To Date (`P_TODT`) | Auto-populated (recalculated) | Text Item - Date | 10 / DD/MM/RRRR | N/A | Last day of From Date's month (or today if in future) | From Date entered and validated | System-recalculated on From Date change; user may further adjust | N/A |

---



#### Requirement ID: BR-007

**Requirement Title:** To Date Entry and Validation Against Business Date Range Rules

**Business Description:**
When the user enters or changes the To Date filter, the system validates it against five sequential business rules: the date must be provided; a From Date must already have been entered before a To Date can be accepted; the To Date must not be earlier than the From Date; the To Date must not be in the future; and the date range between From Date and To Date must not exceed one calendar month. Any rule failure shows a specific message and prevents the user from leaving the field.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The user has entered or changed a value in the To Date field.

**Main Flow:**

**Step 1 - To Date validated against five sequential business rules**
When the user moves focus away from the To Date field, the system performs five checks in order:

1. If the To Date is blank, the system shows *"To Date can not be empty"* and prevents navigation.
2. If the From Date has not been entered, the system shows *"To date cannot be entered without entering From date"*, clears the To Date field, and prevents navigation.
3. If the To Date is earlier than the From Date, the system shows the alert message *"To Date cannot be lesser than From Date"* and prevents navigation.
4. If the From Date is later than the To Date (duplicate boundary check), the system shows *"From Date cannot be greater than To Date"* and prevents navigation.
5. If the To Date is in the future (later than today), the system shows *"To Date cannot be greater than Current Date"* and prevents navigation.
6. If the date range between From Date and To Date exceeds one calendar month, the system shows *"Please give the date range of maximum One month"* and prevents navigation.

*Screen: `CN_MAIN`*

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Date must be provided | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_TODT is not null | When the user moves away from the To Date field | The To Date is required to define the end of the reporting period | *"To Date can not be empty"* shown; user held on the field (trigger failure raised) |
| From Date must be present before To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_FROMDT is not null when P_TODT is not null | When the user moves away from the To Date field | The To Date has no meaning without a From Date; entering it first would create an invalid range | *"To date cannot be entered without entering From date"* shown; To Date field cleared; user held on field (trigger failure raised) |
| To Date must not precede From Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_TODT is not less than P_FROMDT | When the user moves away from the To Date field (after From Date presence check passes) | The reporting period must have a non-negative duration | Alert message *"To Date cannot be lesser than From Date"* shown; user held on the field (trigger failure raised) |
| From Date must not exceed To Date | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_FROMDT is not greater than P_TODT | When the user moves away from the To Date field | Duplicate boundary guard ensuring the range is valid from both ends | Alert message *"From Date cannot be greater than To Date"* shown; user held on the field (trigger failure raised) |
| To Date must not be in the future | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_TODT is not greater than SYSDATE | When the user moves away from the To Date field | Campaign data only exists up to today; a future To Date would include incomplete or non-existent data | Alert message *"To Date cannot be greater than Current Date"* shown; user held on the field (trigger failure raised) |
| Date range must not exceed one month | WHEN-VALIDATE-ITEM on CB_BLK.P_TODT - checks P_TODT does not exceed the last day of P_FROMDT's month | When the user moves away from the To Date field | Report queries are designed for single-month data volumes; a wider range would cause performance or data issues | Alert message *"Please give the date range of maximum One month"* shown; user held on the field (trigger failure raised) |

*Business outcomes (errors, warnings, success, and status):*
- **BR-007-ES-01** - To Date blank - *"To Date can not be empty"*; user must enter a date.
- **BR-007-ES-02** - To Date entered without a From Date - *"To date cannot be entered without entering From date"*; To Date field cleared; user must enter From Date first.
- **BR-007-ES-03** - To Date before From Date - alert shown with message *"To Date cannot be lesser than From Date"*.
- **BR-007-ES-04** - From Date after To Date (boundary duplicate) - alert shown with message *"From Date cannot be greater than To Date"*.
- **BR-007-ES-05** - To Date in the future - alert shown with message *"To Date cannot be greater than Current Date"*.
- **BR-007-ES-06** - Date range exceeds one month - alert shown with message *"Please give the date range of maximum One month"*.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Date (`P_TODT`) | Mandatory | Text Item - Date | 10 / DD/MM/RRRR | N/A | N/A | From Date entered | Must not be blank; must follow From Date in sequence; must not be future; range must not exceed one month | *"To Date can not be empty"*; *"To date cannot be entered without entering From date"*; *"To Date cannot be lesser than From Date"*; *"From Date cannot be greater than To Date"*; *"To Date cannot be greater than Current Date"*; *"Please give the date range of maximum One month"* |
| Campaign From Date (`P_FROMDT`) | Mandatory | Text Item - Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Must be present before To Date is entered | *"To date cannot be entered without entering From date"* |

---



#### Requirement ID: BR-008

**Requirement Title:** Pre-Enquiry Report Generation and CSV Export

**Business Description:**
When the user clicks the Submit Report button, the system builds a report data set from the pre-enquiry campaign and enquiry data matching the user's filter selections, and delivers the result as a CSV file to the user's computer for immediate review. The user may choose either a Detail report - which shows one row per pre-enquiry prospect with campaign, dealer, enquiry, booking, and invoice details - or a Summary report - which aggregates campaign follow-up outcome counts by region, dealer, and campaign. In both cases the output is a CSV file named with the user's login ID and a timestamp, and it is opened automatically on the user's device.

**Actors:** Reporting User

**Preconditions:**
- All mandatory filter parameters have been entered and validated: Zone, Region, Dealer, Campaign From Date, To Date, and Report Type.

**Main Flow:**

**Step 1 - Output filename constructed from user ID and current timestamp**
When the user clicks Submit Report, the system first constructs a unique output filename by combining the logged-in user's identifier with the current date and time (formatted as year, month, day, hour, minute, second) and appending the extension ".csv". This ensures each generated file is uniquely named.

**Step 2 - To Date boundary adjusted for query use**
The system adds one day to the selected To Date and stores the result internally. The report query uses this adjusted date as an exclusive upper bound (less-than comparison) rather than an inclusive one, ensuring that all records created on the To Date itself are included in the output.

**Step 3a - Detail report data set built and exported (Detail type selected)**
If the user selected the Detail report type, the system constructs a query that retrieves one row per pre-enquiry campaign record, joining to the dealer location master, regional master, and - via an outer join - the matching enquiry header and enquiry detail records. For each campaign record the output includes the region code, campaign code, campaign name, campaign loading date, target model, dealer code, outlet code, enquiry outlet location description, dealer name, dealer city, prospect name, reservation number, prospect address (special characters stripped), follow-up outcome (Interested, Call Back, Not Interested, Not Reachable, Wrong Number, or Deferred), remarks, enquiry number, enquiry date, enquiry model, enquiry source, enquiry mode, prospect name from the enquiry, enquiry status (Hot, Warm, Cold, Lost, Dropped, Postponed, Invoiced, Order), lost/dropped date, booking date, invoice date, and the invoiced model. All filters - zone, region, dealer, parent group, location, campaign code, and the campaign creation date range - are applied as conditional filters that default to "include all" when the user selected "ALL" for a given parameter.

*Screen: `CN_MAIN`*

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-065](#SP-065--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - Generates a CSV report file from a query result and delivers it to the user's client machine for immediate opening, choosing between a server-side CSV generation path (when a report server is configured) and a Forms record-group-based path (when no report server is configured), and prompting the user for a save location when no filename is pre-supplied.
    * **Step 1** - Look up the report server address configured for the current company and application; if no server is found, prepare to use the built-in record group method instead.
    * **Step 2** - Choose between the server-side generation path and the built-in record group path based on whether a report server address was found.
    * **Step 3** - When using the server-side path: if no output filename was supplied, prompt the user to choose a save location; otherwise use the constructed filename.
    * **Step 4** - Append ".csv" to the final filename.
    * **Step 5** - If the file path contains a folder name with a space in it, redirect the save location to the root of the C drive to avoid path issues, and inform the user.
    * **Step 6** - Send the query to the database server to generate the CSV content at the server and write the output file.
    * **Step 7** - Move the generated file from the server's interim directory to the delivery directory.
    * **Step 8** - Read the base download URL from the server configuration file.
    * **Step 9** - Combine the base URL with the filename to form the full download address.
    * **Step 10** - Transfer the file from the server to the user's computer; if the transfer fails, notify the user and pause.
    * **Step 11** - Open the downloaded CSV file on the user's computer automatically.
    * **Step 3b** - When using the built-in record group path: prompt the user for a save location if no filename was supplied; redirect to C drive root if the path contains spaces.
    * **Step 4b** - Remove any previous temporary result set with the same name from the session.
    * **Step 5b** - Create a new temporary result set from the report query and execute it.
    * **Step 6b** - Count the number of rows returned.
    * **Step 7b** - Read the base download URL from the server configuration file.
    * **Step 8b** - Open a new output file on the server for writing.
    * **Step 9b** - Write each row from the result set to the output file, one row per line.
    * **Step 10b** - Close the output file.
    * **Step 11b** - Combine the base URL with the filename, transfer the file to the user's computer, and open it automatically.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Report server lookup | VIEW_EXCEL_REPORT_NEW [SP-065] - queries EH_REPORTS for report server configuration by principal and application ID | When the user clicks Submit Report | Determines whether to use the server-side CSV generation or the built-in Forms path; selects the correct delivery mechanism for the current environment | If no server is found, the built-in record group path is used automatically (no user-visible error for this branch) |
| File transfer to user's computer | VIEW_EXCEL_REPORT_NEW [SP-065] - WebUtil_File_Transfer.Url_To_Client | After CSV is generated and ready for download | Delivers the generated report file to the user's device | If the transfer fails, a failure message is displayed and processing pauses |

**Step 3b - Summary report data set built and exported (Summary type selected)**
If the user selected the Summary report type, the system constructs a query that aggregates the pre-enquiry campaign records by region, dealer, and campaign. The output includes one row per region/dealer/campaign combination showing: region code, dealer code, outlet code, dealer name, campaign code, campaign name, total records sent, completion status (Complete or Incomplete, based on whether all follow-up outcomes have been recorded), and counts of each follow-up outcome - Interested, Call Back, Not Interested, Not Reachable, Wrong Numbers, Deferred, and Not Attempted. The same conditional filters apply as for the Detail report.

*Screen: `CN_MAIN`*

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-065](#SP-065--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - Generates a CSV report file from a query result and delivers it to the user's client machine for immediate opening, choosing between a server-side CSV generation path (when a report server is configured) and a Forms record-group-based path (when no report server is configured), and prompting the user for a save location when no filename is pre-supplied.
    * *(Step-by-step logic is identical to Step 3a above - see that bullet for the full sequence.)*

#### Business Scenarios - How the report output differs by Report Type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Detail Report** (Report Type = DETAIL) | Produces one row per pre-enquiry campaign prospect, including campaign, dealer, prospect, enquiry, booking, and invoice details. Query joins the enquiry header and detail tables via outer join. Output columns include all prospect-level and enquiry-level fields. |
| **Summary Report** (Report Type = SUMMARY) | Produces one row per region/dealer/campaign combination, aggregating follow-up outcome counts (Interested, Call Back, Not Interested, Not Reachable, Wrong Numbers, Deferred, Not Attempted) and showing overall completion status (Complete or Incomplete). No individual prospect or enquiry details. |

**Alternative Flows:**
- **BR-008-AF-01** - (from Step 5 of VIEW_EXCEL_REPORT_NEW) If the chosen file save path contains a folder name with a space, the system silently redirects the output filename to the root of the C drive (using the bare filename only) and notifies the user of the redirect before continuing.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Zone (`P_ZONE`) | Mandatory | List Item | N/A | Zone list (dynamic) | Zone code ("ALL" or specific) | Zone list populated | Must be selected before Submit | N/A (validated on field exit, BR-003) |
| Region Code (`P_REGION_DESC` / `P_REGION_CD`) | Mandatory | Text Item | N/A | Region LOV (`LV_REGION`) | Region code | Zone selected | Internal region code must be resolved | N/A (validated on field exit, BR-004) |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text Item | 500 | Dealer LOV (`LV_DEALER`) | Dealer name | Region selected | Must be selected | N/A (validated on field exit, BR-005) |
| Campaign From Date (`P_FROMDT`) | Mandatory | Text Item - Date | 10 / DD/MM/RRRR | N/A | N/A | N/A | Must be valid date, not future, not after To Date | N/A (validated on field exit, BR-006) |
| To Date (`P_TODT`) | Mandatory | Text Item - Date | 10 / DD/MM/RRRR | N/A | N/A | From Date entered | Must be valid, not future, range max 1 month | N/A (validated on field exit, BR-007) |
| Campaign Code (`P_CAMPAIGN_DESC` / `P_CAMPAIGN_CODE`) | Mandatory | Text Item | 100 | Campaign LOV (`LV_CAMPAIGN`) | Campaign code ("ALL" or specific) | Zone/Region/Dealer selected | Default "ALL"; user may select specific campaign | N/A |
| Report Type (`P_REPORT_TYPE`) | Mandatory | List Item | 100 | N/A | DETAIL ("D") / SUMMARY ("S") | Form open | Must be one of two list values | N/A |

---



#### Requirement ID: BR-009

**Requirement Title:** Cancel: Unsaved Data Warning and Form Clear

**Business Description:**
When the user clicks the Cancel button, the system checks whether any filter values have been changed since the screen last opened or was last cleared. If there are unsaved changes, the system asks the user to confirm that the entered data should be discarded before clearing the screen. If no changes are present, the screen is cleared immediately without prompting. This prevents accidental loss of a filter combination the user may have spent time building.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The Cancel button is enabled.

**Main Flow:**

**Step 1 - Check for unsaved changes and confirm before clearing**
When the user clicks Cancel, the system first checks whether the Cancel button is enabled (it is part of the standard toolbar that is always enabled on this form). If the form has been changed since it was last opened or cleared, the system asks the user to confirm the discard using the message *"Entered data will not be Saved"*. If the user confirms (presses the first button), the screen is cleared. If the user declines (presses any other button), the form remains as it is with all current filter values intact. If the form has not been changed, the screen is cleared immediately without prompting.

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-006](#SP-006--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation alert to the user and returns a numeric flag indicating which button was pressed, allowing callers such as the Cancel and Delete triggers to determine whether the user consented to the requested action before proceeding.
    * **Step 1** - Set the text of the confirmation alert to the caller-supplied message *"Entered data will not be Saved"*.
    * **Step 2** - Display the alert and wait for the user to press a button.
    * **Step 3** - If the user pressed the first (confirm) button, return 1 to signal confirmation.
    * **Step 4** - If the user pressed any other button, return 0 to signal rejection.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| User confirms discard of unsaved changes | FT_CANCEL - checks system form status is 'CHANGED', then calls GENERAL.ASK_CONFIRM [SP-006] | When the user clicks Cancel and the form has unsaved changes | Prevents accidental loss of a filter selection the user has built | If the user declines (returns 0), the form is not cleared and the user's current selections are preserved |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-WS-01** - Form has unsaved changes - *"Entered data will not be Saved"* confirmation shown; user must confirm to proceed with clearing.
- **BR-009-SM-01** - Cancel confirmed or no changes present - the form is cleared and all filter fields are reset.

---



#### Requirement ID: BR-010

**Requirement Title:** Form Exit and Database Session Deregistration

**Business Description:**
When the user exits the Pre-Enquiry report form - either by pressing the keyboard exit shortcut or by clicking the Exit button - the system clears the module and client identification that was recorded in the database session when the form opened, then closes the form without saving any data. This ensures that the database session monitor no longer shows the report module as active once the user has left.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.

**Main Flow:**

**Step 1 - Database session deregistered on exit**
When the user triggers the exit action (keyboard shortcut or Exit button), the system clears both the client information and the module/action labels that were written to the database session when the form opened. After clearing, the system closes the form without validating or saving any data.

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-SM-01** - Form closed - the database session labels are cleared and the form exits without saving any data.

**Alternative Flows:**
- **BR-010-AF-01** - (from Step 1 - Exit button, PB_BLK.PB_EXIT) The Exit button's WHEN-BUTTON-PRESSED trigger unconditionally delegates to the standard Forms exit key action (`do_key('exit_form')`), which in turn fires the KEY-EXIT trigger above. Note: a previously used block of code in the Exit button (commented out in the current source) that checked for unsaved changes and prompted the user before exiting is no longer active (COMMENTED OUT / INACTIVE - does not execute).

---



#### Requirement ID: BR-011

**Requirement Title:** Application-Level Error Interception and User-Friendly Error Display

**Business Description:**
Whenever an error condition arises in the form - whether from the user entering data in the wrong format, a database integrity constraint being violated, a data entry conflict with another user, or a general database error - the system intercepts the error before it reaches the user as a raw technical message. The system translates the error into a plain, business-appropriate message and displays it as a labelled alert, then stops processing so the user can correct the issue. This protects users from cryptic Oracle Forms error codes and database technical messages.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open and an error condition has arisen during form operation.

**Main Flow:**

**Step 1 - Invalid date format error intercepted**
If the user enters a date value that the system cannot recognise as a valid date, the system intercepts error code 50004 and shows the message *"Entered Date is not valid Date"* instead of the raw error, then stops further processing on that action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date format guard - error code 50004 | ON-ERROR in Form - checks ERROR_CODE = 50004 | When a form operation produces an error during form use | Replaces a cryptic Oracle error with a plain date-format message | *"Entered Date is not valid Date"* shown as an error alert; trigger failure raised |

**Step 2 - Date format mask error intercepted**
If the user enters a date in a format that does not match the required pattern, the system intercepts error codes 50025 or 50026 and shows the message *"Enter the Date in the proper format (DD-MM-YYYY)"*, then stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date mask guard - error codes 50025/50026 | ON-ERROR in Form - checks ERROR_CODE in (50025, 50026) | When a form operation produces an error during form use | Guides the user to enter dates in the application's required format | *"Enter the Date in the proper format (DD-MM-YYYY)"* shown; trigger failure raised |

**Step 3 - Non-numeric value in numeric field intercepted**
If the user enters a character or special character where a numeric value is required, the system intercepts error codes 40209 or 50016 and shows the message *"Characters/Special Characters are not allowed here, enter the numeric value"*, then stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric field character guard - error codes 40209/50016 | ON-ERROR in Form - checks ERROR_CODE in (40209, 50016) | When a form operation produces an error during form use | Prevents non-numeric input in fields that require numbers | *"Characters/Special Characters are not allowed here, enter the numeric value"* shown; trigger failure raised |

**Step 4 - Item-level validation error intercepted**
If a standard Forms item validation error (error code 40207) occurs, the system intercepts it and shows the underlying error text (the text of error 40207 as provided by the form engine), then stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Item validation guard - error code 40207 | ON-ERROR in Form - checks ERROR_CODE = 40207, displays ERROR_TEXT | When a form validation error occurs | Surfaces the form engine's own validation message to the user in a consistent format | The text of the error is shown; trigger failure raised |

**Step 5 - Foreign key constraint violation intercepted**
If a delete or update operation violates a foreign key constraint (database error code -2292), the system calls the standard error handler for error code 'E0088', which raises the appropriate user-visible error message.

*Procedures called:*
- **GENERAL.RAISE_ERROR** ([SP-009](#SP-009--GENERAL.RAISE_ERROR)) - GENERAL.RAISE_ERROR - Receives a message code from the ON-ERROR trigger, constructs a display string from the code and any associated message text, and routes the notification to the appropriate alert style (error, note, or caution) - halting form processing with `FORM_TRIGGER_FAILURE` when the severity is `Error`.
    * **Step 1** - Build the display text from the error code and any associated message text (note: the message retrieval call is commented out in the current implementation, so the message portion is effectively blank at runtime and the display string shows the error code followed by a separator only).
    * **Step 2** - Determine the severity of the message from its type code.
    * **Step 3** - If the type is Error, display the message with an "Error" title and raise a trigger failure to halt processing.
    * **Step 4** - If the type is Note, display the message with a "Note" title without halting.
    * **Step 5** - If the type is Caution, display the message with a "Caution" title without halting.
    * **Step 6** - If the type is none of the above, exit without displaying anything.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Foreign key constraint guard - DB error -2292 | ON-ERROR in Form - checks DBMS_ERROR_CODE = -2292, calls GENERAL.RAISE_ERROR('E0088') [SP-009] | When a form operation triggers a database foreign key violation | Prevents the user from deleting a record that is referenced by other data in the system | Error message for code 'E0088' displayed; trigger failure raised |

**Step 6 - Concurrent update conflict intercepted**
If the current record has been modified by another user since it was last loaded (error codes 40654-40659), the system shows the message *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any uncommitted changes, and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Concurrent update guard - error codes 40654-40659 | ON-ERROR in Form - checks ERROR_CODE in (40654, 40655, 40656, 40657, 40659) | When a form operation produces a record-locking error | Prevents a user from overwriting another user's changes to the same record | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"* shown; database rolled back; trigger failure raised |

**Step 7 - General database error intercepted**
If a non-zero Oracle SQL error code is present (other than the specific codes handled above), the system shows the database's own error description (the value returned by `SQLERRM` - the Oracle database system error message text), rolls back any uncommitted changes, and stops further processing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| General SQL error guard | ON-ERROR in Form - checks SQLCODE is not zero, displays SQLERRM | When any unhandled database error occurs | Surfaces the database's own error message to the user in a consistent format, and rolls back uncommitted work | The Oracle database error message text (SQLERRM) shown; database rolled back; trigger failure raised |

**Step 8 - Harmless navigation errors silently suppressed**
Error codes 40401 and 40405 (no data found and no rows remaining for navigation) are silently accepted and produce no user-visible message. Processing continues normally.

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Invalid date entered - *"Entered Date is not valid Date"*.
- **BR-011-ES-02** - Date in wrong format - *"Enter the Date in the proper format (DD-MM-YYYY)"*.
- **BR-011-ES-03** - Non-numeric input in numeric field - *"Characters/Special Characters are not allowed here, enter the numeric value"*.
- **BR-011-ES-04** - Item validation error - the form engine's own error text for error 40207 is shown.
- **BR-011-ES-05** - Foreign key constraint violation - error code 'E0088' message displayed.
- **BR-011-ES-06** - Concurrent update conflict - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; database rolled back.
- **BR-011-ES-07** - General database error - the Oracle database system error message (SQLERRM text) is shown; database rolled back.

---



#### Requirement ID: BR-012

**Requirement Title:** Application-Level Message Interception for Forms Notification Errors

**Business Description:**
When the Forms engine generates an informational or notification message with specific error codes that would otherwise be displayed in the status bar or as a raw Forms notice, the system intercepts those messages and re-displays them as a labelled, visible error alert so that the user sees them clearly rather than missing a status-bar-only notification. This applies specifically to the Forms error codes 40209 and 40207, which relate to item validation and navigation feedback.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open and a Forms notification message with code 40209 or 40207 has been generated.

**Main Flow:**

**Step 1 - Specific Forms notification messages elevated to visible alerts**
When the Forms engine generates message code 40209 or 40207, the system intercepts the notification, constructs a formatted message combining the error type prefix, the error code number, and the error text, displays it as a visible error alert via the standard display text function, and then raises a trigger failure to prevent any further processing of the action that caused the notification.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user via a modal alert dialog, routing the alert to either an error-style (`AL_ERRINFO`) or a note-style (`AL_NOTE`) alert based on the supplied title, so that error notifications and informational messages are visually distinguished.
    * **Step 1** - Examine the severity title provided to select the correct alert type (Error or Note).
    * **Step 2** - If the title indicates an error, select the error alert; otherwise select the note alert.
    * **Step 3** - Set the alert's title to the supplied severity label.
    * **Step 4** - Set the alert's message body to the supplied text.
    * **Step 5** - Display the alert and wait for the user to acknowledge it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Forms notification escalation - error codes 40209/40207 | ON-MESSAGE in Form - checks ERROR_CODE in (40209, 40207), calls GENERAL.DISP_TEXT [SP-007] with formatted message | When the Forms engine generates message code 40209 or 40207 | Ensures these specific notification codes are shown as clearly visible error dialogs rather than being silently swallowed by the notification handler | Message text (type prefix + code + error text) shown as error alert; trigger failure raised |

*Business outcomes (errors, warnings, success, and status):*
- **BR-012-ES-01** - Forms notification code 40209 or 40207 generated - message formatted as "error type - error code: error text" and displayed as a visible error alert; processing halted.

---



#### Requirement ID: BR-013

**Requirement Title:** Lookup List Display and Auto-Advance on Successful Selection

**Business Description:**
When the user triggers the list-of-values action on a filter field that has an associated lookup list, the system first checks whether the field under the cursor actually has a lookup list attached to it. If it does, the system opens the list at a fixed position on the screen. If the user selects a value from the list, the system automatically advances the cursor to the next field, streamlining data entry. If the field has no lookup list, nothing happens.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The cursor is positioned on a filter field.

**Main Flow:**

**Step 1 - Lookup list checked and opened on current field**
When the user presses the list-of-values key, the system reads the name of the lookup list associated with the field currently under the cursor. If a lookup list name is found, the system opens that list for the user to pick a value from. The list is displayed at screen position 200, 120 (coordinates in the form window).

**Step 2 - Cursor advanced if a value was selected**
If the user selected a value from the list (the list operation returned success), the system automatically moves the cursor to the next field in the tab order. If the user closed the list without making a selection, the cursor stays on the current field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Lookup list availability check | KEY-LISTVAL in Form - checks that the current item has a LOV_NAME property that is not null before opening the list | When the user presses the list-of-values key | Prevents the LOV open action from failing on fields that have no lookup list defined | If no LOV is attached to the current field, no list opens and no error is shown; the action is silently ignored |

---



#### Requirement ID: BR-014

**Requirement Title:** Form Clear and Copyright Refresh

**Business Description:**
When the user triggers the clear-form action (via keyboard shortcut), the system clears all filter fields on the screen without saving any data, resetting the form to a blank state. After clearing, the system refreshes the copyright notice at the bottom of the screen so the current financial year continues to be shown correctly on the freshly cleared form.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.

**Main Flow:**

**Step 1 - All filter fields cleared without saving**
The system clears all entries from the filter parameter fields without validating or saving any data, returning the form to a blank starting state.

**Step 2 - Copyright notice refreshed**
After clearing the form, the system re-reads and refreshes the copyright notice field so the correct financial year is displayed on the now-blank screen.

*Screen: `CN_MAIN`*

*Procedures called:*
- **SF_COPYRIGHT_DECLARATION** ([SP-063](#SP-063--SF_COPYRIGHT_DECLARATION)) - SF_COPYRIGHT_DECLARATION - Generates the copyright notice string for Maruti Suzuki India Limited, adjusted to reflect the current Indian financial year, so that the displayed copyright year correctly spans April-March boundaries rather than the calendar year.
    * **Step 1** - Capture today's date to determine which financial year is in progress.
    * **Step 2** - Check whether today's month falls in January, February, or March.
    * **Step 3** - If January, February, or March: use the previous calendar year as the financial year start.
    * **Step 4** - If April through December: use the current calendar year as the financial year start.
    * **Step 5** - Return the formatted copyright string.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Copyright Notice (`COPY_RIGHT`) | Auto-populated | Display Item | 100 / N/A | N/A | Financial year copyright string | Form cleared | Read-only; refreshed after each clear | N/A |

---



#### Requirement ID: BR-015

**Requirement Title:** Insert Operation Blocked on Report Parameter Form

**Business Description:**
If the Insert button is enabled in the toolbar and the user attempts to insert a new record, the system displays an informational error telling the user that inserting records is not a supported operation on this screen. This form is a reporting parameter screen and does not support record creation.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The Insert toolbar button is enabled.

**Main Flow:**

**Step 1 - Insert attempt shown as unsupported operation**
If the Insert button is enabled when the user clicks it, the system displays the message *"This Operation Cannot be performed Here"* as an error alert, informing the user that data insertion is not available on this screen. If the Insert button is not enabled, the action is silently ignored.

*Procedures called:*
- **GENERAL.DISP_TEXT** ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - GENERAL.DISP_TEXT - Displays a message to the user via a modal alert dialog, routing the alert to either an error-style (`AL_ERRINFO`) or a note-style (`AL_NOTE`) alert based on the supplied title, so that error notifications and informational messages are visually distinguished.
    * **Step 1** - Examine the severity title ("Error") to select the error alert type.
    * **Step 2** - Select the error alert.
    * **Step 3** - Set the alert title to "Error".
    * **Step 4** - Set the alert message to *"This Operation Cannot be performed Here"*.
    * **Step 5** - Display the alert and wait for acknowledgement.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert not permitted on this form | FT_INSERT in Form - checks PB_INSERT button is enabled, calls GENERAL.DISP_TEXT [SP-007] | When the user clicks the Insert toolbar button and it is enabled | Prevents users from attempting to create records on a read-only parameter form | *"This Operation Cannot be performed Here"* shown as an error alert |

*Business outcomes (errors, warnings, success, and status):*
- **BR-015-ES-01** - Insert attempted - *"This Operation Cannot be performed Here"*; no record is created.

---



#### Requirement ID: BR-016

**Requirement Title:** Delete Record Confirmation (Inherited Template Logic - Not Triggered in Current Form Context)

**Business Description:**
The form contains a delete confirmation routine inherited from the standard DMS form template. When the Delete button is enabled and the cursor is positioned on a specific data block, the system asks the user to confirm before deleting the current record. However, in the current deployment of this Pre-Enquiry report form, the condition required to trigger this logic - the cursor being in a data block named in the template - is never satisfied, because that block does not exist in this form. As a result, the delete routine always executes the else branch silently and no delete action ever occurs. This requirement documents the logic as inherited and non-executing in this context.

**Actors:** Reporting User

**Preconditions:**
- The Delete toolbar button is enabled.

**Main Flow:**

**Step 1 - Delete route checked and confirmation requested (template logic - not triggered in this form)**
The system checks whether the Delete button is enabled and whether the cursor is positioned on a specific data block (a block that is not present in this form). Because that block does not exist here, the condition is always false, and the system takes no action. The inherited code path - which would have disabled form validation, asked the user to confirm deletion with the message *"Are you sure to Delete?"*, and on confirmation deleted the current record - does not execute in this form.

(COMMENTED OUT / INACTIVE logic note: the form-status check inside the delete block is commented out; only the confirmation dialog and delete would run if the condition were met.)

*Procedures called:*
- **GENERAL.ASK_CONFIRM** ([SP-006](#SP-006--GENERAL.ASK_CONFIRM)) - GENERAL.ASK_CONFIRM - Presents a configurable confirmation alert to the user and returns a numeric flag indicating which button was pressed, allowing callers such as the Cancel and Delete triggers to determine whether the user consented to the requested action before proceeding.
    * **Step 1** - Set the confirmation alert text to *"Are you sure to Delete?"*.
    * **Step 2** - Display the alert and wait for the user's response.
    * **Step 3** - Return 1 if the user confirms; return 0 if the user declines.
    * **Step 4** - (not reached in this form) If confirmed, delete the current record.

---



#### Requirement ID: BR-017

**Requirement Title:** Save Action: Commit and Form Clear

**Business Description:**
When the user clicks the Save toolbar button, the system commits any pending changes to the database and then immediately clears the form. Because this is a reporting parameter form with no database items, the commit has no practical data-persistence effect; the save action effectively functions as a "commit and reset" to return the form to a clean state. An earlier version of this logic that would have validated form fields and listed validation errors in a separate panel before committing is no longer active.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.

**Main Flow:**

**Step 1 - Form committed and then cleared**
When the user clicks Save, the system issues a commit to the database (no database-backed items are present in this form, so no data is actually saved) and then clears the form, resetting all filter fields to their empty state.

Note: the error-collection logic that would have gathered validation errors into a list and navigated to an error display block before committing is commented out (COMMENTED OUT / INACTIVE - does not execute).

---



#### Requirement ID: BR-018

**Requirement Title:** List Values Toolbar Action Delegation

**Business Description:**
When the user clicks the List Values toolbar button (if it is enabled), the system triggers the standard list-of-values action for the field currently under the cursor, producing the same result as the keyboard list shortcut described in BR-013. If the button is not enabled, the action is silently ignored.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.
- The cursor is positioned on a filter field.

**Main Flow:**

**Step 1 - List Values action delegated to the standard lookup shortcut**
If the List Values toolbar button is enabled, the system triggers the standard list-of-values key action. This activates the same lookup behaviour described in BR-013: the system finds the lookup list for the current field and opens it, then advances the cursor on successful selection. If the button is not enabled, the action is silently ignored.

---

#### Requirement ID: BR-019

**Requirement Title:** Print Toolbar Action (Template Placeholder - Does Not Execute)

**Business Description:**
The form contains a Print toolbar button inherited from the standard DMS form template. The Print button's logic contains a placeholder comment indicating where print code should be inserted but contains no active print implementation. If the Print button is enabled, clicking it results in no action being taken. This requirement documents the button's presence as a non-executing template placeholder.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.

**Main Flow:**

**Step 1 - Print action checked but no print logic executed**
If the Print toolbar button is enabled, the system enters the print block but finds only a comment placeholder (*"INSERT YOUR PRINT CODE HERE"*) and no active code. No print action is performed. If the button is not enabled, the action is silently ignored. (COMMENTED OUT / INACTIVE - does not execute: the placeholder `NULL;` inside the enabled branch means the action is a no-op in both cases.)

---

#### Requirement ID: BR-020

**Requirement Title:** Excel Report ASCII Character Sanitisation (Form Program Unit - Called from DMS Excel Report Library)

**Business Description:**
The form contains a program unit that reads an already-generated report file, removes any non-printable control characters (specifically lines beginning with the form-feed character, ASCII 12) from the file content, writes the sanitised content to a new output file, and then presents the cleaned file to the user via the web browser. This utility is defined as a form-local procedure and supports the report delivery step by cleaning up output files that may contain printer control characters inserted by the report generation process. An exception handler displays a note containing the SQL error code and message text if any error occurs during file processing.

**Actors:** Reporting User (indirectly - triggered by the report generation flow)

**Preconditions:**
- A report output file has been generated in the server reports printer directory.
- The file path and cleaned output filename have been provided by the calling process.

**Main Flow:**

**Step 1 - Input file opened for reading**
The system opens the source report file from the server reports directory (`/iashome/ias/reports/printer/` + the supplied input filename) for line-by-line reading.

**Step 2 - Output file opened for writing**
The system opens a new output file in the same server directory using the supplied output filename.

**Step 3 - File contents copied with form-feed lines filtered**
The system reads the input file line by line. For each line, if the first character is the form-feed character (ASCII 12), the line is skipped. All other lines are written to the output file unchanged.

**Step 4 - Files closed and cleaned file presented to the user**
After processing all lines, both files are closed. The system constructs the web URL path to the cleaned output file (`/printer/` + output filename) and opens it in a new browser window so the user can view or download the file.

*Business outcomes (errors, warnings, success, and status):*
- **BR-020-ES-01** - File processing exception - if any error occurs during file reading, writing, or closing (including a no-more-data condition that marks the end of the file), the system displays a note message containing the SQL error code and error text (the system's own error code number and message description); processing stops at that point.

---



#### Requirement ID: BR-021

**Requirement Title:** List Item Population from Application Code Master (Form-Local Helper - Not Invoked in Current Active Triggers)

**Business Description:**
The form contains a local helper procedure that can populate a named drop-down list field on screen by querying the application code master table for a given list name and filtering to the current company/principal. The procedure removes any previously loaded entries from the list before reloading it, ensuring the list always reflects the current master data. This procedure is defined in the form but is not called from any active trigger in the current deployment; it is available as a reusable helper for future use or inherited from a template.

**Actors:** Reporting User (potential - not currently triggered)

**Preconditions:**
- (Not currently invoked - documented for completeness as an active but uncalled form-local program unit.)

**Main Flow:**

**Step 1 - Existing list data removed and replaced from application code master**
When invoked, the procedure first checks whether a record group with the standard list name already exists in the current session. If it does, it deletes the old group to avoid stale data. The procedure then creates a new record group by querying the application code master table for the specified list name and the current company identifier, executes the query to retrieve the current code descriptions and codes, and loads the results into the specified drop-down list field on screen.

Note: an alternative commented-out query that would have loaded from a different source table is inactive (COMMENTED OUT / INACTIVE - does not execute).

---



#### Requirement ID: BR-022

**Requirement Title:** Continue Button Navigation (Template Placeholder - Target Block Not Present in This Form)

**Business Description:**
The form contains a Continue button (PM_CONT) inherited from the standard DMS form template. When clicked, the button navigates to the error display block and clears it, then attempts to navigate to a data entry block. In this Pre-Enquiry report form, the target data entry block referenced by the navigation does not exist, so this button's navigation to the main data block always targets a non-existent block and has no practical effect in this deployment. The button and its logic are retained from the form template.

**Actors:** Reporting User

**Preconditions:**
- The Pre-Enquiry report screen is open.

**Main Flow:**

**Step 1 - Error block cleared and navigation attempted (template logic)**
When clicked, the button navigates to the error display block and clears it without validating any data. It then attempts to navigate to a data block that does not exist in this form. Because the target block is absent, this sequence has no meaningful user-facing effect in the current form.

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the RR_PRE_ENQ form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Zone Must Be Selected | Validation | BR-003 | The Zone filter field is left blank when the user moves to the next field | Show *"Zone Code can not be empty"* and prevent navigation to the next field | Ensures every report is scoped to a geographic zone; prevents an unbounded zone selection from being submitted (see WF-001) |
| BRC-002 | Zone Change Resets Dependent Filters | Derivation | BR-003 | The user changes the Zone selection in the drop-down | Clear the Region, Dealer, Location, internal region code, internal dealer code, internal parent group code, and internal location code fields | Prevents stale region or dealer filter values that belonged to the old zone from being carried forward and producing incorrect report output |
| BRC-003 | Region Code Must Be Resolved | Validation | BR-004 | The user moves away from the Region field and the internal region code is blank | Show *"Region Code can not be empty"* and prevent navigation | Ensures a genuine, database-recognised region has been selected so that the region filter is valid |
| BRC-004 | Region Change Resets Dealer and Location | Derivation | BR-004 | The user selects a new Region and the validation passes | Clear the Dealer description, Location description, internal dealer code, internal parent group code, and internal location code | Prevents dealer or location values belonging to the old region from persisting as an inconsistent filter |
| BRC-005 | Dealer Must Be Selected | Validation | BR-005 | The user moves away from the Dealer field and the field is blank | Show *"Dealer can not be empty"* and prevent navigation | Ensures the report is scoped to a specific dealer outlet or an "All Dealers" choice; an empty dealer would produce an unscoped result |
| BRC-006 | Campaign From Date Must Be Entered | Validation | BR-006 | The user moves away from the Campaign From Date field and it is blank | Show *"From Date can not be empty"* and prevent navigation | A date range start is required to define the report's data window |
| BRC-007 | Campaign From Date Must Not Be in the Future | Validation | BR-006 | The Campaign From Date is later than today's date | Show alert message *"From Date cannot be greater than Current Date"* and prevent navigation | Campaign records can only exist up to today; a future start date would yield an empty or meaningless report |
| BRC-008 | Campaign From Date Must Not Exceed To Date | Validation | BR-006 | The Campaign From Date is later than the current To Date | Show alert message *"From Date cannot be greater than To Date"* and prevent navigation | The reporting period must have a valid, non-negative duration |
| BRC-009 | To Date Auto-Recalculated on From Date Entry | Derivation | BR-006 | The Campaign From Date passes all validations | Recalculate the To Date to the last day of the From Date's month; if that day is in the future, set it to today's date instead | Keeps the date range within a single calendar month and prevents a future To Date from being automatically set |
| BRC-010 | To Date Must Be Entered | Validation | BR-007 | The user moves away from the To Date field and it is blank | Show *"To Date can not be empty"* and prevent navigation | The end of the reporting period is required to bound the report query |
| BRC-011 | To Date Requires From Date | Validation | BR-007 | The user enters a To Date but the Campaign From Date is blank | Show *"To date cannot be entered without entering From date"*, clear the To Date field, and prevent navigation | The To Date has no meaning without a From Date; the sequence must be respected |
| BRC-012 | To Date Must Not Precede From Date | Validation | BR-007 | The To Date is earlier than the Campaign From Date | Show alert message *"To Date cannot be lesser than From Date"* and prevent navigation | The reporting period must run in the correct chronological direction |
| BRC-013 | To Date Must Not Be in the Future | Validation | BR-007 | The To Date is later than today's date | Show alert message *"To Date cannot be greater than Current Date"* and prevent navigation | Prevents the report from being run against future dates where data does not yet exist |
| BRC-014 | Date Range Must Not Exceed One Month | Constraint | BR-007 | The To Date is more than one calendar month after the Campaign From Date | Show alert message *"Please give the date range of maximum One month"* and prevent navigation | Report queries are optimised for single-month data volumes; a wider range risks performance issues or excessively large output files (see WF-001) |
| BRC-015 | Insert Operation Not Supported | Constraint | BR-015 | The Insert toolbar button is enabled and the user clicks it | Show *"This Operation Cannot be performed Here"* and take no further action | This is a read-only reporting parameter form; record creation is not permitted |
| BRC-016 | Cancel with Unsaved Changes Requires Confirmation | Validation | BR-009 | The Cancel button is clicked and the form has unsaved changes | Show the confirmation message *"Entered data will not be Saved"*; if the user confirms, clear the form; if the user declines, leave the form unchanged | Prevents accidental loss of a filter combination the user has spent time entering |
| BRC-017 | Invalid Date Entry Replaced by User-Friendly Message | Validation | BR-011 | The form engine raises error code 50004 (invalid date) | Display *"Entered Date is not valid Date"* and halt the current action | Replaces a cryptic Oracle error code with a plain business message |
| BRC-018 | Wrong Date Format Replaced by Format Guidance | Validation | BR-011 | The form engine raises error code 50025 or 50026 (date format mismatch) | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and halt | Guides the user to the required date entry format without exposing a raw error code |
| BRC-019 | Non-Numeric Input in Numeric Field Rejected | Validation | BR-011 | The form engine raises error code 40209 or 50016 (character in numeric field) | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and halt | Prevents non-numeric data from being entered in fields that require numbers |
| BRC-020 | Concurrent Update Conflict Detected | Validation | BR-011 | The form engine raises error codes 40654-40659 (record modified by another user) | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back uncommitted changes, and halt | Prevents a user from overwriting another user's changes to the same record |
| BRC-021 | Delete Requires Confirmation | Validation | BR-016 | The Delete button is enabled and the cursor is on the correct data block (template logic - not met in this form) | Show *"Are you sure to Delete?"*; if confirmed, delete the current record; if declined, take no action | Prevents accidental deletion of records by requiring explicit user confirmation |
| BRC-022 | Zone List Filtered to User's Authorised Zones | Authorization | BR-002 | The form opens and the Zone list is populated | Populate the Zone drop-down only with zones the logged-in user is authorised to access, filtered by user ID and principal map code; prepend an "ALL" option | Ensures users can only report on geographic zones they are permitted to access, enforcing data access control (see WF-001) |
| BRC-023 | Region List Filtered by Selected Zone | Derivation | BR-013 | The user opens the Region lookup after selecting a Zone | Show only regions that belong to the selected zone and the current principal; prepend "ALL REGION" | Prevents the user from selecting a region that does not belong to the currently chosen zone |
| BRC-024 | Dealer List Filtered by Selected Zone and Region | Derivation | BR-013 | The user opens the Dealer lookup after selecting a Zone and Region | Show only active dealer outlets (type S or 3S, not terminated) in the selected zone and region for the current principal; prepend "ALL Dealers" | Prevents the user from selecting a dealer outside their chosen geographic scope |
| BRC-025 | Campaign List Filtered by Current Filter Selections | Derivation | BR-013 | The user opens the Campaign lookup | Show only campaigns available within the currently selected zone, region, dealer, parent group, and location; prepend "ALL" | Ensures the campaign filter list is contextually relevant to the other filter choices already made |

**Total Business Rules Identified: 25**

---

## 6. Data Requirements

*This section describes the data entities, capture requirements, reference data, and lifecycle behaviour of the RR_PRE_ENQ Pre-Enquiry Detail/Summary Report form, which collects filter parameters from users and uses them to generate a CSV report from pre-enquiry campaign and enquiry data.*

### 6.1 Business Entities and Relationships

*The form does not persist data to its own database tables; it operates as a reporting parameter form whose filter selections drive read-only queries against the pre-enquiry campaign, dealer location, regional master, and enquiry master data maintained by the DMS application.*

#### Pre-Enquiry Campaign - MULDMS.PRE_ENQ_CAMPAIGN

This entity stores pre-enquiry campaign records, each linking a prospect to a campaign, a dealer outlet, and a follow-up outcome (Interested, Call Back, Not Interested, Not Reachable, Wrong Number, Deferred). The report form queries this entity - filtered by zone, region, dealer, campaign, and date range - to produce both the Detail and Summary output sets.

#### Dealer Location - MULDMS.AM_DEALER_LOC

This entity contains the dealer outlet master, providing the dealer name, city, region, and outlet codes. The form queries it alongside the campaign data to resolve dealer names, region and zone details, and outlet identifiers used in report output.

#### Regional Master - MULDMS.GM_REGN

This entity maps region codes to zone codes, enabling the form's Zone and Region filters to constrain the report to the user's authorised geographic scope.

#### Enquiry Header - MULDMS.RH_ENQ

This entity holds the enquiry header record linked (outer join) from the pre-enquiry campaign entry, providing enquiry number, date, prospect name, and sales-related status for the Detail report.

#### Enquiry Detail - MULDMS.RD_ENQ

This entity holds the vehicle-level enquiry detail lines, used in the Detail report to resolve model description and the current enquiry status code (Hot, Warm, Cold, Lost, Dropped, Invoiced, Order).

#### Entity Relationships

The form's queries join the pre-enquiry campaign table to the dealer location master on dealer and location keys, and to the regional master on region and principal keys. The enquiry header is linked to the campaign record via an outer join on parent group, dealer, location, and enquiry number. The enquiry detail lines extend the enquiry header. No master-detail form relationship is declared; all joins are embedded in the report query.

```
MULDMS.PRE_ENQ_CAMPAIGN
        ├── MULDMS.AM_DEALER_LOC         <- joined on dealer_map_cd, loc_cd, principal_map_cd
        │         └── MULDMS.GM_REGN     <- joined on region_cd, principal_map_cd
        └── MULDMS.RH_ENQ (outer join)   <- joined on parent_group, dealer_map_cd, loc_cd, comp_fa, enq_num
                  └── MULDMS.RD_ENQ      <- joined on parent_group, dealer_map_cd, loc_cd, comp_fa, enq_num
```

### 6.2 Data Capture Requirements

*The form captures reporting filter parameters entered by the user; all fields are mandatory before the report can be submitted. No data is inserted or updated by this form - the captured values are used exclusively as query parameters.*

#### Report Filter Parameters (Reporting User - before submitting the report)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Zone (`P_ZONE`) | Yes | The geographic zone used to filter report output. Populated from a list of zones the user is authorised to access. "ALL" selects all zones the user may view. | Must not be left blank; system shows *"Zone Code can not be empty"* and blocks navigation if no zone is selected. |
| Region Code (`P_REGION_DESC` / `P_REGION_CD`) | Yes | The sales region within the selected zone used to narrow report output. Displayed as the region description; the internal region code is stored separately. "ALL REGION" selects all regions within the zone. | Internal region code must not be null when the user tabs off the Region field; system shows *"Region Code can not be empty"* and blocks navigation. Changing the zone resets this field to blank. |
| Dealer (`P_DEALER_DESC` / `P_DEALER` / `P_PARENT`) | Yes | The dealer outlet used to filter report output. Displayed as the dealer name; internal dealer map code and parent group are stored separately. "ALL Dealers" selects all dealers in the selected region. | Dealer description must not be blank; system shows *"Dealer can not be empty"* and blocks navigation. Changing the region resets this field and the location field to blank. |
| Location (`LOC_DESC` / `P_LOC`) | No | The specific dealer outlet location to further filter report output. Displayed as the location description; the internal location code is stored separately. The field is read-only (Enabled = false in form XML) and is populated by the Dealer LOV selection. | Not directly validated by the form; value is determined by the Dealer LOV choice. Changing the zone clears this field. |
| Campaign From Date (`P_FROMDT`) | Yes | The start of the date range for filtering campaign records. Automatically defaulted to the first day of the current month on form open. Format: DD/MM/YYYY. | Must not be blank (*"From Date can not be empty"*). Must not be a future date (*"From Date cannot be greater than Current Date"*). Must not be later than the To Date (*"From Date cannot be greater than To Date"*). After validation, the To Date is automatically recalculated as the last day of the month containing the From Date (or today, whichever is earlier). |
| To Date (`P_TODT`) | Yes | The end of the date range for filtering campaign records. Automatically defaulted to today's date on form open. Format: DD/MM/YYYY. | Must not be blank (*"To Date can not be empty"*). Cannot be entered without a From Date (*"To date cannot be entered without entering From date"*). Must not be less than the From Date (*"To Date cannot be lesser than From Date"*). Must not be a future date (*"To Date cannot be greater than Current Date"*). The date range must not exceed one calendar month (*"Please give the date range of maximum One month"*). |
| Campaign Code (`P_CAMPAIGN_DESC` / `P_CAMPAIGN_CODE`) | Yes | The pre-enquiry campaign to include in the report. Displayed as the campaign name; the internal campaign code is stored separately. Defaults to "All Campaign Code" / "ALL" to include all campaigns matching the other filters. | Initial value set to "All Campaign Code" (displayed) / "ALL" (code) in form XML. User may select a specific campaign from the Campaign LOV. |
| Report Type (`P_REPORT_TYPE`) | Yes | Determines whether the report is generated in Detail or Summary format. A fixed list: DETAIL (code "D") or SUMMARY (code "S"). Defaults to DETAIL. | Initial value is "D" (Detail) as set in form XML. Must be one of the two list values; the field validates from the list. |
| Destination (`P_DESTYPE`) | Read-only display | The output destination for the report (Screen, Printer, or Excel). Defaults to "EXCEL". The field is disabled (Enabled = false in form XML) and is not changeable by the user in the current implementation. | Field is disabled; value is fixed at "EXCEL". Not editable. |

#### Session / Application Parameters

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application ID (`P_APP_ID` / `GLOBAL.APP_ID`) | Auto-populated | The application identifier assigned to the current session, passed to the report generation function to locate the report server configuration. Populated automatically from the session global at form initialisation. | System-set; not user-editable. |
| User ID (`GLOBAL.USERID`) | Auto-populated | The logged-in user's identifier, used to construct the output filename (user ID prefix + timestamp suffix + `.csv`). Populated from the session global. | System-set; not user-editable. |
| Principal Map Code (`GLOBAL.PRINCIPAL`) | Auto-populated | The company/principal identifier for the current session, used in all report queries to restrict data to the correct company. Populated from the session global. | System-set; not user-editable. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Zone List (dynamic list - `L_ITEM` record group, sourced from `MULDMS.AM_USER_REGION` / `MULDMS.AM_ZONE`) | Provides the list of zones the logged-in user is authorised to access, filtered by principal map code. "ALL" option is prepended. | Populated into the Zone drop-down list when the form opens. |
| Region Master (`LV_REGION` / `RG_REGION` - sourced from `GM_REGN`) | Provides valid regions within the selected zone, filtered by principal map code. "ALL REGION" option is prepended. | Available when the user opens the Region LOV after selecting a Zone. |
| Dealer Outlet Master (`LV_DEALER` / `RG_DEALER` - sourced from `MULDMS.AM_DEALER_LOC`, `MULDMS.GM_REGN`) | Provides active dealer outlets (type 'S' or '3S', not terminated) within the selected zone and region, filtered by principal map code. "ALL Dealers" option is prepended. | Available when the user opens the Dealer LOV after selecting a Zone and Region. |
| Campaign Master (`LV_CAMPAIGN` / `RG_CAMPAIGN` - sourced from `MULDMS.PRE_ENQ_CAMPAIGN`, `MULDMS.AM_DEALER_LOC`, `MULDMS.GM_REGN`) | Provides the list of distinct pre-enquiry campaigns available within the current zone, region, dealer, and location filter selections, filtered by principal map code. "ALL" option is prepended. | Available when the user opens the Campaign Code LOV. Re-filtered dynamically based on the current zone, region, dealer, and location selections. |
| Report Server Configuration (`EH_REPORTS`) | Determines whether a report server is available for CSV generation (server-side path) or whether the form's built-in record group path should be used. Looked up by principal map code and application ID. | Consulted by the `VIEW_EXCEL_REPORT_NEW` function at report submission time. EXTERNAL / NOT IN BUNDLE - dependency not directly accessible from the form source bundle. |
| City Master (`MULDMS.GM_CITY`) | Provides city descriptions for dealer outlets, used in the Detail report output. | Joined in the Detail report query at report generation time. EXTERNAL / NOT IN BUNDLE. |
| Enquiry Source List (`AM_LIST` where list_name = 'ENQUIRY_SOURCE') | Provides human-readable enquiry source descriptions mapped from enquiry source codes, used in the Detail report output. | Joined in the Detail report query at report generation time. EXTERNAL / NOT IN BUNDLE. |

### 6.4 Data Lifecycle

*Describes how records are created, updated, and saved within this form's evidenced behaviour.*

**Creation**

- This form does not create any database records. It is a read-only reporting parameter form. No INSERT operations are performed.

**Updates**

- This form does not update any database records. All filter fields are local session parameters only.

**Save and Commit**

- No data is saved or committed to the database by this form. The Save button (FT_SAVE trigger) executes `COMMIT_FORM` followed by `DO_KEY('CLEAR_FORM')` - because this form captures no database items, a commit here has no effect on the database; it only clears the form state.
- The Cancel button (FT_CANCEL trigger) checks whether form data has changed and, if so, asks the user to confirm before clearing the form. If the user confirms, the form is cleared without saving.

**Retention and Audit**

- The form registers its module name (`rr_pre_enq`) and action with `DBMS_APPLICATION_INFO` when it opens (PRE-FORM trigger) and clears that registration when the user exits (KEY-EXIT trigger), supporting database session-level auditing of form usage.
- Application-level logging is started via `stop_watch.start_timer` in the PRE-FORM trigger when the session application log flag is enabled.
- No archival, retention, or purge policy is implemented in this form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Report Type: DETAIL | Region |  | AM_DEALER_LOC | REGION_CD | Region code read from AM_DEALER_LOC (alias am) via am.region_cd, joined to PRE_ENQ_CAMPAIGN on dealer_map_cd and loc_cd. |
| 2 | Report Type: DETAIL | Campaign Code |  | PRE_ENQ_CAMPAIGN | CAMPAIGN_CODE | Campaign code read directly from PRE_ENQ_CAMPAIGN (alias x) via x.campaign_code. |
| 3 | Report Type: DETAIL | Campaign Name |  | PRE_ENQ_CAMPAIGN | CAMPAIGN_NAME | Campaign name read from PRE_ENQ_CAMPAIGN (alias x); commas replaced with spaces via replace(x.campaign_name). |
| 4 | Report Type: DETAIL | Campaign Loading Date |  | PRE_ENQ_CAMPAIGN | CREATED_DATE | Campaign loading date read from PRE_ENQ_CAMPAIGN (alias x) via x.created_date; also used as the date-range filter boundary. |
| 5 | Report Type: DETAIL | Campaign Model |  | PRE_ENQ_CAMPAIGN | TARGET_MODEL | Target model for the campaign read from PRE_ENQ_CAMPAIGN (alias x) via x.target_model. |
| 6 | Report Type: DETAIL | Dealer Code |  | PRE_ENQ_CAMPAIGN | DLR_CODE | Dealer code read from PRE_ENQ_CAMPAIGN (alias x) via x.dlr_code. |
| 7 | Report Type: DETAIL | For Code |  | PRE_ENQ_CAMPAIGN | FOR_CODE | FOR code read from PRE_ENQ_CAMPAIGN (alias x) via x.for_code. |
| 8 | Report Type: DETAIL | Enquiry Outlet Code |  | AM_DEALER_LOC | MUL_DEALER_CD | Shows the Enquiry Outlet Code linked to this enquiry. |
| 9 | Report Type: DETAIL | Dealer Name |  | AM_DEALER_LOC | DEALER_NAME | Dealer name read from AM_DEALER_LOC (alias am) via am.dealer_name; commas replaced with spaces. |
| 10 | Report Type, DETAIL | Delr City |  | GM_CITY | CITY_DESC | Shows the Delr City taken from the enquiry's related records. |
| 11 | Report Type: DETAIL | Pre-Enq Prospect Name |  | PRE_ENQ_CAMPAIGN | CUSTOMER_NAME | Pre-enquiry prospect name read from PRE_ENQ_CAMPAIGN (alias x) via x.customer_name; commas replaced with spaces. |
| 12 | Report Type: DETAIL | Pre-Enq Res. Number |  | PRE_ENQ_CAMPAIGN | RES_NUMBER | Reservation number read from PRE_ENQ_CAMPAIGN (alias x) via x.res_number. |
| 13 | Report Type: DETAIL | Pre-Enq Prospect Address |  | PRE_ENQ_CAMPAIGN | ADDRESS1 | Prospect address concatenated from PRE_ENQ_CAMPAIGN (alias x) columns x.address1, x.address2, x.address3; non-alphanumeric characters stripped via REGEXP_REPLACE and commas replaced with spaces. |
| 14 | Report Type: DETAIL | Status of Pre-Enq |  | PRE_ENQ_CAMPAIGN | FOLLOWUP | Pre-enquiry follow-up status decoded from PRE_ENQ_CAMPAIGN (alias x) x.followup: INTR=Interested, CALB=Call Back, NINT=Not Interested, NREA=Not Reachable, WNUM=Wrong Number, DFDN=Deferred. |
| 15 | Report Type: DETAIL | Remarks |  | PRE_ENQ_CAMPAIGN | REASON | Remark/reason text read from PRE_ENQ_CAMPAIGN (alias x) via x.reason; commas replaced with spaces. |
| 16 | Report Type: DETAIL | Enquiry Num |  | RH_ENQ | ENQ_NUM | Enquiry number read from RH_ENQ (alias rh) via rh.enq_num; outer-joined to PRE_ENQ_CAMPAIGN on enq_num. |
| 17 | Report Type: DETAIL | Enquiry date |  | RH_ENQ | ENQ_DATE | Enquiry date read from RH_ENQ (alias rh) via rh.enq_date; outer-joined to PRE_ENQ_CAMPAIGN on enq_num. |
| 18 | Report Type, DETAIL | Enq. Source |  | RM_ETYPES | ETYPE_DESC | Shows the Enq. Source taken from the enquiry's related records. |
| 19 | Report Type, DETAIL | Enq. Mode |  | AM_LIST | LIST_DESC | Shows the Enq. Mode taken from the enquiry's related records. |
| 20 | Report Type: DETAIL | Enq. Prospect Name |  | RH_ENQ | ENQ_NAME | Shows the Enq. Prospect Name included in this Excel export. |
| 21 | Report Type, DETAIL | Status of Enquiry |  | RD_ENQ | ENQ_STATUS | Shows the Status of Enquiry taken from the enquiry's related records. |
| 22 | Report Type: DETAIL | Lost/Dropped Date |  | RH_ENQ | ENQ_CHANGE_DATE | Lost or dropped date read from RH_ENQ (alias rh) via rh.enq_change_date; outer-joined to PRE_ENQ_CAMPAIGN on enq_num. |
| 23 | Report Type, DETAIL | Invoice Date |  | SH_ORDBOOK | INV_DATE | Shows the Invoice Date taken from the enquiry's related records. |
| 24 | Report Type, DETAIL | Invoiced Model |  | RD_ENQ | MODEL_DESC | Shows the Invoiced Model taken from the enquiry's related records. |
| 25 | Report Type: SUMMARY | Data Sent |  | PRE_ENQ_CAMPAIGN | TOT_FOL | Total records sent in the campaign; derived as count(*) over PRE_ENQ_CAMPAIGN (alias x) grouped by dealer and campaign, aliased tot_fol. |
| 26 | Report Type: SUMMARY | Status |  | PRE_ENQ_CAMPAIGN |  | Derived completion status: CASE WHEN COUNT(flag_ind) = SUM(decode(FOLLOWUP,...)) THEN 'Complete' ELSE 'Incomplete' END; compares flagged records to total actioned records within the campaign group. |
| 27 | Report Type: SUMMARY | Enquiries |  | PRE_ENQ_CAMPAIGN | INTR | Derived count of interested responses: sum(decode(x.followup,'INTR',1,0)) over PRE_ENQ_CAMPAIGN, aliased intr. |
| 28 | Report Type: SUMMARY | Call Backs |  | PRE_ENQ_CAMPAIGN | CALB | Derived count of call-back responses: sum(decode(x.followup,'CALB',1,0)) over PRE_ENQ_CAMPAIGN, aliased calb. |
| 29 | Report Type: SUMMARY | Not Interested |  | PRE_ENQ_CAMPAIGN | NINT | Derived count of not-interested responses: sum(decode(x.followup,'NINT',1,0)) over PRE_ENQ_CAMPAIGN, aliased nint. |
| 30 | Report Type: SUMMARY | Not Reachable |  | PRE_ENQ_CAMPAIGN | NREA | Derived count of not-reachable responses: sum(decode(x.followup,'NREA',1,0)) over PRE_ENQ_CAMPAIGN, aliased nrea. |
| 31 | Report Type: SUMMARY | Wrong Numbers |  | PRE_ENQ_CAMPAIGN | WNUM | Derived count of wrong-number responses: sum(decode(x.followup,'WNUM',1,0)) over PRE_ENQ_CAMPAIGN, aliased wnum. |
| 32 | Report Type: SUMMARY | Deferred |  | PRE_ENQ_CAMPAIGN | DFDN | Derived count of deferred responses: sum(decode(x.followup,'DFDN',1,0)) over PRE_ENQ_CAMPAIGN, aliased dfdn. |
| 33 | Report Type: SUMMARY | Not Attempted |  | PRE_ENQ_CAMPAIGN | NATM | Derived count of records with no follow-up attempt: sum(decode(x.followup,null,1,0)) over PRE_ENQ_CAMPAIGN, aliased natm. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer outlet master table - stores dealer location codes, names, and descriptions | - | Dealer, Dealer Outlet, MULDMS.AM_DEALER_LOC |
| AM_LIST | List-of-values reference table - provides dynamic picklist code-description pairs filtered by list name and principal | - | LOV, L_POPULATE |
| AM_USER_REGION | User-region access control table - maps logged-in users to their authorised zones | MULDMS.AM_USER_REGION | Zone, Principal |
| ASK_CONFIRM | DPL shared-library function - presents a confirmation dialog and returns the user's Yes/No response | - | DISP_TEXT, DPL |
| BTN | Button item in Oracle Forms - a push-button control that triggers an action when clicked | Push Button | SUBMIT, PB_BLK |
| CB_BLK | Control block - the single Oracle Forms data block in rr_pre_enq used to hold all report criteria input fields | Control Block | Block |
| Campaign | A pre-enquiry marketing or sales campaign code and description used to filter report data | - | RG_CAMPAIGN, LV_CAMPAIGN |
| CHECK_NULL | DPL shared-library procedure - validates that a field value is not null before allowing navigation | - | VALIDATE_CN_MAIN, DPL |
| COPY_RIGHT | Copyright display field populated by the SF_COPYRIGHT_DECLARATION function at form startup | - | SF_COPYRIGHT_DECLARATION |
| DMS | Dealer Management System - the integrated dealership operations platform within which rr_pre_enq operates | - | Principal, Zone |
| DPL | DPL program library - the attached PL/SQL shared library providing shared utility routines such as GENERAL.DISP_TEXT, GENERAL.ASK_CONFIRM, and GENERAL.RAISE_ERROR | DPL.pld | GENERAL, PLD |
| DISP_TEXT | DPL shared-library procedure - displays an alert dialog with a supplied message and title | - | ASK_CONFIRM, RAISE_ERROR, DPL |
| DUAL | Oracle pseudo-table used in SQL queries to provide a single-row source for 'ALL' sentinel values in record groups | - | RG_DEALER, RG_REGION, RG_CAMPAIGN |
| GENERAL | Package namespace within DPL.pld that groups shared utility routines including ASK_CONFIRM, CHECK_NULL, DISP_TEXT, L_POP_LIST_ITEM, and RAISE_ERROR | - | DPL |
| GM_REGN | Region master table - stores region codes and descriptions used in the region LOV | - | RG_REGION, Region |
| LOV | List of Values - a pop-up selection list in Oracle Forms that allows users to choose from a filtered set of records | Dropdown, Picklist | Record Group, LV_DEALER, LV_REGION, LV_CAMPAIGN |
| LV_CAMPAIGN | Oracle Forms LOV object bound to RG_CAMPAIGN - presents the campaign selection popup | - | RG_CAMPAIGN, LOV |
| LV_DEALER | Oracle Forms LOV object bound to RG_DEALER - presents the dealer outlet selection popup | - | RG_DEALER, LOV |
| LV_REGION | Oracle Forms LOV object bound to RG_REGION - presents the region selection popup | - | RG_REGION, LOV |
| OLB | Oracle Object Library - a shared library of reusable Oracle Forms components (DPL.olb) that provides inherited blocks, canvases, visual attributes, and triggers | .olb | DPL, PB_BLK |
| P_FROMDT | From-date input field in CB_BLK - the start of the reporting period, validated to be on or before today | From Date | P_TODT |
| P_TODT | To-date input field in CB_BLK - the end of the reporting period, validated within one month of P_FROMDT | To Date | P_FROMDT |
| PB_BLK | Inherited push-button toolbar block from DPL.olb - provides the standard Exit, List, Save, Cancel, Print, Cut, Copy, and Paste buttons | - | OLB, BTN |
| PCK | PL/SQL package source file (`.pck`) - contains package specification and body for database packages called from Oracle Forms | .pck | Package |
| PLD | PL/SQL library source file (`.pld`) - a compiled shared program library attached to Oracle Forms | .pld, Program Library | DPL, WEBUTIL |
| Principal | Multi-company scope key (up to 5 characters) used to filter all record group and report queries to the user's company context | - | GLOBAL.PRINCIPAL, Zone |
| RAISE_ERROR | DPL shared-library procedure - looks up an error message by code, displays it, and halts processing for error-type messages | - | DISP_TEXT, DPL |
| Record Group | Oracle Forms data structure populated by a SQL query or static values; drives LOV popup lists | RG | LOV, RG_DEALER, RG_REGION, RG_CAMPAIGN |
| RG_CAMPAIGN | Record group providing campaign codes and descriptions for the LV_CAMPAIGN LOV | - | LOV, LV_CAMPAIGN, AM_DEALER_LOC |
| RG_DEALER | Record group providing dealer outlet names and codes for the LV_DEALER LOV | - | LOV, LV_DEALER, AM_DEALER_LOC |
| RG_REGION | Record group providing region codes and descriptions for the LV_REGION LOV | - | LOV, LV_REGION, GM_REGN |
| Zone | A geographic or organisational grouping of regions and dealer outlets used to scope report criteria and restrict user access | - | Region, Principal, AM_USER_REGION |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: rr_pre_enq (RR_PRE_ENQ)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: WEBUTIL (webutil.olb), DMS_EXCEL_REPORT, D2KWUTIL, DPL (DPL.pld program library)
- First Navigation Block: -
- Console Window: WN_MAIN - Detail/Summary Report (Rel 1.1.5)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `rr_pre_enq_fmb.xml`; OLB `DPL.olb`; WEBUTIL (webutil.olb); DMS_EXCEL_REPORT; D2KWUTIL; DPL (DPL.pld program library)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier passed to the Excel report engine at form startup |
| APP_LOG | Char | Trigger | Logging flag ('Y'/'N') that activates performance timer in PRE-FORM |
| CUR_DATE | Date | ProgramUnit | Current date used for date-range defaulting and validation (INFERRED from date comparisons) |
| DEALER | Char | ProgramUnit | Selected dealer code used as a SQL filter string in report queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Multi-company principal key (up to 5 chars) that scopes all record group and report queries |
| USERID | Char | Trigger | Logged-in user identifier appended to output file names for report generation |

### 8.1.2 Form Parameters

*All 9 ModuleParameter entries from rr_pre_enq_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_APP_ID | Char | - | Application ID pre-set from the global at form startup; drives Excel report generation |
| ENQ_DATE | Date | - | Enquiry date pre-filter passed from the calling form context |
| P_CHECK | Number | 0 | Numeric control flag used for conditional processing checks |
| TB | Number | 0 | Tab or toggle numeric control flag for screen state management |
| PR_REMARK | Char | - | Remark text carried from the calling context; reserved - not used in current form logic |
| CHECK_MAND | Char | N | Mandatory-check toggle; when 'Y' enforces field validation on submit |
| P_USER_TYPE | Char | DLR | User type code (default 'DLR' = dealer) that controls data visibility and scope |
| P_REGION | Char | - | Region code pre-filter passed from the calling context |
| P_USER_HORO | Char | - | User hierarchy or horizontal organisation scope code passed from the calling context |

**Total Parameters:** 9

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control - report criteria entry block; no database table binding |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from rr_pre_enq_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in rr_pre_enq_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `rr_pre_enq_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 19 | 0 | 19 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 2 | 0 | 2 |
| **Total** | **33** | **0** | **33** |

**Item detail (all 33 items, excluding WEBUTIL block):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | P_ZONE | false | Zone selection list; drives region and dealer LOV filtering |
| CB_BLK | P_REGION_CD | false | Internal region code set by LV_REGION LOV selection |
| CB_BLK | P_REGION_DESC | false | Region description input field; opens LV_REGION LOV for selection |
| CB_BLK | P_PARENT | false | Parent group code returned by LV_DEALER LOV selection |
| CB_BLK | P_DEALER | false | Dealer map code (up to 5 chars) returned by LV_DEALER LOV |
| CB_BLK | P_DEALER_DESC | false | Dealer name input field; opens LV_DEALER LOV for selection; mandatory |
| CB_BLK | P_LOC | false | Location code returned by LV_DEALER LOV selection |
| CB_BLK | LOC_DESC | false | Location description returned by LV_DEALER LOV selection |
| CB_BLK | REPORT_DESC | false | Read-only report title display; shows 'Pre-Enquiry Detail/Summary Report' |
| CB_BLK | P_FROMDT | false | Report from-date; validated to be ≤ SYSDATE and ≤ P_TODT; auto-defaults P_TODT to month end |
| CB_BLK | P_TODT | false | Report to-date; validated to be ≥ P_FROMDT, ≤ SYSDATE, and within 1 month of P_FROMDT |
| CB_BLK | P_CAMPAIGN_CODE | false | Campaign code returned by LV_CAMPAIGN LOV selection |
| CB_BLK | P_CAMPAIGN_DESC | false | Campaign name input field; opens LV_CAMPAIGN LOV for selection |
| CB_BLK | P_REPORT_TYPE | false | Report type selection list ('D' = Detail, 'S' = Summary) |
| CB_BLK | P_DESTYPE | false | Report destination type selection list (screen or file output) |
| CB_BLK | SUBMIT | false | Push button that submits report criteria and generates the Excel report |
| CB_BLK | S_NUM | false | Internal numeric sequence field (hidden) |
| CB_BLK | COPY_RIGHT | false | Copyright notice display field; populated from SF_COPYRIGHT_DECLARATION function |
| CB_BLK | TXT | false | **INACTIVE** - 20,000-character text buffer; formerly held dynamic SQL string for report generation |
| PB_BLK | PB_PASTE | false | Toolbar push button - Paste action (standard clipboard paste) |
| PB_BLK | PB_COPY | false | Toolbar push button - Copy action (standard clipboard copy) |
| PB_BLK | PB_CUT | false | Toolbar push button - Cut action (standard clipboard cut) |
| PB_BLK | PB_PRINT | false | Toolbar push button - Print action |
| PB_BLK | PB_SAVE | false | Toolbar push button - Save / commit action |
| PB_BLK | PB_CANCEL | false | Toolbar push button - Cancel / clear action |
| PB_BLK | PB_DEL | false | Toolbar push button - Delete record action |
| PB_BLK | PM_CONT | false | Toolbar push button - Continue / next action |
| PB_BLK | PB_INSERT | false | Toolbar push button - Insert / new record action |
| PB_BLK | PB_LIST | false | Toolbar push button - List of values action |
| PB_BLK | PB_EXIT | false | Toolbar push button - Exit / close form action |
| PB_BLK | PB_ERR_EXIT | false | Toolbar push button - Exit from error screen action |
| CB_ERR | TXT_ERR | false | Error message display text item on the error canvas (CN_ERR) |
| CB_ERR | TXT | false | Secondary text item on the error block |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Dealer Details | RG_DEALER | CB_BLK.P_DEALER_DESC |
| LV_REGION | Region Master | RG_REGION | CB_BLK.P_REGION_DESC |
| LV_CAMPAIGN | Service Type | RG_CAMPAIGN | CB_BLK.P_CAMPAIGN_DESC, CB_BLK.P_REPORT_TYPE |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | - | (set at runtime) | WebUtil built-in infrastructure; raised when a WebUtil API call fails |
| ALERT_BUT | Note |  Please select valid region code and for code | No active calling code found in form triggers or program units; vestigial alert |

**Total Alerts:** 2

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | GENERAL.CHECK_NULL | **INACTIVE** - Body is entirely commented out; formerly validated test-drive fields using CHECK_NULL |
| CHECK_BEFORE_DELETE | Unknown | SH_ENQUIRY, GENERAL.DISP_TEXT | **INACTIVE** - Body is entirely commented out; formerly counted SH_ENQUIRY records before allowing zone deletion |
| POPULATE_ERRORS | Package spec | pk_plsql_table.code_tab | Declares error-code table variable v_tab; consuming FT_SAVE validation loop is commented out |
| L_POPULATE | Procedure | Create_Group_From_Query, Populate_Group, Populate_List, webutil.ID_NULL, AM_LIST | Builds a dynamic list item from the AM_LIST reference table filtered by list name and current principal |
| PR_REMOVE_ASCII_CHR | Procedure | GENERAL.DISP_TEXT, text_io, web.show_document | Strips CHR(12) form-feed characters from the generated report output file, then opens the cleaned file in the browser |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |



**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a confirmation dialog with the supplied message; returns 1 for OK/Yes or 0 for Cancel |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN | Validates that a field value is not null; raises FORM_TRIGGER_FAILURE with the column title if empty |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.P_DEALER_DESC, CB_BLK.P_FROMDT, CB_BLK.P_REGION_DESC, CB_BLK.P_TODT, CB_BLK.P_ZONE, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a message dialog using the AL_ERRINFO alert (Error title) or AL_NOTE alert (other titles) |
| GENERAL.L_POP_LIST_ITEM | Library routine | Form level | Creates or repopulates a named record group from a dynamic SQL statement and populates a list item |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code, displays it via DISP_TEXT, and raises FORM_TRIGGER_FAILURE for error-type messages |



### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Commented out** | Form | - | ON-ERROR | Looked up error messages from an AM_ERRMSG table via RAISE_ERROR; displayed via DISP_TEXT | Replaced by inline error-code mapping directly in trigger body; message-table lookup commented out |
| **Inactive stub** | Form | - | KEY-COMMIT | Would have committed the form and cleared it | Commit disabled; form is report-only; body is `null;` |
| **Inactive stub** | Form | - | KEY-UP | Navigated to previous record or row | Navigation key suppressed; body is `null;` |
| **Inactive stub** | Form | - | KEY-DOWN | Navigated to next record or row | Navigation key suppressed; body is `null;` |
| **Inactive stub** | Form | - | KEY-PRVBLK | Navigated to previous block | Block navigation suppressed; body is `null;` |
| **Inactive stub** | Form | - | KEY-NXTBLK | Navigated to next block | Block navigation suppressed; body is `null;` |
| **Inactive stub** | Form | - | KEY-PREV-ITEM | Navigated to previous item in tab sequence | Item navigation suppressed; body is `null;` |
| **Inactive stub** | Form | - | KEY-OTHERS | Suppressed unrecognised keystrokes | Keystroke suppression; body is `null;` |
| **Commented out** | Form | - | FT_SAVE | Validated fields via POPULATE_ERRORS and committed the form | Validation loop commented out; replaced by simplified COMMIT_FORM call |
| **Commented out** | CB_BLK | P_REGION_DESC | WHEN-LIST-CHANGED | Cleared dealer, location, and campaign fields when region changed | Replaced by zone WHEN-LIST-CHANGED logic; region change handler commented out |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Confirmed exit and closed the form | Replaced by inherited OLB trigger that calls GENERAL.ASK_CONFIRM before exit |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*


**Complete trigger inventory (40 business triggers):**
*rr_pre_enq_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts Oracle and Forms runtime errors; maps specific error codes to user-friendly messages via GENERAL.DISP_TEXT |
| ON-MESSAGE | Form | - | Form level | Intercepts Forms informational messages and suppresses or reformats them using GENERAL.DISP_TEXT |
| KEY-EXIT | Form | - | Form level | Handles the Exit key; asks user to confirm before closing the form |
| KEY-LISTVAL | Form | - | Form level | Triggers the LOV popup for the currently active field |
| KEY-COMMIT | Form | - | Form level | **INACTIVE** - Commit action disabled; body is `null;`; form is report-only |
| KEY-CLRFRM | Form | - | Form level | Clears all form fields and resets the input criteria |
| KEY-OTHERS | Form | - | Form level | Suppresses unrecognised keystrokes to prevent unintended navigation |
| KEY-NEXT-ITEM | Form | - | Form level | Navigates to the next item in the tab sequence |
| KEY-PREV-ITEM | Form | - | Form level | Navigates to the previous item in the tab sequence |
| KEY-NXTBLK | Form | - | Form level | Navigates to the next block |
| KEY-PRVBLK | Form | - | Form level | Navigates to the previous block |
| KEY-DOWN | Form | - | Form level | Moves cursor to the next record or row |
| KEY-UP | Form | - | Form level | Moves cursor to the previous record or row |
| FT_SAVE | Form | - | Form level | Commits the form and clears it; validation loop is commented out |
| FT_CANCEL | Form | - | Form level | Asks the user to confirm cancellation via ASK_CONFIRM; clears the form if confirmed |
| FT_INSERT | Form | - | Form level | Displays an informational message indicating insert is not applicable for this report form |
| FT_DEL | Form | - | Form level | Asks the user to confirm deletion via ASK_CONFIRM; proceeds if confirmed |
| FT_LIST | Form | - | Form level | Triggers the LOV popup for the currently focused list field |
| FT_PRINT | Form | - | Form level | Initiates report print action |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Maximises windows; sets report title and default dates; loads zone LOV from user-region access table; sets copyright |
| PRE-FORM | Form | - | Form level | Registers the application context using DBMS_APPLICATION_INFO; starts performance timer if logging is enabled |
| WHEN-VALIDATE-ITEM | CB_BLK | P_ZONE | CB_BLK.P_ZONE | Validates that a zone has been selected and clears dependent region and dealer fields on change |
| WHEN-LIST-CHANGED | CB_BLK | P_ZONE | CB_BLK.P_ZONE | Refreshes region and dealer LOV record groups when the selected zone changes |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REGION_DESC | CB_BLK.P_REGION_DESC | Validates that a region description has been entered; displays error if blank |
| WHEN-LIST-CHANGED | CB_BLK | P_REGION_DESC | CB_BLK.P_REGION_DESC | **COMMENTED OUT / INACTIVE** - Previously cleared dealer and campaign fields when region changed |
| WHEN-VALIDATE-ITEM | CB_BLK | P_DEALER_DESC | CB_BLK.P_DEALER_DESC | Validates that a dealer name has been selected; displays error if blank |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROMDT | CB_BLK.P_FROMDT | Validates from-date is not in the future; auto-defaults P_TODT to the end of the from-date's month |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TODT | CB_BLK.P_TODT | Validates to-date is ≥ from-date, ≤ SYSDATE, and within one month of from-date |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Builds parameterised report SQL for Detail or Summary report type and calls the Excel report generator |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Asks the user to confirm before closing the form; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens LOV popup for current field; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Initiates insert action; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Continues form processing; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Initiates delete action; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels current operation; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Saves the form; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Prints the current report or screen; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts selected text; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies selected text; inherited from OLB object group |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text; inherited from OLB object group |

### 8.8 Canvas and Window Inventory

**Window Inventory**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WN_MAIN | Detail/Summary Report (Rel 1.1.5) | CN_MAIN |
| WIN_ERR | - | CN_ERR |
| WEBUTIL_HIDDEN_WINDOW | - | WEBUTIL_CANVAS |

**Canvas Inventory**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_MAIN | Content | WN_MAIN |
| CN_TOOL | Content | WN_MAIN |
| CN_ERR | Content | WIN_ERR |
| WEBUTIL_CANVAS | Content | WEBUTIL_HIDDEN_WINDOW |

### 8.9 Editors

*No editors found in rr_pre_enq_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in rr_pre_enq_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger/object |
| KEY-NEXT-ITEM | Inherited trigger/object |
| KEY-PREV-ITEM | Inherited trigger/object |
| KEY-NXTBLK | Inherited trigger/object |
| KEY-PRVBLK | Inherited trigger/object |
| KEY-DOWN | Inherited trigger/object |
| KEY-UP | Inherited trigger/object |
| CN_ERR | Inherited trigger/object |
| VA_DISP | Inherited trigger/object |
| CB_ERR | Inherited trigger/object |
| VA_LOV | Inherited trigger/object |
| VA_TRNI_DT | Inherited trigger/object |
| VA_TITLE | Inherited trigger/object |
| VA_ALERT | Inherited trigger/object |
| VA_BUTN | Inherited trigger/object |
| VA_TEXT | Inherited trigger/object |
| VA_MPROMPT | Inherited trigger/object |
| VA_OPROMPT | Inherited trigger/object |
| VA_MAND | Inherited trigger/object |
| VA_NUM | Inherited trigger/object |
| VA_DESC | Inherited trigger/object |
| VA_ICONIC_BUTN | Inherited trigger/object |
| VA_RB | Inherited trigger/object |
| VA_CB | Inherited trigger/object |
| WN_MAIN | Inherited trigger/object |
| POP_MAIN | Inherited trigger/object |
| CN_MAIN | Inherited trigger/object |
| CN_TOOL | Inherited trigger/object |
| PB_BLK | Inherited trigger/object |
| AL_ERRINFO | Inherited trigger/object |
| AL_NOTE | Inherited trigger/object |
| AL_CONFIRM | Inherited trigger/object |
| WIN_ERR | Inherited trigger/object |
| AL_PRINT | Inherited trigger/object |
| FT_SAVE | Inherited trigger/object |
| FT_CANCEL | Inherited trigger/object |
| FT_INSERT | Inherited trigger/object |
| FT_DEL | Inherited trigger/object |
| FT_LIST | Inherited trigger/object |
| FT_PRINT | Inherited trigger/object |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger/object |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in rr_pre_enq_fmb.xml.*

---

## 9. Object Library

*The form references two Object Library (OLB) sources: DPL.olb (the DMS Platform Library, containing Visual Attributes and Property Classes) and webutil.olb (the Oracle WebUtil object group). The Visual Attributes from DPL.olb are included in the form via the OG_GROUP object group (subclassed from DPL_MTPL.fmb, which draws them from DPL.olb). The WEBUTIL object group is included directly from webutil.olb.*

Source OLB file(s): DPL.olb (DPL_olb.xml), webutil.olb (webutil_olb.xml)

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_DISP | VisualAttribute | Display/read-only item visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP; no direct subclass in this form's items |
| VA_LOV | VisualAttribute | LOV / list field visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_TRNI_DT | VisualAttribute | Transaction date field visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_TITLE | VisualAttribute | Title / heading visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_ALERT | VisualAttribute | Alert dialog visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_BUTN | VisualAttribute | Push button visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_TEXT | VisualAttribute | Standard text item visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_MPROMPT | VisualAttribute | Mandatory field prompt label visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_OPROMPT | VisualAttribute | Optional field prompt label visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_MAND | VisualAttribute | Mandatory field background/foreground style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_NUM | VisualAttribute | Numeric field visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_DESC | VisualAttribute | Description field visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_RB | VisualAttribute | Radio button visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| VA_CB | VisualAttribute | Check box visual style (from DPL.olb, included via OG_GROUP) | 0 | Included in OG_GROUP |
| OG_GROUP | ObjectGroup | Standard DMS Platform object group subclassed from DPL_MTPL.fmb; includes common triggers (KEY-*), canvases, windows, toolbar buttons, alerts, and Visual Attributes used across all DMS forms | 1 | CB_ERR block, PB_BLK block, CN_MAIN canvas, CN_ERR canvas, WN_MAIN window, WIN_ERR window, FT_SAVE/FT_CANCEL/FT_INSERT/FT_DEL/FT_LIST/FT_PRINT triggers, all VA_* entries |
| WEBUTIL | ObjectGroup | Oracle WebUtil client-server integration object group from webutil.olb; provides bean area items for file transfer, client info, host commands, session, OLE, browser, and C-API functions | 1 | WEBUTIL block (DUMMY, WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_BROWSER_FUNCTIONS) |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_DEALER | Query | LV_DEALER | DEALER_NAME | LOC_DESC | Yes - CB_BLK | Lists dealer outlets filtered by zone, region, and principal for the user to select a dealer | LV_DEALER -> CB_BLK.P_DEALER_DESC |
| RG_REGION | Query | LV_REGION | REGION | CODE | Yes - CB_BLK | Lists regions filtered by zone and principal for the user to select a report region | LV_REGION -> CB_BLK.P_REGION_DESC |
| RG_CAMPAIGN | Query | LV_CAMPAIGN | LIST_CODE | LIST_DESC | Yes - CB_BLK | Lists pre-enquiry campaign codes filtered by dealer and region for the user to select a campaign | LV_CAMPAIGN -> CB_BLK.P_CAMPAIGN_DESC, CB_BLK.P_REPORT_TYPE |

**Total Record Groups:** 3

---

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | Trigger WHEN-BUTTON-PRESSED | Dealer outlet master - stores dealer location codes and descriptions used in report sub-queries |
| `AM_LIST` | - | L_POPULATE | List-of-values reference table - provides dynamic picklist values filtered by list name and principal |
| `DUAL` | - | RG_CAMPAIGN, RG_DEALER, RG_REGION, Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle pseudo-table - provides 'ALL' sentinel rows in record group queries and single-row selects |
| `GM_REGN` | - | RG_REGION | Region master - stores region codes and descriptions for the region LOV |
| `MULDMS.AM_DEALER_LOC` | - | RG_CAMPAIGN, RG_DEALER | Dealer outlet master (schema-qualified) - drives dealer and campaign LOV record group queries |
| `MULDMS.AM_USER_REGION` | - | Trigger WHEN-NEW-FORM-INSTANCE | User-region access control table - restricts the zone LOV to the authorised zones for the logged-in user |

**Total Referenced Objects:** 6

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-002 | GENERAL.L_POP_LIST_ITEM | Populates the Zone drop-down list with the zones authorised for the logged-in user on form open |
| BR-002, BR-014 | SF_COPYRIGHT_DECLARATION | Returns the current financial year copyright string displayed at the bottom of the screen |
| BR-008 | VIEW_EXCEL_REPORT_NEW | Generates a CSV report file from the report query and delivers it to the user's computer |
| BR-008, BR-020 | WEB.SHOW_DOCUMENT | Presents the cleaned report CSV file to the user via the web browser (called from PR_REMOVE_ASCII_CHR) |
| BR-009, BR-016 | GENERAL.ASK_CONFIRM | Displays a confirmation alert to the user and returns the user's choice |
| BR-011 | GENERAL.RAISE_ERROR | Resolves an error code to its message and displays it; raises trigger failure for error-type messages |
| BR-011, BR-012, BR-015 | GENERAL.DISP_TEXT | Displays a message as a visible alert with appropriate severity |
| BR-001, BR-010 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers and clears the client module name in the Oracle database session |
| BR-001, BR-010 | DBMS_APPLICATION_INFO.SET_MODULE | Registers and clears the module name and action label in the Oracle database session |
| BR-020 | PR_REMOVE_ASCII_CHR | Reads a server-side report file, strips form-feed control characters, writes the cleaned file, and opens it in the browser (form-local procedure) |
| BR-021 | L_POPULATE | Populates a named list field from the application code master table; defined in the form but not called from any active trigger in the current deployment (form-local procedure - not invoked by active triggers) |
| BR-017 | POPULATE_ERRORS | Declares a package-level table variable used by the (inactive) form validation error-collection logic in FT_SAVE; the active code does not reference it (form-local package spec - referenced by commented-out code only) |

### 12.2 Procedure and Package Catalogue

#### GENERAL (DPL.pld / DPL.pll)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| GENERAL.L_POP_LIST_ITEM | DPL Attached Library | WHEN-NEW-FORM-INSTANCE (Form) | Populates a list item on screen by executing a caller-supplied SQL query and loading the results into the named list field |
| GENERAL.DISP_TEXT | DPL Attached Library | ON-ERROR (Form); ON-MESSAGE (Form); WHEN-VALIDATE-ITEM (CB_BLK.P_ZONE); WHEN-VALIDATE-ITEM (CB_BLK.P_REGION_DESC); WHEN-VALIDATE-ITEM (CB_BLK.P_DEALER_DESC); WHEN-VALIDATE-ITEM (CB_BLK.P_FROMDT); WHEN-VALIDATE-ITEM (CB_BLK.P_TODT); FT_INSERT (Form); PR_REMOVE_ASCII_CHR (Form PU) | Displays a message to the user as a visible alert with an error or note severity, selected by the title parameter |
| GENERAL.RAISE_ERROR | DPL Attached Library | ON-ERROR (Form) | Resolves an error code to its stored message text and displays it to the user; raises FORM_TRIGGER_FAILURE for error-type messages |
| GENERAL.ASK_CONFIRM | DPL Attached Library | FT_CANCEL (Form); FT_DEL (Form) | Displays a confirmation alert with a caller-supplied message and returns 1 if the user confirms or 0 if the user declines |

#### DBMS_APPLICATION_INFO (Built-in Oracle Package)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in (EXTERNAL / NOT IN BUNDLE) | PRE-FORM (Form); KEY-EXIT (Form) | Writes or clears the client module name against the current Oracle database session for operational monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in (EXTERNAL / NOT IN BUNDLE) | PRE-FORM (Form); KEY-EXIT (Form) | Writes or clears the module name and action label against the current Oracle database session |

#### VIEW_EXCEL_REPORT_NEW (DMS_EXCEL_REPORT.pld / .pll)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| VIEW_EXCEL_REPORT_NEW | DMS_EXCEL_REPORT Attached Library | WHEN-BUTTON-PRESSED (CB_BLK.SUBMIT) | Generates a CSV report file from the caller-supplied query result and delivers it to the user's computer, choosing between a server-side generation path and a Forms record-group path based on the configured report server for the principal |

#### WEB (DPL.pld / DPL.pll)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| WEB.SHOW_DOCUMENT | DPL Attached Library | PR_REMOVE_ASCII_CHR (Form PU) | Opens the specified server-side file path in a new browser window so the user can view or download the cleaned report output |

#### SF_COPYRIGHT_DECLARATION (DPL.pld / DPL.pll)

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| SF_COPYRIGHT_DECLARATION | DPL Attached Library | WHEN-NEW-FORM-INSTANCE (Form); KEY-CLRFRM (Form) | Determines the current Indian financial year from today's date and returns the formatted copyright notice string for display on screen |

#### Form-Local Program Units

| Procedure/Package Name | Classification | Called From | Purpose |
| ---------------------- | -------------- | ----------- | ------- |
| PR_REMOVE_ASCII_CHR | Form-Local Procedure (active) | Called from DMS_EXCEL_REPORT library at report delivery time | Reads a server-side report output file line by line, strips form-feed control characters (lines starting with ASCII 12), writes the cleaned content to a new output file, and opens the cleaned file in the browser via WEB.SHOW_DOCUMENT |
| L_POPULATE | Form-Local Procedure (active - not invoked by any active trigger) | Not called from any active trigger in the current form | Populates a named list field from the application code master table (AM_LIST) for the current principal; deletes any pre-existing record group before re-creating it |
| POPULATE_ERRORS | Form-Local Package Spec (active - referenced only by commented-out FT_SAVE logic) | Referenced in commented-out code in FT_SAVE (Form); that code does not execute | Declares a package-level table variable (`v_tab`) intended for collecting form validation errors before display; the active FT_SAVE code does not use this variable |

---

## 13. Package Procedure Specifications

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/rr_pre_enq-2ab94607a9d9/in``. Package specifications cannot be generated without uploaded PCK sources.*

---

## 14. Database Package Catalogue

*No `.pck` source files were found in the input bundle - no database package catalogue entries can be generated. The table structures below are present as required shells.*

**Database Package Catalogue**

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| - | - | - | - | - | - | No PCK files found |

**Function Return Values**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| - | - | - | No PCK files found |

---

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | Displays the AL_CONFIRM alert with the supplied message and returns 1 if the user clicks OK/Yes or 0 if the user clicks Cancel; used to gate destructive or cancellation actions |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DEALER_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_ZONE | Displays the AL_ERRINFO alert when the title is 'Error', otherwise displays AL_NOTE; sets the alert message at runtime from the supplied text_string and title_string arguments |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2,P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item by querying the AM_LIST reference table filtered by list name and the current principal; constructs the list from code-description pairs |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2,p_select VARCHAR2) | Trigger: WHEN-NEW-FORM-INSTANCE in Form | Creates or repopulates a named record group by executing the supplied SELECT statement and then populates the bound list item from the resulting data |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Looks up an error message by its code and displays it via DISP_TEXT; raises FORM_TRIGGER_FAILURE when the message type is 'E' to halt processing |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``rr_pre_enq_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Previously validated that required test-drive fields were not null; called only within the commented-out VALIDATE_CN_MAIN program unit |

**Total Active Routines:** 5 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: L_POPULATE | Returns TRUE if the supplied Oracle Forms ID handle is invalid or null; used in L_POPULATE to check whether a record group already exists before attempting to create a new one |

**Total Active Routines:** 1 of 28 in webutil.pld source

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Zone Authorisation Lookup | MULDMS.AM_USER_REGION, MULDMS.AM_ZONE | user_id (string), principal_map_cd (string) | List of authorised zone codes and descriptions for the user | Returns the list of geographic zones the logged-in user is permitted to access, filtered by principal map code; prepends an "ALL" option | GET /api/v1/zones/authorised?userId={userId}&principalMapCd={principalMapCd} |
| MS-002 | Region Lookup by Zone | MULDMS.GM_REGN | zone_cd (string), principal_map_cd (string) | List of region codes and descriptions within the specified zone | Returns all regions belonging to the given zone and principal, used to populate the Region filter list | GET /api/v1/regions?zoneCd={zoneCd}&principalMapCd={principalMapCd} |
| MS-003 | Dealer Outlet Lookup by Zone and Region | MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN | zone_cd (string), region_cd (string), principal_map_cd (string) | List of active dealer outlets (name, dealer map code, parent group, location code) within zone and region | Returns all active dealer outlets (type S or 3S, not terminated) within the specified zone and region for the principal, used to populate the Dealer filter list | GET /api/v1/dealers?zoneCd={zoneCd}&regionCd={regionCd}&principalMapCd={principalMapCd} |
| MS-004 | Campaign Lookup by Geographic Filters | MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN | zone_cd (string), region_cd (string), dealer_map_cd (string), parent_group (string), loc_cd (string), principal_map_cd (string) | List of distinct campaign codes and names available within the specified filters | Returns all pre-enquiry campaigns matching the current zone, region, dealer, parent group, and location filter selections for the principal, used to populate the Campaign Code filter list | GET /api/v1/campaigns?zoneCd={zoneCd}&regionCd={regionCd}&dealerMapCd={dealerMapCd}&locCd={locCd}&principalMapCd={principalMapCd} |
| MS-005 | Pre-Enquiry Detail Report Generation | MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN, MULDMS.RH_ENQ, MULDMS.RD_ENQ, MULDMS.GM_CITY, MULDMS.GM_MOD, AM_LIST, MULDMS.SH_ORDBOOK, MULDMS.SH_INVOICE | zone_cd (string), region_cd (string), dealer_map_cd (string), parent_group (string), loc_cd (string), campaign_code (string), from_date (date), to_date (date), principal_map_cd (string) | CSV data stream with one row per pre-enquiry campaign prospect including campaign, dealer, prospect, enquiry, booking, and invoice details | Retrieves all pre-enquiry campaign records matching the filter parameters and returns the detail-level CSV payload including campaign, prospect, enquiry, booking, invoice, and model information | POST /api/v1/reports/pre-enquiry/detail |
| MS-006 | Pre-Enquiry Summary Report Generation | MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN | zone_cd (string), region_cd (string), dealer_map_cd (string), parent_group (string), loc_cd (string), campaign_code (string), from_date (date), to_date (date), principal_map_cd (string) | CSV data stream with one row per region/dealer/campaign aggregating follow-up outcome counts | Retrieves pre-enquiry campaign records matching the filter parameters and aggregates them by region, dealer, and campaign, returning follow-up outcome counts (Interested, Call Back, Not Interested, Not Reachable, Wrong Numbers, Deferred, Not Attempted) and completion status | POST /api/v1/reports/pre-enquiry/summary |
| MS-007 | Report Server Configuration Lookup | EH_REPORTS | principal_map_cd (string), app_id (string) | Report server address (string) or null if not configured | Looks up the report server URL configured for the given principal and application ID to determine which CSV delivery path to use | GET /api/v1/config/report-server?principalMapCd={principalMapCd}&appId={appId} |

**Total Microservices Identified: 7**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Pre-Enquiry Report Parameter Entry and Submission | User opens the Pre-Enquiry Detail/Summary Report form (PRE-FORM + WHEN-NEW-FORM-INSTANCE triggers fire) | 1. Form opens: windows maximised, report title displayed, default date range set, Zone list populated with authorised zones, copyright notice displayed. 2. User selects Zone. 3. User selects Region (dependent dealer and location cleared on Zone change). 4. User selects Dealer (dependent location cleared on Region change). 5. User optionally selects Campaign Code. 6. User enters Campaign From Date; To Date auto-recalculated to end of month. 7. User confirms or adjusts To Date. 8. User selects Report Type (Detail or Summary). 9. User clicks Submit Report. 10. Report query built and CSV file generated and delivered to user's computer. 11. CSV file opened automatically on user's device. | Zone must be authorised for the user (BRC-022). Zone selection required (BRC-001). Region code must resolve from lookup (BRC-003). Dealer must be selected (BRC-005). From Date must be non-blank, non-future, not after To Date (BRC-006, BRC-007, BRC-008). To Date requires From Date (BRC-011); must not precede From Date (BRC-012); must not be future (BRC-013); range must not exceed one month (BRC-014). Report Type must be Detail or Summary. Report server availability determines CSV delivery path (MS-007). | CSV report file delivered to user's computer and opened; form filter fields remain as last submitted for reuse or adjustment. |
| WF-002 | Form Cancel with Unsaved Changes | User clicks the Cancel toolbar button (FT_CANCEL trigger fires) | 1. System checks whether the form has unsaved changes. 2a. If changes exist: confirmation message shown ("Entered data will not be Saved"). 3a. If user confirms: form cleared. 4a. If user declines: form remains unchanged. 2b. If no changes: form cleared immediately. | Form has unsaved changes (BRC-016): yes -> prompt; no -> clear immediately. User confirms discard: yes -> clear; no -> preserve. | Form cleared (filter fields reset) or unchanged (if user declines). |
| WF-003 | Form Exit | User presses the exit keyboard shortcut or clicks the Exit toolbar button (KEY-EXIT trigger fires) | 1. Database session application info (module name and client info) cleared. 2. Form closed without saving any data. | None - no conditional branching in the current implementation (prior unsaved-changes check in the Exit button code is commented out). | Form closed; database session no longer labelled with the report module. |
| WF-004 | Error Message Interception and Display | Any form operation raises an Oracle Forms or database error (ON-ERROR trigger fires) | 1. Error code examined. 2. If invalid date (50004): show "Entered Date is not valid Date". 3. If date format (50025/50026): show "Enter the Date in the proper format (DD-MM-YYYY)". 4. If non-numeric in numeric field (40209/50016): show "Characters/Special Characters are not allowed here, enter the numeric value". 5. If item validation (40207): show the error text from the Forms engine. 6. If foreign key violation (DB -2292): call RAISE_ERROR for code 'E0088'. 7. If concurrent update (40654-40659): show "Record Has been Updated by other User..."; rollback. 8. If any other SQL error: show SQLERRM; rollback. 9. If navigation error (40401/40405): suppress silently. | Error code determines which message is shown (BRC-017 through BRC-020). Concurrent update and general SQL errors trigger a database rollback. Navigation errors are suppressed. | User sees a plain-language error alert; processing of the triggering action is halted (trigger failure raised) in all branches except the suppressed navigation codes. |

**Total Workflows Identified: 4**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ASK_CONFIRM | Business Logic | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form | /api/v1/pld/ask_confirm | When a cancellation or deletion is initiated, then a confirmation dialog is presented and the action proceeds only if the user confirms |
| PLD-002 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field is empty, then an error message is raised and navigation to the empty field occurs |
| PLD-003 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_DEALER_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_FROMDT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_DESC, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_TODT, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_ZONE | /api/v1/pld/disp_text | When a message must be shown to the user, then an alert dialog is displayed with the supplied title and text |
| PLD-004 | L_POPULATE | Business Logic | ProgramUnit: L_POPULATE | /api/v1/pld/l_populate | When a list item requires population, then it is filled with code-description pairs from the AM_LIST reference table filtered by principal |
| PLD-005 | l_pop_list_item | Business Logic | Trigger: WHEN-NEW-FORM-INSTANCE in Form | /api/v1/pld/l_pop_list_item | When a list item needs to be loaded from a dynamic query, then the record group is created and the list item is populated from the query result |
| PLD-006 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an error code is encountered, then the corresponding message is displayed and form processing is halted for error-type messages |


---

### webutil.pld (`WEBUTIL_C_API`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: L_POPULATE | /api/v1/pld/id_null | When a record group handle is checked, then TRUE is returned if the handle is invalid or null so that a new group can be created |

---

---

## 19. PCK-Backed Logic

*NO PCK files found - no ``*.pck`` source files were discovered in ``/app/workspace/rr_pre_enq-2ab94607a9d9/in``. PCK-backed logic cannot be generated without uploaded PCK sources.*

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Zone Authorisation Query | SELECT (read-only) | Retrieves the zones the logged-in user is authorised to access, filtered by user ID and principal map code, to populate the Zone drop-down on form open | Form -> MULDMS.AM_USER_REGION, MULDMS.AM_ZONE -> Zone list items returned to form | No explicit error handling in the zone population call; an empty result set produces an empty Zone list |
| Region Lookup Query | SELECT (read-only) | Retrieves region codes and descriptions for the selected zone and principal, to populate the Region LOV (LV_REGION via RG_REGION) | Form -> MULDMS.GM_REGN -> Region list items returned to LOV | Bound to the LOV record group; an empty result set produces an empty Region LOV |
| Dealer Outlet Lookup Query | SELECT (read-only) | Retrieves active dealer outlets (type S or 3S, not terminated) within the selected zone and region for the current principal, to populate the Dealer LOV (LV_DEALER via RG_DEALER) | Form -> MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN -> Dealer list items returned to LOV | Bound to the LOV record group; an empty result set produces an empty Dealer LOV |
| Campaign Lookup Query | SELECT (read-only) | Retrieves distinct pre-enquiry campaigns available within the current zone, region, dealer, and location selections for the principal, to populate the Campaign LOV (LV_CAMPAIGN via RG_CAMPAIGN) | Form -> MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN -> Campaign list items returned to LOV | Bound to the LOV record group; an empty result set produces an empty Campaign LOV |
| Pre-Enquiry Detail Report Query | SELECT (read-only) | Retrieves one row per pre-enquiry campaign prospect joining dealer, region, enquiry, booking, and invoice data for the Detail CSV report | Form (WHEN-BUTTON-PRESSED trigger) -> MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN, MULDMS.RH_ENQ, MULDMS.RD_ENQ, MULDMS.GM_CITY, MULDMS.GM_MOD, AM_LIST, MULDMS.SH_ORDBOOK, MULDMS.SH_INVOICE -> query string passed to VIEW_EXCEL_REPORT_NEW | Handled by VIEW_EXCEL_REPORT_NEW delivery function; file transfer errors produce a failure message |
| Pre-Enquiry Summary Report Query | SELECT (read-only) | Aggregates pre-enquiry campaign records by region, dealer, and campaign, returning follow-up outcome counts for the Summary CSV report | Form (WHEN-BUTTON-PRESSED trigger) -> MULDMS.PRE_ENQ_CAMPAIGN, MULDMS.AM_DEALER_LOC, MULDMS.GM_REGN -> query string passed to VIEW_EXCEL_REPORT_NEW | Handled by VIEW_EXCEL_REPORT_NEW delivery function; file transfer errors produce a failure message |
| Report Server Configuration Lookup | SELECT (read-only) | Looks up the report server address configured for the current principal and application ID to determine the CSV delivery path | VIEW_EXCEL_REPORT_NEW -> EH_REPORTS -> server address returned; if no row found, default to Forms record-group path | On NO_DATA_FOUND, report server address defaults to NULL and the Forms record-group delivery path is used |
| Oracle Database Session Registration | CALL (DBMS_APPLICATION_INFO) | Registers and clears the form module name and client info against the current Oracle database session for operational monitoring | Form (PRE-FORM trigger) -> DBMS_APPLICATION_INFO.SET_CLIENT_INFO / SET_MODULE -> session metadata updated in Oracle | No error handling; calls are fire-and-forget |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS Report Server (server-side CSV generation path) | Server-side procedure call via database link | Generates the CSV output file on the server when a report server is configured for the principal | Database link procedure call (`sp_csv_report_generate@dms1_db3_lnk`) | Server-side UTL directory (`/utl_dir/`) for output; reports printer directory (`/iashome/ias/reports/printer/`) for delivery | Query and filename sent; generated CSV written to server directory | On failure: error output variables returned from the called procedure; VIEW_EXCEL_REPORT_NEW surfaces a failure message to the user |
| Oracle WebUtil Client File Transfer | File transfer (server to client) | Transfers the generated CSV report file from the application server to the user's client computer | WebUtil (WebUtil_File_Transfer.Url_To_Client) | Server URL constructed from base URL in `excelpath.txt` configuration file + filename | CSV file downloaded to the user's specified local path | If transfer fails: failure message displayed to the user and processing pauses |
| Client Operating System File Open | Host OS command | Opens the downloaded CSV file on the user's computer automatically after transfer | HOST command (`cmd /c <filename>`) | Local file path on user's computer | CSV file opened using the default application on the client OS | No explicit error handling in the form; failure to open would be silently ignored |
| Excel Path Configuration File | File read (server-side) | Reads the base download URL for report file delivery from a server-side configuration file | Server-side text file read (TEXT_IO) | `/reports/DMS/excelpath.txt` on the application server | Base URL string read and used to construct the full download URL | On read error: VIEW_EXCEL_REPORT_NEW exception handler surfaces the SQL error code and message |

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | INFERRED - report server address read from EH_REPORTS at runtime using principal map code and application ID | zone_cd, region_cd, dealer_map_cd, parent_group, loc_cd, campaign_code, from_date, to_date, principal_map_cd, app_id, output_filename | CSV (comma-separated values, delivered as .csv file) | WHEN-BUTTON-PRESSED on the Submit Report button (CB_BLK.SUBMIT); report generation delegated to VIEW_EXCEL_REPORT_NEW from the DMS_EXCEL_REPORT attached library |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the RR_PRE_ENQ form.

### 21.1 Catalogue Index

65 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-002](#SP-002--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-004](#SP-004--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-005](#SP-005--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-006](#SP-006--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-007](#SP-007--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-008](#SP-008--GENERAL.L_POP_LIST_ITEM) | GENERAL.L_POP_LIST_ITEM |
| [SP-009](#SP-009--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-010](#SP-010--WEBUTIL.ADD_PARAMETER) | WEBUTIL.ADD_PARAMETER |
| [SP-011](#SP-011--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-013](#SP-013--WEBUTIL.CREATE_PARAMETER_LIST) | WEBUTIL.CREATE_PARAMETER_LIST |
| [SP-014](#SP-014--WEBUTIL.DESTROY_PARAMETER_LIST) | WEBUTIL.DESTROY_PARAMETER_LIST |
| [SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-016](#SP-016--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-017](#SP-017--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-018](#SP-018--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-019](#SP-019--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-020](#SP-020--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-021](#SP-021--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-022](#SP-022--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-023](#SP-023--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-025](#SP-025--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-026](#SP-026--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-027](#SP-027--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-028](#SP-028--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-029](#SP-029--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-030](#SP-030--WEBUTIL.GET_PARAMETER_STRING) | WEBUTIL.GET_PARAMETER_STRING |
| [SP-031](#SP-031--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-032](#SP-032--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-033](#SP-033--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-034](#SP-034--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-035](#SP-035--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-036](#SP-036--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-037](#SP-037--WEBUTIL.INVOKE_INT) | WEBUTIL.INVOKE_INT |
| [SP-038](#SP-038--WEBUTIL.INVOKE_INTEGRAL) | WEBUTIL.INVOKE_INTEGRAL |
| [SP-039](#SP-039--WEBUTIL.INVOKE_WU) | WEBUTIL.INVOKE_WU |
| [SP-040](#SP-040--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-041](#SP-041--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-042](#SP-042--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-043](#SP-043--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-045](#SP-045--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-046](#SP-046--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-050](#SP-050--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-051](#SP-051--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-052](#SP-052--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-053](#SP-053--ADD_ERROR) | ADD_ERROR |
| [SP-054](#SP-054--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-055](#SP-055--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-056](#SP-056--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-057](#SP-057--DEBUGLOG) | DEBUGLOG |
| [SP-058](#SP-058--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-059](#SP-059--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-060](#SP-060--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-061](#SP-061--READ_REGISTRY) | READ_REGISTRY |
| [SP-062](#SP-062--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-063](#SP-063--SF_COPYRIGHT_DECLARATION) | SF_COPYRIGHT_DECLARATION |
| [SP-064](#SP-064--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-065](#SP-065--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |

---

### 21.2 Detailed Specifications

#### SP-001 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the operating-system file-chooser dialog to the user so that they can select or specify a file path. The function resolves well-known directory tokens (`$WINDIR$`, `$TEMP$`) to real paths, normalises the initial directory, prepares the file-filter and separator character, then delegates to the native `d2kwutil_ChooseFile` API call. The chosen file path is returned to the caller via the `szBuffer` IN OUT parameter together with a return code.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-055](#SP-055--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-004](#SP-004--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-057](#SP-057--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-059](#SP-059--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-060](#SP-060--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log the input arguments at debug level 99 via `Win_API_Debug.DebugLog` so that all call-time parameters are traceable.
- Step 2 - Clear any previously accumulated error state by calling `Win_API.Clean_Error_Stack`.
- Step 3 - Determine the owner window handle: if the dialog is to be modal, retrieve the currently active window handle via `win_api_utility.get_active_window`; otherwise set the owner handle to zero (non-modal).
- Step 4 - Verify that the Win32 API layer is available (`Win_API.API_ENABLED`); if not, raise `WIN_API.NOT_AVAILABLE`.
- Step 5 - Register the native `d2kwutil_ChooseFile` function entry point with the Win32 API dispatch layer.
- Step 6 - Map the `CalledBy` string to a numeric mode flag: `'Open_File'` maps to `1` (open); any other caller maps to `2` (save).
- Step 7 - Copy the dialog title and the flags integer into their respective buffer variables.
- Step 8 - Resolve the initial directory token: if `szInitDir` equals `'$WINDIR$'` (case-insensitive), substitute the real Windows directory; if it equals `'$TEMP$'`, substitute the real temporary directory; otherwise use the value as supplied.
- Step 9 - Ensure the resolved directory path ends with a backslash (`\`), appending one if necessary.
- Step 10 - Set the file-filter string: if `szFileFilter` is NULL or empty, default to `'All files(*.*)|*.*|'`; otherwise use the supplied value.
- Step 11 - Extract only the first character of `SepChar` to use as the multi-file separator.
- Step 12 - Right-pad `szBuffer` to 4096 characters with `CHR(0)` to create the correctly sized output buffer for the native call.
- Step 13 - Invoke the native `d2kwutil_ChooseFile` function with all prepared arguments and capture the integer return code.
- Step 14 - Log the result (return code and resulting buffer content) at debug level 99.
- Step 15 - Write the returned buffer value back into `szBuffer` and return the integer return code to the caller.
- Step 16 - On `WIN_API.NOT_AVAILABLE`: record an error via `Win_API.Add_error` using the `NoAPI` message and re-raise the exception.
- Step 17 - On any other exception: record an error via `Win_API.Add_error` with the unhandled-error message concatenated with `Win_API.Add_External_errors` detail, and re-raise.

---

**Decision Points**

DP-001

Condition:
The `Modal` flag is TRUE.

TRUE:
Retrieve the handle of the currently active window and use it as the owner window for the dialog, making the dialog modal.

FALSE:
Set the owner window handle to zero, resulting in a non-modal (unowned) dialog.

DP-002

Condition:
`Win_API.API_ENABLED` evaluates to TRUE.

TRUE:
Proceed with registering the native function and presenting the file-chooser dialog.

FALSE:
Raise `WIN_API.NOT_AVAILABLE`, triggering the exception handler which records an error and re-raises.

DP-003

Condition:
`CalledBy` equals the literal string `'Open_File'`.

TRUE:
Set the mode flag (`iBuff1`) to `1`, indicating an Open File dialog.

FALSE:
Set the mode flag (`iBuff1`) to `2`, indicating a Save File dialog.

DP-004

Condition:
`szInitDir` (upper-cased) equals `'$WINDIR$'`.

TRUE:
Substitute the real Windows directory path obtained from `win_api_environment.get_windows_directory`.

FALSE:
Check whether `szInitDir` equals `'$TEMP$'` (see DP-005).

DP-005

Condition:
`szInitDir` (upper-cased) equals `'$TEMP$'` (evaluated only when DP-004 is FALSE).

TRUE:
Substitute the real temporary directory path obtained from `win_api_environment.get_temp_directory`.

FALSE:
Use `szInitDir` as supplied by the caller.

DP-006

Condition:
The last character of the resolved directory path is not a backslash (`\`).

TRUE:
Append a backslash to the resolved directory path.

FALSE:
Leave the directory path unchanged.

DP-007

Condition:
`szFileFilter` is NULL or an empty string.

TRUE:
Use the default file-filter string `'All files(*.*)|*.*|'`.

FALSE:
Use the caller-supplied `szFileFilter` value.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The file-chooser dialog may only be invoked when the Win32 API layer is available (`Win_API.API_ENABLED`); if the layer is unavailable the function refuses to proceed and raises `WIN_API.NOT_AVAILABLE`.
- SBR-002 - The dialog mode is determined exclusively by the `CalledBy` string: the value `'Open_File'` produces an Open-File dialog; any other value produces a Save-File dialog.
- SBR-003 - The well-known token `$WINDIR$` in the initial directory parameter is always resolved to the actual Windows system directory at runtime; the token `$TEMP$` is always resolved to the actual temporary directory.
- SBR-004 - The resolved initial directory path must always end with a backslash; if it does not, one is appended automatically.
- SBR-005 - When no file filter is specified (NULL or empty string), the dialog displays all files (`All files(*.*)|*.*|`) by default.
- SBR-006 - The output buffer passed to the native API is always exactly 4096 characters, right-padded with null characters (`CHR(0)`).
- SBR-007 - Only the first character of the `SepChar` parameter is used as the multi-file path separator.

---

**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-002 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the low-level foreign-function interface (FFI) declaration for the native `d2kwutil_ActiveWin` C function in the D2KWUTIL client-side shared library. When invoked through ORA_FFI, it returns the Windows HWND handle of the currently active window on the client, which higher-level wrappers such as `Get_Active_Window` use to obtain a valid owner-window handle for dialog positioning.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No PL/SQL body is available for this routine - only its specification/declaration exists in the source. The function is an FFI stub whose execution is performed entirely by the native C library at runtime.

---

**Decision Points**

No business-significant decision points in this routine - implementation body not present in the available source.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - This function is a specification-only FFI declaration; it accepts only an ORA_FFI function handle and delegates all active-window retrieval to the underlying native C implementation.

---

**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides the low-level foreign-function interface (FFI) declaration for the native `d2kwutil_ChooseFile` C function residing in the D2KWUTIL client-side shared library. This specification-only entry point is called by higher-level PL/SQL wrappers to display a standard OS file-chooser dialog (open or save), returning the selected file path(s) in the output buffer.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

No PL/SQL body is available for this routine - only its specification/declaration exists in the source. The function is an FFI stub whose execution is performed entirely by the native C library at runtime.

---

**Decision Points**

No business-significant decision points in this routine - implementation body not present in the available source.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - This function is a specification-only FFI declaration; all dialog behaviour (dialog type, title, initial directory, file filter, multi-select separator, and result buffer) is controlled by the IN/IN OUT parameters passed by the calling PL/SQL wrapper - the stub itself enforces no independent business rules.

---

**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-004 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle (HWND) of the currently active window on the client machine by invoking the native `d2kwutil_ActiveWin` C function through the Win API FFI layer. The handle is returned as an integer and can be used by other D2KWUTIL routines (e.g. to parent file dialogs). If the Win API is unavailable or no active window handle is obtainable, the function records an error and - depending on the `RaiseExceptions` flag - either raises an exception or returns zero.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-055](#SP-055--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-002](#SP-002--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-057](#SP-057--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry at debug level 99, recording the `RaiseExceptions` flag value as a string.
- Step 2 - Clear the Win API error stack to ensure no stale errors from previous calls contaminate the result.
- Step 3 - Check whether the Win API is available (`WIN_API.API_ENABLED`). If not, raise the `WIN_API.NOT_AVAILABLE` exception immediately.
- Step 4 - Register the FFI function call binding for `d2kwutil_ActiveWin` (return type `INT`, no parameters) against the stored function handle `iActiveWin`.
- Step 5 - Invoke the native `d2kwutil_ActiveWin` function via the registered handle and store the returned integer as the candidate active-window handle.
- Step 6 - Log the result at debug level 99.
- Step 7 - If the returned handle is zero (no active window was found), record an error message `'Unable to obtain active window handle'`. If `RaiseExceptions` is `TRUE`, raise `NO_DATA_FOUND`; otherwise continue and return zero.
- Step 8 - Return the active-window handle integer to the caller.
- Step 9 - In the exception handler: re-raise `NO_DATA_FOUND` as-is; for `WIN_API.NOT_AVAILABLE`, record the no-API error message and re-raise; for all other exceptions, record a generic error message (appending any external error details) and re-raise.

---

**Decision Points**

DP-001

Condition:
`WIN_API.API_ENABLED` is `TRUE` - the Win API FFI layer is available on this client.

TRUE:
Proceed to register and invoke the native function.

FALSE:
Raise `WIN_API.NOT_AVAILABLE` immediately - no further processing is attempted.

DP-002

Condition:
The return value from `d2kwutil_ActiveWin` is zero (no active window handle could be obtained).

TRUE:
Record an error. If `RaiseExceptions` is `TRUE`, raise `NO_DATA_FOUND`; otherwise return zero to the caller.

FALSE:
Return the non-zero window handle to the caller.

DP-003

Condition:
`RaiseExceptions` is `TRUE` when the returned handle is zero.

TRUE:
Raise `NO_DATA_FOUND` so the caller can handle the absence of an active window.

FALSE:
Return zero silently - no exception is propagated.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The Win API FFI layer must be enabled before this function can retrieve a window handle; if it is not, execution is aborted with `WIN_API.NOT_AVAILABLE`.
- SBR-002 - A return value of zero from the native call is treated as a failure (no active window); the error is always logged, and exception propagation is controlled by the `RaiseExceptions` parameter.
- SBR-003 - All exceptions (including unexpected ones) are caught, logged with error detail, and re-raised - no error is silently swallowed.

---

**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-005 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows "Save File As" dialog to the user, pre-populated with a suggested filename, title, starting directory, and file-type filter, and returns the file path chosen by the user, or NULL (or an exception) if the user cancels without selecting a file.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-001](#SP-001--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the returned-file variable with the suggested filename (`SampleName`), which pre-populates the dialog's filename field.
- Step 2 - Initialise the local return-code variable `iLRC` to 0.
- Step 3 - Invoke `choosefile` with the operation label `'Save_File'`, modality flag, dialog title, starting directory, file filter, advanced flags, a space as the multi-select separator, and the filename variable passed by reference.
- Step 4 - Evaluate the return code from `choosefile`: if it equals 1, the user did not select a file (dialog was cancelled or dismissed without a selection).
- Step 5 - If no file was selected (`iLRC = 1`), record an error `'No file was selected'`; if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND` to propagate the cancellation to the caller.
- Step 6 - If a file was selected (`iLRC ≠ 1`), return the file path string populated by `choosefile`.

---

**Decision Points**

DP-001

Condition:
The return code from `choosefile` equals 1 (no file was selected by the user).

TRUE:
Log the error `'No file was selected'`; if `RaiseExceptions` is TRUE, raise `NO_DATA_FOUND` - otherwise the function ends without an explicit return, yielding NULL.

FALSE:
Return the file path string chosen by the user.

DP-002

Condition:
`RaiseExceptions` is TRUE (evaluated only when no file was selected).

TRUE:
Raise `NO_DATA_FOUND` to signal cancellation to the caller.

FALSE:
Allow the function to exit without returning a value (implicit NULL return), letting the caller handle the missing selection silently.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The suggested filename (`SampleName`) is used as the pre-filled filename in the Save dialog; the user may accept or change it.
- SBR-002 - A return code of 1 from `choosefile` unambiguously means no file was selected; the routine treats this as a reportable condition regardless of the `RaiseExceptions` setting.
- SBR-003 - The caller controls whether a cancelled or empty file selection raises an exception (`RaiseExceptions => TRUE`) or returns NULL silently (`RaiseExceptions => FALSE`).
- SBR-004 - The default starting directory token `'$WINDIR$'` instructs the dialog to open in the Windows directory when no explicit directory is provided by the caller.

---

**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-006 - GENERAL.ASK_CONFIRM

**Invoked From:**

- rr_pre_enq_fmb.xml [Trigger: FT_CANCEL]
- rr_pre_enq_fmb.xml [Trigger: FT_DEL]

---

**Screen:**

N/A

---

**Purpose**

Presents a configurable confirmation alert to the user and returns a numeric flag indicating which button was pressed, allowing callers such as the Cancel and Delete triggers to determine whether the user consented to the requested action before proceeding.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the message text of the `AL_CONFIRM` alert to the caller-supplied confirmation message.
- Step 2 - Display the alert to the user and capture which button was pressed.
- Step 3 - If the user pressed the first button (`ALERT_BUTTON1`), return `1` to signal confirmation.
- Step 4 - If the user pressed any other button, return `0` to signal rejection.

---

**Decision Points**

DP-001

Condition:
The user pressed `ALERT_BUTTON1` on the displayed confirmation alert.

TRUE:
Return `1` - the calling trigger treats this as user consent and proceeds with the action (cancel or delete).

FALSE:
Return `0` - the calling trigger treats this as user refusal and does not proceed with the action.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Only a press of the first alert button constitutes a positive confirmation; all other button presses (including dismissal) are treated as rejection.
- SBR-002 - The confirmation message displayed to the user is entirely caller-supplied, making this routine reusable across the Cancel and Delete flows without hard-coded text.

---

**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-007 - GENERAL.DISP_TEXT

**Invoked From:**

- rr_pre_enq_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- rr_pre_enq_fmb.xml [Trigger: FT_INSERT]
- rr_pre_enq_fmb.xml [Trigger: ON-ERROR]
- rr_pre_enq_fmb.xml [Trigger: ON-MESSAGE]
- rr_pre_enq_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

N/A

---

**Purpose**

Displays a message to the user via a modal alert dialog, routing the alert to either an error-style (`AL_ERRINFO`) or a note-style (`AL_NOTE`) alert based on the supplied title, so that error notifications and informational messages are visually distinguished.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Examine the supplied title string (case-insensitively) to determine the appropriate alert type.
- Step 2 - If the title is `ERROR`, select the `AL_ERRINFO` alert; otherwise select the `AL_NOTE` alert.
- Step 3 - Set the selected alert's title property to the supplied title string.
- Step 4 - Set the selected alert's message text property to the supplied text string.
- Step 5 - Display the alert to the user and wait for acknowledgement.

---

**Decision Points**

DP-001

Condition:
The `title_string` parameter, converted to upper case, equals `'ERROR'`.

TRUE:
Use the `AL_ERRINFO` alert, which presents the message with error-level styling.

FALSE:
Use the `AL_NOTE` alert, which presents the message with informational/note-level styling.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A title of `ERROR` (case-insensitive) exclusively selects the error-style alert (`AL_ERRINFO`); any other title value results in the note-style alert (`AL_NOTE`).
- SBR-002 - Both the alert title and message text are set dynamically from caller-supplied values, making this a general-purpose display utility reusable across all form triggers and program units.

---

**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-008 - GENERAL.L_POP_LIST_ITEM

**Invoked From:**

- rr_pre_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Builds or rebuilds a named record group from a caller-supplied SQL query at form initialisation time, ensuring that any stale version of the group is replaced before the new query results are loaded into it.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate an existing record group with the supplied name using `Find_Group`.
- Step 2 - If a group with that name already exists (i.e. the returned ID is not null), delete it to prevent duplicate or stale data.
- Step 3 - Create a new record group from the caller-supplied SQL query using `Create_Group_From_Query`.
- Step 4 - Populate the newly created record group by executing the query with `Populate_Group`.

---

**Decision Points**

DP-001

Condition:
A record group with the supplied name already exists in the form (the ID returned by `Find_Group` is not null).

TRUE:
Delete the existing record group before creating a fresh one, avoiding duplicate group errors.

FALSE:
No deletion is needed; proceed directly to creating the new record group from the query.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A record group of the same name must not exist when a new one is created; any pre-existing group with that name is deleted before the new group is built.
- SBR-002 - The record group is always populated from the caller-supplied SQL query (`p_select`), so the data content is fully determined by the caller.

---

**Implementation Logic**

```plsql

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	END IF;
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-009 - GENERAL.RAISE_ERROR

**Invoked From:**

- rr_pre_enq_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Receives a message code from the ON-ERROR trigger, constructs a display string from the code and any associated message text, and routes the notification to the appropriate alert style (error, note, or caution) - halting form processing with `FORM_TRIGGER_FAILURE` when the severity is `Error`.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-007](#SP-007--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Construct the display text by concatenating the message code, a separator, and any message text (note: the `GENERAL.get_message` call that would populate `mesg_text` is commented out, so `mesg_text` remains `NULL` at runtime and the display string is effectively `<mesg_code> : `).
- Step 2 - Evaluate the message type (`mesg_type`) to determine severity.
- Step 3 - If the type is `'E'` (Error), set the title to `'Error'`, display the message via `GENERAL.DISP_TEXT`, and raise `FORM_TRIGGER_FAILURE` to halt form processing.
- Step 4 - If the type is `'N'` (Note), set the title to `'Note'` and display the message via `GENERAL.DISP_TEXT` without halting.
- Step 5 - If the type is `'C'` (Caution), set the title to `'Caution'` and display the message via `GENERAL.DISP_TEXT` without halting.
- Step 6 - If the type matches none of the above, the routine exits without displaying anything.

---

**Decision Points**

DP-001

Condition:
The message type (`mesg_type`) equals `'E'`.

TRUE:
Display the message with title `'Error'` via `GENERAL.DISP_TEXT` and raise `FORM_TRIGGER_FAILURE`, aborting the current form operation.

FALSE:
Proceed to check whether the type is `'N'`.

DP-002

Condition:
The message type (`mesg_type`) equals `'N'`.

TRUE:
Display the message with title `'Note'` via `GENERAL.DISP_TEXT`; processing continues normally.

FALSE:
Proceed to check whether the type is `'C'`.

DP-003

Condition:
The message type (`mesg_type`) equals `'C'`.

TRUE:
Display the message with title `'Caution'` via `GENERAL.DISP_TEXT`; processing continues normally.

FALSE:
No display action is taken; the routine exits silently.

---

**Database Interactions**

- DB-001 - Read am_permissions - referenced only within the commented-out `check_rights` procedure block; this access does not execute at runtime.

---

**Business Rules**

- SBR-001 - Error-severity messages (`mesg_type = 'E'`) always raise `FORM_TRIGGER_FAILURE` after display, ensuring the form's current operation is aborted.
- SBR-002 - Note-severity (`'N'`) and Caution-severity (`'C'`) messages are displayed but do not halt form processing.
- SBR-003 - The `GENERAL.get_message` lookup that would resolve a message code to human-readable text is commented out; consequently `mesg_text` is always `NULL` at runtime and only the raw message code is shown to the user.

---

**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-010 - WEBUTIL.ADD_PARAMETER

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a single output parameter into an existing WebUtil parameter list, communicating its type and direction to the underlying Java bean via the WebUtil Core property mechanism, and returns a handle that callers use to retrieve the parameter's value after a function is invoked.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| paramList | ParameterList | IN |
| parameterType | PLS_INTEGER | IN |
| inOut | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the `inOut` direction flag to determine whether this is an output parameter.
- Step 2 - If the direction is `PARAM_OUT`, encode the parameter descriptor as a pipe-delimited string (`'B|<listHandle>|<type>|<direction>'`) and pass it to the WebUtil Core bean via the `WUL_PARAM_PROPERTIES` property, signalling a bind operation.
- Step 3 - Retrieve the newly assigned parameter handle number from the bean via the `WUL_ADD_PARAMETER` property and store it in the returned `ParameterHandle`.
- Step 4 - Return the `ParameterHandle` to the caller for later value retrieval.
- Step 5 - If the direction is not `PARAM_OUT`, raise `INVALID_PARAM_EXCEPTION` to signal an unsupported parameter direction.
- Step 6 - On `INVALID_PARAM_EXCEPTION`, log error code 923 against `WEBUTIL_C_API.ADD_PARAMETER` via `WebUtil_Core.Error` and then raise `FORM_TRIGGER_FAILURE` to abort the current trigger.

---

**Decision Points**

DP-001

Condition:
The `inOut` parameter equals the constant `PARAM_OUT`.

TRUE:
Register the parameter with the WebUtil bean and return a handle for subsequent value retrieval.

FALSE:
Raise `INVALID_PARAM_EXCEPTION`; the caller receives an error and trigger processing is halted.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Only output-direction parameters (`PARAM_OUT`) are accepted; any other direction raises an error and aborts trigger execution.
- SBR-002 - A parameter is bound to its parent parameter list by handle; the list handle, parameter type, and direction are all encoded together in the bind descriptor sent to the bean.

---

**Implementation Logic**

```plsql
  FUNCTION ADD_PARAMETER (paramList IN ParameterList, parameterType IN PLS_INTEGER, 
                         inOut IN PLS_INTEGER := PARAM_OUT) RETURN ParameterHandle IS
    paramHnd ParameterHandle;
  BEGIN
    if inOut = PARAM_OUT then
      WebUtil_Core.SetProperty(WebUtil_Core.WUL_PACKAGE,'WUL_PARAM_PROPERTIES',
                               'B|'                   -- indicate Bind
                                || TO_CHAR(paramList.hnd) || '|'
                                || TO_CHAR(parameterType) || '|'
                                || TO_CHAR(inOut),
                               false);
      paramHnd.hnd := TO_NUMBER(WebUtil_Core.GetProperty(WebUtil_Core.WUL_PACKAGE,'WUL_ADD_PARAMETER'));
      RETURN paramHnd;
    else
      raise INVALID_PARAM_EXCEPTION;
    end if;
  exception
    when INVALID_PARAM_EXCEPTION then
      WebUtil_Core.Error(Webutil_Core.WUL_PACKAGE,923, 'WEBUTIL_C_API.ADD_PARAMETER');
    RAISE FORM_TRIGGER_FAILURE;  
  END ADD_PARAMETER;
```

#### SP-011 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the form waits for the command to complete before returning control to the caller, and returns the process identifier of the launched process.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-019](#SP-019--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Delegate execution to `WEBUTIL.EXECUTE`, passing the supplied command string and the constant `BLOCKING_MODE` as the execution mode.
- Step 2 - Return the `PROCESS_ID` value received back from `WEBUTIL.EXECUTE` to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The command is always dispatched with `BLOCKING_MODE`, so the form does not regain control until the host process has finished; non-blocking execution is not an option through this entry point.

---

**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-012 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.RELEASE_PROCESS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using its numeric key, so that the callback is no longer invoked when the associated asynchronous process completes.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether an entry with the supplied `callbackKey` exists in the `m_callbacks` collection.
- Step 2 - If the entry exists, delete it from the collection to deregister the callback.
- Step 3 - If the entry does not exist, take no action and return silently.

---

**Decision Points**

DP-001

Condition:
An entry with the supplied `callbackKey` exists in the `m_callbacks` collection.

TRUE:
Delete the entry, deregistering the callback so it will no longer fire.

FALSE:
No action is taken; the routine exits without error.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The deletion is guarded by an existence check; attempting to clear a non-existent callback key is a no-op and does not raise an error.

---

**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-013 - WEBUTIL.CREATE_PARAMETER_LIST

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Creates a new, empty WebUtil parameter list on the client-side Java bean and returns a handle to it, so that callers can subsequently add parameters and invoke external functions with them. It also increments the module-level count of active parameter lists.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Request a new parameter list handle from the WebUtil bean by reading the `WUL_CREATE_PARAMLIST` property via `WebUtil_Core.getProperty`.
- Step 2 - Validate the returned handle string; if it is null or empty, raise `TOOL_ERR.TOOL_ERROR` to signal that the bean could not allocate a list.
- Step 3 - Convert the string handle to a number and store it in the `ParameterList` record's `hnd` field.
- Step 4 - Increment the module-level parameter list counter (`m_paramListCount`) to track the number of active lists.
- Step 5 - Return the populated `ParameterList` handle to the caller.
- Step 6 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing bean class and raise `FORM_TRIGGER_FAILURE` to abort the trigger.
- Step 7 - On `PROPERTY_ERROR`, raise `FORM_TRIGGER_FAILURE` to abort the trigger.
- Step 8 - On `VALUE_ERROR` (numeric conversion failure), raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
The handle string returned by the bean is null or empty.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` - the parameter list cannot be used.

FALSE:
Convert the handle to a number, increment the active-list counter, and return the handle to the caller.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A parameter list is only considered valid when the bean returns a non-null, non-empty handle string; an empty or null response is treated as a hard error.
- SBR-002 - Every successfully created parameter list increments the module-level active-list counter (`m_paramListCount`), keeping the count consistent with subsequent destroy operations.

---

**Implementation Logic**

```plsql

  FUNCTION CREATE_PARAMETER_LIST RETURN ParameterList IS
    paramListHandle ParameterList;
    strHnd VARCHAR2(8);
  BEGIN
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_CREATE_PARAMLIST');

    if (strHnd is null) or (strHnd = '') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
    
    paramListHandle.hnd := TO_NUMBER (strHnd);
    m_paramListCount := m_paramListCount + 1;
    
    RETURN paramListHandle;

EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                            ||' bean not found. WEBUTIL_C_API.CREATE_PARAMETER_LIST will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;  
  when VALUE_ERROR then
    RAISE TOOL_ERR.TOOL_ERROR; 
END CREATE_PARAMETER_LIST;

/*
** For Out only parameters, we don't need to pass any value. If we intend to pass
** a maximum length value for strings, we can call 3rd prototype by passing null for
** the string value and a desired length.
**/
```

#### SP-014 - WEBUTIL.DESTROY_PARAMETER_LIST

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously created WebUtil parameter list on the client-side Java bean and decrements the module-level active-list counter, ensuring that resources allocated during a function-invocation sequence are freed after use.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| paramList | ParameterList | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Send the parameter list handle to the WebUtil bean by setting the `WUL_DESTROY_PARAMLIST` property with the handle's numeric identifier converted to a string.
- Step 2 - Decrement the module-level active parameter list counter (`m_paramListCount`) to reflect the released list.
- Step 3 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing bean class and raise `FORM_TRIGGER_FAILURE` to abort the trigger.
- Step 4 - On `PROPERTY_ERROR`, raise `FORM_TRIGGER_FAILURE` to abort the trigger.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Every destroyed parameter list decrements the module-level active-list counter (`m_paramListCount`), keeping it in step with creation operations.

---

**Implementation Logic**

```plsql

  PROCEDURE DESTROY_PARAMETER_LIST (paramList IN ParameterList) IS
  BEGIN
    WebUtil_Core.SetProperty(WebUtil_Core.WUL_PACKAGE,'WUL_DESTROY_PARAMLIST', TO_CHAR(paramList.hnd),false);
    m_paramListCount := m_paramListCount - 1;

  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.DESTROY_PARAMETER_LIST will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END DESTROY_PARAMETER_LIST;
```

#### SP-015 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified entry point for downloading a file from a URL to a local client path, delegating to the full internal implementation (`DOWNLOADFROMURLINT`) with a fixed set of defaults: no special destination, no progress dialog, and using the caller-supplied file size hint.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-016](#SP-016--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call `DOWNLOADFROMURLINT` with the supplied `sourceURL`, `clientDestination`, and `fileSize`, passing fixed default values: `specialDestination = 0`, `withProgress = false`, and all progress label parameters as `null`.
- Step 2 - Return the boolean result from `DOWNLOADFROMURLINT` directly to the caller - `TRUE` if the download succeeded, `FALSE` otherwise.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - This entry point always disables the progress dialog and uses no special destination; callers requiring a progress indicator or a special client destination must invoke `DOWNLOADFROMURLINT` directly.

---

**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-016 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Performs the full URL-to-client file download by assembling a pipe-delimited parameter string and dispatching it to the WebUtil client-side bean; validates that both source URL and client destination are provided, applies safe defaults for optional parameters, and returns a boolean indicating whether the download succeeded.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-017](#SP-017--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Raise the `URL_NULL` exception if `sourceURL` is null; raise `CLIENT_FILE_NULL` if `clientDestination` is null.
- Step 2 - Determine the special-destination segment: if `specialDestination` is null, negative, or greater than 2, default to `'0'`; otherwise use its string representation.
- Step 3 - Determine the file-size segment: if `fileSize` is null, default to `'0'`; otherwise use its string representation.
- Step 4 - Determine the progress-indicator segment: if `withProgress` is null or false, append `'N'`; if true, append `'Y'`.
- Step 5 - Concatenate the full submit string in the required pipe-delimited order: `specialDestination | fileSize | withProgress | sourceURL | clientDestination | progressTitle | progressSubTitle | progressMessage` (substituting a single space for any null progress label).
- Step 6 - Send the submit string to the WebUtil client-core bean by setting the `WUC_URL_DOWNLOAD` property.
- Step 7 - Read back the `WUC_URL_DOWNLOAD` property from the bean to obtain the download result string.
- Step 8 - Return `TRUE` if the result equals `'TRUE'`, otherwise `FALSE`.
- Step 9 - On `CLIENT_FILE_NULL`, call `WebUtil_Core.Error` with error code 130 and return `FALSE`.
- Step 10 - On `URL_NULL`, call `WebUtil_Core.Error` with error code 25 and return `FALSE`.
- Step 11 - On `BEAN_NOT_REGISTERED`, display an error alert naming the missing bean and raise `FORM_TRIGGER_FAILURE`.
- Step 12 - On `PROPERTY_ERROR`, raise `FORM_TRIGGER_FAILURE`.

---

**Decision Points**

DP-001

Condition:
`sourceURL` is null.

TRUE:
Raise the `URL_NULL` exception, which causes error code 25 to be reported and the function to return `FALSE`.

FALSE:
Proceed to check `clientDestination`.

DP-002

Condition:
`clientDestination` is null.

TRUE:
Raise the `CLIENT_FILE_NULL` exception, which causes error code 130 to be reported and the function to return `FALSE`.

FALSE:
Proceed to build the submit string.

DP-003

Condition:
`specialDestination` is null, less than 0, or greater than 2.

TRUE:
Use `'0'` as the special-destination segment (standard/default destination).

FALSE:
Use the numeric value of `specialDestination` as the segment.

DP-004

Condition:
`fileSize` is null.

TRUE:
Use `'0'` as the file-size segment.

FALSE:
Use the numeric value of `fileSize` as the segment.

DP-005

Condition:
`withProgress` is null or false.

TRUE:
Append `'N'` to suppress the progress dialog.

FALSE:
Append `'Y'` to display a progress dialog during the download.

DP-006

Condition:
The WebUtil client-core bean (`WUC_PACKAGE`) is registered and available.

TRUE:
The bean processes the download; the result string is read back and the function returns `TRUE` or `FALSE` accordingly.

FALSE:
`BEAN_NOT_REGISTERED` is caught; an error alert is shown and `FORM_TRIGGER_FAILURE` is raised.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A non-null source URL is mandatory; omitting it raises error code 25 and aborts the download.
- SBR-002 - A non-null client destination path is mandatory; omitting it raises error code 130 and aborts the download.
- SBR-003 - The `specialDestination` value must be in the range 0-2; any out-of-range or null value is silently replaced with `0`.
- SBR-004 - Null progress label strings (`progressTitle`, `progressSubTitle`, `progressMessage`) are substituted with a single space before submission to avoid null segments in the pipe-delimited string.
- SBR-005 - If the WebUtil client bean is unavailable, processing is halted via `FORM_TRIGGER_FAILURE` rather than returning a false success indicator.

---

**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-017 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURLINT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, the calling program unit name, and up to three optional argument values, then stores it as the `WUC_ERROR_MSG` property on the specified WebUtil package bean so that the error can be retrieved and surfaced by the framework.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Build the base error text by concatenating the literal `'ERROR'`, the error code zero-padded to three digits, a pipe separator, and the calling program unit name.
- Step 2 - If `arg1` is not null, append a pipe separator followed by `arg1` to the error text.
- Step 3 - If `arg2` is not null, append a pipe separator followed by `arg2` to the error text.
- Step 4 - If `arg3` is not null, append a pipe separator followed by `arg3` to the error text.
- Step 5 - Set the `WUC_ERROR_MSG` property on the identified WebUtil bean (`packageID`) to the assembled error text string.

---

**Decision Points**

DP-001

Condition:
`arg1` is not null.

TRUE:
Append `'|' || arg1` to the error text string.

FALSE:
Leave the error text unchanged; `arg1` is omitted from the message.

DP-002

Condition:
`arg2` is not null.

TRUE:
Append `'|' || arg2` to the error text string.

FALSE:
Leave the error text unchanged; `arg2` is omitted from the message.

DP-003

Condition:
`arg3` is not null.

TRUE:
Append `'|' || arg3` to the error text string.

FALSE:
Leave the error text unchanged; `arg3` is omitted from the message.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The error code is always zero-padded to three digits in the message string (e.g. error 25 becomes `ERROR025`), providing a consistent fixed-width identifier regardless of the numeric value.
- SBR-002 - Optional arguments (`arg1`, `arg2`, `arg3`) are included in the message only when non-null; null arguments are silently omitted rather than included as blank segments.
- SBR-003 - The assembled error message is written to the WebUtil bean's `WUC_ERROR_MSG` property and is not displayed directly to the user from this routine; display is the responsibility of the calling framework layer.

---

**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-018 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user using the pre-configured error alert dialog when one is available, or falls back to the standard Forms `message` call when it is not. This ensures that WebUtil internal errors are always surfaced to the user regardless of whether the alert object has been initialised.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the module-level error alert handle `m_errorAlert` is valid (non-null) by calling `ID_NULL`.
- Step 2 - If the alert handle is valid, set the alert's message text property to `errText` and display the alert modal dialog via `SHOW_ALERT`; the return value is discarded.
- Step 3 - If the alert handle is null (alert not yet initialised), display the error text using the standard Forms `message` built-in, prefixed with `'WebUtil Error: '`.

---

**Decision Points**

DP-001

Condition:
The module-level error alert handle `m_errorAlert` is NOT null (i.e., `ID_NULL(m_errorAlert)` returns FALSE).

TRUE:
Set the alert message text to `errText` and display the pre-configured error alert dialog.

FALSE:
Fall back to the Forms `message` built-in to display the error, prefixed with `'WebUtil Error: '`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The error alert dialog is used only when the `m_errorAlert` handle has been initialised; if it has not, the procedure degrades gracefully to a standard Forms status-bar message rather than failing silently.
- SBR-002 - The return value of `SHOW_ALERT` is intentionally discarded; the procedure does not act on which button the user pressed.

---

**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-019 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sends a host command to the WebUtil client-side bean for execution using a caller-specified mode (blocking or non-blocking), and returns the resulting process handle; if the command is null, no action is taken and a null process ID is returned.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local `PROCESS_ID` variable to hold the result.
- Step 2 - Check whether the supplied command is non-null; if null, skip all execution steps and return the uninitialised process ID.
- Step 3 - Set the `WUH_EXECUTION_MODE` property on the WebUtil Host bean to the supplied execution mode.
- Step 4 - Set the `WUH_EXECUTE` property on the WebUtil Host bean to the supplied command, triggering client-side execution.
- Step 5 - Read back the `WUH_EXECUTE` property (which now contains the process handle assigned by the client) and convert it to a number, storing it in `procId.handle`.
- Step 6 - Return `procId` to the caller.
- Step 7 - If the WebUtil bean is not registered on the client, catch the `BEAN_NOT_REGISTERED` exception, display an error alert naming the missing bean, and exit without returning a valid process ID.

---

**Decision Points**

DP-001

Condition:
The `cmd` parameter is not null.

TRUE:
Set the execution mode and command properties on the WebUtil Host bean, then retrieve and return the process handle.

FALSE:
Skip all bean interaction and return an uninitialised `PROCESS_ID` to the caller.

DP-002

Condition:
The WebUtil Host bean (`WUH_PACKAGE`) is registered and available on the client.

TRUE:
Bean properties are set and read successfully; a valid process handle is returned.

FALSE:
`BEAN_NOT_REGISTERED` exception is raised; an error alert is shown informing that the bean was not found and `WEBUTIL_HOST.Execute` will not work.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - If the command string is null, no host execution is attempted and the function returns without error.
- SBR-002 - If the WebUtil Host bean is not available on the client, the failure is reported via an error alert rather than silently ignored, and no process handle is returned.

---

**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-020 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by instructing the WebUtil Java bean to release the underlying file handle, then nullifies the handle reference in the PL/SQL file object so that callers cannot reuse a stale handle.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| file | file_type | IN OUT |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| file | file_type | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the file handle held in the `file` parameter is non-NULL, indicating that the file is currently open.
- Step 2 - If the handle is non-NULL, instruct the WebUtil Java bean (via `WebUtil_Core.setProperty`) to close the file on the client side by passing the `WUF_TEXTIO_CLOSE` property together with the current handle value.
- Step 3 - Nullify the handle field of the `file` object so the caller's reference can no longer be used to perform further I/O operations.
- Step 4 - If the WebUtil bean is not registered on the client, raise a user-facing error alert identifying the missing bean class, then propagate `TOOL_ERR.TOOL_ERROR` to the caller.
- Step 5 - If the bean raises a property-level error during the close operation, propagate `TOOL_ERR.TOOL_ERROR` to the caller.

---

**Decision Points**

DP-001

Condition:
The `file.handle` value is NOT NULL - i.e. the file object represents an open file.

TRUE:
Send the close instruction to the WebUtil bean and nullify the handle so subsequent I/O attempts are blocked.

FALSE:
Skip the close entirely - no interaction with the WebUtil bean is attempted, and the procedure returns silently.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A close operation is only attempted when the file handle is non-NULL; calling `FCLOSE` on an already-closed or never-opened file object is silently ignored.
- SBR-002 - After a successful close, the handle is forcibly set to NULL, preventing any further read or write operations on the same file object without re-opening the file.
- SBR-003 - If the WebUtil bean is unavailable, a descriptive error alert is presented to the user and a `TOOL_ERROR` exception is raised, halting the current operation.

---

**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-021 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the user with a client-side "Save File" dialog and returns the file path chosen by the user. It delegates entirely to `FILE_SELECTION_DIALOG_INT`, fixing the dialog type to `SAVE_FILE`, enabling file selection, and disabling multi-select.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-005](#SP-005--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-022](#SP-022--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the caller-supplied initial directory, default file name, file-type filter, and dialog title.
- Step 2 - Invoke `FILE_SELECTION_DIALOG_INT` with the dialog type hardcoded to `SAVE_FILE`, `select_file` set to `TRUE`, and `multiselect` set to `FALSE`, ensuring the dialog is configured as a single-file save prompt.
- Step 3 - Return the file path string produced by `FILE_SELECTION_DIALOG_INT` directly to the caller (this is the path the user typed or selected in the dialog, or NULL if the user cancelled).

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The dialog is always opened in save mode (`SAVE_FILE`); it is never opened as an open-file or directory-browse dialog.
- SBR-002 - Only a single file path may be returned; multi-selection is explicitly disabled (`multiselect = FALSE`).

---

**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-022 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a client-side file-chooser dialog (save, open-file, or open-directory) to the user via the WebUtil Java bean, then normalises the returned path by collapsing any double-backslash sequences that the Java `JFileChooser` component may produce, and returns the selected path to the caller.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-005](#SP-005--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Pass the initial directory, default file name, file-type filter, dialog title, and multi-select flag to the WebUtil bean by setting the corresponding `WUF_GFN_*` and `WUF_FILTER` properties.
- Step 2 - Determine which dialog variant to invoke based on `dialog_type` and `select_file`:
  - If `dialog_type = SAVE_FILE`, retrieve the user's chosen path using the `WUF_GFN_SAVEFILE` property.
  - Else if `select_file` is FALSE, retrieve the user's chosen directory using the `WUF_GFN_OPENDIR` property.
  - Otherwise, retrieve the user's chosen file path using the `WUF_GFN_OPENFILE` property.
- Step 3 - Search the returned path string for a leading `\\` sequence (double backslash at position 1), which the Java `JFileChooser` can emit on Windows UNC paths.
- Step 4 - If the path starts with `\\`, prepend an additional `\\` to the result string before applying the global replace, preserving the UNC prefix.
- Step 5 - Replace all remaining occurrences of `\\` (escaped backslash) with a single `\` to produce a normalised Windows-style file path.
- Step 6 - Return the normalised path string to the caller. If the user cancelled the dialog, the underlying bean returns NULL or an empty string, which is passed through unchanged.
- Step 7 - If the WebUtil bean is not registered, display an error alert identifying the missing class and raise `FORM_TRIGGER_FAILURE`.
- Step 8 - If a property-level error occurs during dialog interaction, raise `FORM_TRIGGER_FAILURE`.

---

**Decision Points**

DP-001

Condition:
`dialog_type` equals the `SAVE_FILE` constant.

TRUE:
The bean is asked to display a Save-File dialog and the result is read from the `WUF_GFN_SAVEFILE` property.

FALSE:
Proceed to the next condition to distinguish between an open-file and an open-directory dialog.

DP-002

Condition:
`select_file` is FALSE (i.e. the caller wants a directory, not a file).

TRUE:
The bean is asked to display an Open-Directory dialog and the result is read from the `WUF_GFN_OPENDIR` property.

FALSE:
The bean is asked to display an Open-File dialog and the result is read from the `WUF_GFN_OPENFILE` property.

DP-003

Condition:
The returned path string starts with `\\` (double backslash at character position 1).

TRUE:
Prepend `\\` to the result before applying the global backslash-collapse replacement, so that the leading UNC path marker is preserved.

FALSE:
Apply the global backslash-collapse replacement directly to the result without prepending.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The dialog type must be one of: save-file (`SAVE_FILE`), open-directory (when `select_file = FALSE`), or open-file; no other dialog modes are supported.
- SBR-002 - Multi-select behaviour is controlled entirely by the `multiselect` parameter passed to the bean; the function itself does not impose a further restriction.
- SBR-003 - Any `\\` sequence in the returned path is collapsed to a single `\` to produce a valid local file-system path, with special handling to preserve leading UNC double-backslash prefixes.

---

**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-023 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file in the specified access mode (read, write, or append) via the WebUtil Java bean and returns a file handle object that subsequent I/O routines use to identify the open file. Input validation ensures that only a legal mode and a non-empty file path are accepted before the open is attempted.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that `filemode` (case-insensitively) is one of `r` (read), `w` (write), or `a` (append); raise `TOOL_ERR.TOOL_ERROR` immediately if not.
- Step 2 - Validate that `spec` (the file path) is neither NULL nor an empty string; raise `TOOL_ERR.TOOL_ERROR` immediately if it is.
- Step 3 - Pass the file path and the file mode to the WebUtil bean by setting the `WUF_FILENAME` and `WUF_TEXTIO_FILEMODE` properties.
- Step 4 - Set the character-set property: if `charSet` is NULL, send the literal string `'(null)'` to the bean to indicate the platform default; otherwise send the supplied charset name.
- Step 5 - Trigger the file-open operation on the client side by reading the `WUF_TEXTIO_OPEN` property from the bean, which returns a Java-side file handle identifier.
- Step 6 - Validate the returned handle: if it is NULL, empty, or the sentinel value `'-1'`, the file could not be opened - raise `TOOL_ERR.TOOL_ERROR`.
- Step 7 - Convert the returned string handle to a numeric value, store it in `clientFile.handle`, and return the `clientFile` object to the caller.
- Step 8 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing class and raise `TOOL_ERR.TOOL_ERROR`.
- Step 9 - On `PROPERTY_ERROR`, re-raise the exception as-is.
- Step 10 - On `VALUE_ERROR` (e.g. non-numeric handle string), raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
`filemode` (lower-cased) is one of the allowed values: `r`, `w`, or `a`.

TRUE:
Continue to validate the file path.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately - the file open is not attempted.

DP-002

Condition:
`spec` is non-NULL and non-empty.

TRUE:
Continue to configure and execute the file-open operation via the WebUtil bean.

FALSE:
Raise `TOOL_ERR.TOOL_ERROR` immediately - no file path has been provided.

DP-003

Condition:
`charSet` is NULL.

TRUE:
Send the literal `'(null)'` to the bean, instructing it to use the platform default character set.

FALSE:
Send the caller-supplied charset name to the bean.

DP-004

Condition:
The handle returned by the bean is NULL, empty, or equal to `'-1'`.

TRUE:
The file could not be opened on the client side - raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Convert the string handle to a number, populate the `clientFile` record, and return it to the caller.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Only `r` (read), `w` (write), and `a` (append) are valid file modes; any other value is rejected before any client-side operation is attempted.
- SBR-002 - A non-NULL, non-empty file path (`spec`) is mandatory; attempting to open an unnamed file is an error.
- SBR-003 - A handle value of NULL, empty string, or `'-1'` returned by the bean is treated as a failed open and causes an immediate error, preventing the caller from receiving an unusable file object.
- SBR-004 - When no character set is specified, the platform default encoding is used, communicated to the bean via the sentinel value `'(null)'`.

---

**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-024 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the client operating system family identifier that was detected and stored when the WebUtil session was initialised, allowing calling routines to choose the correct platform-specific code path without repeating the OS detection logic.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Return the value of the package-level variable `m_clientOSFamily` directly to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The OS family value is read-only within this function; it reflects whatever was set during package initialisation and is not recalculated on each call.

---

**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-025 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resolves the fully qualified Java class name for a given WebUtil package identifier by prepending the common WebUtil Java root namespace to the package-specific class suffix stored in the internal `m_implClasses` lookup array.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Use `packageID` as an index into the `m_implClasses` associative array to retrieve the class-name suffix for the requested WebUtil package.
- Step 2 - Concatenate the shared `WEBUTIL_JAVA_ROOT` prefix with the retrieved suffix to form the fully qualified Java class name.
- Step 3 - Return the fully qualified class name string to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The fully qualified Java class name is constructed by combining the shared `WEBUTIL_JAVA_ROOT` root namespace with the per-package class suffix; neither component is modified at runtime.

---

**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-026 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads all available output lines from a named output channel of a host process via the WebUtil Core bean interface, collecting them into an array that is returned to the caller. It handles multi-line output by looping until the bean signals no more data, and raises a descriptive alert if the required WebUtil bean is not registered.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-035](#SP-035--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Register the process handle with WebUtil Core by setting the `WUH_PROC_ID` property on the host package, so subsequent bean calls are scoped to the correct process.
- Step 2 - Enter a loop that repeatedly calls `WebUtil_Core.getProperty` for the requested output channel (`prop`), retrieving one buffered line at a time.
- Step 3 - Inspect the first character of the returned buffer as a status flag: `Y` means more lines follow; `N` means this is the last line; `X` means the buffer was empty (no data returned yet).
- Step 4 - If the status is `Y` or `N` (i.e., not `X`), extract the content portion (all characters after the first) and append it to the output array.
- Step 5 - Continue the loop until the status is not `Y` (i.e., the last line `N` has been read, or the buffer was empty `X`), then return the collected array.
- Step 6 - If a `BEAN_NOT_REGISTERED` exception is raised at any point, present an error alert identifying the missing bean class and explain that `WEBUTIL_HOST.GetOutput` will not work.

---

**Decision Points**

DP-001

Condition:
The status character from the bean buffer is not `X` (i.e., the buffer contains a real output line, either with more following (`Y`) or as the last line (`N`)).

TRUE:
Extract the line content and append it to the output array.

FALSE:
Skip appending - the buffer returned no data for this iteration.

DP-002

Condition:
The status character is `Y` (more lines still pending from the host process output channel).

TRUE:
Continue the loop to retrieve the next line.

FALSE:
Exit the loop (status is `N` or `X`), terminating line collection and returning the accumulated array.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Each call to the bean's `getProperty` delivers at most one output line at a time; collecting all lines requires looping until a non-`Y` status is returned.
- SBR-002 - Lines with a status of `X` (empty buffer) are silently discarded and do not contribute an entry to the output array.
- SBR-003 - If the WebUtil Host bean is not registered in the form, the function cannot retrieve output; an error alert is raised and no array is returned.

---

**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-027 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named Java system property from the client JVM by invoking `java.lang.System.getProperty` via the Oracle Forms JNI bridge, and returns the value as a VARCHAR2 string.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list for one argument using `JNI.CREATE_ARG_LIST(1)`.
- Step 2 - Add the property name (`a0`) as a String argument to the argument list.
- Step 3 - Call `java.lang.System.getProperty(String)` on the client JVM via `JNI.CALL_STRING_METHOD`, passing the prepared argument list.
- Step 4 - Return the string value of the property to the caller (NULL if the property does not exist in the client JVM).

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The property lookup is performed against the client JVM's system properties (`java.lang.System`); server-side properties are not accessible through this function.

---

**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-028 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named environment or configuration variable on the client machine, using a platform-specific strategy: Windows Registry and then Windows environment lookup on Win32 clients, a Unix `env` command parse on Unix/Linux clients, and no action on Mac or unknown platforms.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-058](#SP-058--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-061](#SP-061--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-024](#SP-024--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-032](#SP-032--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Determine the client operating system family by calling `WebUtil_Core.GetClientOSFamily`.
- Step 2 - **Win32 path:** First attempt to read the variable from the Windows Registry under `HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE` using `Client_Win_API_Environment.read_registry`.
- Step 3 - If the registry lookup returns null or an empty string, fall back to reading the variable from the Windows environment using `CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING`.
- Step 4 - **Mac / Unknown path:** Take no action; leave `VARVALUE` unchanged (the procedure does nothing for these platforms).
- Step 5 - **Unix path:** Execute the `env` command as a blocking host process via `WebUtil_HOST.Blocking`, capturing standard output into `unixOutput`.
- Step 6 - Release the host process handle after capturing output.
- Step 7 - Iterate over each line of the `env` output; for each line that contains `=`, split it into key and value at the first `=` position.
- Step 8 - If the parsed key matches `VARNAME`, assign the corresponding value to `VARVALUE` and exit the loop immediately.
- Step 9 - On `NO_DATA_FOUND` exception (from any branch), set `VARVALUE` to `NULL`.

---

**Decision Points**

DP-001

Condition:
The client OS family is Win32 (`WebUtil_Core.CLIENT_PLATFORM_WIN32`).

TRUE:
Attempt to read the variable from the Windows Registry; if that yields nothing, attempt to read from the Windows environment variables.

FALSE:
Check whether the platform is Mac or Unknown.

DP-002

Condition:
The Windows Registry lookup returns a non-null, non-empty value.

TRUE:
Use the registry value as `VARVALUE`; no environment variable lookup is performed.

FALSE:
Fall back to `CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING` to retrieve the value from the Windows environment.

DP-003

Condition:
The client OS family is Mac (`CLIENT_PLATFORM_MAC`) or Unknown (`CLIENT_PLATFORM_UNKNOWN`).

TRUE:
Do nothing - `VARVALUE` is left unchanged.

FALSE:
Treat the platform as Unix and execute `env` to enumerate environment variables.

DP-004

Condition:
A line from the Unix `env` output contains an `=` character and the key portion matches `VARNAME`.

TRUE:
Set `VARVALUE` to the value portion of that line and exit the loop.

FALSE:
Continue iterating through the remaining `env` output lines.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - On Win32, the Windows Registry (`HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE`) is the primary source for the variable value; the Windows environment is only consulted if the registry yields nothing.
- SBR-002 - On Mac and Unknown platforms, the procedure deliberately takes no action and makes no attempt to resolve the variable.
- SBR-003 - On Unix/Linux, the variable value is resolved by running the `env` shell command on the client and parsing its output, not by any direct API call.
- SBR-004 - A `NO_DATA_FOUND` exception from any lookup path causes `VARVALUE` to be set to `NULL` rather than propagating the exception to the caller.

---

**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-029 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads the next line of text from an open client-side file identified by a file handle, returning the line content to the caller. A bare newline character returned by the WebUtil Java bean is treated as the end-of-file sentinel and causes a `NO_DATA_FOUND` exception, signalling to the caller that no more lines are available.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| file | file_type | IN |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-025](#SP-025--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-027](#SP-027--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-050](#SP-050--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Send the numeric file handle to the WebUtil bean by setting the `WUF_TEXTIO_HANDLE` property, identifying which open file to read from.
- Step 2 - Retrieve the next line of text from the client-side file by reading the `WUF_TEXTIO_GETLINE` property from the bean; the result is stored in the local `buffer` variable.
- Step 3 - Inspect the returned buffer: if it equals a single newline character (`CHR(10)`), this is the bean's end-of-file signal - raise `NO_DATA_FOUND` to inform the caller that all lines have been read.
- Step 4 - If the buffer is any value other than `CHR(10)`, assign it to the `item` OUT parameter and return normally.
- Step 5 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing class and raise `TOOL_ERR.TOOL_ERROR`.
- Step 6 - On `PROPERTY_ERROR`, raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
The value returned by the bean in `buffer` equals `CHR(10)` (a lone newline character).

TRUE:
The end of file has been reached - raise `NO_DATA_FOUND` so the caller can terminate its read loop.

FALSE:
A valid line of text was read - assign the buffer contents to the `item` OUT parameter and return.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A lone newline character (`CHR(10)`) returned by the WebUtil bean is the agreed end-of-file sentinel; it is never passed back to the caller as data.
- SBR-002 - End-of-file is communicated to the caller exclusively via `NO_DATA_FOUND`, consistent with the Oracle `UTL_FILE` reading convention, allowing callers to use the same exception-based loop pattern.

---

**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-030 - WEBUTIL.GET_PARAMETER_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the string value of a specific output parameter from a WebUtil parameter list after a client-side function has been invoked, allowing the form to read back data (such as a directory path) that was populated by the external call.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| paramList | ParameterList | IN |
| param | ParameterHandle | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Encode a fetch descriptor as a pipe-delimited string (`'F|<listHandle>|<paramHandle>'`) and send it to the WebUtil bean via the `WUL_PARAM_PROPERTIES` property, signalling a fetch operation.
- Step 2 - Read the parameter's string value back from the bean via the `WUL_PARAM_VALUE` property.
- Step 3 - Return the retrieved string value to the caller.
- Step 4 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing bean class and raise `FORM_TRIGGER_FAILURE` to abort the trigger.
- Step 5 - On `PROPERTY_ERROR`, raise `FORM_TRIGGER_FAILURE` to abort the trigger.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The Java interface is responsible for ensuring that the returned string does not exceed the 32 767-character maximum; this routine relies on that guarantee without performing its own length check.

---

**Implementation Logic**

```plsql

  FUNCTION GET_PARAMETER_STRING (paramList IN ParameterList, param IN ParameterHandle) RETURN VARCHAR2 IS
    paramVal VARCHAR2(32767);
  BEGIN
    -- Note: It is up to the Java interface to guarantee sending back a string that is shorter than strmaxlen
    WebUtil_Core.SetProperty(WebUtil_Core.WUL_PACKAGE,'WUL_PARAM_PROPERTIES', 'F|'                   -- indicate Fetch
                                                                              || TO_CHAR(paramList.hnd) || '|'
                                                                              || TO_CHAR(param.hnd),false);
    paramVal := WebUtil_Core.GetProperty(WebUtil_Core.WUL_PACKAGE,'WUL_PARAM_VALUE');
    
    RETURN paramVal;

  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REBIND_PARAMETER will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END GET_PARAMETER_STRING;
```

#### SP-031 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the exit/return code of a previously launched client-side operating system process by querying the WebUtil host-process bean, allowing the caller to determine whether the process completed successfully or with an error.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the process handle to the WebUtil host-process bean by setting the `WUH_PROC_ID` property on the `WUH_PACKAGE` bean.
- Step 2 - Read the process exit code from the bean by getting the `WUH_RC` (return code) property, which the bean populates once the process has completed.
- Step 3 - Convert the string return-code value to a `PLS_INTEGER` and return it to the caller.
- Step 4 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing class; no exception is re-raised (the function implicitly returns NULL to the caller in this case).

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The process whose return code is being queried must have been previously started via the WebUtil host-process bean; the `process.handle` value is used to identify it.
- SBR-002 - If the WebUtil bean is unavailable, an error alert is shown but no exception is propagated, meaning the caller will receive NULL rather than a numeric return code.

---

**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-032 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) lines produced by a previously launched host process by delegating to the generic `GetOutput` function with the fixed property key `WUH_STDOUT`.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-026](#SP-026--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept a `PROCESS_ID` handle identifying the host process whose stdout lines are to be retrieved.
- Step 2 - Delegate immediately to `GetOutput`, passing the supplied process handle and the hard-coded property key `WUH_STDOUT`, and return the resulting `OUTPUT_ARRAY` of captured output lines to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Standard output is always retrieved using the fixed channel identifier `WUH_STDOUT`; callers cannot specify an alternative output channel through this function.

---

**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-033 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a client-side operating system command synchronously, waits for it to complete, captures its return code, releases the associated process object, and returns the exit code to the caller so downstream logic can determine whether the command succeeded.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-011](#SP-011--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-031](#SP-031--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-049](#SP-049--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Launch the supplied command string on the client operating system and wait for it to finish by calling `Blocking(cmd)`, which returns a `PROCESS_ID` handle representing the completed process.
- Step 2 - Check whether the returned process ID is valid (non-null) using `ID_NULL(procId)`.
- Step 3 - If the process ID is valid, retrieve the process's exit (return) code by calling `Get_Return_Code(procId)` and store it in the local `RC` variable.
- Step 4 - Release the client-side process object by calling `Release_Process(procId)`, freeing any resources held by the WebUtil bean for this process.
- Step 5 - Return the captured return code (`RC`) to the caller. If the process ID was null (i.e. the command could not be launched), return the default value of `-1`.

---

**Decision Points**

DP-001

Condition:
`ID_NULL(procId)` returns FALSE - the process was successfully launched and a valid process handle was obtained.

TRUE:
Retrieve the process return code and release the process object before returning the code to the caller.

FALSE:
Skip return-code retrieval and process release; return `-1` to signal that the command could not be executed.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The command is always executed in blocking mode via `Blocking`; the function does not return until the client-side process has terminated.
- SBR-002 - A default return code of `-1` is used when the process handle is null, indicating a launch failure to the caller.
- SBR-003 - Every successfully launched process must be released via `Release_Process` after its return code is read, to avoid resource leaks on the client side.

---

**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-034 - WEBUTIL.ID_NULL

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.INVOKE_WU]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil object handle is uninitialised (null), returning TRUE if the handle's internal `hnd` attribute is null and FALSE if it holds a valid reference. This utility function is used by callers to guard against operating on unregistered or uninitialised WebUtil handles before invoking operations that require them.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the `hnd` attribute of the supplied `handle` pointer object.
- Step 2 - If `handle.hnd` is null, return TRUE (the handle is uninitialised); otherwise return FALSE (the handle references a valid object).

---

**Decision Points**

DP-001

Condition:
`handle.hnd` is NULL.

TRUE:
Return TRUE - the handle is considered uninitialised and the caller should not attempt to use it.

FALSE:
Return FALSE - the handle holds a valid reference and may be used safely.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Handle validity is determined solely by whether the `hnd` attribute of the `Pointer` record type is null; no other attribute or external state is consulted.

---

**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-035 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a public, no-op initialisation entry point for the `WEBUTIL_CORE` package. Entering the package body is sufficient to trigger the package initialisation block (which calls `InitWebUtil`); this procedure exists as a named hook that callers can invoke explicitly when they wish to ensure the package is instantiated.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-036](#SP-036--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Execute a `NULL` statement - the procedure body intentionally performs no work, because simply entering (instantiating) the `WEBUTIL_CORE` package body triggers the package initialisation block, which calls `InitWebUtil` automatically.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The actual WebUtil initialisation is performed by the package initialisation block (`BEGIN ... END`), not by this procedure body; `Init` is a deliberate no-op that exists solely to give callers a named entry point that guarantees package instantiation.

---

**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-036 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil framework at form startup by registering the implementation class names for every WebUtil sub-package, verifying that the required WebUtil object group (and its error alert) is present in the current form, optionally navigating to the hidden bean-container item and triggering bean initialisation, and detecting the server operating system to configure the appropriate file-path separator character.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-051](#SP-051--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field position (`SYSTEM.CURSOR_FIELD`) and locate the WebUtil dummy item handle, so the form can return focus correctly after bean initialisation.
- Step 2 - Populate the internal implementation-class registry (`m_implClasses`) with the Java bean class name for each of the ten WebUtil sub-packages (Common, FileTransfer, FileFunctions, ClientInfo, Host, Session, BrowserFunctions, OleFunctions, and CApiFunctions).
- Step 3 - Check whether the WebUtil error alert object is available in this form (using `id_null`). If it is absent, display a message warning the developer that the `WEBUTIL` object group is missing and pause execution - WebUtil cannot function without it.
- Step 4 - If the error alert is present and the `FLAG_EXPICIT_INSTANCIATE` flag is enabled and the form is in `NORMAL` mode (not Enter-Query mode), attempt explicit bean instantiation.
- Step 5 - Within that branch, confirm the dummy item exists (i.e., the standard WebUtil object group is in use). If so, navigate to the dummy item to force the bean container to render.
- Step 6 - Determine whether the dummy item resides in the same block as the original cursor position. If yes, move to the next block; if no, return focus to the original item. Then call `ShowBeans(false)` to hide the transient bean window.
- Step 7 - If the dummy item does not exist, take no action (the developer is managing bean setup independently).
- Step 8 - Determine the server operating system from `GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)`. If the OS name contains `WIN`, set the server file-path separator to `\`; otherwise set it to `/`.

---

**Decision Points**

DP-001

Condition:
The WebUtil error alert object is null (absent) in this form - the `WEBUTIL` object group has not been included.

TRUE:
Display an error message to the developer that WebUtil cannot operate, then pause. No further initialisation steps are executed.

FALSE:
Proceed with bean instantiation and OS detection.

DP-002

Condition:
`FLAG_EXPICIT_INSTANCIATE` is `TRUE` and the form is currently in `NORMAL` mode (not Enter-Query mode).

TRUE:
Attempt explicit bean instantiation by navigating to the WebUtil dummy item.

FALSE:
Skip explicit bean instantiation; proceed directly to OS detection.

DP-003

Condition:
The WebUtil dummy item handle is not null (the standard WebUtil object group is present in the form).

TRUE:
Navigate to the dummy item to trigger bean rendering, restore focus, and call `ShowBeans(false)`.

FALSE:
Do nothing - assume the developer has implemented their own bean setup.

DP-004

Condition:
After navigating to the dummy item, the dummy item's block name is the same as the original cursor item's block name.

TRUE:
Move to the next block so focus leaves the dummy item's block cleanly.

FALSE:
Return focus directly to the original cursor item.

DP-005

Condition:
The server operating system name (from `GET_APPLICATION_PROPERTY`) contains the string `WIN`.

TRUE:
Set the server file-path separator to `\` (backslash, Windows convention).

FALSE:
Set the server file-path separator to `/` (forward slash, Unix/Linux convention).

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The `WEBUTIL` object group (containing the error alert and bean items) must be present in any form that uses WebUtil; absence blocks all WebUtil functionality.
- SBR-002 - Explicit bean instantiation (`FLAG_EXPICIT_INSTANCIATE`) is suppressed when the form is in Enter-Query mode to avoid navigation side-effects.
- SBR-003 - The server file-path separator is determined once at initialisation time based on the server OS, and applies to all subsequent server-side file path operations in the session.

---

**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-037 - WEBUTIL.INVOKE_INT

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Invokes a registered client-side function and returns its integer result by delegating to `INVOKE_INTEGRAL` with the fixed return-type constant `c_int`, providing a convenience wrapper that spares callers from specifying the return type explicitly.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| funcHandle | FunctionHandle | IN |
| paramList | ParameterList | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INVOKE_INTEGRAL ([SP-038](#SP-038--WEBUTIL.INVOKE_INTEGRAL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Forward the function handle, parameter list, and the hard-coded integer return-type constant `c_int` to `INVOKE_INTEGRAL`.
- Step 2 - Return the `PLS_INTEGER` result produced by `INVOKE_INTEGRAL` directly to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The return type of the external function call is fixed to the integer constant `c_int`; callers of `INVOKE_INT` cannot override the return type.

---

**Implementation Logic**

```plsql

  FUNCTION INVOKE_INT (funcHandle IN FunctionHandle, paramList ParameterList) RETURN PLS_INTEGER IS
  BEGIN
    RETURN INVOKE_INTEGRAL (funcHandle, paramList, c_int);
  END INVOKE_INT;
```

#### SP-038 - WEBUTIL.INVOKE_INTEGRAL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INVOKE_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Bridges the generic string-returning `INVOKE_WU` function and integer-typed callers by invoking a registered client-side function through `INVOKE_WU` and converting the raw string result to a `PLS_INTEGER` before returning it.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| funcHandle | FunctionHandle | IN |
| paramList | ParameterList | IN |
| retType | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INVOKE_WU ([SP-039](#SP-039--WEBUTIL.INVOKE_WU)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Call `INVOKE_WU` with the supplied function handle, parameter list, and return-type constant, receiving a `VARCHAR2` result string.
- Step 2 - Convert the result string to a `PLS_INTEGER` using `TO_NUMBER` and return it to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The string value returned by the client-side function must be numeric; `TO_NUMBER` conversion is performed without defensive handling - a non-numeric return value will raise an unhandled exception.

---

**Implementation Logic**

```plsql
  FUNCTION INVOKE_INTEGRAL (funcHandle IN FunctionHandle, paramList ParameterList, retType IN PLS_INTEGER) RETURN PLS_INTEGER IS
  BEGIN
    RETURN TO_NUMBER (INVOKE_WU (funcHandle, paramList, retType));
  END INVOKE_INTEGRAL;
```

#### SP-039 - WEBUTIL.INVOKE_WU

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INVOKE_INTEGRAL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a registered client-side (Windows) function through the WebUtil Java bean by transmitting the function handle, optional parameter list, and expected return type, and returns the function's result as a raw string for the caller to interpret.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| funcHandle | FunctionHandle | IN |
| paramList | ParameterList | IN |
| retType | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Test whether the supplied `paramList` handle is null using `id_null`.
- Step 2 - If the parameter list is null, build the invocation specification as `'<funcHandle>|(null)|<retType>'` and send it to the bean via the `WUL_INVOKE_SPEC` property.
- Step 3 - If the parameter list is not null, build the invocation specification as `'<funcHandle>|<paramListHandle>|<retType>'` and send it to the bean via the `WUL_INVOKE_SPEC` property.
- Step 4 - Retrieve the function's return value from the bean via the `WUL_INVOKE` property.
- Step 5 - Return the raw string result to the caller.
- Step 6 - On `BEAN_NOT_REGISTERED`, display an error alert identifying the missing bean class and raise `FORM_TRIGGER_FAILURE` to abort the trigger.
- Step 7 - On `PROPERTY_ERROR`, raise `FORM_TRIGGER_FAILURE` to abort the trigger.

---

**Decision Points**

DP-001

Condition:
The `paramList` handle is null (as determined by `id_null`).

TRUE:
Encode the literal string `'(null)'` as the parameter list segment of the invocation specification, indicating to the bean that no parameter list is associated with this call.

FALSE:
Encode the numeric parameter list handle in the invocation specification so that the bean uses the pre-populated parameter list when executing the function.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A function invocation may be made without a parameter list; in that case the bean is explicitly notified of the absent list using the literal token `'(null)'`.
- SBR-002 - The invocation specification always encodes the function handle, parameter list reference (or null marker), and the expected return type as a pipe-delimited string; all three components are mandatory.

---

**Implementation Logic**

```plsql
  FUNCTION INVOKE_WU (funcHandle IN FunctionHandle, paramList ParameterList, retType IN PLS_INTEGER) RETURN VARCHAR2 IS
    strResult VARCHAR2(32767);
  BEGIN
    IF id_null(paramList) THEN
      WebUtil_Core.setProperty (WebUtil_Core.WUL_PACKAGE, 'WUL_INVOKE_SPEC', TO_CHAR(funcHandle.hnd) || '|' 
                                                                             || '(null)'                || '|' 
                                                                             || TO_CHAR(retType),false);
    ELSE                                                                             
      WebUtil_Core.setProperty (WebUtil_Core.WUL_PACKAGE, 'WUL_INVOKE_SPEC', TO_CHAR(funcHandle.hnd) || '|' 
                                                                             || TO_CHAR(paramList.hnd)  || '|' 
                                                                             || TO_CHAR(retType), false);
    END IF;                                                                             
      strResult := WebUtil_Core.getProperty (WebUtil_Core.WUL_PACKAGE, 'WUL_INVOKE');
      RETURN strResult;

  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.INVOKE_WU will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  

  END INVOKE_WU;
```

#### SP-040 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reports whether the most recent WebUtil operation produced an error, by testing the module-level last-error code. Callers use this function to determine after a WebUtil call whether an error condition is in effect before deciding how to proceed.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether the module-level variable `m_lastError` is not equal to zero.
- Step 2 - Return TRUE if `m_lastError ≠ 0` (an error is present), or FALSE if `m_lastError = 0` (no error).

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - An error is considered present if and only if `m_lastError` is any value other than zero; a zero value unambiguously indicates a successful (error-free) state.

---

**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-041 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a WebUtil client-side text file is currently open, by checking whether the file handle's internal `handle` attribute holds a non-null value. This allows callers to verify that a file was successfully opened before attempting to read from or write to it.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Inspect the `handle` attribute of the supplied `file` record.
- Step 2 - If `file.handle` is NULL, return FALSE (the file is not open); otherwise return TRUE (the file is open).

---

**Decision Points**

DP-001

Condition:
`file.handle` is NULL.

TRUE:
Return FALSE - the file handle has not been assigned and the file is therefore not open.

FALSE:
Return TRUE - the file handle is set, indicating the file is currently open.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - File open status is determined exclusively by the nullity of the `handle` field within the `file_type` record; no additional external state or OS-level check is performed.

---

**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-042 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- webutil.pld [StoredProcedure: DEBUGLOG]
- webutil.pld [StoredProcedure: STRIPDIRSEP]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java `java.io.File` object, by invoking the native Java method `File.length()` via the JNI bridge. This allows PL/SQL code to determine the size of a file on the client machine without any direct database or file-system access from the server side.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Clear the JNI argument list by setting `args` to `NULL`.
- Step 2 - Invoke the Java `java.io.File.length()` method on the supplied file object via `JNI.CALL_LONG_METHOD`, passing no arguments, and return the resulting numeric byte count to the caller.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The file length is obtained exclusively via the JNI call to `java.io.File.length()`; no server-side or SQL-based file-size mechanism is used.

---

**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-043 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a message to the configured WebUtil server-side log file, subject to logging policy read from a property bundle on the first call. The procedure initialises the logging cache on its first invocation (reading whether logging is enabled, whether errors-only mode is active, and the target file name), propagates the current logging mode to the WebUtil bean, and then appends the message - optionally prefixed with the client IP and username - to the log file. If the log file cannot be opened or written, logging is disabled and an error is reported.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-040](#SP-040--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-041](#SP-041--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-046](#SP-046--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-047](#SP-047--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (`m_loggingAllowed IS NULL`). If not yet initialised, read the three property-bundle keys: `logging.enabled`, `logging.errorsonly`, and `logging.file`, and store them in the module-level cache variables.
- Step 2 - If logging is enabled but no log file name was supplied, disable logging (`m_loggingAllowed := false`) and report the configuration error: if no WebUtil bean has been registered yet, display an alert with message `WUC-008`; otherwise call `WebUtil_Core.setProperty` to set `WUC_SRV_LOGGING` to `'0'` and raise error 8 via `WebUtil_Core.error`.
- Step 3 - If at least one WebUtil bean is registered, set the `WUC_SRV_LOGGING` property to reflect the resolved logging mode: `'1'` for errors-only, `'2'` for all messages, or `'0'` for disabled.
- Step 4 - After initialisation (or on subsequent calls when the cache is already populated), check whether logging is currently allowed; if not, exit without writing.
- Step 5 - Check whether the message should be written: it is written only if errors-only mode is off, or if errors-only mode is on and `isError` is TRUE.
- Step 6 - Open the log file in append mode (`'A'`) via `TEXT_IO.FOPEN`.
- Step 7 - Verify the file opened successfully via `TEXT_IO.IS_OPEN`; if not, raise `NO_DATA_FOUND`.
- Step 8 - If `m_clientIP` is NULL, write the message as-is; otherwise prefix the message with the client IP address and username separated by colons.
- Step 9 - Close the log file via `TEXT_IO.FCLOSE`.
- Step 10 - On `SQLCODE = -302000` (file write error): if no bean is registered, display an alert with message `WUC-007`; otherwise set `WUC_SRV_LOGGING` to `'0'` and raise error 7. In both cases, set `m_loggingAllowed` to `false` so no further write attempts are made. On any other exception, re-raise.

---

**Decision Points**

DP-001

Condition:
`m_loggingAllowed` is NULL (the logging configuration cache has not yet been initialised).

TRUE:
Read the three logging properties from the property bundle and populate the cache; then evaluate whether a valid log file is configured (DP-002).

FALSE:
Skip initialisation and proceed directly to DP-004.

DP-002

Condition:
Logging is enabled (`m_loggingAllowed = TRUE`) but the log file name (`m_loggingFile`) is NULL.

TRUE:
Disable logging and report the missing-file configuration error (WUC-008 via alert if no bean registered, or via `WebUtil_Core.error` if a bean is registered).

FALSE:
Logging remains enabled with a valid file target; proceed to DP-003.

DP-003

Condition:
At least one WebUtil bean package is registered (`m_registeredPackages.FIRST IS NOT NULL`).

TRUE:
Propagate the logging mode to the bean by setting the `WUC_SRV_LOGGING` property to `'1'` (errors-only), `'2'` (all), or `'0'` (disabled) as appropriate.

FALSE:
Skip the bean property update (no bean to notify).

DP-004

Condition:
`m_loggingAllowed` is TRUE after the initialisation phase.

TRUE:
Proceed to check whether the individual message qualifies for logging (DP-005).

FALSE:
Exit without writing any log entry.

DP-005

Condition:
Errors-only mode is inactive (`NOT m_loggingErrorsOnly`) OR errors-only mode is active AND `isError` is TRUE.

TRUE:
Open the log file and write the message.

FALSE:
The message is a non-error in errors-only mode; skip it and exit.

DP-006

Condition:
`m_clientIP` is NULL.

TRUE:
Write the message text alone to the log file (no client identification prefix).

FALSE:
Write the message text prefixed with `<m_clientIP>:<m_clientUserName>: ` to associate the log entry with the originating client session.

DP-007

Condition:
An exception occurs and `SQLCODE` equals `-302000` (file I/O error during write).

TRUE:
Disable logging permanently for this session and report the write failure (WUC-007 via alert or via `WebUtil_Core.error`).

FALSE:
Re-raise the exception for the caller to handle.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The logging configuration (enabled flag, errors-only flag, and file name) is read from the property bundle exactly once per session and cached; subsequent calls use the cached values without re-reading the bundle.
- SBR-002 - If the `logging.enabled` property is `'true'` but `logging.file` is absent or null, logging is automatically disabled and an error is raised to alert the administrator (WUC-008).
- SBR-003 - When errors-only mode is active (`logging.errorsonly = 'true'`), only messages where `isError = TRUE` are written to the file; informational messages are silently discarded.
- SBR-004 - Log entries are appended to the file (not overwritten) and the file is opened and closed for every individual message write, ensuring each write is flushed independently.
- SBR-005 - When the client IP address is known, every log line is prefixed with `<clientIP>:<clientUsername>: ` to provide session-level traceability in a shared log file.
- SBR-006 - A file I/O error (SQLCODE `-302000`) permanently disables logging for the current session (`m_loggingAllowed := false`) and reports error WUC-007; further log write attempts are suppressed to avoid repeated failures.

---

**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-044 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates the WebUtil configuration file from one of three sources (a Forms global variable, a client environment variable, or a Forms parameter), reads every key-value pair from that file into the in-memory property bundle, and returns the value corresponding to the requested property key. Raises a descriptive error alert and sets a permanent error flag if the configuration file cannot be found or read.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-018](#SP-018--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-028](#SP-028--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check the Forms global variable named by `WEBUTIL_CONFIG_GLOBAL` for the configuration file path; default the global to `[NOTSET]` if it has no current value.
- Step 2 - If the global holds `[NOTSET]`, attempt to resolve the configuration file path from the client environment variable named by `WEBUTIL_CONFIG_ENV` via `TOOL_ENV.GETVAR`.
- Step 3 - If the environment variable also yields nothing, fall back to the Forms parameter named by `WEBUTIL_CONFIG_PARAM` via `name_in`.
- Step 4 - If all three sources fail to provide a path, raise `NO_DATA_FOUND` to trigger the error-handling branch.
- Step 5 - Persist the resolved file path back into the Forms global (`WEBUTIL_CONFIG_GLOBAL`) so subsequent calls do not repeat the resolution.
- Step 6 - Open the configuration file for reading using `Text_IO.FOpen`.
- Step 7 - Read the file line by line in a loop. Skip any line whose first character is `#` (comment lines).
- Step 8 - For each non-comment line that contains an `=` character, parse the key (left of `=`, trimmed, lowercased) and value (right of `=`, trimmed, carriage-return characters removed), then store both in the next slot of `m_propertyBundle`.
- Step 9 - While storing each entry, check whether the stored key matches the requested `propertyKey` (case-insensitive); if it does, record the value as the function result.
- Step 10 - After the loop ends, close the configuration file and return the result (which may be `NULL` if the key was not found in the file).
- Step 11 - On `NO_DATA_FOUND` (no config file path found): display error WUC-005 or invoke `Webutil_Core.Error`, set `m_config_error := TRUE`, and return `NULL`.
- Step 12 - On SQL error `-302000` (file unreadable): display error WUC-006 or invoke `Webutil_Core.Error`, set `m_config_error := TRUE`, and return `NULL`. All other exceptions are re-raised.

---

**Decision Points**

DP-001

Condition:
The Forms global variable (`WEBUTIL_CONFIG_GLOBAL`) contains a value other than `[NOTSET]`.

TRUE:
Use that value directly as the configuration file path.

FALSE:
Attempt to read the path from the client environment variable (`WEBUTIL_CONFIG_ENV`).

DP-002

Condition:
The client environment variable (`WEBUTIL_CONFIG_ENV`) yields a non-null file path.

TRUE:
Use that value as the configuration file path.

FALSE:
Fall back to the Forms parameter (`WEBUTIL_CONFIG_PARAM`).

DP-003

Condition:
The Forms parameter (`WEBUTIL_CONFIG_PARAM`) yields a non-null file path.

TRUE:
Use that value as the configuration file path.

FALSE:
Raise `NO_DATA_FOUND` - no configuration file source is available; error handling will fire.

DP-004

Condition:
A line read from the configuration file begins with `#`.

TRUE:
Skip the line entirely (it is a comment).

FALSE:
Proceed to check whether the line contains a `=` separator.

DP-005

Condition:
The current line contains an `=` character (i.e., it is a name=value pair).

TRUE:
Parse the key and value, store them in `m_propertyBundle`, and check whether the key matches the requested `propertyKey`.

FALSE:
Ignore the line and continue reading.

DP-006

Condition:
No WebUtil bean package has been registered yet (`m_registeredPackages.FIRST is null`) at the time an error is raised.

TRUE:
Display the error in plain English using `ErrorAlert` (WUC-005 or WUC-006).

FALSE:
Route the error through `Webutil_Core.Error` for structured error reporting.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The configuration file path is resolved from three sources in strict priority order: Forms global variable first, client environment variable second, Forms parameter third.
- SBR-002 - Once a valid configuration file path is found it is written back to the Forms global variable so the resolution is not repeated on subsequent calls.
- SBR-003 - Lines beginning with `#` are treated as comments and are ignored during parsing.
- SBR-004 - Only lines containing an `=` character are treated as valid key-value pairs; lines without `=` are silently skipped.
- SBR-005 - Property keys are normalised to lowercase and whitespace-trimmed before storage; values are whitespace-trimmed and stripped of carriage-return characters.
- SBR-006 - If the configuration file cannot be located or read, `m_config_error` is set to `TRUE`, permanently suppressing further file-access attempts for the lifetime of the session.

---

**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-045 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating the operation to the WebUtil FILE bean, providing the equivalent of `TEXT_IO.PUTF` for files opened on the client machine.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Pass the file handle to the WebUtil FILE bean by setting the `WUF_TEXTIO_HANDLE` property, identifying which open file is the target of the write operation.
- Step 2 - Pass the text string to be written by setting the `WUF_TEXTIO_PUTF` property on the same bean, which triggers the actual write to the client-side file.
- Step 3 - If the WebUtil FILE bean is not registered, raise an error alert identifying the missing implementation class and re-raise `TOOL_ERR.TOOL_ERROR` to abort the calling routine.
- Step 4 - If a property error occurs during either `setProperty` call, re-raise `TOOL_ERR.TOOL_ERROR` so the caller can handle the failure.

---

**Decision Points**

DP-001

Condition:
The WebUtil FILE bean is registered in the current browser session (no `BEAN_NOT_REGISTERED` exception is raised).

TRUE:
Both properties are set successfully and the text string is written to the client-side file.

FALSE:
An error alert is displayed naming the unregistered implementation class, and `TOOL_ERR.TOOL_ERROR` is raised to the caller.

DP-002

Condition:
Both `setProperty` calls complete without a `PROPERTY_ERROR` exception.

TRUE:
The write operation completes normally.

FALSE:
`TOOL_ERR.TOOL_ERROR` is raised immediately, propagating the failure to the caller without further error messaging.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The file passed to this procedure must already be open; the procedure does not open or validate the file - it relies entirely on the caller to have obtained a valid `file_type` handle.
- SBR-002 - Both a missing WebUtil FILE bean and a property-level error are treated as fatal failures that raise `TOOL_ERR.TOOL_ERROR`, ensuring the calling routine is notified rather than silently losing the write.

---

**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-046 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a line of text to an open WebUtil client-side file by passing the file handle, the text item, and a newline flag to the WebUtil file-I/O bean via property-set calls. If the required WebUtil bean is not registered or a property error occurs, an appropriate error is raised to the caller.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` bean to the file's handle value, directing subsequent I/O operations to the correct open file.
- Step 2 - Set the `WUF_TEXTIO_PUT` property to the text string `item`, which instructs the bean to write that text to the file.
- Step 3 - Set the `WUF_TEXTIO_NEWLINE` property to `1`, instructing the bean to append a newline character after the text.
- Step 4 - On `BEAN_NOT_REGISTERED`: display an error alert indicating that the `CLIENT_TEXT_IO` bean was not found and therefore `put_line` cannot work, then raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation.
- Step 5 - On `PROPERTY_ERROR`: raise `TOOL_ERR.TOOL_ERROR` to abort the calling operation.

---

**Decision Points**

DP-001

Condition:
A `BEAN_NOT_REGISTERED` exception is raised during one of the `setProperty` calls (the `WUF_PACKAGE` bean is not available).

TRUE:
Display an error alert identifying the missing bean class and indicating that `CLIENT_TEXT_IO.put_line` will not work, then raise `TOOL_ERR.TOOL_ERROR` to stop execution.

FALSE:
The bean is available; proceed to write the text line without interruption.

DP-002

Condition:
A `PROPERTY_ERROR` exception is raised during one of the `setProperty` calls.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` to signal the failure to the caller without displaying additional diagnostic information.

FALSE:
The property sets succeeded; the write operation completes normally.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The write operation requires the `WUF_PACKAGE` WebUtil bean to be registered; if it is absent, the procedure refuses to continue and raises `TOOL_ERR.TOOL_ERROR`.
- SBR-002 - Every call to `put_line` always appends a newline character (`WUF_TEXTIO_NEWLINE = 1`) after the text; there is no variant that writes text without a trailing newline.

---

**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-047 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from the in-memory WebUtil configuration property bundle. If the bundle has not yet been loaded into memory it triggers a one-time population from the configuration file before performing the lookup.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-044](#SP-044--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether a prior configuration-file error has already been recorded (`m_config_error`). If so, return `NULL` immediately without any further processing.
- Step 2 - Check whether the in-memory property bundle (`m_propertyBundle`) is currently empty (count = 0). If empty, delegate to `populatePropertyBundle` to load the bundle from disk, passing the requested `propertyKey`; use the value it returns as the result.
- Step 3 - If the bundle is already populated, iterate through each entry in `m_propertyBundle` comparing each stored key (case-insensitively, using `lower()`) against the requested `propertyKey`.
- Step 4 - When a matching key is found, capture its associated value and exit the loop immediately.
- Step 5 - Return the resolved value (or `NULL` if no matching key was found in the bundle).

---

**Decision Points**

DP-001

Condition:
The package-level `m_config_error` flag is TRUE, indicating a previous failure reading the configuration file.

TRUE:
Return `NULL` immediately - no lookup is attempted.

FALSE:
Continue to check whether the in-memory bundle is populated.

DP-002

Condition:
The in-memory property bundle (`m_propertyBundle`) contains zero entries (has never been loaded).

TRUE:
Call `populatePropertyBundle` to load the configuration file and simultaneously resolve the requested key, then return that result.

FALSE:
Iterate through the already-populated bundle to find the matching key.

DP-003

Condition:
A bundle entry's `propertyKey` (lowercased) matches the lowercased `propertyKey` argument.

TRUE:
Capture the matching `propertyValue` and exit the loop.

FALSE:
Continue to the next bundle entry; if the loop ends without a match, return `NULL`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - If a configuration-file error was previously encountered, the routine short-circuits and returns `NULL` rather than re-attempting a failed load.
- SBR-002 - The in-memory property bundle is loaded lazily: it is populated from disk only on the first lookup request when it is empty, then reused for all subsequent calls.
- SBR-003 - Property key comparisons are case-insensitive; all keys are normalised to lowercase before matching.

---

**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-048 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- webutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specific shared library with the WebUtil bean layer, obtains a callable function handle in return, and tracks the total count of successfully registered handles for the current session.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Publish the library and function specification to the WebUtil bean by calling `WebUtil_Core.setProperty` with property name `WUL_FUNCTION_SPEC` and the value formed as `libName || '|' || funcName`.
- Step 2 - Request the registered function handle from the bean by calling `WebUtil_Core.getProperty` with property name `WUL_REGISTER_FUNCTION`; the bean responds with a string representation of the handle.
- Step 3 - Convert the returned string handle to a numeric `FunctionHandle` record (`funcHnd.hnd := TO_NUMBER(strHnd)`).
- Step 4 - Check whether the returned handle is non-null using `ID_NULL`. If it is not null (i.e. registration succeeded), increment the session-level registered-handle counter (`m_funcHandleCount`).
- Step 5 - Return the `FunctionHandle` record to the caller.
- Step 6 - On `BEAN_NOT_REGISTERED` exception: display an alert naming the missing bean implementation class and raise `FORM_TRIGGER_FAILURE`.
- Step 7 - On `PROPERTY_ERROR` exception: raise `FORM_TRIGGER_FAILURE`.
- Step 8 - On `VALUE_ERROR` exception (e.g. the returned handle string cannot be converted to a number): raise `TOOL_ERR.TOOL_ERROR`.

---

**Decision Points**

DP-001

Condition:
`ID_NULL(funcHnd)` returns FALSE - the handle returned by the bean is valid (non-null).

TRUE:
Increment `m_funcHandleCount` to track the new registration.

FALSE:
Do not increment the counter; return the null handle to the caller.

DP-002

Condition:
A `BEAN_NOT_REGISTERED` exception is raised - the required WebUtil bean implementation class is not present.

TRUE:
Display an alert identifying the missing bean class and raise `FORM_TRIGGER_FAILURE` to abort the trigger.

FALSE:
Continue normal processing.

DP-003

Condition:
A `PROPERTY_ERROR` exception is raised during the `setProperty`/`getProperty` exchange.

TRUE:
Raise `FORM_TRIGGER_FAILURE` to abort the trigger.

FALSE:
Continue normal processing.

DP-004

Condition:
A `VALUE_ERROR` exception is raised - the handle string returned by the bean cannot be converted to a number.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR`.

FALSE:
Continue normal processing.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The function specification passed to the bean must be formatted as `libName|funcName` (pipe-delimited); this is the contract expected by the `WUL_FUNCTION_SPEC` property.
- SBR-002 - Only handles that are confirmed non-null contribute to the `m_funcHandleCount` session counter.
- SBR-003 - If the WebUtil bean is not registered at all, the registration attempt raises `FORM_TRIGGER_FAILURE`, preventing any subsequent C API calls from proceeding.

---

**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-049 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases an in-progress HOST process handle once the host command has completed, clearing the associated callback trigger and nullifying the process reference so that it can no longer be reused.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Output | Source | datatype |
|--------|--------|----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-012](#SP-012--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Register the process handle with the WebUtil HOST package by setting the `WUH_CLEAR_PROC` property to the handle value, signalling the bean to release its association with that process.
- Step 2 - Clear the callback trigger registered against the process handle by calling `WebUtil_Core.ClearCallbackTrigger`, so no stale trigger fires after the process ends.
- Step 3 - Null the `process.handle` field in the IN OUT parameter, rendering the caller's reference invalid and preventing accidental reuse.
- Step 4 - If the WebUtil HOST bean is not registered in the browser session, raise an error alert identifying the missing implementation class and exit gracefully without altering the process handle.

---

**Decision Points**

DP-001

Condition:
The WebUtil HOST bean is registered in the current browser session (no `BEAN_NOT_REGISTERED` exception is raised).

TRUE:
The property is set, the callback trigger is cleared, and the process handle is nullified - the release completes successfully.

FALSE:
An error alert is displayed naming the unregistered implementation class, and the procedure exits without modifying the process handle.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A process handle must be explicitly released via this procedure after use; failing to call it leaves the callback trigger active and the handle non-null.
- SBR-002 - If the WebUtil HOST bean is absent, the procedure surfaces an informative error alert rather than silently failing, ensuring the caller is aware that `Release_Process` will not function in the current environment.

---

**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-050 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named Java system property on the client JVM by invoking `java.lang.System.setProperty` via the Oracle Forms JNI bridge, and returns the property's previous value as a VARCHAR2 string.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Create a JNI argument list for two arguments using `JNI.CREATE_ARG_LIST(2)`.
- Step 2 - Add the property name (`a0`) as the first String argument to the argument list.
- Step 3 - Add the property value (`a1`) as the second String argument to the argument list.
- Step 4 - Call `java.lang.System.setProperty(String, String)` on the client JVM via `JNI.CALL_STRING_METHOD`, passing the prepared argument list.
- Step 5 - Return the previous value of the property (as returned by the JVM) to the caller; this will be NULL if the property was not previously set.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The property is set in the client JVM's system properties (`java.lang.System`); this has no effect on server-side properties.
- SBR-002 - The function returns the property's previous value, allowing callers to restore the original value if required.

---

**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-051 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the WebUtil hidden bean-container window. When called with `show = TRUE`, it records the current item focus, sets the window title to the WebUtil version string, displays the window, and navigates into it; when called with `show = FALSE`, it restores focus to the previously recorded item and hides the window. This mechanism is used during form initialisation to force the client-side Java beans to render and then be concealed.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the form is currently in `NORMAL` mode (not Enter-Query mode); if not, exit immediately without altering any window state.
- Step 2 - Locate the WebUtil hidden window handle using `FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW)`. If the handle is null (the window does not exist in the form), exit without action.
- Step 3 - If `show` is `TRUE`: record the item that currently holds focus (`SYSTEM.CURSOR_ITEM`) in the module-level variable `m_infoFrom`; set the hidden window's title to `'WebUtil '` concatenated with `WEBUTIL_VERSION`; call `SHOW_WINDOW` to make the window visible; then navigate into the dummy item within that window.
- Step 4 - If `show` is `FALSE`: check whether a prior focus item was recorded in `m_infoFrom`; if so, navigate back to that item. Then call `HIDE_WINDOW` to conceal the bean-container window.

---

**Decision Points**

DP-001

Condition:
The form is currently in `NORMAL` mode (not Enter-Query mode).

TRUE:
Proceed to check the hidden window handle and act on the `show` parameter.

FALSE:
Exit immediately without modifying any window state.

DP-002

Condition:
The WebUtil hidden window (`WEBUTIL_HIDDEN_WINDOW`) exists in the form (handle is not null).

TRUE:
Proceed to show or hide the window based on the `show` parameter.

FALSE:
Exit without action - the bean-container window is not present in this form.

DP-003

Condition:
The `show` parameter is `TRUE`.

TRUE:
Record the current cursor item, set the window title, show the window, and navigate to the dummy item inside it.

FALSE:
Restore focus to the previously recorded item (if available) and hide the window.

DP-004

Condition:
When hiding (`show = FALSE`): a prior focus item was previously recorded in `m_infoFrom` (handle is not null).

TRUE:
Navigate back to that item before hiding the window.

FALSE:
Hide the window without attempting any navigation.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Window show/hide operations are suppressed entirely when the form is in Enter-Query mode, preventing navigation side-effects during query entry.
- SBR-002 - The hidden bean-container window title is always set to `'WebUtil '` concatenated with the `WEBUTIL_VERSION` constant when the window is shown.
- SBR-003 - Focus is restored to the originating item when the bean window is hidden, provided that item was recorded at show time.

---

**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-052 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a server-side URL to a specified destination path on the client machine, returning a Boolean result that indicates whether the transfer succeeded.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-015](#SP-015--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Delegate the file download entirely to `WebUtil_Core.DownLoadFromURL`, passing through the source URL, the client-side destination path, and the optional file size hint.
- Step 2 - Return the Boolean result from `WebUtil_Core.DownLoadFromURL` directly to the caller, indicating success (`TRUE`) or failure (`FALSE`) of the transfer.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The `fileSize` parameter defaults to `0` if not supplied; the underlying WebUtil bean accepts this as an unspecified size, so callers are not required to know the file size in advance.
- SBR-002 - The function is a thin wrapper - all transfer logic and error handling reside in `WebUtil_Core.DownLoadFromURL`; this routine adds no additional validation or retry behaviour.

---

**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-053 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- webutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- webutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- webutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a processing error in the module-level error state so that callers can detect and report failures after any Win32 API call. The procedure sets a global error flag, stores a formatted error message combining the calling function name and the error text, and logs the entry for diagnostic purposes.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-057](#SP-057--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level flag `ERROR_ENCOUNTERED` to `TRUE`, marking that an error has occurred.
- Step 2 - Build the error message by concatenating the calling function name, a colon-space separator, and up to 1968 characters of the supplied error text, and store it in the module-level variable `ERROR_STACK`.
- Step 3 - Log the formatted error message at debug level 99 via `CLIENT_WIN_API_DEBUG.DebugLog`, identifying the log source as `'Add_Error'`.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The error text stored in `ERROR_STACK` is capped at 1968 characters to prevent overflow; any text beyond that length is silently truncated.
- SBR-002 - The formatted error message always prepends the name of the calling function followed by a colon and space, so that the error origin is unambiguously identifiable in the error stack.

---

**Implementation Logic**

```plsql

  PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
  begin 
    -- Just watch for value errors 
    ERROR_ENCOUNTERED  := TRUE;
    ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
    CLIENT_WIN_API_DEBUG.DebugLog(99,'Add_Error',ERROR_STACK);
  end Add_Error;
```

#### SP-054 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- webutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- webutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- webutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects any pending error messages from the Oracle Forms `TOOL_ERR` error stack (or falls back to the current `SQLERRM`) and returns them as a single concatenated string, so calling routines can append detailed external error context to their own error reports.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the `TOOL_ERR` error stack contains one or more messages (`tool_err.nerrors > 0`).
- Step 2 - If the stack is non-empty, iterate through each error on the stack; for each one, append a newline followed by the error message text to the accumulation buffer (`vcErrBuff`). If appending would exceed the buffer's 1968-character limit, exit the loop silently to avoid a `VALUE_ERROR`.
- Step 3 - After appending each message, pop it from the `TOOL_ERR` stack to consume it.
- Step 4 - If the `TOOL_ERR` stack is empty but `SQLERRM` is not null, append a newline and the current SQL error message to the buffer instead.
- Step 5 - Return the accumulated error string (which may be `NULL` if neither source yielded any messages).

---

**Decision Points**

DP-001

Condition:
`tool_err.nerrors > 0` - the `TOOL_ERR` error stack holds at least one pending message.

TRUE:
Iterate through and drain the `TOOL_ERR` stack, concatenating each message into `vcErrBuff`.

FALSE:
Check whether `SQLERRM` is non-null and use that as a fallback error source.

DP-002

Condition:
Appending the next `TOOL_ERR` message would cause `vcErrBuff` to exceed its 1968-character limit (raising `VALUE_ERROR`).

TRUE:
Exit the loop immediately - no further messages are appended, and the buffer is returned as-is.

FALSE:
Append the message and continue iterating.

DP-003

Condition:
The `TOOL_ERR` stack is empty and `SQLERRM` is not null.

TRUE:
Append `SQLERRM` to the buffer as the sole error source.

FALSE:
Return `NULL` - no error information is available from either source.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The `TOOL_ERR` error stack takes precedence over `SQLERRM`; `SQLERRM` is only used when the stack is empty.
- SBR-002 - The accumulated error string is capped at 1968 characters; messages that would overflow this limit are silently discarded rather than raising an exception.
- SBR-003 - Each consumed `TOOL_ERR` message is popped from the stack, so the stack is drained during the call.

---

**Implementation Logic**

```plsql

  FUNCTION Add_External_Errors return varchar2 is
    iCounter   pls_integer;
    vcErrBuff  varchar2(1968);
  begin 
    if tool_err.nerrors > 0 then 
      for iCounter in 1..tool_err.nerrors LOOP
        begin 
          vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
        exception
          when VALUE_ERROR then 
            exit; /* String exceeds allowable buffer */
        end;
        tool_err.pop;
      end loop;
    elsif SQLERRM is not null then 
      vcErrBuff := chr(10)||SQLERRM; 
    end if;
    return vcErrBuff;
  end Add_External_Errors;
```

#### SP-055 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL `BOOLEAN` value to its `VARCHAR2` text equivalent (`'TRUE'` or `'FALSE'`), providing a portable string representation of boolean flags for use in debug logging, error messages, and any context where a `VARCHAR2` is required instead of a native boolean.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the input boolean `ThisBoolean`.
- Step 2 - If `ThisBoolean` is `TRUE`, return the string `'TRUE'`; otherwise return the string `'FALSE'`.

---

**Decision Points**

DP-001

Condition:
The input boolean `ThisBoolean` evaluates to `TRUE`.

TRUE:
Return the string literal `'TRUE'`.

FALSE:
Return the string literal `'FALSE'`.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - A PL/SQL `BOOLEAN` value is mapped to exactly one of two string representations: `'TRUE'` or `'FALSE'`; no other values are possible.

---

**Implementation Logic**

```plsql

  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
    if ThisBoolean then 
      RETURN 'TRUE';
    else
      RETURN 'FALSE';
    end if;
  end BoolToChar;

END;

PACKAGE CLIENT_WIN_API_ENVIRONMENT IS

/*-----------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API_Environment                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port to WebUtil
 *
 *********************************************************************************
 * WIN_API_ENVIRONMENT -> This package is concerned with reading from and 
 *       writing to either INI files or the Win95/WinNT Registry.
 *       Or gleaning other useful nuggets of information from the system
 * Contents:
 *    Read_INI_File           -> Gets a Value from an INI file
 *    Write_INI_File          -> Sets a Value in an INI file
 *    Get_Windows_Username    -> Login of current Windows User
 *    Get_Windows_Version     -> Returns the O/S being used
 *    Get_Environment_string  -> Expands Environment Vars e.g %path%
 *    Get_Windows_Directory   -> Gets the Working Windows Dir
 *    Get_Temp_Directory      -> Gets the Temp Dir
 *    Get_Net_Connection      -> Expand Drive Letter into a Network Path
 *    Read_Registry           -> Reads a value from the Registry 
 *    Write_Registry          -> Writes a value to the Registry in REG_SZ fmt
 *    Write_RegistryEx        -> Extended version of Write_Registry which allows 
 *                               You to choose which format to Write in
 *    Create_Registry_Key     -> Creates a new subkey in the registry
 *    Delete_Registry_Key     -> Removes a subkey from the registry
 *    Get_Working_Directory   -> Get the name of the "Start In" / Current Directory
 *                               For this runtime
 *    Get_Computer_Name       -> Get the name of this PC if defined
 * Dependancies:
 *    WIN_API
 *    WIN_API_DIALOG
 *    WIN_API_DEBUG
\*------------------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Read_INI_File    -> Read a Value from a named INI file 
 *                     If you need to read the ORACLE.INI file 
 *                     use TOOL_ENV.GETVAR() instead of this
 *                     package.
 *                     If using 32bit Developer/2000 you would 
 *                     probably rather use 
 *                     WIN_API_PROFILES.READ_REGISTRY() instead
 * Arguments: 
 *  FileName        -> Name of INI file e.g. WIN.INI. If the full
 *                     path is not supplied with this argument
 *                     then the DOS PATH will be searched for the
 *                     Specified INI file
 *  Section         -> Section in INI file where the entry is. 
 *                     This will be delimited using square brackets 
 *                     e.g. [printers]
 *  Entry           -> Name of Variable to read e.g. load (from win.ini)
 *  RaiseExceptions -> TRUE or FALSE(Default) If set to true, then if the 
 *                     requested variable is not found the explicit exception
 *                     NO_DATA_FOUND will be raised.
 * Returns:
 *  Value           -> A VARCHAR2 value containing the 
 *                     string (or number as a string) that the 
 *                     entry contains.
 *                     If the Entry is not found, NULL is returned in 
 *                     the return value. (see RaiseExceptions above)
\*-------------------------------------------------------------------------*/
```

#### SP-056 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- webutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- webutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- webutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the `Client_Win_API` package-level error state by clearing the error flag and nullifying the error stack string, ensuring no residual error information from a previous API call is carried forward into the next one.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the package-level `ERROR_ENCOUNTERED` flag to `FALSE`, indicating no error is currently active.
- Step 2 - Set the package-level `ERROR_STACK` string to `NULL`, discarding any previously recorded error text.

---

**Decision Points**

No business-significant decision points in this routine.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Both the error flag (`ERROR_ENCOUNTERED`) and the error text (`ERROR_STACK`) must be cleared together; partial resets are not performed.

---

**Implementation Logic**

```plsql

  PROCEDURE Clean_Error_Stack is 
  begin 
    -- just empty the variables
    ERROR_ENCOUNTERED  := FALSE;
    ERROR_STACK        := NULL;
  end Clean_Error_Stack;
```

#### SP-057 - DEBUGLOG

**Invoked From:**

- webutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted diagnostic message to the WebUtil client-side log, provided the debug subsystem is active, not paused, and the requested debug level falls within the configured threshold. Each message is optionally prefixed with a timestamp and always includes the debug level and the name of the calling routine, giving developers a complete, filterable trace of D2KWUTIL execution.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-043](#SP-043--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the debug subsystem is disabled (`iDebugState = 0`); if so, do nothing and return immediately.
- Step 2 - Check whether debug output is currently paused (`bDebugPaused`); if so, do nothing and return immediately.
- Step 3 - Check whether the supplied `DebugLevel` exceeds the currently configured maximum debug level (`iDebugLevel`); if so, do nothing and return immediately.
- Step 4 - If a timestamp is enabled (`bDebugTimeStamp`), format the current time as `HH24:MI:SS` followed by `> ` and store it in `vcDateStamp`.
- Step 5 - Build the formatted log string by prepending the zero-padded two-digit debug level in angle brackets, appending the optional timestamp, and then appending the `LoggingCall` name right-padded to 30 characters with a trailing colon.
- Step 6 - Append as much of `LogString` as will fit within the 2000-character overall limit (determined by subtracting the current prefix length from 2000).
- Step 7 - Write the final string to the WebUtil log via `WebUtil_core.log`, prefixed with `'D2KWUTIL '`, with the `false` flag indicating it is not an error-level entry.

---

**Decision Points**

DP-001

Condition:
`iDebugState` equals `0` (debug subsystem is disabled).

TRUE:
Take no action - exit the procedure immediately without writing any log output.

FALSE:
Proceed to check whether debug output is paused (DP-002).

DP-002

Condition:
`bDebugPaused` is TRUE (debug output is temporarily suspended).

TRUE:
Take no action - exit the procedure immediately without writing any log output.

FALSE:
Proceed to check whether the message's debug level qualifies for output (DP-003).

DP-003

Condition:
The supplied `DebugLevel` is greater than the configured maximum `iDebugLevel`.

TRUE:
Take no action - the message's verbosity level is too high; exit without writing.

FALSE:
Proceed to compose and write the debug log entry.

DP-004

Condition:
`bDebugTimeStamp` is TRUE.

TRUE:
Prefix the log message with the current wall-clock time formatted as `HH24:MI:SS> `.

FALSE:
Omit the timestamp from the log message.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - No log output is produced unless the debug subsystem is active (`iDebugState ≠ 0`), not paused (`bDebugPaused = FALSE`), and the message's `DebugLevel` does not exceed the configured threshold (`iDebugLevel`); all three conditions must hold.
- SBR-002 - The complete log line is capped at 2000 characters; the `LogString` payload is truncated so that the total length of the formatted prefix plus payload never exceeds this limit.
- SBR-003 - The calling-routine label is always right-padded to 30 characters (with a trailing colon) in the output, ensuring consistent column alignment across all log entries.
- SBR-004 - All entries written by this procedure are tagged with the literal prefix `'D2KWUTIL '` in the WebUtil log, distinguishing them from log entries produced by other subsystems.

---

**Implementation Logic**

```plsql
   
  PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                      LoggingCall IN VARCHAR2, 
                      LogString   IN VARCHAR2) is
    vcDateStamp   VARCHAR2(10);
    vcDebugString VARCHAR2(2000);
    hFile         TEXT_IO.FILE_TYPE;
  begin
    if iDebugState = 0 then 
      NULL;
    elsif bDebugPaused then 
      NULL;
    elsif DebugLevel > iDebugLevel then 
      NULL;
    else
      -- Sort out the Datestamp    
      if bDebugTimeStamp then 
          vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
      end if;

      -- Construct the final String
      vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
      vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));

      WebUtil_core.log('D2KWUTIL '||vcDebugString,false);
    end if;
  end DebugLog;
```

#### SP-058 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a Windows environment variable value on the client machine by invoking the native `d2kwutil_GetDOSEnv` DLL function via the WebUtil C API. Returns the expanded value of the named variable or `NULL` (or raises `NO_DATA_FOUND`) when the variable is undefined, the buffer is insufficient, or the API is unavailable.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Clear any previously recorded API errors by calling `Client_Win_API.Clean_Error_Stack`.
- Step 2 - Check whether the Win32 API is available (`Client_Win_API.API_ENABLED`). If it is not, raise `CLIENT_WIN_API.NOT_AVAILABLE`.
- Step 3 - Register the native DLL function `d2kwutil_GetDOSEnv` (signature `LONG, *CHAR, *CHAR, LONG`) via `Client_win_api.Register_function_call` so it can be invoked through the WebUtil C API.
- Step 4 - Format the variable name as a `%VARNAME%` Windows environment expansion token and assign it to the input buffer (`vcBuff1`).
- Step 5 - Build a `WEBUTIL_C_API` parameter list with three parameters: the input token buffer (IN, 512 bytes), the output value buffer (OUT, up to 2000 bytes), and the output buffer size (IN integer).
- Step 6 - Invoke the native function via `WebUtil_C_API.Invoke_int` and capture the integer return code (`iRC`).
- Step 7 - Check whether `iRC` exceeds the maximum output buffer size (2000). If so, log a `WUL` package error (code 941) indicating that the expanded variable value is too long to hold.
- Step 8 - Retrieve the output string from the parameter list via `WEBUTIL_C_API.Get_Parameter_String` and then destroy the parameter list.
- Step 9 - Evaluate the failure conditions: `iRC = 0` (call failed), `iRC > iMaxOutBuff` (buffer overflow), or the output equals the unexpanded input token (variable not defined). On any of these, record an error via `Add_error` and either raise `NO_DATA_FOUND` (if `RaiseExceptions` is TRUE) or return `NULL`.
- Step 10 - If none of the failure conditions apply, return the expanded environment variable value (`vcBuff2`).
- Step 11 - On `NO_DATA_FOUND` exception: re-raise directly to the caller.
- Step 12 - On `CLIENT_WIN_API.NOT_AVAILABLE` exception: record the "API not available" error via `Add_error` and re-raise.
- Step 13 - On any other exception: record the unexpected error (appending any external error messages) via `Add_error` and re-raise.

---

**Decision Points**

DP-001

Condition:
`Client_Win_API.API_ENABLED` is TRUE - the Win32 API functions are available on the current client.

TRUE:
Register and invoke the native DLL function to retrieve the environment variable.

FALSE:
Raise `CLIENT_WIN_API.NOT_AVAILABLE`; the error handler records the "API not available" message and re-raises.

DP-002

Condition:
`iRC` (the DLL return code) exceeds the maximum output buffer size (`iMaxOutBuff` = 2000).

TRUE:
Log a buffer-overflow error via `Webutil_Core.Error` (WUL package, code 941); then fall through to the failure-condition check below.

FALSE:
Proceed to retrieve the output string.

DP-003

Condition:
`iRC = 0`, or `iRC > iMaxOutBuff`, or the output buffer still contains the unexpanded `%VARNAME%` token (variable not defined in the environment).

TRUE:
Record an "Unable to get the value" error via `Add_error`; raise `NO_DATA_FOUND` if `RaiseExceptions` is TRUE, otherwise return `NULL`.

FALSE:
Return the successfully expanded environment variable value.

DP-004

Condition:
`RaiseExceptions` is TRUE when a retrieval failure is detected (DP-003 TRUE branch).

TRUE:
Raise `NO_DATA_FOUND` to propagate the failure to the caller.

FALSE:
Return `NULL` silently.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The function is only executable when the Win32 API is loaded and enabled (`API_ENABLED = TRUE`); it raises `NOT_AVAILABLE` on any other platform.
- SBR-002 - The environment variable name is wrapped in `%...%` notation before being passed to the native DLL, matching Windows environment variable expansion syntax.
- SBR-003 - The output buffer is limited to 2000 characters; values longer than this produce an error rather than a truncated result.
- SBR-004 - If the DLL returns the unexpanded `%VARNAME%` token as its output, the variable is treated as undefined, and the call is considered a failure.
- SBR-005 - The `RaiseExceptions` parameter controls whether failures propagate as exceptions (`NO_DATA_FOUND`) or are silently absorbed with a `NULL` return; callers choose their own error-handling behaviour.

---

**Implementation Logic**

```plsql

  FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                     RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
    vcBuff1    VARCHAR2(512);
    iMaxOutBuff NUMBER := 2000;
    vcBuff2    VARCHAR2(2000); -- keep the length same as iMaxOutBuff
    iRC        PLS_INTEGER;
    args      WEBUTIL_C_API.ParameterList;
    param1    WEBUTIL_C_API.ParameterHandle;
    param2    WEBUTIL_C_API.ParameterHandle;   
    param3    WEBUTIL_C_API.ParameterHandle;     
  begin 
    Client_Win_API.Clean_Error_Stack;
    iRC  := 0;
    if Client_Win_API.API_ENABLED then
      Client_win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
      vcBuff1    := '%'||ltrim(rtrim(VariableName))||'%';
      args := WEBUTIL_C_API.Create_Parameter_List;
      param1 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_IN,
                                            vcBuff1,
                                            512);
      param2 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_OUT,
                                            vcBuff2,
                                            iMaxOutBuff);
      param3 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            iMaxOutBuff);

      iRC := WebUtil_C_API.Invoke_int(Client_win_api.FunctionHandle(iGetDOSEnv),args);
      if iRC > iMaxOutBuff then
        -- expanded variable value is too long.
        Webutil_Core.Error(Webutil_Core.WUL_PACKAGE,941,
                           'CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING', iMaxOutBuff, iRC);
      end if;
      vcBuff2 := WEBUTIL_C_API.Get_Parameter_String(args,param2);
      WEBUTIL_C_API.Destroy_Parameter_List(args);            
    else 
      raise CLIENT_WIN_API.NOT_AVAILABLE;
    end if;  
    if iRC = 0
        or iRC > iMaxOutBuff -- buffer is insufficient
        or vcBuff1 = vcBuff2 -- if not defined %VAR% will be returned as %VAR%
    then 
      CLIENT_Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
      if RaiseExceptions then
        raise NO_DATA_FOUND;
      else
        return NULL;
      end if;
    else
      return vcBuff2;
    end if;
  exception
    when NO_DATA_FOUND then 
      raise;
    when CLIENT_WIN_API.NOT_AVAILABLE then
      CLIENT_Win_API.Add_error('Get_Environment_String',CLIENT_Win_API.NoAPI);
      raise;
    when others then 
      CLIENT_Win_API.Add_error('Get_Environment_String',CLIENT_Win_API.UError||CLIENT_WIN_API.Add_External_errors); 
      raise;
  end Get_Environment_String;
```

#### SP-059 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the path of the client machine's temporary directory by calling the native `d2kwutil_TmpDir` C function through the WebUtil C API FFI layer. The returned path string is normalised by stripping any trailing directory separator before being returned. If the API is unavailable or returns no value, the function logs an error and - depending on the `RaiseExceptions` flag - either raises an exception or returns `NULL`.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-064](#SP-064--STRIPDIRSEP)) - matched by member name
- WEBUTIL.ADD_PARAMETER ([SP-010](#SP-010--WEBUTIL.ADD_PARAMETER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CREATE_PARAMETER_LIST ([SP-013](#SP-013--WEBUTIL.CREATE_PARAMETER_LIST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.DESTROY_PARAMETER_LIST ([SP-014](#SP-014--WEBUTIL.DESTROY_PARAMETER_LIST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_PARAMETER_STRING ([SP-030](#SP-030--WEBUTIL.GET_PARAMETER_STRING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.INVOKE_INT ([SP-037](#SP-037--WEBUTIL.INVOKE_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Clear the Client Win API error stack to remove any stale errors from prior calls.
- Step 2 - Check whether the Client Win API is available (`Client_Win_API.API_ENABLED`). If not, raise `CLIENT_WIN_API.NOT_AVAILABLE` immediately.
- Step 3 - Register the FFI function call binding for `d2kwutil_TmpDir` (return type `INT`, parameters `*CHAR, INT`) against the stored function handle `iTmpDir`.
- Step 4 - Initialise the output buffer `vcBuff1` to an empty string and create a WebUtil C API parameter list.
- Step 5 - Add the first parameter to the list: an `IN OUT` `C_CHAR_PTR` bound to `vcBuff1` with a maximum buffer size of 512 characters (to receive the temp directory path string).
- Step 6 - Add the second parameter: an `IN` `C_INT` with value `512` (the buffer length, passed to the native function).
- Step 7 - Invoke the native `d2kwutil_TmpDir` function via `WebUtil_C_API.Invoke_Int`, passing the parameter list; capture the integer return code.
- Step 8 - Read back the populated temp-directory path from the first output parameter into `vcBuff1`.
- Step 9 - Destroy the parameter list to free resources.
- Step 10 - If the return code is zero (no directory path was returned), log an error `'No Value Returned'`. If `RaiseExceptions` is `TRUE`, raise `NO_DATA_FOUND`; otherwise return `NULL`.
- Step 11 - If the return code is non-zero, return the temp directory path after stripping any trailing directory separator via `StripDirSep`.
- Step 12 - In the exception handler: re-raise `NO_DATA_FOUND` as-is; for `CLIENT_WIN_API.NOT_AVAILABLE`, log the no-API error and re-raise; for all other exceptions, log a generic error (appending external error details) and re-raise.

---

**Decision Points**

DP-001

Condition:
`Client_Win_API.API_ENABLED` is `TRUE` - the Client Win API FFI layer is available on this client.

TRUE:
Proceed to build the parameter list and invoke the native function.

FALSE:
Raise `CLIENT_WIN_API.NOT_AVAILABLE` immediately - no further processing is attempted.

DP-002

Condition:
The integer return code from `d2kwutil_TmpDir` is zero (the native function returned no directory path).

TRUE:
Log a `'No Value Returned'` error. If `RaiseExceptions` is `TRUE`, raise `NO_DATA_FOUND`; otherwise return `NULL`.

FALSE:
Return the temp directory path (with trailing separator stripped) to the caller.

DP-003

Condition:
`RaiseExceptions` is `TRUE` when the native function returns no value (return code is zero).

TRUE:
Raise `NO_DATA_FOUND` so the caller can handle the absence of a temp directory.

FALSE:
Return `NULL` silently - no exception is propagated.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The Client Win API FFI layer must be available before the temp directory can be retrieved; absence raises `CLIENT_WIN_API.NOT_AVAILABLE`.
- SBR-002 - The native function is called with a fixed 512-character buffer; the path returned is capped at that length.
- SBR-003 - A return code of zero from the native function is treated as a failure; the error is always logged, and exception propagation is governed by the `RaiseExceptions` parameter.
- SBR-004 - The returned path is always normalised by removing any trailing directory separator character before being returned to the caller.
- SBR-005 - All exceptions (including unexpected ones) are caught, logged with error detail, and re-raised - no error is silently swallowed.

---

**Implementation Logic**

```plsql

  FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
    vcBuff1    VARCHAR2(512);
    iRC        PLS_INTEGER;
    args      WEBUTIL_C_API.ParameterList;
    param1    WEBUTIL_C_API.ParameterHandle;
    param2    WEBUTIL_C_API.ParameterHandle;   
  begin 
    Client_Win_API.Clean_Error_Stack;
    iRC  := 0;
    if Client_Win_API.API_ENABLED then 
      Client_win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
      vcBuff1    := '';
      args := WEBUTIL_C_API.Create_Parameter_List;
      param1 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_INOUT,
                                            vcBuff1,
                                            512);
      param2 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            512);
      iRC := WebUtil_C_API.Invoke_Int(Client_win_api.FunctionHandle(iTmpDir),args);
      vcBuff1 := WEBUTIL_C_API.Get_Parameter_String(args,param1);
      WEBUTIL_C_API.Destroy_Parameter_List(args);                                                
    else
      raise CLIENT_WIN_API.NOT_AVAILABLE;
    end if;  
    if iRC = 0 then 
      CLIENT_Win_API.Add_error('Get_Temp_Directory','No Value Returned');
      if RaiseExceptions then
        raise NO_DATA_FOUND;
      else
        return NULL;
      end if;
    else
      return CLIENT_WIN_API.StripDirSep(vcBuff1);
    end if;
  exception
    when NO_DATA_FOUND then 
      raise;
    when CLIENT_WIN_API.NOT_AVAILABLE then
      CLIENT_Win_API.Add_error('Get_Temp_Directory',CLIENT_Win_API.NoAPI);
      raise;
    when others then 
      CLIENT_Win_API.Add_error('Get_Temp_Directory',CLIENT_Win_API.UError||CLIENT_WIN_API.Add_External_errors); 
      raise;
  end Get_Temp_Directory;
```

#### SP-060 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows system directory path from the client machine by calling the native `d2kwutil_WinDir` function through the WebUtil C API, sanitises the returned path, and returns it as a clean string for use in file-dialog and directory-resolution operations.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-064](#SP-064--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Clear any existing error messages from the error stack by calling `Clean_Error_Stack`.
- Step 2 - Initialise the return-code variable `iRC` to 0.
- Step 3 - Check whether the client Windows API is available (`API_ENABLED`); if not, raise `CLIENT_WIN_API.NOT_AVAILABLE` immediately.
- Step 4 - Register the native function `d2kwutil_WinDir` (signature `'INT','*CHAR,INT'`) against the `iWinDir` slot via `Register_function_call`.
- Step 5 - Create a new WebUtil parameter list.
- Step 6 - Add an in-out character-pointer parameter (`C_CHAR_PTR`, `param_INOUT`) to hold the directory path buffer (maximum 512 characters).
- Step 7 - Add an input integer parameter (`C_INT`, `param_IN`) carrying the buffer size (512).
- Step 8 - Invoke the registered function via `Invoke_Int`, storing the integer return code in `iRC`.
- Step 9 - Read the populated directory path back from the parameter list into `vcBuff1` using `Get_Parameter_String`.
- Step 10 - Destroy the parameter list to release client-side resources.
- Step 11 - If `iRC` equals 0 (no value returned), record an error `'No Value Returned'` and either raise `NO_DATA_FOUND` (if `RaiseExceptions` is TRUE) or return NULL (if FALSE).
- Step 12 - If `iRC` is non-zero, strip any trailing directory separator from `vcBuff1` using `StripDirSep` and return the cleaned path.
- Step 13 - On `NO_DATA_FOUND`, re-raise the exception to the caller.
- Step 14 - On `CLIENT_WIN_API.NOT_AVAILABLE`, record an error with the `NoAPI` message and re-raise.
- Step 15 - On any other exception, record an error combining the unknown-error prefix with any external error details and re-raise.

---

**Decision Points**

DP-001

Condition:
`Client_Win_API.API_ENABLED` is TRUE (the client-side Windows API is accessible).

TRUE:
Proceed to register the function, build the parameter list, invoke the native call, and process the result.

FALSE:
Raise `CLIENT_WIN_API.NOT_AVAILABLE` immediately - no native function call is attempted.

DP-002

Condition:
The integer return code `iRC` from `Invoke_Int` equals 0.

TRUE:
Log an error `'No Value Returned'`; if `RaiseExceptions` is TRUE raise `NO_DATA_FOUND`, otherwise return NULL.

FALSE:
Strip the trailing directory separator from the returned buffer and return the clean path string.

DP-003

Condition:
The `RaiseExceptions` parameter is TRUE (evaluated only when `iRC = 0`).

TRUE:
Raise `NO_DATA_FOUND` to propagate the failure to the caller.

FALSE:
Return NULL silently, allowing the caller to handle the missing value.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The Windows directory retrieval may only proceed when the client Windows API is enabled; the routine does not attempt a native call on platforms where the API is unavailable.
- SBR-002 - A return code of zero from the native function is treated as a failure - no usable directory path was obtained - regardless of whether a buffer was populated.
- SBR-003 - The caller controls error propagation: passing `RaiseExceptions => TRUE` causes failures to raise exceptions, while `FALSE` causes the routine to return NULL, allowing silent fallback in the caller.
- SBR-004 - The raw path returned by the native function is always sanitised through `StripDirSep` before being returned, ensuring consistent path formatting (no trailing backslash, no semicolon-delimited extras).

---

**Implementation Logic**

```plsql

  FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
    vcBuff1    VARCHAR2(512);
    iRC        PLS_INTEGER;
    args      WEBUTIL_C_API.ParameterList;
    param1    WEBUTIL_C_API.ParameterHandle;
    param2    WEBUTIL_C_API.ParameterHandle;      
  begin 
    Client_Win_API.Clean_Error_Stack;
    iRC  := 0;
    if Client_Win_API.API_ENABLED then 
      Client_win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

      vcBuff1    := '';
      args := WEBUTIL_C_API.Create_Parameter_List;
      param1 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_INOUT,
                                            vcBuff1,
                                            512);
      param2 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            512);
      iRC := WebUtil_C_API.Invoke_Int(Client_win_api.FunctionHandle(iWinDir),args);
      vcBuff1 := WEBUTIL_C_API.Get_Parameter_String(args,param1);
      WEBUTIL_C_API.Destroy_Parameter_List(args);                                            
    else
      raise CLIENT_WIN_API.NOT_AVAILABLE;
    end if;  
    if iRC = 0 then 
      CLIENT_Win_API.Add_error('Get_Windows_Directory','No Value Returned');
      if RaiseExceptions then
        raise NO_DATA_FOUND;
      else
        return NULL;
      end if;
    else
      return CLIENT_WIN_API.StripDirSep(vcBuff1);
    end if;
  exception
    when NO_DATA_FOUND then 
      raise;
    when CLIENT_WIN_API.NOT_AVAILABLE then
      CLIENT_Win_API.Add_error('Get_Windows_Directory',CLIENT_Win_API.NoAPI);
      raise;
    when others then 
      CLIENT_Win_API.Add_error('Get_Windows_Directory',CLIENT_Win_API.UError||CLIENT_WIN_API.Add_External_errors); 
      raise;
  end Get_Windows_Directory;
```

#### SP-061 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named value entry from the Windows Registry on the client machine by invoking the native `d2kwutil_GetRegKey` DLL function through the WebUtil C API. Translates the registry root key name in the path to its numeric identifier, constructs the parameter list for the native call, and returns the value string or `NULL` (or raises an exception) depending on the outcome and the `RaiseExceptions` flag.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-053](#SP-053--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-054](#SP-054--ADD_EXTERNAL_ERRORS)) - matched by member name
- CLEAN_ERROR_STACK ([SP-056](#SP-056--CLEAN_ERROR_STACK)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-062](#SP-062--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Clear any previously recorded API errors by calling `Client_Win_API.Clean_Error_Stack`.
- Step 2 - Verify that the Win32 API is available (`Client_Win_API.API_ENABLED`). If not, raise `CLIENT_WIN_API.NOT_AVAILABLE`.
- Step 3 - Register the native DLL function `d2kwutil_GetRegKey` (signature `INT, INT, *CHAR, *CHAR, *CHAR, INT, INT`) via `Client_win_api.Register_function_call`.
- Step 4 - Parse the root key name from `RegPath` (the segment before the first backslash, uppercased) and map it to its numeric constant: `HKEY_LOCAL_MACHINE` -> 0, `HKEY_CLASSES_ROOT` -> 1, `HKEY_CURRENT_USER` -> 2, `HKEY_USERS` -> 3, `HKEY_CURRENT_CONFIG` -> 4. Any unrecognised root name records an error and, if `RaiseExceptions` is TRUE, raises `NO_DATA_FOUND`.
- Step 5 - Extract the sub-path (the portion of `RegPath` after the first backslash) and set the registry entry name, output buffer, and buffer length.
- Step 6 - Set the expand-variables flag based on `CLIENT_WIN_API.COMPAT_EXPAND_REG_VALUES`: if FALSE (compatibility mode), pass 1 (suppress expansion); if TRUE (default), pass 0 (allow expansion).
- Step 7 - Build a six-parameter `WEBUTIL_C_API` parameter list: root key integer (IN), sub-path string (IN, 512 bytes), entry name string (IN, 512 bytes), output value buffer (INOUT, 2000 bytes), buffer length integer (IN), expand flag integer (IN).
- Step 8 - Invoke the native function via `WebUtil_C_API.Invoke_int`, capturing the integer return code (`iRC`).
- Step 9 - Retrieve the output string from the parameter list and destroy the parameter list.
- Step 10 - Evaluate the return code: `-1` (entry not found), `-2` (unsupported data type), `-3` (value too long for buffer), `-4` (environment string expansion failed). For each, record an appropriate error via `Add_error` and either return `NULL` or raise an exception depending on `RaiseExceptions`.
- Step 11 - If `iRC` is not a known failure code, return `vcBuff3` (the registry value string).
- Step 12 - On `NO_DATA_FOUND` or `VALUE_ERROR` exceptions: re-raise directly.
- Step 13 - On `CLIENT_WIN_API.NOT_AVAILABLE` exception: record the "API not available" error and re-raise.
- Step 14 - On any other exception: record the unexpected error (appending external errors) and re-raise.

---

**Decision Points**

DP-001

Condition:
`Client_Win_API.API_ENABLED` is TRUE.

TRUE:
Proceed with the native DLL call to read the registry entry.

FALSE:
Raise `CLIENT_WIN_API.NOT_AVAILABLE`.

DP-002

Condition:
The root key name extracted from `RegPath` matches one of the five recognised Windows registry root key constants.

TRUE:
Assign its numeric identifier (`iBuff1`) and continue building the parameter list.

FALSE:
Record an "Invalid Registry Key" error; if `RaiseExceptions` is TRUE raise `NO_DATA_FOUND`, otherwise leave `iBuff1` unset.

DP-003

Condition:
`CLIENT_WIN_API.COMPAT_EXPAND_REG_VALUES` is TRUE.

TRUE:
Pass `iBuff3 = 0` to allow the DLL to expand environment strings within registry values.

FALSE:
Pass `iBuff3 = 1` to suppress environment string expansion (compatibility mode).

DP-004

Condition:
`iRC = -1` - the registry entry was not found.

TRUE:
Record a "Cannot read entry" error; return `NULL` if `RaiseExceptions` is FALSE, otherwise raise `NO_DATA_FOUND`.

FALSE:
Check the next return code.

DP-005

Condition:
`iRC = -2` - the registry value is of an unsupported data type.

TRUE:
Record an "unsupported datatype" error; return `NULL` if `RaiseExceptions` is FALSE, otherwise raise `NO_DATA_FOUND`.

FALSE:
Check the next return code.

DP-006

Condition:
`iRC = -3` - the registry value exceeds the 2000-byte output buffer.

TRUE:
Record a "longer than N Bytes" error; return `NULL` if `RaiseExceptions` is FALSE, otherwise raise `VALUE_ERROR`.

FALSE:
Check the next return code.

DP-007

Condition:
`iRC = -4` - environment string expansion within the registry value failed.

TRUE:
Record a "Failed to expand environment string" error; return `NULL` if `RaiseExceptions` is FALSE, otherwise raise `NO_DATA_FOUND`.

FALSE:
Return `vcBuff3` as the successfully retrieved registry value.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The function is only executable when the Win32 API is loaded and enabled; it raises `NOT_AVAILABLE` on non-Windows clients.
- SBR-002 - The registry root key must be one of exactly five recognised names (`HKEY_LOCAL_MACHINE`, `HKEY_CLASSES_ROOT`, `HKEY_CURRENT_USER`, `HKEY_USERS`, `HKEY_CURRENT_CONFIG`); any other value is treated as an invalid key.
- SBR-003 - The output buffer for the registry value is fixed at 2000 bytes; values longer than this produce an error rather than a truncated result.
- SBR-004 - By default (`COMPAT_EXPAND_REG_VALUES = TRUE`), environment variable references embedded in registry values are automatically expanded; this behaviour can be suppressed by setting the compatibility flag to `FALSE`.
- SBR-005 - The `RaiseExceptions` parameter governs whether retrieval failures propagate as exceptions or are silently absorbed as `NULL` returns, giving callers control over their own error-handling policy.

---

**Implementation Logic**

```plsql

  FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                          RegEntry        IN  VARCHAR2, 
                          RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
    vcBuff1    VARCHAR2(512);
    vcBuff2    VARCHAR2(512);
    vcBuff3    VARCHAR2(2000);                       
    vcRoot     VARCHAR2(20);
    iBuff1     PLS_INTEGER;
    iBuff2     PLS_INTEGER;
    iBuff3         PLS_INTEGER;
    iRC        PLS_INTEGER;
    args      WEBUTIL_C_API.ParameterList;
    param1    WEBUTIL_C_API.ParameterHandle;
    param2    WEBUTIL_C_API.ParameterHandle;   
    param3    WEBUTIL_C_API.ParameterHandle;       
    param4    WEBUTIL_C_API.ParameterHandle;
    param5    WEBUTIL_C_API.ParameterHandle;   
    param6    WEBUTIL_C_API.ParameterHandle;       
  begin
    Client_Win_API.Clean_Error_Stack;
    iRC  := 0;
    if Client_Win_API.API_ENABLED then 
      Client_win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
      -- Which Root?
      vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
      if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
        iBuff1 := 0;
      elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
        iBuff1 := 1;
      elsif   vcRoot =  'HKEY_CURRENT_USER' then 
        iBuff1 := 2;
      elsif   vcRoot =  'HKEY_USERS' then
        iBuff1 := 3;
      elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
        iBuff1 := 4;      
      else
        CLIENT_Win_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
        if  RaiseExceptions then
          raise NO_DATA_FOUND;
        end if;  
      end if;

      iBuff2     := 2000; /* Length of buffer */
      vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
      vcBuff2    := RegEntry;
      vcBuff3    := '';
      if not CLIENT_WIN_API.COMPAT_EXPAND_REG_VALUES then 
        iBuff3 := 1;
      else
        iBuff3 := 0;
      end if;
      args := WEBUTIL_C_API.Create_Parameter_List;
      param1 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            iBuff1);
      param2 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_IN,
                                            vcBuff1,
                                            512);
      param3 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_IN,
                                            vcBuff2,
                                            512);   
      param4 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_CHAR_PTR,
                                            WEBUTIL_C_API.param_INOUT,
                                            vcBuff3,
                                            2000);                                    
      param5 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            iBuff2); 
      param6 := WEBUTIL_C_API.Add_Parameter(args,
                                            WEBUTIL_C_API.C_INT,
                                            WEBUTIL_C_API.param_IN,
                                            iBuff3);                                     
      iRC := WebUtil_C_API.Invoke_int(Client_win_api.FunctionHandle(iGetRegKey),args);
      vcBuff3 := WEBUTIL_C_API.Get_Parameter_String(args,param4);
      WEBUTIL_C_API.Destroy_Parameter_List(args);      
    
      --iRC        := d2kwutil_GetRegKey(Client_win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);      
    else 
      raise CLIENT_WIN_API.NOT_AVAILABLE;
    end if;  
    if iRC = -1  then 
      CLIENT_Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
      if not RaiseExceptions then
        return NULL;
      else 
        raise NO_DATA_FOUND;
      end if;
    elsif iRC = -2 then
      CLIENT_Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
      if not RaiseExceptions then
        return NULL;
      else 
        raise NO_DATA_FOUND;
      end if;
    elsif iRC = -3 then
      CLIENT_Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
      if not RaiseExceptions then
        return NULL;
      else 
        raise VALUE_ERROR;
      end if;
    elsif iRC = -4 then
      CLIENT_Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
      if not RaiseExceptions then
        return NULL;
      else 
        raise NO_DATA_FOUND;
      end if;    
    end if;
    return vcBuff3;
  exception
    when NO_DATA_FOUND then 
      raise;
    when VALUE_ERROR then 
      raise;
    when CLIENT_WIN_API.NOT_AVAILABLE then
      CLIENT_Win_API.Add_error('Read_Registry',CLIENT_Win_API.NoAPI);
      raise;
    when others then 
      CLIENT_Win_API.Add_error('Read_Registry',CLIENT_Win_API.UError||CLIENT_WIN_API.Add_External_errors); 
      raise;
  end Read_Registry;
```

#### SP-062 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- webutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- webutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- webutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a named native DLL function is registered with the WebUtil C API exactly once per session. If the function has not yet been registered under the given `FunctionID`, it calls `Webutil_C_API.register_function` to bind the function name and stores the resulting handle for subsequent invocations.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.REGISTER_FUNCTION ([SP-048](#SP-048--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the `FunctionHandle` collection already contains an entry for the given `FunctionID`.
- Step 2 - If no entry exists, register the function with the DLL by calling `Webutil_C_API.register_function`, passing `DLL_NAME` and `FunctionName`, and store the returned function handle at index `FunctionID` in the `FunctionHandle` collection.
- Step 3 - If an entry already exists, take no action - the function has already been registered and its handle is available for use.

---

**Decision Points**

DP-001

Condition:
`FunctionHandle.exists(FunctionId)` is FALSE - the function has not yet been registered for this session.

TRUE:
Call `Webutil_C_API.register_function` to bind the DLL function and store the handle in `FunctionHandle(FunctionId)`.

FALSE:
Do nothing - the function is already registered and its handle is cached.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - Each native DLL function is registered at most once per session; subsequent calls for the same `FunctionID` are no-ops, preventing redundant re-registration overhead.
- SBR-002 - The DLL name used for registration is the package constant `DLL_NAME`; callers supply only the function name and its signature metadata.

---

**Implementation Logic**

```plsql

  PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                     FunctionName   in VARCHAR2,
                                     FunctionReturn in VARCHAR2, 
                                     FunctionArgs   in VARCHAR2) is
    vcArgs  VARCHAR2(200);
    vcFrag  VARCHAR2(10);
    iOffset PLS_INTEGER;   
  begin 
    if (not FunctionHandle.exists(FunctionId)) then
      -- We need to go through the registration process.      
      -- Register the function with the DLL
      FunctionHandle(FunctionId) := Webutil_C_API.register_function(DLL_NAME,FunctionName);
    end if;
  end Register_Function_Call;
```

#### SP-063 - SF_COPYRIGHT_DECLARATION

**Invoked From:**

- rr_pre_enq_fmb.xml [Trigger: KEY-CLRFRM]
- rr_pre_enq_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

N/A

---

**Purpose**

Generates the copyright notice string for Maruti Suzuki India Limited, adjusted to reflect the current Indian financial year, so that the displayed copyright year correctly spans April-March boundaries rather than the calendar year.

---

**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current date via `SYSDATE`.
- Step 2 - Inspect the month component of the current date to determine whether it falls in January, February, or March - the tail months of the Indian financial year.
- Step 3 - If the month is January, February, or March, build the copyright string using the previous calendar year (current year minus one) as the financial year, because the financial year that started the previous April is still in progress.
- Step 4 - Otherwise (April through December), build the copyright string using the current calendar year, because the financial year that started in April of this year is in progress.
- Step 5 - Return the formatted copyright string (e.g. `© 2023 Maruti Suzuki India Limited`) to the caller.

---

**Decision Points**

DP-001

Condition:
The current month is January, February, or March.

TRUE:
The copyright year is set to the current calendar year minus one, reflecting the financial year that began in the previous April.

FALSE:
The copyright year is set to the current calendar year, reflecting the financial year that began in April of this year.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - The copyright year shown on the form follows the Indian financial year (April-March), not the calendar year; months January-March display the prior year's number.
- SBR-002 - The copyright notice is always attributed to "Maruti Suzuki India Limited" and is not configurable at runtime.

---

**Implementation Logic**

```plsql
CREATE OR REPLACE
function sf_copyright_declaration return varchar is
a varchar2(50);
dt date;
begin
--Modified by Prerna on 16-May-11  to display current Financial Year Copyright
dt := sysdate;

    if( to_char(dt,'MON') in ('JAN','FEB','MAR')) then
        a := '© '||to_char(to_number(to_char(dt,'RRRR')) - 1)||' Maruti Suzuki India Limited ';
    else
        a := '© '||to_char(dt,'RRRR')||' Maruti Suzuki India Limited ';
    end if;
return(a);
end;

```

#### SP-064 - STRIPDIRSEP

**Invoked From:**

- webutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- webutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw file-system path string returned from a Windows API call by removing any semicolon-delimited suffix (keeping only the first path segment) and stripping any trailing backslash, so that callers receive a clean, consistently formatted directory path.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-042](#SP-042--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Copy the input path into a local working variable.
- Step 2 - Check whether the path contains a semicolon; if so, truncate it to everything before the first semicolon, discarding any additional path entries that may follow.
- Step 3 - Check whether the resulting path ends with a backslash character; if so, remove that trailing backslash.
- Step 4 - Return the cleaned path string to the caller.

---

**Decision Points**

DP-001

Condition:
The input path contains a semicolon (`';'`).

TRUE:
Truncate the path to the substring before the first semicolon, discarding all subsequent entries.

FALSE:
Leave the path unchanged and proceed to the trailing-backslash check.

DP-002

Condition:
The last character of the (possibly already truncated) path is a backslash (`'\'`).

TRUE:
Remove the trailing backslash from the path before returning it.

FALSE:
Return the path as-is.

---

**Database Interactions**

No database table interactions detected in the resolved source.

---

**Business Rules**

- SBR-001 - When a path string contains a semicolon, only the segment before the first semicolon is considered a valid directory path; all subsequent segments are discarded.
- SBR-002 - A directory path must not end with a trailing backslash; any such character is stripped before the value is returned to the caller.

---

**Implementation Logic**

```plsql

  Function StripDirSep ( InPath in varchar2) return varchar2 is 
    vcPath  varchar2(500) := InPath;
  begin 
    -- Check and Strip SemiColons, we take everything
    -- Before the first Semicolon as our path
    if instr(vcPath,';') > 0 then
      vcPath := substr(vcPath,1,instr(vcPath,';') -1);
    end if;

    -- Check and Strip '\'
    if substr(vcPath,-1,1) = '\' then 
      vcPath := substr(vcPath,1,length(vcPath)-1);
    end if;

    return vcPath;
  end StripDirSep;
```

#### SP-065 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- rr_pre_enq_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates a CSV report file from a query result and delivers it to the user's client machine for immediate opening, choosing between a server-side CSV generation path (when a report server is configured) and a Forms record-group-based path (when no report server is configured), and prompting the user for a save location when no filename is pre-supplied.

---

**Input Parameters**

| Input | Source | datatype |
|-------|--------|----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-020](#SP-020--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-021](#SP-021--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-023](#SP-023--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-029](#SP-029--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-033](#SP-033--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-034](#SP-034--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-045](#SP-045--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-052](#SP-052--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query `EH_REPORTS` for the report server (`rep_server`) associated with the given principal map code and application ID; if no row is found, default `lv_rep_server` to `NULL`.
- Step 2 - Branch on whether a report server is configured (`lv_rep_server IS NOT NULL`) to choose the server-side or the Forms record-group path.

**Server-side path (report server configured):**

- Step 3a - If no filename was supplied (`p_file_name IS NULL`), present a Save File dialog to the user via `Webutil_file.FILE_SAVE_DIALOG`; otherwise use the supplied name.
- Step 4a - Append `.csv` to the filename.
- Step 5a - If the resulting filename contains a space in any folder segment, redirect the save path to `C:\<filename_only>` and display a warning message to the user.
- Step 6a - Call the database link procedure `sp_csv_report_generate@dms1_db3_lnk` to generate the CSV on the server, passing the filename, query, and output variables for error reporting.
- Step 7a - Execute a shell command via `HOST` to move the generated file from the UTL directory (`/utl_dir/`) to the reports printer directory (`/iashome/ias/reports/printer/`).
- Step 8a - Open the `excelpath.txt` configuration file from `/reports/DMS/` to read the base URL, then close the file.
- Step 9a - Construct the full download URL by concatenating the base URL with the bare filename portion.
- Step 10a - Transfer the file from the server URL to the client destination via `WebUtil_File_Transfer.Url_To_Client`; if the transfer fails, display a failure message and pause.
- Step 11a - Open the downloaded CSV file on the client by issuing a `HOST` command (`cmd /c <filename>`).

**Forms record-group path (no report server configured):**

- Step 3b - If no filename was supplied, present a Save File dialog; otherwise use the supplied name.
- Step 4b - If the filename contains a space in any folder segment, redirect to `C:\<filename_only>` and display a warning message.
- Step 5b - Delete any pre-existing record group named `DataRecordSet` from the current Forms session.
- Step 6b - Create a new record group from the provided query and populate it.
- Step 7b - Determine the total row count of the populated record group.
- Step 8b - Open the `excelpath.txt` configuration file from `/reports/DMS/` to read the base URL, then close the file.
- Step 9b - Open a server-side output file for writing at the reports printer path.
- Step 10b - Find the designated column in the record group by name and iterate over all rows, writing each cell value followed by a newline character to the output file using `TEXT_IO.PUTF`.
- Step 11b - Close the output file.
- Step 12b - Construct the full download URL and transfer the file to the client via `WebUtil_File_Transfer.Url_To_Client`; if the transfer fails, display a failure message and pause.
- Step 13b - Open the downloaded CSV on the client via `HOST`.

**Exception handling:**

- Step 14 - If any unhandled exception occurs, display the Forms error code and error text, then raise `FORM_TRIGGER_FAILURE` to abort the trigger.

---

**Decision Points**

DP-001

Condition:
A report server entry (`rep_server`) exists in `EH_REPORTS` for the given `p_principal` and `p_app_id`.

TRUE:
Use the server-side CSV generation path (Steps 3a-11a), which delegates generation to `sp_csv_report_generate` on the linked database.

FALSE:
Use the Forms record-group path (Steps 3b-13b), which builds the CSV directly from a Forms record group populated by the supplied query.

DP-002

Condition:
`p_file_name` is NULL (either in the server-side or the record-group path).

TRUE:
Present the user with a Save File dialog (`FILE_SAVE_DIALOG`) to choose the destination.

FALSE:
Use the caller-supplied filename directly, without prompting.

DP-003

Condition:
The resolved filename contains a space character within any folder name segment.

TRUE:
Override the destination to `C:\<bare_filename>` and display a warning message that the file will be saved to the C drive instead of the intended path.

FALSE:
Use the filename as resolved, without path modification.

DP-004

Condition:
The file transfer from the server URL to the client (`WebUtil_File_Transfer.Url_To_Client`) returns `TRUE`.

TRUE:
Proceed to open the CSV on the client machine.

FALSE:
Display a "File Transfer failed" message and pause, alerting the user to the failure.

DP-005

Condition:
A record group named `DataRecordSet` already exists in the Forms session (record-group path only).

TRUE:
Delete the existing group before creating a new one from the current query, preventing duplicate group errors.

FALSE:
Proceed directly to creating the new record group.

---

**Database Interactions**

- DB-001 - Read eh_reports - retrieve the report server identifier (`rep_server`) associated with the supplied principal map code and application ID, to determine which CSV generation path to follow.

---

**Business Rules**

- SBR-001 - The destination filename must not contain spaces in any folder name; if it does, the file is automatically redirected to the root of the C drive and the user is notified.
- SBR-002 - The `.csv` extension is always appended to the filename in the server-side path, regardless of what the caller or the user supplies.
- SBR-003 - Any pre-existing Forms record group named `DataRecordSet` is unconditionally deleted and recreated before populating it with fresh query results, ensuring no stale data is written to the output file.
- SBR-004 - The base URL for file transfer is not hard-coded; it is read at runtime from the configuration file `/reports/DMS/excelpath.txt`, allowing the server path to be changed without modifying form code.
- SBR-005 - If the URL-to-client file transfer fails, the procedure does not silently continue - it explicitly notifies the user and pauses before attempting to open the file.
- SBR-006 - Any unhandled exception terminates the operation by raising `FORM_TRIGGER_FAILURE`, preventing partial or corrupt report delivery from appearing as a successful operation.

---

**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

---

# BRD Validation Report: No Show Customer Summary (VR_NSC_SUMM)

**Verdict:** PASS WITH FINDINGS  —  Overall fidelity: 97%

## Correction Loop Log

Round-by-round history of the automated QC feedback loop (generate → validate → correct → re-validate). One row per correction round; carried forward across re-validations so the final report shows the full round-by-round history. If the first verdict was already PASS, a single "no correction needed" row is recorded.

| Round | Verdict before | Findings addressed (IDs) | Verdict after |
| --- | --- | --- | --- |
| 1 | FAIL | 21-07, 21-09, 21-10, 21-11, 21-14, 21-17, 21-12, 21-13, 21-16, 21-18, 21-19, 20-11, 12-12, B-01, B-02, B-03, D-02, D-04, F-10, 8-01, 8-05, G-13, G-18 | PASS WITH FINDINGS |

**Purpose:** Standard review criteria validating this generated BRD against the Oracle Forms source XML and dependent artifacts (PLL/PLD, OLB, FMB/XML subclasses, PCK, PRC, FNC). For each checkpoint, compare the BRD to source and record whether anything is **missing**, **hallucinated / fabricated**, or **incorrect**; assign a Score (0–100% or N/A); and record a Recommendation with source evidence.

In each table below, record the Score in the Score column. Unless the score is 100%, fill **Missing / Hallucination / Incorrect** with the specific source-vs-BRD gap (missing item, fabricated claim, or incorrect detail, with source evidence). Then record the fix — scoped to the *existing* section only — plus supporting evidence in the Recommendation column: cite the extractor/coverage key + value, the BRD section (§N), or the real artifact name.

## Review Metadata

| Field | Value |
| --- | --- |
| Form Module | VR_NSC_SUMM |
| BRD File / Version | vr_nsc_summ_BRD.md (version 1.0, corrected Round 1) |
| Source Folder Reviewed | vr_nsc_summ_fmb.xml, n/a (no SQL dump), DPL_olb.xml, DPL.pld / n/a (no PCK in scope) |
| Reviewer | iBEAM oracle-form-brd-traceability skill |
| Review Date | 2025-01-31 |
| Overall Score (calculated at end) | 97% |
| Overall Result (PASS / PASS WITH FINDINGS / FAIL) | PASS WITH FINDINGS |

## Inventory & Count Reconciliation

"Count (Source Truth)" is from `xml.element_counts` (extract_metrics.py). "Count in BRD" is what the BRD §8 (and §5/§16/§17/§21 totals) state. Match = Yes only when they agree (or the difference is fully explained).

| Element Category | Count (Source Truth) | Count in BRD | Match | Severity | Comments |
| --- | --- | --- | --- | --- | --- |
| Form-level Triggers | 7 | 7 | Yes | — | PRE-FORM, KEY-CLRFRM, KEY-COMMIT, KEY-LISTVAL, KEY-EXIT, ON-MESSAGE, ON-ERROR |
| Block-level Triggers | 0 | 0 | Yes | — | No block-level triggers in source |
| Item-level Triggers | 8 | 8 | Yes | — | WHEN-BUTTON-PRESSED×2, KEY-NEXT-ITEM×3, WHEN-VALIDATE-ITEM×3 |
| Total Triggers | 15 | 15 | Yes | — | BRD §8.7 states "15 business triggers" |
| Active Triggers | 14 | 14 | Yes | — | 1 inactive (KEY-COMMIT) per extractor |
| Inactive Triggers | 1 | 1 | Yes | — | §8.7.1 lists KEY-COMMIT as inactive stub; ON-ERROR commented versions noted separately |
| Blocks | 1 | 1 | Yes | — | CB_BLK |
| Database Blocks | 0 | 0 | Yes | — | Control block only |
| Items / Fields | 10 | 10 | Yes | — | All 10 items in CB_BLK |
| LOVs | 0 | 0 | Yes | — | §8.4 correctly states no LOVs |
| Record Groups | 0 | 0 | Yes | — | §10 correctly states no record groups |
| Alerts | 1 | 1 | Yes | — | ALERT_BUT |
| Program Units | 5 | 5 | Yes | — | CALL_REPORT, VIEW_EXCEL_REP, POPULATE_ERRORS, CHECK_BEFORE_DELETE, VALIDATE_CN_MAIN |
| Parameters | 0 | 0 | Yes | — | §8.1.2 correctly states 0 |
| Editors | 0 | 0 | Yes | — | §8.9 correctly states none |
| Visual Attributes | 3 | 3 | Yes | — | VA_DISPLAY, VA_DEFAULT, VA_MANDATORY |
| Property Classes | 0 | 0 | Yes | — | §8.10.2 correctly states none form-local |
| Object Groups | 1 | 1 | Yes | — | OG_GROUP |
| DataSource Columns | 0 | 0 | Yes | — | §8.11 correctly states none |
| Canvases | 0 | 0 | Yes | — | §8.8 correctly states none |
| Windows | 0 | 0 | Yes | — | §8.8 correctly states none |
| Attached Libraries | 2 | 2 | Yes | — | DPL, D2KWUTIL |
| Database Tables | 0 | 0 | Yes | — | No base tables; §11 lists DUAL only (used in inline SQL) |
| Object Library objects | 43 | 43 | Yes | — | §9 catalogues 43 entries from DPL_olb.xml |
| SP Catalogue entries | 6 | 6 | Yes | — | §21.1 lists SP-001 through SP-006; extractor has 5 form-local + 1 external (SF_COPYRIGHT_DECLARATION) |

**Count fidelity: 25/25 categories match (100%).**

## Inventory Coverage in the BRD

Does the BRD actually document each inventoried category, and where? "Documented" comes from `check_coverage.py` (`_coverage.json`).

| Inventory Category | Source Count | Documented (covered/total) | BRD Section(s) | Coverage % | Missing names / Comments |
| --- | --- | --- | --- | --- | --- |
| Blocks | 1 | 1/1 | §8.2 | 100% | — |
| Items / Fields | 10 | 10/10 | §8.3 | 100% | — |
| Program Units | 5 | 5/5 | §8.6, §21 | 100% | — |
| LOVs | 0 | 0/0 | §8.4 | 100% | N/A — no LOVs in source |
| Record Groups | 0 | 0/0 | §10 | 100% | N/A — no record groups in source |
| Alerts | 1 | 1/1 | §8.5 | 100% | — |
| Editors | 0 | 0/0 | §8.9 | 100% | N/A — no editors in source |
| Parameters | 0 | 0/0 | §8.1.2 | 100% | N/A — no parameters in source |
| Canvases | 0 | 0/0 | §8.8 | 100% | N/A — no canvases in source |
| Windows | 0 | 0/0 | §8.8 | 100% | N/A — no windows in source |
| Attached Libraries | 2 | 2/2 | §8.1 | 100% | — |
| Visual Attributes | 3 | 3/3 | §8.10.1 | 100% | — |
| Property Classes | 0 | 0/0 | §8.10.2 | 100% | N/A — no form-local property classes |
| Object Groups | 1 | 1/1 | §8.10.3 | 100% | — |
| Database Tables | 0 | 0/0 | §11 | 100% | — |
| Package call-sites | 0 | 0/0 | §12, §14, §19 | 100% | N/A — no PCK-level call sites in scope |
| Globals | 6 | 6/6 | §8.1.1 | 100% | APP_LOG, CUR_DATE, PARENT_GROUP, PRINCIPAL, REP_SERVER, USERID |

**Inventory coverage: 17/17 categories fully documented (check_coverage.py: PASS).**

---

## A. Preconditions & Source Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| A-01 | Has every file in the source folder been inventoried before BRD review begins? | 100% | | |

---

## B. Cross-Cutting Validation Rules (apply to every section)

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| B-01 | Is every factual statement in the BRD directly supported by source or logically derived from it? | 95% | **Incorrect (minor)**: §8.1 Console Window is now correctly documented as "WN_MAIN (inherited from DPL parent via PC_FORM property class; ConsoleWindow XML attribute not set directly on this form module)". The XML `console_window` attribute is empty (`xml.console_window = ""`), and the runtime title note is accurate. This minor presentation gap is now within acceptable range. | No further change needed; the notation is now accurate. |
| B-02 | Is there no hallucinated object, field, parameter, message, table, or procedure name anywhere in the document? | 100% | | |
| B-03 | Are inactive / commented / `NULL` units and triggers not described as active behaviour? | 100% | | |
| B-04 | Are "Not Available" / N/A markings used only when the value truly cannot be derived from source? | 100% | | |
| B-05 | Where a value is derivable from source is it filled instead of left as N/A? | 100% | | |
| B-06 | Are counts in the BRD consistent with source element counts? | 100% | | |
| B-07 | Are naming conventions consistent with source identifiers (case-insensitive match to real names)? | 100% | | |
| B-08 | Are dependency chains closed through the nth level of dependencies? | 100% | | |
| B-09 | Are all user-facing messages/alerts traced to actual source definitions? | 100% | | |
| B-10 | Is business language used throughout without inventing business policy not evidenced in code? | 100% | | |
| B-11 | Is every table and column name in the BRD verifiable against source files? | 100% | | |
| B-12 | Are all trigger names, program unit names, procedure names, function names, and parameter names consistent with the exact identifiers in the source? | 100% | | |
| B-13 | Are description/purpose columns written in plain business language? | 100% | | |
| B-14 | Is each field/message/element documented only within the business requirement the source assigns it to? | 100% | | |
| B-15 | Does the BRD contain only the standard sections 1 through 21.2 in order? | 100% | | |

---

## 1. Document Control

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 1-01 | Does Document Title correctly identify the form/module? | 100% | | |
| 1-02 | Are Document Version and Date present and current? | 100% | | |
| 1-03 | Is Author / Prepared recorded? | 100% | | |
| 1-04 | Are source artifact references listed? | 100% | | |

---

## 2. Executive Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 2-01 | Does the summary correctly state the form's business purpose as implemented? | 100% | | |
| 2-02 | Does it identify the primary transaction/document type(s) from source? | 100% | | |
| 2-03 | Does it accurately summarize behaviours that exist in source? | 100% | | |
| 2-04 | Does it avoid claiming features that are inactive, orphaned, or absent in source? | 100% | | |
| 2-05 | Are Key Stakeholders / roles restricted to actors that genuinely interact with or are referenced by the form? | 100% | | |
| 2-06 | Is the Stakeholder table written in business-friendly language? | 100% | | |
| 2-07 | Does the Stakeholder table contain the columns: Stakeholder, Role? | 100% | | |
| 2-08 | Is the Executive Summary written entirely in plain, non-technical business language? | 100% | | |

---

## 3. System Context

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 3-01 | Is System Purpose aligned with implemented functionality? | 100% | | |
| 3-02 | Is In-Scope strictly limited to behaviours evidenced in source? | 100% | | |
| 3-03 | Are Process Name, Objective, Trigger, and Process Owner grounded in actual form entry points and flows? | 100% | | |
| 3-04 | Does Process Flow sequence match the real trigger/program-unit/procedure/function call and navigation order in source? | 100% | | |
| 3-05 | Are Process Flow steps mapped to BR-IDs in Section 4? | 100% | | |
| 3-06 | Are Major Process Interactions written in business-friendly language? | 100% | | |
| 3-07 | Does System Context avoid repeating content already covered in Executive Summary? | 100% | | |
| 3-08 | Is the System Context narrative written in plain business language? | 100% | | |

---

## 4. Functional Requirements

### 4.1 Requirement Catalogue Completeness

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-01 | Are Requirement IDs sequential, and are steps within the Main Flow sequential within each requirement based on source? | 100% | | |
| 4-02 | Are BR IDs unique, sequential, and consistently cross-referenced throughout? | 100% | | |
| 4-03 | Do BR titles accurately reflect the implemented capability without overstating scope? | 100% | | |
| 4-04 | Are all triggers covered, with their full logic documented as part of the respective functional requirement? | 100% | | |
| 4-05 | Are all actors that appear in the form source represented, and are actors not relevant to the source removed? | 100% | | |

### 4.2 Per-Requirement Content Quality

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-07 | Are Requirement ID, Title, Business Description, Actors, and Preconditions present for every BR? | 100% | | |
| 4-08 | Is the Business Description written in business-friendly language? | 100% | | |
| 4-09 | Do Actors match realistic form users and system roles implied by the module? | 100% | | |
| 4-10 | Do Preconditions match actual form state requirements in business-friendly English? | 100% | | |
| 4-11 | Does Main Flow follow the real trigger/program-unit/procedure/function execution sequence from source? | 100% | | |
| 4-12 | Are Main Flow step numbers sequential, continuous, and non-repeating within each BR? | 100% | | |
| 4-13 | Are procedures/functions referenced within Main Flow steps linked to their SP-XXX entries? | 100% | | |
| 4-14 | Are all success, error, warning, and informational messages captured as Business Outcome codes within appropriate steps? | 100% | | |
| 4-15 | Do Business Outcome codes include the actual message text from source? | 100% | | |
| 4-16 | Are Alternative Flows included only when source contains a real branching path? | 100% | | |
| 4-17 | Are Alternative Flow and Error/information/status Flow IDs unique and sequential within each BR? | 100% | | |
| 4-18 | Does the Data Elements table list only real block.item fields from source? | 100% | | |
| 4-19 | Are Field State values justified by source validations and item properties? | 100% | | |
| 4-20 | Is the Description/Purpose column written in business-friendly language? | 100% | | |
| 4-21 | Are lookup entities correctly named from xml when referenced in Data Elements? | 100% | | |
| 4-22 | Are validation rules traceable to triggers, functions, procedures, program units, or DB procedures? | 100% | | |
| 4-23 | Is save/commit/delete/cancel/print behaviour described only if coded in source? | 100% | | |
| 4-24 | Are configurations explained in business-friendly language? | 100% | | |

### 4.3 Critical Functional Themes

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 4-25 | Are all messages that are in form scope from the sources captured and included in the appropriate requirements? | 100% | | |
| 4-26 | Is the sequence of requirement IDs and steps within the Main Flow correct? | 100% | | |
| 4-27 | Is all end-to-end logic of every active trigger and program unit captured within a BR? | 100% | | |
| 4-28 | Is the business-friendly content relevant to the source? | 100% | | |
| 4-29 | Are all procedures/functions called in the Main Flow named in the relevant step, linked to the matching SP-XXX? | 100% | | |
| 4-30 | Are Alternative Flows written in business-friendly language and accurate/relevant to the source? | 100% | | |
| 4-31 | Is the validation table limited to rules that apply to this BR's context and fields? | 100% | | |
| 4-32 | Does the validation table contain the columns: Validation, Technical Reference, Trigger, Business Purpose, Failure Outcome? | 100% | | |
| 4-33 | Does the Data Elements table contain the required columns? | 100% | | |
| 4-34 | Are generic/common system behaviours excluded from being standalone functional requirements? | 100% | | |

---

## 5. Business Rules Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 5-01 | Does every validation and decision in source appear as a business rule? | 100% | | |
| 5-02 | Does each BRC row include all required columns? | 100% | | |
| 5-03 | Is the Condition column written in business-friendly language? | 100% | | |
| 5-04 | Is the Action column written in business-friendly language? | 100% | | |
| 5-05 | Is the Business Impact column detailed and in plain business language? | 100% | | |
| 5-06 | Are rule conditions/actions faithful to actual source logic? | 100% | | |
| 5-07 | Are inactive or commented-out constraints documented as inactive? | 100% | | |
| 5-08 | Are external/unverifiable dependencies documented as dependency rules? | 100% | | |
| 5-09 | Is there no BRC entry that invents policy not present in code? | 100% | | |
| 5-10 | Is the Business Requirement ID column populated for every rule? | 100% | | |
| 5-11 | Does the BRC table contain the required columns? | 100% | | |

---

## 6. Data Requirements

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 6-01 | Are master/detail entities mapped to real base tables and blocks from source? | 100% | | |
| 6-02 | Are mandatory/autopopulated flags consistent with source? | 100% | | |
| 6-03 | Are field descriptions free of fabricated business meanings? | 100% | | |
| 6-04 | Are the Used By and Purpose columns detailed and relevant to source? | 100% | | |
| 6-05 | Are create/update/query data behaviours aligned with block DML settings and triggers? | 100% | | |
| 6-06 | If a Mandatory column value is stated as conditional, is the condition mentioned? | 100% | | |
| 6-07 | Are entity descriptions in 6.1 written in business-friendly language? | 100% | | |
| 6-08 | Are data lifecycle states (6.4) consistent with status codes and transitions evidenced in source? | 100% | | |
| 6-09 | Are all table names and column names in Section 6 verifiable against source SQL? | 100% | | |
| 6-10 | Does the data capture table (6.2) contain the required columns? | 100% | | |
| 6-11 | Does the reference data table (6.3) contain the required columns? | 100% | | |

---

## 7. Glossary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 7-01 | Are glossary terms limited to terms actually used in the form and BRD? | 100% | | |
| 7-02 | Are definitions consistent with relevant source usage? | 100% | | |
| 7-03 | If those terms exist, do they match actual source values? | 100% | | |
| 7-04 | Are there no glossary entries that invent domain meanings not evidenced in source? | 100% | | |
| 7-05 | Are all acronyms that appear in the BRD defined in the glossary? | 100% | | |
| 7-06 | Does the glossary table contain the required columns? | 100% | | |

---

## 8. Technical Inventory

### 8.1 Form Architecture

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-01 | Do Form Module Name and Title match source attributes exactly? | 95% | **Incorrect (minor, residual)**: §8.1 now correctly documents the XML Title attribute as "MODULE2" and notes that the runtime screen title is assigned by KEY-CLRFRM. The original discrepancy is resolved; a minor presentation gap remains in that the Console Window entry still uses "WN_MAIN" though the XML `console_window` attribute is empty (WN_MAIN is inherited). The note explaining this is now present. | The current notation accurately reflects the source; no further change needed. |
| 8-02 | Is Oracle Forms version recorded from source when available? | 100% | | |
| 8-03 | Are Parent OLBs mentioned correctly? | 100% | | |
| 8-04 | Are Attached Libraries exactly the source attached libraries? | 100% | | |
| 8-05 | Is Console Window / First Navigation Block correct? | 95% | **Incorrect (minor, residual)**: `xml.console_window` is empty in source; the BRD now correctly notes WN_MAIN is inherited from DPL. The gap is documented and explained. | No further change needed; the BRD now notes the inheritance correctly. |
| 8-06 | Do the source artifacts correctly include all the dependencies? | 100% | | |

### 8.1.1 Global Variables

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-07 | Are GLOBAL variables limited to those actually referenced in the form? | 100% | | |
| 8-08 | Is the Description/Purpose column for each global variable written in plain business language? | 100% | | |
| 8-09 | Does the tabular structure contain the columns: Global Variable, Data Type, Set Location, Purpose? | 100% | | |
| 8-10 | Are all global variables and their values correctly derived from the sources? | 100% | | |

### 8.1.2 Form Parameters

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-11 | Does the parameter list match ModuleParameter names exactly? | 100% | | |
| 8-12 | Are ParameterInitializeValue defaults captured correctly? | N/A | No parameters in source; §8.1.2 correctly states 0 parameters. | |
| 8-13 | Are all parameters in the form captured in this section? | 100% | | |
| 8-14 | Is the Description/Purpose column for each parameter written in plain business language? | N/A | No parameters exist in the form source. | |
| 8-15 | Does the tabular structure contain the required columns? | N/A | No parameters to tabulate. | |

### 8.2 Blocks

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-16 | Does the tabular structure contain the required columns? | 100% | | |
| 8-17 | Do all block names match source exactly and vice versa? | 100% | | |
| 8-18 | Are Query Data Source, master-detail relationship and RecordsDisplayCount correct? | 100% | | |
| 8-19 | Are query, insert, update, and delete correctly identified? | 100% | | |

### 8.2.1 Block WhereClause and OrderByClause

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-20 | Are all WhereClause and OrderByClause values transcribed accurately? | 100% | | |
| 8-21 | Are blocks with no WhereClause / OrderByClause correctly shown as blank? | 100% | | |
| 8-22 | Does the tabular structure contain the required columns? | N/A | §8.2.1 states no blocks with WhereClause or OrderByClause, consistent with source. No table needed. | |
| 8-23 | Is the Description/Purpose column written in plain business language? | N/A | No WhereClause/OrderByClause blocks to document. | |

### 8.3 Items Summary

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-24 | Does item inventory cover all source items? | 100% | | |
| 8-25 | Are Database Item flags and item types consistent with source? | 100% | | |
| 8-26 | Is the Description/Purpose column for each item written in business-friendly language? | 100% | | |
| 8-27 | Does the tabular structure of the item summary contain the required columns? | 100% | | |
| 8-28 | Does the tabular structure of the item detail contain the required columns? | 100% | | |

### 8.4 List of Values

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-29 | Are all LOVs, their titles, and attached items listed? | 100% | | |
| 8-30 | Does the tabular structure contain the required columns? | N/A | No LOVs in source. | |

### 8.5 Alerts

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-31 | Are all Alerts listed with titles/buttons/messages from source? | 100% | | |
| 8-32 | Is alert calling context accurate to the source? | 100% | | |
| 8-33 | Does the tabular structure contain the required columns? | 100% | | |

### 8.6 Program Units

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-34 | Are all form Program Units from source listed with names? | 100% | | |
| 8-35 | Is active vs. inactive status correct for each program unit? | 100% | | |
| 8-36 | Is the Description/Purpose column written in business-friendly language? | 100% | | |
| 8-37 | Does the tabular structure contain the required columns? | 100% | | |

### 8.7 Triggers

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-38 | Does all triggers from source covered, with inactive triggers properly identified? | 100% | | |
| 8-39 | Are trigger purposes consistent with TriggerText content? | 100% | | |
| 8-40 | Is the Description/Purpose column written in business-friendly language? | 100% | | |
| 8-41 | Are all triggers referred to within the form properly captured? | 100% | | |
| 8-42 | Does the trigger inventory table contain the required columns? | 100% | | |
| 8-43 | Does the trigger-called-routines table contain the required columns? | 100% | | |

### 8.7.1 Inactive / Commented-Out Trigger Register

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-44 | Is the inactive-trigger register present and complete by name? | 100% | | |
| 8-45 | Are all commented-out and NULL-body triggers identified and clearly marked as inactive? | 100% | | |
| 8-46 | Does the inactive-trigger register contain the required columns? | 100% | | |
| 8-47 | Does the Complete trigger inventory contain the required columns? | 100% | | |

### 8.8 Canvas and Window Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-48 | Are all Canvases and Windows listed? | 100% | | |
| 8-49 | Are all canvas and windows present in source documented? | 100% | | |
| 8-50 | Does the window inventory contain the required columns? | N/A | No windows in source XML. | |
| 8-51 | Does the canvas inventory contain the required columns? | N/A | No canvases in source XML. | |

### 8.9 Editors

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-52 | Are all Editors correctly stated? | 100% | | |
| 8-53 | Does the editors table contain the required columns? | N/A | No editors in source. | |

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-54 | Are Visual Attributes, Property Classes, and Object Groups counted and named correctly? | 100% | | |
| 8-55 | Are unused/inherited items distinguished from locally applied ones? | 100% | | |
| 8-56 | Are Visual Attributes, Property Classes, and Object Groups listed with the expected column structures? | 100% | | |

### 8.11 DataSourceColumn Inventory

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 8-57 | Are DataSource columns for each datasource properly taken from the sources? | 100% | | |
| 8-58 | Are column names and datatypes consistent with source block definitions? | N/A | No DataSourceColumns in source; §8.11 correctly states none. | |
| 8-59 | Does the DataSourceColumn table contain the required columns? | N/A | No DataSourceColumns to tabulate. | |

---

## 9. Object Library

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 9-01 | Are OLB-sourced objects distinguished from form-local objects? | 100% | | |
| 9-02 | Does the tabular structure contain the required columns? | 100% | | |
| 9-03 | Are descriptions relevant to the source? | 100% | | |

---

## 10. Record Groups

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 10-01 | Are all Record Groups in source counted and listed? | 100% | | |
| 10-02 | Is LOV linkage correct for all record groups? | N/A | No record groups in source. | |
| 10-03 | Does the tabular structure contain the required columns? | N/A | No record groups to tabulate. | |
| 10-04 | Are the Purpose and Where Used columns written in business-friendly language? | N/A | No record groups in source. | |

---

## 11. Referenced Database Objects

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 11-01 | Are block base tables and primary keys correct? | 100% | | |
| 11-02 | Are additional tables limited to those referenced in SQL/DML? | 100% | | |
| 11-03 | Is there no fabricated table? | 100% | | |
| 11-04 | Is the Description column written in business-friendly language? | 100% | | |
| 11-05 | Does the block/base-table table contain the required columns? | N/A | No database blocks; no base-table inventory applicable. | |
| 11-06 | Does the database objects table contain the required columns? | 100% | | |

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure / Package Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-01 | Are all form-local program units included in the index? | 100% | | |
| 12-02 | Are all DB procedures/functions/packages called by the form included? | 100% | | |
| 12-03 | Are library package calls (e.g., GENERAL.*) covered? | 100% | | |
| 12-04 | Are inactive units labeled inactive and mentioned in descriptions? | 100% | | |
| 12-05 | Are external/not-in-bundle routines labeled as unverifiable dependencies? | 100% | | |
| 12-06 | Is call direction (who calls whom) correct for the main business flows? | 100% | | |
| 12-07 | Is the Purpose/Description column written in business-friendly language? | 100% | | |
| 12-08 | Does the main-flow backend index contain the required columns? | 100% | | |

### 12.2 Procedure and Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 12-09 | Does the catalogue include all procedures/packages from the index? | 100% | | |
| 12-10 | Is the Description/Purpose column for each catalogue entry written in plain business language? | 100% | | |
| 12-11 | Are the classification values correct against the sources? | 100% | | |
| 12-12 | Does the tabular structure contain the columns: Procedure/Package Name, Called From, Purpose, Classification? | 100% | | |

---

## 13. Package Procedure Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 13-01 | Are supplied `.pck` sources listed and summarized accurately? | 100% | | |
| 13-02 | Do documented package entry points match the package specification/body? | N/A | No PCK routines invoked from this form. §13 correctly states no package routines referenced. | |
| 13-03 | Are the Acceptance criteria in business-friendly language? | N/A | No PCK routines to evaluate. | |
| 13-04 | Are packages referenced in XML but missing from the bundle explicitly noted? | 100% | | |
| 13-05 | Does the tabular structure contain the required columns? | N/A | No PCK routines applicable. | |

---

## 14. Database Package Catalogue

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 14-01 | Does the catalogue include only packages evidenced by source calls or supplied files? | 100% | | |
| 14-02 | Are package purposes derived from actual procedure logic? | N/A | No PCK routines referenced from this form. | |
| 14-03 | Is the Called From definition properly given? | N/A | No PCK routines applicable. | |
| 14-04 | Does the tabular structure contain the required columns? | N/A | No PCK routines applicable. | |
| 14-05 | Does the function-values table contain the required columns? | N/A | No PCK routines applicable. | |

---

## 15. PLD Procedure Call Sites

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 15-01 | Are all attached PLD libraries identified correctly? | 100% | | |
| 15-02 | Are all observed call sites listed? | 100% | | |
| 15-03 | Are inactive/commented-only PLD call sites distinguished from active ones? | 100% | | |
| 15-04 | Is the Description column written in business-friendly language covering end-to-end logic? | 100% | | |
| 15-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 16-01 | Is each microservice candidate clearly derived from a real form or DB capability? | 100% | | |
| 16-02 | Are input/output fields limited to data actually used by the capability? | 100% | | |
| 16-03 | Is the API Endpoint Suggestion actually relevant and needed? | 100% | | |
| 16-04 | Is the Business Function column written in business-friendly language? | 100% | | |
| 16-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 17. Workflows

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 17-01 | Do workflows correspond to real end-to-end paths in the form? | 100% | | |
| 17-02 | Are step sequences consistent with Section 3 process flow, Section 4 BRs and grounded to source? | 100% | | |
| 17-03 | Are decision points aligned with source branches? | 100% | | |
| 17-04 | Are the steps business-friendly and accurate based on the sources? | 100% | | |
| 17-05 | Does the tabular structure contain the required columns? | 100% | | |

---

## 18. PLD-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 18-01 | Are PLD-backed rows limited to routines actually invoked in source? | 100% | | |
| 18-02 | Does the Business Rule Summary accurately define business rules? | 100% | | |
| 18-03 | Are confirmation/message texts quoted accurately? | 100% | | |
| 18-04 | Does the tabular structure contain the required columns? | 100% | | |

---

## 19. PCK-Backed Logic

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 19-01 | Are PCK-backed rows limited to package routines actually invoked? | 100% | | |
| 19-02 | Are package behaviours correctly described? | N/A | No PCK routines invoked. §19 correctly states none. | |
| 19-03 | Is there no fabricated or hallucinated content? | 100% | | |
| 19-04 | Does the Business Rule Summary accurately define business rules? | N/A | No PCK routines invoked. | |
| 19-05 | Does the tabular structure contain the required columns? | N/A | No PCK routines applicable. | |

---

## 20. System Interfaces

### 20.1 Database Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-01 | Are DB table interfaces limited to real DML/SQL targets? | 100% | | |
| 20-02 | Is the Error Handling/Purpose column written in business-friendly language? | 100% | | |
| 20-03 | Does §20.1 contain only the required columns? | 100% | | |

### 20.2 External System Integrations

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-04 | Are external system integrations limited to those evidenced in source code? | 100% | | |
| 20-05 | Do external integrations include endpoint details, data exchange, and error/success codes? | 100% | | |
| 20-06 | Does §20.2 contain only the required columns? | 100% | | |
| 20-07 | Is the Data Exchange/Purpose column written in business-friendly language? | 100% | | |
| 20-08 | Are all Success / Error Codes relevant to sources and correctly mapped? | 100% | | |

### 20.3 Report Integrations

Ground truth: `_report_ground_truth.json` — actual report file names: `["rep.rdf", "vr_nsc_summ"]`.

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 20-09 | Are report interfaces limited to actual report file names evidenced in source — no report-object handles, variables, or API names? | 100% | §20.3 now lists "vr_nsc_summ" (plsql_invocation) and "rep.rdf" (xml_report_object). Both are evidenced in `_report_ground_truth.json`. No report-object handles are presented as report filename rows. | |
| 20-10 | Does the trigger column for each report contain the actual trigger/program unit whose code invokes that report filename? | 100% | Both §20.3 rows cite CALL_REPORT program unit, which is evidenced in source. | |
| 20-11 | Are all report filenames in `report_filenames[]` correctly captured in §20.3? | 100% | Both `report_filenames[]` entries (`rep.rdf` and `vr_nsc_summ`) are now documented in §20.3. | |
| 20-12 | Does §20.3 contain only the required columns? | 100% | | |

---

## 21. Procedure and Function Business Rule Catalogue

### 21.1 Catalogue Index

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-01 | Does the SP index cover all form program units, procedures, functions, and key DB/library routines? | 100% | | |
| 21-02 | Is each SP mapped to a real routine name in source? | 100% | | |
| 21-03 | Are SP-XXX IDs strictly sequential (SP-001, SP-002, …) with no gaps? | 100% | | |
| 21-04 | Are Invoked From references and Screen/Canvas references correct? | 100% | | |
| 21-05 | Are inactive SPs explicitly labeled inactive in the index? | 100% | | |

### 21.2 Detailed Specifications

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| 21-06 | Does each SP-XXX detailed specification match the correct routine? | 100% | | |
| 21-07 | Is the Purpose section written in plain business language? | 100% | All six SP specs (SP-001 through SP-006) now have authored Purpose fields grounded in the Implementation Logic. | |
| 21-08 | Are Input and Output Parameter tables complete? | 100% | All SP Input Parameters tables now use Input/Source/datatype columns. SP-006 now has an Output Parameters table with the return value row. | |
| 21-09 | Are Step-by-Step Business Logic steps sequential, written entirely in business English, and aligned with the actual execution order? | 100% | All six SP specs now have Step-by-Step Business Logic authored from the Implementation Logic. | |
| 21-10 | Does every IF/ELSIF/CASE condition in the source body appear as a Decision Point? | 100% | All six SP specs now have Decision Points documenting every IF/ELSIF/CASE branch from the source. | |
| 21-11 | Are Decision Point conditions written in business-friendly language? | 100% | All Decision Points are authored in business-friendly language, not raw PL/SQL. | |
| 21-12 | Are Database Interactions complete for every table referenced? | 100% | SP-005 `am_permissions` row is now correctly labeled as from inactive/commented-out code. All other SPs correctly state no DB interactions. | |
| 21-13 | Are all table names and column names in Database Interactions verifiable against actual SQL? | 100% | The `am_permissions` reference is now labeled as inactive/commented-out, not as a live database interaction. | |
| 21-14 | Are Business Rules within each SP written in plain business language? | 100% | All six SP specs now have Business Rules authored in plain business language. | |
| 21-15 | Is the Implementation Logic section free of any additional code? | 100% | | |
| 21-16 | Are dependency levels documented where a procedure calls other procedures/functions? | 100% | SP-001 and SP-002 now list all Oracle Forms built-in callees as Level 1 dependencies. SP-003 and SP-005 list GENERAL.DISP_TEXT as SP-004. | |
| 21-17 | Are messages displayed by the routine captured within the Step-by-Step business logic? | 100% | All message strings are documented within the Step-by-Step Business Logic steps for each SP. | |
| 21-18 | Does each Input Parameters table contain the columns: Input, Source, datatype? | 100% | All SP Input Parameters tables now use the required Input/Source/datatype columns. | |
| 21-19 | Does each Output Parameters table contain the columns: Output, Source, datatype? | 100% | SP-006 now has an Output Parameters table with Output/Source/datatype. All other SPs have Output tables noting no return value. | |
| 21-20 | Is each SP-XXX's Purpose/Step-by-Step Business Logic documented in exactly one place? | 100% | | |
| 21-21 | Are inactive/commented out procedures marked as inactive? | 100% | | |

---

## C. Message & Alert Sweep

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| C-01 | Have all active DISP_TEXT / ASK_CONFIRM / message strings been identified? | 100% | | |
| C-02 | Are success/note messages documented only if present in source? | 100% | | |
| C-03 | Are commented/inactive messages explicitly marked inactive? | 100% | | |
| C-04 | Are alert titles and buttons taken from form or source definitions? | 100% | | |
| C-05 | Are severity labels consistent with source usage? | 100% | | |
| C-06 | Is there no fabricated success, error, or information message? | 100% | | |
| C-07 | Are all onscreen messages captured within the Main Flow steps of the relevant BR? | 100% | | |

---

## D. Active vs. Inactive Integrity

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| D-01 | Is every inactive trigger identified and excluded from the active flow narrative? | 100% | | |
| D-02 | Is every inactive program unit identified and mentioned as inactive? | 100% | | |
| D-03 | Are "dead" alternative flows removed or clearly marked as historical/inactive? | 100% | | |
| D-04 | Is commented-out code clearly labeled as inactive wherever referenced? | 100% | | |

---

## E. Traceability & Consistency

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| E-01 | Do all BR-IDs used in Process Flow, BRC, and SP sections exist in Section 4? | 100% | | |
| E-02 | Do all BRC rows reference valid BR-IDs? | 100% | | |
| E-03 | Do SP specs reference valid BR-IDs where claimed? | 100% | | |
| E-04 | Are element counts in the Technical Inventory internally consistent? | 100% | | |
| E-05 | Are BRC-IDs referenced back from the relevant BR Main Flow steps? | 100% | | |
| E-06 | Are SP-XXX IDs referenced from the BR Main Flow steps where the procedure is called? | 100% | | |

---

## F. Hallucination / Unsupported Content Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| F-01 | No invented ModuleParameters or globals? | 100% | | |
| F-02 | No invented tables or views? | 100% | | |
| F-03 | No invented procedures or packages? | 100% | | |
| F-04 | No invented LOVs, record groups, alerts, blocks, or items? | 100% | | |
| F-05 | No invented business statuses or codes beyond source literals? | 100% | | |
| F-06 | No invented UI messages? | 100% | | |
| F-07 | No claims of cascade delete / full edit / print / save behaviour absent from source? | 100% | | |
| F-08 | No "Not Available" where value is present in XML or derivable from subclass/OLB? | 100% | | |
| F-09 | No actors, roles, or stakeholders not referenced in form source or dependent code? | 100% | | |
| F-10 | No business rules or configuration values stated as fact when not present in source? | 100% | | |

---

## G. Feedback-Tracker Generic Checkpoints

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| G-01 | Are functional requirements correctly mapped to their corresponding business rules? | 100% | | |
| G-02 | Does the Business Rules Catalogue include a brief description of purpose for each package referenced? | 100% | | |
| G-03 | Are all references to out-of-scope modules removed? | 100% | | |
| G-04 | Are all actors validated against the form source? | 100% | | |
| G-05 | Is the document scope strictly aligned to this specific form? | 100% | | |
| G-06 | Are all BR requirement IDs unique and sequential? | 100% | | |
| G-07 | Are Actors and Preconditions defined for every functional requirement? | 100% | | |
| G-08 | Are field-level UI elements and data elements captured for each requirement? | 100% | | |
| G-09 | Are explanations and validations specific to the form? | 100% | | |
| G-10 | Do Alternative Flows reference Main Flow steps rather than repeating Main Flow content? | 100% | | |
| G-11 | Does every Alternative Flow and Business Outcome have a unique serial ID? | 100% | | |
| G-12 | Is the Main Flow sequence correct and logical? | 100% | | |
| G-13 | Are data objects explained with their business logic, rules applied, and purpose? | 100% | | |
| G-14 | Is business terminology used strictly consistent with the source XML? | 100% | | |
| G-15 | Are all XML elements present in the source captured in the BRD? | 100% | | |
| G-16 | Are all processes defined in the XML covered in the BRD? | 100% | | |
| G-17 | Are all data objects referenced in the relevant Main Flow step, with SP ID linked to Section 21.2? | 100% | | |
| G-18 | Are the step-by-step business logics of all stored procedures described in plain business English within Section 21.2? | 100% | | |
| G-19 | Are all configurations explained in business-friendly language? | 100% | | |
| G-20 | Are all onscreen success, error, warning, and info messages captured within the Main Flow steps with unique sequential codes? | 100% | | |
| G-21 | Is the exact message text from source captured in each Business Outcome? | 100% | | |
| G-22 | Is every active trigger fully covered in the BRD? | 100% | | |
| G-23 | Do external system integration entries include endpoints, data exchange, and error/success codes? | 100% | | |
| G-24 | Are field conditional vs. mandatory vs. auto-populated states explained in detail? | 100% | | |
| G-25 | Are all missing fields included and all unused fields removed from data element tables? | 100% | | |
| G-26 | Is the stored procedure logic in Section 21.2 consistent with the actual source? | 100% | | |
| G-27 | Are the SP-XXX IDs in Section 21.2 strictly sequential? | 100% | | |
| G-28 | Is each stored procedure's business logic explanation documented once (Section 21.2)? | 100% | | |
| G-29 | Are generic/common system behaviours kept out of the functional requirement catalogue as standalone requirements? | 100% | | |

---

## H. Cross-BRD Template & Consistency Gate

| # | Checkpoint | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ---------- | --------------------- | ----------------------------------- | -------------- |
| H-01 | Does the structure of recurring sections match the standard template? | N/A | No second BRD available for cross-template comparison in this run. | |
| H-02 | Do overall section numbering and heading hierarchy match the standard BRD template? | N/A | No comparison BRD available. | |
| H-03 | Are cross-cutting rules applied identically to other BRDs? | N/A | No comparison BRD available. | |

---

## I. Client Acceptance Summary

| # | Acceptance Question | Score (0–100% or N/A) | Missing / Hallucination / Incorrect | Recommendation |
| - | ------------------- | --------------------- | ----------------------------------- | -------------- |
| I-01 | Completeness: Does the BRD cover all implemented functionality, procedures, triggers, program units and all elements? | 98% | Minor residual: §8.1 form title and console window annotation are now accurate with explanatory notes; no material gaps remain. | No change needed. |
| I-02 | Correctness: Are documented behaviours, inventories, and logics end-to-end factually accurate vs. source? | 97% | **Minor residual**: §8.05 Console Window still annotated as inherited (accurate but not directly traceable to a single XML attribute). SP-005 Business Rule BR-002 notes the get_message call is commented out — this is an accurate reflection of the source's current state. | No change needed. |
| I-03 | Coverage: Are all major flows, rules, messages, triggers, functions, procedures, and technical objects represented? | 100% | | |
| I-04 | Traceability: Can each major BRD claim be traced to a source artifact? | 100% | | |
| I-05 | Integrity: Are inactive/external/commented items correctly classified throughout? | 100% | | |
| I-06 | Fit for use: Is the BRD acceptable as the baseline for client and modernization planning? | 97% | Minor: §8.1 console window notation is technically accurate (inherited from DPL parent). §21.2 SP-005 business rule BR-002 correctly notes that the message lookup is commented out. Both are accurate observations that inform modernisation planning. | No change needed. |

---

## Final Sign-off

| Role | Name | Date | Status (Approved / Approved with gaps / Rejected) |
| --- | --- | --- | --- |
| Business Analyst / Reviewer | iBEAM oracle-form-brd-traceability skill | 2025-01-31 | Approved with gaps — PASS WITH FINDINGS: minor residual on §8.01/8.05 (console window inherited from DPL parent, XML attribute empty); all major findings from Round 1 resolved |
| Technical Validator | [To be assigned] | | |
| Client / Stakeholder | [To be assigned] | | |

**Checkpoints scoring below 100% (list IDs and brief reason):**
- B-01 (95%) — Minor residual: Console Window WN_MAIN is inherited from DPL parent, not a direct XML attribute; BRD now correctly notes this
- 8-01 (95%) — Same as B-01; XML Title attribute is "MODULE2"; runtime title noted correctly
- 8-05 (95%) — Same as B-01; Console Window is inherited via PC_FORM property class; now documented
- I-01 (98%) — Minor residual from console window notation
- I-02 (97%) — Minor residual: SP-005 get_message commented-out is accurately noted
- I-06 (97%) — Same minor residuals

**N/A Justifications:**
- 8-12, 8-14, 8-15: No form parameters in source
- 8-22, 8-23: No blocks with WhereClause/OrderByClause
- 8-30: No LOVs in source
- 8-50, 8-51: No canvases or windows in source
- 8-53: No editors in source
- 8-58, 8-59: No DataSourceColumns in source
- 10-02, 10-03, 10-04: No record groups in source
- 11-05: No database blocks; no base-table inventory applies
- 13-02, 13-03, 13-05: No PCK routines invoked from this form
- 14-02, 14-03, 14-04, 14-05: No PCK routines applicable
- 19-02, 19-04, 19-05: No PCK routines invoked
- H-01, H-02, H-03: No comparison BRD available for cross-template scoring

**Recommended minimum thresholds before client delivery:**

| Gate | Threshold |
| ---- | --------- |
| Overall weighted score | above 95% |

Any checkpoint below 100% must be addressed before the BRD is presented to the client.

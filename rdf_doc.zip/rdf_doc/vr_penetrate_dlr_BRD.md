# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Business Scenarios - How the quarter-to-month mapping differs by quarter
    - Requirement ID: BR-005
    - Business Scenarios - How the quarter-year key differs by quarter
    - Requirement ID: BR-006
    - Business Scenarios - How the format control differs by destination type
    - Requirement ID: BR-007
    - Business Scenarios - How the file name field availability differs by format
    - Requirement ID: BR-008
    - Requirement ID: BR-009
    - Requirement ID: BR-010
    - Requirement ID: BR-011
    - Requirement ID: BR-012
    - Requirement ID: BR-013
    - Requirement ID: BR-014
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Report Parameter Configuration - ED_REPORTS
    - Dealer and Location Master - AM_DEALER_LOC and AM_DEALER_LOC_PARAM
    - Zone and Region Reference - GM_REGN
    - Financial Year Master - FM_COMPANY
    - Extended Warranty Incentive Detail - VD_EW_INCE_DTL
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Parameters (User - before submission)
    - Session and Non-Database Parameters (System - at form load)
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - L_POP_LIST_ITEM
    - SP-002 - PR_PASS_PARAM
    - SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-004 - D2KWUTIL.CHOOSEFILE
    - SP-005 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-006 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-007 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-008 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-009 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-010 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-011 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-012 - D2KWUTIL.SAVE_FILE
    - SP-013 - D2KWUTIL.TRANSLATETYPE
    - SP-014 - GENERAL.ASK_CONFIRM
    - SP-015 - GENERAL.DISP_TEXT
    - SP-016 - GENERAL.RAISE_ERROR
    - SP-017 - WEBUTIL.BLOCKING
    - SP-018 - WEBUTIL.CHECKLIBS
    - SP-019 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-020 - WEBUTIL.CLOSEBLOB
    - SP-021 - WEBUTIL.CLOSEFILE
    - SP-022 - WEBUTIL.DOWNLOADFROMURL
    - SP-023 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-024 - WEBUTIL.ERROR
    - SP-025 - WEBUTIL.ERRORALERT
    - SP-026 - WEBUTIL.EXECUTE
    - SP-027 - WEBUTIL.FCLOSE
    - SP-028 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-029 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-030 - WEBUTIL.FOPEN
    - SP-031 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-032 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-033 - WEBUTIL.GETCLIENTSETTING
    - SP-034 - WEBUTIL.GETIMPLCLASS
    - SP-035 - WEBUTIL.GETLASTERROR
    - SP-036 - WEBUTIL.GETLASTERRORARGS
    - SP-037 - WEBUTIL.GETNUMBER
    - SP-038 - WEBUTIL.GETOSFAMILY
    - SP-039 - WEBUTIL.GETOUTPUT
    - SP-040 - WEBUTIL.GETPROPERTY
    - SP-041 - WEBUTIL.GETSTRING
    - SP-042 - WEBUTIL.GETVAR
    - SP-043 - WEBUTIL.GET_LINE
    - SP-044 - WEBUTIL.GET_RETURN_CODE
    - SP-045 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-046 - WEBUTIL.HOST
    - SP-047 - WEBUTIL.ID_NULL
    - SP-048 - WEBUTIL.INIT
    - SP-049 - WEBUTIL.INITWEBUTIL
    - SP-050 - WEBUTIL.ISERROR
    - SP-051 - WEBUTIL.IS_OPEN
    - SP-052 - WEBUTIL.LENGTH
    - SP-053 - WEBUTIL.LOG
    - SP-054 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-055 - WEBUTIL.PUTF
    - SP-056 - WEBUTIL.PUT_LINE
    - SP-057 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-058 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-059 - WEBUTIL.REGISTERBEAN
    - SP-060 - WEBUTIL.REGISTER_FUNCTION
    - SP-061 - WEBUTIL.RELEASE_PROCESS
    - SP-062 - WEBUTIL.SETCLIENTSETTING
    - SP-063 - WEBUTIL.SETDATA
    - SP-064 - WEBUTIL.SETPROPERTY
    - SP-065 - WEBUTIL.SHOWBEANS
    - SP-066 - WEBUTIL.URL_TO_CLIENT
    - SP-067 - WEBUTIL.WRITEDATA
    - SP-068 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-069 - ADD_ERROR
    - SP-070 - ADD_EXTERNAL_ERRORS
    - SP-071 - BOOLTOCHAR
    - SP-072 - CLEAN_ERROR_STACK
    - SP-073 - DEBUGLOG
    - SP-074 - GET_ENVIRONMENT_STRING
    - SP-075 - GET_TEMP_DIRECTORY
    - SP-076 - GET_WINDOWS_DIRECTORY
    - SP-077 - READ_REGISTRY
    - SP-078 - REGISTER_FUNCTION_CALL
    - SP-079 - SETDEBUG
    - SP-080 - STRIPDIRSEP
    - SP-081 - VIEW_EXCEL_REPORT_NEW
    - SP-082 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_PENETRATE_DLR - Business Requirements Document |
| Form Module Name | VR_PENETRATE_DLR |
| Document Version | 1.0 |
| Date Created | August 15, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 15, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_penetrate_dlr Dealer Penetration Report form, its purpose, and roles referenced in the module.*

The **vr_penetrate_dlr** Oracle Forms module is the **Dealer Penetration Report** screen used within the Dealer Management System. A dealer user or regional officer opens this screen to generate an extended-warranty penetration analysis report for a specific dealer, location, quarter, and financial year. The user selects the reporting region, then picks the target dealer from a list, chooses the applicable quarter and financial year, and selects the output destination (on-screen or printer). Before the report is submitted, the system checks that all required selections - dealer, quarter, and financial year - have been made. The system then reads the configured report parameters, passes them to Oracle Reports, and delivers the completed PDF report directly in the browser. A separate Excel output path exists in the codebase but is currently disabled. Clearing the screen restores the report title and recalculates the financial year label automatically.

### Key Stakeholders

*Who uses vr_penetrate_dlr*

| Stakeholder | Role |
| :--- | :--- |
| **Dealer User / Regional Officer** | **Primary interactive user** of vr_penetrate_dlr. Selects report parameters, triggers the report, and views the output. |
| **Dealer** | The business entity whose extended-warranty penetration figures are analysed; not a direct user of the form. |

---

---

## 3. System Context

*Describes the vr_penetrate_dlr module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_penetrate_dlr** module is the Dealer Management System **Dealer Penetration Report** screen. It is the entry point for generating extended-warranty penetration analysis reports and connects the user with the Oracle Reports engine, dealer master data, and company financial-year configuration.

**System purpose:** Allow an authorised user to select the reporting scope (region, dealer, location, quarter, financial year, and output format), validate all mandatory selections, build the report parameter string from the configured report definition, and submit the request to Oracle Reports - as implemented in the vr_penetrate_dlr Oracle Forms module.

**In scope:**

- Load the region list from user-specific access permissions at form startup
- Select the reporting region from the pre-populated region list
- Select the target dealer via a LOV filtered by the current parent group and principal
- Optionally select a specific location from the dealer-location list
- Select the report quarter (Q1-Q4) from the quarter list; system calculates the corresponding date range
- Select the financial year from a LOV listing open financial years for the selected dealer
- Select the report output destination (on-screen cache or printer)
- Select the output format (PDF or CHARACTER)
- Validate all mandatory parameters before report submission
- Build the report parameter string by reading configured parameter definitions from the report catalogue
- Submit the completed parameter set to Oracle Reports and display the PDF output in the browser
- Clear the screen and restore the report header label

**Process Name:** Dealer Penetration Report Generation

**Process Owner:** Regional Manager / Dealer Operations Officer

**Process Objective:** Select dealer, location, quarter, and financial year; validate all mandatory inputs; build the report parameter string; and submit to Oracle Reports to produce the penetration analysis PDF.

**Process Trigger:** User opens the Dealer Penetration Report screen to generate a periodic or on-demand extended-warranty penetration report for a dealer

**Process Flow:**

The complete dealer penetration report generation process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── SCREEN OPENS
         User opens the Dealer Penetration Report screen.
         The region list is loaded automatically from the regions accessible to
         the logged-in user based on their access configuration.

STEP 2 ── REGION SELECTION
         User selects the reporting region from the region list.
         On selection, all dependent fields (dealer, location, quarter, from date,
         to date, city) are cleared to prevent stale selections.

STEP 3 ── VALIDATE REGION
         When the user leaves the region field, the system checks that a region
         has been selected. If the field is empty, an error message is displayed
         and the user is returned to the region field.

STEP 4 ── DEALER SELECTION
         User selects the target dealer from the dealer lookup list.
         The list is filtered by the current parent group and principal to show
         only dealers whose DMS is implemented.

STEP 5 ── VALIDATE DEALER
         When the user leaves the dealer field, the system checks that a dealer
         has been selected. If blank, an error message is displayed and the user
         is returned to the dealer field.

STEP 6 ── LOCATION SELECTION (optional)
         User may select a specific location from the location list.
         The list shows all locations for the selected dealer plus an "ALL LOC" option.

STEP 7 ── QUARTER SELECTION
         User selects the reporting quarter (Q1, Q2, Q3, or Q4).
         On selection, the system validates that a quarter is chosen, clears the
         financial year field, and calculates the corresponding from and to date
         range based on the financial year globals.

STEP 8 ── VALIDATE QUARTER
         When the user navigates away from the quarter field, the system checks
         that a quarter has been selected. If blank, an error message is displayed
         and the user is returned to the quarter field.

STEP 9 ── FINANCIAL YEAR SELECTION
         User selects the financial year from the financial year lookup list.
         The list shows open financial years for the selected dealer, filtered by
         parent group, location, company, and dealer map code.

STEP 10 ── VALIDATE FINANCIAL YEAR
          When the user leaves the financial year field, the system checks that a
          financial year has been selected. If blank, an error is displayed and the
          user is returned to the financial year field.

STEP 11 ── OUTPUT DESTINATION SELECTION
          User selects the report output destination (Screen/Cache or Printer).
          On selection, the system automatically sets the output format:
          ├── PRINTER: format is set to CHARACTER and the format field is disabled
          └── Other: format is set to PDF and the format field is enabled

STEP 12 ── OUTPUT FORMAT SELECTION
          User may change the output format (PDF or CHARACTER) when the format
          field is enabled. Selecting EXCEL enables the filename entry field.

STEP 13 ── VALIDATE FROM DATE (when applicable)
          If a From Date has been entered, the system checks that it is not empty.
          An error alert is displayed if the From Date field is blank.

STEP 14 ── SUBMIT REPORT - MANDATORY FIELD CHECK
          User clicks the Submit Report button.
          System re-validates that Dealer, Quarter, and Financial Year are all
          selected. If any is missing, an error is shown and the user is directed
          to the missing field.

STEP 15 ── EXCEL DESTINATION CHECK
          If the user has selected Excel as the destination type, the system displays
          an error ("Excel is not available for this report") and returns the user
          to the destination field. Report submission is blocked.

STEP 16 ── BUILD REPORT PARAMETERS
          System reads the report parameter definitions from the report catalogue
          for this application and principal, maps current form field values to
          each parameter, and assembles the complete Oracle Reports parameter string.

STEP 17 ── CONFIGURE REPORT OBJECT
          System configures the Oracle Reports object with the report filename,
          parameter string, output server, and output destination properties.
          The output file is named using the logged-in user ID and current timestamp.

STEP 18 ── SUBMIT TO ORACLE REPORTS
          System submits the configured report to the Oracle Reports server.
          The report is generated as a PDF file in the designated printer folder.

STEP 19 ── DISPLAY REPORT OUTPUT
          System opens the generated PDF report in the browser window so the user
          can view, save, or print the penetration analysis.

STEP 20 ── CLEAR SCREEN
          User may clear the screen to start a new report request.
          The system restores the report description label and recalculates the
          financial year display label from the stored financial year globals.
```

**Major process interactions:**

- **Dealer and location master data** - the dealer list and location list are populated from the dealer location master, filtered by the current parent group and principal
- **User access configuration** - the region list is filtered by the regions assigned to the logged-in user in the user-region mapping
- **Company financial-year configuration** - the financial year list is drawn from the company master for the selected dealer, showing only open financial years
- **Report parameter catalogue** - parameter definitions for this form are read at submission time to build the Oracle Reports parameter string
- **Oracle Reports server** - receives the completed parameter set and generates the PDF penetration report output

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Initialisation and Application Session Registration

**Business Description:**
When the dealer penetration report form is opened, the system runs two sequential initialisation phases. First, before the form is displayed (PRE-FORM phase), the system registers the form session with the database for monitoring and performance-tracking purposes, and starts a performance timer if application logging is enabled. Second, once the form is displayed (WHEN-NEW-FORM-INSTANCE phase), the system sets the report identity, seeds the global financial period defaults, derives and displays the current financial year, sets application identity globals, retrieves the report server name from the application configuration, maximises the form window, and populates the Region drop-down list from the user's authorised regions. This ensures that the form opens in a fully initialised, ready-to-use state without any action required from the user.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has launched the dealer penetration report form from the application menu.

**Main Flow:**

**Step 1 - Performance timer started when logging is enabled**
Before the form is displayed, the system checks whether application-level logging is currently active for this session. If it is, a performance timer is started automatically so that the time taken for the form to complete its initialisation can be measured and reported.

**Step 2 - Session registered with the database for monitoring**
The system registers the current form's identity with the database session, recording the module name `vr_penetrate_dlr` as the active client. This allows database administrators to identify which application module a session belongs to, supporting active session monitoring and performance auditing.

**Step 3 - Report identity and display description set**
Once the form opens, the system sets the report description global (`global.report_desc`) to *"Extended Warranty Incentive Details"* and assigns both the report name global (`global.report_name`) and the application identifier global (`global.app_id`) to `vr_penetrate_dlr`. The report description is also displayed in the form's report description display field and the report name is written to the report name display field (`CB_BLK.report_name`).

**Step 4 - Financial period defaults and current financial year seeded**
The system seeds the global financial period start date (`GLOBAL.FIN_BEG`) to `01-APR-2012` and the global financial period end date (`GLOBAL.FIN_END`) to `31-MAR-2013` as fallback defaults, applying them only if those globals are not already set. It then extracts the four-digit year from each date and combines them to form the current financial year string (for example, `2012-2013`), which is written to the Financial Year display field.

**Step 5 - Application parameter and check value set**
The system copies the application identifier to the form parameter `PARAMETER.P_APP_ID`. It also sets the report validation parameter `PARAMETER.P_CHECK` to `0` for this application (indicating a standard, non-restricted report path).

**Step 6 - Report server retrieved from application configuration**
The system looks up the report server name from the application reports configuration table for this form and the current user's principal mapping. If no matching record is found or multiple rows are returned, the global default report server name is used.

**Step 7 - Form window maximised**
The MDI parent window and the main form window (`WN_MAIN`) are both maximised so the form opens at full screen.

**Step 8 - Region drop-down populated**
The Region drop-down list (`CB_BLK.P_REGION_CD`) is populated using the record group `P_REGION_CD`. The list is built from the regions authorised for the current user, joined to the region master for the user's principal, filtered to users of type `SERVICE`, and ordered by region code. Only regions the user is entitled to see are presented.

**Step 9 - Copyright declaration displayed**
The system retrieves the copyright declaration text from the database function `SF_COPYRIGHT_DECLARATION` and writes it to the copyright display field on the form.

**Alternative Flows:**
- **BR-001-AF-01** - (from Step 1) If application logging is not active for this session, the performance timer step is skipped entirely and the form proceeds directly to Step 2.
- **BR-001-AF-02** - (from Step 6) If the report server lookup finds no row or multiple rows, the global default report server value is used without displaying an error.

---

---

#### Requirement ID: BR-002

**Requirement Title:** Region Filter Selection and Dependent Field Reset

**Business Description:**
When the user selects a region from the Region drop-down list and then moves away from the field, the system validates that a region has been chosen. If the field is left empty, the user is shown an error and must provide a value before continuing. When a valid region is selected, the system automatically clears all downstream filter fields - dealer, city, location, quarter, from date, and to date - so that previously entered values from a different region do not carry forward and produce incorrect report results.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open and the Region drop-down is available for selection.

**Main Flow:**

**Step 1 - Region value validated on exit from the field**
When the user leaves the Region drop-down after changing its value, the system checks that a region has been selected. If the field is empty, the system displays the error *"Region Code can not be empty"* and returns focus to the Region field so the user can correct the entry.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Region selection is mandatory | Region mandatory check - WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD | When the user tabs off or otherwise leaves the Region field after interacting with it | Ensures a region has been chosen before any dependent fields can be populated, preventing filter combinations that have no valid meaning | *"Region Code can not be empty"*; focus stays on the Region field; the user must select a region before proceeding |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - Region field is empty on exit - *"Region Code can not be empty"*; focus returns to the Region field.

**Step 2 - Dependent filter fields cleared when region changes**
Once a valid region is confirmed, the system automatically clears the Dealer, City/Location description, City code, Quarter, From Date, and To Date fields. This prevents stale values from a previous region selection from being passed to the report, ensuring that only filter values consistent with the newly selected region are used.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Region (`P_REGION_CD`) | Mandatory | List item | N/A | N/A | N/A | Form open | Must not be empty when the user leaves the field | *"Region Code can not be empty"*; focus returned to field |
| Dealer (`P_DEALER_DESC`) | Auto-populated / Optional | Text | 500 | Dealer list (LV_DEALER) | Dealer name | Region selected | Cleared automatically when Region changes | N/A |
| Location Description (`P_CITY_DESC`) | Auto-populated | Text | 500 | N/A | N/A | Dealer selected | Cleared automatically when Region changes | N/A |
| City Code (`P_CITY`) | Auto-populated | Text | 20 | City list (LV_CITY) | City code | Dealer selected | Cleared automatically when Region changes | N/A |
| Quarter (`QUARTER`) | Auto-populated / Mandatory | List item | N/A | N/A | N/A | Region selected | Cleared automatically when Region changes | N/A |
| From Date (`P_FROM_DT`) | Auto-populated | Date | 10 / DD-MM-YYYY | N/A | N/A | Quarter and Financial Year selected | Cleared automatically when Region changes | N/A |
| To Date (`P_TO_DT`) | Auto-populated | Date | 10 / DD-MM-YYYY | N/A | N/A | Quarter and Financial Year selected | Cleared automatically when Region changes | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** Dealer Lookup and Selection

**Business Description:**
The user can look up and select a dealer from a list of authorised dealers associated with the current session's principal and dealer mapping. Once a dealer is selected and the user moves to the next field, the system validates that the Dealer field is not empty. If it is empty, the user is shown an error and must select a dealer before the report filters can be completed.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open.
- A region has been selected.

**Main Flow:**

**Step 1 - Dealer selected from the lookup list**
The user opens the dealer lookup list on the Dealer field and selects an authorised dealer. The list shows dealer names, location descriptions, and city information for the current session's principal and dealer mapping, sourced from the dealer master. The form's list-of-values key opens this list at a fixed position; after a successful selection, the cursor advances to the next input field automatically.

**Step 2 - Dealer field validated when user advances to the next field**
When the user tabs away from the Dealer field, the system checks that a dealer has been selected. If the field is empty, the system displays the error *"Dealer can not be Blank)"* and returns focus to the Dealer field so the user must complete the selection before proceeding. If a dealer is present, the cursor moves on to the Quarter field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer selection is mandatory | Dealer mandatory check - KEY-NEXT-ITEM on CB_BLK.P_DEALER_DESC | When the user presses the Tab or Next Field key to leave the Dealer field | Prevents the user from advancing to subsequent report parameters without first selecting a dealer, ensuring the report will have a valid dealer scope | *"Dealer can not be Blank)"*; focus returns to the Dealer field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - Dealer field is empty when the user tries to advance - *"Dealer can not be Blank)"*; focus returns to the Dealer field.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text | 500 | Dealer lookup (LV_DEALER / RG_DEALER) | Dealer name, location, and city for the current principal | Region selected | Must not be empty when the user advances from this field | *"Dealer can not be Blank)"*; focus returned to field |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Quarter Selection and Quarter-Month Mapping

**Business Description:**
When the user selects a financial quarter from the Quarter drop-down, the system validates that a quarter has been chosen and then derives the corresponding calendar month number used internally to define the reporting period. If the Quarter field is empty when changed, the user sees an error and must correct the entry. Once a valid quarter is confirmed, the system clears the Financial Year field so the user is prompted to re-confirm the year for the newly chosen quarter, and then advances the cursor to the Financial Year field.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- A dealer has been selected.

**Main Flow:**

**Step 1 - Quarter validated when the selection changes**
When the user changes the value in the Quarter drop-down, the system immediately checks that the field is not empty. If it is empty, the system displays the error *"Quarter can not be Blank)"* and returns focus to the Quarter field.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quarter selection is mandatory | Quarter mandatory check - WHEN-LIST-CHANGED on CB_BLK.QUARTER | When the user changes the Quarter drop-down selection | Ensures a quarter is always set before dependent calculations run, preventing an undefined reporting period from reaching the report | *"Quarter can not be Blank)"*; focus returns to the Quarter field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-ES-01** - Quarter field is empty after the change event - *"Quarter can not be Blank)"*; focus returns to the Quarter field.

**Step 2 - Financial Year field cleared**
The Financial Year field is cleared so that the user must re-select it for the newly chosen quarter, preventing a mismatch between the quarter and a previously selected year.

**Step 3 - Quarter mapped to an internal month number**
The system derives the end-month number for the selected quarter: Q1 maps to month 06, Q2 to month 09, Q3 to month 12, and Q4 to month 03. This value is stored internally for use when the Financial Year is subsequently selected to form the full quarter-year reporting period key.

**Step 4 - Cursor advanced to the Financial Year field**
After the quarter mapping is set, the cursor is moved automatically to the Financial Year field so the user can complete the period selection.

#### Business Scenarios - How the quarter-to-month mapping differs by quarter

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Q1 selected** | Internal month number set to 06 (June); represents the end of the first quarter of the Indian financial year. |
| **Q2 selected** | Internal month number set to 09 (September); represents the end of the second quarter. |
| **Q3 selected** | Internal month number set to 12 (December); represents the end of the third quarter. |
| **Q4 selected** | Internal month number set to 03 (March); represents the end of the fourth quarter (the final quarter of the Indian financial year). |

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 1) Quarter is empty when changed: error *"Quarter can not be Blank)"* is displayed; the Financial Year and subsequent steps are not executed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Quarter (`QUARTER`) | Mandatory | List item | N/A | N/A | Q1, Q2, Q3, Q4 | Dealer selected | Must not be empty when changed | *"Quarter can not be Blank)"*; focus returned to field |
| Financial Year (`FINANCIAL_YEAR`) | Auto-populated / Mandatory | List item (with LOV) | N/A | Financial Year lookup (LV_FINANCIAL_YEAR) | Financial year display string | Quarter selected | Cleared automatically when Quarter changes; must be re-selected | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Financial Year Selection and Quarter-Year Reporting Period Finalisation

**Business Description:**
When the user selects a financial year from the Financial Year lookup, the system validates that a year has been chosen and then combines the selected quarter and year into a single quarter-year reporting period key used to scope the penetration report. For the fourth quarter, the system automatically uses the following calendar year as the year component of the period key, reflecting the fact that Q4 of an Indian financial year ends in March of the next calendar year. Once the period is finalised, the cursor advances to the Destination field.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- A dealer has been selected.
- A quarter has been selected.

**Main Flow:**

**Step 1 - Financial Year list opened and selection made**
The user opens the Financial Year lookup on the Financial Year field. The list shows available financial years sourced from the company master for the current session's parent group, location, dealer, and company code, limited to years that have not been finally closed. Once selected, the chosen year value is stored.

**Step 2 - Financial Year validated**
After the financial year is selected, the system checks that the Financial Year field is not empty. If it is empty, the system displays the error *"Financial Year can not be Blank)"* and returns focus to the Financial Year field. The same validation also applies when the user tabs away from the Financial Year field without opening the lookup.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Financial Year selection is mandatory (via lookup) | Financial Year mandatory check - KEY-LISTVAL on CB_BLK.FINANCIAL_YEAR | When the user completes the Financial Year lookup selection | Ensures a financial year is chosen before the quarter-year period key can be formed, preventing an incomplete reporting period from reaching the report | *"Financial Year can not be Blank)"*; focus returns to the Financial Year field |
| Financial Year selection is mandatory (via Tab) | Financial Year mandatory check - KEY-NEXT-ITEM on CB_BLK.FINANCIAL_YEAR | When the user presses Tab to advance from the Financial Year field | Same purpose as the lookup path; ensures no empty year is accepted regardless of how the user leaves the field | *"Financial Year can not be Blank)"*; focus returns to the Financial Year field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-ES-01** - Financial Year field is empty after the lookup or Tab key - *"Financial Year can not be Blank)"*; focus returns to the Financial Year field.

**Step 3 - Quarter-year reporting period key calculated**
The system combines the stored quarter month number with the selected financial year to produce the quarter-year period key used as the report parameter. For quarters Q1, Q2, and Q3, the year component is taken directly from the selected financial year. For Q4, the year component is set to the financial year value plus one, because Q4 ends in March of the subsequent calendar year.

#### Business Scenarios - How the quarter-year key differs by quarter

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Q1, Q2, or Q3 selected** | Quarter-year key uses the selected financial year directly as the year component, combined with the quarter's month number. |
| **Q4 selected** | Quarter-year key uses the selected financial year plus one as the year component (because Q4 ends in March of the following calendar year), combined with month 03. |

**Step 4 - Cursor advanced to the Destination field**
After the period key is set, the cursor is moved automatically to the Destination field so the user can specify where the report output should be sent.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) Financial Year is empty after the lookup or Tab: error *"Financial Year can not be Blank)"* is displayed; the quarter-year key is not formed.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Financial Year (`FINANCIAL_YEAR`) | Mandatory | List item (with LOV) | N/A | Financial Year lookup (LV_FINANCIAL_YEAR / RG_FINANCIAL_YEAR) | Financial year string from company master | Quarter selected | Must not be empty after the lookup or Tab key | *"Financial Year can not be Blank)"*; focus returned to field |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Destination Type Selection and Report Format Control

**Business Description:**
When the user selects where the report should be sent - either to a printer or to another destination such as a file, cache, or mail - the system automatically controls the availability of the Format field. Selecting the Printer destination locks the Format field to a fixed value (character mode) and disables it so the user cannot change it. Selecting any other destination sets the Format to PDF and enables the Format field for the user to change if needed. This same behaviour also applies when the Report Type is changed and when an alternative Destination field on the form changes.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open with report parameters completed.

**Main Flow:**

**Step 1 - Destination type selection applied and Format field controlled**
When the user changes the Destination drop-down (or the Report Type, which also re-applies this rule), the system checks the selected destination value. If Printer is selected, the Format field is set to character mode and disabled so the user cannot modify it. For any other destination, the Format field is set to PDF and enabled so the user can change it if required.

#### Business Scenarios - How the format control differs by destination type

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Printer selected** | Format field is set to `CHAR` (character mode) and disabled - the user cannot change the format for printer output. |
| **Any other destination selected (File, Cache, Mail)** | Format field is set to `PDF` and enabled - the user may change the format if needed. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Destination (`P_DESTYPE`) | Mandatory | List item | N/A | N/A | PRINTER, FILE, CACHE, MAIL | Report parameters entered | Must not be empty (required property set) | N/A - enforced by form required flag |
| Report Type (`P_REPO_TYPE`) | Mandatory | List item | N/A | N/A | N/A | Report parameters entered | Required (required property set) | N/A |
| Format (`P_DESFORMAT`) | Conditional - auto-set when Destination or Report Type changes | List item | N/A | N/A | CHAR, PDF | Destination selected | Set to CHAR and disabled when Printer; set to PDF and enabled otherwise | N/A |

---

---

#### Requirement ID: BR-007

**Requirement Title:** Report Output Format Change and File Name Field Availability

**Business Description:**
When the user changes the report output format, the system controls whether the File Name field is available for input. The File Name field is only relevant when the user selects the Excel output format; for all other formats, the field is cleared and locked so the user cannot enter a value. Additionally, when the cursor enters the File Name field, the system re-evaluates the current format and allows or prevents editing accordingly.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open.
- The Destination and Format fields are visible.

**Main Flow:**

**Step 1 - Format selection evaluated and File Name field controlled**
When the user changes the Format drop-down, the system checks whether the selected format is Excel. If it is not Excel, the File Name field is cleared and its Enabled and Navigable properties are set to false so the user cannot enter a file name. If Excel is selected, the File Name field is enabled and made navigable so the user can enter the output file name.

**Step 2 - File Name field editing enforced when cursor enters the field**
When the cursor moves into the File Name field, the system re-checks whether the current format is Excel. If Excel, the field allows both inserting and updating. If any other format, the field is set to read-only - inserting and updating are both prevented.

#### Business Scenarios - How the file name field availability differs by format

| Scenario | What Happens Differently |
| -------- | ------------------------ |
| **Non-Excel format selected** | File Name field is cleared, disabled, and not navigable - the field is hidden from keyboard navigation and any previous file name is removed. When cursor enters the field, insert and update are prevented. |
| **Excel format selected** | File Name field is enabled and navigable - the user can type a destination file path for the Excel output. When cursor enters the field, insert and update are both allowed. |

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Format (`P_DESFORMAT`) | Mandatory | List item | N/A | N/A | CHAR, PDF, EXCEL | Destination selected | Required | N/A |
| File Name (`FILENAME`) | Conditional - when Excel format selected | Text | 4000 | N/A | N/A | Excel format selected | Enabled and navigable only when format is Excel; cleared and locked otherwise | N/A |

---

---

#### Requirement ID: BR-008

**Requirement Title:** From Date Validation

**Business Description:**
When the user has entered a value in the From Date field and moves away from it, the system validates that the field is not empty. If the From Date is blank, the user is shown an alert and the form prevents further processing until a date is provided.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open.
- The From Date field is accessible.

**Main Flow:**

**Step 1 - From Date checked for a value on exit**
When the user leaves the From Date field, the system checks whether a date has been entered. If the From Date is empty, the system displays an alert popup with the message *"From Date cannot be empty"* and prevents the user from advancing. The user must enter a date before continuing.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Date is mandatory | From Date mandatory check - WHEN-VALIDATE-ITEM on CB_BLK.P_FROM_DT | When the user leaves the From Date field | Ensures a valid reporting start date is always provided before the report can be submitted, preventing reports with an undefined date range | Alert popup shown: *"From Date cannot be empty"*; validation failure raised; user must enter a date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-008-ES-01** - From Date is empty when the user leaves the field - alert shown with *"From Date cannot be empty"*; the user must provide a date.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Date (`P_FROM_DT`) | Mandatory | Date | 10 / DD-MM-YYYY | N/A | N/A | Quarter and Financial Year selected | Must not be empty when the user leaves the field | Alert: *"From Date cannot be empty"*; validation failure; focus retained |

---

---

#### Requirement ID: BR-009

**Requirement Title:** Report Submission - Parameter Assembly and PDF Delivery

**Business Description:**
When the user clicks the Submit Report button, the system first checks that all required filter fields have been completed. It then assembles the report parameters from the entered filter values, configures the report object for the selected destination and format, and submits the report for execution. The report output is delivered to the user's browser as a PDF file opened in a new window. The Excel destination path is explicitly blocked for this report. Excel output, the region list pre-population, and certain legacy report paths visible in the source code have been commented out and do not execute.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- All required report parameters have been completed: Dealer, Quarter, and Financial Year are populated.

**Main Flow:**

**Step 1 - Mandatory fields validated before report submission**
When the user clicks Submit Report, the system checks in sequence that the Dealer, Quarter, and Financial Year fields are all populated. If any of these is empty, the corresponding error is displayed and the cursor is placed on the empty field; the report is not submitted.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Dealer is required for submission | Dealer null check - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the Submit Report button is pressed | Prevents report submission without a dealer filter, which would produce a report with no meaningful scope | *"Dealer can not be Blank)"*; focus placed on the Dealer field |
| Quarter is required for submission | Quarter null check - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the Submit Report button is pressed, after the Dealer check passes | Prevents report submission without a quarter period, which would produce a report with an undefined reporting period | *"Quarter can not be Blank)"*; focus placed on the Quarter field |
| Financial Year is required for submission | Financial Year null check - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the Submit Report button is pressed, after the Quarter check passes | Prevents report submission without a financial year, completing the period key required by the report | *"Financial Year can not be Blank)"*; focus placed on the Financial Year field |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-01** - Dealer is empty when Submit is pressed - *"Dealer can not be Blank)"*; focus placed on the Dealer field; report not submitted.
- **BR-009-ES-02** - Quarter is empty when Submit is pressed - *"Quarter can not be Blank)"*; focus placed on the Quarter field; report not submitted.
- **BR-009-ES-03** - Financial Year is empty when Submit is pressed - *"Financial Year can not be Blank)"*; focus placed on the Financial Year field; report not submitted.

**Step 2 - Excel destination blocked**
If the user has selected Excel as the destination, the system displays the error *"Excel is not available for this report!)"* and places the cursor on the Destination field. The report is not submitted.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Excel destination is not supported | Excel check - WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | When the Submit Report button is pressed and all mandatory fields are present | Prevents submission with the Excel destination, which is explicitly disabled for this report | *"Excel is not available for this report!)"*; cursor placed on the Destination field; report not submitted |

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-ES-04** - Excel destination selected when Submit is pressed - *"Excel is not available for this report!)"*; cursor placed on the Destination field.

**Step 3 - Report parameters assembled**
The system assembles the report parameter string by reading the report's parameter configuration from the report parameters master table for this application and the current principal. For each defined parameter, the current on-screen value is appended to the parameter string: the dealer code, location code (or the value `ALL` if no dealer is selected), the quarter-year reporting period key, the report type, and the destination type.

*Procedures called:*
- **PR_PASS_PARAM** ([SP-001](#SP-001--PR_PASS_PARAM)) - PR_PASS_PARAM - builds the complete report parameter string from the current screen values by iterating the application's registered parameter list from the report parameters master.
    * **Step 1** - Retrieve the list of report parameters defined for this application and principal from the report parameters master, ordered by serial number.
    * **Step 2** - For the Dealer parameter, append the current dealer code to the parameter string.
    * **Step 3** - For the Location parameter, append the current location code to the parameter string; if no dealer has been selected, substitute the value `ALL` for the location.
    * **Step 4** - For the Quarter-Year parameter, check that the quarter-year period key is present; if it is absent, display an informational alert prompting the user to enter it, then append the quarter-year value to the parameter string regardless.
    * **Step 5** - For the Report Type parameter, append the current report type value to the parameter string.
    * **Step 6** - For the Destination Type parameter, append the current destination type value to the parameter string.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Quarter-Year period key must be set | Quarter-Year presence check - PR_PASS_PARAM [SP-001] | When the report parameters are assembled on submission | Ensures the period key used to scope the penetration report has been properly formed from the selected quarter and financial year | Alert displayed: *"Please Enter QTR YEAR"*; the parameter is still appended (the alert does not stop processing) |

**Step 4 - Report object configured for output destination and format**
The system locates the report object and sets its destination type to match the user's selection (Cache, Printer, File, or Mail). For all non-Excel paths, the format is fixed to PDF and the destination is overridden to FILE. A unique output file name is generated from the current user's ID and the current date and time, and the `.pdf` extension is appended. The report parameters string, file name, report server, and output path are all set on the report object.

**Step 5 - Report submitted and PDF opened in browser**
The report is submitted to the report server for execution. Once the server accepts the job, the system opens the resulting PDF file in a new browser window so the user can view or save it immediately.

*Business outcomes (errors, warnings, success, and status):*
- **BR-009-SM-01** - Report submitted and PDF generated - the report output is opened in a new browser tab/window for the user to review.

**Alternative Flows:**
- **BR-009-AF-01** - (from Step 1) Dealer is empty: error *"Dealer can not be Blank)"* shown; report not submitted.
- **BR-009-AF-02** - (from Step 1) Quarter is empty: error *"Quarter can not be Blank)"* shown; report not submitted.
- **BR-009-AF-03** - (from Step 1) Financial Year is empty: error *"Financial Year can not be Blank)"* shown; report not submitted.
- **BR-009-AF-04** - (from Step 2) Excel is selected as destination: error *"Excel is not available for this report!)"* shown; cursor placed on Destination field; report not submitted.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Dealer (`P_DEALER_DESC`) | Mandatory | Text | 500 | Dealer lookup (LV_DEALER) | Dealer name | Region selected | Must not be empty at submission | *"Dealer can not be Blank)"*; focus on field |
| Quarter (`QUARTER`) | Mandatory | List item | N/A | N/A | Q1, Q2, Q3, Q4 | Dealer selected | Must not be empty at submission | *"Quarter can not be Blank)"*; focus on field |
| Financial Year (`FINANCIAL_YEAR`) | Mandatory | List item (with LOV) | N/A | Financial Year lookup (LV_FINANCIAL_YEAR) | Financial year string | Quarter selected | Must not be empty at submission | *"Financial Year can not be Blank)"*; focus on field |
| Destination (`P_DESTYPE`) | Mandatory | List item | N/A | N/A | PRINTER, FILE, CACHE, MAIL | Report parameters entered | Excel destination not permitted | *"Excel is not available for this report!)"*; focus on field |
| File Name (`FILENAME`) | Auto-populated | Text | 4000 | N/A | N/A | Report submitted | System-generated from user ID + timestamp + `.pdf` extension | N/A |
| Report Description (`REPORT_DESC`) | Read-only display | Display item | 200 | N/A | N/A | N/A | Display only | N/A |

---

---

#### Requirement ID: BR-010

**Requirement Title:** Form Clear and Financial Year Reset

**Business Description:**
The form provides three toolbar-driven actions that reset or clear the screen: Save, Cancel/Clear, and an explicitly blocked Insert. When the user clicks Save, the system commits any pending changes to the database and then immediately clears the form so it is ready for the next request. When the user clicks Cancel or Clear, the system checks whether any data has been entered; if data exists, the user is asked to confirm before the form is cleared; if no changes are present, the form is cleared without prompting. The Insert toolbar button is active on this form but intentionally blocked - pressing it shows an informational message explaining that the operation is not supported here. After any clear action, the system resets the Financial Year field to the current financial year derived from the session's stored financial period dates, ensuring the form is in a consistent, ready-to-use state.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open.

**Main Flow:**

**Step 1 - Save toolbar button commits and clears the form**
When the user clicks the Save toolbar button, the system commits the current form data to the database and then immediately clears all fields on the form via the Clear Form action. After clearing, the Financial Year field is reset to the current financial year as described in Step 4.

**Step 2 - Cancel toolbar button checks for unsaved changes before clearing**
When the user clicks the Cancel or Clear toolbar button, the system first checks whether the form has any unsaved changes. If the form status is Changed (indicating the user has entered or modified data), the system presents a confirmation prompt with the message *"Entered data will not be Saved"*. If the user confirms, the form is cleared. If the form has no unsaved changes, the form is cleared immediately without prompting.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Unsaved changes confirmation | Cancel unsaved-data check - FT_CANCEL via PB_BLK.PB_CANCEL WHEN-BUTTON-PRESSED | When the Cancel button is pressed and the form has unsaved changes | Prevents the user from accidentally discarding entered data without an explicit acknowledgement | *"Entered data will not be Saved"* confirmation shown; clear only proceeds if the user confirms |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-WS-01** - Form has unsaved changes when Cancel is pressed - *"Entered data will not be Saved"* confirmation shown; user must confirm before the form is cleared.

**Step 3 - Insert toolbar button blocked on this form**
When the user clicks the Insert toolbar button and the button is currently enabled, the system displays the message *"This Operation Cannot be performed Here"* and does not perform any insert action. This form is a read-only report-parameter screen; record insertion is not supported.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Insert is not permitted on this form | Insert-blocked check - FT_INSERT via PB_BLK.PB_INSERT WHEN-BUTTON-PRESSED | When the Insert toolbar button is pressed while it is enabled | Prevents the user from attempting to insert a record on a form that does not support data entry in that way | *"This Operation Cannot be performed Here"* displayed; no action taken |

*Business outcomes (errors, warnings, success, and status):*
- **BR-010-ES-01** - Insert toolbar button pressed while enabled - *"This Operation Cannot be performed Here"*; no insert action performed.

**Step 4 - All on-screen values cleared**
Following any confirmed save or cancel/clear action, the system clears all fields on the form, removing any previously entered filter values.

**Step 5 - Financial Year field reset to current financial year**
After clearing, the system reads the financial period start and end years stored in the session's global financial period settings and sets the Financial Year field to the combined start-and-end year string (for example, `2023-2024`). This gives the user a meaningful default for the Financial Year without requiring them to re-select it from the lookup.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Financial Year (`FINANCIAL_YEAR`) | Auto-populated | Text | N/A | N/A | Derived from session financial period start and end years | Form clear action | Auto-set from session data | N/A |

---

---

#### Requirement ID: BR-011

**Requirement Title:** Form-Level Error Interception and User-Friendly Error Display

**Business Description:**
When any error occurs anywhere within the form - whether from a date format problem, an invalid character in a numeric field, a concurrent modification by another user, a database-level integrity constraint violation, or any other system error - the form intercepts the error and presents a plain, descriptive message to the user instead of a raw system error code. Specific known error conditions each have their own tailored message; any other unexpected error shows the database error text. After displaying the error, the form cancels the triggering action so the user stays on the form and can correct the issue.

**Actors:** System (automatic on any form error); Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open and an error condition has arisen.

**Main Flow:**

**Step 1 - Invalid date format intercepted**
If an error occurs because the user entered a value that cannot be interpreted as a date (Forms error 50004), the system displays *"Entered Date is not valid Date"* and cancels the action that caused the error. The user stays on the form.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date fields must contain a valid date | Invalid date check - ON-ERROR (Form), error code 50004 | When a date-format error is raised anywhere on the form | Gives the user a clear message that the value entered is not a recognisable date, preventing confusing system error codes from appearing | *"Entered Date is not valid Date"*; action cancelled; user stays on the form |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-01** - Date format error (error 50004) - *"Entered Date is not valid Date"*; action cancelled.

**Step 2 - Incorrect date format pattern intercepted**
If the error code indicates an incorrect date format mask (50025 or 50026), the system displays *"Enter the Date in the proper format (DD-MM-YYYY)"* and cancels the action. The user is guided to use the expected date format.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date fields must use DD-MM-YYYY format | Date format mask check - ON-ERROR (Form), error codes 50025 or 50026 | When a date format mask error is raised anywhere on the form | Tells the user the exact format expected, so they can correct their input | *"Enter the Date in the proper format (DD-MM-YYYY)"*; action cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-02** - Date format mask error (50025 or 50026) - *"Enter the Date in the proper format (DD-MM-YYYY)"*; action cancelled.

**Step 3 - Non-numeric value in a numeric field intercepted**
If the error codes 40209 or 50016 are raised because the user entered text or special characters into a field that only accepts numbers, the system displays *"Characters/Special Characters are not allowed here, enter the numeric value"* and cancels the action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Numeric fields must not contain non-numeric characters | Numeric field check - ON-ERROR (Form), error codes 40209 or 50016 | When a non-numeric-input error is raised on the form | Gives the user a clear message explaining why the value was rejected and prompting a numeric input | *"Characters/Special Characters are not allowed here, enter the numeric value"*; action cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-03** - Non-numeric characters in a numeric field (40209 or 50016) - *"Characters/Special Characters are not allowed here, enter the numeric value"*; action cancelled.

**Step 4 - Field-level error text intercepted and displayed**
If error code 40207 is raised (a field-level validation failure), the system displays the error text associated with that error (`errtxt`) and cancels the action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Field-level validation failure | Field error text display - ON-ERROR (Form), error code 40207 | When a field-level validation error is raised on the form | Surfaces the specific field-level error message to the user in plain text | The error text for that error is displayed; action cancelled |

**Step 5 - Database integrity constraint violation intercepted**
If the database raises an integrity constraint violation (database error code -02292, indicating a child record still exists), the system calls the general error handler with the business error reference `E0088`. The action is cancelled.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Child record integrity check | Database constraint check - ON-ERROR (Form), DBMS error code -02292 | When a database integrity constraint is violated anywhere on the form | Prevents the user from deleting or modifying a parent record that still has related child records, with a user-friendly business error message | Business error `E0088` raised; action cancelled |

**Step 6 - Concurrent record modification intercepted**
If error codes 40654, 40655, 40656, 40657, or 40659 are raised, it means another user has changed the same record. The system displays *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, rolls back any unsaved changes, and cancels the action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Record concurrent modification check | Concurrent update check - ON-ERROR (Form), error codes 40654, 40655, 40656, 40657, 40659 | When a concurrent record-modification error is raised on the form | Alerts the user that the record they were editing has been changed by another user and instructs them to re-query before saving | *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback performed; action cancelled |

*Business outcomes (errors, warnings, success, and status):*
- **BR-011-ES-04** - Concurrent update detected - *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*; rollback; action cancelled.

**Step 7 - Unexpected database or SQL error intercepted**
If any other SQL error is present (SQL code is not zero), the system displays the database's own error message text (the dynamic `SQLERRM` value) as an error, performs a rollback, and cancels the action.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| General SQL error handler | SQL error check - ON-ERROR (Form), when SQL code is not zero | When an unclassified SQL or database error is raised anywhere on the form | Surfaces the underlying database error to the user so it can be reported or investigated, while rolling back any partial changes | The database error text (dynamic SQLERRM) is displayed; rollback performed; action cancelled |

**Step 8 - Benign no-data or maximum-records messages suppressed**
If error codes 40401 (query produced no records) or 40405 (maximum records retrieved) are raised, the system silently ignores them - no message is shown and the form continues normally.

**Alternative Flows:**
- **BR-011-AF-01** - (from Step 8) Error codes 40401 or 40405: silently suppressed; no message displayed, no action taken.

---

---

#### Requirement ID: BR-012

**Requirement Title:** Form-Level Message Interception and Error Reclassification

**Business Description:**
When the form raises an informational message for certain known conditions, the system intercepts the message and reclassifies it as an error with a descriptive text, preventing the default system message from appearing and ensuring the user always sees a meaningful, consistent error message.

**Actors:** System (automatic on form message); Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open and a message condition has arisen.

**Main Flow:**

**Step 1 - Known message codes intercepted and reclassified as errors**
When message codes 40209 or 40207 are raised, the form intercepts the message, builds the display text from the error type, code, and description (in the dynamic pattern: error type, then a dash, then the error code number, then a colon and the error text), and displays it as an error. The action that caused the message is then cancelled.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Message reclassification for codes 40209 and 40207 | Message reclassification - ON-MESSAGE (Form), message codes 40209 or 40207 | When a message with code 40209 or 40207 is raised anywhere on the form | Replaces the default system message with a formatted, descriptive error text, giving the user a clearer indication of what went wrong | Formatted error text displayed as an error; action cancelled |

---

---

#### Requirement ID: BR-013

**Requirement Title:** Form Exit and Database Session Clean-Up

**Business Description:**
When the user chooses to exit the dealer penetration report form, the system closes the form immediately without saving or validating any unsaved changes. At the same time, the system clears the database session tracking information that was registered when the form was opened, removing the module and client identifiers so the session no longer appears as actively running this form in the database monitoring tools.

**Actors:** Report User (OEM / Dealer staff)

**Preconditions:**
- The dealer penetration report form is open.

**Main Flow:**

**Step 1 - Form closed without saving**
When the user triggers the form exit action, the form closes immediately and discards any unsaved input without prompting for confirmation or attempting to save.

**Step 2 - Database session tracking information cleared**
The system clears the client identifier and module name from the database session, resetting both to null/empty. This ensures that after the form is closed, the database session no longer reports itself as being associated with this form module, keeping session monitoring data accurate.

---

---

#### Requirement ID: BR-014

**Requirement Title:** Non-Executing and Inactive Code Register

**Business Description:**
The following form elements exist in the codebase but do not execute in the current version of the form. They are documented here for completeness and traceability. None of these items affect any business outcome.

**Actors:** N/A (inactive elements - do not execute)

**Preconditions:**
- N/A

**Main Flow:**

**Step 1 - Inactive triggers (COMMENTED OUT / INACTIVE - do not execute)**

The following triggers are present in the form but are inactive and do not run:

- **KEY-COMMIT** (Form level): Body is `NULL;` - the commit shortcut is disabled entirely. `(COMMENTED OUT / INACTIVE - does not execute)`
- **FT_DEL (Delete toolbar trigger, unreachable path)**: The Delete toolbar button trigger checks whether the cursor is in block `B_GM_PROGRAM_MASTER` before proceeding. This block does not exist in the dealer penetration report form, so the delete branch - including the confirmation prompt *"Are you sure to Delete?"* - is never reached. The trigger body executes `NULL` for all practical purposes in this form. `(UNREACHABLE in this form - condition B_GM_PROGRAM_MASTER never satisfied - does not execute)`
- **WHEN-VALIDATE-ITEM on CB_BLK.P_TO_DT**: Entire body is a block comment followed by `NULL;` - To Date validation (empty check, future-date check, before-From-Date check, one-month range check) does not execute. `(COMMENTED OUT / INACTIVE - does not execute)`
- **WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY**: Empty body. `(COMMENTED OUT / INACTIVE - does not execute)`
- **WHEN-CUSTOM-ITEM-EVENT on WEBUTIL items** (WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL_FILE_FUNCTIONS, WEBUTIL_HOST_FUNCTIONS, WEBUTIL_SESSION_FUNCTIONS, WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL_OLE_FUNCTIONS, WEBUTIL_C_API_FUNCTIONS, WEBUTIL_BROWSER_FUNCTIONS): All have empty bodies. `(COMMENTED OUT / INACTIVE - do not execute)`

**Step 2 - Inactive and unreachable program units (do not execute)**

The following program units are present in the form but are either fully commented out or are not reachable from any active execution path:

- **VALIDATE_CN_MAIN**: Entire body is a block comment; stub is `NULL;`. `(COMMENTED OUT / INACTIVE - does not execute)`
- **CHECK_BEFORE_DELETE**: Entire body is a block comment; stub is `NULL;`. `(COMMENTED OUT / INACTIVE - does not execute)`
- **PR_REMOVE_ASCII_CHR**: Active procedure code present, but no active trigger in this form calls it - its call site in the Submit trigger was commented out. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **L_POPULATE**: Active procedure code present; no active caller found in any trigger. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **LIST_POPULATE_ZONE**: Active procedure code present; its only call was commented out in the Clear Form trigger. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **POP_LIST_REGION**: Active procedure code present; called only from the commented-out line in the Clear Form trigger. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **VIEW_EXCEL_REP**: Active procedure code present; called only from EXCEL_REPORT, which is itself unreachable. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **L_POP_LIST_ITEM**: Marked as commented out in its header; no active caller. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **EXCEL_REPORT**: Active procedure code present; call from the Submit trigger is commented out. `(UNREACHABLE from active execution paths - does not execute in this form)`
- **POPULATE_ERRORS**: Package specification only - declares a PL/SQL table variable; no executable body and not invoked from any active trigger. `(UNREACHABLE from active execution paths - does not execute in this form)`

---

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the form's code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | Region Is Mandatory | Validation | BR-002 | The Region field is left empty when the user moves away from it | Display the error *"Region Code can not be empty"* and return focus to the Region field | Prevents the user from proceeding with no region selected, which would produce a report with no geographic scope |
| BRC-002 | Region Change Clears Dependent Fields | Derivation | BR-002 | The user changes the Region selection | Clear the Dealer, Location Description, City code, Quarter, From Date, and To Date fields | Ensures that stale values from a previous region do not carry forward into a new region's report run |
| BRC-003 | Dealer Is Mandatory on Tab | Validation | BR-003 | The user presses the Tab/Next-Field key on the Dealer field and it is empty | Display the error *"Dealer can not be Blank)"* and return focus to the Dealer field | Prevents the user from advancing the cursor without selecting a dealer |
| BRC-004 | Quarter Is Mandatory on List Change | Validation | BR-004 | The Quarter drop-down is changed to an empty value | Display the error *"Quarter can not be Blank)"* and return focus to the Quarter field | Ensures a quarter is always set before the Financial Year and reporting period can be determined |
| BRC-005 | Quarter Is Mandatory on Tab | Validation | BR-004 | The user presses the Tab/Next-Field key on the Quarter field and it is empty | Display the error *"Quarter can not be Blank)"* and return focus to the Quarter field | Prevents the user from advancing without selecting a quarter |
| BRC-006 | Quarter Change Clears Financial Year | Derivation | BR-004 | The user changes the Quarter drop-down to any value | Clear the Financial Year field | Prevents a mismatch between the newly selected quarter and a previously selected financial year |
| BRC-007 | Quarter Maps to Month Number | Derivation | BR-004 | A valid quarter is selected (Q1, Q2, Q3, or Q4) | Derive the end-month number: Q1 -> 06, Q2 -> 09, Q3 -> 12, Q4 -> 03 | Provides the month component of the quarter-year period key used to filter the report |
| BRC-008 | Financial Year Is Mandatory on LOV Selection | Validation | BR-005 | The Financial Year lookup is completed and the field is empty | Display the error *"Financial Year can not be Blank)"* and return focus to the Financial Year field | Ensures a financial year is always selected before the period key can be formed |
| BRC-009 | Financial Year Is Mandatory on Tab | Validation | BR-005 | The user presses the Tab/Next-Field key on the Financial Year field and it is empty | Display the error *"Financial Year can not be Blank)"* and return focus to the Financial Year field | Same purpose as BRC-008; prevents an empty year from being accepted regardless of how the field is left |
| BRC-010 | Quarter-Year Key for Q1/Q2/Q3 | Derivation | BR-005 | A valid financial year is selected and the quarter is Q1, Q2, or Q3 | Form the quarter-year key using the selected financial year as the year component combined with the quarter's month number | Produces the reporting period key used to scope the penetration data |
| BRC-011 | Quarter-Year Key for Q4 Uses Next Calendar Year | Derivation | BR-005 | A valid financial year is selected and the quarter is Q4 | Form the quarter-year key using the selected financial year plus one as the year component, combined with month 03 | Correctly represents the Q4 period-end in March of the following calendar year |
| BRC-012 | Printer Destination Locks Format to Character Mode | Derivation | BR-006 | The user selects Printer as the destination | Set the Format field to `CHAR` (character mode) and disable it | Ensures the format is always compatible with printer output |
| BRC-013 | Non-Printer Destination Enables PDF Format | Derivation | BR-006 | The user selects any destination other than Printer | Set the Format field to `PDF` and enable it | Ensures the default output format is PDF when the destination supports it |
| BRC-014 | Non-Excel Format Clears and Locks File Name Field | Constraint | BR-007 | The Format field is changed to any value other than Excel | Clear the File Name field and set it to disabled and not navigable | Prevents the user from entering a file name that would be ignored for non-Excel output |
| BRC-015 | Excel Format Enables File Name Field | Constraint | BR-007 | The Format field is changed to Excel | Enable the File Name field and make it navigable | Allows the user to provide the destination file path for Excel output |
| BRC-016 | File Name Field Editing Controlled on Cursor Entry | Constraint | BR-007 | The cursor enters the File Name field | Allow insert and update only when the format is Excel; lock insert and update for all other formats | Ensures the field's edit state is consistent with the current format even if the cursor is moved directly into it |
| BRC-017 | From Date Is Mandatory | Validation | BR-008 | The user leaves the From Date field and it is empty | Display the alert *"From Date cannot be empty"* and raise a validation failure | Ensures a reporting start date is always provided |
| BRC-018 | Dealer Required at Submission | Validation | BR-009 | The Submit Report button is pressed and the Dealer field is empty | Display *"Dealer can not be Blank)"* and place the cursor on the Dealer field | Prevents report submission without a dealer scope |
| BRC-019 | Quarter Required at Submission | Validation | BR-009 | The Submit Report button is pressed and the Quarter field is empty | Display *"Quarter can not be Blank)"* and place the cursor on the Quarter field | Prevents report submission without a quarter period |
| BRC-020 | Financial Year Required at Submission | Validation | BR-009 | The Submit Report button is pressed and the Financial Year field is empty | Display *"Financial Year can not be Blank)"* and place the cursor on the Financial Year field | Prevents report submission without a financial year |
| BRC-021 | Excel Destination Blocked | Constraint | BR-009 | The Submit Report button is pressed and the selected destination is Excel | Display *"Excel is not available for this report!)"* and place the cursor on the Destination field | Prevents submission with an unsupported output type |
| BRC-022 | Quarter-Year Must Be Present for Report Assembly | Validation | BR-009 | The report parameters are being assembled and the quarter-year period key is absent | Display the informational alert *"Please Enter QTR YEAR"*; continue assembling the parameter string | Alerts the user that the period key is missing; assembly continues regardless |
| BRC-023 | Invalid Date Value Error | Validation | BR-011 | Forms error 50004 is raised anywhere on the form | Display *"Entered Date is not valid Date"* and cancel the triggering action | Replaces a cryptic system error code with a clear date-validation message |
| BRC-024 | Incorrect Date Format Error | Validation | BR-011 | Forms error 50025 or 50026 is raised anywhere on the form | Display *"Enter the Date in the proper format (DD-MM-YYYY)"* and cancel the triggering action | Guides the user to enter dates in the expected format |
| BRC-025 | Non-Numeric Characters in Numeric Field | Validation | BR-011 | Forms error 40209 or 50016 is raised anywhere on the form | Display *"Characters/Special Characters are not allowed here, enter the numeric value"* and cancel the action | Prevents non-numeric input in numeric fields |
| BRC-026 | Field-Level Error Text Displayed | Validation | BR-011 | Forms error 40207 is raised anywhere on the form | Display the error text associated with that error and cancel the action | Surfaces the specific field-level error text to the user |
| BRC-027 | Child Record Integrity Constraint | Constraint | BR-011 | Database error code -02292 (child record exists) is raised | Raise business error `E0088` and cancel the action | Prevents deletion or modification of a parent record that still has dependent child records |
| BRC-028 | Concurrent Record Modification Detected | Validation | BR-011 | Forms error 40654, 40655, 40656, 40657, or 40659 is raised | Display *"Record Has been Updated by other User, Please Requery the Record to do the Changes and then Save"*, roll back, and cancel the action | Informs the user of a concurrent update conflict and preserves data integrity |
| BRC-029 | General SQL Error Displayed and Rolled Back | Validation | BR-011 | A SQL error is present (SQL code is not zero) and no earlier specific handler matched | Display the database error text (dynamic SQLERRM content), perform a rollback, and cancel the action | Surfaces unexpected database errors for investigation and rolls back any partial changes |
| BRC-030 | Benign No-Data and Maximum-Records Messages Suppressed | Constraint | BR-011 | Forms error 40401 or 40405 is raised | Take no action and allow the form to continue | Prevents confusing or unnecessary messages when a query returns no rows or reaches the maximum row count |
| BRC-031 | Message Codes 40209 and 40207 Reclassified as Errors | Validation | BR-012 | Forms message 40209 or 40207 is raised | Build a formatted error text from the error type, code, and description; display it as an error; cancel the action | Ensures these message codes always appear as clearly formatted error messages rather than informational messages |
| BRC-032 | Financial Year Reset After Form Clear | Derivation | BR-010 | The user clears the form | Reset the Financial Year field to the combined financial year string derived from the session's stored period start and end years | Ensures the form returns to a meaningful default state after clearing |

**Total Business Rules Identified: 32**

---

## 6. Data Requirements

*This section documents the data entities referenced by the Dealer Penetration Report parameter form, the filter parameters captured from the user, the reference data used to populate lookup lists, and the data lifecycle applicable to this report-submission form.*

### 6.1 Business Entities and Relationships

*The form does not persist data to any directly owned base table. It reads from several reference and master tables to populate its filter drop-downs, and it reads report parameter configuration from the report parameters master to assemble the submission string.*

#### Report Parameter Configuration - ED_REPORTS

The report parameters master table (`ED_REPORTS`) stores the list of parameters that the form must assemble when running the dealer penetration report. The form reads this table at report submission time, filtered by the application identifier `vr_penetrate_dlr` and the current session's principal, to determine which parameter names to include and in what order. No records are inserted or updated by this form.

#### Dealer and Location Master - AM_DEALER_LOC and AM_DEALER_LOC_PARAM

The dealer location master (`AM_DEALER_LOC`) and dealer location parameter table (`AM_DEALER_LOC_PARAM`) are read to populate the Dealer lookup list. The list is restricted to dealers that have the DMS (Dealer Management System) flag set, belong to the current session's parent group and dealer mapping, and whose principal mapping matches the session's principal.

#### Zone and Region Reference - GM_REGN

The zone and region master (`GM_REGN`) is referenced by the Zone list population procedure to derive zone descriptions and zone codes for the Region drop-down, filtered by country code and principal. This table is read-only for this form.

#### Financial Year Master - FM_COMPANY

The company master (`FM_COMPANY`) is used to populate the Financial Year lookup. The form queries it for open financial years associated with the current session's parent group, location, dealer, and company code.

#### Extended Warranty Incentive Detail - VD_EW_INCE_DTL

The extended warranty incentive detail table (`VD_EW_INCE_DTL`) is referenced within the `EXCEL_REPORT` program unit, which builds a query to retrieve penetration data filtered by dealer, location, and transaction month. This program unit is currently unreachable from any active trigger path (its call site is commented out); the table reference is documented here for completeness. `(UNREACHABLE from active execution paths - does not execute in this form)`

#### Entity Relationships

The form is a parameter-entry and report-submission screen with no master-detail block relationships. The blocks carry no base tables and own no persistable rows. The reference tables are read independently based on the session's contextual values (principal, parent group, dealer, location). No foreign-key or parent-child relationship between the above tables is navigated or enforced by this form's active code.

```
ED_REPORTS            (report parameter configuration - read at submission)
AM_DEALER_LOC         (dealer master - read to populate Dealer lookup)
AM_DEALER_LOC_PARAM   (dealer parameters - joined to AM_DEALER_LOC for DMS filter)
GM_REGN               (zone/region reference - read to populate Region list)
FM_COMPANY            (financial year master - read to populate Financial Year lookup)
VD_EW_INCE_DTL        (EW incentive detail - referenced in inactive EXCEL_REPORT path only)
```

No evidenced parent-child or join relationships cross the above nodes in active code; they are shown as independent references rather than a hierarchy.

---

### 6.2 Data Capture Requirements

*The form captures filter parameters chosen by the user and assembles them into a report submission string. All block items are non-database (no base tables); values are held in memory for the duration of the report session.*

#### Report Filter Parameters (User - before submission)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Region (`P_REGION_CD`) | Yes | The region selected by the user to scope the report geographically. Sourced from the Region list populated from the zone/region master. | Must not be empty when the user leaves the field - error *"Region Code can not be empty"* displayed otherwise |
| Dealer (`P_DEALER_DESC`) | Yes | The dealer name chosen from the dealer lookup. Cleared when Region changes. The dealer code (`P_DEALER`) is stored separately as the system value. | Must not be empty when the user tabs away - error *"Dealer can not be Blank)"* displayed otherwise |
| Dealer Code (`P_DEALER`) | Auto-Populated | The numeric dealer code associated with the selected dealer name. Populated automatically when the dealer is selected from the lookup. | Cleared when Region changes; used as the report parameter value |
| Location/City Description (`P_CITY_DESC`) | No | Display label for the dealer's location. Cleared when Region changes. | Not user-editable (enabled = false) |
| City Code (`P_CITY`) | No | The city/location code for the selected dealer. Cleared when Region changes. | Not user-editable (enabled = false) |
| Location Code (`P_LOC`) | No | An additional location code field. Not user-editable. | Not user-editable (enabled = false) |
| Quarter (`QUARTER`) | Yes | The financial quarter selected by the user (Q1, Q2, Q3, or Q4). Cleared when Region changes. | Must not be empty when changed or when Tab is pressed - error *"Quarter can not be Blank)"* displayed otherwise |
| Financial Year (`FINANCIAL_YEAR`) | Yes | The financial year selected from the Financial Year lookup. Cleared when Quarter changes. | Must not be empty after the lookup or Tab key - error *"Financial Year can not be Blank)"* displayed otherwise |
| As On Date (`P_MONTHYEAR`) | Conditional | Month/year period selector available on the form. | Visible and enabled |
| From Date (`P_FROM_DT`) | Yes | The start date of the reporting period. Enabled = false (auto-derived from quarter/financial year in commented-out code; manually entered in the active form). | Must not be empty when the user leaves the field - alert *"From Date cannot be empty"* displayed otherwise |
| To Date (`P_TO_DT`) | No | The end date of the reporting period. Enabled = false. Validation for this field is commented out (inactive). | Inactive - does not execute |
| Report Type (`P_REPO_TYPE`) | Yes | The type of report to generate. Required property set on the item. | Required |
| Destination (`P_DESTYPE`) | Yes | Where the report output should be delivered (PRINTER, FILE, CACHE, or MAIL). Required property set. Excel destination is blocked at submission. | Required; Excel not permitted - *"Excel is not available for this report!)"* |
| Format (`P_DESFORMAT`) | Yes | The output format for the report (CHAR, PDF). Required property set. Controlled automatically by the Destination selection; disabled when Printer. | Required; set to CHAR and disabled when Printer, set to PDF and enabled otherwise |
| File Name (`FILENAME`) | Conditional - when Excel format | The destination file path for Excel output. Enabled and navigable only when format is Excel; cleared and locked otherwise. | Editable only when Excel format is selected |
| For Code Description (`P_FOR_DESC`) | No | A display-only description field. Not visible or enabled. | Not user-editable (visible = false) |
| Report Description (`REPORT_DESC`) | Auto-Populated | A display field showing the report description, set from the session global. | Display only; 200 characters |

#### Session and Non-Database Parameters (System - at form load)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Report Name (`REPORT_NAME`) | Auto-Populated | The Oracle Reports file name used for the report object. Set at form load from configuration. | System-managed |
| Report Server (`REP_SERVER`) | Auto-Populated | The name of the report server used to submit the report job. Sourced from the session global. | System-managed |
| Application ID (`APP_ID`) | Auto-Populated | The application identifier (`vr_penetrate_dlr`) used to filter report parameter configuration. | System-managed |
| For Code (`P_FOR_CD`) | Auto-Populated | The OEM for-code associated with the session's principal. | System-managed |
| Financial Year numeric (`FINANCIAL_YEAR` / `YEAR`) | Auto-Populated | Internal numeric year value derived from the Financial Year selection. | Derived |
| Quarter-Year Key (`P_QTR_YEAR`) | Auto-Populated | The combined quarter-year period key (year + month number) assembled from the selected Quarter and Financial Year. Used as the primary report date filter. | Derived from Quarter and Financial Year selections |

---

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form to populate drop-down lists and assemble report parameters.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Dealer Lookup (LV_DEALER / RG_DEALER - AM_DEALER_LOC + AM_DEALER_LOC_PARAM + GM_FOR) | Provides the list of authorised dealers the user can select, restricted to DMS-enabled dealers for the current session's principal and parent group | When the user opens the Dealer lookup field |
| City/Location Lookup (LV_CITY / RG_CITY - MULDMS.AM_DEALER_LOC) | Provides location codes and descriptions for the selected dealer, including an option for all locations | When the user opens the City/Location lookup field |
| Financial Year Lookup (LV_FINANCIAL_YEAR / RG_FINANCIAL_YEAR - FM_COMPANY) | Provides the list of open financial years for the current session's parent group, location, dealer, and company code | When the user opens the Financial Year lookup on the Financial Year field |
| Region List (RG_REGION - AM_USER_REGION + AM_DEALER_LOC) | Provides the region codes assigned to the current user for service-type access, filtered by the session's principal | When the Region list is populated (via the zone population procedure) |
| List Master (AM_LIST) | Provides code-description pairs for various application lists, filtered by list name and principal. Referenced by the L_POPULATE procedure (currently unreachable in active code). | Referenced by the inactive L_POPULATE program unit - `(UNREACHABLE from active execution paths)` |
| Report Parameter Configuration (ED_REPORTS) | Defines which parameters must be assembled for the dealer penetration report, including parameter names and serial order, filtered by application ID and principal | When the Submit Report button is pressed (during parameter assembly in PR_PASS_PARAM) |
| Company Alert (AL_ERRINFO - form alert) | Used to display alert popups for validation failures on the From Date field and for the quarter-year presence check in parameter assembly | When From Date validation fails; when quarter-year key is absent during submission |
| Report Object (REPORT_CALL) | The Oracle Forms report object used to configure and submit the report job | When the Submit Report button is pressed |

---

### 6.4 Data Lifecycle

*This form is a parameter-entry and report-submission form with no owned persistent data. All data lifecycle behaviour is limited to the session and to report submission.*

**Creation**

- No records are inserted into any database table by this form. The form is purely a report-parameter screen.
- The only write-like operation is parameter string assembly and report job submission, performed when the user presses the Submit Report button (via the WHEN-BUTTON-PRESSED trigger on the Submit button).

**Updates**

- No database records are updated by this form.
- Filter field values on screen are updated by the user's selections; the Region change trigger and Quarter change trigger automatically clear dependent fields when their respective owning fields change.
- The database session monitoring identifiers (module name and client info) are updated when the form opens (PRE-FORM trigger) and cleared when it exits (KEY-EXIT trigger).

**Save and Commit**

- There is no save or commit operation in this form. The KEY-COMMIT trigger is set to `NULL` (inactive) - the commit shortcut is disabled.
- The report is submitted by calling the Oracle Reports runtime (`RUN_REPORT_OBJECT`) and the result is displayed in the user's browser via `WEB.SHOW_DOCUMENT`. No database transaction is committed.

**Retention and Audit**

- The form does not implement any record creation or modification timestamps on database entities.
- Application session monitoring data (module name and client identifier) is recorded in the database session at form open and cleared at form exit via the PRE-FORM and KEY-EXIT triggers; this is session-scoped only and is not persisted to any audit table by this form.
- No archival or retention policy is evidenced in this form's code.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | Not evidenced in source | S.No. |  |  |  | Row sequence number generated by ROWNUM applied to the VD_EW_INCE_DTL result set; not a physical stored column. |
| 2 | Not evidenced in source | Dealer Map Code |  | VD_EW_INCE_DTL | DEALER_MAP_CD | Dealer mapping code read directly from VD_EW_INCE_DTL and also used as the WHERE filter key (DEALER_MAP_CD = :P_DEALER). |
| 3 | Not evidenced in source | Loc Code |  | VD_EW_INCE_DTL | LOC_CD | Location code read from VD_EW_INCE_DTL; filtered by :P_CITY via DECODE when a specific city is selected. |
| 4 | Not evidenced in source | Mul Dealer Code |  | VD_EW_INCE_DTL | MUL_DEALER_CD | Multi-dealer code for the dealer row, sourced directly from VD_EW_INCE_DTL. |
| 5 | Not evidenced in source | Dealer Name |  | VD_EW_INCE_DTL | DEALER_NAME | Dealer name sourced directly from VD_EW_INCE_DTL. |
| 6 | Not evidenced in source | Loc_Desc |  | VD_EW_INCE_DTL | LOC_DESC | Location description sourced directly from VD_EW_INCE_DTL. |
| 7 | Not evidenced in source | City |  | VD_EW_INCE_DTL | CITY | City name sourced directly from VD_EW_INCE_DTL. |
| 8 | Not evidenced in source | Retail |  | VD_EW_INCE_DTL | RETAIL | Retail sales count for the dealer and period, sourced directly from VD_EW_INCE_DTL. |
| 9 | Not evidenced in source | EW1_Sale |  | VD_EW_INCE_DTL | EW1_SALE | Extended Warranty type-1 sales count sourced directly from VD_EW_INCE_DTL. |
| 10 | Not evidenced in source | EW2_Sale |  | VD_EW_INCE_DTL | EW2_SALE | Extended Warranty type-2 sales count sourced directly from VD_EW_INCE_DTL. |
| 11 | Not evidenced in source | Total_EW |  | VD_EW_INCE_DTL | TOTAL_EW | Total Extended Warranty sales (EW1 + EW2) sourced directly from VD_EW_INCE_DTL. |
| 12 | Not evidenced in source | EW_Pen |  | VD_EW_INCE_DTL | EW_PEN | Overall Extended Warranty penetration percentage sourced directly from VD_EW_INCE_DTL. |
| 13 | Not evidenced in source | EW11_Pen |  | VD_EW_INCE_DTL | EW11_PEN | EW type-11 penetration percentage sourced directly from VD_EW_INCE_DTL. |
| 14 | Not evidenced in source | Slab1 |  | VD_EW_INCE_DTL | SLAB1 | Incentive slab 1 value for the dealer, sourced directly from VD_EW_INCE_DTL. |
| 15 | Not evidenced in source | Slab2 |  | VD_EW_INCE_DTL | SLAB2 | Incentive slab 2 value for the dealer, sourced directly from VD_EW_INCE_DTL. |
| 16 | Not evidenced in source | Slab3 |  | VD_EW_INCE_DTL | SLAB3 | Incentive slab 3 value for the dealer, sourced directly from VD_EW_INCE_DTL. |
| 17 | Not evidenced in source | Slab4 |  | VD_EW_INCE_DTL | SLAB4 | Incentive slab 4 value for the dealer, sourced directly from VD_EW_INCE_DTL. |
| 18 | Not evidenced in source | Slab5 |  | VD_EW_INCE_DTL | SLAB5 | Incentive slab 5 value for the dealer, sourced directly from VD_EW_INCE_DTL. |
| 19 | Not evidenced in source | TOTAL_INC |  | VD_EW_INCE_DTL | TOTAL_INC | Total incentive amount for the dealer across all slabs, sourced directly from VD_EW_INCE_DTL. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| AM_DEALER_LOC | Dealer location master table - stores dealer codes, names, location codes, parent group assignments, and principal mappings | Dealer Location Master | Dealer, Location, Parent Group |
| AM_LIST | Application list master table - stores list item labels and codes used to populate dynamic form dropdowns | List Master | List Item, L_POPULATE |
| AM_USER_REGION | User-region mapping table - records the region codes each user is authorised to access for reporting | User Region Mapping | Region, USERID |
| BRD | Business Requirements Document - this document; records functional and technical requirements for migration | - | - |
| CB_BLK | Control block - the single Oracle Forms data block in this form holding all report parameter fields; not bound to a database table | Control Block | Block |
| DMS | Dealer Management System - integrated software platform for dealership operations including sales, service, and reporting | - | System |
| DPL | Shared program library (`DPL.pld`) containing common Oracle Forms utility procedures such as DISP_TEXT and RAISE_ERROR | DPL Library, DPL.pld | PLD, DISP_TEXT, RAISE_ERROR |
| ED_REPORTS | Report parameter configuration table - stores parameter definitions and default values for each Oracle Reports module | Report Catalogue | PR_PASS_PARAM, Oracle Reports |
| EW | Extended Warranty - a post-sale service contract extending the manufacturer's warranty coverage period | Extended Warranty | EW Penetration, VD_EW_INCE_DTL |
| FM_COMPANY | Company financial master table - stores financial year records used to populate the financial year selection list | Company Master | Financial Year, RG_FINANCIAL_YEAR |
| GM_REGN | Region master table - stores region codes and descriptions used to populate the region and zone selection lists | Region Master | Region, LIST_POPULATE_ZONE |
| GM_FOR | For-code master table - stores city/for-code descriptions referenced in the dealer selection query | For Code Master | For Code, P_FOR_CD |
| LOV | List of Values - a popup selection list in Oracle Forms allowing the user to pick a value from a filtered dataset | Dropdown, Picklist | RG_DEALER, RG_CITY, RG_FINANCIAL_YEAR |
| OLB | Object Library - an Oracle Forms binary file (`.olb`) containing reusable objects, property classes, and visual attributes inherited by forms | Object Library File | DPL.olb, WEBUTIL.olb |
| Oracle Reports | Oracle-provided reporting engine that generates formatted PDF or character-mode reports; invoked by this form via a report object | Reports Server | Report Object, PDF Output |
| PCK | PL/SQL package source file (`.pck`) containing one or more stored procedure and function implementations | Package Source | Package, Stored Procedure |
| PDF | Portable Document Format - the default output format for reports generated by this form; opened directly in the user's browser | - | Oracle Reports, Output Format |
| Penetration | Extended-warranty penetration rate - the percentage of vehicle sales for which an extended-warranty contract was sold | EW Penetration Rate | EW, VD_EW_INCE_DTL |
| PLD | Program Library Definition - a shared Oracle Forms library file (`.pld`) containing reusable PL/SQL procedures attached to multiple forms | Shared Library, PLD File | DPL, webutil |
| Principal | A business grouping code (principal map code) used to scope dealer, zone, and city queries to the correct business unit | Principal Map Code | PRINCIPAL, Dealer |
| Q/I/U/D | Query / Insert / Update / Delete - four DML permission flags indicating which database operations a form block allows | DML Flags | Block, CB_BLK |
| RG | Record Group - an Oracle Forms in-memory tabular structure used to hold the rows returned by a LOV query | Record Group | LOV, RG_DEALER, RG_REGION |
| VD_EW_INCE_DTL | Extended-warranty incentive detail view - database view providing dealer penetration report data for Excel output | EW Incentive Detail | EW, EXCEL_REPORT |
| VR_PENETRATE_DLR | The Oracle Forms module documented in this BRD - the Dealer Penetration Report screen | vr_penetrate_dlr, Dealer Penetration Report | DMS, EW, Oracle Reports |
| WEBUTIL | Oracle Forms WebUtil library - provides client-side utility functions such as file handling and browser interaction; referenced via `webutil.pld` and `webutil.olb` | WebUtil Library | PLD, OLB |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_penetrate_dlr (VR_PENETRATE_DLR)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, D2KWUTIL, DPL (DPL.pld program library), WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WEBUTIL_HIDDEN_WINDOW (inherited webutil infrastructure window; no visible business window defined in form)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, menu.mmx
- Source artifacts: `vr_penetrate_dlr_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; D2KWUTIL; DPL (DPL.pld program library); WEBUTIL (webutil.olb)

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier used to identify this form context (e.g. `vr_penetrate_dlr`) |
| APP_LOG | Char | Trigger | Logging flag (`Y`/`N`) controlling whether the performance timer is started at form open |
| COMP_FA | Char | RecordGroup / Trigger | Company financial account code used to filter the financial year record group |
| CURRENCY | Char | Trigger | Currency code used to scope currency-sensitive report parameters at runtime |
| CUR_DATE | Char | ProgramUnit | Current system date passed to commented-out validation logic (INFERRED - used only in inactive code) |
| DEALER | Char | RecordGroup / Trigger | Dealer map code used to bind dealer-specific queries in record groups |
| FIN_BEG | Char | Trigger | Financial year begin date used to calculate and display the current financial year label |
| FIN_END | Char | Trigger | Financial year end date used to calculate and display the current financial year label |
| LOC_CD | Char | RecordGroup / Trigger | Location code used to filter the financial year record group |
| PARENT_GROUP | Char | RecordGroup / Trigger | Parent group code used to scope dealer, location, and financial year queries |
| PRINCIPAL | Char | ProgramUnit / RecordGroup / Trigger | Principal map code used to filter dealer and zone list queries |
| P_FIN_YR | Char | Trigger | Financial year parameter value set at runtime and passed to the report as a filter for the selected financial year |
| REPORT_DESC | Char | Trigger | Report description label restored when the form is cleared |
| REPORT_NAME | Char | Trigger | Report module filename stored globally and used to populate the report name field at form initialisation |
| REP_SERVER | Char | Trigger | Report server name used to route report output at submission time |
| USERID | Char | ProgramUnit / RecordGroup / Trigger | Logged-in user ID used for region filtering, Excel file naming, and audit context |
| USER_NAME | Char | Trigger | Display name of the logged-in user set at form startup and used in header or audit labelling |

### 8.1.2 Form Parameters

*All 5 ModuleParameter entries from vr_penetrate_dlr_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_USER_TYPE | Char | DLR | Controls user type context; default `DLR` indicates dealer user; used to scope zone and region list queries in `LIST_POPULATE_ZONE` |
| P_CHECK | Char | - | Reserved check flag passed into the form; not actively used in current form logic |
| P_REGION | Char | - | Incoming region code pre-filter passed at form startup; used to seed the region list |
| P_USER_HORO | Char | - | User hierarchy orientation indicator (e.g. `HO` for head-office users); governs zone query logic in `LIST_POPULATE_ZONE` |
| P_APP_ID | Char | - | Application ID passed at startup to identify the calling context; stored in `:global.app_id` |

**Total Parameters:** 5

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_BLK | - | 1 | N/N/N/N | Default | Control block - entry point for report parameter selection; no master-detail relationship |

**Total Blocks:** 1 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_penetrate_dlr_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_penetrate_dlr_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_penetrate_dlr_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_BLK | 35 | 0 | 35 |
| PB_BLK | 12 | 0 | 12 |
| CB_ERR | 1 | 0 | 1 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **57** | **0** | **57** |

**Item detail (all 57 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_BLK | LOC_DESC | false | Location description display field showing the location name |
| CB_BLK | REPORT_DESC | false | Report description label displayed on the form header |
| CB_BLK | P_REGION_CD | false | Region code selection list; user selects the target region |
| CB_BLK | P_FOR_DESC | false | For code description text field showing the selected for-code label |
| CB_BLK | P_MONTHYEAR | false | Month/year selection list for month-based report filtering |
| CB_BLK | P_DEALER_DESC | false | Dealer name entry field; populated via LOV or manual input for dealer selection |
| CB_BLK | P_CITY_DESC | false | City/location description text field showing the selected location label |
| CB_BLK | P_CITY | false | City/location code field holding the selected LOV return value |
| CB_BLK | QUARTER | false | Quarter selection list (Q1-Q4) for quarterly report period selection |
| CB_BLK | FINANCIAL_YEAR | false | Financial year selection field; populated via LV_FINANCIAL_YEAR LOV |
| CB_BLK | P_DESTYPE | false | Report destination type list (Excel, Screen/Cache, Printer) |
| CB_BLK | SUBMIT | false | Submit Report button; triggers parameter validation and report execution |
| CB_BLK | P_QTR | false | Derived quarter parameter field holding computed quarter value for report |
| CB_BLK | P_FIN_YEAR | false | Derived financial year parameter field holding computed year value for report |
| CB_BLK | P_QTR_YEAR | false | Derived quarter-year parameter field combining quarter and year for report |
| CB_BLK | YEAR | false | Derived year parameter field holding computed year value |
| CB_BLK | P_FROM_DT | false | From date text field for date-range report filtering |
| CB_BLK | P_TO_DT | false | To date text field for date-range report filtering |
| CB_BLK | P_REPO_TYPE | false | Report type selection list controlling report sub-type |
| CB_BLK | P_PARENT | false | Parent group parameter field holding parent group code for report |
| CB_BLK | P_DEALER | false | Dealer map code parameter field holding selected dealer code for report |
| CB_BLK | P_LOC | false | Location code text field for location-based report filtering |
| CB_BLK | APP_ID | false | Application ID field holding the form application identifier |
| CB_BLK | REPORT_NAME | false | Report name field holding the report module filename to execute |
| CB_BLK | REP_SERVER | false | Report server name field used to specify the target Oracle Reports server |
| CB_BLK | P_FOR_CD | false | For code parameter field holding the selected for-code value for report |
| CB_BLK | P_T_PARENT | false | Total/target parent group parameter field for report totals |
| CB_BLK | P_T_DEALER | false | Total/target dealer parameter field for report totals |
| CB_BLK | P_T_LOC | false | Total/target location parameter field for report totals |
| CB_BLK | P_DLR | false | Dealer parameter field (alternate) used in report parameter string |
| CB_BLK | P_DES_TYPE | false | Destination type text field (alternate) reflecting selected destination |
| CB_BLK | P_DESFORMAT | false | Output format list (PDF, CHARACTER) controlling report output format |
| CB_BLK | FILENAME | false | File name text field for Excel/CSV output file naming |
| CB_BLK | CK | false | Check field; reserved for internal use |
| CB_BLK | COPYRIGHT_DECLARATION | false | Copyright declaration text field displaying legal notice |
| PB_BLK | PB_EXIT | false | Exit button (inherited from DPL.olb OG_GROUP); closes the form when pressed (inherited) |
| PB_BLK | PB_LIST | false | List-of-values button (inherited from DPL.olb OG_GROUP); opens the LOV for the current item (inherited) |
| PB_BLK | PB_INSERT | false | Insert button (inherited from DPL.olb OG_GROUP); initiates a new record insert (inherited) |
| PB_BLK | PM_CONT | false | Continue/context button (inherited from DPL.olb OG_GROUP); navigates to the next logical step (inherited) |
| PB_BLK | PB_DEL | false | Delete button (inherited from DPL.olb OG_GROUP); deletes the current record (inherited) |
| PB_BLK | PB_CANCEL | false | Cancel button (inherited from DPL.olb OG_GROUP); cancels pending changes (inherited) |
| PB_BLK | PB_SAVE | false | Save button (inherited from DPL.olb OG_GROUP); commits the current transaction (inherited) |
| PB_BLK | PB_PRINT | false | Print button (inherited from DPL.olb OG_GROUP); triggers the print action (inherited) |
| PB_BLK | PB_CUT | false | Cut button (inherited from DPL.olb OG_GROUP); cuts selected text to clipboard (inherited) |
| PB_BLK | PB_COPY | false | Copy button (inherited from DPL.olb OG_GROUP); copies selected text to clipboard (inherited) |
| PB_BLK | PB_PASTE | false | Paste button (inherited from DPL.olb OG_GROUP); pastes clipboard text into the current field (inherited) |
| PB_BLK | PB_ERR_EXIT | false | Error-exit button (inherited from DPL.olb OG_GROUP); closes the error window and returns focus to the main canvas (inherited) |
| CB_ERR | TXT_ERR | false | Error message text item displayed in the error canvas (CN_ERR); shows the runtime error description (inherited) |
| WEBUTIL | DUMMY | false | WebUtil placeholder button item; no active business logic; infrastructure item used by the webutil library (inherited) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | WebUtil bean area item providing client information functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | WebUtil bean area item providing client-side file operation functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | WebUtil bean area item providing host command execution functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | WebUtil bean area item providing session management functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | WebUtil bean area item providing file transfer functions between client and server; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | WebUtil bean area item providing OLE automation functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | WebUtil bean area item providing C API call functions; infrastructure item (inherited) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | WebUtil bean area item providing browser control functions; infrastructure item (inherited) |

### 8.4 List of Values

| LOV Name | Title | Record Group | Attached Block.Item |
| :--- | :--- | :--- | :--- |
| LV_DEALER | Dealer Master | RG_DEALER | CB_BLK.P_DEALER_DESC |
| LV_CITY | Loc | RG_CITY | CB_BLK.P_CITY |
| LV_FINANCIAL_YEAR | Financial_Year | RG_FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR |

**Total LOVs:** 3

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | WebUtil library internal error handler; subclassed from webutil.olb and invoked by WebUtil library routines when a client-side operation fails (inherited) |
| ALERT_BUT | Note | Please select valid region code and for code | Displayed when region code or for-code validation fails; referenced contextually from CB_BLK.P_REGION_CD validation logic |
| AL_PRINT | Print | (set at runtime) | Inherited print-confirmation alert from DPL.olb OG_GROUP; displayed by `GENERAL.ASK_CONFIRM` / `ASK_PRINT` before sending output to a printer (inherited) |
| AL_ERRINFO | Error | (set at runtime) | Inherited error-information alert from DPL.olb OG_GROUP; used by `GENERAL.DISP_TEXT` to display error-level messages throughout the form (inherited) |
| AL_NOTE | Note | (set at runtime) | Inherited informational alert from DPL.olb OG_GROUP; used by `GENERAL.DISP_TEXT` to display note-level messages throughout the form (inherited) |
| AL_CONFIRM | Caution | (set at runtime) | Inherited caution/confirmation alert from DPL.olb OG_GROUP; used by `GENERAL.ASK_CONFIRM` to prompt the user before destructive operations (inherited) |

**Total Alerts:** 6

### 8.6 Program Units

*Authoritative catalogue of **11 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| VALIDATE_CN_MAIN | Unknown | **COMMENTED OUT / INACTIVE** - `GENERAL.CHECK_NULL` | **COMMENTED OUT / INACTIVE** - Previously validated required fields on a test drive block (plate number, model year, test date); entire procedure body is block-commented and never called |
| CHECK_BEFORE_DELETE | Unknown | **COMMENTED OUT / INACTIVE** - SH_ENQUIRY (SELECT) | **COMMENTED OUT / INACTIVE** - Previously checked for dependent enquiry records before deleting a zone master entry; body is `NULL;` with commented logic |
| POPULATE_ERRORS | Package spec | None (type reference only: `pk_plsql_table.code_tab`) | Package specification declaring `v_tab` PL/SQL table variable; no body; used as a shared error-collector type declaration |
| L_POPULATE | Procedure | AM_LIST (SELECT), FIND_ITEM, FIND_GROUP, ID_NULL (webutil), DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, POPULATE_LIST | Populates a form list item by executing a dynamic query against `AM_LIST` filtered by list name and principal; used to load list items at form startup |
| PR_REMOVE_ASCII_CHR | Procedure | TEXT_IO, WEB.SHOW_DOCUMENT, GENERAL.DISP_TEXT | Reads a CSV report file, strips non-printable ASCII characters from each line, writes a cleaned output file, and opens the result in the browser; used for Excel report post-processing |
| PR_PASS_PARAM | Procedure | ED_REPORTS (SELECT), FIND_ALERT, SET_ALERT_PROPERTY, SHOW_ALERT | Builds the Oracle Reports parameter string by reading report parameter definitions from `ED_REPORTS` and mapping current form field values; called before report submission |
| LIST_POPULATE_ZONE | Procedure | GM_REGN (SELECT), FIND_GROUP, ID_NULL (webutil), CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, POPULATE_LIST | Populates zone or region list items dynamically based on the parameter name; applies user-type and hierarchy filters when constructing the query against `GM_REGN` |
| POP_LIST_REGION | Procedure | POPULATE_GROUP, POPULATE_LIST | Populates the region code list item (`P_REGION_CD`) from the `RG_REGION` record group; executed at form initialisation |
| VIEW_EXCEL_REP | Procedure | NAME_IN, FIND_GROUP, ID_NULL (webutil), DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP, GET_GROUP_ROW_COUNT, FIND_COLUMN, GET_GROUP_CHAR_CELL, WEB.SHOW_DOCUMENT | Creates an in-memory record group from a passed SQL query, iterates rows to build a CSV string, writes the content to a text file, and opens it in the browser as an Excel download |
| L_POP_LIST_ITEM | Procedure | FIND_GROUP, ID_NULL (webutil), DELETE_GROUP, CREATE_GROUP_FROM_QUERY, POPULATE_GROUP | **COMMENTED OUT / INACTIVE** - Previously populated a list item dynamically from a passed SQL query using a record group; procedure body is entirely block-commented |
| EXCEL_REPORT | Procedure | DUAL (SELECT), VD_EW_INCE_DTL (SELECT), VIEW_EXCEL_REPORT_NEW | Constructs a CSV query against `VD_EW_INCE_DTL`, generates a timestamped filename, and calls `VIEW_EXCEL_REPORT_NEW` to produce and display the Excel file |

**Total Program Units:** 11

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level, PB_BLK.PB_EXIT (inherited) | Displays a confirmation dialog (using AL_CONFIRM or AL_PRINT) and returns the button pressed; used to prompt the user before exit or print actions |
| GENERAL.CHECK_NULL | Library routine | ProgramUnit: VALIDATE_CN_MAIN (inactive/commented) | Validates that a required field value is not null; displays "Enter a valid {column_title}" error and raises FORM_TRIGGER_FAILURE |
| GENERAL.DISP_TEXT | Library routine | CB_BLK.FINANCIAL_YEAR, CB_BLK.P_DEALER_DESC, CB_BLK.P_REGION_CD, CB_BLK.QUARTER, CB_BLK.SUBMIT, Form level, ProgramUnit: CHECK_BEFORE_DELETE, ProgramUnit: PR_REMOVE_ASCII_CHR, ProgramUnit: VALIDATE_CN_MAIN | Displays a modal alert dialog with a given message and title; uses AL_ERRINFO for errors and AL_NOTE for informational messages |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up an error message by code and displays it as an error, note, or caution dialog; raises FORM_TRIGGER_FAILURE for error-type messages |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | KEY-COMMIT | Previously committed the current form data to the database | Replaced with `NULL;` stub - form uses WHEN-BUTTON-PRESSED on SUBMIT instead of KEY-COMMIT for report submission; no DML commit is required |
| **Commented out** | Form | - | FT_SAVE | Previously executed the save/commit action from the toolbar save button | Body is block-commented; toolbar save action is not applicable in this report-only form |
| **Commented out** | CB_BLK | P_TO_DT | WHEN-VALIDATE-ITEM | Previously validated that To Date is not null, not greater than today, not less than From Date, and within a one-month range from From Date | Entire trigger body block-commented; current implementation replaces body with `NULL;` - date range validations removed or deferred |
| **Commented out** | PB_BLK | PB_EXIT | WHEN-BUTTON-PRESSED | Previously called `GENERAL.ASK_CONFIRM` to prompt the user before exiting the form | Body is block-commented; exit confirmation logic disabled in current version (inherited) |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (47 business triggers):**
*vr_penetrate_dlr_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | Intercepts form errors; displays a date-format error message for error code 50004 and date-range messages for codes 50025/50026; delegates other errors to `GENERAL.RAISE_ERROR` |
| ON-MESSAGE | Form | - | Form level | Intercepts form messages; suppresses informational messages for codes 40209/40207 by displaying them via `GENERAL.DISP_TEXT` and raising FORM_TRIGGER_FAILURE |
| KEY-EXIT | Form | - | Form level | Exits the form without validation and clears the DBMS application info session context |
| KEY-LISTVAL | Form | - | Form level | Retrieves the LOV name for the current item and displays it; navigates to the next item on successful LOV selection |
| KEY-COMMIT | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Inactive stub (`NULL;`); form uses WHEN-BUTTON-PRESSED on SUBMIT for report submission instead |
| KEY-CLRFRM | Form | - | Form level | Clears the form without validation, restores the report description label, and recalculates the financial year label from global begin and end year values |
| KEY-OTHERS | Form | - | Form level | Inherited key handler that suppresses or handles all other unassigned keyboard keys at form level (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited handler that navigates to the next item in tab order at form level (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited handler that navigates to the previous item in tab order at form level (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited handler that navigates to the next block at form level (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited handler that navigates to the previous block at form level (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited handler that navigates to the next record or item downward at form level (inherited) |
| KEY-UP | Form | - | Form level | Inherited handler that navigates to the previous record or item upward at form level (inherited) |
| FT_SAVE | Form | - | Form level | **COMMENTED OUT / INACTIVE** - Inherited toolbar save trigger; body is block-commented; save action not applicable in this report-only form (inherited) |
| FT_CANCEL | Form | - | Form level | Inherited toolbar cancel trigger; cancels pending changes and clears the current block (inherited) |
| FT_INSERT | Form | - | Form level | Inherited toolbar insert trigger; initiates a new record insert on the current block (inherited) |
| FT_DEL | Form | - | Form level | Inherited toolbar delete trigger; deletes the current record after confirmation (inherited) |
| FT_LIST | Form | - | Form level | Inherited toolbar LOV trigger; opens the LOV for the currently focused item (inherited) |
| FT_PRINT | Form | - | Form level | Inherited toolbar print trigger; invokes the print action for the current block (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | Initialises the form at startup: sets DBMS application info, loads global variables, populates list items, seeds the region list, and sets the financial year label (inherited) |
| PRE-FORM | Form | - | Form level | Starts the performance timer if application logging is enabled; sets DBMS application info module context to `vr_penetrate_dlr` |
| WHEN-VALIDATE-ITEM | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Validates that region code is not empty; displays error and raises FORM_TRIGGER_FAILURE if null; clears the for-code description when a valid region is selected |
| WHEN-LIST-CHANGED | CB_BLK | P_REGION_CD | CB_BLK.P_REGION_CD | Clears dependent fields (city, dealer, quarter, from date, to date, city description) when the region selection changes |
| KEY-NEXT-ITEM | CB_BLK | P_DEALER_DESC | CB_BLK.P_DEALER_DESC | Validates that dealer is not blank before navigating to the next field; displays error via `GENERAL.DISP_TEXT` if empty |
| WHEN-LIST-CHANGED | CB_BLK | QUARTER | CB_BLK.QUARTER | Validates quarter is not blank; clears financial year; calculates and sets the from and to date range based on the selected quarter and financial year globals |
| KEY-NEXT-ITEM | CB_BLK | QUARTER | CB_BLK.QUARTER | Validates that quarter is not blank before navigating; displays error via `GENERAL.DISP_TEXT` if empty; navigates to FINANCIAL_YEAR |
| KEY-LISTVAL | CB_BLK | FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR | Displays the `LV_FINANCIAL_YEAR` LOV when triggered from the financial year field |
| KEY-NEXT-ITEM | CB_BLK | FINANCIAL_YEAR | CB_BLK.FINANCIAL_YEAR | Validates that financial year is not blank before navigating; displays error via `GENERAL.DISP_TEXT` if empty; navigates to P_DESTYPE |
| WHEN-LIST-CHANGED | CB_BLK | P_DESTYPE | CB_BLK.P_DESTYPE | Sets report format to `CHAR` and disables the format field when Printer is selected; sets format to `PDF` and enables the format field otherwise |
| WHEN-BUTTON-PRESSED | CB_BLK | SUBMIT | CB_BLK.SUBMIT | Validates mandatory fields (dealer, quarter, financial year); rejects Excel destination type; builds report parameter string via `PR_PASS_PARAM`; configures and runs the Oracle Reports object; opens the generated PDF in the browser |
| WHEN-VALIDATE-ITEM | CB_BLK | P_FROM_DT | CB_BLK.P_FROM_DT | Validates that From Date is not null; raises FORM_TRIGGER_FAILURE if empty (commented-out logic previously also checked future dates) |
| WHEN-VALIDATE-ITEM | CB_BLK | P_TO_DT | CB_BLK.P_TO_DT | **COMMENTED OUT / INACTIVE** - Body is `NULL;`; previously validated To Date not null, not future, not before From Date, and within one month of From Date |
| WHEN-LIST-CHANGED | CB_BLK | P_REPO_TYPE | CB_BLK.P_REPO_TYPE | Sets report format to `CHAR` and disables format field for Printer destination; sets PDF format and enables format field otherwise |
| WHEN-LIST-CHANGED | CB_BLK | P_DES_TYPE | CB_BLK.P_DES_TYPE | Sets report format to `CHAR` and disables format field for Printer destination; sets PDF format and enables format field otherwise |
| WHEN-LIST-CHANGED | CB_BLK | P_DESFORMAT | CB_BLK.P_DESFORMAT | Clears and disables the FILENAME field when format is not EXCEL; enables and makes FILENAME navigable when EXCEL format is selected |
| WHEN-NEW-ITEM-INSTANCE | CB_BLK | FILENAME | CB_BLK.FILENAME | Enables insert/update on FILENAME when output format is EXCEL; disables insert/update otherwise |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | **COMMENTED OUT / INACTIVE** - Previously called `GENERAL.ASK_CONFIRM` before exiting; body is block-commented in current version (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Opens the LOV for the currently focused item; equivalent to pressing the List key (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Initiates a new record insert on the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Navigates to the next logical step or continues the current operation (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Deletes the current record after optional confirmation (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Cancels pending changes and clears the current block (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Commits the current transaction to the database (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Invokes the print action for the current block or report (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Cuts the selected text in the current item to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Copies the selected text in the current item to the clipboard (inherited) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Pastes clipboard text into the current item (inherited) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Extended Warranty Incentive Details (Rel 1.1.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_ERR | Content | WIN_ERR |
| CN_MAIN | Content | - |
| CN_TOOL | Content | - |

*WIN_ERR and WN_MAIN, together with their associated canvases CN_ERR, CN_MAIN, and CN_TOOL, are inherited from the DPL.olb OG_GROUP object group. They provide the standard DPL error-display window and the main business canvas/toolbar canvas respectively. No WEBUTIL-only business windows are defined in this form; the WEBUTIL_HIDDEN_WINDOW and WEBUTIL_CANVAS are infrastructure components noted in Section 8.1.*

### 8.9 Editors

*No editors found in vr_penetrate_dlr_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*3 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

| Visual Attribute |
| :--- |
| VA_MANDATORY |
| VA_DEFAULT |
| VA_DISPLAY |

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_penetrate_dlr_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_penetrate_dlr_fmb.xml.*

## 9. Object Library

*This form references two Object Library files. The DPL library (`DPL_olb.xml`) provides the reusable visual attributes and property classes used across forms in this application suite. The WebUtil library (`webutil_olb.xml`) provides the WebUtil object groups for client-side integration capabilities.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Check box visual attribute - gray background, Arial 8pt, black foreground | referenced | Check box items |
| VA_RB | VisualAttribute | Radio button visual attribute - gray background, Arial 8pt, black foreground | referenced | Radio button items |
| VA_ICONIC_BUTN | VisualAttribute | Iconic button visual attribute - white background, black foreground | referenced | Iconic push buttons |
| VA_DESC | VisualAttribute | Description label visual attribute - gray background, Small Fonts 7pt, blue foreground | referenced | Description display items |
| VA_NUM | VisualAttribute | Numeric field visual attribute - white background, Arial 8pt, black foreground | referenced | Numeric text items |
| VA_MAND | VisualAttribute | Mandatory field visual attribute - cyan background, Arial 9pt, black foreground | referenced | Mandatory entry fields |
| VA_OPROMPT | VisualAttribute | Optional prompt visual attribute - white background, Arial 9pt, black prompt foreground | referenced | Optional field prompts |
| VA_MPROMPT | VisualAttribute | Mandatory prompt visual attribute - white background, Arial 9pt, red prompt foreground | referenced | Mandatory field prompts |
| VA_TEXT | VisualAttribute | Standard text field visual attribute - white background, Arial 9pt, black foreground | referenced | Standard text items |
| VA_BUTN | VisualAttribute | Push button visual attribute - gray background, Arial 10pt bold, black foreground | referenced | Push buttons |
| VA_ALERT | VisualAttribute | Alert visual attribute - gray background, MT Extra 11pt, black foreground | referenced | Alert objects |
| VA_TITLE | VisualAttribute | Title visual attribute - gray background, Arial 10pt bold, blue foreground | referenced | Title/heading items |
| VA_TRNI_DT | VisualAttribute | Transaction date visual attribute - white background, Courier bold, black foreground | referenced | Date display items |
| VA_LOV | VisualAttribute | LOV visual attribute - gray background, Arial 9pt, dark blue foreground | referenced | LOV-bound items |
| VA_DISP | VisualAttribute | Display field visual attribute - r25g75b75 background, Arial 8pt bold, black foreground | referenced | Read-only display items |
| PC_DESC | PropertyClass | Display item property class - left-justified, 250-wide, Arial 9pt, blue foreground, bevel none | referenced | Description display items |
| PC_SC_DATE | PropertyClass | Short date display property class - character data type, format hint DD-MM-YY, gray background | referenced | Display date fields |
| PC_TITLE | PropertyClass | Title text property class - centered, Arial 10pt bold, blue foreground, uppercase | referenced | Title items |
| PC_FORMAT | PropertyClass | Format text property class - centered, 60-wide, Arial 9pt, uppercase | referenced | Format indicator items |
| PC_MR_BLK | PropertyClass | Multi-row block property class - vertical orientation, change-record navigation, 12-wide scrollbar | referenced | Multi-row blocks |
| PC_DISP | PropertyClass | Disabled display item property class - left-justified, gray8 background, bevel lowered, not keyboard-navigable | referenced | Read-only display items |
| PC_LOV | PropertyClass | LOV property class - no auto-select, gray background, Arial 8pt, dark blue foreground, 200-high | referenced | LOV items |
| PC_FORM | PropertyClass | Form-level property class - includes standard ON-ERROR, ON-MESSAGE, KEY-EXIT, KEY-LISTVAL, KEY-COMMIT, and KEY-CLRFRM trigger templates; validation unit = Item; savepoint mode = false | referenced | Form-level defaults |
| PC_DISP_DATE | PropertyClass | Disabled date display property class - DD-MM-RRRR format mask, gray8 background, not keyboard-navigable | referenced | Read-only date display items |
| PC_DISP_NUM | PropertyClass | Disabled numeric display property class - right-justified, gray8 background, bevel lowered, not keyboard-navigable | referenced | Read-only numeric display items |
| PC_DATE | PropertyClass | Date entry property class - DD-MM-RRRR format mask, 60-wide, white background, date data type, popup menu POP_MAIN | referenced | Date entry fields |
| PC_DTTIME | PropertyClass | Date-time entry property class - DD-MM-RRRR HH24:MI format mask, date-time data type, initialised to current date-time | referenced | Date-time entry fields |
| PC_CB | PropertyClass | Check box item property class - white background, Arial 9pt, 14-high | referenced | Check box items |
| PC_ALERT | PropertyClass | Alert property class - gray background, MT Extra 11pt, demilight weight | referenced | Alert objects |
| PC_MDATE | PropertyClass | Mandatory date entry property class - DD-MM-RRRR format mask, red prompt foreground; includes WHEN-VALIDATE-ITEM trigger that enforces non-null entry using the item hint text | referenced | Mandatory date fields |
| PC_RB | PropertyClass | Radio button property class - gray background, Arial 9pt, black foreground | referenced | Radio button items |
| PC_WIND | PropertyClass | Window property class - resizable, hide on exit, gray background, Arial 10pt bold, blue foreground, 464×286 | referenced | Windows |
| PC_CANV | PropertyClass | Canvas property class - white background, Arial font, 750×440 canvas size, WindowName = WN_MAIN | referenced | Canvases |
| PC_BUTN | PropertyClass | Push button property class - 42-wide, Arial 9pt bold, gray background, mouse-navigate = false | referenced | Push buttons |
| PC_TEXT | PropertyClass | Standard text item property class - left-justified, Arial 9pt, white background, popup menu POP_MAIN | referenced | Standard text items |
| PC_MTEXT | PropertyClass | Mandatory text item property class - left-justified, Arial 9pt, red prompt foreground; includes WHEN-VALIDATE-ITEM trigger for non-null validation using hint text | referenced | Mandatory text items |
| PC_UTEXT | PropertyClass | Uppercase text item property class - left-justified, Arial 9pt, white background, uppercase case restriction | referenced | Uppercase text items |
| PC_MUTEXT | PropertyClass | Mandatory uppercase text item property class - Arial 9pt, red prompt foreground, uppercase; includes WHEN-VALIDATE-ITEM trigger for non-null validation | referenced | Mandatory uppercase text items |
| PC_NUM | PropertyClass | Numeric text item property class - right-justified, Arial 9pt, white background, number data type, minimum value 0 | referenced | Numeric entry items |
| PC_MNUM | PropertyClass | Mandatory numeric property class - right-justified, Arial 9pt, red prompt foreground; includes WHEN-VALIDATE-ITEM trigger that enforces non-zero numeric entry | referenced | Mandatory numeric items |
| PC_ICONIC_BUTN | PropertyClass | Iconic push button property class - iconic = true, 20-wide, white background, bevel none, mouse-navigate = false | referenced | Iconic buttons |
| PC_SCROLL | PropertyClass | Scrollbar property class - scrollbar width = 13 | referenced | Scrollable blocks |
| OG_GROUP | ObjectGroup | Form-level object group from the DPL library - referenced by the VR_PENETRATE_DLR form | referenced | N/A |
| WEBUTIL (ObjectGroup) | ObjectGroup | WebUtil full object group - contains all WebUtil bean areas, parameters, and triggers needed to use WebUtil including OLE support | referenced | WEBUTIL block items |
| WEBUTIL_NO_OLE (ObjectGroup) | ObjectGroup | WebUtil object group without OLE - contains WebUtil bean areas and triggers excluding OLE interface components | referenced | N/A |

---

## 10. Record Groups

*Lists all record groups, their LOV bindings, query logic, dynamic bindings, business purpose, and form usage.*

| Record Group | Type | Used By LOV | Display Column | Return Column | Dynamic Bindings | Purpose | Where Used |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| RG_FINANCIAL_YEAR | Query | LV_FINANCIAL_YEAR | ICRGGQ_0 | ICRGGQ_1 | No | Lists available financial years for the selected dealer and company; user selects the reporting financial year | LV_FINANCIAL_YEAR -> CB_BLK.FINANCIAL_YEAR |
| RG_CITY | Query | LV_CITY | LOC_DESC | LOC_CD | No | Lists all locations for the selected dealer parent group; user selects the reporting location | LV_CITY -> CB_BLK.P_CITY |
| RG_REGION | Query | - | REGION_CD | - | No | Populates the region code list item with regions accessible to the logged-in user; drives the region selection field | - |
| RG_DEALER | Query | LV_DEALER | DEALER | DEALER_NAME | No | Lists dealers whose DMS is implemented, filtered by the current parent group and principal; user selects the reporting dealer | LV_DEALER -> CB_BLK.P_DEALER_DESC |

**Total Record Groups:** 4

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_BLK | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `AM_DEALER_LOC` | - | RG_DEALER | Dealer location master - stores dealer codes, names, location codes, and parent group assignments |
| `AM_LIST` | - | L_POPULATE | Application list master - provides list item labels and codes for dynamic form list population |
| `AM_USER_REGION` | - | RG_REGION, Trigger WHEN-NEW-FORM-INSTANCE | User-region mapping - stores the region codes accessible to each user for access control |
| `DUAL` | - | EXCEL_REPORT, RG_CITY, Trigger WHEN-NEW-FORM-INSTANCE | Oracle system table - used in UNION queries to add a catch-all "ALL LOC" option, to generate file naming timestamps, and to initialise default values at form startup |
| `ED_REPORTS` | - | PR_PASS_PARAM | Report parameter configuration - stores parameter definitions and default values for each report module |
| `EH_REPORTS` | - | Trigger WHEN-NEW-FORM-INSTANCE | Report header/configuration master - queried at form startup to initialise report-level settings and default parameters for the current session |
| `FM_COMPANY` | - | RG_FINANCIAL_YEAR | Company financial master - stores financial year records; used to populate the financial year selection list |
| `GM_REGN` | - | LIST_POPULATE_ZONE | Region master - stores region codes and descriptions used to populate the zone and region list items |
| `MULDMS.AM_DEALER_LOC` | - | RG_CITY | Dealer location master (multi-DMS schema) - accessed with schema prefix to retrieve location descriptions for city/location LOV |
| `VD_EW_INCE_DTL` | - | EXCEL_REPORT | Extended warranty incentive detail view - provides dealer penetration report data queried for Excel output |

**Total Referenced Objects:** 10

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | STOP_WATCH.START_TIMER | Starts a performance timer when application logging is active, to measure form initialisation time |
| BR-001, BR-013 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Registers or clears the form's client identifier in the database session for monitoring |
| BR-001, BR-013 | DBMS_APPLICATION_INFO.SET_MODULE | Registers or clears the form's module name in the database session for monitoring |
| BR-009 | PR_PASS_PARAM | Assembles the report parameter string from current filter values by reading the report parameter configuration master |
| BR-009 | WEB.SHOW_DOCUMENT | Opens the generated PDF report in a new browser window after the report job completes |
| BR-011 | GENERAL.DISP_TEXT | Displays user-facing error and information messages throughout the form |
| BR-011 | GENERAL.RAISE_ERROR | Raises a business-level error by code for integrity constraint violations |
| - | GENERAL.ASK_CONFIRM | Presents a confirmation dialog before cancel or delete actions to obtain explicit user consent |
| - | GENERAL.L_POPULATE | Populates a named list item from the AM_LIST master table for a given list name and principal |
| - | GENERAL.L_POP_LIST_ITEM | Executes a dynamic SQL query to populate a record group and refresh the associated list item; called during form initialisation |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central dispatch routine for all WebUtil custom item events across browser, file, host, OLE, and session subsystems |
| - | WEBUTIL.ID_NULL | Tests whether a record group handle is null before attempting to delete or reuse it; guards record group lifecycle operations |
| - | VIEW_EXCEL_REPORT_NEW | Generates and delivers an Excel report to the client; called from the inactive EXCEL_REPORT path |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| PR_PASS_PARAM | Form Program Unit (PROCEDURE) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT | Builds the report parameter string by iterating the application's registered parameter list from the ED_REPORTS master table; appends dealer, location, quarter-year, report type, and destination type values |
| PR_REMOVE_ASCII_CHR | Form Program Unit (PROCEDURE) | No active caller (call site is commented out in WHEN-BUTTON-PRESSED) | Reads a CSV file from the server, filters out form-feed characters, and writes a clean copy; then opens the result in the browser. Present in source but unreachable from any active execution path |
| L_POPULATE | Form Program Unit (PROCEDURE) | No active caller | Populates a list item dynamically from the AM_LIST master table for a given list name and principal. Internally delegates to GENERAL.L_POPULATE from the DPL library. Present in source but unreachable from any active execution path |
| LIST_POPULATE_ZONE | Form Program Unit (PROCEDURE) | No active caller (call site commented out in KEY-CLRFRM) | Builds and populates the Zone/Region list from GM_REGN and AM_USER_REGION based on user type (HO/RO/DLR). Uses WEBUTIL.ID_NULL to guard record group handle checks. Present in source but unreachable from any active execution path |
| POP_LIST_REGION | Form Program Unit (PROCEDURE) | No active caller (call site commented out in KEY-CLRFRM) | Populates the Region list item from the RG_REGION record group. Present in source but unreachable from any active execution path |
| VIEW_EXCEL_REP | Form Program Unit (PROCEDURE) | Called by EXCEL_REPORT (itself unreachable) | Generates a CSV file from a dynamic query, writes it to the server, and opens it in the browser. Uses WEBUTIL.ID_NULL to guard record group handle checks. Unreachable from any active execution path |
| EXCEL_REPORT | Form Program Unit (PROCEDURE) | No active caller (call site commented out in WHEN-BUTTON-PRESSED) | Builds a penetration data query against VD_EW_INCE_DTL and calls VIEW_EXCEL_REPORT_NEW to produce a CSV download. Queries DUAL for file-naming timestamp. Unreachable from any active execution path |
| L_POP_LIST_ITEM | Form Program Unit (PROCEDURE) | No active caller; GENERAL.l_pop_list_item also called from WHEN-NEW-FORM-INSTANCE | Generic procedure to create and populate a record group from a dynamic SQL query using GENERAL.l_pop_list_item; uses WEBUTIL.ID_NULL to guard handle checks. Present in source but marked as commented out in its header |
| POPULATE_ERRORS | Form Program Unit (PACKAGE SPEC) | Not invoked | Package specification declaring a PL/SQL table variable; no executable body |
| VALIDATE_CN_MAIN | Form Program Unit (stub - COMMENTED OUT) | Not invoked | Formerly performed mandatory field checks for a test-drive screen; entire body is commented out; stub is NULL. Previously called GENERAL.CHECK_NULL (inactive) |
| CHECK_BEFORE_DELETE | Form Program Unit (stub - COMMENTED OUT) | Not invoked | Formerly checked for child records before delete; entire body is commented out; stub is NULL |
| GENERAL.ASK_CONFIRM | External Library Routine (DPL attached library) | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the supplied message and returns a numeric result indicating the user's choice; called before discarding changes or removing records to obtain explicit user confirmation |
| GENERAL.DISP_TEXT | External Library Routine (DPL attached library) | ON-ERROR, ON-MESSAGE, WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD, KEY-NEXT-ITEM on CB_BLK.P_DEALER_DESC, WHEN-LIST-CHANGED on CB_BLK.QUARTER, KEY-NEXT-ITEM on CB_BLK.QUARTER, KEY-LISTVAL on CB_BLK.FINANCIAL_YEAR, KEY-NEXT-ITEM on CB_BLK.FINANCIAL_YEAR, WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT, FT_INSERT, PR_REMOVE_ASCII_CHR | Displays a modal dialog by setting the message text and title on AL_ERRINFO (when title is "Error") or AL_NOTE (all other titles) and calling SHOW_ALERT. Parameters: text_string - message body; title_string - dialog title. Used throughout the form for field validation errors, form error handling, and informational messages |
| GENERAL.RAISE_ERROR | External Library Routine (DPL attached library) | ON-ERROR | Retrieves an error message by code, classifies it as Error/Note/Caution, calls DISP_TEXT with the derived title, and raises FORM_TRIGGER_FAILURE for error-type messages; used for integrity constraint violation E0088 |
| GENERAL.L_POPULATE | External Library Routine (DPL attached library) | ProgramUnit: L_POPULATE | Populates a named list item by driving the record-group query and list-refresh cycle; accepts the target list name and field name whose values are to be loaded |
| GENERAL.l_pop_list_item | External Library Routine (DPL attached library) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE | Executes the SQL statement supplied in p_select to populate the record group identified by p_rg_name, then refreshes the associated list item; called during form initialisation to pre-load drop-down lists |
| GENERAL.CHECK_NULL | External Library Routine (DPL attached library - INACTIVE) | ProgramUnit: VALIDATE_CN_MAIN (commented out) | Previously validated that required fields were not null; entire calling procedure body is block-commented; not executed in current form logic |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Records or clears the client application identifier in the Oracle database session for monitoring |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle Built-in Package | PRE-FORM, KEY-EXIT | Records or clears the module name in the Oracle database session for monitoring |
| STOP_WATCH.START_TIMER | External Package | PRE-FORM (conditional - when app_log = Y) | Starts a performance timer for form load measurement when application logging is active |
| WEB.SHOW_DOCUMENT | Oracle Forms Built-in | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT, PR_REMOVE_ASCII_CHR, VIEW_EXCEL_REP | Opens a URL in the user's browser; used to deliver the report PDF and Excel output to the user |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil Library Routine (webutil.pld - WEBUTIL_CORE) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine for all WebUtil custom item events; each WEBUTIL bean block forwards its event name and serialised parameter string to this handler, which routes processing to the appropriate WebUtil subsystem |
| WEBUTIL.ID_NULL | WebUtil Library Routine (webutil.pld - WEBUTIL_C_API) | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | Tests whether a record group handle is null (record group does not yet exist); returns TRUE if null, FALSE otherwise; called before attempting to delete or reuse a record group to avoid runtime errors |
| VIEW_EXCEL_REPORT_NEW | External Library Routine (DMS_EXCEL_REPORT attached library) | EXCEL_REPORT (unreachable) | Generates and delivers an Excel report to the client; called with principal, file name, query, column name, and application ID parameters. Referenced in the inactive EXCEL_REPORT path only |

---

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source `.pck` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

*No PCK files found - no `*.pck` source files were discovered in `/app/section-rewrite-pipeline/workspaces/ee5953c3-6295-42b4-a751-3f9320e60faa/inputs/form_sources`. Package specifications cannot be generated without uploaded PCK sources.*

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*

*No PCK files found - no `*.pck` source files were discovered in the form sources directory. The database package catalogue cannot be generated without uploaded PCK sources.*

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: FT_CANCEL in Form, Trigger: FT_DEL in Form, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Presents a confirmation dialog to the user with the message supplied in `confirm_msg` and returns a numeric result indicating the user's choice. Called from cancel and delete triggers to obtain explicit user confirmation before discarding changes or removing records, and from the WEBUTIL dummy button handler. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: FT_INSERT in Form, Trigger: KEY-LISTVAL in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.P_DEALER_DESC, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-LIST-CHANGED in CB_BLK.QUARTER, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | Displays a modal dialog by setting the message text and title on AL_ERRINFO (when title is "Error") or AL_NOTE (all other titles) and then calling SHOW_ALERT. Parameters: `text_string` - the message body; `title_string` - the dialog title. Used throughout the form for field validation errors, form error handling, and general informational messages. |
| L_POPULATE | Procedure | Procedure(P_LIST_NAME VARCHAR2, P_LIST_FIELD VARCHAR2) | ProgramUnit: L_POPULATE | Populates a named list item by delegating to the lower-level list-population infrastructure. Accepts the target list name and the field name whose values are to be loaded, then drives the record-group query and list-refresh cycle. Called recursively or as a helper from within the L_POPULATE program unit itself. |
| l_pop_list_item | Procedure | Procedure(p_rg_name VARCHAR2, p_select VARCHAR2) | ProgramUnit: L_POP_LIST_ITEM, Trigger: WHEN-NEW-FORM-INSTANCE in Form | Executes the SQL statement supplied in `p_select` to populate the record group identified by `p_rg_name`, then refreshes the associated list item. Called during form initialisation (WHEN-NEW-FORM-INSTANCE) to pre-load drop-down lists, and from within the L_POP_LIST_ITEM program unit for reuse across multiple list fields. |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | Retrieves an error message by code and classifies it as Error (E), Note (N), or Caution (C). Calls DISP_TEXT with the message text and type-derived title. Raises FORM_TRIGGER_FAILURE for error-type messages. Invoked from ON-ERROR to surface application-specific error codes. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_penetrate_dlr_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CHECK_NULL | Procedure | Procedure(p_value IN VARCHAR2, column_title IN VARCHAR2) | ProgramUnit: VALIDATE_CN_MAIN | **COMMENTED OUT / INACTIVE** - Previously invoked from VALIDATE_CN_MAIN to validate that required fields were not null; entire calling procedure body is block-commented; not executed in current form logic. |

**Total Active Routines:** 5 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central dispatch routine for all WebUtil custom item events. Each WEBUTIL bean block registers a WHEN-CUSTOM-ITEM-EVENT trigger that forwards the event name and its serialised parameter string to this handler, which routes processing to the appropriate WebUtil subsystem (browser, client-info, C-API, file transfer, file functions, host, OLE, or session). |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | Tests whether a record group handle is null (i.e., the record group does not yet exist). Returns TRUE if the handle is null, FALSE otherwise. Called before attempting to delete or reuse a record group to avoid runtime errors. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Report Parameter Configuration Service | ED_REPORTS | Application ID, Principal code | Ordered list of parameter names, types, and default values | Retrieves the report parameter definitions for a given application and principal, providing the parameter assembly order for report submission | `GET /api/report-parameters/{appId}?principal={principalCode}` |
| MS-002 | Dealer Lookup Service | AM_DEALER_LOC, AM_DEALER_LOC_PARAM, GM_FOR | Parent group, Dealer map code, Principal code | List of authorised dealers with dealer code, name, location description, city, and company financial account | Provides the list of DMS-enabled dealers available to the current user session for report filtering | `GET /api/dealers?parentGroup={pg}&dealerMapCd={dmc}&principal={principalCode}` |
| MS-003 | City / Location Lookup Service | MULDMS.AM_DEALER_LOC | Parent group, Dealer map code | List of location codes and descriptions plus an ALL-LOCATIONS option | Provides the city/location filter options for the selected dealer | `GET /api/locations?parentGroup={pg}&dealerMapCd={dmc}` |
| MS-004 | Financial Year Lookup Service | FM_COMPANY | Parent group, Location code, Dealer map code, Company FA code | List of open financial years in display and numeric form | Provides the available financial years that have not been finally closed, for the current dealer session | `GET /api/financial-years?parentGroup={pg}&locCd={locCd}&dealerMapCd={dmc}&compFa={compFa}` |
| MS-005 | Zone / Region List Service | GM_REGN, AM_USER_REGION | User ID, User type, Principal code | List of zone descriptions and zone codes | Provides the zone/region filter options for the current user based on their assigned service regions | `GET /api/zones?userId={userId}&userType={userType}&principal={principalCode}` |
| MS-006 | Penetration Report Submission Service | ED_REPORTS (parameter config), report server | Dealer code, Location code, Quarter-year period key, Report type, Destination type, Report server name | Report file URL (PDF) for browser delivery | Assembles the report parameters and submits the dealer penetration report job to the report server, returning the URL of the generated PDF output | `POST /api/reports/dealer-penetration/submit` |
| MS-007 | Extended Warranty Penetration Data Service (inactive) | VD_EW_INCE_DTL | Dealer map code, Location code, Transaction month (quarter-year key) | CSV dataset with dealer, location, retail, EW sale counts, penetration percentages, and incentive slab values | Provides extended warranty penetration and incentive data for a specific dealer, location, and quarter period - referenced in the inactive EXCEL_REPORT path only | `GET /api/reports/ew-penetration?dealerMapCd={dmc}&locCd={locCd}&tranMonth={qtrYear}` |

**Total Microservices Identified: 7**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Initialisation | User opens the dealer penetration report form (PRE-FORM trigger) | 1. Check if application logging is active; 2. If active, start performance timer; 3. Register module name and client identifier in the database session | Is application logging active? If yes -> start timer; if no -> skip timer | Form is open with session monitoring registered; user is on the report parameter screen |
| WF-002 | Region Selection and Filter Reset | User changes the Region drop-down (WHEN-LIST-CHANGED on CB_BLK.P_REGION_CD) | 1. Clear Dealer, Location Description, City code, Quarter, From Date, and To Date fields | None | All dependent filter fields are cleared; user must re-enter downstream filters |
| WF-003 | Region Mandatory Validation | User leaves the Region field (WHEN-VALIDATE-ITEM on CB_BLK.P_REGION_CD) | 1. Check if Region is empty; 2. If empty, display error and abort; 3. If not empty, clear the For Code Description field | Is Region empty? If yes -> display *"Region Code can not be empty"* and raise failure; if no -> clear P_FOR_DESC | Region is confirmed selected; For Code Description field cleared |
| WF-004 | Dealer Navigation and Validation | User presses Tab/Next-Field on the Dealer field (KEY-NEXT-ITEM on CB_BLK.P_DEALER_DESC) | 1. Check if Dealer is empty; 2. If empty, display error and return focus; 3. If not empty, advance cursor to Quarter field | Is Dealer empty? If yes -> display *"Dealer can not be Blank)"* and stay; if no -> advance to Quarter | Cursor is on the Quarter field with a dealer confirmed |
| WF-005 | Quarter Selection - Validation and Quarter-Month Mapping | User changes the Quarter drop-down (WHEN-LIST-CHANGED on CB_BLK.QUARTER) | 1. Check if Quarter is empty; 2. If empty, display error and abort; 3. Clear Financial Year; 4. Map quarter to end-month number (Q1->06, Q2->09, Q3->12, Q4->03); 5. Advance cursor to Financial Year field | Is Quarter empty? If yes -> display *"Quarter can not be Blank)"* and abort remaining steps | Financial Year field cleared; internal month number set; cursor on Financial Year |
| WF-006 | Financial Year Selection - Validation and Quarter-Year Key Assembly | User completes the Financial Year lookup or presses Tab (KEY-LISTVAL / KEY-NEXT-ITEM on CB_BLK.FINANCIAL_YEAR) | 1. Open Financial Year lookup (KEY-LISTVAL path only); 2. Check if Financial Year is empty; 3. If empty, display error and abort; 4. Map quarter-year key (Q1/Q2/Q3: year = selected year; Q4: year = selected year + 1); 5. Advance cursor to Destination field | Is Financial Year empty after selection/Tab? If yes -> display *"Financial Year can not be Blank)"* and abort; Is quarter Q4? If yes -> use year+1 for key | Quarter-year period key is set; cursor is on the Destination field |
| WF-007 | Destination Selection and Format Control | User changes the Destination or Report Type drop-down (WHEN-LIST-CHANGED on CB_BLK.P_DESTYPE, CB_BLK.P_DES_TYPE, CB_BLK.P_REPO_TYPE) | 1. Check if selected destination is Printer; 2. If Printer, set Format to CHAR and disable it; 3. If not Printer, set Format to PDF and enable it | Is destination Printer? If yes -> set CHAR + disable; if no -> set PDF + enable | Format field is in a state consistent with the selected destination |
| WF-008 | Format Change and File Name Field Control | User changes the Format drop-down (WHEN-LIST-CHANGED on CB_BLK.P_DESFORMAT) | 1. Check if format is Excel; 2. If not Excel, clear File Name, disable and make not navigable; 3. If Excel, enable File Name and make navigable | Is format Excel? If yes -> enable File Name; if no -> clear and lock File Name | File Name field availability is consistent with the selected format |
| WF-009 | File Name Field Edit Control on Cursor Entry | Cursor enters the File Name field (WHEN-NEW-ITEM-INSTANCE on CB_BLK.FILENAME) | 1. Check current format; 2. If Excel, allow insert and update; 3. If not Excel, disallow insert and update | Is format Excel? If yes -> allow editing; if no -> prevent editing | File Name field is editable or read-only according to format |
| WF-010 | From Date Mandatory Validation | User leaves the From Date field (WHEN-VALIDATE-ITEM on CB_BLK.P_FROM_DT) | 1. Check if From Date is empty; 2. If empty, display alert and raise failure; 3. If not empty, proceed | Is From Date empty? If yes -> alert *"From Date cannot be empty"* and abort; if no -> continue | From Date confirmed present |
| WF-011 | Report Submission | User clicks the Submit Report button (WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT) | 1. Validate Dealer is not empty; 2. Validate Quarter is not empty; 3. Validate Financial Year is not empty; 4. Block Excel destination; 5. Assemble report parameter string (PR_PASS_PARAM); 6. Configure report object (destination, format, file name, server); 7. Submit report job (RUN_REPORT_OBJECT); 8. Open PDF in browser (WEB.SHOW_DOCUMENT) | Is Dealer empty? Is Quarter empty? Is Financial Year empty? Is destination Excel? Is format PDF? | Report PDF opened in the user's browser, or an error shown and report not submitted |
| WF-012 | Form Clear and Financial Year Reset | User triggers the Clear Form action (KEY-CLRFRM trigger) | 1. Clear all form fields; 2. Set Report Description from session global; 3. Calculate financial year start and end years from session globals; 4. Set Financial Year field to combined year string | None | Form is cleared with Financial Year set to current financial year |
| WF-013 | Form-Level Error Handling | Any error raised in the form (ON-ERROR trigger) | 1. Check error code 50004 -> display *"Entered Date is not valid Date"*; 2. Check codes 50025/50026 -> display date format message; 3. Check codes 40209/50016 -> display numeric field message; 4. Check code 40207 -> display field error text; 5. Check DBMS error -02292 -> raise E0088; 6. Check codes 40654-40659 -> display concurrent-update message and rollback; 7. Check SQL code ≠ 0 -> display SQLERRM and rollback; 8. Check codes 40401/40405 -> suppress | Multiple: different error codes route to different messages and outcomes | User-visible error displayed (or suppressed) and action cancelled; form remains open |
| WF-014 | Form-Level Message Reclassification | Forms message 40209 or 40207 raised (ON-MESSAGE trigger) | 1. Check if message code is 40209 or 40207; 2. If yes, format error text as type-code-text; 3. Display as error; 4. Cancel action | Is message code 40209 or 40207? If yes -> reclassify and display; if no -> allow default | User sees a formatted error message instead of a default system message |
| WF-015 | Form Exit and Session Clean-Up | User triggers the Exit Form action (KEY-EXIT trigger) | 1. Close the form without validation or save; 2. Clear client identifier in database session; 3. Clear module name in database session | None | Form is closed; database session no longer shows this form as active |

**Total Workflows Identified: 15**

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: LIST_POPULATE_ZONE, ProgramUnit: L_POPULATE, ProgramUnit: L_POP_LIST_ITEM, ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is tested, then returns true if the handle is null so the caller can safely create or skip the group |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | CHECK_NULL | Validation | ProgramUnit: VALIDATE_CN_MAIN | /api/v1/pld/check_null | **COMMENTED OUT / INACTIVE** - When a required field value is null, then an error message is displayed and form navigation is halted |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: PR_REMOVE_ASCII_CHR, Trigger: KEY-LISTVAL in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.FINANCIAL_YEAR, Trigger: KEY-NEXT-ITEM in CB_BLK.P_DEALER_DESC, Trigger: KEY-NEXT-ITEM in CB_BLK.QUARTER, Trigger: ON-ERROR in Form, Trigger: ON-MESSAGE in Form, Trigger: WHEN-BUTTON-PRESSED in CB_BLK.SUBMIT, Trigger: WHEN-LIST-CHANGED in CB_BLK.QUARTER, Trigger: WHEN-VALIDATE-ITEM in CB_BLK.P_REGION_CD | /api/v1/pld/disp_text | When a message and title are provided, then displays a modal alert dialog using AL_ERRINFO for errors or AL_NOTE for other messages |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | When an application error code is raised, then the corresponding message is retrieved, classified, and displayed; form navigation is halted for error-type messages |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_penetrate_dlr_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

*No package routines from the available PCK files are referenced in ``vr_penetrate_dlr_fmb.xml``.*

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Report Parameter Configuration (ED_REPORTS) | Oracle Database Table (SELECT) | Retrieves the ordered list of parameter names and types configured for the dealer penetration report and current principal | Form -> DB: application ID + principal code; DB -> Form: parameter names and serial order | Read executed inside PR_PASS_PARAM; no explicit exception handler - errors surfaced through the form-level ON-ERROR trigger |
| Dealer and Location Master (AM_DEALER_LOC, AM_DEALER_LOC_PARAM, GM_FOR) | Oracle Database Tables (SELECT) | Populates the Dealer lookup list with DMS-enabled dealers for the current session | Form -> DB: parent group, dealer map code, principal; DB -> Form: dealer code, name, location description, city | Record group populated via RG_DEALER query; errors surfaced through form-level ON-ERROR trigger |
| City / Location Reference (MULDMS.AM_DEALER_LOC) | Oracle Database Table (SELECT, external schema) | Populates the City/Location lookup list for the selected dealer | Form -> DB: parent group, dealer map code; DB -> Form: location codes and descriptions plus ALL-LOCATIONS option | Record group populated via RG_CITY query; errors surfaced through form-level ON-ERROR trigger |
| Financial Year Master (FM_COMPANY) | Oracle Database Table (SELECT) | Provides the list of open financial years for the current session's dealer | Form -> DB: parent group, location, dealer map code, company FA code; DB -> Form: financial year display strings and numeric values | Record group populated via RG_FINANCIAL_YEAR query; errors surfaced through form-level ON-ERROR trigger |
| Zone / Region Reference (GM_REGN, AM_USER_REGION) | Oracle Database Tables (SELECT) | Provides zone descriptions and codes for the Region filter, based on user service regions | Form -> DB: user ID, user type, principal; DB -> Form: zone descriptions and codes | Populated via LIST_POPULATE_ZONE program unit (currently unreachable); errors surfaced through ON-ERROR trigger |
| Region User Assignments (AM_USER_REGION, AM_DEALER_LOC) | Oracle Database Tables (SELECT) | Determines the region codes assigned to the current user for service access | Form -> DB: user ID, principal; DB -> Form: region codes | Populated via RG_REGION record group query; errors surfaced through ON-ERROR trigger |
| List Master (AM_LIST) | Oracle Database Table (SELECT) | Provides code-description pairs for application list items, filtered by list name and principal | Form -> DB: list name, principal; DB -> Form: list codes and descriptions | Referenced by the inactive L_POPULATE program unit - unreachable from active execution paths |
| Extended Warranty Incentive Detail (VD_EW_INCE_DTL) | Oracle Database Table (SELECT) | Provides penetration and incentive data for the Excel report path | Form -> DB: dealer map code, location code, transaction month; DB -> Form: CSV dataset | Referenced by the inactive EXCEL_REPORT program unit - unreachable from active execution paths |

---

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| Oracle Reports Server | Report Submission (RUN_REPORT_OBJECT / Oracle Forms Reports integration) | Submits the dealer penetration report job and returns the path to the generated PDF output file | Oracle Forms Reports runtime protocol | Report server name sourced from the global session variable `REP_SERVER`; output path `/iashome/ias/reports/printer/` | Form -> Report Server: report object name (`REPORT_CALL`), destination type (FILE), format (PDF), report parameter string, output file name; Report Server -> Form: job completion status | Report job accepted -> PDF opened in browser via WEB.SHOW_DOCUMENT; report failure -> surfaced through form-level error handling |
| Oracle WebUtil (Client-Side Integration) | Forms Client Bean (WebUtil OLB) | Provides client-side file handling, host command, session monitoring, file transfer, OLE, C API, and browser interaction capabilities via the WebUtil bean areas in the WEBUTIL block | Oracle WebUtil JavaBean integration (Oracle Forms runtime) | N/A - client-side bean integration | Forms ↔ Client: WebUtil bean areas handle client OS family, file selection, file open/save, host commands, file transfer, and URL display | Bean area events handled by WHEN-CUSTOM-ITEM-EVENT triggers (all inactive in this form - trigger bodies are empty) |
| DPL General Library (GENERAL package) | Attached PL/SQL Library (DPL.pld / DPL.pll) | Provides shared utility routines for displaying messages (DISP_TEXT) and raising business errors (RAISE_ERROR) used throughout the form | PL/SQL library attachment (Oracle Forms runtime) | Attached as DPL library | Form calls -> DPL.GENERAL.DISP_TEXT / DPL.GENERAL.RAISE_ERROR | Called routines raise FORM_TRIGGER_FAILURE on failure conditions; errors propagate to the ON-ERROR trigger |
| DMS Excel Report Library (VIEW_EXCEL_REPORT_NEW) | Attached PL/SQL Library (DMS_EXCEL_REPORT.pld) | Provides the VIEW_EXCEL_REPORT_NEW procedure for generating and delivering Excel reports from dynamic queries | PL/SQL library attachment (Oracle Forms runtime) | N/A - referenced in inactive EXCEL_REPORT path only | Form calls -> VIEW_EXCEL_REPORT_NEW (with principal, file name, query, column name, app ID parameters) | Referenced in the inactive EXCEL_REPORT program unit - unreachable from any active execution path |
| DBMS_APPLICATION_INFO (Oracle Built-in) | Oracle Database Package | Registers and clears the form's module name and client identifier in the Oracle database session for monitoring and tracing | PL/SQL built-in (direct database call) | N/A - Oracle database session | Form -> DB: module name (`vr_penetrate_dlr`) and client info string on open; empty strings on exit | Called unconditionally in PRE-FORM and KEY-EXIT; no explicit error handling |

---

### 20.3 Report Integrations

| Report Name | Report Server | Parameters | Output Format | Trigger |
| ----------- | ------------- | ---------- | ------------- | ------- |
| rep.rdf | Sourced from session global `REP_SERVER` (value resolved at runtime) | P_DEALER (dealer code), P_LOC (location code or `ALL`), P_QTR_YEAR (quarter-year period key), P_REPO_TYPE (report type), P_DES_TYPE (destination type); additional parameters read from ED_REPORTS by PR_PASS_PARAM at submission time | PDF (fixed; format set to PDF and destination overridden to FILE for all non-Excel paths) | WHEN-BUTTON-PRESSED on CB_BLK.SUBMIT - when the user clicks the Submit Report button and all mandatory field validations pass |

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_PENETRATE_DLR form.

### 21.1 Catalogue Index

82 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--L_POP_LIST_ITEM) | L_POP_LIST_ITEM |
| [SP-002](#SP-002--PR_PASS_PARAM) | PR_PASS_PARAM |
| [SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-004](#SP-004--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-010](#SP-010--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-011](#SP-011--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-012](#SP-012--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-013](#SP-013--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-014](#SP-014--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-015](#SP-015--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-016](#SP-016--GENERAL.RAISE_ERROR) | GENERAL.RAISE_ERROR |
| [SP-017](#SP-017--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-018](#SP-018--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-019](#SP-019--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-020](#SP-020--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-021](#SP-021--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-024](#SP-024--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-025](#SP-025--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-026](#SP-026--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-027](#SP-027--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-028](#SP-028--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-029](#SP-029--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-030](#SP-030--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-034](#SP-034--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-035](#SP-035--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-037](#SP-037--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-038](#SP-038--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-039](#SP-039--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-040](#SP-040--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-041](#SP-041--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-042](#SP-042--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-043](#SP-043--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-044](#SP-044--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-045](#SP-045--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-046](#SP-046--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-047](#SP-047--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-048](#SP-048--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-049](#SP-049--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-050](#SP-050--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-051](#SP-051--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-052](#SP-052--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-053](#SP-053--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-054](#SP-054--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-055](#SP-055--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-056](#SP-056--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-058](#SP-058--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-059](#SP-059--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-060](#SP-060--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-061](#SP-061--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-063](#SP-063--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-064](#SP-064--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-065](#SP-065--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-066](#SP-066--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-067](#SP-067--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-068](#SP-068--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-069](#SP-069--ADD_ERROR) | ADD_ERROR |
| [SP-070](#SP-070--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-071](#SP-071--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-072](#SP-072--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-073](#SP-073--DEBUGLOG) | DEBUGLOG |
| [SP-074](#SP-074--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-075](#SP-075--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-076](#SP-076--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-077](#SP-077--READ_REGISTRY) | READ_REGISTRY |
| [SP-078](#SP-078--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-079](#SP-079--SETDEBUG) | SETDEBUG |
| [SP-080](#SP-080--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-081](#SP-081--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-082](#SP-082--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - L_POP_LIST_ITEM

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-NEW-FORM-INSTANCE]

---

**Screen:**

Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

L_POP_LIST_ITEM is a reusable utility procedure that dynamically builds and populates a named Oracle Forms Record Group from a caller-supplied SQL query. It is invoked during form initialisation (WHEN-NEW-FORM-INSTANCE) to load the data sets that back list items on the CN_MAIN screen, ensuring each list item is populated with current values from the relevant database tables before the user interacts with the form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_rg_name | VARCHAR2 | IN |
| p_select | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target Record Group name (p_rg_name) and the SQL SELECT statement (p_select) that will supply its data.
- Step 2 - Attempt to locate an existing Record Group in the current form session using Find_Group, storing the returned handle in rg_id.
- Step 3 - Evaluate whether rg_id represents a valid (non-null) Record Group handle using WEBUTIL.ID_NULL (Id_Null).
- Step 4 - If the Record Group already exists (handle is not null), delete it with delete_group to prevent stale or duplicate data.
- Step 5 - If the Record Group does not exist (handle is null), create a new one from the supplied query using Create_Group_From_Query, assigning the resulting handle to rg_id.
- Step 6 - Populate the Record Group by executing the underlying SQL query via Populate_Group, capturing the return code in errcode.

---
**Decision Points**

DP-001

Condition: The Record Group identified by p_rg_name already exists in the current form session (Id_Null(rg_id) evaluates to FALSE).

TRUE: The existing Record Group is deleted using delete_group(rg_id) to clear any previously loaded data before re-population.

FALSE: A new Record Group is created from the supplied SQL query using Create_Group_From_Query(rg_name, p_select), and the new handle is assigned to rg_id for subsequent population.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A Record Group must never be duplicated within a form session; if a group with the supplied name already exists it must be destroyed before new data is loaded.
- BR-002 - The Record Group must always be created from the exact SQL query passed in p_select, ensuring the list item data reflects the caller's intended data scope at the time of invocation.
- BR-003 - The procedure must be callable generically for any list item; the caller is responsible for supplying a valid group name and a syntactically correct SELECT statement.
- BR-004 - Record Group population is performed unconditionally after the create-or-delete step; the errcode return value from Populate_Group is captured but does not alter the procedure's execution flow as defined in the current implementation.

---
**Implementation Logic**

```plsql
-- Commented by sanjeev on 14/4/04 for the prototype.

/* 
A common procedure to dynamically retrieve the values from the respective table b4 displaying them in the list items
*/

PROCEDURE l_pop_list_item (p_rg_name VARCHAR2,p_select VARCHAR2 )IS

	 rg_name VARCHAR2(40) := p_rg_name;
	 rg_id RecordGroup;
	 errcode NUMBER; 
BEGIN 
	/* ** Make sure group doesn't already exist */ 
	rg_id := Find_Group( rg_name ); 

	IF NOT Id_Null(rg_id) THEN 
		delete_group(rg_id);
	ELSE
	/* ** If it does not exist, create it and add the two ** necessary columns to it. */ 
		rg_id := Create_Group_From_Query( rg_name, p_select); 
	END IF; 
	/* ** Populate the record group */ 
	errcode := Populate_Group( rg_id );
END;
```

#### SP-002 - PR_PASS_PARAM

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

Builds a concatenated parameter string (Lv_param) for the dealer-penetration report by iterating over the report parameter definitions stored in ED_REPORTS for the application 'vr_penetrate_dlr' and the current principal. For each recognised parameter name, the procedure appends the corresponding screen block or global value to Lv_param in the key=value format expected by the report runtime. The procedure is triggered when the user presses the report-launch button (WHEN-BUTTON-PRESSED) on screen CN_MAIN.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Lv_param | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Open cursor C1 to retrieve all parameter definitions (param_type, parameter_name, default_value, parameter_datatype) from ED_REPORTS where app_id = 'vr_penetrate_dlr' and principal_map_cd matches the current global principal value, ordered by serial_no.
- Step 2 - Iterate over each row returned by C1.
- Step 3 - If the current parameter name is 'P_DEALER', append the token P_DEALER='<CB_BLK.P_DEALER>' to Lv_param.
- Step 4 - If the current parameter name is 'P_LOC', append the token P_LOC='<CB_BLK.P_LOC>' to Lv_param; if CB_BLK.P_DEALER is NULL, additionally append P_LOC='ALL' to Lv_param.
- Step 5 - If the current parameter name is 'P_QTR_YEAR' and the screen item P_QTR_YEAR is NULL, display alert AL_ERRINFO with the message 'Please Enter QTR YEAR' to notify the user; regardless of the alert outcome, append the token P_QTR_YEAR='<P_QTR_YEAR>' to Lv_param.
- Step 6 - If the current parameter name is 'P_REPO_TYPE', append the token P_REPO_TYPE='<P_REPO_TYPE>' to Lv_param.
- Step 7 - If the current parameter name is 'P_DES_TYPE', append the token P_DES_TYPE='<P_DES_TYPE>' to Lv_param.
- Step 8 - After all cursor rows are processed, return the fully assembled Lv_param string to the caller via the IN OUT parameter.

---
**Decision Points**

DP-001

Condition:
cur_val.parameter_name = 'P_DEALER'

TRUE:
Append the token P_DEALER='<CB_BLK.P_DEALER>' to Lv_param.

FALSE:
No action taken for this parameter check; processing continues to the next condition.

---

DP-002

Condition:
cur_val.parameter_name = 'P_LOC'

TRUE:
Append the token P_LOC='<CB_BLK.P_LOC>' to Lv_param, then evaluate DP-003.

FALSE:
No action taken for this parameter check; processing continues to the next condition.

---

DP-003

Condition:
cur_val.parameter_name = 'P_LOC' AND CB_BLK.P_DEALER IS NULL

TRUE:
Additionally append the token P_LOC='ALL' to Lv_param, effectively overriding the location value with 'ALL' when no dealer is selected.

FALSE:
The previously appended P_LOC value is retained unchanged.

---

DP-004

Condition:
cur_val.parameter_name = 'P_QTR_YEAR'

TRUE:
Evaluate DP-005, then append the token P_QTR_YEAR='<P_QTR_YEAR>' to Lv_param.

FALSE:
No action taken for this parameter check; processing continues to the next condition.

---

DP-005

Condition:
cur_val.parameter_name = 'P_QTR_YEAR' AND P_QTR_YEAR IS NULL

TRUE:
Display alert AL_ERRINFO with the message 'Please Enter QTR YEAR' to warn the user that the quarter-year value is missing. Execution continues (no exception is raised).

FALSE:
No alert is shown; the current P_QTR_YEAR value is appended to Lv_param.

---

DP-006

Condition:
cur_val.parameter_name = 'P_REPO_TYPE'

TRUE:
Append the token P_REPO_TYPE='<P_REPO_TYPE>' to Lv_param.

FALSE:
No action taken for this parameter check; processing continues to the next condition.

---

DP-007

Condition:
cur_val.parameter_name = 'P_DES_TYPE'

TRUE:
Append the token P_DES_TYPE='<P_DES_TYPE>' to Lv_param.

FALSE:
No action taken for this parameter check; end of loop iteration.

---
**Database Interactions**

- DB-001 - Read ED_REPORTS - Reads data from ED_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - Only report parameters defined in ED_REPORTS for app_id = 'vr_penetrate_dlr' and the current global principal (principal_map_cd = :global.principal) are eligible for inclusion in the parameter string, ensuring principal-level data segregation.
- BR-002 - Parameters are processed in ascending serial_no order, which governs the sequence in which tokens are appended to Lv_param.
- BR-003 - When no dealer (P_DEALER) is selected (CB_BLK.P_DEALER IS NULL) and the P_LOC parameter is present, the location is forced to 'ALL', preventing a report run scoped to a specific location without an associated dealer.
- BR-004 - The quarter-year value (P_QTR_YEAR) is mandatory for reports that include the P_QTR_YEAR parameter; if it is absent, the user must be alerted via AL_ERRINFO before the parameter token is appended.
- BR-005 - Each parameter token is appended in the format <PARAM_NAME>='<value>', with a leading space separator, conforming to the report runtime's expected parameter string syntax.
- BR-006 - The procedure handles only the five recognised parameter names (P_DEALER, P_LOC, P_QTR_YEAR, P_REPO_TYPE, P_DES_TYPE); any other parameter names returned by the cursor are silently ignored.

---
**Implementation Logic**

```plsql
PROCEDURE PR_PASS_PARAM (Lv_param IN OUT VARCHAR2)
IS
	cursor c1 is 
		select param_type,parameter_name,default_value,parameter_datatype
	    from ed_reports
		 where  app_id = 'vr_penetrate_dlr'
		 and principal_map_cd=:global.principal /*added by bhawana*/
		 order by to_number(serial_no);
	Lv_frm_date  DATE;
	Lv_to_date   DATE;	
	L_AlertID		 ALERT;
	L_Alert			 NUMBER;	
BEGIN
			
	For cur_val in c1 Loop		

		if cur_val.parameter_name = 'P_DEALER'  then
  	   lv_param := lv_param||' '||'P_DEALER='''||:CB_BLK.P_DEALER||'''';
     	-- if :CB_BLK.P_DEALER is null then
			   --   lv_param := lv_param||' '||'P_DEALER='''||99999||'''';
		  -- end if; 
		   
    end if;

			
		if cur_val.parameter_name = 'P_LOC'  then
  	   lv_param := lv_param||' '||'P_LOC='''||:CB_BLK.P_LOC||'''';
		   if :CB_BLK.P_DEALER is null then
			      lv_param := lv_param||' '||'P_LOC='''||'ALL'||'''';
			 end if;  	   
	  end if;

		if cur_val.parameter_name = 'P_QTR_YEAR'  then
			if :P_QTR_YEAR IS NULL THEN
		     L_AlertID := Find_Alert('AL_ERRINFO');
		  	 Set_Alert_Property(L_AlertID,Alert_Message_Text,'Please Enter QTR YEAR');
		  	 L_Alert	 := Show_Alert(L_AlertID);
		  --	 Go_Item('CB_BLK.P_FROM_DT');
		  --	 RAISE form_trigger_failure;
			end if;  	 		
  	   lv_param := lv_param||' '||'P_QTR_YEAR='''||:P_QTR_YEAR||''''; 
		end if;
		
   	if cur_val.parameter_name = 'P_REPO_TYPE'  then
  	   lv_param := lv_param||' '||'P_REPO_TYPE='''||:P_REPO_TYPE||''''; 
		end if;

		if cur_val.parameter_name = 'P_DES_TYPE'  then
  	   lv_param := lv_param||' '||'P_DES_TYPE='''||:P_DES_TYPE||''''; 
		end if;
	End Loop;	
END;
```

#### SP-003 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying the file's physical existence at a supplied directory path before loading. If the load succeeds and the LoadCount flag is set, the procedure increments the global DLL load counter and marks the API as enabled. If any failure occurs, the API is flagged as disabled and a null library handle is returned, allowing the caller (REGISTER_FUNCTION_CALL) to handle the failure gracefully.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath is non-null; if it is null, skip file-existence validation and proceed directly to the DLL load attempt.
- Step 2 - When TargetPath is provided, normalise the path by calling STRIPDIRSEP to remove any trailing directory separator, then append a single backslash ('\'), ensuring a consistently formatted path regardless of how the caller supplied it. This also discards any additional paths that may have been concatenated in TargetPath, retaining only the first segment.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode ('R') to confirm the file physically exists at the specified location.
- Step 4 - If the file is opened successfully, close it immediately with TEXT_IO.FCLOSE; the open was purely a presence check.
- Step 5 - If the file cannot be opened, call DEBUGLOG (severity 99) to record that the DLL was not found at the specified location, then raise the BadLocation exception to abort further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into memory and capture the resulting library handle (hDLL).
- Step 7 - If the LoadCount parameter is TRUE, increment the package-level DLL_LOAD_COUNT counter by 1 and set the package-level API_ENABLED flag to TRUE, signalling that the API is operational.
- Step 8 - Return the library handle hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load sequence, set API_ENABLED to FALSE and return the null library handle, allowing the caller to detect the failure.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash, then perform a file-existence check before attempting the DLL load.

FALSE: Skip path normalisation and file-existence validation; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the concatenated TargetPath || TargetDLL in read mode.

TRUE: Close the file handle and continue to the DLL load step.

FALSE: Log the missing-file condition via DEBUGLOG (severity 99) and raise the BadLocation exception, halting further execution within the procedure.

---

DP-003

Condition: LoadCount parameter is TRUE after a successful ORA_FFI.LOAD_LIBRARY call.

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE.

FALSE: Skip counter increment and API_ENABLED update; return the library handle without altering load-tracking state.

---

DP-004

Condition: An unhandled exception is raised anywhere within the main execution block (outer WHEN OTHERS handler).

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Normal execution completes; the valid library handle is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - TargetPath must contain exactly one directory path; if multiple paths are present, only the first is used and the remainder are discarded by STRIPDIRSEP before the backslash is appended.
- BR-002 - A trailing backslash separator must always be present on TargetPath before it is used for file validation or DLL loading; STRIPDIRSEP followed by '\' concatenation enforces this regardless of how the caller formatted the input.
- BR-003 - The physical existence of the DLL file must be confirmed via a read-mode file open before ORA_FFI.LOAD_LIBRARY is invoked, but only when TargetPath is supplied; a null TargetPath bypasses this check.
- BR-004 - A failed file-existence check must be logged at severity level 99 via DEBUGLOG, recording both the DLL name and the path that was searched, before the BadLocation exception is raised.
- BR-005 - The global DLL_LOAD_COUNT counter and the API_ENABLED flag must only be updated when the DLL load succeeds and the LoadCount parameter is explicitly TRUE.
- BR-006 - Any exception during the load sequence must result in API_ENABLED being set to FALSE and a null library handle being returned; the procedure must not propagate the exception to the caller.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-004 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native Windows file-chooser dialog (Open or Save) to the end user and returns the selected file path(s) in the IN OUT buffer. The procedure resolves special directory tokens, registers the external DLL call via the Win_API framework, delegates to the low-level D2KWUTIL.D2KWUTIL_CHOOSEFILE external function, and surfaces any errors through the standard Win_API error stack.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-011](#SP-011--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-075](#SP-075--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-076](#SP-076--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log all input arguments (CalledBy, Modal flag, title, initial directory, file filter, flags, separator character, and buffer) using DEBUGLOG for diagnostic traceability.
- Step 2 - Clear the Win_API error stack by calling CLEAN_ERROR_STACK to ensure no stale errors influence processing.
- Step 3 - Determine the owner window handle: if Modal is TRUE, retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW; otherwise set the handle to 0 (non-modal, no owner).
- Step 4 - Check that the Win_API external-call framework is enabled (API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external DLL entry point 'd2kwutil_ChooseFile' with its parameter signature using REGISTER_FUNCTION_CALL, binding it to the internal handle iChooseFile.
- Step 6 - Translate the CalledBy value to a dialog-mode integer: 'Open_File' maps to 1 (Open dialog); any other caller value maps to 2 (Save dialog).
- Step 7 - Resolve the initial directory token: if szInitDir equals '$WINDIR$' (case-insensitive), retrieve the Windows directory via GET_WINDOWS_DIRECTORY; if it equals '$TEMP$', retrieve the temporary directory via GET_TEMP_DIRECTORY; otherwise use szInitDir as supplied.
- Step 8 - Ensure the resolved directory path ends with a backslash ('\'); append one if the final character is not already a backslash.
- Step 9 - Apply the file filter: if szFileFilter is NULL or empty, default to 'All files(*.*)|*.*|'; otherwise use the supplied filter string.
- Step 10 - Truncate SepChar to its first character to guarantee a single-character separator.
- Step 11 - Pad szBuffer to exactly 4096 characters with null characters (CHR(0)) to provide the required fixed-length buffer for the external call.
- Step 12 - Invoke D2KWUTIL.D2KWUTIL_CHOOSEFILE with the resolved function handle, dialog mode, owner handle, title, directory, file filter, flags, separator character, and padded buffer; capture the integer return code.
- Step 13 - Log the return code and the resulting buffer content via DEBUGLOG.
- Step 14 - Write the populated buffer back to the IN OUT parameter szBuffer and return the integer result code to the caller.
- Step 15 - On WIN_API.NOT_AVAILABLE exception, record the error using ADD_ERROR with the NoAPI message and re-raise.
- Step 16 - On any other exception, record the error using ADD_ERROR combined with ADD_EXTERNAL_ERRORS to capture external error detail, then re-raise.

---
**Decision Points**

DP-001

Condition:
Modal IN parameter is TRUE.

TRUE:
Retrieve the active window handle via D2KWUTIL.GET_ACTIVE_WINDOW and assign it to hwndOwner, making the dialog modal to that window.

FALSE:
Set hwndOwner to 0, allowing the dialog to appear without a modal owner.

---

DP-002

Condition:
Win_API.API_ENABLED is TRUE.

TRUE:
Proceed with registering the external function and invoking the file-chooser dialog.

FALSE:
Raise WIN_API.NOT_AVAILABLE, bypassing all dialog logic.

---

DP-003

Condition:
CalledBy = 'Open_File'.

TRUE:
Set dialog-mode integer iBuff1 to 1 (Open File dialog).

FALSE:
Set dialog-mode integer iBuff1 to 2 (Save File dialog).

---

DP-004

Condition:
UPPER(szInitDir) = '$WINDIR$'.

TRUE:
Resolve the initial directory by calling GET_WINDOWS_DIRECTORY.

FALSE:
Evaluate DP-005 to check for the '$TEMP$' token.

---

DP-005

Condition:
UPPER(szInitDir) = '$TEMP$'.

TRUE:
Resolve the initial directory by calling GET_TEMP_DIRECTORY.

FALSE:
Use szInitDir as supplied without further resolution.

---

DP-006

Condition:
The last character of the resolved directory path is not a backslash ('\').

TRUE:
Append a backslash to the directory path to ensure a valid trailing separator.

FALSE:
Leave the directory path unchanged.

---

DP-007

Condition:
szFileFilter is NULL or an empty string.

TRUE:
Default the file filter to 'All files(*.*)|*.*|'.

FALSE:
Use the caller-supplied szFileFilter value.

---

DP-008

Condition:
Exception WIN_API.NOT_AVAILABLE is raised.

TRUE:
Call ADD_ERROR with the NoAPI message code and re-raise the exception to the caller.

FALSE:
If a different (OTHERS) exception is raised, call ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raise.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file-chooser dialog may only be invoked when the Win_API external-call framework is available (API_ENABLED); if the framework is unavailable, the procedure must raise WIN_API.NOT_AVAILABLE without attempting any dialog interaction.
- BR-002 - The caller identity ('Open_File' or any other value) exclusively determines whether an Open (1) or Save (2) dialog is presented; no other input governs dialog type.
- BR-003 - The special tokens '$WINDIR$' and '$TEMP$' in szInitDir must be resolved to their actual system paths at runtime via GET_WINDOWS_DIRECTORY and GET_TEMP_DIRECTORY respectively; all other values are used verbatim.
- BR-004 - The resolved initial directory path must always terminate with a backslash; one must be appended automatically if absent.
- BR-005 - When no file filter is provided (NULL or empty string), the dialog must default to displaying all files using the filter 'All files(*.*)|*.*|'.
- BR-006 - The separator character passed to the external function must be exactly one character; only the first character of SepChar is used.
- BR-007 - The file-path buffer supplied to the external DLL call must be exactly 4096 characters, padded with null characters (CHR(0)); this guarantees sufficient capacity for multi-file selections.
- BR-008 - All invocations must be logged at debug level 99 (entry arguments and exit result) via DEBUGLOG to support diagnostic tracing.
- BR-009 - The Win_API error stack must be cleared at the start of every invocation via CLEAN_ERROR_STACK to prevent prior errors from contaminating the current call's error reporting.
- BR-010 - On any exception, the error must be recorded through ADD_ERROR (supplemented by ADD_EXTERNAL_ERRORS for non-framework errors) before the exception is re-raised, ensuring the calling layer receives full error context.

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves the currently active window handle within the Oracle Forms runtime environment. It is declared as a specification-only entry point and is invoked by D2KWUTIL.GET_ACTIVE_WINDOW to obtain the active window identifier as a PLS_INTEGER value.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying external library function responsible for identifying the active window.
- Step 2 - Delegate execution to the external function via the ORA_FFI mechanism using the supplied handle.
- Step 3 - Return the active window identifier as a PLS_INTEGER value to the calling routine (D2KWUTIL.GET_ACTIVE_WINDOW).

---
**Decision Points**

No conditional decision points are present in this routine. The function signature contains no branching logic; it accepts the FFI function handle and returns the active window identifier unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid ORA_FFI.funcHandleType handle; the handle is expected to be initialised by the caller (D2KWUTIL.GET_ACTIVE_WINDOW) before invocation.
- BR-002 - The return value is typed as PLS_INTEGER, meaning the active window identifier must be representable within that data type range.
- BR-003 - No database interactions are performed; the function operates entirely within the Forms runtime and external FFI layer, ensuring no transactional side-effects.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-006 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a Windows-native file-chooser dialog to the Oracle Forms runtime by delegating to an external foreign-function interface (FFI) handle. The function accepts dialog configuration parameters (title, initial directory, file filter, flags, and separator character) and returns the user's file selection in the szBuffer output parameter together with a PLS_INTEGER return code indicating the outcome of the dialog interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the pre-registered ORA_FFI function handle (hFunc) that references the underlying Windows file-dialog DLL entry point.
- Step 2 - Accept the dialog configuration inputs: dialog_type (open vs. save variant), hwndOwner (parent window handle), szTitle (dialog caption), szInitDir (initial directory path), szFileFilter (file-type filter string), AdvancedFlags (bitmask of advanced dialog options), and SepChar (separator character for multi-file selections).
- Step 3 - Invoke the external function through the FFI handle, passing all configuration parameters and the IN OUT buffers (szTitle, szInitDir, szFileFilter, szBuffer) by reference so the called DLL can populate or modify them.
- Step 4 - Return the PLS_INTEGER result code produced by the external call to the caller (D2KWUTIL.CHOOSEFILE), indicating whether the user confirmed a selection, cancelled the dialog, or an error occurred.
- Step 5 - Expose the updated IN OUT parameters (szTitle, szInitDir, szFileFilter, szBuffer) back to the caller, where szBuffer contains the selected file path or paths delimited by SepChar.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional logic has been resolved. Any branching behaviour resides within the external DLL invoked via the ORA_FFI handle and is not visible at the PL/SQL layer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid, pre-registered ORA_FFI function handle (hFunc); the handle is the sole mechanism by which the PL/SQL layer communicates with the underlying Windows file-dialog DLL.
- BR-002 - The dialog_type parameter governs the variant of file-chooser presented (e.g., open or save); the calling routine D2KWUTIL.CHOOSEFILE is responsible for supplying the correct integer value.
- BR-003 - szBuffer is the primary output vehicle for the selected file path(s); when multiple files are selectable, individual paths are delimited by the character supplied in SepChar.
- BR-004 - szTitle, szInitDir, and szFileFilter are IN OUT parameters, meaning the external dialog may modify them; callers must treat their post-call values as potentially updated rather than identical to the values passed in.
- BR-005 - No database reads or writes are performed; this function is purely a UI-layer utility that mediates between Oracle Forms and the Windows shell file-dialog API.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-007 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) bridge that passes a debug text string to the underlying C-language D2KWUTIL library routine. It is invoked by the WINDEBUG stored procedure within D2kwutil.pld to emit diagnostic or debug messages through the native Windows utility layer, without interacting with the database.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the target C function entry point within the D2KWUTIL external library.
- Step 2 - Receive the debug text string (Text) to be forwarded to the external routine.
- Step 3 - Delegate execution to the registered C function via the ORA_FFI PRAGMA INTERFACE binding (interface code 11265), passing both hFunc and Text directly to the native library.
- Step 4 - Return control to the calling procedure (WINDEBUG) upon completion of the external call; no return value or output parameter is produced.

---
**Decision Points**

No decision points are present in this procedure. The implementation consists solely of a direct foreign-function call with no conditional branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be called with a valid ORA_FFI.funcHandleType handle (hFunc); the handle must have been registered against the D2KWUTIL C library before invocation, as the procedure itself performs no handle validation.
- BR-002 - The Text parameter carries the debug message content; no transformation, truncation, or formatting is applied by this procedure - the string is passed as-is to the external C function.
- BR-003 - This procedure operates exclusively through the ORA_FFI C-language pragma interface (code 11265) and performs no database reads or writes; it must not be used in contexts requiring transactional database interaction.
- BR-004 - Invocation is restricted to the WINDEBUG procedure within D2kwutil.pld; direct calls from other contexts are outside the defined usage pattern.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-008 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. It accepts a function handle to an externally registered OS routine, passes the source environment variable name and an output buffer, and returns an integer status code indicating the outcome of the OS-level call. This procedure is invoked indirectly through the parent routine GET_ENVIRONMENT_STRING in D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the pre-registered external OS routine responsible for resolving environment variable names.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the external OS call.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter that will be populated by the external OS call with the resolved environment variable value.
- Step 4 - Accept the input buffer length (InBuffLen) that defines the maximum size of the ExpandStr buffer to prevent overflow during the OS call.
- Step 5 - Invoke the external OS function via the supplied FFI function handle, passing SourceStr, ExpandStr, and InBuffLen.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING) reflecting the success or failure of the OS environment variable retrieval.

---
**Decision Points**

No decision points are deterministically evidenced in the available implementation source. Only the function specification is present; no conditional branching logic is declared.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be called with a valid, pre-registered ORA_FFI function handle (hFunc); the handle is not created or validated within this function.
- BR-002 - The ExpandStr buffer size is governed by InBuffLen; the caller is responsible for supplying a buffer length that accommodates the expected environment variable value to prevent truncation or overflow.
- BR-003 - Both SourceStr and ExpandStr are declared IN OUT, meaning the caller must initialise these parameters before invocation and must read their potentially modified values upon return.
- BR-004 - The function returns a PLS_INTEGER status code; the caller (GET_ENVIRONMENT_STRING) is responsible for interpreting this return value to determine whether the environment variable was successfully resolved.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it populates the RegValue output parameter with the corresponding registry data and returns an integer status code indicating the outcome of the retrieval operation. It is invoked by the READ_REGISTRY stored procedure within D2kwutil.pld to abstract low-level OS registry access from higher-level application logic.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that references the underlying native Windows registry API, along with the registry root identifier (RegRoot), registry path (RegPath), entry name (RegEntry), maximum value buffer length (RegValueLength), and expansion flag (RegDontExpand).
- Step 2 - Delegate the registry read operation to the native Windows function referenced by hFunc, passing all supplied parameters through the ORA_FFI mechanism.
- Step 3 - Receive the registry value returned by the native call and populate the IN OUT parameter RegValue with that data.
- Step 4 - Return a PLS_INTEGER status code to the caller (READ_REGISTRY) indicating success or failure of the registry key retrieval.

---
**Decision Points**

No explicit decision points are determinable from the available source. Only the function specification is present; no PL/SQL body with conditional logic was found in the resolved source.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle binds the call to the correct native Windows registry API entry point.
- BR-002 - RegRoot must be a valid Windows registry root constant (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) expressed as a PLS_INTEGER, as required by the underlying native API.
- BR-003 - RegValueLength must accurately reflect the maximum allowable length of the RegValue buffer to prevent buffer overrun at the native API level.
- BR-004 - The RegDontExpand flag controls whether environment-variable references within the registry value are expanded by the OS; the caller must set this flag deliberately to obtain the correct value format.
- BR-005 - RegPath and RegEntry are declared IN OUT, meaning the native API may normalise or modify these values during the call; callers must not assume they are unchanged after execution.
- BR-006 - The integer return value must be evaluated by the calling routine (READ_REGISTRY) to determine whether the registry read succeeded or failed before using the contents of RegValue.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-010 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level Foreign Function Interface (FFI) wrapper that delegates to the underlying Windows API to retrieve a Windows directory path (either the Windows system directory or the temporary directory, depending on the function handle supplied by the caller). The function accepts a pre-registered FFI function handle, a buffer to receive the directory path, and the buffer length, returning a PLS_INTEGER status code. It is consumed exclusively by GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY within D2kwutil.pld.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the FFI function handle (hFunc) that identifies the specific Windows API function to invoke (e.g., GetWindowsDirectory or GetTempPath), the output buffer (WindowsDir) sized to hold the resulting path, and the declared buffer length (InBuffLen).
- Step 2 - Invoke the Windows API function referenced by hFunc via ORA_FFI, passing WindowsDir as the target buffer and InBuffLen as its maximum capacity.
- Step 3 - Allow the Windows API to populate WindowsDir IN OUT with the resolved directory path (e.g., 'C:\Windows\' or 'C:\Temp\').
- Step 4 - Return a PLS_INTEGER status code to the caller reflecting the outcome of the Windows API call (non-zero typically indicates the number of characters written; zero indicates failure).

---
**Decision Points**

No conditional decision points are present in the available implementation. The function delegates execution entirely to the Windows API referenced by hFunc; branching on the returned status code is the responsibility of the calling routines (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function handle (hFunc) must be a valid, pre-registered ORA_FFI.funcHandleType referencing a Windows API directory-retrieval function; passing an invalid handle will produce an undefined or error result.
- BR-002 - InBuffLen must accurately reflect the allocated capacity of the WindowsDir buffer to prevent truncation of the returned directory path.
- BR-003 - WindowsDir is both an input (providing the pre-allocated buffer) and an output (receiving the populated directory path); the caller is responsible for declaring it with sufficient length before invocation.
- BR-004 - The function returns a PLS_INTEGER status code; callers (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY) are responsible for interpreting this value to determine success or failure of the directory retrieval.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-011 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active window by invoking the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN through the WIN_API framework. The function returns the active window handle as a PLS_INTEGER and optionally raises an exception when the handle cannot be obtained, supporting the CHOOSEFILE dialog flow that requires a valid parent window reference.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics by calling DEBUGLOG, recording the value of the RaiseExceptions flag converted to a character string via BOOLTOCHAR.
- Step 2 - Clear any previously recorded error state by calling CLEAN_ERROR_STACK, ensuring a clean context before the external call.
- Step 3 - Check whether the WIN_API framework is enabled (WIN_API.API_ENABLED). If not enabled, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function call by invoking REGISTER_FUNCTION_CALL, binding the iActiveWin slot to the 'D2KWUTIL_ACTIVEWIN' DLL function with a return type of INT and no additional arguments.
- Step 5 - Execute the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN, passing the resolved function handle, and capture the returned integer window handle in iRC.
- Step 6 - Log the result by calling DEBUGLOG, recording the returned RC value.
- Step 7 - Evaluate the returned handle value. If iRC equals zero (no valid handle returned), record an error via ADD_ERROR and, when RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 8 - Return iRC (the active window handle) to the caller.
- Step 9 - Handle exceptions: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, record the no-API error via ADD_ERROR then re-raise; for all other exceptions, record a general error message appended with any external error details via ADD_EXTERNAL_ERRORS then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register and invoke the external DLL function D2KWUTIL.D2KWUTIL_ACTIVEWIN to obtain the active window handle.

FALSE:
Raise WIN_API.NOT_AVAILABLE, bypassing the external call entirely.

---

DP-002

Condition:
The value returned by D2KWUTIL.D2KWUTIL_ACTIVEWIN (iRC) equals zero.

TRUE:
Record an error via ADD_ERROR indicating that the active window handle could not be obtained, then evaluate DP-003.

FALSE:
Skip error recording and return the non-zero handle value to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iRC equals zero).

TRUE:
Raise NO_DATA_FOUND to signal the failure to the calling routine.

FALSE:
Return zero to the caller without raising an exception, allowing the caller to handle the absent handle silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API framework must be enabled before any attempt is made to invoke the external DLL function; execution is blocked and an error is raised if the framework is unavailable.
- BR-002 - The error stack must be cleared at the start of each invocation to prevent stale error information from prior calls from influencing the current execution context.
- BR-003 - A return value of zero from D2KWUTIL.D2KWUTIL_ACTIVEWIN is treated as a failure condition; a zero handle does not represent a valid active window and must be accompanied by an error entry.
- BR-004 - Exception propagation on a zero-handle result is caller-controlled: the RaiseExceptions flag determines whether the function raises NO_DATA_FOUND or silently returns zero.
- BR-005 - All exceptions, regardless of type, must be accompanied by a recorded error message before being re-raised, ensuring the error stack is populated for upstream handlers.
- BR-006 - Unhandled (OTHERS) exceptions must append any available external error detail, obtained via ADD_EXTERNAL_ERRORS, to the recorded error message to maximise diagnostic information.

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-012 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a 'Save File As' dialog to the user and returns the file path chosen for saving. The function delegates file-system dialog rendering to D2KWUTIL.CHOOSEFILE and, if no file is selected, records an application error via ADD_ERROR and optionally raises a hard exception, giving callers control over whether an empty selection is treated as a silent no-op or a fatal condition.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-004](#SP-004--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the candidate file path by assigning the caller-supplied SampleName to the local return variable, pre-populating the dialog with a suggested file name.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE (SP-004) in 'Save_File' mode, passing the Modal flag, Title, StartDirectory, FileFilter, AdvancedFlags, and the pre-populated file path variable (passed by reference) to display the operating-system Save File dialog.
- Step 3 - Evaluate the integer return code (iLRC) produced by D2KWUTIL.CHOOSEFILE to determine whether the user confirmed a file selection or cancelled/dismissed the dialog.
- Step 4 - If iLRC equals 1 (no file selected), call ADD_ERROR (SP-069) to log the message 'No file was selected' against the 'Save_File' context.
- Step 5 - If the RaiseExceptions flag is TRUE and no file was selected, raise the NO_DATA_FOUND exception to propagate the failure to the calling routine.
- Step 6 - If iLRC does not equal 1 (a valid file path was returned), return the resolved file path string to the caller.

---
**Decision Points**

DP-001

Condition:
iLRC (return code from D2KWUTIL.CHOOSEFILE) equals 1, indicating the user did not select a file.

TRUE:
Call ADD_ERROR to record 'No file was selected', then evaluate DP-002.

FALSE:
Return the resolved file path (vcReturnedFile) to the caller.

---

DP-002

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when iLRC = 1).

TRUE:
Raise the NO_DATA_FOUND exception, escalating the missing-selection condition to the calling routine.

FALSE:
Procedure exits without returning a value and without raising an exception; the caller receives a NULL result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The SampleName parameter is used as the pre-populated file name suggestion in the Save dialog; it must be supplied by the caller and is not defaulted by this function.
- BR-002 - A return code of 1 from D2KWUTIL.CHOOSEFILE is the definitive indicator that no file was selected; any other return code is treated as a successful selection.
- BR-003 - When no file is selected, an error must always be logged via ADD_ERROR with the context label 'Save_File' and the message 'No file was selected', regardless of the RaiseExceptions setting.
- BR-004 - Exception escalation on an empty selection is opt-in: the caller controls this behaviour through the RaiseExceptions parameter (default FALSE), allowing silent failure where appropriate.
- BR-005 - The function returns a file path only on a confirmed selection; it does not return a value when the user cancels, ensuring callers cannot inadvertently use an empty or stale path.

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-013 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

TranslateType is a lookup function that converts a string-based C data type name (e.g., 'INT', '*CHAR', 'DOUBLE') into the corresponding ORA_FFI integer constant required to register foreign-function interface (FFI) parameters and return types. It is invoked by REGISTER_FUNCTION_CALL within D2kwutil.pld to resolve type tokens supplied at runtime into the numeric type codes expected by the ORA_FFI library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input string DataType and convert it to uppercase, storing the result in the local variable vcType to ensure case-insensitive matching.
- Step 2 - Evaluate vcType against the full set of recognised C type tokens in a sequential IF-ELSIF chain.
- Step 3 - For each matched token, assign the corresponding ORA_FFI constant to the local return variable iRC (e.g., '*CHAR' -> ORA_FFI.C_CHAR_PTR; 'CHAR' -> ORA_FFI.C_CHAR; '*INT' -> ORA_FFI.C_INT_PTR; 'INT' -> ORA_FFI.C_INT; '*LONG' -> ORA_FFI.C_LONG_PTR; 'LONG' -> ORA_FFI.C_LONG; '*SHORT' or '*BYTE' -> ORA_FFI.C_SHORT_PTR; 'SHORT' or 'BYTE' -> ORA_FFI.C_SHORT; '*DOUBLE' -> ORA_FFI.C_DOUBLE_PTR; 'DOUBLE' -> ORA_FFI.C_DOUBLE; '*VOID' -> ORA_FFI.C_VOID_PTR).
- Step 4 - Return the resolved ORA_FFI integer constant iRC to the caller.

---
**Decision Points**

DP-001
Condition: vcType = '*CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer to character).
FALSE: Evaluation continues to DP-002.

DP-002
Condition: vcType = 'CHAR'
TRUE: iRC is set to ORA_FFI.C_CHAR (character by value).
FALSE: Evaluation continues to DP-003.

DP-003
Condition: vcType = '*INT'
TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer to integer).
FALSE: Evaluation continues to DP-004.

DP-004
Condition: vcType = 'INT'
TRUE: iRC is set to ORA_FFI.C_INT (integer by value).
FALSE: Evaluation continues to DP-005.

DP-005
Condition: vcType = '*LONG'
TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer to long).
FALSE: Evaluation continues to DP-006.

DP-006
Condition: vcType = 'LONG'
TRUE: iRC is set to ORA_FFI.C_LONG (long by value).
FALSE: Evaluation continues to DP-007.

DP-007
Condition: vcType = '*SHORT' OR vcType = '*BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer to short/byte).
FALSE: Evaluation continues to DP-008.

DP-008
Condition: vcType = 'SHORT' OR vcType = 'BYTE'
TRUE: iRC is set to ORA_FFI.C_SHORT (short/byte by value).
FALSE: Evaluation continues to DP-009.

DP-009
Condition: vcType = '*DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer to double).
FALSE: Evaluation continues to DP-010.

DP-010
Condition: vcType = 'DOUBLE'
TRUE: iRC is set to ORA_FFI.C_DOUBLE (double by value).
FALSE: Evaluation continues to DP-011.

DP-011
Condition: vcType = '*VOID'
TRUE: iRC is set to ORA_FFI.C_VOID_PTR (void pointer).
FALSE: No branch matches; iRC remains uninitialised (NULL) and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DataType input is normalised to uppercase before matching; callers may pass type tokens in any case and the function will resolve them correctly.
- BR-002 - The token '*BYTE' is treated as an alias for '*SHORT', and 'BYTE' is treated as an alias for 'SHORT'; both resolve to the same ORA_FFI short constants.
- BR-003 - Only the eleven recognised C type tokens ('*CHAR', 'CHAR', '*INT', 'INT', '*LONG', 'LONG', '*SHORT', 'SHORT', '*BYTE', 'BYTE', '*DOUBLE', 'DOUBLE', '*VOID') produce a defined ORA_FFI constant; any unrecognised token causes the function to return NULL, as no default or error-handling branch is defined.
- BR-004 - The function performs a pure in-memory lookup with no database interaction and no side effects; it is strictly a translation utility.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-014 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [Trigger: FT_CANCEL]
- vr_penetrate_dlr_fmb.xml [Trigger: FT_DEL]
- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric flag indicating which button was pressed. Calling triggers use the return value to determine whether to proceed with or abort a sensitive operation such as a cancellation or deletion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text via the input parameter confirm_msg.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the value of confirm_msg using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user via show_alert and capture the button pressed in p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed against ALERT_BUTTON1 to determine the user's response.
- Step 5 - Return 1 if the user pressed ALERT_BUTTON1 (confirmation accepted), or 0 for any other button (confirmation declined).

---
**Decision Points**

DP-001

Condition: p_albtn_pressed = ALERT_BUTTON1

TRUE: The function returns 1, signalling to the caller that the user confirmed the action.

FALSE: The function returns 0, signalling to the caller that the user did not confirm the action and the operation should be aborted.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The alert used for confirmation must be the predefined alert named AL_CONFIRM; no other alert component is permitted.
- BR-002 - The confirmation message displayed to the user is fully determined by the caller-supplied confirm_msg parameter, making the function reusable across different confirmation contexts (cancel, delete, etc.).
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1); any other button response, regardless of which button is pressed, is treated as a rejection and returns 0.
- BR-004 - The function must always return a numeric value (1 or 0); the trailing RETURN NULL is unreachable and exists only as a syntactic safeguard.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-015 - GENERAL.DISP_TEXT

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [ProgramUnit: PR_REMOVE_ASCII_CHR]
- DPL.pld [StoredProcedure: GENERAL.RAISE_ERROR]
- vr_penetrate_dlr_fmb.xml [Trigger: FT_INSERT]
- vr_penetrate_dlr_fmb.xml [Trigger: KEY-LISTVAL]
- vr_penetrate_dlr_fmb.xml [Trigger: KEY-NEXT-ITEM]
- vr_penetrate_dlr_fmb.xml [Trigger: ON-ERROR]
- vr_penetrate_dlr_fmb.xml [Trigger: ON-MESSAGE]
- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]
- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-LIST-CHANGED]
- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-VALIDATE-ITEM]

---

**Screen:**

Press CTRL+L (N/A / CN_MAIN)

---

**Purpose**

Displays a modal alert dialog to the user containing a caller-supplied message and title. The procedure selects the appropriate pre-defined Oracle Forms alert object based on whether the title indicates an error condition, then presents the alert and waits for the user to dismiss it. It is used across multiple triggers and program units in vr_penetrate_dlr_fmb.xml and by GENERAL.RAISE_ERROR in DPL.pld as the standard mechanism for surfacing informational and error messages.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and dialog title (title_string) as input parameters.
- Step 2 - Evaluate whether the title_string, converted to upper case, equals 'ERROR' to determine which alert template to use.
- Step 3 - If the condition is TRUE, assign the alert name 'AL_ERRINFO' (error-style alert); if FALSE, assign 'AL_NOTE' (informational-style alert).
- Step 4 - Apply the caller-supplied title_string to the selected alert object using SET_ALERT_PROPERTY with the TITLE attribute.
- Step 5 - Apply the caller-supplied text_string to the selected alert object using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute.
- Step 6 - Display the configured alert to the user via SHOW_ALERT and capture the user's button response in the local variable p_alert_id (response is not evaluated further).

---
**Decision Points**

DP-001

Condition:
UPPER(title_string) = 'ERROR'

TRUE:
The alert name is set to 'AL_ERRINFO', presenting the message in an error-styled alert dialog.

FALSE:
The alert name is set to 'AL_NOTE', presenting the message in a general informational alert dialog.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure supports exactly two alert styles: 'AL_ERRINFO' for error messages and 'AL_NOTE' for all other messages; the selection is driven solely by whether the title equals 'ERROR' (case-insensitive).
- BR-002 - The title comparison is performed in upper case, ensuring that variations in capitalisation (e.g., 'error', 'Error') are all treated as error-level alerts.
- BR-003 - Both the alert title and the alert message text are overwritten dynamically at runtime before display, ensuring the alert always reflects the current caller-supplied content rather than any design-time default.
- BR-004 - The user's button response returned by SHOW_ALERT is captured but not acted upon; the procedure does not branch or raise exceptions based on the user's dismissal choice.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-016 - GENERAL.RAISE_ERROR

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [Trigger: ON-ERROR]

---

**Screen:**

N/A

---

**Purpose**

Centralises runtime error handling for Oracle Forms by classifying an incoming message code as an Error, Note, or Caution, composing the display text, and presenting it to the user via GENERAL.DISP_TEXT. When the message is classified as a hard error, the procedure additionally raises FORM_TRIGGER_FAILURE to halt form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| mesg_code | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-015](#SP-015--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message code (mesg_code) as the sole input parameter.
- Step 2 - Compose the display text by concatenating mesg_code, a colon separator, and mesg_text (note: mesg_text is declared but not populated by the commented-out GENERAL.get_message call, so it contributes an empty suffix at runtime).
- Step 3 - Evaluate mesg_type to determine the severity classification of the message.
- Step 4 - If mesg_type is 'E' (Error), set the dialog title to 'Error', invoke GENERAL.DISP_TEXT to present the message, then raise FORM_TRIGGER_FAILURE to abort the current form trigger.
- Step 5 - If mesg_type is 'N' (Note), set the dialog title to 'Note' and invoke GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 6 - If mesg_type is 'C' (Caution), set the dialog title to 'Caution' and invoke GENERAL.DISP_TEXT to present the message; processing continues normally.
- Step 7 - If mesg_type matches none of the above values, no action is taken and the procedure exits silently.

---
**Decision Points**

DP-001

Condition:
mesg_type = 'E'

TRUE:
Set dialog title to 'Error', call GENERAL.DISP_TEXT with the composed message text and title, then raise FORM_TRIGGER_FAILURE to halt form trigger execution.

FALSE:
Proceed to evaluate DP-002.

---

DP-002

Condition:
mesg_type = 'N'

TRUE:
Set dialog title to 'Note', call GENERAL.DISP_TEXT with the composed message text and title; form processing continues.

FALSE:
Proceed to evaluate DP-003.

---

DP-003

Condition:
mesg_type = 'C'

TRUE:
Set dialog title to 'Caution', call GENERAL.DISP_TEXT with the composed message text and title; form processing continues.

FALSE:
No message is displayed and the procedure exits silently.

---
**Database Interactions**

- DB-001 - Read AM_PERMISSIONS - Reads data from AM_PERMISSIONS for lookup or validation.
**Business Rules**

- BR-001 - The message display text must always include the originating message code as a prefix, separated from any supplementary text by ' : ', ensuring the user can identify the specific message reference.
- BR-002 - A message classified as type 'E' (Error) is treated as a blocking condition; FORM_TRIGGER_FAILURE must be raised after displaying the error dialog to prevent further form trigger execution.
- BR-003 - Messages classified as type 'N' (Note) or 'C' (Caution) are informational only; they are displayed to the user but do not interrupt form processing.
- BR-004 - All user-facing message dialogs must be rendered through GENERAL.DISP_TEXT (SP-015); no direct Oracle Forms alert or message calls are permitted within this procedure.
- BR-005 - If mesg_type does not match any recognised severity code ('E', 'N', or 'C'), the procedure takes no action, suppressing unclassified messages silently.

---
**Implementation Logic**

```plsql
PROCEDURE RAISE_ERROR ( mesg_code IN VARCHAR2 )IS
  mesg_type  varchar2(7); 
  mesg_text  varchar2(200) ;
  mesg_title varchar2(7);
  BEGIN
     -- murali 17.05.04 GENERAL.get_message(mesg_code,mesg_text,mesg_type );
     mesg_text:=mesg_code||' : '||mesg_text;		
     IF ( mesg_type = 'E' ) THEN
        mesg_title := 'Error' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
        raise FORM_TRIGGER_FAILURE;
     ELSIF ( mesg_type = 'N' ) THEN
        mesg_title := 'Note' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     ELSIF ( mesg_type = 'C' ) THEN
        mesg_title := 'Caution' ;
        GENERAL.DISP_TEXT(mesg_text,mesg_title);
     END IF;
  END;     

/* PROCEDURE check_rights( 
pi_form_name in varchar2,
pi_user_id in number) IS
lv_x varchar2(1);
BEGIN
	
	begin
	SELECT substr(access_string, pi_user_id,1) 
	INTO   lv_x
	FROM   	am_permissions
	WHERE  form_name = pi_form_name
	AND SUBSTR(access_string,pi_user_id,1)='Y';
	exception 
		when no_data_found then
		  general.disp_text('You do not have the Permission to access this.','Error rr');
		  raise form_trigger_failure; 
		when too_many_rows then
		  general.disp_text('Many rows in USER_PERMISSIONS','Error ss');
		  raise form_trigger_failure;
		when others then
		       general.disp_text(sqlerrm,'Error mm');
		       raise form_trigger_failure;
	end;

	open_form(pi_form_name,activate,session);
END;
*/
```

#### SP-017 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command in blocking mode, meaning the Oracle Forms session waits for the command to complete before continuing. It acts as a convenience wrapper that enforces the BLOCKING_MODE constant when delegating execution to WEBUTIL.EXECUTE (SP-026).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-026](#SP-026--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the operating-system command string (cmd) as input.
- Step 2 - Invoke WEBUTIL.EXECUTE (SP-026) passing the supplied cmd and the constant BLOCKING_MODE as the execution mode.
- Step 3 - Return the PROCESS_ID value produced by WEBUTIL.EXECUTE to the caller (WEBUTIL.HOST).

---
**Decision Points**

No conditional decision points exist in this procedure. Execution always delegates unconditionally to WEBUTIL.EXECUTE with BLOCKING_MODE; branching logic, if any, resides within WEBUTIL.EXECUTE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The command must always be executed in blocking mode; the procedure does not permit the caller to override the execution mode - BLOCKING_MODE is hard-coded in the call to WEBUTIL.EXECUTE (SP-026).
- BR-002 - The procedure returns a PROCESS_ID, allowing the caller (WEBUTIL.HOST) to reference or track the completed process after execution finishes.

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-018 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present on the client machine at the correct version. For each library defined in the property bundle for the package, the procedure compares the installed version against the required version and, where a mismatch or absence is detected, downloads the library from the configured URL to the client. It is invoked by WEBUTIL.REGISTERBEAN as part of the package registration sequence.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-058](#SP-058--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the packageID input parameter that identifies the WebUtil package whose dependent system libraries must be checked.
- Step 2 - Enter a loop and, for each iteration, attempt to read a library specification entry from the property bundle using the fully qualified key 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib_index>'. Increment the library index counter (lib) on each successful read.
- Step 3 - If the OS-architecture-specific key returns no value, fall back to reading the key 'install.syslib.<OSFamily>.<packageID>.<lib_index>' to support OS-family-level definitions.
- Step 4 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 5 - Parse the retrieved library specification string using pipe-delimited positions to extract: library file name (position 1), expected file size in bytes (position 2), required version string (position 3), and a progress-display flag (position 4).
- Step 6 - Query the client settings store via WEBUTIL.GETCLIENTSETTING using the key 'syslib.<libName>' to retrieve the currently installed version of the library on the client.
- Step 7 - Evaluate whether a download is required: if the installed version is NULL, differs from the required version, or the REDOWNLOAD_SYSLIB flag is set, proceed to download; otherwise skip to the next library.
- Step 8 - Resolve the download base URL by reading the property bundle in order of specificity: first 'install.syslib.location.<OSFamily>.<OSArch>', then 'install.syslib.location.<OSFamily>', then 'install.syslib.location', using the first non-NULL value found.
- Step 9 - Invoke WEBUTIL.DOWNLOADFROMURLINT with the constructed full URL (base URL + '/' + library file name), the library name, the system-library install type indicator (1), the expected file size, the progress flag, and localised progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 10 - If the download succeeds, record the newly installed version on the client by calling WEBUTIL.SETCLIENTSETTING with key 'syslib.<libName>' and the required version value.
- Step 11 - If the download fails, write a failure message to the WebUtil log via WEBUTIL.LOG, flagging it as an error, and continue processing remaining libraries in the loop.

---
**Decision Points**

DP-001

Condition: The property bundle key 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<lib_index>' returns a non-NULL value.

TRUE: Use the returned specification string for the current library entry.

FALSE: Attempt the fallback lookup using the OS-family-only key 'install.syslib.<OSFamily>.<packageID>.<lib_index>' (see DP-002).

---

DP-002

Condition: The OS-family-only fallback key 'install.syslib.<OSFamily>.<packageID>.<lib_index>' returns a non-NULL value.

TRUE: Use the returned specification string for the current library entry.

FALSE: Exit the loop; no further library entries exist for this package.

---

DP-003

Condition: The installed version retrieved from the client settings store is NULL, differs from the required version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: The library is already installed at the correct version; skip download and advance to the next library.

---

DP-004

Condition: The property bundle key 'install.syslib.location.<OSFamily>.<OSArch>' returns a non-NULL download base URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the next fallback key 'install.syslib.location.<OSFamily>' (see DP-005).

---

DP-005

Condition: The property bundle key 'install.syslib.location.<OSFamily>' returns a non-NULL download base URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the generic fallback key 'install.syslib.location'.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Record the required version as the installed version on the client via WEBUTIL.SETCLIENTSETTING.

FALSE: Log a failure message for the library via WEBUTIL.LOG and continue processing the remaining libraries.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications must be defined in the property bundle using the structured key pattern 'install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>' or its OS-family fallback; the absence of an entry at a given index signals the end of the library list for that package.
- BR-002 - Each library specification string is pipe-delimited and must encode, in order: library file name, expected file size, required version, and a Boolean progress-display indicator; all four fields are mandatory for correct processing.
- BR-003 - A library must be downloaded if and only if the client has no recorded installed version, the recorded version does not match the required version, or the REDOWNLOAD_SYSLIB override flag is active.
- BR-004 - The download base URL is resolved with the highest specificity first (OS family + architecture), falling back to OS family only, then to the generic location; this ensures platform-appropriate library sources are used where available.
- BR-005 - Upon a successful download, the required version string must be persisted to the client settings store under the key 'syslib.<libName>' so that subsequent invocations can detect an already-current installation.
- BR-006 - A failed library download must be logged as an error via WEBUTIL.LOG but must not abort processing; the procedure continues to evaluate and download remaining libraries in the package.
- BR-007 - Localised strings for the progress dialog (title and subtitle) must be sourced exclusively from the message bundle via WEBUTIL.READTRANSFROMMSGBUNDLE using the keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring UI text is consistent with the application's localisation framework.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-019 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a previously registered callback entry from the internal callbacks collection using the supplied integer key. This procedure is used during WebUtil processing to clean up callback registrations that are no longer needed, ensuring the collection does not retain stale or orphaned entries.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer key (callbackKey) that identifies the callback entry to be removed.
- Step 2 - Check whether an entry with the given key exists in the internal callbacks collection (m_callbacks).
- Step 3 - If the entry exists, delete it from the collection using the supplied key.
- Step 4 - If the entry does not exist, take no action and exit silently.

---
**Decision Points**

DP-001

Condition:
Does an entry identified by callbackKey exist in the m_callbacks collection (m_callbacks.exists(callbackKey))?

TRUE:
Delete the entry from m_callbacks using m_callbacks.delete(callbackKey).

FALSE:
No action is taken; the procedure exits without modifying the collection.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must only attempt to delete a callback entry if it is confirmed to exist in the collection; deletion of a non-existent key is not permitted and is silently bypassed.
- BR-002 - The callbackKey parameter uniquely identifies a single entry in the m_callbacks collection; the procedure operates solely on the entry matching that key.
- BR-003 - No error or exception is raised when the specified callbackKey is not found in the collection; the procedure completes normally in all cases.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-020 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by its checksum value. The procedure delegates the close operation entirely to the WebUtil_DB package, releasing any server-side resources associated with the BLOB session referenced by the supplied checksum.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the sole argument.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

No decision points are present in this procedure. All conditional logic, if any, is encapsulated within WebUtil_DB.CloseBlob and is not exposed at this layer.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a previously opened BLOB handle; the procedure passes it directly to WebUtil_DB.CloseBlob without independent validation.
- BR-002 - The success or failure of the close operation is determined solely by the BOOLEAN value returned by WebUtil_DB.CloseBlob; this procedure does not apply additional outcome logic.
- BR-003 - This function is invoked from WEBUTIL.SETDATA, meaning BLOB closure is expected to occur as part of the data-set completion lifecycle managed by the parent routine.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-021 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open server-side file handle represented by a Java object reference. The procedure delegates the close operation to the underlying Java class oracle/forms/webutil/fileTransfer/AppServerFileReader via a JNI boolean method call, returning a success indicator to the caller (WEBUTIL.SETDATA).

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) that identifies the currently open AppServerFileReader file handle.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method.
- Step 3 - Invoke the closeFile() method on the AppServerFileReader Java class through JNI.CALL_BOOLEAN_METHOD, passing the object reference and an empty argument signature '()Z'.
- Step 4 - Return the boolean result produced by the Java method to the caller, indicating whether the file was closed successfully.

---
**Decision Points**

DP-001

Condition: JNI.CALL_BOOLEAN_METHOD returns TRUE or FALSE based on the outcome of the Java closeFile() invocation.

TRUE: The AppServerFileReader successfully closed the file; the function returns TRUE to the calling routine WEBUTIL.SETDATA.

FALSE: The AppServerFileReader was unable to close the file; the function returns FALSE to the calling routine WEBUTIL.SETDATA, signalling a failure condition.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The JNI argument list must be explicitly reset to NULL before invoking the Java method to prevent argument contamination from any prior JNI call.
- BR-002 - The file close operation must be performed against the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class using the no-argument method signature '()Z'; no other class or signature is permissible.
- BR-003 - The function must propagate the raw boolean result from the Java layer unchanged to the caller; no additional transformation or default override is applied.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-022 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a simplified public entry point for downloading a file from a specified URL to a client-side destination. The procedure delegates all processing to the internal implementation routine WEBUTIL.DOWNLOADFROMURLINT (SP-023), passing fixed defaults for parameters not exposed at this level. It is invoked by WEBUTIL.URL_TO_CLIENT and abstracts the complexity of the internal download mechanism from its callers.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-023](#SP-023--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the three caller-supplied inputs: the source URL to download from (sourceURL), the target path on the client machine (clientDestination), and an optional expected file size (fileSize; defaults to 0 if not provided).
- Step 2 - Invoke WEBUTIL.DOWNLOADFROMURLINT (SP-023) with the following argument mapping: sourceURL and clientDestination are passed through unchanged; the offset parameter is fixed at 0; fileSize is forwarded as supplied; the resume flag is fixed at FALSE; and the three optional credential/proxy parameters are passed as NULL.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURLINT directly to the caller, indicating whether the download operation succeeded or failed.

---
**Decision Points**

No conditional decision points exist within this routine. All branching and conditional logic is fully delegated to WEBUTIL.DOWNLOADFROMURLINT (SP-023). The function acts as a pass-through wrapper with fixed default arguments.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file offset passed to the internal download routine is always 0, meaning downloads initiated through this public entry point always begin from the start of the remote file; partial/resumable downloads are not supported at this interface level.
- BR-002 - The resume flag forwarded to WEBUTIL.DOWNLOADFROMURLINT is always FALSE, explicitly disabling resume behaviour for callers using this simplified interface.
- BR-003 - Authentication credentials and proxy parameters are always passed as NULL, meaning this entry point supports only unauthenticated, non-proxied URL downloads.
- BR-004 - The fileSize parameter defaults to 0 if not supplied by the caller, indicating that file size validation or pre-allocation is optional at this interface level.
- BR-005 - The success or failure of the download operation is communicated solely through the returned BOOLEAN value; no exception is raised or output parameter populated by this routine directly.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-023 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs and submits a formatted download request to the WebUtil client-side bean, instructing it to retrieve a file from a given URL and save it to a specified client destination. The function returns TRUE if the bean reports a successful download, or FALSE if a handled error occurs. It is called internally by WEBUTIL.CHECKLIBS and WEBUTIL.DOWNLOADFROMURL to perform the actual file-transfer operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Validate that sourceURL is not null; if null, raise the URL_NULL exception.
- Step 2 - Validate that clientDestination is not null; if null, raise the CLIENT_FILE_NULL exception.
- Step 3 - Evaluate specialDestination: if null, negative, or greater than 2, append '0' to the submit string; otherwise append its numeric value. Append the pipe separator after the value.
- Step 4 - Evaluate fileSize: if null, append '0' to the submit string; otherwise append its numeric value. Append the pipe separator.
- Step 5 - Evaluate withProgress: if null or FALSE, append 'N' to the submit string; if TRUE, append 'Y'. Append the pipe separator.
- Step 6 - Append sourceURL, clientDestination, progressTitle (defaulting to a single space if null), progressSubTitle (defaulting to a single space if null), and progressMessage (defaulting to a single space if null) to the submit string, each separated by the pipe character.
- Step 7 - Call WebUtil_Core.setProperty with the WUC_PACKAGE constant, the property key 'WUC_URL_DOWNLOAD', and the fully assembled submit string to dispatch the download request to the client bean.
- Step 8 - Call WebUtil_Core.getProperty with the same package constant and property key to retrieve the bean's response.
- Step 9 - Return TRUE if the response equals 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition:
sourceURL IS NULL

TRUE:
Raise the URL_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 25 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue processing.

---

DP-002

Condition:
clientDestination IS NULL

TRUE:
Raise the CLIENT_FILE_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 130 referencing 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue processing.

---

DP-003

Condition:
specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE:
Append '0' (the default/safe value) to the submit string.

FALSE:
Append the actual numeric value of specialDestination to the submit string.

---

DP-004

Condition:
fileSize IS NULL

TRUE:
Append '0' to the submit string.

FALSE:
Append the actual numeric value of fileSize to the submit string.

---

DP-005

Condition:
withProgress IS NULL OR NOT withProgress

TRUE:
Append 'N' (no progress display) to the submit string.

FALSE:
Append 'Y' (show progress) to the submit string.

---

DP-006

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during setProperty or getProperty

TRUE:
Call WebUtil_Core.ErrorAlert to notify the user that the required bean class was not found, then raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Not applicable; this path is only reached via exception.

---

DP-007

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during setProperty or getProperty

TRUE:
Raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Not applicable; this path is only reached via exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A source URL must be supplied; a null sourceURL is invalid and causes the function to return FALSE after logging error code 25.
- BR-002 - A client destination path must be supplied; a null clientDestination is invalid and causes the function to return FALSE after logging error code 130.
- BR-003 - The specialDestination parameter must be an integer in the range 0-2 inclusive; any null, negative, or out-of-range value is normalised to 0 before submission.
- BR-004 - A null fileSize is normalised to 0 before submission, ensuring the bean always receives a valid numeric size token.
- BR-005 - Progress display is disabled by default; the 'Y' flag is only included in the submit string when withProgress is explicitly TRUE.
- BR-006 - Null progress label parameters (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character to preserve the pipe-delimited token structure expected by the bean.
- BR-007 - The download request and its result are communicated exclusively through WebUtil_Core property get/set calls using the WUC_URL_DOWNLOAD key; no direct database interaction is performed.
- BR-008 - If the WebUtil bean is not registered on the client, processing must be aborted via FORM_TRIGGER_FAILURE; the function does not silently return FALSE in this scenario.
- BR-009 - A PROPERTY_ERROR raised by the WebUtil_Core layer also aborts form processing via FORM_TRIGGER_FAILURE rather than returning a boolean result.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-024 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Constructs a structured error message string from a numeric error code, a program-unit name, and up to three optional argument values, then publishes that message to the WebUtil client-side property 'WUC_ERROR_MSG' via Webutil_Core.setProperty. This provides a standardised mechanism for surfacing WebUtil runtime errors back to the calling Oracle Forms environment.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the error text variable by concatenating the literal prefix 'ERROR', the zero-padded three-digit error code (derived from the 'code' parameter), a pipe delimiter, and the program-unit name ('pu_name').
- Step 2 - Evaluate whether the first optional argument ('arg1') is non-null; if so, append a pipe delimiter followed by 'arg1' to the error text string.
- Step 3 - Evaluate whether the second optional argument ('arg2') is non-null; if so, append a pipe delimiter followed by 'arg2' to the error text string.
- Step 4 - Evaluate whether the third optional argument ('arg3') is non-null; if so, append a pipe delimiter followed by 'arg3' to the error text string.
- Step 5 - Publish the fully assembled error text string to the WebUtil property 'WUC_ERROR_MSG' by calling Webutil_Core.setProperty, passing the 'packageID' as the target package identifier.

---
**Decision Points**

DP-001

Condition:
arg1 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg1 to the error text string.

FALSE:
Skip; arg1 is omitted from the error text string.

---

DP-002

Condition:
arg2 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg2 to the error text string.

FALSE:
Skip; arg2 is omitted from the error text string.

---

DP-003

Condition:
arg3 IS NOT NULL

TRUE:
Append a pipe delimiter and the value of arg3 to the error text string.

FALSE:
Skip; arg3 is omitted from the error text string.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error message must always begin with the fixed prefix 'ERROR' followed by the error code zero-padded to exactly three digits, ensuring a consistent, parseable format for all WebUtil errors.
- BR-002 - The program-unit name ('pu_name') is a mandatory component of the error message and is always included immediately after the error code, separated by a pipe delimiter.
- BR-003 - Optional arguments (arg1, arg2, arg3) are included in the error message only when they carry a non-null value; null arguments are silently excluded, keeping the message compact.
- BR-004 - All message segments are separated by pipe ('|') delimiters, producing a pipe-delimited string that downstream consumers can reliably parse.
- BR-005 - The assembled error message must be published to the WebUtil property key 'WUC_ERROR_MSG' using Webutil_Core.setProperty, scoped to the package identified by 'packageID', so that the Oracle Forms client can retrieve and display the error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-025 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error message to the user by either presenting a pre-configured alert dialog or falling back to the Forms MESSAGE built-in. The procedure is invoked by FCLOSE, LOG, and POPULATEPROPERTYBUNDLE to surface bean-registration and bean-not-found errors in a consistent, user-visible manner.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the error text string (errText) that describes the WebUtil error condition to be communicated to the user.
- Step 2 - Call WEBUTIL.ID_NULL (SP-047) to evaluate whether the module-level alert handle m_errorAlert references a valid, registered alert object.
- Step 3 - If the alert handle is valid, set the alert's message text property to errText using SET_ALERT_PROPERTY with the ALERT_MESSAGE_TEXT attribute, then display the alert dialog to the user via SHOW_ALERT, capturing the user's response in the local ignore variable (response is not acted upon).
- Step 4 - If the alert handle is not valid (null/unregistered), fall back to the Forms MESSAGE built-in, prepending the literal prefix 'WebUtil Error: ' to errText so the user still receives the error information.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) returns FALSE - i.e., the module-level alert handle m_errorAlert is not null and refers to a registered alert object.

TRUE:
Set the alert's ALERT_MESSAGE_TEXT property to errText and display the alert dialog via SHOW_ALERT. The user's button response is captured but ignored.

FALSE:
Bypass the alert dialog entirely and display the error using the Forms MESSAGE built-in, formatting the output as 'WebUtil Error: ' concatenated with errText.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Error messages surfaced through this procedure must always be prefixed with the label 'WebUtil Error' to clearly identify their origin, whether displayed via the alert dialog or the MESSAGE fallback.
- BR-002 - The alert title is not overwritten at runtime; it is assumed to be correctly set in the alert's design-time property sheet, ensuring consistent branding without redundant property updates.
- BR-003 - The user's response to the alert dialog (button clicked) is deliberately discarded; this procedure is notification-only and does not branch on user input.
- BR-004 - Availability of the alert dialog depends on the alert handle m_errorAlert being a valid, non-null reference as determined by WEBUTIL.ID_NULL (SP-047); if the handle is unregistered, the MESSAGE built-in serves as the mandatory fallback to ensure no error is silently lost.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-026 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command from an Oracle Forms client session by delegating the call to the WebUtil host-execution bean. The procedure accepts a command string and an execution mode flag, passes both to the underlying WebUtil core layer, and returns a process handle that the caller can use to track or interact with the spawned process.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the command string (cmd) and execution mode (exemode) as input parameters.
- Step 2 - Check whether the command string is non-null; if it is null, skip execution and return an uninitialised process handle.
- Step 3 - Set the execution mode on the WebUtil host-utility bean by calling WebUtil_Core.setProperty with the WUH_EXECUTION_MODE property key and the supplied exemode value.
- Step 4 - Instruct the WebUtil host-utility bean to execute the command by calling WebUtil_Core.setProperty with the WUH_EXECUTE property key and the supplied cmd value.
- Step 5 - Retrieve the process identifier assigned by the bean by calling WebUtil_Core.getProperty with the WUH_EXECUTE property key, convert the returned string to a number, and store it in the local PROCESS_ID variable.
- Step 6 - Return the populated PROCESS_ID record to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing implementation class and indicating that WEBUTIL_HOST.Execute will not function.

---
**Decision Points**

DP-001

Condition:
cmd IS NOT NULL

TRUE:
Set the execution mode property, set the execute command property, retrieve and store the resulting process handle, then return the populated PROCESS_ID.

FALSE:
Skip all bean interactions and return an uninitialised PROCESS_ID record to the caller.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during bean property set or get operations.

TRUE:
Display an error alert that names the missing WebUtil implementation class and states that WEBUTIL_HOST.Execute will not work; no process handle is returned.

FALSE:
Normal execution continues; the process handle is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null command string must not be dispatched to the WebUtil bean; the function returns an empty process handle without invoking any bean operations.
- BR-002 - The execution mode must be set on the bean before the command is submitted, ensuring the bean applies the correct run-mode semantics to the spawned process.
- BR-003 - The process identifier returned by the bean is stored as a numeric handle within the PROCESS_ID record type; the raw string value from the bean property must be converted to a number before assignment.
- BR-004 - If the WebUtil host-utility bean is not registered on the client, the function must surface a descriptive error alert that identifies the missing implementation class and must not silently fail or return a partial result.

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-027 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side text file by releasing the file handle managed by the WebUtil framework. The procedure signals the WebUtil bean to perform the physical close operation, clears the in-memory handle reference, and surfaces a descriptive alert via WEBUTIL.ERRORALERT if the required bean is not registered, ensuring the calling process receives a clean error state rather than a silent failure.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-034](#SP-034--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file_type parameter (IN OUT) representing an open client-side text file handle.
- Step 2 - Check whether the file handle (file.handle) is not NULL, indicating an actively open file.
- Step 3 - If the handle is active, invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the current handle value to instruct the WebUtil bean to close the physical file on the client.
- Step 4 - Set file.handle to NULL to mark the file as closed in the Oracle Forms session, preventing any further operations on the stale handle.
- Step 5 - If the BEAN_NOT_REGISTERED exception is raised during the close attempt, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a message identifying the missing bean class (retrieved by WEBUTIL.GETIMPLCLASS via WebUtil_Core.getImplClass) and stating that CLIENT_TEXT_IO.fclose will not work; then raise TOOL_ERR.TOOL_ERROR to propagate the failure to the caller.
- Step 6 - If the PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR directly without an alert, propagating the error to the caller.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to close the file by invoking WebUtil_Core.setProperty with the WUF_TEXTIO_CLOSE command and then set file.handle to NULL.

FALSE:
No action is taken; the procedure exits normally because there is no open file handle to close.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE:
Call WEBUTIL.ERRORALERT (WebUtil_Core.ErrorAlert) with a message that includes the implementation class name returned by WEBUTIL.GETIMPLCLASS (WebUtil_Core.getImplClass) and the text 'bean not found. CLIENT_TEXT_IO.fclose will not work'; then raise TOOL_ERR.TOOL_ERROR.

FALSE:
Exception is not of this type; processing continues to the next exception handler check.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately without displaying an alert, propagating the error to the caller.

FALSE:
Exception is not of this type; normal processing completes without error.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file close operation is only attempted when the file handle is not NULL; a NULL handle is treated as already closed and requires no action.
- BR-002 - Once the WebUtil bean successfully closes the file, the in-memory handle must be set to NULL immediately to prevent reuse of a stale reference within the same Oracle Forms session.
- BR-003 - If the WebUtil bean required to perform the close is not registered on the client, the procedure must surface a user-facing alert (via WEBUTIL.ERRORALERT) that identifies the missing bean class (resolved by WEBUTIL.GETIMPLCLASS) before terminating with TOOL_ERR.TOOL_ERROR.
- BR-004 - A PROPERTY_ERROR during the close operation must cause the procedure to raise TOOL_ERR.TOOL_ERROR, ensuring the calling context (dms_excel_report.pld / VIEW_EXCEL_REPORT_NEW) is aware of the failure and can handle it appropriately.
- BR-005 - No database table interactions are performed; all file operations are delegated entirely to the WebUtil client-side bean layer.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-028 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents the client-side operating-system Save File dialog to the end user, allowing them to choose a target directory and file name when saving a generated Excel report. The function delegates entirely to WEBUTIL.FILE_SELECTION_DIALOG_INT, passing a fixed mode constant (SAVE_FILE sourced from D2KWUTIL) and hard-coded flags that enforce save-dialog behaviour. It returns the fully qualified file path selected by the user, or NULL if the dialog is cancelled.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-012](#SP-012--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-029](#SP-029--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the optional input parameters: default directory path (directory_name), suggested file name (file_name), file-type filter string (file_filter), and dialog title (title).
- Step 2 - Invoke WEBUTIL.FILE_SELECTION_DIALOG_INT, forwarding all four caller-supplied parameters together with three fixed arguments: the SAVE_FILE mode constant (obtained from D2KWUTIL), a TRUE flag indicating that the dialog operates in save mode, and a FALSE flag suppressing multi-select or read-only behaviour.
- Step 3 - Return the string result produced by WEBUTIL.FILE_SELECTION_DIALOG_INT directly to the caller (VIEW_EXCEL_REPORT_NEW in dms_excel_report.pld). This value is the file path entered or selected by the user, or NULL if the user dismissed the dialog without confirming.

---
**Decision Points**

No explicit conditional branching exists within FILE_SAVE_DIALOG itself. All decision logic is encapsulated inside WEBUTIL.FILE_SELECTION_DIALOG_INT. The function unconditionally passes SAVE_FILE, TRUE, and FALSE as fixed arguments, so no runtime branching occurs at this level.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The dialog must always operate in save-file mode; this is enforced by passing the D2KWUTIL.SAVE_FILE constant and the boolean TRUE flag to FILE_SELECTION_DIALOG_INT - these values are hard-coded and cannot be overridden by the caller.
- BR-002 - All four input parameters (directory_name, file_name, file_filter, title) are optional (default NULL); the dialog must still be invokable without any caller-supplied context.
- BR-003 - The function must return the result of FILE_SELECTION_DIALOG_INT unmodified; no post-processing, validation, or defaulting of the returned path is performed at this layer.
- BR-004 - The FALSE flag passed as the final argument to FILE_SELECTION_DIALOG_INT ensures that behaviours such as multi-file selection or read-only mode are disabled for a save-dialog invocation.

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-029 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file-selection dialog to the end user by communicating with the WebUtil client-side bean, then returns the selected file or directory path as a VARCHAR2 string. The function supports three dialog modes-Save File, Open Directory, and Open File-controlled by the calling procedure (WEBUTIL.FILE_SAVE_DIALOG). It also normalises any escaped backslash sequences that may be introduced by the underlying Java JFileChooser component before returning the result.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-012](#SP-012--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Push the initial dialog context to the WebUtil bean by setting the starting directory (`WUF_GFN_DIRNAME`), default file name (`WUF_FILENAME`), file-type filter (`WUF_FILTER`), dialog title (`WUF_GFN_MESSAGE`), and multi-select flag (`WUF_GFN_MULTISELECT`) via `WebUtil_Core.setProperty`.
- Step 2 - Determine the dialog mode: if `dialog_type` equals the `SAVE_FILE` constant, retrieve the result using the `WUF_GFN_SAVEFILE` property; if `select_file` is FALSE, retrieve the result using the `WUF_GFN_OPENDIR` property (directory picker); otherwise retrieve the result using the `WUF_GFN_OPENFILE` property (file picker).
- Step 3 - Inspect the returned path string for a double-backslash sequence (`\\`) at position 1, which can occur when JFileChooser returns a UNC path.
- Step 4 - If the string starts with `\\`, prepend an additional `\\` to preserve the UNC prefix before the global replace that follows.
- Step 5 - Apply a global `REPLACE` to convert every remaining `\\` sequence to a single `\`, yielding a correctly formed file-system path.
- Step 6 - Return the normalised path string to the caller (WEBUTIL.FILE_SAVE_DIALOG).
- Step 7 - If the WebUtil bean is not registered, raise an error alert identifying the missing bean class and then raise `FORM_TRIGGER_FAILURE` to abort processing.
- Step 8 - If a property read/write error occurs, raise `FORM_TRIGGER_FAILURE` to abort processing.

---
**Decision Points**

DP-001

Condition:
`dialog_type = SAVE_FILE`

TRUE:
Retrieve the selected path from the bean using the `WUF_GFN_SAVEFILE` property, presenting a Save File dialog.

FALSE:
Proceed to DP-002 to determine whether an Open Directory or Open File dialog is required.

---

DP-002

Condition:
`select_file` is FALSE (evaluated only when `dialog_type ≠ SAVE_FILE`)

TRUE:
Retrieve the selected path from the bean using the `WUF_GFN_OPENDIR` property, presenting a directory-selection dialog.

FALSE:
Retrieve the selected path from the bean using the `WUF_GFN_OPENFILE` property, presenting an Open File dialog.

---

DP-003

Condition:
The position of the first `\\` sequence in the returned result string equals 1 (i.e., the path begins with a double backslash, indicating a UNC path).

TRUE:
Prepend `\\` to the result string before executing the global backslash-replacement, so the UNC prefix is preserved after normalisation.

FALSE:
Proceed directly to the global `REPLACE` without prepending any characters.

---

DP-004

Condition:
Exception `WebUtil_Core.BEAN_NOT_REGISTERED` is raised during bean property interaction.

TRUE:
Display an error alert identifying the unregistered bean class and raise `FORM_TRIGGER_FAILURE` to halt form processing.

FALSE:
Normal execution continues; no alert is raised.

---

DP-005

Condition:
Exception `WebUtil_Core.PROPERTY_ERROR` is raised during bean property interaction.

TRUE:
Raise `FORM_TRIGGER_FAILURE` to halt form processing.

FALSE:
Normal execution continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always receive a valid `dialog_type` value; the `SAVE_FILE` constant is the only named constant checked-any other numeric value combined with `select_file = TRUE` defaults to Open File mode.
- BR-002 - All five dialog context properties (`WUF_GFN_DIRNAME`, `WUF_FILENAME`, `WUF_FILTER`, `WUF_GFN_MESSAGE`, `WUF_GFN_MULTISELECT`) must be set on the WebUtil bean before the dialog is invoked; no dialog may be presented with partially initialised context.
- BR-003 - The returned file-system path must be normalised so that double-backslash sequences (`\\`) are reduced to single backslashes (`\`), ensuring downstream consumers receive a consistent path format regardless of JFileChooser escaping behaviour.
- BR-004 - UNC paths (those beginning with `\\`) must be protected during normalisation by prepending an extra `\\` prior to the global replace, so the leading double-backslash identifying the UNC root is retained in the final result.
- BR-005 - If the WebUtil client-side bean is not registered in the form session, the function must not silently fail; it must display a descriptive error alert and raise `FORM_TRIGGER_FAILURE` to prevent any dependent logic from executing with a null or invalid path.
- BR-006 - Any property-level error returned by the WebUtil bean must immediately abort form processing via `FORM_TRIGGER_FAILURE`; no partial or default result may be returned to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-030 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a client-side text file for reading, writing, or appending on behalf of the calling Oracle Forms session. The function validates the supplied file specification and access mode, communicates the open request to the WebUtil Java bean layer via WEBUTIL.GETPROPERTY (SP-040), and returns a file handle that the caller uses for subsequent file I/O operations.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the file mode: confirm that the supplied `filemode` parameter (case-insensitive) is one of the three permitted values: 'r' (read), 'w' (write), or 'a' (append). Raise TOOL_ERR.TOOL_ERROR immediately if the value is outside this set.
- Step 2 - Validate the file specification: confirm that `spec` is neither NULL nor an empty string. Raise TOOL_ERR.TOOL_ERROR if no file name has been provided.
- Step 3 - Transmit the file name to the WebUtil bean layer by calling WebUtil_Core.setProperty with property key 'WUF_FILENAME' and the value of `spec`.
- Step 4 - Transmit the file mode to the WebUtil bean layer by calling WebUtil_Core.setProperty with property key 'WUF_TEXTIO_FILEMODE' and the value of `filemode`.
- Step 5 - Transmit the character set to the WebUtil bean layer by calling WebUtil_Core.setProperty with property key 'WUF_TEXTIO_CHARSET'. If `charSet` is NULL the literal string '(null)' is passed; otherwise the supplied charset value is passed.
- Step 6 - Request the file open operation from the WebUtil bean layer by calling WebUtil_Core.getProperty (WEBUTIL.GETPROPERTY, SP-040) with property key 'WUF_TEXTIO_OPEN'. The bean attempts to open the file and returns a Java handle string.
- Step 7 - Validate the returned Java handle: if the handle is NULL, empty, or equals '-1' the file was not successfully opened; raise TOOL_ERR.TOOL_ERROR.
- Step 8 - Convert the valid Java handle string to a numeric value, assign it to the `handle` field of a local `file_type` record, and return that record to the caller.
- Step 9 - Handle exceptions: if the WebUtil bean is not registered, surface a descriptive error alert (via WebUtil_Core.ErrorAlert and WebUtil_Core.getImplClass) and re-raise TOOL_ERR.TOOL_ERROR. Propagate PROPERTY_ERROR, VALUE_ERROR (as TOOL_ERR.TOOL_ERROR), and TOOL_ERR.TOOL_ERROR directly to the caller.

---
**Decision Points**

DP-001

Condition:
Is the supplied `filemode` (converted to lower case) one of 'r', 'w', or 'a'?

TRUE:
Processing continues to the file specification validation step.

FALSE:
TOOL_ERR.TOOL_ERROR is raised immediately; the function does not proceed.

---

DP-002

Condition:
Is `spec` NULL or an empty string?

TRUE:
TOOL_ERR.TOOL_ERROR is raised; no attempt is made to open a file.

FALSE:
Processing continues; the file name is transmitted to the WebUtil bean layer.

---

DP-003

Condition:
Is the `charSet` parameter NULL?

TRUE:
The literal string '(null)' is passed as the WUF_TEXTIO_CHARSET property value to the WebUtil bean layer.

FALSE:
The actual value of `charSet` is passed as the WUF_TEXTIO_CHARSET property value.

---

DP-004

Condition:
Is the Java handle returned by WebUtil_Core.getProperty NULL, empty, or equal to '-1'?

TRUE:
The file was not opened; TOOL_ERR.TOOL_ERROR is raised and NULL is returned.

FALSE:
The handle is valid; it is converted to a number, stored in the file_type record, and returned to the caller.

---

DP-005

Condition:
Does the EXCEPTION block catch BEAN_NOT_REGISTERED?

TRUE:
An error alert is displayed (identifying the missing bean class) and TOOL_ERR.TOOL_ERROR is re-raised.

FALSE:
Other exception handlers (PROPERTY_ERROR, VALUE_ERROR, TOOL_ERR.TOOL_ERROR) apply as appropriate.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file access mode must be exactly one of 'r' (read), 'w' (write), or 'a' (append); any other value is rejected before any file system interaction occurs.
- BR-002 - A non-null, non-empty file path specification is mandatory; the function will not attempt to open a file without a valid file name.
- BR-003 - When no character set is explicitly supplied by the caller, the WebUtil bean layer is instructed to use a null charset by passing the sentinel string '(null)', ensuring the property is always explicitly set.
- BR-004 - A Java handle of NULL, empty string, or '-1' is treated as a failed open attempt; the function raises an error rather than returning an unusable file handle.
- BR-005 - The Java handle returned by the bean layer must be convertible to a NUMBER; a VALUE_ERROR during conversion is surfaced as TOOL_ERR.TOOL_ERROR to maintain a consistent error contract with the caller.
- BR-006 - If the required WebUtil bean is not registered in the Forms runtime environment, the function must surface a human-readable alert identifying the missing bean class before raising TOOL_ERR.TOOL_ERROR, ensuring the failure is diagnosable by support staff.
- BR-007 - PROPERTY_ERROR exceptions propagate unmodified to the caller, preserving the original error context from the WebUtil bean layer.

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-031 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given numeric key. The function provides a lookup mechanism into the internal callbacks collection, allowing callers such as WEBUTIL.SETDATA to resolve which trigger name corresponds to a specific callback key.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the integer callback key (callbackKey) supplied by the calling routine.
- Step 2 - Use callbackKey as an index into the package-level collection m_callbacks.
- Step 3 - Return the VARCHAR2 trigger name stored at that index position to the caller.

---
**Decision Points**

No conditional decision points exist in this function. The implementation performs a direct collection lookup and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no default or fallback value is applied if the key is absent, meaning an invalid key will raise a collection-level exception.
- BR-002 - The function is read-only with respect to the m_callbacks collection; it does not modify, add, or remove any entries during execution.
- BR-003 - The return value is the VARCHAR2 trigger name exactly as it was stored in m_callbacks, with no transformation or formatting applied.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-032 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the pre-resolved client operating-system family identifier stored in the package-level variable `m_clientOSFamily`. This allows calling code (invoked via WEBUTIL.GETVAR) to retrieve the OS family classification of the client machine without re-evaluating or re-detecting it at the point of call.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - The function is invoked by WEBUTIL.GETVAR, which requires the client OS family value.
- Step 2 - The function reads the package-level variable `m_clientOSFamily`, which holds the previously determined OS family identifier as a PLS_INTEGER.
- Step 3 - The function returns the value of `m_clientOSFamily` directly to the caller with no transformation or additional processing.

---
**Decision Points**

No decision points are present. The function contains a single unconditional RETURN statement that passes back the value of `m_clientOSFamily`.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The client OS family value must have been set in `m_clientOSFamily` prior to this function being called; the function performs no detection or defaulting logic of its own and will return whatever value (including NULL or an uninitialised default) is currently held in that package-level variable.
- BR-002 - The return type is PLS_INTEGER, meaning the OS family is represented as a numeric identifier; callers are responsible for interpreting the integer value against the applicable OS family enumeration defined elsewhere in the WEBUTIL package.

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-033 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set and then read the property value from the local client environment, returning the result to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client settings required for WebUtil initialisation and bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input parameter propertyName (VARCHAR2).
- Step 2 - Evaluate whether propertyName is non-null; if null, skip property retrieval and return a null result.
- Step 3 - Invoke WebUtil_Core.setProperty, targeting the WUC_PACKAGE component with the key WUC_GET_LOCAL_PROPERTY and the supplied propertyName value, to request the client-side property lookup.
- Step 4 - Invoke WebUtil_Core.getProperty with the same component and key to retrieve the value returned by the client.
- Step 5 - Store the retrieved value in the local variable result.
- Step 6 - Return result to the caller.
- Step 7 - If the WebUtil Core bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 8 - If a property error occurs (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Proceed to call WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client-side setting, then return the result.

FALSE: Skip the property retrieval block entirely and return a null value to the caller.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property access

TRUE: Display an error alert identifying the unregistered WebUtil Core implementation class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No exception of this type; normal processing continues.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during property access

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger (no alert is displayed).

FALSE: No exception of this type; normal processing continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger a client-side property lookup; the function returns null immediately when propertyName is null.
- BR-002 - The client property is retrieved using a two-step set-then-get interaction with WebUtil_Core, targeting the WUC_PACKAGE component and the WUC_GET_LOCAL_PROPERTY key; no direct database access is performed.
- BR-003 - If the WebUtil Core bean is not registered at the time of invocation, the function must surface a descriptive error alert (including the implementation class name) and terminate the form trigger via FORM_TRIGGER_FAILURE, preventing silent failure.
- BR-004 - If a property error occurs, the function must terminate the form trigger via FORM_TRIGGER_FAILURE without displaying an additional alert, ensuring consistent error propagation to the calling trigger.
- BR-005 - The return value is constrained to a maximum length of 255 characters, as defined by the result variable declaration.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-034 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the fully qualified Java implementation class name for a given WebUtil package by concatenating the standard WebUtil Java root prefix with the registered implementation class suffix for the specified package identifier.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the package identifier (packageID) as an integer input parameter.
- Step 2 - Retrieve the implementation class suffix associated with packageID from the internal collection m_implClasses.
- Step 3 - Concatenate the constant WEBUTIL_JAVA_ROOT with the retrieved class suffix to form the fully qualified Java class name.
- Step 4 - Return the concatenated string to the caller (WEBUTIL.FCLOSE).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single unconditional concatenation and return.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fully qualified Java implementation class name is always composed by prefixing the value stored in m_implClasses for the given packageID with the WEBUTIL_JAVA_ROOT constant; neither component may be substituted independently at call time.
- BR-002 - The packageID supplied by the caller must correspond to a valid index in the m_implClasses collection; no bounds or null validation is performed within this function, so the caller is responsible for passing a valid package identifier.

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-035 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. This function is called during server-side file transfer operations (specifically within WEBUTIL.SETDATA) to determine whether a preceding file-read action completed successfully or encountered an error, enabling the caller to take appropriate corrective action.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the AppServerFileReader Java object instance (obj) as the target on which the error state will be queried.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method invocation.
- Step 3 - Invoke the Java method getLastError() on the supplied AppServerFileReader object via JNI.CALL_INT_METHOD, targeting the class oracle/forms/webutil/fileTransfer/AppServerFileReader with method signature ()I (no arguments, integer return).
- Step 4 - Return the integer error code obtained from the Java method to the caller (WEBUTIL.SETDATA), which uses it to assess the outcome of the most recent file operation.

---
**Decision Points**

No decision points are present in this function. The implementation unconditionally clears the argument list, invokes the Java method, and returns the resulting integer error code to the caller without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always reset the JNI argument list to NULL before invoking the Java method to prevent argument contamination from prior JNI calls.
- BR-002 - The error code is retrieved exclusively from the AppServerFileReader Java object instance passed by the caller; no alternative or default error source is consulted.
- BR-003 - The function returns a numeric error code only; interpretation of the code value and any resulting business action are the sole responsibility of the invoking routine (WEBUTIL.SETDATA).

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-036 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates directly to the underlying JNI layer to invoke the Java method getLastErrorArgs on the supplied Java object, returning the error argument details as a VARCHAR2 string for use by the calling routine WEBUTIL.SETDATA.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an active AppServerFileReader instance passed in by the caller.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java instance method getLastErrorArgs on the AppServerFileReader class via JNI.CALL_STRING_METHOD, passing FALSE (non-static call), the target object, the fully qualified class path, the method name, and the method signature '()Ljava/lang/String;' with the cleared args list.
- Step 4 - Return the VARCHAR2 string result produced by the JNI call to the caller, which contains the error argument details from the last error recorded by the AppServerFileReader instance.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a single, unconditional JNI method invocation and returns the result directly.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be explicitly set to NULL before each JNI invocation to prevent stale argument data from contaminating the method call.
- BR-002 - The function must target the non-static (instance-level) Java method getLastErrorArgs on the oracle/forms/webutil/fileTransfer/AppServerFileReader class; the JNI call flag is set to FALSE to enforce instance-method dispatch.
- BR-003 - The method signature used in the JNI call must be '()Ljava/lang/String;', confirming the method accepts no arguments and returns a Java String, which is mapped to VARCHAR2 for the PL/SQL caller.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-037 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited field from a source string at a specified positional index and returns its value as a NUMBER. The function delegates string extraction to WEBUTIL.GETSTRING and applies a numeric conversion to the result, providing callers with a type-safe numeric token from a delimited string without requiring them to perform the conversion themselves.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-041](#SP-041--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the 1-based field position, an optional Boolean flag indicating whether the final field in the string is unterminated, and an optional delimiter character (defaulting to a comma).
- Step 2 - Pass all four arguments directly to WEBUTIL.GETSTRING (SP-041), which locates and returns the raw VARCHAR2 token at the requested position within the delimited source string.
- Step 3 - Apply Oracle's TO_NUMBER conversion to the VARCHAR2 token returned by WEBUTIL.GETSTRING.
- Step 4 - Return the resulting NUMBER value to the caller.

---
**Decision Points**

No conditional decision points exist within this function. All branching logic related to field extraction and delimiter handling is fully delegated to WEBUTIL.GETSTRING (SP-041). The function unconditionally converts the returned string token to a number and returns it.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The field position must correspond to a valid numeric token within the source string; if WEBUTIL.GETSTRING returns a non-numeric string, Oracle's TO_NUMBER will raise a VALUE_ERROR, and the caller is responsible for handling that exception.
- BR-002 - The Delimiter parameter defaults to a comma (',') if not supplied by the caller; callers using a non-standard delimiter must explicitly pass the correct character.
- BR-003 - The UnTerminated flag defaults to FALSE; callers must set it to TRUE only when the final field in the source string is not followed by a closing delimiter.
- BR-004 - The function produces no output parameters and no database interactions; its sole output is the NUMBER return value derived from the delegated string extraction.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-038 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family from a supplied OS name string. The function maps the raw OS name to a predefined platform constant (Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown) and stores the result in the module-level variable m_clientOSFamily so that subsequent calls within the same session return the cached value without re-evaluating the string. It is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required for bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to the constant CLIENT_PLATFORM_UNKNOWN as the default platform value.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is null; if it is not null, skip all evaluation steps and proceed directly to Step 10, returning the already-cached value.
- Step 4 - If the cache is null, evaluate whether l_osName contains the substring 'windows'; if true, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If Step 4 is false, evaluate whether l_osName contains 'mac'; if true, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If Step 5 is false, evaluate whether l_osName contains 'linux'; if true, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If Step 6 is false, evaluate whether l_osName contains 'solaris' or 'sunos'; if true, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If Step 7 is false, evaluate whether l_osName contains 'hp-ux'; if true, set result to CLIENT_PLATFORM_HP.
- Step 9 - If Step 8 is false, evaluate whether l_osName contains 'aix'; if true, set result to CLIENT_PLATFORM_AIX; otherwise result remains CLIENT_PLATFORM_UNKNOWN.
- Step 10 - Assign the resolved result value to the module-level variable m_clientOSFamily, persisting it as the session cache.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL (cache has not yet been populated for this session).

TRUE: Proceed to evaluate the OS name string against all known platform substrings (Steps 4-9) and populate the cache.

FALSE: Skip all string evaluation; return the existing cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'.

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next platform check (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'.

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next platform check (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'.

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next platform check (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR 'sunos'.

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next platform check (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'.

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next platform check (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'.

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no recognised platform was matched.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison must be case-insensitive; the input string is converted to lowercase before any substring matching is performed.
- BR-002 - Platform identification follows a strict precedence order: Windows is evaluated first, followed by Mac, Linux, Solaris/SunOS, HP-UX, and AIX; the first matching condition wins and subsequent checks are skipped.
- BR-003 - If the OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN; no error is raised for unrecognised platforms.
- BR-004 - The resolved platform value is cached in the module-level variable m_clientOSFamily after the first evaluation; once cached, the function returns the stored value on all subsequent calls without re-evaluating the OS name string, ensuring consistency within the session.
- BR-005 - Sun Solaris is identified by either the substring 'solaris' or 'sunos', treating both OS name variants as equivalent for platform classification purposes.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-039 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves all lines of output associated with a previously launched host process by iterating over the WebUtil core property interface. The function accumulates each output line into an array and returns the complete OUTPUT_ARRAY to the caller (WEBUTIL.GET_STANDARD_OUTPUT). Package initialisation is enforced at the package body level by invoking WEBUTIL.INIT (SP-048) via Webutil_Core.Init.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-048](#SP-048--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Set the process handle on the WebUtil core package by calling WebUtil_Core.setProperty with the WUH_PACKAGE constant, the property key 'WUH_PROC_ID', and the handle value from the supplied PROCESS_ID parameter.
- Step 2 - Enter a loop to retrieve output lines one at a time. On each iteration, call WebUtil_Core.getProperty with the WUH_PACKAGE constant and the supplied prop parameter to obtain a buffered line.
- Step 3 - Extract the first character of the returned buffer as a status indicator ('Y' = more lines to follow, 'N' = this is the last line, 'X' = buffer was empty).
- Step 4 - If the status character is not 'X' (i.e., the buffer contains data), strip the status prefix and store the remaining text as the next element of the OUTPUT_ARRAY, then increment the array index.
- Step 5 - Exit the loop when the status character is not 'Y', meaning no further lines are available.
- Step 6 - Return the populated OUTPUT_ARRAY to the caller.
- Step 7 - If a BEAN_NOT_REGISTERED exception is raised at any point, display an error alert identifying the missing bean class and noting that WEBUTIL_HOST.GetOutput will not function.
- Step 8 (package initialisation) - When the package body is first loaded, Webutil_Core.Init is called unconditionally to ensure the WebUtil core is instantiated before any function executes.

---
**Decision Points**

DP-001

Condition:
The status character extracted from the buffer is not 'X'.

TRUE:
The remainder of the buffer (characters from position 2 onwards) is appended to the OUTPUT_ARRAY at the current index, and the index is incremented.

FALSE:
The buffer is considered empty; no entry is added to the OUTPUT_ARRAY and the index is not incremented.

---

DP-002

Condition:
The status character extracted from the buffer is not 'Y'.

TRUE:
The loop exits; no further output lines are requested from the WebUtil core.

FALSE:
The loop continues and another line is requested from the WebUtil core on the next iteration.

---

DP-003

Condition:
A BEAN_NOT_REGISTERED exception is raised during execution.

TRUE:
An error alert is displayed to the user identifying the unregistered bean class and stating that WEBUTIL_HOST.GetOutput will not work; normal processing is abandoned.

FALSE:
No exception handling is triggered; the function completes normally and returns the OUTPUT_ARRAY.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle must be registered with the WebUtil core before output retrieval begins; the function sets 'WUH_PROC_ID' via WebUtil_Core.setProperty as the first action, ensuring subsequent getProperty calls are scoped to the correct process.
- BR-002 - Each buffer returned by WebUtil_Core.getProperty carries a mandatory single-character status prefix ('Y', 'N', or 'X'); only the substring from position 2 onwards is stored as actual output content.
- BR-003 - A status of 'X' indicates an empty buffer; such lines are silently skipped and must not be added to the output array.
- BR-004 - Iteration continues only while the status is 'Y'; a status of 'N' (last line) or 'X' (empty) terminates the loop, preventing infinite retrieval.
- BR-005 - The WebUtil bean identified by WUH_PACKAGE must be registered on the client at the time of invocation; if it is not, the function raises BEAN_NOT_REGISTERED and no output is returned.
- BR-006 - The WebUtil core must be initialised (via WEBUTIL.INIT / Webutil_Core.Init) before any function in this package is called; this is enforced unconditionally in the package body initialisation block.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-040 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named Java system property at runtime by delegating to the Java Native Interface (JNI) layer. Callers such as WEBUTIL.FOPEN and WEBUTIL.REGISTERBEAN use this function to obtain environment-level configuration values (e.g., file-separator, OS name) that are held in the JVM's system-property map and are not directly accessible from PL/SQL.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the property name (a0) as the single input parameter.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the property-name string to the argument list via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java static method java.lang.System.getProperty(String) through JNI.CALL_STRING_METHOD, passing the prepared argument list.
- Step 5 - Return the string value produced by the JVM to the caller; if the property does not exist the JVM returns NULL and that NULL is propagated to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally builds the argument list, invokes the JNI call, and returns the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property name supplied in parameter a0 must be a valid Java system-property key; an unrecognised key causes the JVM to return NULL, which is silently passed back to the caller.
- BR-002 - The JNI argument list must be initialised with a capacity of exactly 1 before the property-name argument is added; the function does not support multi-argument variants of System.getProperty.
- BR-003 - The function always targets the static Java method java.lang.System.getProperty with the exact signature (Ljava/lang/String;)Ljava/lang/String;; no alternative method or class may be substituted.
- BR-004 - No database reads or writes are performed; all data retrieval is confined to the JVM system-property store, ensuring no transactional side-effects.

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-041 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string at a specified positional index. Given a delimiter-separated string, the function returns the substring occupying the Nth field (Field_position), supporting both pre-terminated and unterminated source strings. It is used internally by WEBUTIL.GETNUMBER to isolate a positional value before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source string, the target field position (1-based), an optional UnTerminated flag (default FALSE), and an optional delimiter (default comma).
- Step 2 - Copy the source string into a local working variable (vcSourceStrCopy) to avoid mutating the input.
- Step 3 - If the UnTerminated flag is TRUE, append the delimiter to the end of the working copy so that the final token is bounded and can be located consistently.
- Step 4 - Determine the start pointer (iPtrStart): if Field_position is greater than 1, locate the delimiter occurrence at position Field_position-1 using INSTR and advance the pointer past the delimiter by adding the length of the delimiter; otherwise set iPtrStart to 1 (beginning of the string).
- Step 5 - Determine the end pointer (iPtrEnd) by locating the Nth occurrence of the delimiter (where N equals Field_position) using INSTR.
- Step 6 - Extract and return the substring from iPtrStart for a length of (iPtrEnd - iPtrStart), which isolates exactly the token at the requested field position.

---
**Decision Points**

DP-001

Condition: UnTerminated = TRUE

TRUE: The delimiter is appended to the working copy of the source string before any parsing begins, ensuring the last token in an unterminated string is bounded by a delimiter and can be located by INSTR.

FALSE: The source string is used as-is; it is assumed to already contain a trailing delimiter or the caller has accounted for the terminal boundary.

---

DP-002

Condition: Field_position > 1

TRUE: iPtrStart is calculated by finding the (Field_position - 1)th delimiter occurrence with INSTR and adding the length of the delimiter, positioning the start pointer immediately after the preceding delimiter.

FALSE: iPtrStart is set to 1, meaning extraction begins at the very start of the string (first token).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The source string must use a consistent, known delimiter throughout; the delimiter character(s) passed at invocation must match those present in the source string, otherwise token boundaries will be resolved incorrectly.
- BR-002 - Field positions are 1-based; a Field_position value of 1 always refers to the first token in the string.
- BR-003 - If the source string is not terminated by the delimiter (i.e., the final field has no trailing delimiter), the caller must pass UnTerminated = TRUE so that the function appends the delimiter and correctly resolves the last token.
- BR-004 - The function returns only the content between the resolved start and end delimiter positions; if the specified field position does not exist within the string, the returned substring will be empty or NULL due to INSTR returning 0.
- BR-005 - The working copy of the source string is limited to 32,000 characters (varchar2(32000)); source strings exceeding this length are not supported.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-042 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named client-side variable (VARNAME) and returns it in VARVALUE. The resolution strategy is platform-aware: on Windows clients the procedure first queries the Oracle registry key under HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE via READ_REGISTRY, then falls back to GET_ENVIRONMENT_STRING if the registry yields no value; on Unix/Linux clients it executes the 'env' command via a blocking host process, captures standard output via WEBUTIL.GET_STANDARD_OUTPUT, and parses the output to locate the matching variable; on macOS and unknown platforms no action is taken. The procedure is invoked by WEBUTIL.REGISTERBEAN to resolve environment or registry configuration values needed during bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-074](#SP-074--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-077](#SP-077--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-032](#SP-032--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-045](#SP-045--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive VARNAME (the variable name to resolve) and the IN OUT parameter VARVALUE.
- Step 2 - Call WEBUTIL.GETCLIENTOSFAMILY (SP-032) to determine the client operating-system platform.
- Step 3 - If the client platform is WIN32, call READ_REGISTRY (SP-077) with the path 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' and VARNAME to attempt retrieval from the Windows registry.
- Step 4 - If the registry call returns NULL or an empty string, call GET_ENVIRONMENT_STRING (SP-074) with VARNAME to retrieve the value from the Windows environment variables instead.
- Step 5 - Assign the resolved value (registry or environment) to VARVALUE and exit the WIN32 branch.
- Step 6 - If the client platform is MAC or UNKNOWN, take no action and leave VARVALUE unchanged.
- Step 7 - For all other platforms (Unix/Linux), execute the shell command 'env' as a blocking host process to capture all environment variables.
- Step 8 - Retrieve the command's standard output array via WEBUTIL.GET_STANDARD_OUTPUT (SP-045) and release the host process handle.
- Step 9 - Iterate over each output line; for each line locate the '=' delimiter using INSTR.
- Step 10 - If a delimiter is found, extract the key (substring before '=') and compare it to VARNAME.
- Step 11 - When a matching key is found, extract the value (substring after '='), assign it to VARVALUE, and exit the loop.
- Step 12 - If a NO_DATA_FOUND exception is raised at any point, set VARVALUE to NULL and return.

---
**Decision Points**

DP-001

Condition:
WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32

TRUE:
Attempt to read VARNAME from the Windows registry via READ_REGISTRY; if that yields no value, fall back to GET_ENVIRONMENT_STRING. Assign the result to VARVALUE.

FALSE:
Proceed to DP-002.

---

DP-002

Condition:
WebUtil_Core.GetClientOSFamily IN (WebUtil_Core.CLIENT_PLATFORM_MAC, WebUtil_Core.CLIENT_PLATFORM_UNKNOWN)

TRUE:
Take no action; VARVALUE remains unchanged.

FALSE:
Treat the platform as Unix/Linux and proceed to the environment-parsing branch (DP-003).

---

DP-003

Condition:
VARVALUE returned by READ_REGISTRY is NULL or empty string (evaluated only within the WIN32 branch)

TRUE:
Call GET_ENVIRONMENT_STRING(VARNAME) and assign the result to VARVALUE.

FALSE:
Use the registry value already assigned to VARVALUE; skip the environment-variable fallback.

---

DP-004

Condition:
A '=' delimiter is found (INSTR result > 0) in the current Unix 'env' output line

TRUE:
Extract the key and compare it to VARNAME; if equal, assign the value portion to VARVALUE and exit the loop.

FALSE:
Skip the current line and continue iterating.

---

DP-005

Condition:
The extracted key from the current Unix output line equals VARNAME

TRUE:
Assign the substring after '=' to VARVALUE and EXIT the loop.

FALSE:
Continue to the next iteration without updating VARVALUE.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Variable resolution is strictly platform-specific; the Windows registry path, Windows environment fallback, Unix environment parsing, and the no-op for macOS/unknown are mutually exclusive branches determined solely by the client OS family reported by WEBUTIL.GETCLIENTOSFAMILY (SP-032).
- BR-002 - On Windows, the Oracle registry hive 'HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE' is always the primary lookup source for a named variable; the environment variable (GET_ENVIRONMENT_STRING, SP-074) is consulted only when the registry returns no value.
- BR-003 - On macOS and platforms of unknown type, GETVAR performs no resolution; VARVALUE is returned in whatever state it was passed in.
- BR-004 - On Unix/Linux platforms, variable resolution is performed by executing the 'env' shell command as a blocking process; the output is retrieved via WEBUTIL.GET_STANDARD_OUTPUT (SP-045) and parsed line by line - no registry or Java API is used.
- BR-005 - During Unix parsing, only lines containing a '=' character are evaluated; lines without a delimiter are silently skipped.
- BR-006 - The first matching Unix environment variable found terminates the search; subsequent duplicate keys (if any) are ignored.
- BR-007 - A NO_DATA_FOUND exception at any stage results in VARVALUE being set to NULL, ensuring the caller always receives a defined (non-exception) return state.

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-043 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a single line of text from an open client-side text file and returns it to the caller. The procedure delegates the actual read operation to the WebUtil PJC (Pluggable Java Component) layer via WebUtil_Core property calls, then interprets the returned buffer to distinguish a normal line of text from an end-of-file condition. It is invoked indirectly through VIEW_EXCEL_REPORT_NEW in dms_excel_report.pld to consume lines from a client-side file during Excel report processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the file handle encapsulated in the IN parameter `file` (of type file_type).
- Step 2 - Pass the file handle to the WebUtil PJC by setting the property `WUF_TEXTIO_HANDLE` on the `WUF_PACKAGE` component via `WebUtil_Core.setProperty`.
- Step 3 - Retrieve the next line of text from the PJC by reading the property `WUF_TEXTIO_GETLINE` via `WebUtil_Core.getProperty`; the result is stored in the local VARCHAR2 buffer (up to 4000 characters).
- Step 4 - Evaluate the buffer content: if the buffer equals `CHR(10)` (a lone newline character), the PJC has signalled end-of-file using its sentinel convention, so raise `NO_DATA_FOUND` to inform the caller that no more lines are available.
- Step 5 - If the buffer does not equal `CHR(10)`, assign the buffer value to the OUT parameter `item` and return normally.
- Step 6 - If the WebUtil bean is not registered (`BEAN_NOT_REGISTERED` exception), display an error alert identifying the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to halt processing.
- Step 7 - If a property read/write error occurs (`PROPERTY_ERROR` exception), raise `TOOL_ERR.TOOL_ERROR` to halt processing.

---
**Decision Points**

DP-001

Condition:
The value returned in `buffer` by `WebUtil_Core.getProperty` equals `CHR(10)` (lone newline character).

TRUE:
The end-of-file sentinel has been detected; raise `NO_DATA_FOUND` to signal the caller that there are no more lines to read.

FALSE:
The buffer contains a valid line of text; assign `buffer` to the OUT parameter `item` and return successfully.

---

DP-002

Condition:
The `BEAN_NOT_REGISTERED` exception is raised during the WebUtil_Core property calls.

TRUE:
Display an error alert naming the unregistered implementation class, then raise `TOOL_ERR.TOOL_ERROR` to abort the calling process.

FALSE:
No bean registration error; continue normal processing.

---

DP-003

Condition:
The `PROPERTY_ERROR` exception is raised during the WebUtil_Core property calls.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` to abort the calling process.

FALSE:
No property error; continue normal processing.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle supplied in the `file` IN parameter must be a valid, previously opened client-side file; the procedure does not open or validate the file itself before delegating to the PJC.
- BR-002 - A lone newline character (`CHR(10)`) returned by the PJC is treated exclusively as the end-of-file sentinel and is never returned as line content to the caller; this is a deliberate PJC convention because `get_line` would not normally return a newline as data.
- BR-003 - The maximum length of a single line that can be read and returned is 4000 characters, as constrained by the local buffer declaration (`VARCHAR2(4000 CHAR)`).
- BR-004 - If the WebUtil bean required to perform the read is not registered on the client, processing must not continue silently; an informational error alert must be raised before propagating `TOOL_ERR.TOOL_ERROR`.
- BR-005 - Any `PROPERTY_ERROR` raised by the WebUtil_Core layer must be escalated immediately as `TOOL_ERR.TOOL_ERROR`; the procedure does not suppress or retry on property errors.

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-044 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the integer return code produced by a previously executed host process. Given a PROCESS_ID handle, the function identifies the target process on the WebUtil bean layer and returns its numeric exit/return code to the caller (WEBUTIL.HOST). This allows the calling logic to inspect whether the host command completed successfully or with an error status.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the PROCESS_ID handle supplied by the caller (WEBUTIL.HOST) identifying the host process whose return code is required.
- Step 2 - Communicate the process handle to the WebUtil bean layer by calling WebUtil_Core.setProperty, setting the WUH_PROC_ID property on the WUH_PACKAGE component to the value of process.handle.
- Step 3 - Retrieve the return code string from the WebUtil bean layer by calling WebUtil_Core.getProperty for the WUH_RC property on the WUH_PACKAGE component.
- Step 4 - Convert the retrieved string value to a PLS_INTEGER using TO_NUMBER and return it to the caller.
- Step 5 - If the WebUtil bean is not registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and the function that failed, then exit without returning a value.

---
**Decision Points**

DP-001

Condition:
Does the WebUtil bean identified by WebUtil_Core.WUH_PACKAGE exist and respond to property calls during execution?

TRUE:
The process handle is set via setProperty, the return code is retrieved via getProperty, converted to PLS_INTEGER, and returned to the caller.

FALSE:
The BEAN_NOT_REGISTERED exception is raised; an error alert is displayed combining the implementation class name (from WebUtil_Core.getImplClass) with a message stating that WEBUTIL_HOST.Get_Return_Code will not work, and the function terminates without returning a value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function requires a valid PROCESS_ID whose handle attribute can be resolved by the WebUtil bean layer; no return code can be obtained without a registered bean.
- BR-002 - The process handle must be communicated to the bean layer via WebUtil_Core.setProperty before the return code property (WUH_RC) is read, ensuring the bean targets the correct process.
- BR-003 - The return code stored on the bean layer is held as a string property (WUH_RC) and must be converted to a PLS_INTEGER before being surfaced to the caller; non-numeric values will cause a conversion error.
- BR-004 - If the WebUtil bean is not registered, the function must not silently fail; it must display a descriptive error alert that identifies the missing bean class and the affected function (WEBUTIL_HOST.Get_Return_Code) to support diagnostics.

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-045 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output (stdout) stream collected from a previously executed host process. The function acts as a named convenience wrapper that delegates to WEBUTIL.GETOUTPUT (SP-039), passing the fixed stream identifier 'WUH_STDOUT' so that callers do not need to know the internal stream name.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-039](#SP-039--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the process identifier (`process`) that references a previously executed host process whose output is to be retrieved.
- Step 2 - Invoke WEBUTIL.GETOUTPUT (SP-039) with the supplied `process` identifier and the hard-coded stream label `'WUH_STDOUT'` to obtain the standard output lines captured for that process.
- Step 3 - Return the resulting OUTPUT_ARRAY directly to the caller (WEBUTIL.GETVAR) without further transformation.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: delegate to WEBUTIL.GETOUTPUT with the fixed stream identifier and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The stream identifier used to retrieve standard output is always `'WUH_STDOUT'`; callers must not supply or override this value.
- BR-002 - The function returns an OUTPUT_ARRAY; if the referenced process produced no standard output, the content of that array is determined entirely by the behaviour of WEBUTIL.GETOUTPUT (SP-039).
- BR-003 - A valid PROCESS_ID must be supplied; the function performs no independent validation of the process identifier before passing it to WEBUTIL.GETOUTPUT.

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-046 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a host operating-system command synchronously on the client machine and returns the process exit code to the caller. The function delegates command execution to WEBUTIL.BLOCKING, waits for completion, retrieves the numeric return code via WEBUTIL.GET_RETURN_CODE, and releases the client-side process handle via WEBUTIL.RELEASE_PROCESS. It is used by the Excel report generation logic in dms_excel_report.pld to launch OS-level commands (e.g., opening or processing an Excel file) from within Oracle Forms.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-017](#SP-017--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-044](#SP-044--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-061](#SP-061--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the OS command string (cmd) as input and initialise the return code (RC) to -1, representing an unexecuted or failed state.
- Step 2 - Invoke WEBUTIL.BLOCKING (SP-017) with the command string to execute the command synchronously on the client; the call blocks until the host process completes and returns a process identifier (procId).
- Step 3 - Evaluate whether a valid process identifier was obtained by calling WEBUTIL.ID_NULL (SP-047) on procId.
- Step 4 - If the process identifier is valid (not null), call WEBUTIL.GET_RETURN_CODE (SP-044) with procId to retrieve the integer exit code returned by the host process, and assign it to RC.
- Step 5 - Release the client-side process object by calling WEBUTIL.RELEASE_PROCESS (SP-061) with procId, freeing any associated client resources.
- Step 6 - Return RC to the caller; a value of -1 indicates the process was never successfully launched, while any other value reflects the actual OS process exit code.

---
**Decision Points**

DP-001

Condition:
WEBUTIL.ID_NULL(procId) evaluates to FALSE (i.e., WEBUTIL.BLOCKING returned a valid, non-null process identifier).

TRUE:
The process launched successfully; WEBUTIL.GET_RETURN_CODE is called to capture the exit code, WEBUTIL.RELEASE_PROCESS is called to free the client-side handle, and the retrieved exit code is returned to the caller.

FALSE:
The process did not launch or returned a null identifier; neither GET_RETURN_CODE nor RELEASE_PROCESS is called, and the default return code of -1 is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must execute the host command synchronously; asynchronous execution is not permitted. WEBUTIL.BLOCKING is used exclusively to enforce this constraint.
- BR-002 - A default return code of -1 is reserved to signal that the host process was not successfully initiated; callers must treat -1 as an execution failure rather than a valid process exit code.
- BR-003 - Client-side process resources must always be released after a successful launch; WEBUTIL.RELEASE_PROCESS must be called whenever a valid process identifier is obtained, regardless of the exit code value.
- BR-004 - The exit code is only meaningful and retrievable when a valid process identifier exists; WEBUTIL.GET_RETURN_CODE must not be called if WEBUTIL.ID_NULL indicates the identifier is null.

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-047 - WEBUTIL.ID_NULL

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [StoredProcedure: L_POP_LIST_ITEM]
- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given handle object is uninitialised (null) by inspecting its internal `hnd` attribute. This utility function is used across multiple WebUtil and reporting routines to guard against operations on invalid or unresolved handles before proceeding with host calls, bean registration, alert display, and list population.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the `handle` pointer passed in by the calling routine.
- Step 2 - Inspect the `hnd` attribute of the supplied handle object.
- Step 3 - If `hnd` is NULL, return TRUE to signal that the handle is uninitialised.
- Step 4 - If `hnd` is NOT NULL, return FALSE to signal that the handle holds a valid reference.

---
**Decision Points**

DP-001

Condition:
The `hnd` attribute of the input `handle` pointer is NULL.

TRUE:
Return TRUE, indicating the handle is null/uninitialised and the caller should treat it as an invalid reference.

FALSE:
Return FALSE, indicating the handle contains a valid reference and the caller may safely proceed with handle-dependent operations.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A handle is considered null solely on the basis of its internal `hnd` attribute being NULL; no other attribute or external state is evaluated.
- BR-002 - The function is read-only and produces no side effects; it neither modifies the handle nor interacts with any database object.
- BR-003 - Callers must treat a TRUE return value as a signal to abort or skip any operation that requires a valid handle, preventing runtime errors in host calls, bean registration, alert display, and list-item population.

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-048 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.INIT is a lightweight package-level initialisation procedure for the WebUtil core library. Its sole responsibility is to trigger the package initialisation block, which in turn calls WEBUTIL.INITWEBUTIL (SP-049) to set up the WebUtil runtime environment. The procedure body itself performs no discrete work; entering the package is sufficient to invoke the initialisation sequence.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-049](#SP-049--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - The procedure is invoked by WEBUTIL.GETOUTPUT as part of the WebUtil initialisation sequence.
- Step 2 - The procedure body executes a null statement, performing no explicit processing; this is intentional by design.
- Step 3 - Control passes to the package initialisation block (BEGIN...END WEBUTIL_CORE), which calls WEBUTIL.INITWEBUTIL (SP-049) to perform the actual WebUtil environment setup.
- Step 4 - Once WEBUTIL.INITWEBUTIL completes, the package is fully initialised and control returns to the caller.

---
**Decision Points**

No decision points are present. The procedure body contains only a null statement and unconditionally delegates all initialisation work to the package-level BEGIN block via WEBUTIL.INITWEBUTIL (SP-049).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Entering the WEBUTIL_CORE package is sufficient to trigger initialisation; no explicit procedural logic is required inside INIT, and the body must remain a no-op (null statement) by design.
- BR-002 - The WebUtil environment must be initialised via WEBUTIL.INITWEBUTIL (SP-049) exactly once at package load time through the package initialisation block; INIT itself must not duplicate that call.
- BR-003 - WEBUTIL.INIT accepts no input parameters and produces no output parameters; it is a side-effect-only entry point whose value lies entirely in causing the package initialisation block to execute.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-049 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil runtime environment when the form starts. The procedure registers the Java implementation class names for each WebUtil sub-package, verifies that the mandatory WEBUTIL object group (error alert and dummy item) is present in the calling form, optionally navigates to the WebUtil bean area to force bean instantiation, and determines the server-side file-path separator based on the host operating system. It is called once by WEBUTIL.INIT during form startup.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-065](#SP-065--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Capture the current cursor field (SYSTEM.CURSOR_FIELD) and locate the WebUtil dummy item (WEBUTIL_DUMMY_ITEM) for later navigation use.
- Step 2 - Populate the m_implClasses associative array with the fully-qualified Java class names for all known WebUtil sub-packages (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
- Step 3 - Call ID_NULL (SP-047) to test whether the WebUtil error alert object (m_errorAlert) exists in the form.
- Step 4 - If the error alert is absent, display a message informing the developer that the WEBUTIL object group is missing and that WebUtil cannot operate, then pause execution; no further initialisation is performed.
- Step 5 - If the error alert is present and the FLAG_EXPICIT_INSTANCIATE flag is TRUE and the form is in NORMAL mode, proceed with explicit bean instantiation.
- Step 6 - Within explicit instantiation, call ID_NULL (SP-047) to confirm the dummy item exists; if it does, navigate to it with GO_ITEM to trigger bean drawing.
- Step 7 - Compare the block of the original cursor position with the block of the dummy item; if they are the same block, call NEXT_BLOCK to return focus to a different block, otherwise navigate back to the original item with GO_ITEM.
- Step 8 - Call SHOWBEANS (SP-065) with the parameter FALSE to render the bean areas without forcing visibility.
- Step 9 - If the dummy item does not exist, take no action, assuming the developer is managing bean setup independently.
- Step 10 - After the navigation/bean block, inspect the server operating system via GET_APPLICATION_PROPERTY(OPERATING_SYSTEM); if the value contains 'WIN' (case-insensitive), set the server file separator m_serverFileSep to backslash, otherwise set it to forward slash.

---
**Decision Points**

DP-001

Condition:
ID_NULL(m_errorAlert) is TRUE - the WebUtil error alert object is not found in the form.

TRUE:
Display a message stating the WEBUTIL object group is unavailable and WebUtil cannot work, then pause. No further initialisation steps are executed.

FALSE:
Continue with bean instantiation and server OS detection.

---

DP-002

Condition:
FLAG_EXPICIT_INSTANCIATE is TRUE AND SYSTEM.MODE equals 'NORMAL'.

TRUE:
Proceed with explicit navigation to the dummy item to force bean instantiation.

FALSE:
Skip explicit bean instantiation entirely; proceed directly to server OS detection.

---

DP-003

Condition:
ID_NULL(hDummy) is FALSE - the WebUtil dummy item exists in the form.

TRUE:
Navigate to the dummy item, resolve block positioning, and call SHOWBEANS(false).

FALSE:
Take no action; the developer is assumed to be managing bean area setup independently.

---

DP-004

Condition:
The block of the original cursor item equals the block of the dummy item (GET_ITEM_PROPERTY comparison).

TRUE:
Call NEXT_BLOCK to move focus out of the shared block after bean navigation.

FALSE:
Call GO_ITEM(startPoint) to return focus directly to the original cursor position.

---

DP-005

Condition:
The server operating system string (GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)) contains 'WIN' (case-insensitive).

TRUE:
Set m_serverFileSep to backslash ('\') for Windows-style file paths.

FALSE:
Set m_serverFileSep to forward slash ('/') for Unix/Linux-style file paths.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WEBUTIL object group, including its error alert object, must be present in the calling form; if it is absent, WebUtil initialisation is aborted and the form is notified via a message and pause.
- BR-002 - Explicit bean instantiation via navigation is only performed when FLAG_EXPICIT_INSTANCIATE is TRUE and the form is in NORMAL mode; Enter-Query mode is explicitly excluded to avoid navigation conflicts (per Bug 2955789).
- BR-003 - If the dummy item is not found in the form, the procedure assumes the developer has implemented a custom bean setup and performs no navigation or bean rendering.
- BR-004 - When navigating away from the dummy item after bean instantiation, the procedure must return focus to the original cursor position unless the original position shares the same block as the dummy item, in which case NEXT_BLOCK is used to avoid remaining in the WebUtil block.
- BR-005 - SHOWBEANS (SP-065) must be called with FALSE after dummy-item navigation to render bean areas without forcing them visible unconditionally.
- BR-006 - The server file-path separator (m_serverFileSep) is determined once at initialisation time based on the server OS and stored for use by other WebUtil routines; Windows environments use backslash, all others use forward slash.

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-050 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a lightweight Boolean indicator that reports whether the most recent WebUtil operation resulted in an error. Callers (such as WEBUTIL.LOG) use this function to determine whether an error condition is currently active before taking further action.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Read the module-level variable `m_lastError`, which holds the error code set by the most recent WebUtil operation.
- Step 2 - Evaluate whether `m_lastError` is non-zero.
- Step 3 - Return TRUE if `m_lastError` is not equal to zero, indicating an error is present; return FALSE if `m_lastError` equals zero, indicating no error.

---
**Decision Points**

DP-001

Condition:
`m_lastError <> 0`

TRUE:
The function returns TRUE, signalling to the caller that the last WebUtil operation produced an error.

FALSE:
The function returns FALSE, signalling to the caller that no error was recorded by the last WebUtil operation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The sole source of truth for error state is the module-level variable `m_lastError`; no input parameters are accepted, and no database or external lookups are performed.
- BR-002 - Any non-zero value of `m_lastError` is treated as an error condition regardless of sign or magnitude; only an exact value of zero is considered error-free.
- BR-003 - This function is read-only with respect to `m_lastError`; it reports state but does not reset or modify it.

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-051 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines whether a given file handle is currently open by inspecting the handle attribute of the supplied file_type record. Returns TRUE if the file is open and FALSE if it is not, allowing callers such as WEBUTIL.LOG to guard against operations on unopened files.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the file_type record passed by the caller as an IN parameter.
- Step 2 - Inspect the handle attribute of the supplied file_type record.
- Step 3 - If the handle is NULL, return FALSE to indicate the file is not open.
- Step 4 - If the handle is not NULL, return TRUE to indicate the file is open.

---
**Decision Points**

DP-001

Condition:
file.handle IS NULL

TRUE:
The function returns FALSE, signalling to the caller that no open file handle exists for the supplied file_type record.

FALSE:
The function returns TRUE, signalling to the caller that a valid open file handle exists for the supplied file_type record.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file_type record is considered closed (not open) if and only if its handle attribute is NULL; any non-NULL handle value is treated as evidence of an open file.
- BR-002 - The function is read-only with respect to the file_type record; it does not modify the handle or any other attribute of the supplied parameter.
- BR-003 - No database interactions or external dependencies are involved; the open/closed determination is made solely from the in-memory state of the file_type record.

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-052 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the byte length of a file represented by a Java File object. It delegates directly to the Java Native Interface (JNI) to invoke the standard java.io.File.length() method, providing Oracle Forms PL/SQL code with a reliable way to determine a file's size on the host file system without database interaction.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java File object reference (obj) passed in by the calling routine.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are forwarded to the Java method.
- Step 3 - Invoke the Java method java/io/File.length() via JNI.CALL_LONG_METHOD, passing the target object reference, the fully qualified class name, the method name, and the method signature '()J' (no parameters, returns a long integer).
- Step 4 - Return the numeric result (file size in bytes) to the calling routine.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: clear arguments, call the Java method, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be explicitly reset to NULL before invoking the JNI method to prevent unintended parameter passing from a prior call.
- BR-002 - The file size is retrieved directly from the host file system via the Java io.File.length() method; no database query or PL/SQL computation is performed.
- BR-003 - The function returns a NUMBER value representing the file size in bytes, consistent with the long integer (J) return type declared in the JNI method signature '()J'.
- BR-004 - The caller is responsible for supplying a valid ORA_JAVA.JOBJECT reference to an existing java.io.File instance; this function performs no null-check or validation on the input object.

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-053 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic or error message to the server-side WebUtil log file. On first invocation it initialises the logging configuration cache by reading three property-bundle settings (enabled flag, errors-only flag, and log file path), propagates the resolved logging mode to the registered WebUtil bean via a client property, and then appends the supplied message - optionally prefixed with the client IP address and username - to the log file in append mode. If the log file is unavailable or misconfigured, the procedure disables logging and raises an appropriate alert or bean-level error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-050](#SP-050--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-051](#SP-051--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-056](#SP-056--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Check whether the logging configuration cache has been initialised (m_loggingAllowed IS NULL). If not yet initialised, proceed to Steps 2-7; otherwise skip to Step 8.
- Step 2 - Call WEBUTIL.READFROMPROPERTYBUNDLE to read 'logging.enabled', 'logging.errorsonly', and 'logging.file', and store the results in the module-level cache variables m_loggingAllowed, m_loggingErrorsOnly, and m_loggingFile respectively.
- Step 3 - If logging is allowed but no log file path was returned, set m_loggingAllowed to FALSE to disable logging. If no bean is registered yet, call WEBUTIL.ERRORALERT to display error WUC-008 in English; otherwise notify the bean by setting the WUC_SRV_LOGGING client property to '0' and raise error 8 via WebUtil_Core.
- Step 4 - If at least one bean is registered, propagate the resolved logging mode to the bean: set WUC_SRV_LOGGING to '1' (errors-only), '2' (all messages), or '0' (disabled) depending on the cached flags.
- Step 5 - After cache initialisation, evaluate whether logging is currently allowed (m_loggingAllowed = TRUE).
- Step 6 - If logging is allowed, evaluate whether the current message should be written: write if errors-only mode is off, or if errors-only mode is on and isError is TRUE.
- Step 7 - Open the log file in append mode using TEXT_IO.FOPEN. Call WEBUTIL.IS_OPEN to confirm the file handle is valid; if not, raise NO_DATA_FOUND.
- Step 8 - Write the message to the log file using WEBUTIL.PUT_LINE. If m_clientIP is populated, prefix the message with the client IP address and username; otherwise write the message as-is.
- Step 9 - Close the log file with TEXT_IO.FCLOSE.
- Step 10 - In the EXCEPTION handler, if SQLCODE = -302000 (file write failure), disable logging (m_loggingAllowed := FALSE) and report error WUC-007 via WEBUTIL.ERRORALERT (no bean registered) or via the bean property and WebUtil_Core.error (bean registered). For any other exception, re-raise.

---
**Decision Points**

DP-001

Condition:
m_loggingAllowed IS NULL (logging configuration cache not yet initialised)

TRUE:
Read the three logging properties from the property bundle via WEBUTIL.READFROMPROPERTYBUNDLE and populate the cache; then proceed through Steps 3-4 to validate configuration and notify the bean.

FALSE:
Skip initialisation and proceed directly to the logging eligibility check.

---

DP-002

Condition:
m_loggingAllowed is TRUE but m_loggingFile IS NULL (logging enabled with no file path)

TRUE:
Set m_loggingAllowed to FALSE. If no bean is registered, call WEBUTIL.ERRORALERT with WUC-008; otherwise set WUC_SRV_LOGGING to '0' on the bean and raise WebUtil_Core error 8.

FALSE:
Logging file path is present; continue with bean notification.

---

DP-003

Condition:
m_registeredPackages.FIRST IS NOT NULL (at least one bean is registered) during cache initialisation

TRUE:
Set the WUC_SRV_LOGGING client property on the bean to '1' (errors-only), '2' (all), or '0' (disabled) according to the cached flags.

FALSE:
Skip bean property notification; bean is not yet available.

---

DP-004

Condition:
m_loggingAllowed is TRUE at the point of writing

TRUE:
Evaluate the errors-only filter (DP-005) and attempt to write the message.

FALSE:
Skip all file I/O; procedure exits without writing.

---

DP-005

Condition:
m_loggingErrorsOnly is FALSE, OR (m_loggingErrorsOnly is TRUE AND isError is TRUE)

TRUE:
Open the log file in append mode and write the message.

FALSE:
Message is suppressed because errors-only mode is active and the message is not an error.

---

DP-006

Condition:
m_clientIP IS NULL

TRUE:
Write the bare message text to the log file via WEBUTIL.PUT_LINE.

FALSE:
Prefix the message with m_clientIP and m_clientUserName before writing via WEBUTIL.PUT_LINE.

---

DP-007

Condition:
Exception raised with SQLCODE = -302000 (file write failure)

TRUE:
Disable logging (m_loggingAllowed := FALSE). If no bean is registered, call WEBUTIL.ERRORALERT with WUC-007; otherwise set WUC_SRV_LOGGING to '0' on the bean and raise WebUtil_Core error 7.

FALSE:
Re-raise the exception to the caller.

---

DP-008

Condition:
TEXT_IO.IS_OPEN returns FALSE after FOPEN (file handle invalid)

TRUE:
Raise NO_DATA_FOUND, which is caught by the EXCEPTION handler.

FALSE:
File is open; proceed to write the message.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging configuration (enabled flag, errors-only flag, and file path) is read from the property bundle exactly once per session via WEBUTIL.READFROMPROPERTYBUNDLE and cached in module-level variables; subsequent calls reuse the cached values without re-reading the bundle.
- BR-002 - If logging is configured as enabled but no log file path is provided, logging must be disabled immediately; the absence of a file path is treated as an invalid configuration.
- BR-003 - When no bean is registered at the time a configuration error is detected, the error must be surfaced to the user in English via WEBUTIL.ERRORALERT (WUC-008 for missing file, WUC-007 for write failure), because the bean communication channel is unavailable.
- BR-004 - The WUC_SRV_LOGGING client property on the registered bean must reflect the active logging mode: '0' = disabled, '1' = errors only, '2' = all messages; this property is set during cache initialisation and updated whenever logging is disabled due to an error.
- BR-005 - In errors-only mode, only messages passed with isError = TRUE are written to the log file; informational messages are silently suppressed.
- BR-006 - If the client IP address is known (m_clientIP is not null), every log entry must be prefixed with the client IP address and username to provide audit traceability.
- BR-007 - The log file must be opened in append mode ('A') for each write operation and closed immediately afterwards; the procedure does not hold the file handle open between calls.
- BR-008 - A file write failure (SQLCODE -302000) must disable logging for the remainder of the session (m_loggingAllowed := FALSE) to prevent repeated failed write attempts, and must be reported via WEBUTIL.ERRORALERT or the bean error channel (WUC-007).
- BR-009 - Any exception other than SQLCODE -302000 must be re-raised to the caller; the procedure does not suppress unexpected errors.

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-054 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resolves the path to the WebUtil configuration file, reads it line by line, and populates the in-memory property bundle (m_propertyBundle) with key-value pairs parsed from that file. As a side effect it returns the value associated with the requested propertyKey, making the full bundle available for subsequent lookups without re-reading the file. Error conditions (missing configuration path or unreadable file) are surfaced via WEBUTIL.ERRORALERT or the Webutil_Core error framework depending on whether a bean has already been registered.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-025](#SP-025--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Read the configuration file path from the Forms global variable identified by WEBUTIL_CONFIG_GLOBAL; if the global holds the sentinel value '[NOTSET]', treat it as unset.
- Step 2 - If the global is unset, attempt to retrieve the configuration file path from the operating-system environment variable identified by WEBUTIL_CONFIG_ENV using TOOL_ENV.GETVAR.
- Step 3 - If the environment variable also yields no value, fall back to the Forms parameter identified by WEBUTIL_CONFIG_PARAM using NAME_IN.
- Step 4 - If all three sources are exhausted without a valid path, raise NO_DATA_FOUND to trigger the error-handling block.
- Step 5 - Persist the resolved configuration file path back into WEBUTIL_CONFIG_GLOBAL (via COPY) so that subsequent calls avoid repeating the resolution logic.
- Step 6 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 7 - Loop through every line of the file using TEXT_IO.GET_LINE; exit the loop when NO_DATA_FOUND signals end-of-file.
- Step 8 - Skip any line whose first character is '#' (comment line).
- Step 9 - For non-comment lines, locate the first '=' character using INSTR; skip lines that contain no '=' (not a valid key-value pair).
- Step 10 - For valid key-value lines, increment the property index, then store the trimmed, lower-cased key and the trimmed, CR-stripped value into the next slot of m_propertyBundle.
- Step 11 - After storing each entry, compare its key (lower-case) against the lower-cased input propertyKey; if they match, capture the corresponding value in the result variable.
- Step 12 - After the loop, close the file with TEXT_IO.FCLOSE and return the result (NULL if the key was not found).
- Step 13 - On NO_DATA_FOUND exception (missing config path): if no bean is registered, call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error with code WUC_PACKAGE/5. Set m_config_error to TRUE and return NULL.
- Step 14 - On SQLCODE -302000 (file unreadable): if no bean is registered, call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error with code WUC_PACKAGE/6. Set m_config_error to TRUE and return NULL. Any other exception is re-raised.

---
**Decision Points**

DP-001

Condition:
The value read from WEBUTIL_CONFIG_GLOBAL equals the sentinel '[NOTSET]'.

TRUE:
The global is treated as unset; the procedure attempts to resolve the configuration file path from the environment variable (WEBUTIL_CONFIG_ENV) and then from the Forms parameter (WEBUTIL_CONFIG_PARAM).

FALSE:
The value from WEBUTIL_CONFIG_GLOBAL is used directly as the configuration file path; environment and parameter lookups are skipped.

---

DP-002

Condition:
The environment variable WEBUTIL_CONFIG_ENV returns a non-null value.

TRUE:
The returned value is used as the configuration file path; the Forms parameter fallback is skipped.

FALSE:
The procedure falls back to reading the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM.

---

DP-003

Condition:
The Forms parameter WEBUTIL_CONFIG_PARAM returns a non-null value.

TRUE:
The returned value is used as the configuration file path.

FALSE:
NO_DATA_FOUND is raised, triggering the error-handling block.

---

DP-004

Condition:
The first character of the current line is '#'.

TRUE:
The line is treated as a comment and skipped entirely.

FALSE:
The line is examined for a key-value pair.

---

DP-005

Condition:
The current (non-comment) line contains an '=' character (INSTR result > 0).

TRUE:
The line is parsed into a key-value pair and stored in m_propertyBundle.

FALSE:
The line is not a valid key-value pair and is skipped.

---

DP-006

Condition:
The lower-cased stored key equals the lower-cased input propertyKey.

TRUE:
The corresponding value is captured in the result variable to be returned.

FALSE:
The entry is stored in m_propertyBundle but does not update the result variable.

---

DP-007

Condition:
A NO_DATA_FOUND or SQLCODE -302000 exception is raised AND m_registeredPackages.FIRST is null (no bean registered).

TRUE:
WEBUTIL.ERRORALERT is called with the appropriate WUC error message in English.

FALSE:
Webutil_Core.Error is called with the structured error code and context, delegating error presentation to the registered bean framework.

---

DP-008

Condition:
The OTHERS exception handler fires and SQLCODE equals -302000.

TRUE:
The file-unreadable error path is executed (DP-007 logic applied for WUC-006); m_config_error is set to TRUE and NULL is returned.

FALSE:
The exception is re-raised to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be obtainable from exactly one of three sources in priority order: (1) the WEBUTIL_CONFIG_GLOBAL Forms global, (2) the WEBUTIL_CONFIG_ENV environment variable, (3) the WEBUTIL_CONFIG_PARAM Forms parameter. If none provides a value, the procedure treats the situation as a fatal configuration error.
- BR-002 - Once resolved, the configuration file path is written back to WEBUTIL_CONFIG_GLOBAL so that the resolution process is not repeated on subsequent invocations within the same Forms session.
- BR-003 - Lines beginning with '#' are treated as comments and must not be parsed as key-value pairs.
- BR-004 - Only lines containing an '=' character are valid key-value pairs; lines without '=' are silently ignored.
- BR-005 - Property keys are normalised to lower-case and stripped of leading/trailing whitespace before storage; property values are stripped of leading/trailing whitespace and carriage-return characters (CHR(13)).
- BR-006 - Key comparison against the input propertyKey is case-insensitive (both sides converted to lower-case).
- BR-007 - All parsed key-value pairs are loaded into the shared in-memory collection m_propertyBundle regardless of whether they match the requested key, ensuring the full bundle is available for subsequent lookups.
- BR-008 - When a configuration error occurs (missing path: WUC-005; unreadable file: WUC-006), the flag m_config_error is set to TRUE and NULL is returned; the error is never silently swallowed.
- BR-009 - Error presentation is context-sensitive: if no WebUtil bean has been registered (m_registeredPackages.FIRST is null), WEBUTIL.ERRORALERT is used to display a plain English message; otherwise the error is routed through the Webutil_Core structured error framework.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-055 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted text string to an open client-side file by delegating to the WebUtil Core bean. The procedure sets the active file handle and transmits the supplied text argument to the client file system via the WebUtil TEXT_IO bridge. It is invoked by the Excel report generation routine to stream report content line-by-line to a local file on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the target file handle (file.handle extracted from the file_type parameter) and the text string (arg) to be written.
- Step 2 - Register the active file handle with the WebUtil Core bean by calling WebUtil_Core.setProperty with the WUF_PACKAGE context, property key WUF_TEXTIO_HANDLE, and the file handle value.
- Step 3 - Transmit the formatted text argument to the client file by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and property key WUF_TEXTIO_PUTF, passing arg as the value.
- Step 4 - If the WebUtil bean is not registered on the client (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing implementation class and raise TOOL_ERR.TOOL_ERROR to halt processing.
- Step 5 - If a property communication error occurs (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to halt processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
The WebUtil Core bean corresponding to WUF_PACKAGE is registered and available on the client at the time of the setProperty calls.

TRUE:
Both setProperty calls succeed; the file handle and text argument are transmitted to the client, and the procedure completes normally.

FALSE:
The BEAN_NOT_REGISTERED exception is raised; an error alert is displayed identifying the missing bean class, and TOOL_ERR.TOOL_ERROR is raised to abort the calling process.

---

DP-002

Condition:
The setProperty communication with the WebUtil bean completes without a property-level error (PROPERTY_ERROR).

TRUE:
The write operation proceeds or has already completed successfully.

FALSE:
The PROPERTY_ERROR exception is raised; TOOL_ERR.TOOL_ERROR is raised immediately to abort the calling process.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the file handle and the text argument must be supplied; the procedure accepts no optional parameters and performs no null-substitution before delegating to the WebUtil Core bean.
- BR-002 - The WebUtil Core bean for WUF_PACKAGE must be registered on the client before this procedure is called; absence of the bean is a fatal condition that prevents any client-side text file write.
- BR-003 - The file handle is communicated to the bean as a discrete property (WUF_TEXTIO_HANDLE) prior to sending the text content (WUF_TEXTIO_PUTF), ensuring the bean targets the correct open file for each write operation.
- BR-004 - Any bean registration failure or property communication error must propagate as TOOL_ERR.TOOL_ERROR, preventing silent data loss or partial file writes in the calling Excel report generation process.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-056 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to an open client-side file by transmitting the file handle, the text content, and a newline instruction to the WebUtil bean layer. It is called by WEBUTIL.LOG to append log entries to a file residing on the client machine.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the target file reference (`file`) and the text string (`item`) to be written.
- Step 2 - Set the `WUF_TEXTIO_HANDLE` property on the `WUF_PACKAGE` bean to identify the open client-side file that will receive the output.
- Step 3 - Set the `WUF_TEXTIO_PUT` property on the `WUF_PACKAGE` bean to supply the text content to be written.
- Step 4 - Set the `WUF_TEXTIO_NEWLINE` property to `1`, instructing the bean to append a newline character after the text, completing the line write operation.
- Step 5 - If a `BEAN_NOT_REGISTERED` exception is raised during any property-set call, display an error alert identifying the missing implementation class and raise `TOOL_ERR.TOOL_ERROR` to abort processing.
- Step 6 - If a `PROPERTY_ERROR` exception is raised, raise `TOOL_ERR.TOOL_ERROR` to abort processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
A `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised when attempting to set a bean property (handle, text, or newline).

TRUE:
Display an error alert stating that the implementation class bean was not found and that `CLIENT_TEXT_IO.put_line` will not work, then raise `TOOL_ERR.TOOL_ERROR` to halt execution.

FALSE:
Continue to the next property-set call.

---

DP-002

Condition:
A `WebUtil_Core.PROPERTY_ERROR` exception is raised when attempting to set a bean property.

TRUE:
Raise `TOOL_ERR.TOOL_ERROR` immediately to halt execution.

FALSE:
All three property-set calls complete successfully; the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The file handle stored in the `file_type` parameter must be passed to the bean before the text content; the sequence of property assignments (handle -> text -> newline) must be preserved to ensure correct file targeting.
- BR-002 - A newline character is always appended after the supplied text (`WUF_TEXTIO_NEWLINE = 1`); this procedure unconditionally writes a full line and cannot be used to write partial lines without a terminating newline.
- BR-003 - If the WebUtil bean is not registered on the client, the procedure must raise `TOOL_ERR.TOOL_ERROR` after alerting the user; silent failure is not permitted.
- BR-004 - Any `PROPERTY_ERROR` encountered during the write sequence must cause an immediate `TOOL_ERR.TOOL_ERROR` raise, preventing partial or corrupt line output.

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-057 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value associated with a given property key from an in-memory property bundle collection. If the bundle has not yet been loaded, it delegates to WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) to initialise it before performing the lookup. The function is a shared utility called by WEBUTIL.CHECKLIBS, WEBUTIL.LOG, and WEBUTIL.REGISTERBEAN to resolve runtime configuration properties.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-054](#SP-054--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input property key (propertyKey) and capture the current count of entries in the in-memory collection m_propertyBundle into propCount.
- Step 2 - Check whether a configuration error flag (m_config_error) has previously been raised; if so, return NULL immediately without further processing.
- Step 3 - If no configuration error exists and the property bundle is empty (propCount = 0), delegate to WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) passing propertyKey to load the bundle and obtain the result directly from that call.
- Step 4 - If the property bundle is already populated (propCount > 0), iterate through all entries in m_propertyBundle comparing each entry's propertyKey (stored in lower case) against the lower-case equivalent of the supplied propertyKey.
- Step 5 - On finding a matching entry, assign its propertyValue to the result variable and exit the loop immediately.
- Step 6 - Return the resolved result value (or NULL if no match was found or a config error was present).

---
**Decision Points**

DP-001

Condition:
m_config_error is TRUE (a prior configuration file read failure has been recorded).

TRUE:
Return NULL immediately; no further lookup is attempted.

FALSE:
Proceed to check whether the property bundle has been populated.

---

DP-002

Condition:
The property bundle collection m_propertyBundle is empty (propCount = 0).

TRUE:
Call WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) with propertyKey to load the bundle and capture the returned value as the result.

FALSE:
Iterate through the existing bundle entries to locate the matching key.

---

DP-003

Condition:
During iteration, the current entry's propertyKey (lower-case stored) matches lower(propertyKey).

TRUE:
Assign the entry's propertyValue to result and exit the loop.

FALSE:
Continue to the next entry; if the loop completes without a match, result remains NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - If a configuration error has been detected in a prior operation (m_config_error = TRUE), the function must return NULL without attempting any property lookup, preventing use of a potentially corrupt or incomplete configuration state.
- BR-002 - Property key comparisons are performed in lower case; the stored key (m_propertyBundle(i).propertyKey) is held in lower case and the supplied propertyKey is converted via lower() at comparison time, ensuring case-insensitive matching.
- BR-003 - The property bundle is loaded on demand: if the in-memory collection is empty at the time of the call, WEBUTIL.POPULATEPROPERTYBUNDLE (SP-054) must be invoked to populate it before any key lookup can succeed.
- BR-004 - Once a matching property key is found during iteration, the loop must exit immediately (EXIT), ensuring the first matching entry takes precedence and avoiding unnecessary processing.
- BR-005 - The function returns NULL when no matching key is found in a populated bundle, signalling to the caller that the requested property is not defined.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-058 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by composing a lookup key and an optional arguments string, then delegating the get/set cycle to the WebUtil Core client-server bridge. The function is used to obtain localised UI text - currently the progress bar title - during library validation performed by WEBUTIL.CHECKLIBS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the message bundle property key (propertyKey) and an optional arguments string (args) as inputs.
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form a composite lookup value.
- Step 3 - Write the composite lookup value to the WebUtil Core client-server property slot WUC_TRANS_MSG on the WUC_PACKAGE component via Webutil_Core.setProperty, triggering the client-side message bundle resolution.
- Step 4 - Read back the resolved translated message string from the same WUC_TRANS_MSG property slot via Webutil_Core.getProperty.
- Step 5 - Return the resolved translated message string to the caller.

---
**Decision Points**

DP-001

Condition: Whether the args parameter is supplied by the caller.

TRUE: The composite lookup value passed to Webutil_Core.setProperty contains propertyKey, a pipe delimiter, and the args value (e.g. 'MY_KEY|arg1').

FALSE: The composite lookup value contains propertyKey followed by a pipe delimiter and a NULL segment (args defaults to NULL), resulting in the string 'MY_KEY|' being passed to the property slot.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and arguments must be combined using a pipe character ('|') as the delimiter before being submitted to the WebUtil Core message bundle resolver; no other delimiter is permitted.
- BR-002 - The translated message is retrieved exclusively through the Webutil_Core.setProperty / Webutil_Core.getProperty mechanism on the WUC_PACKAGE component using the WUC_TRANS_MSG property slot; no direct database or file lookup is performed.
- BR-003 - The args parameter is optional and defaults to NULL; callers that do not require argument substitution may omit it without causing a runtime error.
- BR-004 - The function must return the string value resolved by the WebUtil Core bridge; the caller (currently WEBUTIL.CHECKLIBS) is responsible for applying the returned text to the appropriate UI element (e.g. progress bar title).

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-059 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the server-side Forms session on first contact. For the very first bean registered in a session, the procedure also captures client environment details (IP address, OS, architecture, username, path/file separators, language code), resolves the system-library download directory, determines whether system libraries must be re-downloaded, logs the connection if configured, and downloads any required user libraries. For every bean registration it resolves the correct internal package identifier, prevents duplicate registration of the same bean, and communicates heartbeat-blocking and server-logging configuration back to the client bean.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-018](#SP-018--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-033](#SP-033--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-038](#SP-038--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-040](#SP-040--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-042](#SP-042--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-062](#SP-062--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) using DelimStr.getString.
- Step 2 - Map the bean short name ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') to the corresponding WEBUTIL_CORE package-ID constant; packageID remains unset if the short name is not recognised.
- Step 3 - If the session-level client IP (m_clientIP) is null, this is the first bean to register; set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields (positions 2-8) to populate m_clientIP, m_clientOS, m_clientOSFamily (via WEBUTIL.GETOSFAMILY), clientOSArch, m_clientOSArch (set to 1 when the arch string contains '64'), m_clientUserName, m_clientPathSep, m_clientFileSep, and m_clientLangCode.
- Step 4 - If the resolved packageID does not yet exist in the m_registeredPackages array, record the triggering item (SYSTEM.TRIGGER_ITEM) against that packageID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 5 - When checkUserLibs is TRUE, reset REDOWNLOAD_SYSLIB to FALSE, then retrieve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME'; if null, fall back to WEBUTIL.GETVAR for 'HOST'.
- Step 6 - Attempt to resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with the key 'install.syslib.location.client.<OSFamily>.<OSArch>'; if null, retry with the shorter key 'install.syslib.location.client.<OSFamily>'.
- Step 7 - If no client library directory is found, send a WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application CONFIG, allowing the client JRE to handle placement. If a directory is found, substitute the '$(SERVERHOST)' token with the resolved server host name, then send the full WUC_SYSLIB_DIR property; compare the new directory against the previously stored value retrieved via WEBUTIL.GETCLIENTSETTING ('install.syslib.dir'): if they differ, persist the new value with WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 8 - Retrieve and store the WebUtil bean version into Webutil_Core.WEBUTIL_VERSION via WEBUTIL.GETPROPERTY on WUC_BEAN_VERSION.
- Step 9 - If the property bundle key 'logging.connections' evaluates to 'true' (case-insensitive), write a connection log entry via WEBUTIL.LOG containing the current form name, client OS, and locale.
- Step 10 - If newPackage is TRUE, call WEBUTIL.CHECKLIBS with the string representation of packageID to verify and download required package-specific libraries.
- Step 11 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 12 - Read the 'BlockAllowHeartBeat' property bundle key; if its lower-case value equals 'true', 'yes', or '1', set the WUC_BLOCK_ALLOW_HEART_BEAT property to '1' on the registered bean; otherwise set it to '0'.
- Step 13 - Evaluate the m_loggingAllowed and m_loggingErrorsOnly flags and send the appropriate WUC_SRV_LOGGING value ('1' = errors only, '2' = full logging, '0' = disabled) to the registered bean.
- Step 14 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL').
TRUE: packageID is assigned the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains unset; subsequent array and property operations may not execute correctly for unrecognised beans.

DP-002
Condition: m_clientIP IS NULL (i.e., no bean has previously registered in this session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, OS architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; checkUserLibs remains FALSE and parsing is skipped.

DP-003
Condition: The architecture string parsed from clientInfo position 4 contains '64'.
TRUE: m_clientOSArch is set to 1 (64-bit client).
FALSE: m_clientOSArch remains at its default value (not set to 1).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The bean is recorded in m_registeredPackages against SYSTEM.TRIGGER_ITEM and newPackage is set to TRUE.
FALSE: The bean is already registered (e.g., placed in a multi-row block); no action is taken and newPackage remains FALSE.

DP-005
Condition: WEBUTIL.READFROMPROPERTYBUNDLE returns a non-null value for 'install.syslib.location.client.<OSFamily>.<OSArch>'.
TRUE: clientLibDir is set to the OS-family-and-architecture-specific path; the fallback lookup is skipped.
FALSE: A second lookup is attempted using the shorter key 'install.syslib.location.client.<OSFamily>'.

DP-006
Condition: clientLibDir IS NULL after both property bundle lookups.
TRUE: WUC_SYSLIB_DIR is sent to the client containing only ':serverHost:CONFIG', delegating directory resolution to the client JRE.
FALSE: clientLibDir is used; the '$(SERVERHOST)' token is replaced, WUC_SYSLIB_DIR is sent with the full path, and the stored client setting is compared to detect a directory change.

DP-007
Condition: clientLibDirOld (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The directory is unchanged; REDOWNLOAD_SYSLIB remains FALSE.

DP-008
Condition: lower(WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections')) = 'true'.
TRUE: WEBUTIL.LOG is called to record the connection details (form name, client OS, locale).
FALSE: No connection log entry is written.

DP-009
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string representation of packageID to verify package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-010
Condition: lower(WEBUTIL.READFROMPROPERTYBUNDLE('BlockAllowHeartBeat')) equals 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT property is set to '1' on the registered bean, instructing the client to block heartbeat allowance.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT property is set to '0'.

DP-011
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is set to '1' (errors-only logging).
FALSE: Proceed to DP-012.

DP-012
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is set to '2' (full logging).
FALSE: WUC_SRV_LOGGING is set to '0' (logging disabled).

DP-013
Condition: checkUserLibs is TRUE (evaluated after the newPackage library check).
TRUE: WEBUTIL.CHECKLIBS is called with the literal 'user' to verify and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only the ten recognised bean short names ('WUC', 'WUT', 'WUF', 'WUI', 'WUH', 'WUS', 'WUB', 'WUO', 'WUU', 'WUL') are mapped to internal package IDs; any unrecognised short name results in no packageID assignment.
- BR-002 - Client environment metadata (IP, OS, architecture, username, separators, language code) is captured exactly once per Forms session, on the first bean registration; subsequent bean registrations within the same session do not overwrite these values.
- BR-003 - Each bean type may be registered only once per session regardless of how many instances appear in the form (e.g., in a multi-row block); only the first instance is recorded.
- BR-004 - A 64-bit client is identified by the presence of the string '64' anywhere within the OS architecture field supplied in clientInfo position 4.
- BR-005 - The system-library client directory is resolved in priority order: architecture-specific property bundle key first, OS-family-only key second, and client-JRE default last.
- BR-006 - The placeholder token '$(SERVERHOST)' within a configured client library directory must be replaced with the runtime server host name before the value is transmitted to the client.
- BR-007 - The server host name is obtained from the environment variable 'COMPUTERNAME'; if that is null, 'HOST' is used as a fallback via WEBUTIL.GETVAR.
- BR-008 - When the resolved client system-library directory differs from the previously persisted value, the new value is saved via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag is raised to force a re-download.
- BR-009 - Connection logging is governed by the 'logging.connections' property bundle entry; the log entry includes the current form name, client operating system, and locale.
- BR-010 - The heartbeat-blocking instruction sent to the client bean accepts three equivalent affirmative values: 'true', 'yes', and '1' (case-insensitive); all other values disable heartbeat blocking.
- BR-011 - Server-side logging state (errors-only vs. full vs. disabled) is communicated to the client bean via the WUC_SRV_LOGGING property to prevent unnecessary round-trips from the client to the server.
- BR-012 - Package-specific library verification (WEBUTIL.CHECKLIBS with packageID) is performed only when a bean type is registered for the first time; user library verification (WEBUTIL.CHECKLIBS with 'user') is performed only once per session, after at least one bean has been registered so that a handler bean is available to perform any required download.
- BR-013 - The logging initialisation call (WEBUTIL.LOG with a null message) must occur after at least one bean has been registered to ensure the logging flags m_loggingAllowed and m_loggingErrorsOnly are correctly initialised before they are used to set WUC_SRV_LOGGING.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-060 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named function from a specified library with the WebUtil client-side bean and returns a FunctionHandle that subsequent calls can use to invoke the function. The procedure communicates the library/function specification to the WebUtil core layer, retrieves a numeric handle assigned by the bean, and maintains an internal count of successfully registered function handles.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Concatenate the input library name (libName) and function name (funcName) into a pipe-delimited specification string (libName || '|' || funcName) and pass it to the WebUtil core layer by setting the WUL_FUNCTION_SPEC property on the WUL_PACKAGE component.
- Step 2 - Request the bean to register the function by retrieving the WUL_REGISTER_FUNCTION property from the WUL_PACKAGE component via WebUtil_Core.getProperty; the bean returns a string handle (strHnd).
- Step 3 - Convert the returned string handle to a numeric value and assign it to the hnd field of the local FunctionHandle variable (funcHnd).
- Step 4 - Call ID_NULL (SP-047) to test whether the resulting FunctionHandle is null; if the handle is valid (not null), increment the module-level registered-function counter (m_funcHandleCount) by 1.
- Step 5 - Return the populated FunctionHandle to the caller.
- Step 6 (Exception - BEAN_NOT_REGISTERED) - If the WebUtil bean is not registered, display an error alert identifying the missing implementation class and raise FORM_TRIGGER_FAILURE to abort processing.
- Step 7 (Exception - PROPERTY_ERROR) - If a property interaction error occurs, raise FORM_TRIGGER_FAILURE to abort processing.
- Step 8 (Exception - VALUE_ERROR) - If the string-to-number conversion of the handle fails, raise TOOL_ERR.TOOL_ERROR.

---
**Decision Points**

DP-001

Condition:
The FunctionHandle returned by the bean is NOT null, as determined by calling ID_NULL (SP-047) on funcHnd.

TRUE:
The handle is valid; increment the module-level counter m_funcHandleCount by 1, confirming a successful registration.

FALSE:
m_funcHandleCount is not incremented; the null handle is still returned to the caller, indicating the bean did not produce a usable handle.

---

DP-002

Condition:
A BEAN_NOT_REGISTERED exception is raised during the WebUtil core property calls.

TRUE:
Display an error alert naming the missing implementation class and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE:
Processing continues normally through the remaining steps.

---

DP-003

Condition:
A PROPERTY_ERROR exception is raised during the WebUtil core property calls.

TRUE:
Raise FORM_TRIGGER_FAILURE to halt form processing without displaying an additional alert.

FALSE:
Processing continues normally.

---

DP-004

Condition:
A VALUE_ERROR exception is raised when converting the string handle to a number (TO_NUMBER).

TRUE:
Raise TOOL_ERR.TOOL_ERROR to signal an unrecoverable data conversion failure.

FALSE:
Conversion succeeds and the numeric handle is stored in funcHnd.hnd.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The library name and function name must be supplied as a pipe-delimited pair (libName || '|' || funcName) when communicating the function specification to the WebUtil core layer; neither value may be omitted without producing an invalid specification.
- BR-002 - A function handle is counted as successfully registered only when ID_NULL (SP-047) confirms the returned FunctionHandle is not null; null handles do not increment the registration counter.
- BR-003 - The WebUtil client-side bean must be registered before this function is called; if the bean is absent, the form operation is terminated via FORM_TRIGGER_FAILURE and an informational error alert is presented to the user.
- BR-004 - The string value returned by the bean for the registered function must be convertible to a number; a VALUE_ERROR during conversion escalates to TOOL_ERR.TOOL_ERROR, preventing a corrupt handle from being returned.
- BR-005 - A PROPERTY_ERROR raised by the WebUtil core layer results in immediate termination of the form trigger via FORM_TRIGGER_FAILURE, with no partial handle returned to the caller.

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-061 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases a previously acquired host process handle by clearing its associated callback trigger and nullifying the handle reference. This ensures that process resources managed by the WebUtil host facility are properly cleaned up after use, preventing stale handles from persisting in the calling context.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the process handle (PROCESS_ID) as an IN OUT parameter representing an active host process to be released.
- Step 2 - Invoke WebUtil_Core.setProperty to clear the WUH_CLEAR_PROC property on the WUH_PACKAGE, registering the intent to release the process identified by process.handle.
- Step 3 - Invoke WebUtil_Core.ClearCallbackTrigger with the current process handle to remove any callback trigger associated with that process.
- Step 4 - Set process.handle to NULL, effectively releasing the caller's reference to the process and signalling that the handle is no longer valid.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised during any of the above steps, display an error alert indicating that the required WebUtil bean could not be found and that WEBUTIL_HOST.Release_Process will not function, then exit without completing the release.

---
**Decision Points**

DP-001

Condition:
A BEAN_NOT_REGISTERED exception is raised when attempting to set the property or clear the callback trigger (i.e., the WebUtil bean identified by WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE) is not registered).

TRUE:
An error alert is displayed to the user stating that the bean was not found and that WEBUTIL_HOST.Release_Process will not work. The procedure exits without nullifying the handle or completing the release.

FALSE:
The release sequence completes normally: the WUH_CLEAR_PROC property is set, the callback trigger is cleared, and process.handle is set to NULL.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The process handle (process.handle) must be nullified upon successful release to prevent the calling context from retaining a stale or reusable reference to a freed process.
- BR-002 - The WUH_CLEAR_PROC property on WUH_PACKAGE must be updated via WebUtil_Core.setProperty before the callback trigger is cleared, ensuring the WebUtil framework is notified of the release intent prior to trigger removal.
- BR-003 - The WebUtil bean associated with WUH_PACKAGE must be registered at the time of invocation; if it is not, the procedure must surface a descriptive error alert and abort the release operation rather than silently failing.
- BR-004 - No database interactions are performed during process release; the operation is entirely client-side and framework-level, with no persistence layer involvement.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-062 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transmits a named configuration property and its value to the WebUtil client-side bean by delegating to WebUtil_Core.setProperty. This allows the Oracle Forms runtime to push local client settings (identified by name/value pairs) to the WebUtil core package on the client tier. The procedure is called during library initialisation (WEBUTIL.CHECKLIBS) and bean registration (WEBUTIL.REGISTERBEAN) to ensure client-side settings are applied before dependent WebUtil functionality is used.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the client setting as two IN parameters: propertyName (the setting identifier) and propertyValue (the value to assign).
- Step 2 - Evaluate whether propertyName is non-null; only a non-null property name constitutes a valid setting request.
- Step 3 - If propertyName is non-null, invoke WebUtil_Core.setProperty, targeting the WUC_PACKAGE package constant with the action key WUC_SET_LOCAL_PROPERTY and passing the concatenated string propertyName||'='||propertyValue as the property payload.
- Step 4 - If the WebUtil_Core bean has not been registered (BEAN_NOT_REGISTERED exception), display an error alert via WebUtil_Core.ErrorAlert identifying the missing bean class, then raise FORM_TRIGGER_FAILURE to halt further form processing.
- Step 5 - If WebUtil_Core.setProperty reports a property error (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE immediately to halt further form processing without displaying an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Calls WebUtil_Core.setProperty with WUC_PACKAGE, WUC_SET_LOCAL_PROPERTY, and the concatenated propertyName||'='||propertyValue string to apply the client setting.

FALSE: The procedure exits silently without invoking WebUtil_Core.setProperty; no setting is transmitted and no error is raised.

---

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Displays an error alert via WebUtil_Core.ErrorAlert identifying the unregistered bean class, then raises FORM_TRIGGER_FAILURE to abort form processing.

FALSE: Exception is not raised; execution continues normally.

---

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raises FORM_TRIGGER_FAILURE immediately to abort form processing; no additional alert is displayed.

FALSE: Exception is not raised; execution continues normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A client setting is only transmitted to the WebUtil bean if propertyName is non-null; a null propertyName causes the procedure to exit silently with no action taken.
- BR-002 - The property payload delivered to the WebUtil client bean must be formatted as a single concatenated string in the form propertyName||'='||propertyValue.
- BR-003 - The target package for the client setting is always WebUtil_Core.WUC_PACKAGE with action key WUC_SET_LOCAL_PROPERTY; these constants are not overridable by callers.
- BR-004 - If the WebUtil core bean is not registered at the time of invocation, the procedure must surface a descriptive error alert (identifying the missing bean class) and terminate form processing via FORM_TRIGGER_FAILURE.
- BR-005 - If a property error is returned by WebUtil_Core.setProperty, the procedure must terminate form processing via FORM_TRIGGER_FAILURE; no informational alert is displayed for this condition.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-063 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Receives a single chunk of upload data (as a VARCHAR2 string) and writes it to the appropriate destination - either a database BLOB via WebUtil_DB_Local or a server-side file via JAVA_APPSERV_WRITER. When all expected chunks have been received, the procedure finalises the transfer by closing the target resource, marks the upload as succeeded or failed, and fires any registered callback trigger before clearing it.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-019](#SP-019--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-020](#SP-020--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-021](#SP-021--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-031](#SP-031--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-035](#SP-035--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-036](#SP-036--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-067](#SP-067--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming uploadData parameter; if it is NULL or empty, set the module-level flag m_uploadSucceeded to FALSE and exit - no further processing is performed.
- Step 2 - Determine the write destination by evaluating the module-level flag m_toDB.
- Step 3 (m_toDB = TRUE) - Delegate the chunk write to WebUtil_DB_Local.WriteData, passing uploadData.
- Step 4 (m_toDB = FALSE) - Attempt to write the chunk via JAVA_APPSERV_WRITER.WriteData; if the write fails, retrieve the error code and error arguments from JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs respectively, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception.
- Step 5 - Decrement the module-level chunk counter m_chunks by 1.
- Step 6 - Evaluate whether m_chunks has reached 0 (i.e., all chunks have been delivered).
- Step 7 (all chunks received, m_toDB = TRUE) - Call WebUtil_DB_Local.CloseBlob passing m_fileSize; if successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error via WebUtil_DB_Local.getLastError and log it through WebUtil_Core.Error, leaving m_uploadSucceeded as FALSE.
- Step 8 (all chunks received, m_toDB = FALSE) - Call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize; if successful, set m_uploadSucceeded to TRUE; otherwise, retrieve the error code and arguments, log via WebUtil_Core.Error, release the Java global reference with ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 9 - After finalisation, check whether a callback trigger is registered by calling WebUtil_Core.GetCallbackTrigger(-1); if one is present, execute it via EXECUTE_TRIGGER.
- Step 10 - Unconditionally clear the callback trigger by calling WebUtil_Core.ClearCallbackTrigger(-1).

---
**Decision Points**

DP-001

Condition: uploadData IS NULL or uploadData = '' (empty string)

TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately; no write or chunk-count operations are performed.

FALSE: Proceed with writing the data chunk and all subsequent processing steps.

---

DP-002

Condition: m_toDB is TRUE

TRUE: Write the data chunk to the database BLOB destination using WebUtil_DB_Local.WriteData.

FALSE: Write the data chunk to the application-server file destination using JAVA_APPSERV_WRITER.WriteData.

---

DP-003

Condition: JAVA_APPSERV_WRITER.WriteData returns a failure result (m_toDB = FALSE path only)

TRUE: Retrieve error details via JAVA_APPSERV_WRITER.getLastError and JAVA_APPSERV_WRITER.getLastErrorArgs, log the error, and raise READWRITE_ERROR.

FALSE: Continue to decrement m_chunks.

---

DP-004

Condition: m_chunks equals 0 after decrement (all expected chunks have been received)

TRUE: Proceed to finalise the transfer by closing the target resource.

FALSE: No finalisation action; procedure exits normally awaiting further chunks.

---

DP-005

Condition: m_toDB is TRUE at finalisation time

TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob; set m_uploadSucceeded based on the result.

FALSE: Close the file via JAVA_APPSERV_WRITER.CloseFile; set m_uploadSucceeded based on the result, or raise READWRITE_ERROR on failure.

---

DP-006

Condition: WebUtil_DB_Local.CloseBlob returns success (m_toDB = TRUE finalisation path)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve and log the error via WebUtil_DB_Local.getLastError; m_uploadSucceeded remains FALSE.

---

DP-007

Condition: JAVA_APPSERV_WRITER.CloseFile returns success (m_toDB = FALSE finalisation path)

TRUE: Set m_uploadSucceeded to TRUE.

FALSE: Retrieve error details, log the error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.

---

DP-008

Condition: WebUtil_Core.GetCallbackTrigger(-1) returns a non-null trigger name

TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.

FALSE: Skip trigger execution; proceed directly to clearing the callback trigger.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData value is treated as an error condition; the upload is immediately marked as failed (m_uploadSucceeded = FALSE) and no data is written to any destination.
- BR-002 - Each call to SETDATA processes exactly one chunk; the procedure is designed to be invoked repeatedly until all chunks have been delivered.
- BR-003 - The write destination (database BLOB or application-server file) is determined solely by the pre-established module-level flag m_toDB and cannot be changed mid-transfer.
- BR-004 - Any failure during a file-system write (JAVA_APPSERV_WRITER.WriteData) must be accompanied by error logging using the error code and arguments retrieved from the writer object before the READWRITE_ERROR exception is raised.
- BR-005 - Finalisation (closing the target resource) is triggered only when the chunk counter m_chunks reaches exactly zero, ensuring the resource is not closed prematurely.
- BR-006 - On a successful close of either the BLOB or the file, m_uploadSucceeded must be set to TRUE; any close failure leaves the flag FALSE and the error is logged.
- BR-007 - On a file-close failure (m_toDB = FALSE), the Java global reference held in m_persistObj must be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF before raising READWRITE_ERROR, preventing resource leaks.
- BR-008 - After all chunks are finalised, any registered callback trigger (identified by index -1) must be executed before it is cleared, ensuring downstream processes are notified of transfer completion regardless of success or failure of that trigger check.
- BR-009 - The callback trigger must always be cleared via WebUtil_Core.ClearCallbackTrigger(-1) after the finalisation step, whether or not a trigger was fired.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-064 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a PL/SQL wrapper that delegates to the Java Virtual Machine via the JNI bridge to set a named JVM system property to a specified value. The function accepts a property key and its desired value, invokes the standard Java method java.lang.System.setProperty, and returns the property's previous value (or NULL if it was not previously set). This allows Oracle Forms runtime code to manipulate JVM-level system properties without direct Java coding.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property key (a0) and the new property value (a1) as VARCHAR2 input parameters.
- Step 2 - Allocate a JNI argument list sized for exactly two arguments by calling JNI.CREATE_ARG_LIST(2) and storing the handle in the shared 'args' variable.
- Step 3 - Append the property key (a0) to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Append the new property value (a1) to the argument list as a second String argument via JNI.ADD_STRING_ARG.
- Step 5 - Invoke the static Java method java.lang.System.setProperty(String, String) through JNI.CALL_STRING_METHOD, passing the fully-qualified class name 'java/lang/System', method name 'setProperty', and the JNI method descriptor '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;' together with the populated argument list.
- Step 6 - Return the VARCHAR2 result received from the JNI call, which represents the previous value of the named system property (NULL if the property had no prior value).

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a linear sequence of JNI calls unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Exactly two arguments must be supplied to the JNI argument list; the property key (a0) must be added first and the new value (a1) second, matching the parameter order required by java.lang.System.setProperty.
- BR-002 - The target Java method is always invoked as a static method on the class 'java/lang/System'; no object instance is passed (the instance argument to JNI.CALL_STRING_METHOD is NULL).
- BR-003 - The function returns the previous value of the system property as a VARCHAR2; callers must handle a NULL return, which indicates the property did not exist before this call.
- BR-004 - This function has no database interactions; all side effects occur exclusively within the JVM system property store via the JNI bridge.

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-065 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls the visibility of the hidden WebUtil window (WEBUTIL_HIDDEN_WINDOW) used to host WebUtil bean components. When called with show = TRUE, the procedure navigates focus into the hidden window so that embedded beans can be interacted with; when called with show = FALSE, it restores focus to the previously active item and hides the window. The procedure is guard-railed to execute only when the form is in NORMAL mode, preventing interference during Enter Query Mode.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Locate the hidden WebUtil window by calling FIND_WINDOW with the constant WEBUTIL_HIDDEN_WINDOW and store the handle in a local variable.
- Step 2 - Check whether the form is currently in NORMAL mode by reading SYSTEM.MODE; if the mode is not NORMAL, the procedure exits immediately without taking any action (Enter Query Mode guard, Bug 2955789).
- Step 3 - Validate that the window handle obtained in Step 1 is not null by calling WEBUTIL.ID_NULL (SP-047); if the handle is null, no further action is taken.
- Step 4 - Evaluate the incoming show parameter to determine whether to display or hide the window.
- Step 5 (show = TRUE) - Capture the currently focused form item by reading SYSTEM.CURSOR_ITEM via FIND_ITEM and store it in the module-level variable m_infoFrom for later restoration.
- Step 6 (show = TRUE) - Set the hidden window's title to 'WebUtil ' concatenated with WEBUTIL_VERSION to identify the window version.
- Step 7 (show = TRUE) - Make the hidden window visible using SHOW_WINDOW, then navigate form focus to WEBUTIL_DUMMY_ITEM so that the beans within the window receive control.
- Step 8 (show = FALSE) - Check whether the previously saved item handle m_infoFrom is not null using WEBUTIL.ID_NULL (SP-047); if valid, navigate focus back to that item using GO_ITEM.
- Step 9 (show = FALSE) - Hide the window using HIDE_WINDOW, returning the UI to its normal state.

---
**Decision Points**

DP-001

Condition:
SYSTEM.MODE = 'NORMAL'

TRUE:
Proceed to check the window handle and evaluate the show parameter.

FALSE:
Exit the procedure immediately; no window or focus changes are made (protects Enter Query Mode behaviour, Bug 2955789).

---

DP-002

Condition:
WEBUTIL.ID_NULL(hWin) is FALSE (i.e., the WEBUTIL_HIDDEN_WINDOW handle is valid)

TRUE:
Proceed to evaluate the show parameter and act on the window.

FALSE:
Exit without performing any window or focus operations.

---

DP-003

Condition:
show = TRUE

TRUE:
Capture the current cursor item into m_infoFrom, set the window title, show the hidden window, and navigate focus to WEBUTIL_DUMMY_ITEM.

FALSE:
Attempt to restore focus to the previously captured item and hide the window (see DP-004).

---

DP-004

Condition:
show = FALSE and WEBUTIL.ID_NULL(m_infoFrom) is FALSE (i.e., a prior cursor item was captured)

TRUE:
Navigate form focus back to m_infoFrom before hiding the window.

FALSE:
Skip the GO_ITEM call and proceed directly to hiding the window.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must not execute any window or focus logic when the form is in Enter Query Mode (SYSTEM.MODE ≠ 'NORMAL'); this restriction exists to prevent corruption of the query state (Bug 2955789).
- BR-002 - The hidden WebUtil window must have a valid handle (verified via WEBUTIL.ID_NULL, SP-047) before any show or hide operation is attempted; an invalid handle causes the procedure to abort silently.
- BR-003 - When showing the WebUtil bean window, the currently active form item (SYSTEM.CURSOR_ITEM) must be captured and stored in m_infoFrom so that focus can be accurately restored when the window is subsequently hidden.
- BR-004 - The hidden window's title must be set to 'WebUtil ' concatenated with WEBUTIL_VERSION each time it is shown, ensuring the displayed version label is always current at the moment of display.
- BR-005 - Focus restoration on hide is conditional: GO_ITEM is called only when m_infoFrom holds a valid item handle (verified via WEBUTIL.ID_NULL, SP-047); if no prior item was captured, focus restoration is skipped to avoid a runtime error.

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-066 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-accessible URL to a specified destination path on the client machine. The function acts as a named wrapper within the WEBUTIL package, delegating the actual download operation to WEBUTIL.DOWNLOADFROMURL (SP-022). It is invoked during Excel report generation to deliver the report file to the end user's local file system.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-022](#SP-022--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive the source URL identifying the file to be downloaded, the client-side destination path where the file should be saved, and an optional file size hint (defaulting to 0 if not supplied).
- Step 2 - Delegate the download operation to WEBUTIL.DOWNLOADFROMURL (SP-022), passing through all three arguments (sourceURL, clientDestination, fileSize) unchanged.
- Step 3 - Return the BOOLEAN result produced by WEBUTIL.DOWNLOADFROMURL (SP-022) directly to the caller, indicating whether the file transfer succeeded or failed.

---
**Decision Points**

DP-001

Condition:
The evaluation of the download outcome is performed entirely within WEBUTIL.DOWNLOADFROMURL (SP-022); URL_TO_CLIENT itself contains no conditional branching.

TRUE:
Not applicable - no decision logic exists within this function body.

FALSE:
Not applicable - the function unconditionally delegates to WEBUTIL.DOWNLOADFROMURL (SP-022) and returns its result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The fileSize parameter is optional; if omitted by the caller, it defaults to 0, allowing WEBUTIL.DOWNLOADFROMURL (SP-022) to handle size determination internally.
- BR-002 - The function must return a BOOLEAN to the caller, reflecting the success or failure of the file transfer as determined by WEBUTIL.DOWNLOADFROMURL (SP-022); no independent success/failure assessment is performed by this wrapper.
- BR-003 - All three parameters (sourceURL, clientDestination, fileSize) are passed to WEBUTIL.DOWNLOADFROMURL (SP-022) without modification; no transformation or validation of input values is performed by this function.

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-067 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Passes a string data payload to the Java-layer AppServerFileWriter class on the application server by invoking its WriteData method via the JNI bridge. The function returns a Boolean indicating whether the write operation succeeded, and is called by WEBUTIL.SETDATA to physically write data content to a server-side file.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing an active AppServerFileWriter instance and the string data payload (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the string data payload (a0) to the argument list by calling JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter instance via JNI.CALL_BOOLEAN_METHOD, passing the populated argument list and targeting the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result received from the JNI call to the caller (WEBUTIL.SETDATA), indicating success or failure of the write operation.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally constructs the JNI argument list, invokes the remote Java method, and returns the Boolean result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must receive a valid Java object reference (obj) pointing to an initialised AppServerFileWriter instance; the JNI call targets that specific object and will not substitute an alternative writer.
- BR-002 - Exactly one string argument (a0) must be supplied to the JNI argument list; the argument list is created with a fixed capacity of 1, so no additional arguments may be appended.
- BR-003 - The write outcome is communicated solely through the returned Boolean value; the function does not raise exceptions or produce output parameters, making it the caller's responsibility to evaluate the return value.
- BR-004 - The FALSE flag passed to JNI.CALL_BOOLEAN_METHOD indicates the method is not static; a valid, non-null object reference (obj) is therefore mandatory for correct execution.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-068 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil client-side bean within the WHEN-CUSTOM-ITEM-EVENT trigger. It receives an event name and its associated parameter string, extracts the data payload and multipart metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer notification) based on the event type.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-024](#SP-024--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-037](#SP-037--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-053](#SP-053--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-059](#SP-059--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-063](#SP-063--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-064](#SP-064--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate that the incoming EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); if not, raise the local 'unhandled' exception and exit silently.
- Step 2 - Extract the data payload string from EventParameters by reading the 'WUC_DATA' attribute via the internal get_parameter_attr call, storing the result in dataPayload.
- Step 3 - Extract the multipart descriptor from EventParameters by reading the 'WUC_DATA_MULTIPART' attribute, storing the result in dataMultiPart.
- Step 4 - Parse dataMultiPart using DelimStr.getNumber to derive the current chunk sequence number (chunkNumber) and the total number of chunks required to complete the payload (PayloadChunks).
- Step 5 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': forward dataPayload to WEBUTIL.LOG as an informational message.
  - If 'WUC_ERROR_EVENT': forward dataPayload to WEBUTIL.LOG as an error message.
  - If 'WUC_REGISTER': forward dataPayload to WEBUTIL.REGISTERBEAN to register the client bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a numeric callback index (m_lastCallback); if conversion fails, call WEBUTIL.ERROR with code 408; if the index is valid, execute the stored callback trigger via EXECUTE_TRIGGER; if the index is null, log a warning via WEBUTIL.LOG.
  - If 'WUT_TRANSFER_EVENT': pass dataPayload to WEBUTIL.SETDATA to store the transferred file data, then call WEBUTIL.SETPROPERTY to mark the transfer event status as 'RECEIVED'.
- Step 6 - On an 'unhandled' exception (unrecognised event name), suppress the error and return normally. All other exceptions are re-raised to the caller.

---
**Decision Points**

DP-001

Condition: EventName is one of the five recognised values ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: Proceed with payload extraction and event routing.

FALSE: Raise the local 'unhandled' exception; the exception handler suppresses it and the procedure exits without further processing.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload as an informational (non-error) log entry.

FALSE: Evaluate the next event condition (DP-003).

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload flagged as an error entry.

FALSE: Evaluate the next event condition (DP-004).

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN with dataPayload to register the client-side bean.

FALSE: Evaluate the next event condition (DP-005).

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt numeric conversion of dataPayload to m_lastCallback and proceed with callback execution (see DP-006 and DP-007).

FALSE: Evaluate the next event condition (DP-008).

---

DP-006

Condition: Conversion of dataPayload to a number succeeds (no INVALID_NUMBER exception).

TRUE: Store the numeric value in m_lastCallback and proceed to DP-007.

FALSE: Call WEBUTIL.ERROR with package constant WUC_PACKAGE and error code 408, identifying 'WEBUTIL_CORE.CustomEventHandler' as the source; m_lastCallback remains unset.

---

DP-007

Condition: m_lastCallback IS NOT NULL after successful numeric conversion.

TRUE: Execute the trigger stored at m_callbacks(m_lastCallback) via EXECUTE_TRIGGER.

FALSE: Call WEBUTIL.LOG to record a warning that no callback trigger was specified for the host command.

---

DP-008

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload to store the file-transfer data, then call WEBUTIL.SETPROPERTY to set the 'WUT_TRANSFER_EVENT' property to 'RECEIVED'.

FALSE: No further routing occurs (all five valid event names have been evaluated).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the five explicitly whitelisted event names ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; any other event name is silently discarded to prevent unauthorised or malformed events from affecting form state.
- BR-002 - The data payload and multipart descriptor must always be extracted from EventParameters before any event-specific processing begins, ensuring all routing branches operate on consistent data.
- BR-003 - For 'WUH_CALLBACK_EVENT', the payload must be convertible to a valid integer index; a non-numeric payload is treated as a configuration error and reported via WEBUTIL.ERROR (code 408) rather than causing an unhandled exception.
- BR-004 - A null callback index (m_lastCallback IS NULL) after a successful numeric conversion is treated as a business warning, not a hard error; the condition is logged via WEBUTIL.LOG and processing continues.
- BR-005 - For 'WUT_TRANSFER_EVENT', both the data storage (WEBUTIL.SETDATA) and the status acknowledgement (WEBUTIL.SETPROPERTY set to 'RECEIVED') must be performed together to correctly signal transfer completion to downstream consumers.
- BR-006 - Unrecognised events are suppressed without surfacing an error to the user or the calling trigger, preserving form stability when unexpected client events are received.
- BR-007 - All unexpected runtime exceptions other than the locally defined 'unhandled' exception are re-raised, ensuring that genuine processing failures are not masked.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-069 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a runtime error condition by setting a global error flag, composing a structured error message from the calling function name and error text, and writing the composed message to the debug log via DEBUGLOG. This procedure serves as the centralised error-registration mechanism for the D2KWUTIL library, ensuring that any error encountered by a calling routine is captured consistently and traceable through the debug log.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the name of the calling function (CallingFunction) and the descriptive error text (SetErrorText) as input parameters.
- Step 2 - Set the global flag ERROR_ENCOUNTERED to TRUE to signal that an error condition is now active.
- Step 3 - Compose the ERROR_STACK message by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess to prevent overflow.
- Step 4 - Invoke DEBUGLOG (SP-073) with severity level 99, the label 'Add_Error', and the composed ERROR_STACK value to write the error entry to the debug log.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The procedure executes all steps unconditionally for every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The global flag ERROR_ENCOUNTERED must be set to TRUE whenever this procedure is called, indicating that at least one error has occurred in the current execution context.
- BR-002 - The error message stored in ERROR_STACK must be prefixed with the name of the calling function followed by a colon-space separator to maintain traceability to the originating routine.
- BR-003 - The error text component of ERROR_STACK is limited to a maximum of 1,968 characters; any text beyond this length is silently truncated to prevent value errors.
- BR-004 - Every error registration must be written to the debug log by calling DEBUGLOG (SP-073) at severity level 99, ensuring all errors are externally observable through the debug output channel.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-070 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Collects and consolidates external error messages into a single string buffer for upstream display or logging. The function first drains the Oracle Forms tool_err error stack, appending each queued message to a running buffer; if no tool_err entries exist it falls back to the current SQL error message (SQLERRM). The concatenated result is returned to the caller so that all pending external errors are surfaced in one pass.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Initialise a local integer counter (iCounter) and a VARCHAR2 buffer (vcErrBuff, max 1968 characters) to accumulate error text.
- Step 2 - Check whether the tool_err error stack contains one or more entries (tool_err.nerrors > 0).
- Step 3 - If the stack is non-empty, iterate from 1 to tool_err.nerrors; on each iteration append a newline character followed by the current top-of-stack message (tool_err.message) to vcErrBuff.
- Step 4 - After each append attempt, handle the VALUE_ERROR exception: if the buffer capacity (1968 characters) is exceeded, exit the loop immediately to prevent overflow.
- Step 5 - After appending the message, pop it off the tool_err stack (tool_err.pop) and advance to the next entry.
- Step 6 - If the tool_err stack was empty, evaluate SQLERRM; if it is not null, append a newline followed by the SQL error message to vcErrBuff.
- Step 7 - Return vcErrBuff (populated or empty) to the caller.

---
**Decision Points**

DP-001

Condition:
tool_err.nerrors > 0 - the tool_err error stack holds at least one pending error message.

TRUE:
Enter the FOR loop and iteratively append each tool_err message to vcErrBuff, popping each entry after it is appended. Exit the loop early if a VALUE_ERROR is raised.

FALSE:
Skip the loop and evaluate the SQLERRM fallback (see DP-002).

---

DP-002

Condition:
SQLERRM is not null - a SQL-level error message is available (evaluated only when tool_err.nerrors = 0).

TRUE:
Append a newline and the SQLERRM text to vcErrBuff.

FALSE:
Leave vcErrBuff unchanged; return it as-is (empty or previously populated).

---

DP-003

Condition:
A VALUE_ERROR exception is raised during the buffer-append operation inside the loop - vcErrBuff has reached or would exceed its 1968-character limit.

TRUE:
Exit the FOR loop immediately, discarding any remaining unprocessed tool_err entries to prevent a runtime overflow.

FALSE:
Continue the loop normally, popping the current entry and processing the next.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The tool_err stack takes precedence over SQLERRM; the SQLERRM fallback is only consulted when tool_err.nerrors equals zero.
- BR-002 - Each error message appended to the buffer must be preceded by a newline character (CHR(10)) to ensure messages are delimited when the buffer is displayed or logged.
- BR-003 - The accumulated error buffer must not exceed 1968 characters; if appending a message would cause a VALUE_ERROR overflow, the loop is exited immediately and no further messages are processed.
- BR-004 - Every tool_err entry that is successfully appended to the buffer must be popped from the stack (tool_err.pop) to prevent duplicate reporting by subsequent callers.
- BR-005 - The function always returns a value (vcErrBuff) to the caller; if neither tool_err entries nor a SQLERRM message are present, an empty string is returned.

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-071 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 text equivalent ('TRUE' or 'FALSE'). This utility function is used by multiple D2KWUTIL stored procedures that require a character representation of a boolean result for display, concatenation, or further string-based processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input BOOLEAN parameter ThisBoolean.
- Step 2 - Evaluate the boolean value of ThisBoolean.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE'.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE'.

---
**Decision Points**

DP-001

Condition:
ThisBoolean IS TRUE

TRUE:
Return the VARCHAR2 string 'TRUE' to the caller.

FALSE:
Return the VARCHAR2 string 'FALSE' to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must always return a non-null VARCHAR2 value; every possible evaluation of the input BOOLEAN results in either 'TRUE' or 'FALSE'.
- BR-002 - The returned string values are fixed literals ('TRUE' / 'FALSE') and must not be localised or altered, as calling procedures in D2KWUTIL depend on these exact string values.
- BR-003 - The function has no dependencies on any internal package, database table, or external routine; its output is derived solely from the supplied input parameter.

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-072 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Resets the module-level error state by clearing the error flag and discarding any accumulated error messages. This utility procedure is called by multiple D2KWUTIL routines prior to or after execution to ensure a clean error context, preventing stale error information from affecting subsequent operations.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Set the module-level boolean variable ERROR_ENCOUNTERED to FALSE, indicating that no error is currently recorded.
- Step 2 - Set the module-level variable ERROR_STACK to NULL, discarding any previously accumulated error message text.
- Step 3 - Return control to the calling routine with both error-state variables in their default, clean state.

---
**Decision Points**

No conditional decision points exist in this procedure. The reset of ERROR_ENCOUNTERED and ERROR_STACK is unconditional on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - ERROR_ENCOUNTERED must be set to FALSE on every invocation, regardless of its prior value, ensuring no residual error flag persists across calls.
- BR-002 - ERROR_STACK must be set to NULL on every invocation, ensuring no residual error message text is carried forward to subsequent processing.
- BR-003 - The procedure accepts no input and produces no formal output; its sole effect is the unconditional reset of the shared error-state variables, making it safe to call at any point in the D2KWUTIL processing lifecycle.

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-073 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

DEBUGLOG writes a formatted diagnostic message to the active debug output channel on behalf of any calling routine within D2kwutil.pld. It gates each log attempt against the current debug state, pause flag, and configured severity threshold, then routes the formatted message either to the Windows debug monitor via WINDEBUG or to a flat text file via TEXT_IO. When the preferred output channel is unavailable, DEBUGLOG transparently falls back to file logging using SETDEBUG and restores the original channel once the monitor becomes available again. The procedure is designed to be silent on failure so that debug instrumentation never disrupts normal form processing.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-079](#SP-079--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-082](#SP-082--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState). If debug logging is disabled (iDebugState = 0), exit immediately without writing any output.
- Step 2 - Evaluate the global pause flag (bDebugPaused). If logging is paused, exit immediately without writing any output.
- Step 3 - Compare the caller-supplied DebugLevel against the configured threshold (iDebugLevel). If DebugLevel exceeds the threshold, exit immediately; the message is below the current verbosity level.
- Step 4 - Optionally prepend a timestamp. If the bDebugTimeStamp flag is set, format SYSDATE as HH24:MI:SS and append a '>' separator to vcDateStamp; otherwise vcDateStamp remains empty.
- Step 5 - Construct the formatted debug string vcDebugString by combining the zero-padded DebugLevel, the optional timestamp, the right-padded LoggingCall label (30 characters), and a truncated substring of LogString so that the total length does not exceed 2,000 characters. WEBUTIL.LENGTH is used implicitly through the package-level length function to compute available space.
- Step 6 - Determine the output channel. If iDebugState = 2 (Windows debug monitor mode), attempt to call WINDEBUG (win_api_debug.WinDebug) to write the message.
- Step 7 - If iDebugState = 2 but DEBUG_API_ENABLED is FALSE (the Windows debug API is unavailable), fall back to file logging: call SETDEBUG to reconfigure the debug session to file mode (mode 1) targeting vcDebugFile (defaulting to 'd2kwutil.log'), log a notice message at level 0, re-invoke DEBUGLOG recursively with the original arguments, and set bDebugType2Required to TRUE to remember that the monitor was the intended channel.
- Step 8 - If iDebugState is not 2 (file logging mode), check whether a deferred restoration is pending (bDebugType2Required = TRUE) and the Windows debug API is now available (DEBUG_API_ENABLED = TRUE). If so, call SETDEBUG to restore debug mode 2, log a restoration notice at level 0, clear bDebugType2Required, and re-invoke DEBUGLOG recursively with the original arguments.
- Step 9 - If no deferred restoration is pending and the mode is file-based, open vcDebugFile in append mode using TEXT_IO.FOPEN, write vcDebugString with TEXT_IO.PUT_LINE, and close the file with TEXT_IO.FCLOSE.
- Step 10 - If any unhandled exception occurs at any point, silently set iDebugState to 0 to disable further logging and prevent debug instrumentation from interfering with normal form execution.

---
**Decision Points**

DP-001

Condition:
iDebugState = 0

TRUE:
Logging is disabled; procedure exits immediately with no action (NULL).

FALSE:
Proceed to DP-002.

---

DP-002

Condition:
bDebugPaused = TRUE

TRUE:
Logging is paused; procedure exits immediately with no action (NULL).

FALSE:
Proceed to DP-003.

---

DP-003

Condition:
DebugLevel > iDebugLevel

TRUE:
The message severity is below the configured threshold; procedure exits immediately with no action (NULL).

FALSE:
The message qualifies for output; proceed to timestamp and string construction.

---

DP-004

Condition:
bDebugTimeStamp = TRUE

TRUE:
Format SYSDATE as HH24:MI:SS and append '> ' to vcDateStamp for inclusion in the log entry.

FALSE:
vcDateStamp remains empty; no timestamp is included in the log entry.

---

DP-005

Condition:
iDebugState = 2 (Windows debug monitor mode)

TRUE:
Attempt to route the message to the Windows debug monitor; proceed to DP-006.

FALSE:
Route the message to file-based logging; proceed to DP-007.

---

DP-006

Condition:
DEBUG_API_ENABLED = TRUE (Windows debug API is available)

TRUE:
Call WINDEBUG (win_api_debug.WinDebug) to write vcDebugString to the Windows debug monitor.

FALSE:
The API is unavailable; call SETDEBUG to switch to file mode (mode 1), log a fallback notice via recursive DEBUGLOG call, re-invoke DEBUGLOG with the original arguments, and set bDebugType2Required to TRUE.

---

DP-007

Condition:
bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE

TRUE:
The Windows debug monitor is now available and was the originally configured channel; call SETDEBUG to restore mode 2, log a restoration notice via recursive DEBUGLOG call, clear bDebugType2Required, and re-invoke DEBUGLOG with the original arguments.

FALSE:
No deferred restoration is pending or the API is still unavailable; open vcDebugFile in append mode, write vcDebugString, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Logging is suppressed entirely when iDebugState equals 0; no output is produced and no resources are accessed.
- BR-002 - Logging is suppressed entirely when bDebugPaused is TRUE, allowing callers to temporarily halt output without disabling the debug session.
- BR-003 - A log entry is only written when the caller-supplied DebugLevel is less than or equal to the configured threshold iDebugLevel; messages with a higher level are silently discarded.
- BR-004 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to fit within the remaining space after the fixed prefix (level indicator, optional timestamp, and padded call label) has been constructed.
- BR-005 - The LoggingCall label is always right-padded to exactly 30 characters in the formatted output to maintain consistent column alignment across log entries.
- BR-006 - When iDebugState = 2 and the Windows debug API (WINDEBUG) is unavailable, the procedure must automatically fall back to file logging via SETDEBUG rather than silently dropping the message or raising an error.
- BR-007 - The fallback file target defaults to 'd2kwutil.log' when vcDebugFile is NULL, ensuring a log destination is always available.
- BR-008 - Once a fallback to file mode has occurred (bDebugType2Required = TRUE), the procedure must automatically restore Windows debug monitor output via SETDEBUG as soon as DEBUG_API_ENABLED becomes TRUE, ensuring the originally configured channel is reinstated without manual intervention.
- BR-009 - Any unhandled exception within DEBUGLOG must be caught and resolved by setting iDebugState to 0; debug instrumentation must never propagate errors to the calling business routine.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-074 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named operating-system environment variable by delegating the low-level DOS/Windows environment lookup to the D2KWUTIL library function D2KWUTIL_GETDOSENV. The function logs its invocation and result via DEBUGLOG, manages the WIN_API error stack, and returns the resolved variable value as a VARCHAR2 string. If the variable cannot be resolved, or if the WIN_API integration layer is unavailable, the function either returns NULL or raises an exception depending on the RaiseExceptions flag supplied by the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the incoming arguments (VariableName and the Boolean RaiseExceptions flag, converted to a character representation via BOOLTOCHAR) at debug level 99 using DEBUGLOG.
- Step 2 - Clear the WIN_API error stack by calling CLEAN_ERROR_STACK to ensure no stale error state influences subsequent processing.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the WIN_API integration layer is active (WIN_API.API_ENABLED). If it is not active, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for D2KWUTIL.D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL, supplying the function handle, name, and parameter type signature.
- Step 6 - Prepare the lookup string by wrapping VariableName in percent signs (e.g. %VAR_NAME%) and initialise a 512-character null-padded output buffer.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV with the function handle, the formatted variable name, the output buffer, and the buffer length (512). Store the integer return code in iRC.
- Step 8 - Log the result of the external call (return-code length and resolved buffer value) via DEBUGLOG at debug level 99.
- Step 9 - Evaluate the outcome: if iRC equals 0 or the output buffer still contains the unexpanded input string (indicating the variable was not found), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If the lookup succeeded, return the resolved environment variable value contained in the output buffer.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log an error via ADD_ERROR using the WIN_API.NoAPI message then re-raise; for all other exceptions, log an error via ADD_ERROR combining WIN_API.UError with any external error detail from ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE:
Raise WIN_API.NOT_AVAILABLE, bypassing all lookup logic.

---

DP-002

Condition:
The return code iRC equals 0 OR the output buffer value equals the unexpanded input string (variable was not resolved).

TRUE:
Log an error via ADD_ERROR. Evaluate DP-003 to determine whether to raise or return NULL.

FALSE:
Return the resolved environment variable value from the output buffer.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE:
Raise NO_DATA_FOUND to signal the unresolved variable to the caller.

FALSE:
Return NULL silently, allowing the caller to handle the absence of a value without an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The WIN_API integration layer must be enabled (WIN_API.API_ENABLED) before any attempt is made to resolve an environment variable; if the layer is unavailable the function must not proceed and must raise WIN_API.NOT_AVAILABLE.
- BR-002 - The environment variable name must be wrapped in percent signs before being passed to D2KWUTIL.D2KWUTIL_GETDOSENV, conforming to the DOS/Windows environment variable expansion convention (e.g. %VAR_NAME%).
- BR-003 - The output buffer passed to D2KWUTIL.D2KWUTIL_GETDOSENV must be pre-allocated to 512 characters padded with null characters (CHR(0)), and the buffer length must be declared as 512.
- BR-004 - A return code of 0 from D2KWUTIL.D2KWUTIL_GETDOSENV, or an output buffer that still contains the unexpanded input string, is treated as a failed lookup; an error must be recorded via ADD_ERROR in both cases.
- BR-005 - The caller controls exception propagation: when RaiseExceptions is TRUE a failed lookup raises NO_DATA_FOUND; when RaiseExceptions is FALSE (the default) the function returns NULL instead, enabling non-fatal usage.
- BR-006 - All exceptions except NO_DATA_FOUND must be logged via ADD_ERROR before being re-raised; unhandled errors must additionally incorporate external error detail retrieved via ADD_EXTERNAL_ERRORS.
- BR-007 - Entry arguments and the resolved result must be written to the debug log via DEBUGLOG (at level 99) to support traceability of environment variable resolution at runtime.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-075 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows temporary directory path for the current session by invoking the D2KWUTIL Windows API utility. The function registers and calls the underlying OS-level directory lookup, strips any trailing directory separator from the result, and returns the clean path as a VARCHAR2 string. Diagnostic entries are written via DEBUGLOG at entry and exit. If the API is unavailable or returns no value, the function either raises an exception or returns NULL depending on the caller-supplied flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Write a diagnostic entry via DEBUGLOG (level 99) recording the procedure name and the value of the RaiseExceptions input parameter, converted to a readable string using BOOLTOCHAR.
- Step 2 - Clear any pre-existing error stack by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Windows API layer is enabled (WIN_API.API_ENABLED).
- Step 5 - If the API is enabled, register the external function call using REGISTER_FUNCTION_CALL, binding the iTmpDir handle to the 'd2kwutil_TmpDir' entry point with the appropriate signature.
- Step 6 - Initialise a 512-character buffer (vcBuff1) padded with null characters to receive the directory path.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and its length (512); capture the integer return code in iRC.
- Step 8 - Write a second DEBUGLOG entry recording the return code and the raw buffer value returned by the API call.
- Step 9 - If iRC equals 0 (no value returned), log an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero (success), pass the populated buffer to STRIPDIRSEP to remove any trailing directory separator and return the resulting clean path to the caller.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE log the no-API message via ADD_ERROR and re-raise; for all other exceptions log the unexpected error message combined with ADD_EXTERNAL_ERRORS via ADD_ERROR and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function, allocate the output buffer, and call D2KWUTIL.D2KWUTIL_WINDIR to obtain the temporary directory path.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
The return code iRC returned by D2KWUTIL.D2KWUTIL_WINDIR equals 0 (indicating no directory value was returned).

TRUE:
Log an error via ADD_ERROR. Evaluate the RaiseExceptions flag (see DP-003).

FALSE:
Pass the populated buffer to STRIPDIRSEP and return the cleaned temporary directory path to the caller.

---

DP-003

Condition:
iRC equals 0 AND RaiseExceptions is TRUE.

TRUE:
Raise NO_DATA_FOUND, which is immediately re-raised to the caller by the exception handler.

FALSE:
Return NULL to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED) before any attempt is made to retrieve the temporary directory; if it is not active the function is unconditionally aborted and WIN_API.NOT_AVAILABLE is raised.
- BR-002 - The external function 'd2kwutil_TmpDir' must be registered via REGISTER_FUNCTION_CALL with the exact signature ('INT','*CHAR,INT') before D2KWUTIL.D2KWUTIL_WINDIR is invoked; this binding is performed on every call rather than assumed to be pre-registered.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition (no value returned); a non-zero return code indicates a successful directory retrieval.
- BR-004 - When the API returns no value (iRC = 0), the caller's RaiseExceptions flag governs error propagation: TRUE causes a NO_DATA_FOUND exception; FALSE causes a silent NULL return, allowing non-critical callers to handle the absence of a temp directory without exception handling.
- BR-005 - The returned path is always normalised by STRIPDIRSEP before being handed back to the caller, ensuring no trailing directory separator is present in the result.
- BR-006 - Diagnostic logging via DEBUGLOG at severity level 99 is mandatory at both entry (recording RaiseExceptions via BOOLTOCHAR) and after the API call (recording the raw return code and buffer), providing a full audit trail for troubleshooting.
- BR-007 - All exception paths (WIN_API.NOT_AVAILABLE and OTHERS) must record an error via ADD_ERROR before re-raising; unexpected errors additionally append any external error detail collected by ADD_EXTERNAL_ERRORS.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-076 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows directory path on the client machine by invoking the native D2KWUTIL utility function D2KWUTIL_WINDIR. The function registers the external call, captures the returned directory string, strips any trailing directory separator, and returns the clean path to the caller. Error handling is configurable via the RaiseExceptions flag, allowing the caller to choose between silent NULL returns and raised exceptions when no value is obtained.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-010](#SP-010--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-080](#SP-080--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry point and input argument value using DEBUGLOG, recording the RaiseExceptions flag converted to a character representation via BOOLTOCHAR.
- Step 2 - Clear any pre-existing error state by calling CLEAN_ERROR_STACK.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Win API is available (WIN_API.API_ENABLED). If not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 5 - Register the external function call for D2KWUTIL_WINDIR with its expected signature ('INT','*CHAR,INT') using REGISTER_FUNCTION_CALL, binding it to the iWinDir handle.
- Step 6 - Initialise the output buffer vcBuff1 as a 512-character null-padded string.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and its length (512), capturing the integer return code in iRC.
- Step 8 - Log the result, including the return code and the raw buffer contents, using DEBUGLOG.
- Step 9 - Evaluate iRC: if iRC equals 0, the external call returned no value; record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero, strip the trailing directory separator from vcBuff1 using STRIPDIRSEP and return the cleaned path to the caller.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR and re-raise; for all other exceptions, log the error with additional external error detail via ADD_ERROR and ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the Win API layer is available and initialised.

TRUE:
Proceed to register the external function call and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the Windows directory path.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 - the external call to D2KWUTIL_WINDIR returned a zero result code, indicating no directory value was returned.

TRUE:
Log an error via ADD_ERROR. Then evaluate the RaiseExceptions flag (see DP-003).

FALSE:
Strip the trailing directory separator from the buffer using STRIPDIRSEP and return the resulting path string.

---

DP-003

Condition:
RaiseExceptions is TRUE - the caller has requested that a missing return value be treated as a hard failure.

TRUE:
Raise the NO_DATA_FOUND exception, which propagates to the caller.

FALSE:
Return NULL silently to the caller without raising an exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must not execute the external Windows directory lookup unless the Win API layer is confirmed available; if unavailable, the WIN_API.NOT_AVAILABLE exception is raised and the error is recorded before propagation.
- BR-002 - A zero return code from D2KWUTIL_WINDIR is treated as a failure condition; the function never returns an empty or uninitialised buffer as a valid directory path.
- BR-003 - The caller controls failure-mode behaviour via the RaiseExceptions flag: TRUE causes a NO_DATA_FOUND exception on missing data; FALSE causes a NULL return, allowing the caller to handle the absence gracefully.
- BR-004 - All returned directory paths must have their trailing directory separator removed via STRIPDIRSEP before being returned, ensuring a consistent path format for downstream consumers.
- BR-005 - Every invocation must be logged at entry (with the RaiseExceptions argument) and at result (with the return code and raw buffer) using DEBUGLOG to support diagnostics and audit traceability.
- BR-006 - All error conditions must be recorded in the Win API error stack via ADD_ERROR (and ADD_EXTERNAL_ERRORS for unhandled exceptions) before any exception is re-raised, ensuring the error context is available to the caller.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-077 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named entry from the Windows Registry at a caller-supplied path and returns its value as a VARCHAR2 string. The procedure resolves the registry root hive from the path prefix, delegates the actual Win32 read to the D2KWUtil native library call D2KWUTIL.D2KWUTIL_GETREGKEY, and surfaces any retrieval errors either as NULL return values or as raised exceptions depending on the RaiseExceptions flag. Diagnostic progress and results are written to the debug log via DEBUGLOG throughout execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-071](#SP-071--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-072](#SP-072--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-009](#SP-009--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry diagnostics: call DEBUGLOG (severity 99) recording the RegPath, RegEntry, and the Boolean RaiseExceptions flag converted to a character representation via BOOLTOCHAR.
- Step 2 - Clear the error stack by invoking CLEAN_ERROR_STACK to ensure no stale errors influence downstream error handling.
- Step 3 - Check API availability via WIN_API.API_ENABLED; if the Win32 API layer is unavailable raise WIN_API.NOT_AVAILABLE immediately.
- Step 4 - Register the native function handle for D2KWUTIL_GETREGKEY by calling REGISTER_FUNCTION_CALL, binding the function signature used for the subsequent low-level call.
- Step 5 - Determine the registry root hive by extracting the prefix of RegPath (the segment before the first backslash) and mapping it to the integer constant expected by D2KWUTIL_GETREGKEY: HKEY_LOCAL_MACHINE->0, HKEY_CLASSES_ROOT->1, HKEY_CURRENT_USER->2, HKEY_USERS->3, HKEY_CURRENT_CONFIG->4.
- Step 6 - If the root prefix does not match any known hive, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND; otherwise continue (the subsequent native call will not be reached because iBuff1 is unset).
- Step 7 - Prepare call buffers: set the sub-path (RegPath after the first backslash) into vcBuff1, the entry name into vcBuff2, initialise the 2000-byte result buffer vcBuff3 padded with CHR(0), and set the buffer-length indicator iBuff2 to 2000.
- Step 8 - Evaluate the compatibility flag WIN_API.COMPAT_EXPAND_REG_VALUES; if expansion is suppressed set iBuff3 to 1 and log a compatibility diagnostic via DEBUGLOG, otherwise set iBuff3 to 0 to allow environment-variable expansion.
- Step 9 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the resolved function handle, root integer, sub-path, entry name, result buffer, buffer length, and expansion flag; capture the integer return code in iRC.
- Step 10 - Log the result via DEBUGLOG recording iRC and the raw value returned in vcBuff3.
- Step 11 - Evaluate iRC for error codes: -1 (entry not found), -2 (unsupported data type), -3 (value exceeds buffer length), -4 (environment-string expansion failure). For each error code call ADD_ERROR with a descriptive message; return NULL if RaiseExceptions is FALSE, otherwise raise NO_DATA_FOUND (codes -1, -2, -4) or VALUE_ERROR (code -3).
- Step 12 - If iRC indicates success (not -1 through -4), return vcBuff3 containing the registry value.
- Step 13 - In the exception block: re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE call ADD_ERROR with the NoAPI message then re-raise; for all other exceptions call ADD_ERROR with the generic unhandled-error message appended with ADD_EXTERNAL_ERRORS output, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE

TRUE:
Proceed with registry root resolution, function registration, buffer preparation, and the D2KWUTIL_GETREGKEY call.

FALSE:
Raise WIN_API.NOT_AVAILABLE; execution transfers to the exception handler which logs the error via ADD_ERROR and re-raises.

---

DP-002

Condition:
The extracted root prefix of RegPath matches one of the five known hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG)

TRUE:
Assign the corresponding integer constant (0-4) to iBuff1 and continue buffer preparation.

FALSE:
Call ADD_ERROR reporting an invalid registry key; if RaiseExceptions is TRUE raise NO_DATA_FOUND, otherwise continue (native call will not execute meaningfully).

---

DP-003

Condition:
WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE (expansion is permitted)

TRUE:
Set iBuff3 to 0, allowing D2KWUTIL_GETREGKEY to expand environment variables within the registry value.

FALSE:
Set iBuff3 to 1 suppressing environment-variable expansion, and log a compatibility diagnostic via DEBUGLOG.

---

DP-004

Condition:
Return code iRC from D2KWUTIL_GETREGKEY equals -1 (registry entry not found)

TRUE:
Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE:
Evaluate next error-code condition (DP-005).

---

DP-005

Condition:
Return code iRC equals -2 (unsupported registry data type)

TRUE:
Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE:
Evaluate next error-code condition (DP-006).

---

DP-006

Condition:
Return code iRC equals -3 (registry value exceeds the 2000-byte buffer)

TRUE:
Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise VALUE_ERROR if RaiseExceptions is TRUE.

FALSE:
Evaluate next error-code condition (DP-007).

---

DP-007

Condition:
Return code iRC equals -4 (environment-string expansion failed)

TRUE:
Call ADD_ERROR; return NULL if RaiseExceptions is FALSE, raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE:
No error condition applies; return vcBuff3 as the registry value.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Win32 API layer must be enabled (WIN_API.API_ENABLED) before any registry access is attempted; if unavailable the procedure raises WIN_API.NOT_AVAILABLE and records the reason via ADD_ERROR.
- BR-002 - The registry root hive must be one of the five recognised Windows hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG) supplied as the leading segment of RegPath; any other value is treated as an invalid key.
- BR-003 - The result buffer is fixed at 2000 bytes; registry values longer than this limit produce error code -3 and are reported as oversized via ADD_ERROR.
- BR-004 - Environment-variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag; when suppressed, the raw unexpanded string is returned.
- BR-005 - Error surfacing behaviour is governed entirely by the RaiseExceptions input parameter: FALSE causes the procedure to return NULL on any retrieval failure; TRUE causes the appropriate PL/SQL exception (NO_DATA_FOUND or VALUE_ERROR) to be raised.
- BR-006 - All error conditions must be recorded through ADD_ERROR before returning NULL or raising an exception, ensuring the error stack is populated for upstream handlers.
- BR-007 - ADD_EXTERNAL_ERRORS is appended to the unhandled-exception error message to capture any additional external error context not covered by the standard error codes.
- BR-008 - DEBUGLOG calls at severity 99 must bracket the operation (entry arguments including the BOOLTOCHAR representation of RaiseExceptions, and the raw result with return code) to support runtime diagnostics without affecting functional behaviour.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-078 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Ensures that a Windows DLL function is registered with the ORA_FFI foreign-function interface before it is called by any D2KWUTIL or Win_API routine. The procedure first confirms the target DLL is loaded (attempting a reload via D2KWUTIL.ATTEMPT_DLL_LOAD if necessary), then registers the function handle, its parameter types (translated via D2KWUTIL.TRANSLATETYPE), and its return type only when the function has not yet been registered or when the DLL has been reloaded since the last registration. Diagnostic entries are written through DEBUGLOG, and any FFI or load failures are surfaced to the user through ADD_ERROR and ADD_EXTERNAL_ERRORS.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-003](#SP-003--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-013](#SP-013--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-060](#SP-060--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the DLL in memory using ORA_FFI.FIND_LIBRARY. If the library is found, execution continues; if an FFI error is raised, fall through to Step 2.
- Step 2 - On DLL-not-found error, call D2KWUTIL.ATTEMPT_DLL_LOAD to reload the DLL from the configured path. If the reload also fails with an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record a 'DLL not found' message, and raise NO_DATA_FOUND to abort processing.
- Step 3 - Compare the cached load-count for the supplied FunctionID (FunctionLoad array) against the current DLL_LOAD_COUNT. If no cache entry exists or the counts differ, the function must be (re-)registered; otherwise skip to Step 9.
- Step 4 - Register the function with the DLL handle using ORA_FFI.REGISTER_FUNCTION (C_STD calling convention), storing the resulting handle in FunctionHandle(FunctionID).
- Step 5 - If the function being registered is not the internal debug function ('d2kwutil_DebugString'), call DEBUGLOG (via Win_API_Debug.DebugLog at level 99) to record either an initial registration or a re-registration event, including the function name and current DLL load count.
- Step 6 - Append a comma delimiter to FunctionArgs and iterate through the comma-separated argument type tokens. For each token, call D2KWUTIL.TRANSLATETYPE to convert the string type name to the corresponding ORA_FFI type constant, then call ORA_FFI.REGISTER_PARAMETER to register it against the function handle. Use WEBUTIL.LENGTH (via the instr/substr/length logic) to determine token boundaries and advance the cursor; exit the loop when the argument string is exhausted or equals 'VOID'.
- Step 7 - After all parameters are registered, check whether FunctionReturn is non-NULL and not 'VOID'. If so, call D2KWUTIL.TRANSLATETYPE on the return-type string and register it with ORA_FFI.REGISTER_RETURN.
- Step 8 - Store DLL_LOAD_COUNT in FunctionLoad(FunctionID) to cache the registration state and prevent redundant re-registration on future calls.
- Step 9 - If an ORA_FFI.FFI_ERROR is raised at the outer level (e.g., during parameter or return-type registration), call ADD_ERROR with the function name and the concatenated error text from ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND to abort the calling routine.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY raises ORA_FFI.FFI_ERROR (DLL not currently loaded).

TRUE:
Call D2KWUTIL.ATTEMPT_DLL_LOAD to reload the DLL. If that also fails, set API_ENABLED = FALSE, call ADD_ERROR, and raise NO_DATA_FOUND.

FALSE:
DLL is already loaded; continue with registration check.

---

DP-002

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD raises ORA_FFI.FFI_ERROR (reload also fails).

TRUE:
Set API_ENABLED = FALSE, call ADD_ERROR with 'DLL not found' message, raise NO_DATA_FOUND.

FALSE:
DLL reloaded successfully; continue with registration check.

---

DP-003

Condition:
FunctionLoad array does not contain an entry for FunctionID, OR FunctionLoad(FunctionID) differs from DLL_LOAD_COUNT.

TRUE:
Proceed with full registration: register function handle, parameters, and return type, then update the cache.

FALSE:
Function is already registered against the current DLL load; skip all registration steps.

---

DP-004

Condition:
FunctionName equals 'd2kwutil_DebugString'.

TRUE:
Skip the DEBUGLOG diagnostic call to avoid recursive logging.

FALSE:
Call DEBUGLOG to record initial registration or re-registration details.

---

DP-005

Condition:
FunctionLoad.exists(FunctionID) is FALSE (first-time registration for this function).

TRUE:
Log an 'Initial Reg' message via DEBUGLOG.

FALSE:
Log a 'Re-Registration Count' message via DEBUGLOG, including the previous load-count value.

---

DP-006

Condition:
The remaining FunctionArgs string is NULL, equals ',', or equals 'VOID,' (no more parameter tokens to process).

TRUE:
Exit the parameter-registration loop.

FALSE:
Extract the next comma-delimited token, call D2KWUTIL.TRANSLATETYPE, register the parameter, and advance the cursor.

---

DP-007

Condition:
FunctionReturn is not NULL AND UPPER(FunctionReturn) <> 'VOID'.

TRUE:
Call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register it as the ORA_FFI return type.

FALSE:
No return type is registered (procedure or explicitly void function).

---

DP-008

Condition:
ORA_FFI.FFI_ERROR is raised in the outer exception handler (during function/parameter/return registration).

TRUE:
Call ADD_ERROR with FunctionName and the error text from ADD_EXTERNAL_ERRORS; raise NO_DATA_FOUND.

FALSE:
No exception; procedure completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The DLL must be locatable in memory before any function registration is attempted; if ORA_FFI.FIND_LIBRARY fails, D2KWUTIL.ATTEMPT_DLL_LOAD must be invoked as a recovery step before the operation is abandoned.
- BR-002 - If the DLL cannot be loaded by any means, the API is disabled (API_ENABLED = FALSE), an error is recorded via ADD_ERROR, and NO_DATA_FOUND is raised to prevent any further FFI calls in the calling routine.
- BR-003 - A function is registered (or re-registered) only when no cache entry exists for its FunctionID or when the cached DLL load-count does not match the current DLL_LOAD_COUNT, ensuring stale handles from a prior DLL load are never used.
- BR-004 - All parameter type strings supplied in FunctionArgs must be translated to ORA_FFI type constants via D2KWUTIL.TRANSLATETYPE before being passed to ORA_FFI.REGISTER_PARAMETER; raw string type names are not passed directly to the FFI layer.
- BR-005 - A return type is registered only for non-void functions; if FunctionReturn is NULL or equals 'VOID' (case-insensitive), ORA_FFI.REGISTER_RETURN is not called.
- BR-006 - The internal debug function 'd2kwutil_DebugString' is exempt from DEBUGLOG diagnostic calls during its own registration to prevent recursive logging.
- BR-007 - On successful registration, FunctionLoad(FunctionID) is set to the current DLL_LOAD_COUNT to serve as the authoritative cache marker for future calls.
- BR-008 - Any FFI error raised during parameter or return-type registration is surfaced to the caller by concatenating ADD_EXTERNAL_ERRORS output with the function name via ADD_ERROR, followed by raising NO_DATA_FOUND; the error is never silently swallowed.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-079 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment by setting the debug output type (file, screen, or off), the target log file name, the logging verbosity level, and whether log entries should include timestamps. Once the configuration is applied, the procedure announces the resulting logging state via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-073](#SP-073--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept four input parameters: DebugType (output destination selector), DebugFile (target file name, defaults to NULL), DebugLevel (verbosity threshold, defaults to 98), and TimeStamp (flag controlling timestamp inclusion, defaults to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp so that all subsequent log calls respect the timestamp preference.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile so that file-based logging calls reference the correct output file.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel so that subsequent log calls apply the correct verbosity filter.
- Step 5 - Evaluate DebugType to determine the logging destination and set iDebugState accordingly (see Decision Points).
- Step 6 - Call DEBUGLOG to record a confirmation message reflecting the outcome of the configuration change.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging) and call DEBUGLOG with the message 'Logging to File ' concatenated with the DebugFile value.

FALSE: Evaluate DP-002.

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (screen/alternative logging) and call DEBUGLOG with the message 'Logging Started'.

FALSE: Call DEBUGLOG with the message 'Logging Stopped' and set iDebugState to 0, disabling all debug logging.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType = 1 activates file-based logging; the target file is identified by the DebugFile parameter, which must be supplied by the caller when file logging is required.
- BR-002 - DebugType = 2 activates non-file (screen/alternative) logging; DebugFile is not used in this mode.
- BR-003 - Any DebugType value other than 1 or 2 disables logging entirely by setting iDebugState to 0.
- BR-004 - The default DebugLevel of 98 applies when the caller does not supply an explicit verbosity level, representing the broadest practical logging threshold.
- BR-005 - Timestamp inclusion in log entries is opt-in; the TimeStamp parameter defaults to FALSE, meaning timestamps are suppressed unless explicitly requested.
- BR-006 - Every invocation of SETDEBUG produces exactly one confirmation log entry via DEBUGLOG, regardless of the logging state being activated or deactivated.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-080 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sanitises a raw directory path string by removing any semicolon-delimited suffix and any trailing backslash, returning a clean, single-path value suitable for use in DLL load attempts and directory resolution routines.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-052](#SP-052--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw input path string (InPath) and assign it to a working variable (vcPath).
- Step 2 - Search vcPath for the first occurrence of a semicolon character.
- Step 3 - If a semicolon is found, truncate vcPath to retain only the substring before that semicolon, discarding any additional path entries.
- Step 4 - Inspect the last character of the (possibly truncated) vcPath for a trailing backslash.
- Step 5 - If a trailing backslash is present, remove it by taking all characters except the final one.
- Step 6 - Return the sanitised path string to the caller.

---
**Decision Points**

DP-001

Condition:
The position of the first semicolon in vcPath is greater than zero (i.e., a semicolon exists in the path string).

TRUE:
Truncate vcPath to the substring preceding the semicolon, effectively discarding any secondary or additional path entries.

FALSE:
Leave vcPath unchanged and proceed to the trailing-backslash check.

---

DP-002

Condition:
The last character of vcPath is a backslash ('\').

TRUE:
Remove the trailing backslash by returning the substring from position 1 to length minus one.

FALSE:
Leave vcPath unchanged and return it as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the portion of the path string before the first semicolon is considered a valid directory path; any text from the semicolon onward is discarded.
- BR-002 - A valid directory path must not end with a trailing backslash; if one is present it must be stripped before the path is returned.
- BR-003 - The function does not invoke WEBUTIL.LENGTH (SP-052) directly in its logic; path length is managed via the native PL/SQL LENGTH function, and SP-052 is listed as a package-level dependency only.
- BR-004 - The sanitised path is returned as the function result and is not written to any database table; all processing is in-memory.

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-081 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- vr_penetrate_dlr_fmb.xml [ProgramUnit: EXCEL_REPORT]

---

**Screen:**

N/A

---

**Purpose**

Generates and delivers a CSV/Excel report to the client workstation. The procedure determines the appropriate report-generation path based on whether a dedicated report server is configured for the given principal and application. If a report server is available, it delegates CSV generation to a remote database procedure and transfers the resulting file to the client. If no report server is configured, it builds the report locally using an Oracle Forms record group populated from the supplied query, writes the output to a server-side file, and then transfers it to the client. In both paths the file is opened on the client desktop via a host command.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-027](#SP-027--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-028](#SP-028--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-030](#SP-030--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-043](#SP-043--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-046](#SP-046--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-047](#SP-047--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-055](#SP-055--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-066](#SP-066--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS to retrieve the report server (rep_server) associated with the supplied p_principal and p_app_id. If no matching row exists, lv_rep_server is set to NULL.
- Step 2 - Evaluate whether lv_rep_server is populated to determine which generation path to follow (report-server path vs. local record-group path).
- Step 3 (both paths) - Determine the output file name: if p_file_name is NULL, invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user for a save location; otherwise use p_file_name directly. Append the '.csv' extension (report-server path only appends the extension explicitly; the local path uses the name as resolved).
- Step 4 (both paths) - Validate that the resolved file name contains no spaces in its folder path. If spaces are detected, redirect the file to 'C:\' using only the bare file name and display a warning message to the user.
- Step 5a (report-server path) - Call sp_csv_report_generate via the remote database link (dms1_db3_lnk), passing the file name and query, to generate the CSV on the report server.
- Step 5b (report-server path) - Move the generated file from /utl_dir/ to /iashome/ias/reports/printer/ using WEBUTIL.HOST with a Unix mv command.
- Step 6a (local path) - Check whether a record group named 'DataRecordSet' already exists using Find_Group; if it does, delete it with Delete_Group.
- Step 6b (local path) - Create a new record group from the supplied p_query using Create_Group_From_Query, populate it with Populate_Group, and retrieve the row count with Get_Group_Row_Count.
- Step 6c (local path) - Open a server-side write file at /iashome/ias/reports/printer/ using WEBUTIL.FOPEN (TEXT_IO.FOPEN), locate the target column in the record group using Find_Column with p_column_name, iterate over all rows, and write each cell value followed by a newline using WEBUTIL.PUTF (TEXT_IO.PUTF). Close the file with WEBUTIL.FCLOSE (TEXT_IO.FCLOSE).
- Step 7 (both paths) - Read the base URL path from the server-side configuration file /reports/DMS/excelpath.txt using WEBUTIL.FOPEN (TEXT_IO.Fopen) and WEBUTIL.GET_LINE (Text_Io.Get_Line), then close the file with WEBUTIL.FCLOSE.
- Step 8 (both paths) - Construct the full URL (formserverpath) by concatenating the URL path with the bare file name, then transfer the file to the client using WEBUTIL.URL_TO_CLIENT.
- Step 9 (both paths) - If the file transfer fails (returns FALSE), display a 'File Transfer failed' message and pause.
- Step 10 (both paths) - Open the transferred file on the client desktop by invoking WEBUTIL.HOST with 'cmd /c <FILENAME>'.
- Step 11 - If any unhandled exception occurs, display an error message combining ERROR_CODE and ERROR_TEXT, then raise Form_trigger_failure.

---
**Decision Points**

DP-001

Condition:
lv_rep_server IS NOT NULL (a report server entry was found in EH_REPORTS for the given p_principal and p_app_id).

TRUE:
Follow the report-server path: delegate CSV generation to sp_csv_report_generate via the remote database link, move the file on the server, read the URL path, transfer the file to the client, and open it.

FALSE:
Follow the local record-group path: build the report in-process using Oracle Forms record groups, write the output file directly to the server, read the URL path, transfer the file to the client, and open it.

---

DP-002

Condition:
p_file_name IS NULL.

TRUE:
Invoke WEBUTIL.FILE_SAVE_DIALOG to prompt the user to choose a save location and file name.

FALSE:
Use p_file_name as the output file name directly.

---

DP-003

Condition:
INSTR(FILENAME, ' ') > 0 (the resolved file path contains at least one space in a folder name).

TRUE:
Override the path to 'C:\' using only the bare file name extracted from the last backslash, and display a warning message informing the user that the file will be stored on the C drive.

FALSE:
Proceed with the resolved file name unchanged.

---

DP-004

Condition:
Id_Null(rg_id) is FALSE, i.e., a record group named 'DataRecordSet' already exists (local path only).

TRUE:
Delete the existing record group with Delete_Group before creating a new one.

FALSE:
Proceed directly to creating the record group.

---

DP-005

Condition:
file_transfer_bool is FALSE (WEBUTIL.URL_TO_CLIENT returned a failure indicator).

TRUE:
Display a 'File Transfer failed' message and pause execution.

FALSE:
Continue to open the file on the client desktop.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The report generation path (remote server vs. local record group) is determined exclusively by the presence of a rep_server value in EH_REPORTS for the combination of p_principal and p_app_id; if no row matches, the local path is always used.
- BR-002 - A '.csv' extension is always appended to the file name in the report-server path, ensuring the output file is identifiable as a CSV regardless of the value supplied in p_file_name.
- BR-003 - File names whose folder path contains spaces are not supported; the procedure automatically redirects such files to the root of the C drive and notifies the user, preventing file-save failures caused by path-space limitations.
- BR-004 - In the local record-group path, any pre-existing record group named 'DataRecordSet' must be destroyed before a new one is created, ensuring the report always reflects the current query and not stale data from a prior execution.
- BR-005 - Report data written in the local path is limited to a single column identified by p_column_name; each cell value is written as a separate line (delimited by CHR(10)) in the output file.
- BR-006 - The server-side base URL used for file transfer is not hard-coded; it is read at runtime from the configuration file /reports/DMS/excelpath.txt, allowing the deployment URL to be changed without modifying the procedure.
- BR-007 - File transfer to the client is performed via WEBUTIL.URL_TO_CLIENT; a failed transfer must be reported to the user with a message and a pause, but does not raise an exception - execution continues to the host-open command.
- BR-008 - The transferred file is automatically opened on the client desktop using WEBUTIL.HOST with a Windows 'cmd /c' command, providing immediate access to the report without additional user action.
- BR-009 - Any unhandled runtime exception causes the procedure to display the Oracle Forms ERROR_CODE and ERROR_TEXT and then raise Form_trigger_failure, ensuring the calling trigger is notified of the failure.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-082 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a controlled interface for writing a debug string to an external Win32 debug output channel via the D2KWUTIL utility library. It accepts a text string, appends a newline character, and delegates the actual output call to D2KWUTIL.D2KWUTIL_DEBUGSTRING through a registered function handle. If the underlying Win32 API layer is unavailable or an unexpected error occurs, the procedure captures and surfaces a structured error message before re-raising the exception.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-069](#SP-069--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-070](#SP-070--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-078](#SP-078--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameter Text (VARCHAR2) and initialise a local buffer variable vcBuff1 by concatenating Text with a newline character (CHR(10)).
- Step 2 - Check whether the Win32 API layer is enabled by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the debug-string function call by invoking REGISTER_FUNCTION_CALL, passing the internal debug-string handle (iDebugString), the function name 'd2kwutil_DebugString', NULL, and the argument type indicator '*CHAR'.
- Step 4 - Execute the external debug output by calling D2KWUTIL.D2KWUTIL_DEBUGSTRING with the resolved function handle (WIN_API.FunctionHandle(iDebugString)) and the prepared buffer vcBuff1.
- Step 5 - If the API is not enabled, raise the WIN_API.NOT_AVAILABLE exception to signal that the operation cannot proceed.
- Step 6 - In the WIN_API.NOT_AVAILABLE exception handler, log a structured error via ADD_ERROR (identifying the source as 'WinDebug' and the error code as WIN_API.NoAPI), then re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, log a structured error via ADD_ERROR (identifying the source as 'WinDebug' and combining WIN_API.UError with any supplementary external error details retrieved through ADD_EXTERNAL_ERRORS), then re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
Proceed to register the function call via REGISTER_FUNCTION_CALL and invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING to write the debug string to the external output channel.

FALSE:
Raise WIN_API.NOT_AVAILABLE to indicate that the Win32 API layer is not accessible.

---

DP-002

Condition:
The WIN_API.NOT_AVAILABLE exception is raised (either explicitly from DP-001 FALSE branch or propagated from a called routine).

TRUE:
Log an error via ADD_ERROR with source 'WinDebug' and error code WIN_API.NoAPI, then re-raise the exception.

FALSE:
Not applicable; this handler is entered only when the specific exception fires.

---

DP-003

Condition:
An unhandled exception other than WIN_API.NOT_AVAILABLE is raised during execution.

TRUE:
Log an error via ADD_ERROR with source 'WinDebug' and a composite message combining WIN_API.UError and the output of ADD_EXTERNAL_ERRORS, then re-raise the exception.

FALSE:
Not applicable; this OTHERS handler is entered only when an unexpected exception fires.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must always be appended with a newline character (CHR(10)) before being passed to the external debug output function; this ensures each debug message is terminated on its own line in the output channel.
- BR-002 - The procedure may only invoke the external D2KWUTIL debug string function when WIN_API.API_ENABLED is TRUE; execution is not permitted if the Win32 API layer is unavailable.
- BR-003 - The function call must be registered via REGISTER_FUNCTION_CALL before D2KWUTIL.D2KWUTIL_DEBUGSTRING is invoked; this establishes the required function handle used to resolve the external call.
- BR-004 - All exceptions must be re-raised after error logging, ensuring that callers (including the parent DEBUGLOG procedure in D2KWUTIL.pld) receive notification of any failure rather than silently swallowing errors.
- BR-005 - Errors arising from the unavailability of the Win32 API are recorded using the WIN_API.NoAPI error code; all other unexpected errors are recorded using WIN_API.UError supplemented by any additional details returned by ADD_EXTERNAL_ERRORS.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

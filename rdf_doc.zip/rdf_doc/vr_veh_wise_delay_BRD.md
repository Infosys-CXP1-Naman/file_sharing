# BUSINESS REQUIREMENTS DOCUMENT

## Table of Contents

- 1. Document Control
  - 1.1 Document Information
  - 1.2 Revision History
- 2. Executive Summary
  - Key Stakeholders
- 3. System Context
- 4. Functional Requirements
  - 4.1 Business Requirements
    - Requirement ID: BR-001
    - Requirement ID: BR-002
    - Requirement ID: BR-003
    - Requirement ID: BR-004
    - Requirement ID: BR-005
    - Requirement ID: BR-006
    - Requirement ID: BR-007
    - Requirement ID: BR-008
  - 4.2 Inactive Code Register
- 5. Business Rules Catalogue
- 6. Data Requirements
  - 6.1 Business Entities and Relationships
    - Repair Order - VH_RO
    - Vehicle Tracking Hold Record - VT_VTS_HOLD
    - Vehicle Hold Reason Master - VM_PROC_HOLD_REASON
    - Entity Relationships
  - 6.2 Data Capture Requirements
    - Report Filter Criteria (Report User - before searching)
    - Parameters and Session Values
  - 6.3 Reference Data
  - 6.4 Data Lifecycle
  - 6.5 Excel Output Columns
- 7. Glossary
- 8. Technical Inventory
  - 8.1 Form Architecture
    - 8.1.1 Global Variables
    - 8.1.2 Form Parameters
  - 8.2 Blocks
    - 8.2.1 Block WhereClause and OrderByClause
  - 8.3 Items Summary
  - 8.4 List of Values
  - 8.5 Alerts
  - 8.6 Program Units
  - 8.7 Triggers
    - 8.7.1 Inactive / Commented-Out Trigger Register
  - 8.8 Canvas and Window Inventory
  - 8.9 Editors
  - 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups
    - 8.10.1 Visual Attributes (form-defined)
    - 8.10.2 Property Classes (form-defined)
    - 8.10.3 Object Groups
  - 8.11 DataSourceColumn Inventory
- 9. Object Library
- 10. Record Groups
- 11. Referenced Database Objects
- 12. Backend Procedures and Packages
  - 12.1 Main Flow Backend Procedure/Package Index
  - 12.2 Procedure and Package Catalogue
- 13. Package Procedure Specifications
- 14. Database Package Catalogue
- 15. PLD Procedure Call Sites
  - DPL.pld (`general`)
  - Inactive / commented-only PLD call sites
  - webutil.pld (`WEBUTIL_CORE`)
  - webutil.pld (`WEBUTIL_C_API`)
- 16. Microservice API Candidates
  - 16.1 Microservices with APIs
- 17. Workflows
- 18. PLD-Backed Logic
  - webutil.pld (`CLIENT_IMAGE`)
  - DPL.pld (`general`)
  - D2kwutil.pld (`Win_API`)
- 19. PCK-Backed Logic
- 20. System Interfaces
  - 20.1 Database Integrations
  - 20.2 External System Integrations
  - 20.3 Report Integrations
    - 20.3.1 Parameters Passed to the Report
- 21. Procedure and Function Business Rule Catalogue
  - 21.1 Catalogue Index
  - 21.2 Detailed Specifications
    - SP-001 - D2KWUTIL.ATTEMPT_DLL_LOAD
    - SP-002 - D2KWUTIL.CHOOSEFILE
    - SP-003 - D2KWUTIL.D2KWUTIL_ACTIVEWIN
    - SP-004 - D2KWUTIL.D2KWUTIL_CHOOSEFILE
    - SP-005 - D2KWUTIL.D2KWUTIL_DEBUGSTRING
    - SP-006 - D2KWUTIL.D2KWUTIL_GETDOSENV
    - SP-007 - D2KWUTIL.D2KWUTIL_GETREGKEY
    - SP-008 - D2KWUTIL.D2KWUTIL_WINDIR
    - SP-009 - D2KWUTIL.GET_ACTIVE_WINDOW
    - SP-010 - D2KWUTIL.SAVE_FILE
    - SP-011 - D2KWUTIL.TRANSLATETYPE
    - SP-012 - GENERAL.ASK_CONFIRM
    - SP-013 - GENERAL.CHECK_FORM_FAILURE
    - SP-014 - GENERAL.DISP_TEXT
    - SP-015 - PKG_VTS_BODYSHOP.SF_GET_DATE_NUM
    - SP-016 - PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE
    - SP-017 - PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR
    - SP-018 - PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN
    - SP-019 - PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT
    - SP-020 - WEBUTIL.BLOCKING
    - SP-021 - WEBUTIL.CHECKLIBS
    - SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER
    - SP-023 - WEBUTIL.CLOSEBLOB
    - SP-024 - WEBUTIL.CLOSEFILE
    - SP-025 - WEBUTIL.DOWNLOADFROMURL
    - SP-026 - WEBUTIL.DOWNLOADFROMURLINT
    - SP-027 - WEBUTIL.ERROR
    - SP-028 - WEBUTIL.ERRORALERT
    - SP-029 - WEBUTIL.EXECUTE
    - SP-030 - WEBUTIL.FCLOSE
    - SP-031 - WEBUTIL.FILE_SAVE_DIALOG
    - SP-032 - WEBUTIL.FILE_SELECTION_DIALOG_INT
    - SP-033 - WEBUTIL.FOPEN
    - SP-034 - WEBUTIL.GETCALLBACKTRIGGER
    - SP-035 - WEBUTIL.GETCLIENTOSFAMILY
    - SP-036 - WEBUTIL.GETCLIENTSETTING
    - SP-037 - WEBUTIL.GETIMPLCLASS
    - SP-038 - WEBUTIL.GETLASTERROR
    - SP-039 - WEBUTIL.GETLASTERRORARGS
    - SP-040 - WEBUTIL.GETNUMBER
    - SP-041 - WEBUTIL.GETOSFAMILY
    - SP-042 - WEBUTIL.GETOUTPUT
    - SP-043 - WEBUTIL.GETPROPERTY
    - SP-044 - WEBUTIL.GETSTRING
    - SP-045 - WEBUTIL.GETVAR
    - SP-046 - WEBUTIL.GET_LINE
    - SP-047 - WEBUTIL.GET_RETURN_CODE
    - SP-048 - WEBUTIL.GET_STANDARD_OUTPUT
    - SP-049 - WEBUTIL.HOST
    - SP-050 - WEBUTIL.ID_NULL
    - SP-051 - WEBUTIL.INIT
    - SP-052 - WEBUTIL.INITWEBUTIL
    - SP-053 - WEBUTIL.ISERROR
    - SP-054 - WEBUTIL.IS_OPEN
    - SP-055 - WEBUTIL.LENGTH
    - SP-056 - WEBUTIL.LOG
    - SP-057 - WEBUTIL.POPULATEPROPERTYBUNDLE
    - SP-058 - WEBUTIL.PUTF
    - SP-059 - WEBUTIL.PUT_LINE
    - SP-060 - WEBUTIL.READFROMPROPERTYBUNDLE
    - SP-061 - WEBUTIL.READTRANSFROMMSGBUNDLE
    - SP-062 - WEBUTIL.REGISTERBEAN
    - SP-063 - WEBUTIL.REGISTER_FUNCTION
    - SP-064 - WEBUTIL.RELEASE_PROCESS
    - SP-065 - WEBUTIL.SETCLIENTSETTING
    - SP-066 - WEBUTIL.SETDATA
    - SP-067 - WEBUTIL.SETPROPERTY
    - SP-068 - WEBUTIL.SHOWBEANS
    - SP-069 - WEBUTIL.URL_TO_CLIENT
    - SP-070 - WEBUTIL.WRITEDATA
    - SP-071 - WEBUTIL_CORE.CUSTOMEVENTHANDLER
    - SP-072 - ADD_ERROR
    - SP-073 - ADD_EXTERNAL_ERRORS
    - SP-074 - BOOLTOCHAR
    - SP-075 - CLEAN_ERROR_STACK
    - SP-076 - DEBUGLOG
    - SP-077 - GET_ENVIRONMENT_STRING
    - SP-078 - GET_TEMP_DIRECTORY
    - SP-079 - GET_WINDOWS_DIRECTORY
    - SP-080 - READ_REGISTRY
    - SP-081 - REGISTER_FUNCTION_CALL
    - SP-082 - SETDEBUG
    - SP-083 - STRIPDIRSEP
    - SP-084 - VIEW_EXCEL_REPORT_NEW
    - SP-085 - WINDEBUG

## 1. Document Control

### 1.1 Document Information

| Field | Value |
| ----- | ----- |
| Document Title | VR_VEH_WISE_DELAY - Business Requirements Document |
| Form Module Name | VR_VEH_WISE_DELAY |
| Document Version | 1.0 |
| Date Created | August 14, 2026 |
| Author/Prepared By | BRD Agent |

### 1.2 Revision History

| Version | Date | Author | Description |
| --- | --- | --- | --- |
| 1.0 | August 14, 2026 | BRD Agent | Initial draft |

---

## 2. Executive Summary

*High-level overview of the vr_veh_wise_delay Vehicle Wise Delay Report form, its purpose, and roles referenced in the module.*

The **vr_veh_wise_delay** Oracle Forms module is the dealership **Vehicle Wise Delay Report** screen used within the bodyshop management area of a Dealer Management System. A service manager or analyst opens the screen, enters a billing date range (up to one month), and clicks Search to retrieve a summary of bodyshop hold reasons - showing how many vehicles were affected by each delay category and the total hours of hold time accumulated over the period. The date range is validated to ensure neither date is in the future, that the To Date is not earlier than the From Date, and that the span does not exceed 31 days. Once the summary is displayed, the user may click **Export to Excel** to download a detailed CSV file listing each individual job card with its registration number, vehicle model, service type, number of body panels, job opening and closing dates, bill and promise dates, and calculated productive, idle, and hold times. The form is a read-only reporting and export tool; no records are created, updated, or deleted through this screen.

### Key Stakeholders

*Who uses vr_veh_wise_delay*

| Stakeholder | Role |
| :--- | :--- |
| **Service Manager / Bodyshop Analyst** | Primary interactive user of vr_veh_wise_delay. Enters the billing date range, triggers the delay summary search, and exports the results to Excel for operational review and performance analysis. |
| **Dealer Management System Administrator** | Configures session context (dealer, location, principal, and company details) that is passed into the form; ensures the application ID and login session are correctly set before the form is opened. |

---

---

## 3. System Context

*Describes the vr_veh_wise_delay module's role within the DMS ecosystem, scope, process flow, and key integrations.*

The **vr_veh_wise_delay** module is the bodyshop **Vehicle Wise Delay Report** screen within the Dealer Management System. It provides service managers and analysts with a summary of delay causes affecting bodyshop job cards over a selected billing period, and enables the export of per-vehicle detail for further analysis. The form connects to the vehicle repair order data, hold-event tracking, and vehicle model master data to calculate and present delay statistics.

**System purpose:** Retrieve and display bodyshop vehicle delay statistics by hold reason for a user-specified billing date range, and generate a detailed per-job-card CSV export including productive, idle, and hold times - as implemented in the vr_veh_wise_delay Oracle Forms module.

**In scope:**

- Enter and validate a billing date range (From Bill Date and To Bill Date)
- Search for bodyshop job cards matching the dealer, location, and date range
- Display a summary of hold reasons with affected vehicle count and total hold-up time
- Calculate per-line hold time contributions using shift schedules and holiday calendars
- Export a detailed CSV report of individual job cards with vehicle and time breakdown

**Process Name:** Vehicle Wise Delay Report

**Process Owner:** Service Manager / Bodyshop Analyst

**Process Objective:** Enter a billing date range, validate the dates, retrieve the vehicle-wise delay summary by hold reason, and optionally export the full per-job-card detail to a CSV file.

**Process Trigger:** Service manager or analyst opens the Vehicle Wise Delay Report screen to review bodyshop delay performance for a specific billing period.

**Process Flow:**

The complete vehicle wise delay report process follows this sequence. Each step corresponds to Functional Requirements in Section 4.

```
STEP 1 ── FORM OPENS
         The Vehicle Wise Delay Report screen opens.
         The session is registered in Oracle application monitoring with the form module name.
         Pagination globals are initialised (from_no, to_no, increment_no).

STEP 2 ── ENTER FROM BILL DATE
         The analyst enters the From Bill Date (start of the billing period).
         The result display area is cleared automatically.

STEP 3 ── VALIDATE FROM BILL DATE
         ├── If From Bill Date is null: an error is displayed and entry is blocked.
         └── If From Bill Date is in the future: an error is displayed and entry is blocked.

STEP 4 ── NAVIGATE TO TO BILL DATE
         The cursor moves to the To Bill Date field.
         Any previously displayed hold reason results are cleared.

STEP 5 ── ENTER TO BILL DATE
         The analyst enters the To Bill Date (end of the billing period).
         If left blank, To Bill Date defaults to today's date.

STEP 6 ── VALIDATE TO BILL DATE
         ├── If To Bill Date is in the future: an error is displayed.
         ├── If To Bill Date is earlier than From Bill Date: an error is displayed.
         └── If the date range exceeds 31 days: an error is displayed and the analyst is
                       prompted to correct the To Bill Date.

STEP 7 ── CLICK SEARCH
         The analyst clicks the Search button.
         The system executes the vehicle delay summary query filtered by dealer, location,
         parent group, principal, and the entered billing date range (B&P repair category only).

STEP 8 ── CALCULATE HOLD TIME PER LINE
         For each matching hold event in the selected period, the working-hours hold
         duration is calculated per stage and serial line, accounting for shift schedules
         and public holidays.

STEP 9 ── POPULATE RESULTS
         The system groups results by hold reason description and populates the results
         block with the hold reason, number of distinct affected job cards, and total
         accumulated hold time.

STEP 10 ── VIEW RESULTS
          The analyst reviews the hold reason summary on screen.
          Each row shows the delay category, number of vehicles affected, and total hours.

STEP 11 ── CLICK EXPORT TO EXCEL (optional)
          The analyst clicks the Export to Excel button to download detailed job card data.
          The system builds a dynamic SQL query for all matching bodyshop job cards,
          incorporating vehicle model description and panel count lookups.

STEP 12 ── GENERATE CSV REPORT
          The system executes the export query via the Excel report library.
          The CSV includes job card number, registration, model description, service type,
          panel count, opening date, closing date, bill date, promise date, productive time,
          idle time, and hold time per job card.

STEP 13 ── DOWNLOAD CSV FILE
          The generated CSV file is named with the user ID and current timestamp.
          The file is made available for download in the browser.

STEP 14 ── EXIT FORM
          The analyst exits the form.
          Session application monitoring information is cleared and pagination globals are erased.
```

**Major process interactions:**

- **Vehicle repair order data** - job card records (including bill date, dealer, location, and service category) are the primary data source for the delay summary
- **Hold event tracking** - individual hold events linked to job cards provide the stage, serial line, and hold start/end times used to calculate delay durations
- **Hold reason master** - hold reason codes are resolved to descriptions and used to group the delay summary results
- **Shift schedule and holiday calendar** - working hours and public holiday dates are used to convert raw hold durations into working-hours delay values
- **Vehicle model master** - vehicle model descriptions are retrieved by principal and model code for the Excel export
- **Excel report library** - the DMS_EXCEL_REPORT library generates and delivers the CSV file to the user's browser

---

---

## 4. Functional Requirements

### 4.1 Business Requirements

#### Requirement ID: BR-001

**Requirement Title:** Form Session Identification, Audit Tagging, and Initialisation

**Business Description:**
When the vehicle-wise delay report screen opens, the system performs a sequence of automatic initialisation steps before the user interacts with the form. It registers the current database session with the module identity so that operations staff can trace active sessions; it records the report description and application identifier for audit and reporting services; it maximises the application window so the full report screen is visible; it pre-populates the billing date range to cover the previous calendar month up to today; and it loads the system copyright declaration into the screen footer. All of these actions happen automatically in the background, requiring no input from the user.

**Actors:** System (automatic on form open)

**Preconditions:**
- The user has launched the vehicle-wise delay report from the dealer management menu.

**Main Flow:**

**Step 1 - Session tagged with the module identity**
Before the form is displayed, the system records the module name `vr_veh_wise_delay` as both the client identifier and the module name against the current database session so that operations and support staff can identify the session's purpose in the active sessions view. The action name is cleared to an empty value at the same time.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-01** - Session client identifier set to `vr_veh_wise_delay`; module name set to `vr_veh_wise_delay`; action name set to empty - the session is now tagged in the database's active session registry for traceability.

**Step 2 - Report description and application identifier seeded**
The system sets the global report description to *"VTS BodyShop Delay Report"* and copies it to the on-screen report description field so that any downstream reporting service or audit log receives a human-readable label for this report. The global application identifier is set to `vr_veh_wise_delay` and copied to the report parameter `p_app_id` so that the Excel export service can identify the calling form.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-02** - Global session value `global.report_desc` set to *"VTS BodyShop Delay Report"*; `global.app_id` set to `vr_veh_wise_delay`; both values propagated to screen and parameter fields.

**Step 3 - Application window maximised**
The system maximises both the MDI host window and the report's main window (WN_MAIN) so that the full report screen fills the display, giving the user maximum viewing area for the results grid.

**Step 4 - Default billing date range applied**
The system automatically pre-populates the From Bill Date with the first day of the previous calendar month and the To Bill Date with today's date. This provides a convenient default one-month reporting window that the user can adjust before running the search.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-03** - From Bill Date defaulted to the first day of the preceding month; To Bill Date defaulted to today's date.

**Step 5 - Copyright declaration loaded**
The system queries the standard copyright declaration text from the database and displays it in the designated copyright field on screen, ensuring the form always shows the current approved legal notice.

*Business outcomes (errors, warnings, success, and status):*
- **BR-001-IC-04** - Copyright declaration text retrieved and displayed in the copyright field on the report screen.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Module identifier (session tag) | Auto-populated | Character | 50 | N/A | Fixed value `vr_veh_wise_delay` | Form launch initiated | System-set only; not user-editable | N/A |
| Report description (`report_desc` / `global.report_desc`) | Auto-populated | Character | N/A | N/A | Fixed value `VTS BodyShop Delay Report` | Form launch initiated | System-set only; not user-editable | N/A |
| Application identifier (`global.app_id` / `parameter.p_app_id`) | Auto-populated | Character | N/A | N/A | Fixed value `vr_veh_wise_delay` | Form launch initiated | System-set only; used by Excel export service | N/A |
| From Bill Date (`FROM_JC_BILL_DT`) | Auto-defaulted | Date | DD-MM-RRRR | N/A | First day of previous calendar month | Form launch initiated | User may override before searching | N/A |
| To Bill Date (`TO_BILL_DT`) | Auto-defaulted | Date | DD-MM-RRRR | N/A | Today's date (sysdate) | Form launch initiated | User may override before searching | N/A |
| Copyright declaration (`COPYRIGHT_DECLARATION`) | Auto-populated | Character | N/A | System copyright function (SF_COPYRIGHT_DECLARATION) | Current copyright text | Form launch initiated | System-set only; not user-editable | N/A |

---

---

#### Requirement ID: BR-002

**Requirement Title:** From Bill Date Entry and Validation

**Business Description:**
When the user enters the start date for the billing period they want to report on, the system validates that a date has been provided and that it does not fall in the future. If the entered date fails either check, the user is shown a clear alert and must correct the value before proceeding. Any previously displayed report results on screen are also cleared at this point so the results always match the current search criteria.

**Actors:** Dealer Service Advisor / Report User

**Preconditions:**
- The vehicle-wise delay report screen is open.

**Main Flow:**

**Step 1 - Previously loaded results cleared on date entry**
As the user enters a value in the start date field, the system immediately clears any hold-reason summary results that were shown on screen from a previous search, ensuring stale data is not visible while new criteria are being entered.

**Step 2 - Start date presence verified**
The system checks that the user has actually provided a start date. If the field is left empty, an alert is displayed telling the user the start date is required, and the cursor remains on the field so the user can enter a value.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Bill Date must not be blank | `FROM_JC_BILL_DT` is null check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT | When the user tabs off or confirms the From Bill Date field | Ensures the report always has a defined start date; no search can run without it | Alert displayed: *"From Date can not be null"*; user must supply a date before proceeding |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-01** - From Bill Date is blank - *"From Date can not be null"*; the cursor stays on the From Bill Date field and the user must enter a valid date.

**Step 3 - Start date must not be in the future**
The system checks that the start date entered is not later than today's date. Report data exists only up to the current date, so a future start date would yield no meaningful results. If the date is in the future, an alert is displayed and the user must correct the value.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| From Bill Date must not exceed today | `FROM_JC_BILL_DT > SYSDATE` check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT | When the user tabs off or confirms the From Bill Date field after a non-null value is entered | Prevents users from querying a date range that cannot have any completed billing records yet | Alert displayed: *"From Date cannot be greater than Current Date"*; user must enter a date on or before today |

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-ES-02** - From Bill Date is a future date - *"From Date cannot be greater than Current Date"*; the cursor stays on the From Bill Date field and the user must correct the date.

**Step 4 - Cursor advances to the end date field**
Once all validations pass, the cursor moves automatically to the To Bill Date field so the user can complete the date range without an extra tab or click.

*Business outcomes (errors, warnings, success, and status):*
- **BR-002-SM-01** - From Bill Date accepted and cursor advanced - the start date has passed all checks; previous results have been cleared; focus is now on the To Bill Date field ready for the user to enter the end of the reporting period.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Mandatory | Date | DD-MM-RRRR | N/A | N/A | Report screen open | Must not be blank; must not be greater than today's date | Alert: *"From Date can not be null"* if blank; alert: *"From Date cannot be greater than Current Date"* if future |
| Hold Reason summary (`HOLD_REASON`) | Auto-populated | Character | N/A | N/A | N/A | Previous search results present | System-cleared when From Bill Date is entered; not user-editable at this step | N/A |
| Total Vehicles Affected (`TOTAL_VEH_AFFECTED`) | Auto-populated | Numeric | N/A | N/A | N/A | Previous search results present | System-cleared when From Bill Date is entered; not user-editable at this step | N/A |
| Total Hold-Up Time (`TOTAL_HOLD_UP_TIME`) | Auto-populated | Numeric | N/A | N/A | N/A | Previous search results present | System-cleared when From Bill Date is entered; not user-editable at this step | N/A |

---

---

#### Requirement ID: BR-003

**Requirement Title:** To Bill Date Entry, Validation, and Default

**Business Description:**
When the user enters the end date for the billing period, the system validates the date against three rules: it must not be in the future, it must not be earlier than the start date already entered, and the overall date range must not exceed one calendar month. If the end date field is left empty, the system automatically defaults it to today's date. These controls ensure that report requests are always for a valid, bounded period that the system can meaningfully process.

**Actors:** Dealer Service Advisor / Report User

**Preconditions:**
- The vehicle-wise delay report screen is open.
- A valid start date for the billing period has already been entered.

**Main Flow:**

**Step 1 - End date checked against today**
The system first checks whether the end date entered is later than today's date. Because report data exists only up to the current date, a future end date would produce no useful results. If the date is in the future, an alert is shown and the user must correct it.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date must not exceed today | `TO_BILL_DT > SYSDATE` check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT | When the user tabs off or confirms the To Bill Date field | Prevents querying a billing window that cannot yet have completed records | Alert displayed: *"To Date cannot be greater than Current Date"*; user must enter a date on or before today |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-01** - To Bill Date is a future date - *"To Date cannot be greater than Current Date"*; the cursor remains on the To Bill Date field.

**Step 2 - End date checked against start date**
The system verifies that the end date is not earlier than the start date. A date range where the end falls before the start is logically invalid and would return no records. If the check fails, an alert is shown and the user must correct the end date.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| To Bill Date must not be earlier than From Bill Date | `FROM_JC_BILL_DT > TO_BILL_DT` check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT | After the future-date check passes | Ensures the end date forms a valid date range with the start date | Alert displayed: *"To Date cannot be less than From Date"*; user must enter a date on or after the start date |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-02** - To Bill Date is earlier than From Bill Date - *"To Date cannot be less than From Date"*; the cursor remains on the To Bill Date field.

**Step 3 - Date range checked against the one-month maximum**
The system checks that the period from the start date to the end date is no more than 31 days. Longer date ranges could result in very large data volumes; the one-month limit keeps report generation within acceptable bounds. If the range exceeds 31 days, an alert is shown, the cursor is moved back to the To Bill Date field, and the user must narrow the range.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Date range must not exceed 31 days | `TO_BILL_DT - FROM_JC_BILL_DT > 31` check - WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT | After the start-date comparison passes | Limits report data volume to a manageable one-month window | Alert displayed: *"Report can be generated for maximum 1 Month"*; cursor moved to To Bill Date field; user must reduce the range |

*Business outcomes (errors, warnings, success, and status):*
- **BR-003-ES-03** - Date range exceeds 31 days - *"Report can be generated for maximum 1 Month"*; cursor is placed on the To Bill Date field so the user can reduce the range.

**Step 4 - Empty end date defaulted to today**
In a separate validation block, if the To Bill Date field is left empty after the range checks, the system automatically sets it to today's date. This provides a convenient default so users do not have to type today's date manually when they want to report up to the current day.

**Alternative Flows:**
- **BR-003-AF-01** - (from Step 4) If the To Bill Date is left blank, the system sets it to today's date rather than prompting the user for a value; the field is populated automatically and processing continues.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| To Bill Date (`TO_BILL_DT`) | Conditional - defaults to today if left blank | Date | DD-MM-RRRR (maxLength 10) | N/A | N/A | From Bill Date entered and valid | Must not exceed today; must not be earlier than From Bill Date; range must not exceed 31 days | Alert: *"To Date cannot be greater than Current Date"*; alert: *"To Date cannot be less than From Date"*; alert: *"Report can be generated for maximum 1 Month"* |
| From Bill Date (`FROM_JC_BILL_DT`) | Read-only (used for range comparison) | Date | DD-MM-RRRR | N/A | N/A | Entered and validated in prior step | Read only at this step; compared against To Bill Date for ordering and range checks | N/A |

---

---

#### Requirement ID: BR-004

**Requirement Title:** Vehicle-Wise Delay Search by Hold Reason

**Business Description:**
When the user clicks the Search button, the system queries all body-and-paint job cards billed within the selected date range at the dealer's location and calculates the total vehicle hold-up time attributed to each hold reason for that period. The results - grouped by hold reason, showing the number of distinct job cards affected and the total hold time - are displayed on screen, giving service management a clear picture of where delays are occurring and how much time is being lost.

**Actors:** Dealer Service Advisor / Service Manager

**Preconditions:**
- A valid billing start date and a valid billing end date have been entered and confirmed.

**Main Flow:**

**Step 1 - Previous results cleared**
When the user presses Search, the system immediately clears any hold-reason summary rows currently shown on screen, ensuring that the display is reset before the new results load.

**Step 2 - Vehicle delay data queried and summarised by hold reason**
The system queries all body-and-paint repair orders billed at the user's dealership location within the selected date range. For each hold-reason category recorded against those repair orders, it counts the number of distinct job cards affected and sums the vehicle hold-up time. The summed hold-up time for each hold-reason line is calculated by calling the hold-time calculation function for every individual hold record within that line.

*Procedures called:*
- **PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE** ([SP-007](#SP-007--PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE)) - PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE - calculates the adjusted hold time (in working shift hours) for a single hold line on a repair order, factoring in the applicable work-shift schedule and whether intervening days are working days or holidays.
    * **Step 1** - Retrieve all hold records for the specified repair order, stage, and hold-line sequence number, ordered by stage and sequence.
    * **Step 2** - For each hold record retrieved, determine whether the hold start and hold end dates fall on the same calendar day or span multiple days; this controls which calculation path is used.
    * **Step 3** - If the hold is within a single day, look up the total available working hours and the shift start and end times for that day, then calculate the hold duration as a proportion of the shift.
    * **Step 4** - If the hold spans multiple days, calculate the partial time on the first day (from hold start to shift end), check each intermediate day against the holiday calendar to count only working days, and calculate the partial time on the last day (from shift start to hold end); sum all three components.
    * **Step 5** - Accumulate the calculated hold time across all hold records for the line and return the total as a numeric value.

| Validation | Technical Reference | Trigger | Business Purpose | Failure Outcome |
| :--- | :--- | :--- | :--- | :--- |
| Hold-time span determination | Hold start date vs. hold end date same-day check - PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE [SP-007] | When the Search button is pressed and hold-time is summed for each hold line | Ensures hold time is calculated using the correct method (single-day proportion vs. multi-day accumulation) so that shift schedules and non-working days are properly accounted for | If no matching hold records exist for a line the function returns zero; no error is raised - the line simply contributes 0 to the hold-time total |

**Step 3 - Summarised results displayed on screen**
For each hold reason returned by the query, the system populates a row on the results area of the screen showing the hold reason description, the number of vehicles affected, and the total hold-up time. The user can see all hold-reason rows in sequence.

*Business outcomes (errors, warnings, success, and status):*
- **BR-004-SM-01** - Search completed and results loaded - the hold-reason summary rows are populated on screen showing each hold reason, vehicle count, and total hold time.

**Alternative Flows:**
- **BR-004-AF-01** - (from Step 2) If no body-and-paint job cards with matching hold records exist in the date range, the cursor loop completes without writing any results rows; the results area remains empty (or shows only the rows from the last clear).

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Read-only (used as search filter) | Date | DD-MM-RRRR | N/A | N/A | Entered and validated | Used as the lower bound of the billing date filter (inclusive, truncated to date) | N/A |
| To Bill Date (`TO_BILL_DT`) | Read-only (used as search filter) | Date | DD-MM-RRRR | N/A | N/A | Entered and validated | Used as the upper bound of the billing date filter (exclusive, truncated to date) | N/A |
| Hold Reason (`HOLD_REASON`) | Auto-populated | Character | N/A | Vehicle Hold Reason master (VM_PROC_HOLD_REASON) | Hold reason description | Search executed | Populated from the hold-reason master matching the recorded hold codes | N/A |
| Total Vehicles Affected (`TOTAL_VEH_AFFECTED`) | Auto-populated | Numeric | N/A | N/A | Count of distinct job card numbers | Search executed | System-calculated count of distinct repair order numbers per hold reason | N/A |
| Total Hold-Up Time (`TOTAL_HOLD_UP_TIME`) | Auto-populated | Numeric | N/A | N/A | Sum of hold-time values (working shift hours) | Search executed | System-calculated sum of hold time per hold reason via PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE | N/A |

---

---

#### Requirement ID: BR-005

**Requirement Title:** Export Detailed Vehicle Delay Report to Excel

**Business Description:**
When the user clicks the Export to Excel button, the system generates a comma-separated file containing one row per body-and-paint repair order billed within the selected date range. Each row includes the job card number, vehicle registration, model description, service type, panel count, job card open and close dates, bill date, promised delivery date, and the productive time, idle time, and total hold time for that vehicle. The file is made available for the user to download and open in a spreadsheet application, providing a detailed vehicle-level view of delay data for analysis and management reporting.

**Actors:** Dealer Service Advisor / Service Manager

**Preconditions:**
- A valid billing start date and end date have been entered and confirmed.

**Main Flow:**

**Step 1 - Export filename generated**
The system composes a unique filename for the export file using the current user's login identity and the current date and time, resulting in a CSV filename in the format `<userid>-<timestamp>.CSV`. This ensures each export file is distinctly identifiable.

**Step 2 - Detailed query string built**
The system constructs the query that will populate the export file. The query selects each body-and-paint repair order billed at the user's dealership location within the date range and, for each repair order, retrieves the vehicle registration number, model description, service type, panel count, open date, close date, bill date, promised delivery date, productive time, idle time, and total hold time. Time values are calculated by calling dedicated bodyshop performance functions for each repair order row within the query. The assembled query string is also stored in an internal field for reference.

**Step 3 - Excel file generated and made available for download**
The system passes the generated filename, query, and application identifier to the Excel reporting service, which executes the query, writes the result rows to the CSV file, and opens the file in a new browser window so the user can download it.

*Procedures called:*
- **VIEW_EXCEL_REPORT_NEW** ([SP-065](#SP-065--VIEW_EXCEL_REPORT_NEW)) - VIEW_EXCEL_REPORT_NEW - an attached library routine (DMS_EXCEL_REPORT library - EXTERNAL / NOT IN BUNDLE) that receives a principal identifier, filename, query string, column name, and application identifier; executes the query to produce the CSV file; and opens the resulting file for the user to download. Its full internal logic is not verifiable from the bundle.

*Business outcomes (errors, warnings, success, and status):*
- **BR-005-SM-01** - Export file generated and opened - the CSV file is created and opened in a new browser window; the user can download the detailed vehicle delay data.

**Alternative Flows:**
- **BR-005-AF-01** - (from Step 2) If no body-and-paint repair orders exist in the date range for the user's location, the query returns no detail rows and the exported file contains only the header row.

**Data Elements:**

| Field | Mandatory/Optional | Field Type | Field Length/Format | Lookup Entity | Lookup Value | Pre-requisite | Validation Rule | Error Handling |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| From Bill Date (`FROM_JC_BILL_DT`) | Read-only (used as export filter) | Date | DD-MM-RRRR | N/A | N/A | Entered and validated | Used as lower bound of the billing date filter in the export query (inclusive) | N/A |
| To Bill Date (`TO_BILL_DT`) | Read-only (used as export filter) | Date | DD-MM-RRRR | N/A | N/A | Entered and validated | Used as upper bound of the billing date filter in the export query (exclusive); the code adds 1 day to compute the exclusive upper bound | N/A |
| Query text (`TXT`) | Auto-populated | Character | 5000 | N/A | Dynamically built SQL query string | Date range entered | System-set only; stores the constructed export query for reference | N/A |

---

---

#### Requirement ID: BR-006

**Requirement Title:** Form Exit and Session Cleanup

**Business Description:**
When the user exits the vehicle-wise delay report, the system clears the database session's tracking identifiers and removes the internal pagination control values that were set during the session. The form then closes without checking for unsaved changes. This ensures that no residual session metadata from this report remains associated with the user's database connection after they leave the screen.

**Actors:** Dealer Service Advisor / Report User

**Preconditions:**
- The vehicle-wise delay report screen is open.

**Main Flow:**

**Step 1 - Database session tracking cleared**
The system clears the module name and client identifier that were registered against the current database session when the form opened, removing the "vr_veh_wise_delay" tag from the active session registry. The module name and action name are both set to empty strings.

**Step 2 - Internal pagination values removed**
Three internal session values used for pagination control (the starting record number, the ending record number, and the increment step) are erased from the session. This prevents stale pagination state from affecting any subsequently opened form in the same session.

**Step 3 - Form closed without validation**
The form closes immediately without checking for any pending unsaved changes. The user is returned to the calling application menu.

*Business outcomes (errors, warnings, success, and status):*
- **BR-006-SM-01** - Form exit completed - session tracking identifiers cleared; pagination globals erased; form closed without validating unsaved changes.

---

---

#### Requirement ID: BR-007

**Requirement Title:** Pagination Initialisation Utility (Defined - Not Currently Invoked)

**Business Description:**
The form contains a named utility procedure that initialises three internal pagination control values used for navigating through large result sets: the starting record position is set to 1, the ending record position to 10, and the step increment to 10. This procedure is defined in the form's code library but has no active call site within the form; it is not invoked by any trigger or button. It represents a server-side pagination helper that was likely part of an earlier version of the result display and is currently inactive from a business-operation perspective.

**Actors:** System (no active invocation)

**Preconditions:**
- N/A - the procedure is defined but not currently called from any trigger or control in the form.

**Main Flow:**

**Step 1 - Pagination variables initialised (not currently executed)**
The procedure would set the starting record number to 1, the ending record number to 10, and the record increment to 10, preparing the session for paginated navigation through result rows. Because no active trigger or control currently calls this procedure, this step does not execute during normal operation.

*(Note: The form program unit SET_GLOBAL contains executable code but has no active call sites in the current form version - it does not execute during any user interaction. Documented here to satisfy completeness per source-coverage rules.)*

---

---

#### Requirement ID: BR-008

**Requirement Title:** Legacy Excel Generation Utility (Defined - Not Currently Invoked)

**Business Description:**
The form contains a named utility procedure that represents the earlier, now-superseded approach to generating the vehicle delay Excel export. This procedure builds a CSV file by querying repair order data, constructing the file on the application server, reading the output file path from a configuration text file, and then opening the file in the user's browser. It has been replaced by a newer Excel reporting service and its invocation in the Export to Excel button has been commented out since August 2016; it is no longer called from any active trigger. The procedure body remains in the form's code library but does not execute during any user interaction.

**Actors:** System (no active invocation - superseded)

**Preconditions:**
- N/A - the procedure is defined but not currently called from any trigger or control in the form.

**Main Flow:**

**Step 1 - Legacy Excel generation flow (not currently executed)**
The procedure would generate a unique export filename, execute the provided query using an Oracle record group, check the row count against the 65,535-row Excel limit (warning the user if exceeded), read the output directory path from a server-side configuration file (`/reports/DMS/excelpath.txt`), write all data rows to the file, and open the file in a new browser window. Because the call to this procedure in the Export to Excel button was commented out in August 2016, this flow does not execute. The replacement flow is documented in BR-005.

*(Note: The form program unit VIEW_EXCEL_REP contains executable code but has no active call sites in the current form version - it does not execute during any user interaction. Documented here to satisfy completeness per source-coverage rules.)*

**Step 2 - Active message interceptor re-styles Forms validation errors (ON-MESSAGE)**
The form carries an active ON-MESSAGE trigger that runs whenever Oracle Forms raises an internal message. When the message code is `40209` (item value not in a list of valid values) or `40207` (item value outside the permitted range), the trigger re-presents the message as a formatted error dialog by calling `GENERAL.DISP_TEXT` with the error type, code, and text, then raises a trigger failure so that the offending field retains focus. All other Forms message codes are passed through without modification.

*(Note: This trigger is active and executes on every Forms message event in this form. It affects how Forms item-validation feedback is presented to the user.)*

---







### 4.2 Inactive Code Register

The following triggers and program units exist in the form source but contain only commented-out code, empty bodies, or a `null;` statement and therefore do not execute. They are listed here for completeness; they impose no business behaviour.

| Trigger / Program Unit | Level / Owner | Status | Notes |
| --- | --- | --- | --- |
| ON-ERROR | Form-level trigger | COMMENTED OUT / INACTIVE - does not execute | Contains multiple commented-out error-handling blocks (various versions); the active body is `null;` only. |
| ON-MESSAGE | Form-level trigger | ACTIVE - executes on every Forms internal message | Intercepts Forms messages with error codes `40209` (item validation - value must be in list) and `40207` (item validation - value not in valid range); when either code fires, the trigger re-presents the message as a styled error dialog using GENERAL.DISP_TEXT and raises a trigger failure to block further processing. All other Forms messages are passed through unchanged. |
| KEY-LISTVAL | Form-level trigger | COMMENTED OUT / INACTIVE - does not execute | Empty body; LOV invocation uses default Forms behaviour. |
| KEY-COMMIT | Form-level trigger | COMMENTED OUT / INACTIVE - does not execute | Empty body; commit behaviour uses the default Forms commit. |
| KEY-CLRFRM | Form-level trigger | COMMENTED OUT / INACTIVE - does not execute | Body is `null;` with commented-out field-clear logic. |
| KEY-UP | Block-level trigger (CB_DOC_QUERY) | COMMENTED OUT / INACTIVE - does not execute | Body is `NULL;`; cursor-up navigation uses default Forms behaviour. |
| KEY-DOWN | Block-level trigger (CB_DOC_QUERY) | COMMENTED OUT / INACTIVE - does not execute | Body is `NULL;`; cursor-down navigation uses default Forms behaviour. |
| WHEN-BUTTON-PRESSED (WEBUTIL.DUMMY) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body; WebUtil initialisation uses the library's own event triggers. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_FILE_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_HOST_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_SESSION_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_OLE_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_C_API_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| WHEN-CUSTOM-ITEM-EVENT (WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS) | Item-level trigger (WEBUTIL block) | COMMENTED OUT / INACTIVE - does not execute | Empty body. |
| POPULATE (Form program unit) | Form-level procedure | COMMENTED OUT / INACTIVE - does not execute | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It formerly populated the CB_DOC display block from the in-memory document table during paginated result navigation; it is no longer referenced by any active code. |
| DOC_DET (Form program unit) | Form-level package | COMMENTED OUT / INACTIVE - does not execute | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It formerly declared an in-memory PL/SQL table (`v_doc_tab` of type `pk_plsql_table.code_tab6`) used by the old paginated result display approach; it is no longer referenced by any active code. |
| EXCEL_GENERATION (Form program unit) | Form-level procedure | COMMENTED OUT / INACTIVE - does not execute | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It was formerly a server-side CSV generation procedure that queried vehicle repair order data and wrote job card details to a file, but was superseded by the VIEW_EXCEL_REPORT_NEW library routine and its invocation was removed in August 2016. |

---

## 5. Business Rules Catalogue

Catalogue of the discrete business rules enforced by the VR_VEH_WISE_DELAY form's active code.

| Rule ID | Rule Name | Rule Type | Business Requirement ID | Condition | Action | Business Impact |
| ------- | --------- | --------- | ----------------------- | --------- | ------ | --------------- |
| BRC-001 | From Bill Date is mandatory | Validation | BR-002 | The From Bill Date field is left empty when the user moves off the field | Display an alert message *"From Date can not be null"* and prevent navigation away from the field until a date is entered | Ensures every search and export request has a defined start boundary; no report can run without it |
| BRC-002 | From Bill Date cannot be a future date | Validation | BR-002 | The From Bill Date entered is later than today's date | Display an alert message *"From Date cannot be greater than Current Date"* and keep the cursor on the From Bill Date field | Prevents querying a billing period that cannot yet contain completed records |
| BRC-003 | Results are cleared when From Bill Date changes | Derivation | BR-002 | A value is entered in or confirmed for the From Bill Date field | Clear all currently displayed hold-reason summary rows from the results area | Ensures the results area always reflects the current search criteria and not a stale prior search |
| BRC-004 | To Bill Date cannot be a future date | Validation | BR-003 | The To Bill Date entered is later than today's date | Display an alert message *"To Date cannot be greater than Current Date"* and keep the cursor on the To Bill Date field | Prevents querying a billing window that cannot yet have completed records |
| BRC-005 | To Bill Date cannot precede From Bill Date | Validation | BR-003 | The To Bill Date entered is earlier than the From Bill Date | Display an alert message *"To Date cannot be less than From Date"* and keep the cursor on the To Bill Date field | Prevents an illogical date range that would return no records |
| BRC-006 | Date range is limited to one calendar month | Constraint | BR-003 | The difference between To Bill Date and From Bill Date exceeds 31 days | Display an alert message *"Report can be generated for maximum 1 Month"*, move the cursor to the To Bill Date field, and prevent the user from proceeding | Controls data volumes and report generation time by restricting each search to a maximum one-month window |
| BRC-007 | To Bill Date defaults to today if left blank | Derivation | BR-003 | The To Bill Date field is empty after the range-validation checks | Automatically set the To Bill Date to today's date | Provides a convenient default so users can report up to the current day without typing today's date |
| BRC-008 | Search results are restricted to body-and-paint repair orders | Constraint | BR-004 | A search is executed for vehicle-wise delay data | Apply a fixed filter restricting the query to body-and-paint category repair orders only (service category code `BANDP`) | Ensures the vehicle-wise delay report shows only the relevant bodyshop category; other service categories are excluded by design |
| BRC-009 | Form session is identified in the database session registry on open | Derivation | BR-001 | The vehicle-wise delay report form begins loading | Register the module name `vr_veh_wise_delay` and clear the action name in the database session, so operations staff can identify this report in the active sessions view | Supports session traceability and operational monitoring of active report sessions |
| BRC-010 | Database session identifiers are cleared on form exit | Derivation | BR-006 | The user exits the vehicle-wise delay report form | Clear the module name, action name, and client identifier from the database session registry | Prevents residual session metadata from the report appearing against the user's connection after they close the screen |
| BRC-011 | Pagination control values are erased on form exit | Derivation | BR-006 | The user exits the vehicle-wise delay report form | Erase the internal starting record number, ending record number, and increment step from the session | Prevents stale pagination state from affecting any subsequently opened form in the same database session |
| BRC-012 | Export file is named uniquely using user identity and timestamp | Derivation | BR-005 | The user clicks the Export to Excel button | Compose the export filename as the current user's login identifier followed by the current date and time, with a `.CSV` extension | Ensures each export file can be uniquely identified and associated with the user and the moment it was generated; prevents filename collisions |

**Total Business Rules Identified: 12**

---

## 6. Data Requirements

*This section covers the data entities queried by the vehicle-wise delay report, the capture requirements for the report's filter fields, the reference data lookups used, and the lifecycle behaviour of the data the form reads.*

### 6.1 Business Entities and Relationships

*The form reads from two transactional tables - the repair order header and the vehicle tracking hold records - to produce its delay summary; no data is persisted directly by this form.*

#### Repair Order - VH_RO

The Repair Order table stores the header record for every vehicle service job raised at a dealership location. For this form, it provides the billing date, service category, and job card number used to filter the body-and-paint jobs within the user's selected date range. It is the primary driving entity for the vehicle-wise delay calculation.

#### Vehicle Tracking Hold Record - VT_VTS_HOLD

The Vehicle Tracking System (VTS) hold records table stores each hold event recorded against a repair order during the bodyshop production process. Each row captures the hold reason code, hold start time, hold end time, stage, and sequence number. The form joins these records to the repair order to aggregate total hold time by reason. It is also queried by the hold-time calculation function for individual line-level timing calculations.

#### Vehicle Hold Reason Master - VM_PROC_HOLD_REASON

This master table stores the descriptions for each hold reason code recorded in the VTS hold records. The form joins to it to resolve hold reason codes into business-readable descriptions for display in the results area.

#### Entity Relationships

The repair order is the root entity; each repair order may have multiple VTS hold records, one for each hold event recorded during its bodyshop production. The hold reason master provides descriptions for the hold reason codes referenced by the hold records.

```
VH_RO (Repair Order)
    └── VT_VTS_HOLD (Vehicle Tracking Hold Records)   <- joined on parent_group, dealer_map_cd, loc_cd, comp_fa, ro_num
            └── VM_PROC_HOLD_REASON (Hold Reason Master) <- joined on principal_map_cd and reason_code
```

### 6.2 Data Capture Requirements

*The user supplies a billing date range as the only input; all other data is read from the database and displayed.*

#### Report Filter Criteria (Report User - before searching)

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| From Bill Date (`FROM_JC_BILL_DT`) | Yes | The start date of the billing period to include in the delay report. The user enters this date to define the lower boundary of the search window. | Must not be blank; must not be later than today's date. Alerts shown: *"From Date can not be null"* and *"From Date cannot be greater than Current Date"*. |
| To Bill Date (`TO_BILL_DT`) | Conditional - auto-defaults to today if blank | The end date of the billing period to include in the delay report. If left blank, the system defaults it to today's date. | Must not be later than today; must not be earlier than the From Bill Date; the range must not exceed 31 days. Alerts: *"To Date cannot be greater than Current Date"*, *"To Date cannot be less than From Date"*, *"Report can be generated for maximum 1 Month"*. |

#### Parameters and Session Values

| Data Element | Mandatory | Description | Business Validation |
| :--- | :---: | :--- | :--- |
| Application identifier (`P_APP_ID` - parameter) | Auto-Populated | Application-level identifier passed to the Excel reporting service to identify the calling application context. Supplied by the calling environment; not entered by the user. | System-supplied; no user validation. |
| Repair order number parameter (`P_RO_NUM` - parameter) | Auto-Populated | Internal parameter used by the now-inactive legacy Excel generation program unit. Not exposed to the user in the current form version. | Referenced only by inactive code (EXCEL_GENERATION - commented out). |
| Parent group (`GLOBAL.PARENT_GROUP`) | Auto-Populated | Session global identifying the vehicle manufacturer group context for the logged-in dealer. Applied as a filter to all data queries. | System-supplied global; not entered by the user. |
| Dealer identifier (`GLOBAL.DEALER`) | Auto-Populated | Session global identifying the dealer's map code. Applied as a filter to all data queries. | System-supplied global; not entered by the user. |
| Location code (`GLOBAL.LOC_CD`) | Auto-Populated | Session global identifying the dealer's location code. Applied as a filter to all data queries. | System-supplied global; not entered by the user. |
| Principal map code (`GLOBAL.PRINCIPAL`) | Auto-Populated | Session global identifying the manufacturer principal. Used to filter the hold reason master and the model description lookup in the export query. | System-supplied global; not entered by the user. |
| User ID (`GLOBAL.USERID`) | Auto-Populated | Session global holding the logged-in user's identifier. Used to compose the export filename. | System-supplied global; not entered by the user. |

### 6.3 Reference Data

*Lists the master and configuration data referenced by this form when querying and displaying results.*

| Reference Data | Business Purpose | Used When |
| :--- | :--- | :--- |
| Vehicle Hold Reason Master (`VM_PROC_HOLD_REASON`) | Resolves hold reason codes into business-readable descriptions for display in the delay summary results. Filtered by the current principal map code and by the reason codes recorded in the VTS hold records. | When the Search button is pressed and the delay summary results are populated. |
| Vehicle Model Description Master (`VM_SVAR`) | Resolves the vehicle model code of each repair order into a human-readable model description for inclusion in the detailed Excel export. Filtered by the current principal map code and the repair order's model code. | When the Export to Excel button is pressed and the export query is constructed. |
| Bodyshop Work Shift Schedule (via `PKG_VTS_BODYSHOP` functions - EXTERNAL / NOT IN BUNDLE) | Provides the total working hours and shift start/end times per day for each repair order, used by the hold-time calculation function to compute hold duration as a proportion of the working shift. | When the Search button is pressed and hold times are calculated per hold record line. |
| Dealership Holiday Calendar (`WD_BTN` - queried within `PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE`) | Records non-working days for the dealership location, used to exclude public holidays and rest days from multi-day hold-time calculations. | When the Search button is pressed and a hold event spans multiple calendar days. |
| Excel output file path configuration (`/reports/DMS/excelpath.txt` - server-side text file - EXTERNAL / NOT IN BUNDLE) | Holds the server-side path prefix used to construct the URL for the generated Excel file. Referenced only by the inactive legacy VIEW_EXCEL_REP program unit; not used in the current active export flow. | Referenced by the inactive VIEW_EXCEL_REP procedure - does not execute in the current form version. |

### 6.4 Data Lifecycle

*Describes how the form interacts with data during a user session.*

**Creation**

- This form does not create or insert any records. It is a read-only reporting and export screen.

**Updates**

- This form does not update or modify any database records. All data interactions are read-only queries.

**Save and Commit**

- There is no save or commit action on this form. No database write operations are performed and no transactional commit is issued. The on-screen results display is populated entirely in memory and is not persisted.

**Retention and Audit**

- The form does not write audit stamps, created-by fields, or modification records. The database session is tagged on open with the module name `vr_veh_wise_delay` (via the PRE-FORM trigger) and cleared on exit (via the KEY-EXIT trigger) for operations traceability, but this tagging is session-level metadata only and is not persisted to any table by the form.

---

### 6.5 Excel Output Columns

Excel download columns produced by this form, with when each Excel is produced (report / principal path), filters that limit which rows are included, and the database source for each value. Column sets vary by export path (for example app_id, principal, and enquiry-date mode); the rows below are evidenced layouts, not a guaranteed list for every combination. Blank Table/Database means the physical column was not proven in source.

| # | What the user selects on screen | Excel column name | When this Excel is produced | Table name | Database column | Logic |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | PRINCIPAL | JC_NUM |  | VH_RO | RO_NUM | Shows the JC_NUM taken from the enquiry's related records. |
| 2 | PRINCIPAL | REG_NUM |  | VH_RO | REG_NUM | Shows the REG_NUM taken from the enquiry's related records. |
| 3 | PRINCIPAL | MODEL DESC |  | VM_SVAR | SVAR_DESC | Shows the MODEL DESC taken from the enquiry's related records. |
| 4 | PRINCIPAL | SERV TYPE |  | VH_RO | RCATEG_CD | Shows the SERV TYPE taken from the enquiry's related records. |
| 5 | PRINCIPAL | PANELS |  | VT_VTS | PANEL_WNSHLD | Shows the PANELS taken from VT_VTS.PANEL_WNSHLD, looked up via PKG_VTS_BODYSHOP.SF_GET_PANEL. |
| 6 | PRINCIPAL | JC_OPEN_DT |  | VH_RO | RO_DATE | Shows the JC_OPEN_DT taken from the enquiry's related records. |
| 7 | PRINCIPAL | JC_CLOSE_DT |  | VH_RO | ACTUAL_DATE | Shows the JC_CLOSE_DT taken from the enquiry's related records. |
| 8 | PRINCIPAL | JC_BILL_DATE |  | VH_RO | BILL_DATE | Shows the JC_BILL_DATE taken from the enquiry's related records. |
| 9 | PRINCIPAL | JC_PROMISE_DATE |  | VH_RO | PROMISED_DATE | Shows the JC_PROMISE_DATE taken from the enquiry's related records. |
| 10 | PRINCIPAL | PROD TIME |  | VH_RO | PRODUCT_TIME | Shows the PROD TIME taken from VH_RO.PRODUCT_TIME, looked up via PKG_VTS_BODYSHOP.SF_GET_PRODUCTIVE_TIME. |
| 11 | PRINCIPAL | IDLE TIME |  | VT_VTS |  | Shows the IDLE TIME linked to VT_VTS, looked up via PKG_VTS_BODYSHOP.SF_GET_VTS_IDLE_TIME. |
| 12 | PRINCIPAL | HOLD TIME |  | VT_VTS_HOLD |  | Shows the HOLD TIME linked to VT_VTS_HOLD, looked up via PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME. |

## 7. Glossary

*Definitions of terms, abbreviations, and acronyms used throughout this document.*

The following table defines key terms, acronyms, and abbreviations used throughout this Business Requirements Document.

| Term | Definition | Aliases | Related Terms |
| :--- | :--- | :--- | :--- |
| B&P | Body and Paint - the repair category code used to filter bodyshop job cards in the delay report | BANDP | Bodyshop, Repair Category |
| Bodyshop | The vehicle body repair and paint workshop within a dealership where vehicles are held for panel work and paint | Body Shop | VTS, Hold Time |
| CB_DOC | Control block in the form that displays the hold-reason summary results | Results Block | CB_DOC_QUERY, Hold Reason |
| CB_DOC_QUERY | Control block in the form that captures the date range query parameters | Query Block | CB_DOC, From Bill Date, To Bill Date |
| CSV | Comma-Separated Values - the file format used for the Excel export output | Excel Export | Export, Report |
| DMS | Dealer Management System - the integrated software platform for dealership operations in which this form runs | - | VTS, Bodyshop |
| DPL | Shared Oracle Forms program library providing common UI utilities, validation routines, and error handling used across DMS forms | - | PLD, Attached Library |
| From Bill Date | The start date of the billing period used to filter bodyshop job cards in the delay summary | FROM_JC_BILL_DT | To Bill Date, Billing Period |
| Hold Reason | A coded category describing why a vehicle was delayed in the bodyshop (e.g. waiting for bay allocation, consultant not available) | Delay Category | Hold Time, VTS |
| Hold Time | The total duration in working hours that a vehicle was delayed in the bodyshop due to a specific hold reason | Delay Duration | Hold Reason, Productive Time, Idle Time |
| Idle Time | The period within a job card when the vehicle is present but no productive work is being performed and no hold reason is recorded | - | Hold Time, Productive Time |
| Job Card | The primary service document created when a vehicle enters the bodyshop for repair; identified by a unique job card number | RO, Repair Order | Bill Date, VTS |
| LOC_CD | Location code identifying the specific service outlet or branch within a dealer group | Location Code | DEALER, PARENT_GROUP |
| PARENT_GROUP | Dealer group identifier that scopes all bodyshop queries to the correct organisational hierarchy | Dealer Group | DEALER, LOC_CD |
| PCK | Oracle PL/SQL package - a compiled database object containing related procedures and functions; PKG_VTS_BODYSHOP is the package used by this form | Package | PKG_VTS_BODYSHOP |
| PRINCIPAL | Map code identifying the vehicle manufacturer or brand principal for multi-company environments | Principal Map Code | PARENT_GROUP |
| PKG_VTS_BODYSHOP | Oracle database package providing VTS analytics functions for hold time, idle time, productive time, and panel count calculations | - | PCK, VTS |
| PLD | Oracle Forms program library (`.pld` source file) containing shared PL/SQL procedures and functions attached to one or more form modules | Program Library | DPL |
| Productive Time | The working hours spent on active repair or paint work on a vehicle, calculated as total open-to-close time minus idle and hold time | - | Hold Time, Idle Time |
| RO | Repair Order - the job card document tracking a vehicle's service visit from intake to billing | Job Card | Bill Date, VTS |
| To Bill Date | The end date of the billing period used to filter bodyshop job cards in the delay summary | TO_BILL_DT | From Bill Date, Billing Period |
| VTS | Vehicle Tracking System - the bodyshop workflow tracking component that records hold events, stage transitions, and time measurements for each repair order | Vehicle Tracking | Hold Time, Bodyshop |

---

---

## 8. Technical Inventory

*Complete inventory of Oracle Forms components including blocks, items, triggers, canvases, and global variables.*

### 8.1 Form Architecture

**Form Module Details:**

- Form Name: vr_veh_wise_delay (VR_VEH_WISE_DELAY)
- Form Module XML Title: MODULE2
- Oracle Forms Version: 12c (Module version 122010400)
- Parent Object Library: DPL.olb (PC_FORM property class)
- Attached Libraries: DMS_EXCEL_REPORT, DPL (DPL.pld program library), D2KWUTIL, WEBUTIL (webutil.olb)
- First Navigation Block: -
- Console Window: WN_MAIN - Vehicle Wise Report (Rel:1.1.1) (inherited from DPL object group; no dedicated form-local window defined)
- Compile Dependencies: Requires DPL.olb, DPL.pld, WEBUTIL.olb, database packages PKG_VTS_BODYSHOP
- Source artifacts: `vr_veh_wise_delay_fmb.xml`; OLB `DPL.olb`; DMS_EXCEL_REPORT; DPL (DPL.pld program library); D2KWUTIL; WEBUTIL (webutil.olb); PCK `PKG_VTS_BODYSHOP.pck`

### 8.1.1 Global Variables

| Global Variable | Data Type | Set Location | Purpose |
| :--- | :--- | :--- | :--- |
| APP_ID | Char | Trigger | Application identifier for the current session; supplied to library routines for session context and Excel export |
| APP_LOG | Char | Trigger | Application log flag or identifier set at session initialisation; used for audit/logging context |
| COMP_FA | Char | ProgramUnit / Trigger | Company/FA identifier for the current dealer context, used to scope bodyshop queries |
| CURRENCY | Char | Trigger | Currency code for the current dealer context; set at session initialisation |
| DEALER | Char | ProgramUnit / Trigger | Dealer map code identifying the current dealer location, used in all VTS data queries |
| FIN_BEG | Char | Trigger | Financial year begin date for the current session context |
| FIN_END | Char | Trigger | Financial year end date for the current session context |
| FROM_NO | Char | ProgramUnit / Trigger | Starting record number for pagination in the document results display |
| FROM_REC | Char | ProgramUnit | Starting record index for the results page currently displayed |
| INCREMENT_NO | Char | ProgramUnit / Trigger | Page size increment used for navigating through result records |
| LOC_CD | Char | ProgramUnit / Trigger | Location code scoping bodyshop hold-time queries to the specific service outlet |
| PARENT_GROUP | Char | ProgramUnit / Trigger | Parent group identifier (e.g. dealer group) used across all bodyshop data queries |
| PRINCIPAL | Char | Trigger | Principal map code used for multi-company filtering of vehicle model and hold reason lookups |
| P_FIN_YR | Char | Trigger | Financial year parameter set at session initialisation; used for period-scoped reporting |
| REPORT_DESC | Char | Trigger | Report description/title string set at session initialisation and displayed on the form header |
| REP_SERVER | Char | Trigger | Report server name used when invoking server-side report generation |
| TALLY_INTEGRATION | Char | Trigger | Flag indicating whether Tally accounting integration is enabled for the current dealer |
| TO_NO | Char | ProgramUnit / Trigger | Ending record number for pagination in the document results display |
| TO_REC | Char | ProgramUnit | Ending record index for the results page currently displayed |
| USERID | Char | ProgramUnit / Trigger | Logged-in user identifier, used to generate unique export file names |
| USER_NAME | Char | Trigger | Display name of the logged-in user; set at session initialisation |

### 8.1.2 Form Parameters

*All 2 ModuleParameter entries from vr_veh_wise_delay_fmb.xml.*

| Parameter | Data Type | Default | Description |
| :--- | :--- | :--- | :--- |
| P_RO_NUM | Char | - | Repair order number passed at form startup; used in the commented-out legacy EXCEL_GENERATION procedure to filter job card details |
| P_APP_ID | Char | - | Application identifier passed at startup; supplied to the Excel export routine for session context |

**Total Parameters:** 2

### 8.2 Blocks

| Block Name | Query Data Source | Records | Q/I/U/D | Key Mode | Master-Detail Relationship |
| :--- | :--- | :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | 1 | N/N/N/N | Default | Control - entry point for date range input and report retrieval |
| CB_DOC | - | 4 | N/N/N/N | Default | Control - displays hold-reason summary results populated programmatically |

**Total Blocks:** 2 business blocks

### 8.2.1 Block WhereClause and OrderByClause

*Block query scope from vr_veh_wise_delay_fmb.xml. **Description** explains filter and sort in business terms; **Order By** and **Where Clause** columns retain verbatim XML text for migration.*

| Block | Description | Order By (XML) | Where Clause (XML) |
| :--- | :--- | :--- | :--- |
| - | No blocks with WhereClause/OrderByClause in vr_veh_wise_delay_fmb.xml | - | - |

### 8.3 Items Summary

*Complete item inventory from `vr_veh_wise_delay_fmb.xml`.*

**Block counts:**

*Database / non-database counts derived from XML.*

| Block | Total Items | Database Items | Non-Database Items |
| :--- | ---: | ---: | ---: |
| CB_DOC_QUERY | 7 | 0 | 7 |
| CB_DOC | 9 | 0 | 9 |
| CB_ERR | 1 | 0 | 1 |
| PB_BLK | 13 | 0 | 13 |
| WEBUTIL | 9 | 0 | 9 |
| **Total** | **39** | **0** | **39** |

**Item detail (all 39 items):**

| Block | Item Name | DatabaseItem | Description |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | FROM_JC_BILL_DT | false | From Bill Date - start date for the job card billing period to query |
| CB_DOC_QUERY | TO_BILL_DT | false | To Bill Date - end date for the job card billing period; defaults to system date if blank |
| CB_DOC_QUERY | SEARCH | false | Search button - initiates the vehicle-wise delay query for the selected date range |
| CB_DOC_QUERY | PB_EXCEL | false | Export to Excel button - generates and downloads CSV report for the selected date range |
| CB_DOC_QUERY | TXT | false | Hidden text field storing the dynamically built SQL query string for Excel export |
| CB_DOC_QUERY | COPYRIGHT_DECLARATION | false | Display field showing copyright/declaration text on the form |
| CB_DOC_QUERY | REPORT_DESC | false | Display item showing the report title/description heading |
| CB_DOC | HOLD_REASON | false | Hold reason description - reason category causing vehicle delay in bodyshop |
| CB_DOC | TOTAL_VEH_AFFECTED | false | Total number of distinct job cards (vehicles) affected by the hold reason |
| CB_DOC | TOTAL_HOLD_UP_TIME | false | Total accumulated hold-up time (hours) across all affected vehicles for the hold reason |
| CB_DOC | WAIT_FOR_BAY_ALLOC_MAN | false | **INACTIVE** - Man-hours waiting for bay allocation (not populated in active flow) |
| CB_DOC | WAIT_FOR_BAY_ALLOC_HOLD | false | **INACTIVE** - Hold time waiting for bay allocation (not populated in active flow) |
| CB_DOC | CONS_NOT_AVAIL_MAN | false | **INACTIVE** - Man-hours for consultant not available delay (not populated in active flow) |
| CB_DOC | CONS_NOT_AVAIL_HOLD | false | **INACTIVE** - Hold time for consultant not available delay (not populated in active flow) |
| CB_DOC | SURVE_DISC_MAN | false | **INACTIVE** - Man-hours for surveyor/discount delay (not populated in active flow) |
| CB_DOC | SURV_DISC_HOLD | false | **INACTIVE** - Hold time for surveyor/discount delay (not populated in active flow) |
| CB_ERR | TXT_ERR | false | Error message text field on the inherited error canvas (CN_ERR); displays runtime error descriptions to the user (inherited from DPL object group) |
| PB_BLK | PB_EXIT | false | Exit button on the inherited toolbar block; triggers KEY-EXIT to close the form (inherited from DPL object group) |
| PB_BLK | PB_LIST | false | List of Values button on the inherited toolbar block; invokes the LOV for the current item (inherited from DPL object group) |
| PB_BLK | PB_INSERT | false | Insert button on the inherited toolbar block; initiates a new record insert (inherited from DPL object group; inactive on this read-only report form) |
| PB_BLK | PM_CONT | false | Context/menu button on the inherited toolbar block (inherited from DPL object group) |
| PB_BLK | PB_DEL | false | Delete button on the inherited toolbar block; deletes the current record (inherited from DPL object group; inactive on this read-only report form) |
| PB_BLK | PB_CANCEL | false | Cancel button on the inherited toolbar block; cancels pending changes (inherited from DPL object group) |
| PB_BLK | PB_SAVE | false | Save button on the inherited toolbar block; commits changes (inherited from DPL object group; inactive on this read-only report form) |
| PB_BLK | PB_PRINT | false | Print button on the inherited toolbar block; invokes the print routine (inherited from DPL object group) |
| PB_BLK | PB_CUT | false | Cut button on the inherited toolbar block; cuts selected text (inherited from DPL object group) |
| PB_BLK | PB_COPY | false | Copy button on the inherited toolbar block; copies selected text (inherited from DPL object group) |
| PB_BLK | PB_PASTE | false | Paste button on the inherited toolbar block; pastes clipboard text (inherited from DPL object group) |
| PB_BLK | PB_ERR_EXIT | false | Error dialog Exit button on the inherited error block; closes the error overlay without action (inherited from DPL object group) |
| PB_BLK | PB_ERR_OK | false | Error dialog OK button on the inherited error block; acknowledges and dismisses the error message (inherited from DPL object group) |
| WEBUTIL | DUMMY | false | Placeholder item required by the WEBUTIL block to satisfy Oracle Forms block structure (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_CLIENTINFO_FUNCTIONS | false | Bean area item hosting the WebUtil client-information Java bean for client-side property retrieval (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILE_FUNCTIONS | false | Bean area item hosting the WebUtil file-functions Java bean for client-side file operations (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_HOST_FUNCTIONS | false | Bean area item hosting the WebUtil host-functions Java bean for executing host commands on the client (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_SESSION_FUNCTIONS | false | Bean area item hosting the WebUtil session-functions Java bean for session-level client utilities (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_FILETRANSFER_FUNCTIONS | false | Bean area item hosting the WebUtil file-transfer Java bean for uploading/downloading files between client and server (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_OLE_FUNCTIONS | false | Bean area item hosting the WebUtil OLE-functions Java bean for client-side OLE automation (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_C_API_FUNCTIONS | false | Bean area item hosting the WebUtil C-API Java bean for low-level client API calls (inherited from webutil.olb) |
| WEBUTIL | WEBUTIL_BROWSER_FUNCTIONS | false | Bean area item hosting the WebUtil browser-functions Java bean for browser control operations such as opening URLs (inherited from webutil.olb) |

### 8.4 List of Values

*No LOVs found in vr_veh_wise_delay_fmb.xml.*

### 8.5 Alerts

| Alert Name | Title | Message Text | Calling Context |
| :--- | :--- | :--- | :--- |
| WEBUTIL_ERROR | Forms | (set at runtime) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL block; displays WebUtil bean error messages at runtime (inherited from webutil.olb) |
| AL_PRINT | Print | (set at runtime) | Inherited alert from DPL object group; displayed by the DPL print routine when confirming or reporting print actions |
| AL_ERRINFO | Error | (set at runtime) | Inherited alert from DPL object group; displays detailed error information to the user via the DPL error-handling framework |
| AL_NOTE | Note | (set at runtime) | Inherited alert from DPL object group; displays informational notes or warnings to the user |
| AL_CONFIRM | Caution | (set at runtime) | Inherited alert from DPL object group; presents a confirmation prompt before destructive or significant operations |

**Total Alerts:** 5

### 8.6 Program Units

*Authoritative catalogue of **5 form-local program units**. Database packages and standalone procedures are in **Section 15.2**; PLD shared-library routines are in **Section 18**.*

| Program Unit | Type | Calls | Description |
| :--- | :--- | :--- | :--- |
| SET_GLOBAL | Procedure | `:global.from_no`, `:global.to_no`, `:global.increment_no` | Initialises pagination global variables (FROM_NO=1, TO_NO=10, INCREMENT_NO=10) at form startup |
| POPULATE | Unknown | `CB_DOC` block (commented) | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It formerly populated the CB_DOC display block from the in-memory document table during paginated result navigation; it is no longer referenced by any active code. |
| DOC_DET | Unknown | `pk_plsql_table.code_tab6` (commented) | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It formerly declared an in-memory PL/SQL table (`v_doc_tab` of type `pk_plsql_table.code_tab6`) used by the old paginated result display approach; it is no longer referenced by any active code. |
| EXCEL_GENERATION | Unknown | `general.disp_text`, `ph_issue`, `vh_ro`, `vm_rcateg`, `gm_cin` (commented) | **INACTIVE** - This program unit's body is a null statement; all logic is commented out and does not execute. It was formerly a server-side CSV generation procedure that queried vehicle repair order data and wrote job card details to a file, but was superseded by the VIEW_EXCEL_REPORT_NEW library routine and its invocation was removed in August 2016. |
| VIEW_EXCEL_REP | Procedure | `Id_Null`, `Delete_Group`, `Create_Group_From_Query`, `Populate_Group`, `Get_Group_Row_Count`, `Find_Column`, `GET_GROUP_CHAR_CELL`, `Text_IO`, `web.show_document` | Generates a CSV file from a SQL query via record group, writes it to the application server, and opens it in the browser; not invoked in the current active code path |

**Total Program Units:** 5

### 8.7 Triggers

**Item-Level Trigger Types (reference):**

| Trigger Name | Purpose |
| :--- | :--- |
| WHEN-VALIDATE-ITEM | Validates field when user leaves item |
| KEY-* | Keyboard actions - commit, exit, LOV, navigation |
| WHEN-NEW-BLOCK-INSTANCE | Initializes block on entry |
| WHEN-BUTTON-PRESSED | Executes button action |
| PRE-INSERT / POST-INSERT | Before/after record creation |
| WHEN-LIST-CHANGED | Dropdown selection changed |
| PRE-QUERY / POST-QUERY | Before/after query execution |
| WHEN-CHECKBOX-CHANGED | Checkbox toggled |
| WHEN-VALIDATE-RECORD | Validates entire record before leaving row |

**DPL library routines invoked from triggers and program units:**

| Routine | Type | Called From | Purpose |
| :--- | :--- | :--- | :--- |
| GENERAL.ASK_CONFIRM | Library routine | Form level | Displays a modal confirmation dialog and returns the user's response; used by inherited DPL triggers to confirm destructive actions |
| GENERAL.DISP_TEXT | Library routine | Form level, ProgramUnit: EXCEL_GENERATION (commented) | Displays a modal message dialog with a title and message text; referenced in the active ON-ERROR path and in commented-out EXCEL_GENERATION code |
| GENERAL.RAISE_ERROR | Library routine | Form level | Looks up and displays a coded error message from the message table; referenced in the inherited error-handling framework |

### 8.7.1 Inactive / Commented-Out Trigger Register

*Triggers and field validations where XML source is `null;`, fully block-commented, or legacy code preserved but not executed. Do **not** migrate these as active business requirements.*

| Status | Block | Item | Trigger | Former behaviour (preserved in comments) | Disabled since / note |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Inactive stub** | Form | - | ON-ERROR | Previously handled Oracle Forms errors 40209/40207, constraint violations (E0088), stale-record errors 40654-40659, SQLCODE errors, and navigation errors 40401/40405 using GENERAL.DISP_TEXT and GENERAL.RAISE_ERROR | Body is `null;` with all logic block-commented; superseded by inherited error handling from DPL object group |
| **Inactive stub** | Form | - | KEY-CLRFRM | Previously cleared FROM_JC_BILL_DT, TO_BILL_DT, HOLD_REASON, TOTAL_VEH_AFFECTED, and TOTAL_HOLD_UP_TIME fields on form clear | Body is `null;` with field-clearing logic block-commented |
| **Inactive stub** | Form | - | FT_CANCEL | Previously provided a form-local override for the inherited FT_CANCEL toolbar trigger; no custom behaviour documented | Body is `null;`; inherited DPL cancel behaviour applies |
| **Inactive stub** | Form | - | FT_DEL | Previously provided a form-local override for the inherited FT_DEL toolbar trigger; no custom delete behaviour documented | Body is `null;`; inherited DPL delete behaviour applies |
| **Inactive stub** | Form | - | FT_LIST | Previously provided a form-local override for the inherited FT_LIST toolbar trigger; no custom LOV behaviour documented | Body is `null;`; inherited DPL list behaviour applies |
| **Commented out** | Form | - | WHEN-NEW-FORM-INSTANCE | Previously initialised session globals (DEALER, LOC_CD, COMP_FA, USERID, PRINCIPAL, PARENT_GROUP, APP_ID, etc.) from the DPL session context and called SET_GLOBAL for pagination setup | Logic is fully block-commented; session initialisation now handled by the inherited DPL WHEN-NEW-FORM-INSTANCE trigger from the object group |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-UP | No prior custom behaviour documented; inherited KEY-UP navigation suppressed for this block | Body is `NULL;` - disables upward navigation within CB_DOC_QUERY |
| **Inactive stub** | CB_DOC_QUERY | - | KEY-DOWN | No prior custom behaviour documented; inherited KEY-DOWN navigation suppressed for this block | Body is `NULL;` - disables downward navigation within CB_DOC_QUERY |

*Additional null-only or partially commented triggers exist on estimation and legacy blocks - see XML `TriggerText` starting with `null;` or `/*`.*

**Complete trigger inventory (39 business triggers):**
*vr_veh_wise_delay_fmb.xml contains Trigger elements.*

| Trigger Name | Block | Item | Called From / Context | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| ON-ERROR | Form | - | Form level | **INACTIVE** - Body is `null;`; all custom error handling logic is block-commented; superseded by inherited DPL error handling |
| ON-MESSAGE | Form | - | Form level | **INACTIVE** - Empty body; trigger has no active logic in this form version (body is fully commented out) |
| KEY-EXIT | Form | - | Form level | Clears session application info, erases pagination globals (from_no, to_no, increment_no), and exits the form without validation |
| KEY-LISTVAL | Form | - | Form level | Inherited LOV invocation key; subclassed from DPL; no form-level override body |
| KEY-COMMIT | Form | - | Form level | Inherited commit key; subclassed from DPL; no form-level override - commit is suppressed on this read-only report form |
| KEY-CLRFRM | Form | - | Form level | **INACTIVE** - Body is `null;`; form-clear logic is block-commented |
| KEY-UP | Form | - | Form level | Inherited upward navigation key from DPL object group; provides standard block navigation at form level (inherited) |
| KEY-DOWN | Form | - | Form level | Inherited downward navigation key from DPL object group; provides standard block navigation at form level (inherited) |
| KEY-PRVBLK | Form | - | Form level | Inherited previous-block navigation key from DPL object group; navigates to the previous block (inherited) |
| KEY-NXTBLK | Form | - | Form level | Inherited next-block navigation key from DPL object group; navigates to the next block (inherited) |
| KEY-PREV-ITEM | Form | - | Form level | Inherited previous-item navigation key from DPL object group; moves focus to the previous item (inherited) |
| KEY-NEXT-ITEM | Form | - | Form level | Inherited next-item navigation key from DPL object group; moves focus to the next item (inherited) |
| KEY-OTHERS | Form | - | Form level | Inherited catch-all key handler from DPL object group; suppresses or handles unmapped keystrokes (inherited) |
| FT_SAVE | Form | - | Form level | Inherited toolbar Save trigger from DPL object group; commits changes - inactive on this read-only report form (inherited) |
| FT_CANCEL | Form | - | Form level | **INACTIVE** - Body is `null;`; form-local override of the inherited FT_CANCEL toolbar trigger; inherited DPL cancel behaviour applies |
| FT_INSERT | Form | - | Form level | Inherited toolbar Insert trigger from DPL object group; initiates a new record insert - inactive on this read-only report form (inherited) |
| FT_DEL | Form | - | Form level | **INACTIVE** - Body is `null;`; form-local override of the inherited FT_DEL toolbar trigger; inherited DPL delete behaviour applies |
| FT_LIST | Form | - | Form level | **INACTIVE** - Body is `null;`; form-local override of the inherited FT_LIST toolbar trigger; inherited DPL LOV behaviour applies |
| FT_PRINT | Form | - | Form level | Inherited toolbar Print trigger from DPL object group; invokes the DPL print routine (inherited) |
| WHEN-NEW-FORM-INSTANCE | Form | - | Form level | **Commented out** - Logic block-commented; session initialisation (DEALER, LOC_CD, COMP_FA, USERID, PRINCIPAL, PARENT_GROUP, APP_ID, pagination globals) formerly performed here is now handled by the inherited DPL WHEN-NEW-FORM-INSTANCE trigger |
| PRE-FORM | Form | - | Form level | Registers the form module name in the Oracle session using DBMS_APPLICATION_INFO for monitoring and tracing |
| KEY-UP | CB_DOC_QUERY | - | CB_DOC_QUERY | **INACTIVE** - Body is `NULL;`; disables upward navigation within the query control block |
| KEY-DOWN | CB_DOC_QUERY | - | CB_DOC_QUERY | **INACTIVE** - Body is `NULL;`; disables downward navigation within the query control block |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Clears result fields, then validates that From Bill Date is not null and does not exceed the current system date |
| KEY-NEXT-ITEM | CB_DOC_QUERY | FROM_JC_BILL_DT | CB_DOC_QUERY.FROM_JC_BILL_DT | Clears result fields and navigates to the To Bill Date field; old date-range auto-fill logic is block-commented |
| WHEN-VALIDATE-ITEM | CB_DOC_QUERY | TO_BILL_DT | CB_DOC_QUERY.TO_BILL_DT | Validates that To Bill Date does not exceed today, is not earlier than From Bill Date, and that the date range does not exceed 31 days; defaults To Bill Date to system date if blank |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | SEARCH | CB_DOC_QUERY.SEARCH | Executes the vehicle-wise delay summary query using the date range and session globals; populates CB_DOC with hold reason, affected job cards, and total hold time per reason |
| WHEN-BUTTON-PRESSED | CB_DOC_QUERY | PB_EXCEL | CB_DOC_QUERY.PB_EXCEL | Builds a dynamic SQL query for full job card detail export, stores it in TXT field, and calls the Excel report library to generate and download the CSV file |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_EXIT | PB_BLK.PB_EXIT (inherited) | Inherited toolbar Exit button handler; fires KEY-EXIT to clear session context and close the form (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_LIST | PB_BLK.PB_LIST (inherited) | Inherited toolbar LOV button handler; invokes the LOV for the currently focused item (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_INSERT | PB_BLK.PB_INSERT (inherited) | Inherited toolbar Insert button handler; initiates a new record insert - inactive on this read-only report form (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PM_CONT | PB_BLK.PM_CONT (inherited) | Inherited toolbar context/menu button handler (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_DEL | PB_BLK.PB_DEL (inherited) | Inherited toolbar Delete button handler; deletes the current record - inactive on this read-only report form (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CANCEL | PB_BLK.PB_CANCEL (inherited) | Inherited toolbar Cancel button handler; cancels pending changes (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_SAVE | PB_BLK.PB_SAVE (inherited) | Inherited toolbar Save button handler; commits changes - inactive on this read-only report form (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PRINT | PB_BLK.PB_PRINT (inherited) | Inherited toolbar Print button handler; invokes the DPL print routine (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_CUT | PB_BLK.PB_CUT (inherited) | Inherited toolbar Cut button handler; cuts selected text to clipboard (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_COPY | PB_BLK.PB_COPY (inherited) | Inherited toolbar Copy button handler; copies selected text to clipboard (inherited from DPL object group) |
| WHEN-BUTTON-PRESSED | PB_BLK | PB_PASTE | PB_BLK.PB_PASTE (inherited) | Inherited toolbar Paste button handler; pastes clipboard text into the current item (inherited from DPL object group) |

### 8.8 Canvas and Window Inventory

**Windows:**

| Window | Title | Primary Canvas |
| :--- | :--- | :--- |
| WIN_ERR | - | CN_ERR |
| WN_MAIN | Vehicle Wise Report (Rel:1.1.1) | CN_MAIN |

**Canvases:**

| Canvas | Type | Window |
| :--- | :--- | :--- |
| CN_TOOL | Content | WN_MAIN (inherited) |
| CN_MAIN | Content | WN_MAIN (inherited) |
| CN_ERR | Content | WIN_ERR (inherited) |

---

### 8.9 Editors

*No editors found in vr_veh_wise_delay_fmb.xml.*

### 8.10 Form-Local Visual Attributes, Property Classes, and Object Groups

#### 8.10.1 Visual Attributes (form-defined)

*0 VisualAttribute elements defined at form level (not inherited from DPL.olb).*

*No form-local visual attributes found in vr_veh_wise_delay_fmb.xml.*

#### 8.10.2 Property Classes (form-defined)

*Form-local PropertyClass elements.*

*No form-local property classes found in vr_veh_wise_delay_fmb.xml.*

#### 8.10.3 Object Groups

*Object groups bundle inherited triggers and visual objects applied form-wide at runtime.*

| Object Group Child | Type |
| :--- | :--- |
| KEY-OTHERS | Inherited trigger |
| KEY-NEXT-ITEM | Inherited trigger |
| KEY-PREV-ITEM | Inherited trigger |
| KEY-NXTBLK | Inherited trigger |
| KEY-PRVBLK | Inherited trigger |
| KEY-DOWN | Inherited trigger |
| KEY-UP | Inherited trigger |
| CN_ERR | Inherited canvas |
| VA_DISP | Inherited visualattribute |
| CB_ERR | Inherited block |
| VA_LOV | Inherited visualattribute |
| VA_TRNI_DT | Inherited visualattribute |
| VA_TITLE | Inherited visualattribute |
| VA_ALERT | Inherited visualattribute |
| VA_BUTN | Inherited visualattribute |
| VA_TEXT | Inherited visualattribute |
| VA_MPROMPT | Inherited visualattribute |
| VA_OPROMPT | Inherited visualattribute |
| VA_MAND | Inherited visualattribute |
| VA_NUM | Inherited visualattribute |
| VA_DESC | Inherited visualattribute |
| VA_ICONIC_BUTN | Inherited visualattribute |
| VA_RB | Inherited visualattribute |
| VA_CB | Inherited visualattribute |
| WN_MAIN | Inherited window |
| POP_MAIN | Inherited trigger |
| CN_MAIN | Inherited canvas |
| CN_TOOL | Inherited canvas |
| PB_BLK | Inherited block |
| AL_ERRINFO | Inherited alert |
| AL_NOTE | Inherited alert |
| AL_CONFIRM | Inherited alert |
| WIN_ERR | Inherited window |
| AL_PRINT | Inherited alert |
| FT_SAVE | Inherited trigger |
| FT_CANCEL | Inherited trigger |
| FT_INSERT | Inherited trigger |
| FT_DEL | Inherited trigger |
| FT_LIST | Inherited trigger |
| FT_PRINT | Inherited trigger |
| WHEN-NEW-FORM-INSTANCE | Inherited trigger |

### 8.11 DataSourceColumn Inventory

*No DataSourceColumns found in vr_veh_wise_delay_fmb.xml.*

## 9. Object Library

*The form references objects from two external Object Library files: the DPL standard library (`DPL_olb.xml`), subclassed via the `OG_GROUP` object group, and the WebUtil library (`webutil_olb.xml`), subclassed via the `WEBUTIL` object group. The DPL library provides the standard visual attributes and property classes applied across forms in this system. The WebUtil library provides the standard client-integration block, canvas, window, and alert objects used for file-transfer and browser integration.*

Source OLB file(s): DPL_olb.xml, webutil_olb.xml

| Name | Type | Description | Used By (count) | Sample Items |
| ---- | ---- | ----------- | --------------- | ------------ |
| VA_CB | VisualAttribute | Standard visual attribute for check box items | Referenced via OG_GROUP (DPL_olb) | Check box items inheriting DPL standard style |
| VA_RB | VisualAttribute | Standard visual attribute for radio button items | Referenced via OG_GROUP (DPL_olb) | Radio button items inheriting DPL standard style |
| VA_ICONIC_BUTN | VisualAttribute | Standard visual attribute for iconic push buttons | Referenced via OG_GROUP (DPL_olb) | Iconic button items inheriting DPL standard style |
| VA_DESC | VisualAttribute | Standard visual attribute for description/label text items | Referenced via OG_GROUP (DPL_olb) | Description text items |
| VA_NUM | VisualAttribute | Standard visual attribute for numeric items | Referenced via OG_GROUP (DPL_olb) | Numeric items |
| VA_MAND | VisualAttribute | Standard visual attribute for mandatory fields | Referenced via OG_GROUP (DPL_olb) | Mandatory input fields |
| VA_OPROMPT | VisualAttribute | Standard visual attribute for optional-field prompts | Referenced via OG_GROUP (DPL_olb) | Optional prompt labels |
| VA_MPROMPT | VisualAttribute | Standard visual attribute for mandatory-field prompts | Referenced via OG_GROUP (DPL_olb) | Mandatory prompt labels |
| VA_TEXT | VisualAttribute | Standard visual attribute for standard text items | Referenced via OG_GROUP (DPL_olb) | Text input items |
| VA_BUTN | VisualAttribute | Standard visual attribute for push buttons | Referenced via OG_GROUP (DPL_olb) | Push button items (e.g. Search, Export to Excel) |
| VA_ALERT | VisualAttribute | Standard visual attribute for alert display | Referenced via OG_GROUP (DPL_olb) | Alert dialog formatting |
| VA_TITLE | VisualAttribute | Standard visual attribute for title/header text | Referenced via OG_GROUP (DPL_olb) | Title text items |
| VA_TRNI_DT | VisualAttribute | Standard visual attribute for transaction date fields | Referenced via OG_GROUP (DPL_olb) | Date fields such as From Bill Date, To Bill Date |
| VA_LOV | VisualAttribute | Standard visual attribute for LOV-enabled fields | Referenced via OG_GROUP (DPL_olb) | Fields with list-of-values buttons |
| VA_DISP | VisualAttribute | Standard visual attribute for display-only items | Referenced via OG_GROUP (DPL_olb) | Read-only display items (e.g. REPORT_DESC) |
| PC_DESC | PropertyClass | Property class for description text items | Referenced via OG_GROUP (DPL_olb) | Description/label items |
| PC_SC_DATE | PropertyClass | Property class for date fields (comment: PROPERTY CLASS FOR DATE) | Referenced via OG_GROUP (DPL_olb) | Date input items |
| PC_TITLE | PropertyClass | Property class for title text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Title/heading items |
| PC_FORMAT | PropertyClass | Property class for formatted text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Formatted text items |
| PC_MR_BLK | PropertyClass | Property class for master-record blocks | Referenced via OG_GROUP (DPL_olb) | Block-level property inheritance |
| PC_DISP | PropertyClass | Property class for display-only text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Display items |
| PC_LOV | PropertyClass | Property class for list-of-values items (comment: PROPERTY CLASS FOR LIST OF VALUES) | Referenced via OG_GROUP (DPL_olb) | LOV-linked items |
| PC_FORM | PropertyClass | Property class for form-level objects | Referenced via OG_GROUP (DPL_olb) | Form-level property inheritance |
| PC_DISP_DATE | PropertyClass | Property class for display-only date items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Read-only date display items |
| PC_DISP_NUM | PropertyClass | Property class for display-only numeric items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Read-only numeric display items |
| PC_DATE | PropertyClass | Property class for editable date items (comment: PROPERTY CLASS FOR DATE) | Referenced via OG_GROUP (DPL_olb) | Editable date input items |
| PC_DTTIME | PropertyClass | Property class for date-and-time items (comment: Property class for Date and Time) | Referenced via OG_GROUP (DPL_olb) | Date-time combination items |
| PC_CB | PropertyClass | Property class for check box items | Referenced via OG_GROUP (DPL_olb) | Check box items |
| PC_ALERT | PropertyClass | Property class for alert objects | Referenced via OG_GROUP (DPL_olb) | Alert dialogs including AL_ERRINFO |
| PC_MDATE | PropertyClass | Property class for mandatory date items (comment: PROPERTY CLASS FOR DATE) | Referenced via OG_GROUP (DPL_olb) | Mandatory date input items |
| PC_RB | PropertyClass | Property class for radio button items | Referenced via OG_GROUP (DPL_olb) | Radio button items |
| PC_WIND | PropertyClass | Property class for window objects (comment: PROPERTY CLASS FOR WINDOWS) | Referenced via OG_GROUP (DPL_olb) | Window-level property inheritance |
| PC_CANV | PropertyClass | Property class for canvas objects | Referenced via OG_GROUP (DPL_olb) | Canvas-level property inheritance |
| PC_BUTN | PropertyClass | Property class for push button items (comment: PROPERTY CLASS FOR PUSH BUTTONS) | Referenced via OG_GROUP (DPL_olb) | Push buttons (Search, Export to Excel) |
| PC_TEXT | PropertyClass | Property class for standard text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Standard text input items |
| PC_MTEXT | PropertyClass | Property class for mandatory text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Mandatory text input items |
| PC_UTEXT | PropertyClass | Property class for uppercase text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Uppercase text fields |
| PC_MUTEXT | PropertyClass | Property class for mandatory uppercase text items (comment: PROPERTY CLASS FOR TEXT ITEMS) | Referenced via OG_GROUP (DPL_olb) | Mandatory uppercase text fields |
| PC_NUM | PropertyClass | Property class for numeric items (comment: PROPERTY CLASS FOR NUMERIC ITEMS) | Referenced via OG_GROUP (DPL_olb) | Numeric input items (e.g. TOTAL_VEH_AFFECTED, TOTAL_HOLD_UP_TIME) |
| PC_MNUM | PropertyClass | Property class for mandatory numeric items (comment: PROPERTY CLASS FOR NUMERIC ITEMS) | Referenced via OG_GROUP (DPL_olb) | Mandatory numeric input items |
| PC_ICONIC_BUTN | PropertyClass | Property class for iconic push buttons (comment: PROPERTY CLASS FOR PUSH BUTTONS) | Referenced via OG_GROUP (DPL_olb) | Iconic push buttons |
| PC_SCROLL | PropertyClass | Property class for scrollable block/canvas objects | Referenced via OG_GROUP (DPL_olb) | Scrollable results area |
| WEBUTIL | ObjectGroup | The WebUtil object group containing the complete set of client-integration objects for WebUtil (comment: The WebUtil object group contains everything needed to use WebUtil). Provides the WEBUTIL block, canvas, hidden window, and error alert subclassed into this form. | 4 form objects (WEBUTIL block, WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW, WEBUTIL_ERROR alert) | WEBUTIL block (all items), WEBUTIL_CANVAS, WEBUTIL_HIDDEN_WINDOW, WEBUTIL_ERROR |
| WEBUTIL_NO_OLE | ObjectGroup | Alternative WebUtil object group for environments without OLE support (comment: The WebUtil object group contains everything needed to use WebUtil). Not subclassed into this form. | not used by this form | N/A |

---

## 10. Record Groups

*No record groups found in `vr_veh_wise_delay_fmb.xml`.*

## 11. Referenced Database Objects

*Database tables, views, and objects accessed by the form.*

| Block | Base Table | Primary Key Item | Database Item |
| :--- | :--- | :--- | :--- |
| CB_DOC_QUERY | - | - | No |
| CB_DOC | - | - | No |

| Object | Schema | Used In | Description |
| :--- | :--- | :--- | :--- |
| `DUAL` | - | Trigger WHEN-BUTTON-PRESSED, Trigger WHEN-NEW-FORM-INSTANCE | Oracle standard single-row utility table - used to anchor the CSV header row in the union query for Excel export, and to perform lightweight initialisation selects at form startup |
| `VH_RO` | - | Trigger WHEN-BUTTON-PRESSED | Vehicle repair order master - source of job card records including bill date, location, and dealer identity for delay analysis |
| `VM_SVAR` | - | Trigger WHEN-BUTTON-PRESSED | Vehicle model variant master - looked up by principal and model code to retrieve model description for the Excel export |

**Total Referenced Objects:** 3

---

## 12. Backend Procedures and Packages

### 12.1 Main Flow Backend Procedure/Package Index

| Requirement ID | Procedure/Package | Purpose |
| -------------- | ----------------- | ------- |
| BR-001 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Tags the database session with the form module name on form open for session traceability |
| BR-001 | DBMS_APPLICATION_INFO.SET_MODULE | Sets the database session's module and action names on form open for operational monitoring |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE | Calculates the adjusted hold time (in working shift hours) for a single hold-record line on a repair order, used to aggregate total hold time by hold reason |
| BR-004 | PKG_VTS_BODYSHOP.SF_GET_DATE_NUM | Internal package helper that converts a date to a numeric day-sequence value used by hold-time and shift calculations within PKG_VTS_BODYSHOP |
| BR-004 | PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR | Internal package helper that returns the number of working hours within a shift for a given date, used by hold-time calculations within PKG_VTS_BODYSHOP |
| BR-004 | PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN | Internal package helper that returns the shift start time for a given date, used by hold-time boundary calculations within PKG_VTS_BODYSHOP |
| BR-004 | PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT | Internal package helper that returns the shift end time for a given date, used by hold-time boundary calculations within PKG_VTS_BODYSHOP |
| BR-005 | VIEW_EXCEL_REPORT_NEW | Executes the dynamically built query, generates the CSV export file, and opens it for the user to download |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_PANEL | Returns the total body panel count for a repair order, used as the panel count column in the detailed Excel export |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_PRODUCTIVE_TIME | Returns the total productive working time for a repair order, used as the productive time column in the detailed Excel export |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_VTS_IDLE_TIME | Returns the total idle time (excluding hold and productive periods) for a repair order, used as the idle time column in the detailed Excel export |
| BR-005 | PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME | Returns the total aggregated hold time for a repair order across all hold events, used as the overall hold time column in the detailed Excel export |
| BR-006 | DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Clears the database session's client identifier on form exit |
| BR-006 | DBMS_APPLICATION_INFO.SET_MODULE | Clears the database session's module and action names on form exit |
| - | GENERAL.ASK_CONFIRM | Displays a confirmation dialog and returns the user's numeric choice; gates all toolbar push-button actions behind explicit user confirmation |
| - | GENERAL.CHECK_FORM_FAILURE | Inspects Oracle Forms failure state after a commit and raises an application error if the commit did not succeed |
| - | GENERAL.DISP_TEXT | Displays a modal dialog with supplied text and title; called from the ON-MESSAGE trigger to present informational messages in a standardised dialog |
| - | WEBUTIL_CORE.CUSTOMEVENTHANDLER | Central WebUtil event dispatcher that routes custom item events from the WebUtil Java bean to the appropriate WebUtil function group handler |
| - | WEBUTIL.ID_NULL | Checks whether a record group handle is NULL before attempting to delete it; called in the VIEW_EXCEL_REP program unit to prevent errors on first-run |

---

### 12.2 Procedure and Package Catalogue

| Procedure/Package | Type | Called From | Purpose |
| ----------------- | ---- | ----------- | ------- |
| DBMS_APPLICATION_INFO.SET_CLIENT_INFO | Oracle built-in package procedure | PRE-FORM trigger (form-level); KEY-EXIT trigger (form-level) | Sets (on open) or clears (on exit) the client identifier registered against the current database session, enabling operations staff to identify this report session in the active sessions view |
| DBMS_APPLICATION_INFO.SET_MODULE | Oracle built-in package procedure | PRE-FORM trigger (form-level); KEY-EXIT trigger (form-level) | Sets (on open) or clears (on exit) the module name and action name registered against the current database session for session monitoring |
| PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE | Database package function (`PKG_VTS_BODYSHOP`) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.SEARCH (as a scalar function called inside a cursor query's SELECT list) | Calculates the adjusted hold time for one VTS hold record line, accounting for single-day vs. multi-day spans, applicable work-shift schedules, and public holidays recorded in the dealership's holiday calendar. Signature: `sf_get_vts_holdtime_line(p_pgroup VARCHAR2, p_dealermap NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_ronum VARCHAR2, p_stage VARCHAR2, p_line NUMBER)`. Returns 0 or a positive decimal number of working hours |
| PKG_VTS_BODYSHOP.SF_GET_DATE_NUM | Database package function (`PKG_VTS_BODYSHOP`) | Called internally within PKG_VTS_BODYSHOP routines invoked from WHEN-BUTTON-PRESSED triggers on CB_DOC_QUERY.SEARCH and CB_DOC_QUERY.PB_EXCEL | Internal helper that converts a date value to a numeric day-sequence identifier used by shift-schedule and hold-time boundary calculations throughout the package |
| PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR | Database package function (`PKG_VTS_BODYSHOP`) | Called internally within PKG_VTS_BODYSHOP routines invoked from WHEN-BUTTON-PRESSED triggers on CB_DOC_QUERY.SEARCH and CB_DOC_QUERY.PB_EXCEL | Internal helper that returns the total number of working hours in the applicable shift for a given date; used by `sf_get_vts_holdtime_line` and related hold-time functions to determine per-day working capacity |
| PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN | Database package function (`PKG_VTS_BODYSHOP`) | Called internally within PKG_VTS_BODYSHOP routines invoked from WHEN-BUTTON-PRESSED triggers on CB_DOC_QUERY.SEARCH and CB_DOC_QUERY.PB_EXCEL | Internal helper that returns the shift start time for a given date; used to calculate the working-hours boundary at the beginning of a hold period |
| PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT | Database package function (`PKG_VTS_BODYSHOP`) | Called internally within PKG_VTS_BODYSHOP routines invoked from WHEN-BUTTON-PRESSED triggers on CB_DOC_QUERY.SEARCH and CB_DOC_QUERY.PB_EXCEL | Internal helper that returns the shift end time for a given date; used to calculate the working-hours boundary at the end of a hold period |
| PKG_VTS_BODYSHOP.SF_GET_PANEL | Database package function (`PKG_VTS_BODYSHOP`) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.PB_EXCEL (embedded in dynamic export SQL string) | Returns the total panel count (sum of PANEL_WNSHLD) from the VT_VTS table for the given repair order. Signature: `sf_get_panel(p_pgroup VARCHAR2, p_dealermap NUMBER, p_loc VARCHAR2, p_comp VARCHAR2, p_ronum VARCHAR2)`. Returns 0 when no records match. Used to populate the panel count column in the Excel export |
| PKG_VTS_BODYSHOP.SF_GET_PRODUCTIVE_TIME | Database package function (`PKG_VTS_BODYSHOP`) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.PB_EXCEL (embedded in dynamic export SQL string) | Returns the total productive working time for the specified repair order by querying VTS stage records and applying shift schedule calculations; used to populate the productive time column in the Excel export |
| PKG_VTS_BODYSHOP.SF_GET_VTS_IDLE_TIME | Database package function (`PKG_VTS_BODYSHOP`) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.PB_EXCEL (embedded in dynamic export SQL string) | Returns the total idle time for the specified repair order - time that is neither productive nor on hold - by querying VTS stage records; used to populate the idle time column in the Excel export |
| PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME | Database package function (`PKG_VTS_BODYSHOP`) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.PB_EXCEL (embedded in dynamic export SQL string) | Returns the total accumulated hold time across all hold events for the specified repair order; used to populate the overall hold time column in the Excel export |
| VIEW_EXCEL_REPORT_NEW | Attached library procedure (DMS_EXCEL_REPORT library - external, not in bundle) | WHEN-BUTTON-PRESSED trigger on CB_DOC_QUERY.PB_EXCEL | Accepts a principal identifier, output filename, SQL query string, column name, and application identifier; executes the query; writes the result to a CSV file; and presents the file to the user for download via the browser |
| GENERAL.ASK_CONFIRM | Attached library function (`DPL.pld` - GENERAL package) | WHEN-BUTTON-PRESSED triggers on PB_BLK.PB_COPY, PB_BLK.PB_CUT, PB_BLK.PB_DEL, PB_BLK.PB_EXIT, PB_BLK.PB_INSERT, PB_BLK.PB_LIST, PB_BLK.PB_PASTE, PB_BLK.PB_PRINT, PB_BLK.PB_SAVE; WHEN-BUTTON-PRESSED on WEBUTIL.DUMMY | Displays a confirmation dialog containing the supplied message and returns a numeric response indicating the user's choice. Gates every toolbar push-button action and the WEBUTIL dummy item trigger behind explicit user confirmation before proceeding. Signature: `ASK_CONFIRM(confirm_msg VARCHAR2) RETURN NUMBER` |
| GENERAL.CHECK_FORM_FAILURE | Attached library procedure (`DPL.pld` - GENERAL package) | KEY-COMMIT trigger (form-level) | Inspects the current Oracle Forms failure state after a commit operation and raises an application error if the commit did not succeed, ensuring that any database write failure is surfaced to the user rather than silently ignored |
| GENERAL.DISP_TEXT | Attached library procedure (`DPL.pld` - GENERAL package) | ON-MESSAGE trigger (form-level) | Displays a modal dialog box with the supplied text and title. Called from the form-level ON-MESSAGE trigger to present Oracle Forms informational and status messages to the user in a standardised dialog rather than the default status-bar display. Signature: `DISP_TEXT(text_string VARCHAR2, title_string VARCHAR2)` |
| GENERAL.RAISE_ERROR | Attached library procedure (`DPL.pld` - GENERAL package) | ON-ERROR trigger (form-level) - **commented out / inactive** | Looks up a message record by the supplied error code and displays the corresponding message and title using DISP_TEXT. Referenced only in the block-commented ON-ERROR trigger body to handle Oracle constraint violation error E0088; not executed in the current active form code |
| WEBUTIL_CORE.CUSTOMEVENTHANDLER | WebUtil library procedure (`webutil.pld` - WEBUTIL_CORE package) | WHEN-CUSTOM-ITEM-EVENT triggers on WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, WEBUTIL.WEBUTIL_C_API_FUNCTIONS, WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, WEBUTIL.WEBUTIL_FILE_FUNCTIONS, WEBUTIL.WEBUTIL_HOST_FUNCTIONS, WEBUTIL.WEBUTIL_OLE_FUNCTIONS, WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher that receives the name and serialised parameters of a custom item event fired by the WebUtil Java bean and routes it to the appropriate WebUtil function group handler. All WHEN-CUSTOM-ITEM-EVENT triggers on the WEBUTIL block bean items delegate immediately to this procedure, allowing all client-side callback responses across browser, client-info, C-API, file transfer, file, host, OLE, and session function groups to be processed through a single coordinated entry point. Signature: `CUSTOMEVENTHANDLER(EventName IN VARCHAR2, EventParameters IN VARCHAR2)` |
| WEBUTIL.ID_NULL | WebUtil library function (`webutil.pld` - WEBUTIL_C_API package) | Program unit VIEW_EXCEL_REP | Checks whether a record group handle is NULL. Called in VIEW_EXCEL_REP before attempting to delete an existing record group named 'DataRecordSet'; returns TRUE if the handle is null, FALSE if the group exists, preventing an error when the group has not yet been created. Signature: `ID_NULL(handle IN Pointer) RETURN BOOLEAN` |
| WEB.SHOW_DOCUMENT | Oracle Forms built-in package procedure | Program unit VIEW_EXCEL_REP (inactive - no active call sites in this form version) | Opens a URL in a new browser window; referenced only in the superseded VIEW_EXCEL_REP program unit which is no longer invoked from any trigger |

## 13. Package Procedure Specifications

*Behavioural requirements for each database package invoked from the form. Only packages referenced in the form XML that have a matching source ``.pck`` file in the input directory are listed. Descriptions are derived from the package bodies in the uploaded PCK sources.*

| ID | Package | Description | Business Requirement | Acceptance Criteria |
| :--- | :--- | :--- | :--- | :--- |
| BR-T-PKG-VTS-BODYSHOP | PKG_VTS_BODYSHOP | Bodyshop VTS (Vehicle Tracking System) analytics engine - calculates hold time, idle time, productive time, and panel count per repair order using shift schedules and hold event records | The form depends on this package to compute per-line hold-time contributions and panel totals that are displayed in the delay summary and exported to Excel | sf_get_vts_holdtime_line returns a non-negative hold duration in working hours for the given RO and stage/serial line; sf_get_panel returns the total panel count from VT_VTS for the given RO |

**Total Matched Packages:** 1

## 14. Database Package Catalogue

*Detailed specifications for each database package routine called from the form, including signatures and business rules.*
**Source PCK file(s):** PKG_VTS_BODYSHOP.pck

| Source File (.pck) | Package | Routine Name | Type | Definition (signature / excerpt) | Called From | Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_panel | Function | function sf_get_panel(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_comp varchar2, p_ronum varchar2) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL | Returns the total panel count (sum of PANEL_WNSHLD) from the VT_VTS table for the given repair order. Accepts parent group, dealer map code, location, company FA, and RO number. Returns 0 when no records match. Called inline within the dynamically built SQL string that generates the Excel export CSV, providing the panel count column per job card. |
| PKG_VTS_BODYSHOP.pck | PKG_VTS_BODYSHOP | sf_get_vts_holdtime_line | Function | function sf_get_vts_holdtime_line(p_pgroup varchar2, p_dealermap number, p_loc varchar2, p_comp varchar2, p_ronum varchar2, p_stage varchar2, p_line number) | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | Calculates the working-hours hold time for a specific hold event line (identified by stage and serial number) within a repair order. Accounts for shift schedules, multi-day holds, and holidays by querying VT_VTS_HOLD and WD_BTN. Called in the SEARCH button cursor aggregation to sum total hold time per hold reason across all affected job cards. |

**Total Matched Package Routines (called from form XML):** 2

---

**Function return values:**

| Function | Returns | Values | Description |
| :--- | :--- | :--- | :--- |
| sf_get_panel | Number | 0 or positive integer (sum of windshield panel counts) | Total number of panels processed for the repair order; returns 0 when no VTS records exist |
| sf_get_vts_holdtime_line | Number | 0 or positive decimal (working hours) | Calculated hold duration in working hours for the specified hold event line; returns 0 when the record loop yields no results |

## 15. PLD Procedure Call Sites

*Maps each program-library routine to its call sites within triggers and program units. Behaviour descriptions are derived from the uploaded ``.pld`` sources.*

### DPL.pld (`general`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ASK_CONFIRM | Function | Function(confirm_msg VARCHAR2) RETURN NUMBER | Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_COPY, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_CUT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_DEL, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_EXIT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_INSERT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_LIST, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PASTE, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_PRINT, Trigger: WHEN-BUTTON-PRESSED in PB_BLK.PB_SAVE, Trigger: WHEN-BUTTON-PRESSED in WEBUTIL.DUMMY | Displays a confirmation dialog containing the supplied message and returns a numeric response indicating the user's choice. Called from every toolbar push-button trigger (inherited via OG_GROUP) and from the WEBUTIL.DUMMY item trigger to gate destructive or navigational actions behind explicit user confirmation before proceeding. |
| CHECK_FORM_FAILURE | Procedure | Procedure() | Trigger: KEY-COMMIT in Form | Inspects the current Oracle Forms failure state after a commit operation and raises an application error if the commit did not succeed. Called from the form-level KEY-COMMIT trigger to ensure that any database write failure is surfaced to the user rather than silently ignored. |
| DISP_TEXT | Procedure | Procedure(text_string VARCHAR2, title_string VARCHAR2) | Trigger: ON-MESSAGE in Form | Displays a modal dialog box with the supplied text and title. Called from the form-level ON-MESSAGE trigger to present Oracle Forms informational and status messages to the user in a standardised dialog rather than the default status-bar display. |

### Inactive / commented-only PLD call sites

*The following routines appear only in commented or inactive trigger code in ``vr_veh_wise_delay_fmb.xml``.*

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| RAISE_ERROR | Procedure | Procedure(mesg_code IN VARCHAR2) | Trigger: ON-ERROR in Form | **COMMENTED OUT / INACTIVE** - Looks up a message record by the supplied error code and displays the corresponding message and title using DISP_TEXT. Referenced only in the block-commented ON-ERROR trigger body to handle Oracle constraint violation error E0088; not executed in the current active form code. |

**Total Active Routines:** 3 of 24 in DPL.pld source
**Inactive / commented-only routines:** 1

---

### webutil.pld (`WEBUTIL_CORE`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| CustomEventHandler | Procedure | Procedure(EventName in VARCHAR2, EventParameters in VARCHAR2) | Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_BROWSER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_CLIENTINFO_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_C_API_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILETRANSFER_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_FILE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_HOST_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_OLE_FUNCTIONS, Trigger: WHEN-CUSTOM-ITEM-EVENT in WEBUTIL.WEBUTIL_SESSION_FUNCTIONS | Central WebUtil event dispatcher that receives the name and serialised parameters of a custom item event fired by the WebUtil Java bean and routes it to the appropriate WebUtil function group handler. Each WHEN-CUSTOM-ITEM-EVENT trigger on the respective WEBUTIL block bean items delegates immediately to this procedure, allowing all client-side callback responses - spanning browser, client-info, C-API, file transfer, file, host, OLE, and session function groups - to be processed through a single coordinated entry point. |

**Total Active Routines:** 1 of 39 in webutil.pld source

---

### webutil.pld (`WEBUTIL_C_API`)

| Routine | Type | Signature | Called From | Description |
| :--- | :--- | :--- | :--- | :--- |
| ID_NULL | Function | Function(handle IN Pointer) RETURN BOOLEAN | ProgramUnit: VIEW_EXCEL_REP | Oracle Forms built-in (exposed via webutil) that checks whether a record group handle is NULL. Called in VIEW_EXCEL_REP before attempting to delete an existing record group named 'DataRecordSet'; returns TRUE if the handle is null, FALSE if the group exists. Prevents an error when the group has not yet been created. |

**Total Active Routines:** 1 of 28 in webutil.pld source

## 16. Microservice API Candidates

### 16.1 Microservices with APIs

| ID | Service Name | Database Object | Input Parameters | Output | Business Function | API Endpoint Suggestion |
| -- | ------------ | --------------- | ---------------- | ------ | ----------------- | ----------------------- |
| MS-001 | Vehicle Delay Summary Service | PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE; VH_RO; VT_VTS_HOLD; VM_PROC_HOLD_REASON | Parent group, dealer map code, location code, company code, from bill date, to bill date | List of hold reasons with affected vehicle count and total hold-up time per reason | Queries body-and-paint repair orders billed within a date range and aggregates vehicle hold time by hold reason using the bodyshop hold-time calculation function | `GET /vehicle-delay/summary?dealerMapCd={dealer}&locCd={loc}&fromDate={from}&toDate={to}` |
| MS-002 | Vehicle Delay Detail Export Service | PKG_VTS_BODYSHOP (sf_get_panel, sf_get_productive_time, sf_get_vts_idle_time, sf_get_vts_holdtime); VH_RO; VM_SVAR | Parent group, dealer map code, location code, company code, from bill date, to bill date, principal map code, application identifier | CSV file download containing one row per body-and-paint repair order with job card, vehicle, timing, and performance metrics | Generates a detailed per-vehicle delay export file including productive time, idle time, hold time, and associated dates for each repair order in the date range | `GET /vehicle-delay/export?dealerMapCd={dealer}&locCd={loc}&fromDate={from}&toDate={to}&format=csv` |
| MS-003 | Hold-Time Line Calculator Service | PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE; VT_VTS_HOLD; WD_BTN | Parent group, dealer map code, location code, company code, repair order number, stage ID, hold-line serial number | Numeric hold time in working shift hours for the specified hold line | Calculates adjusted hold time for a single VTS hold-record line, accounting for work-shift schedules and holiday calendar | `GET /vehicle-delay/hold-time-line?roNum={roNum}&stageId={stageId}&lineNo={lineNo}` |
| MS-004 | Session Audit Tagging Service | DBMS_APPLICATION_INFO | Module name, action name, client identifier | Confirmation of session registration | Registers and clears the database session's module, action, and client identifier for operational traceability of report sessions | `POST /session/audit-tag` (internal infrastructure service - no direct user-facing API needed) |

**Total Microservices Identified: 4**

---

## 17. Workflows

| ID | Workflow Name | Trigger Event | Steps | Decision Points | End State |
| -- | ------------- | ------------- | ----- | --------------- | --------- |
| WF-001 | Form Open and Session Initialisation | User launches the vehicle-wise delay report from the menu (PRE-FORM trigger fires) | 1. Session tagged with module name "vr_veh_wise_delay" and action name cleared in the database session registry | None | Session is identified; report screen is presented to the user |
| WF-002 | From Bill Date Entry and Validation | User enters a value in the From Bill Date field and moves off it (WHEN-VALIDATE-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT; KEY-NEXT-ITEM on CB_DOC_QUERY.FROM_JC_BILL_DT) | 1. Previously displayed hold-reason summary results cleared from screen. 2. System checks whether From Bill Date is blank. 3. System checks whether From Bill Date is a future date. 4. Focus moves to To Bill Date field | (a) If From Bill Date is blank -> alert *"From Date can not be null"*, user stays on field; (b) If From Bill Date is future -> alert *"From Date cannot be greater than Current Date"*, user stays on field; (c) Both checks pass -> move to To Bill Date | From Bill Date accepted; cursor on To Bill Date field |
| WF-003 | To Bill Date Entry, Validation, and Default | User enters a value in the To Bill Date field and moves off it (WHEN-VALIDATE-ITEM on CB_DOC_QUERY.TO_BILL_DT) | 1. System checks whether To Bill Date is a future date. 2. System checks whether To Bill Date is earlier than From Bill Date. 3. System checks whether the date range exceeds 31 days. 4. If To Bill Date is blank, system defaults it to today's date | (a) Future date -> alert *"To Date cannot be greater than Current Date"*, user stays on field; (b) Earlier than From Bill Date -> alert *"To Date cannot be less than From Date"*, user stays on field; (c) Range > 31 days -> alert *"Report can be generated for maximum 1 Month"*, cursor returns to To Bill Date; (d) Blank -> auto-set to today; (e) All checks pass -> proceed | To Bill Date accepted or defaulted; ready for search or export |
| WF-004 | Vehicle-Wise Delay Summary Search | User clicks the Search button (WHEN-BUTTON-PRESSED on CB_DOC_QUERY.SEARCH) | 1. Previous results rows cleared from screen. 2. Database queried for body-and-paint repair orders billed within the date range, grouped by hold reason, with hold-time calculated per line via PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE. 3. Results rows (hold reason, vehicle count, total hold time) populated on screen | (a) No matching records -> results area remains empty after clear; (b) Matching records found -> rows populated on screen | Results displayed by hold reason; user can review or export |
| WF-005 | Detailed Vehicle Delay Export to Excel | User clicks the Export to Excel button (WHEN-BUTTON-PRESSED on CB_DOC_QUERY.PB_EXCEL) | 1. Unique export filename generated from user ID and current timestamp. 2. SQL query string built for per-vehicle detail data. 3. Query string stored in internal field. 4. VIEW_EXCEL_REPORT_NEW called to produce the CSV file and present it to the user | (a) No matching repair orders -> export file contains header row only; (b) Matching records found -> CSV file with per-vehicle rows opened in browser for download | CSV file available for user download |
| WF-006 | Form Exit and Session Cleanup | User presses the Exit key (KEY-EXIT trigger fires) | 1. Database session client identifier cleared. 2. Session module and action names cleared. 3. Internal pagination control globals erased. 4. Form closed without checking for unsaved changes | None - the exit path has no conditional branches | Form closed; session metadata removed; user returned to menu |

---

## 18. PLD-Backed Logic

*Maps shared library routines to their business function and suggested API contracts.*

### webutil.pld (`CLIENT_IMAGE`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-001 | ID_NULL | Business Logic | ProgramUnit: VIEW_EXCEL_REP | /api/v1/pld/id_null | When a record group handle is checked, then it returns true if the handle is null so the caller can safely skip deletion |


---

### DPL.pld (`general`)

| ID | PLD Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ----------- | ---- | ---------- | ------------- | --------------------- |
| PLD-002 | DISP_TEXT | Business Logic | ProgramUnit: EXCEL_GENERATION, Trigger: ON-ERROR in Form | /api/v1/pld/disp_text | **COMMENTED OUT / INACTIVE** - When called with a message and title, then a modal error or information dialog is displayed to the user |
| PLD-003 | RAISE_ERROR | Validation | Trigger: ON-ERROR in Form | /api/v1/pld/raise_error | **COMMENTED OUT / INACTIVE** - When a coded error message key is supplied, then the matching error text is retrieved and displayed as a validation error |


---

### D2kwutil.pld (`Win_API`)

*No routines from ``D2kwutil.pld`` are referenced in ``vr_veh_wise_delay_fmb.xml``.*

---

---

## 19. PCK-Backed Logic

*Maps database package routines to their business rules and suggested API contracts.*

| ID | Package.Routine | Role | Call Sites | Suggested API | Business Rule Summary |
| --- | ------------- | ---- | ---------- | ------------- | --------------------- |
| PCK-001 | PKG_VTS_BODYSHOP.sf_get_panel | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL | /api/v1/packages/pkg_vts_bodyshop/sf_get_panel | When an RO identifier is provided, then the total panel count is retrieved from the VTS table and returned for inclusion in the Excel export |
| PCK-002 | PKG_VTS_BODYSHOP.sf_get_vts_holdtime_line | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.SEARCH | /api/v1/packages/pkg_vts_bodyshop/sf_get_vts_holdtime_line | When a hold event stage and serial line are provided, then the working-hours hold duration is calculated using shift schedules and returned for aggregation by hold reason |
| PCK-003 | PKG_VTS_BODYSHOP.sf_get_productive_time | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL | /api/v1/packages/pkg_vts_bodyshop/sf_get_productive_time | When a repair order identifier is provided, then the total productive working time is calculated and returned for inclusion in the detailed Excel export report |
| PCK-004 | PKG_VTS_BODYSHOP.sf_get_vts_idle_time | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL | /api/v1/packages/pkg_vts_bodyshop/sf_get_vts_idle_time | When a repair order identifier is provided, then the total idle (non-working, non-hold) time is calculated and returned for inclusion in the detailed Excel export report |
| PCK-005 | PKG_VTS_BODYSHOP.sf_get_vts_holdtime | Business Logic | Trigger: WHEN-BUTTON-PRESSED in CB_DOC_QUERY.PB_EXCEL | /api/v1/packages/pkg_vts_bodyshop/sf_get_vts_holdtime | When a repair order identifier is provided, then the total hold time across all hold events is calculated and returned for inclusion in the detailed Excel export report |

---

---

## 20. System Interfaces

### 20.1 Database Integrations

| Interface Name | Type | Purpose | Data Flow | Error Handling |
| -------------- | ---- | ------- | --------- | -------------- |
| Repair Order Data Query (VH_RO) | Direct table SELECT | Retrieves body-and-paint repair order headers billed within the user's selected date range, scoped to the dealer's parent group, dealer map code, and location | Form -> Database (read-only): dealer, parent group, location, date range, category filter in; repair order records out | No explicit error handling in the search trigger; if no records match, the cursor loop completes without writing result rows |
| Vehicle Tracking Hold Records Query (VT_VTS_HOLD) | Direct table SELECT (via PKG_VTS_BODYSHOP cursor and function) | Provides the individual hold events recorded against each repair order's VTS stages, used to aggregate hold time by reason | Form -> Database (read-only): repair order key fields in; hold stage, serial number, reason code, start/end timestamps out | No explicit error handling; empty hold records contribute zero to the hold-time total |
| Hold Reason Description Lookup (VM_PROC_HOLD_REASON) | Direct table SELECT (within Search trigger cursor) | Resolves hold reason codes into business-readable descriptions for display in the delay summary results | Form -> Database (read-only): principal map code and reason code in; reason description out | No explicit error handling in the joining query |
| Vehicle Model Description Lookup (VM_SVAR) | Direct table SELECT (within dynamically built export query) | Resolves vehicle model codes to human-readable model descriptions for inclusion in the Excel export | Form -> Database (read-only): principal map code and model code in; model description out | Embedded in the dynamic export query; any lookup failure results in a NULL model description in the export |
| Bodyshop Hold-Time Calculation (PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE) | Database package function call | Calculates the adjusted hold time for each individual VTS hold-record line, querying work-shift schedules and the holiday calendar | Form -> Database (read-only): repair order key fields, stage, and line number in; numeric hold time (working hours) out | Function returns zero if no matching hold records are found; no exception raised for empty input |
| Bodyshop Performance Functions in Export Query (PKG_VTS_BODYSHOP: sf_get_panel, sf_get_productive_time, sf_get_vts_idle_time, sf_get_vts_holdtime) | Database package function calls (embedded in dynamic export SQL) | Calculates per-repair-order panel count, productive time, idle time, and total hold time for inclusion in the detailed Excel export | Form -> Database (read-only): repair order key fields in; numeric metrics per repair order out | Embedded in the dynamic export query string; errors within the query are handled by VIEW_EXCEL_REPORT_NEW (EXTERNAL / NOT IN BUNDLE) |
| Database Session Audit (DBMS_APPLICATION_INFO) | Oracle built-in package procedure call | Tags and clears the database session's module name, action name, and client identifier for operational monitoring | Form -> Database (write session metadata): module name and client identifier set on open; cleared on exit | No error handling in the source code; failure to set session attributes does not prevent the form from opening or closing |
| Holiday Calendar Query (WD_BTN - within PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE) | Direct table SELECT (inside the hold-time function) | Checks whether intermediate dates within a multi-day hold span are working days or public holidays, to exclude non-working days from hold-time totals | Database internal (read-only): parent group, dealer, location, and date in; holiday record count out | No explicit error handler for this inner query; returns 0 (no holiday) if no matching row found |

### 20.2 External System Integrations

| System Name | Integration Type | Purpose | Protocol | Endpoint | Data Exchange | Success / Error Codes |
| ----------- | ---------------- | ------- | -------- | -------- | ------------- | --------------------- |
| DMS Excel Report Service (DMS_EXCEL_REPORT library - VIEW_EXCEL_REPORT_NEW) | Attached PL/SQL library call | Executes the vehicle delay detail export query, generates the CSV output file, and opens it for the user to download via the browser | Oracle Forms attached library call (server-side PL/SQL - EXTERNAL / NOT IN BUNDLE) | Not applicable (internal library call within the Oracle Forms application server) | Input: principal identifier, filename, SQL query string, column name, application identifier; Output: CSV file accessible via browser URL | Not verifiable - library is external to the bundle; error handling within the library is not available for review |

### 20.3 Report Integrations

No Oracle Reports files (`rdf`, `rep`, or similar) are invoked by this form. The form generates its own CSV export directly via the DMS_EXCEL_REPORT attached library rather than through Oracle Reports. The `reference_data.reports` list in the functional slice is empty (reports count: 0).

---

### 20.3.1 Parameters Passed to the Report

This form does not pass parameters to an Oracle Report. No report parameters were identified in the form sources.

## 21. Procedure and Function Business Rule Catalogue

End-to-end business requirement specification for every stored procedure and function referenced by the VR_VEH_WISE_DELAY form.

### 21.1 Catalogue Index

85 procedures/functions - each SP ID links to its detailed specification in Section 21.2.

| SP Index | Routine Name |
| :--- | :--- |
| [SP-001](#SP-001--D2KWUTIL.ATTEMPT_DLL_LOAD) | D2KWUTIL.ATTEMPT_DLL_LOAD |
| [SP-002](#SP-002--D2KWUTIL.CHOOSEFILE) | D2KWUTIL.CHOOSEFILE |
| [SP-003](#SP-003--D2KWUTIL.D2KWUTIL_ACTIVEWIN) | D2KWUTIL.D2KWUTIL_ACTIVEWIN |
| [SP-004](#SP-004--D2KWUTIL.D2KWUTIL_CHOOSEFILE) | D2KWUTIL.D2KWUTIL_CHOOSEFILE |
| [SP-005](#SP-005--D2KWUTIL.D2KWUTIL_DEBUGSTRING) | D2KWUTIL.D2KWUTIL_DEBUGSTRING |
| [SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETDOSENV) | D2KWUTIL.D2KWUTIL_GETDOSENV |
| [SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETREGKEY) | D2KWUTIL.D2KWUTIL_GETREGKEY |
| [SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR) | D2KWUTIL.D2KWUTIL_WINDIR |
| [SP-009](#SP-009--D2KWUTIL.GET_ACTIVE_WINDOW) | D2KWUTIL.GET_ACTIVE_WINDOW |
| [SP-010](#SP-010--D2KWUTIL.SAVE_FILE) | D2KWUTIL.SAVE_FILE |
| [SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE) | D2KWUTIL.TRANSLATETYPE |
| [SP-012](#SP-012--GENERAL.ASK_CONFIRM) | GENERAL.ASK_CONFIRM |
| [SP-013](#SP-013--GENERAL.CHECK_FORM_FAILURE) | GENERAL.CHECK_FORM_FAILURE |
| [SP-014](#SP-014--GENERAL.DISP_TEXT) | GENERAL.DISP_TEXT |
| [SP-015](#SP-015--PKG_VTS_BODYSHOP.SF_GET_DATE_NUM) | PKG_VTS_BODYSHOP.SF_GET_DATE_NUM |
| [SP-016](#SP-016--PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE) | PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE |
| [SP-017](#SP-017--PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR) | PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR |
| [SP-018](#SP-018--PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN) | PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN |
| [SP-019](#SP-019--PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT) | PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT |
| [SP-020](#SP-020--WEBUTIL.BLOCKING) | WEBUTIL.BLOCKING |
| [SP-021](#SP-021--WEBUTIL.CHECKLIBS) | WEBUTIL.CHECKLIBS |
| [SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER) | WEBUTIL.CLEARCALLBACKTRIGGER |
| [SP-023](#SP-023--WEBUTIL.CLOSEBLOB) | WEBUTIL.CLOSEBLOB |
| [SP-024](#SP-024--WEBUTIL.CLOSEFILE) | WEBUTIL.CLOSEFILE |
| [SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURL) | WEBUTIL.DOWNLOADFROMURL |
| [SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT) | WEBUTIL.DOWNLOADFROMURLINT |
| [SP-027](#SP-027--WEBUTIL.ERROR) | WEBUTIL.ERROR |
| [SP-028](#SP-028--WEBUTIL.ERRORALERT) | WEBUTIL.ERRORALERT |
| [SP-029](#SP-029--WEBUTIL.EXECUTE) | WEBUTIL.EXECUTE |
| [SP-030](#SP-030--WEBUTIL.FCLOSE) | WEBUTIL.FCLOSE |
| [SP-031](#SP-031--WEBUTIL.FILE_SAVE_DIALOG) | WEBUTIL.FILE_SAVE_DIALOG |
| [SP-032](#SP-032--WEBUTIL.FILE_SELECTION_DIALOG_INT) | WEBUTIL.FILE_SELECTION_DIALOG_INT |
| [SP-033](#SP-033--WEBUTIL.FOPEN) | WEBUTIL.FOPEN |
| [SP-034](#SP-034--WEBUTIL.GETCALLBACKTRIGGER) | WEBUTIL.GETCALLBACKTRIGGER |
| [SP-035](#SP-035--WEBUTIL.GETCLIENTOSFAMILY) | WEBUTIL.GETCLIENTOSFAMILY |
| [SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING) | WEBUTIL.GETCLIENTSETTING |
| [SP-037](#SP-037--WEBUTIL.GETIMPLCLASS) | WEBUTIL.GETIMPLCLASS |
| [SP-038](#SP-038--WEBUTIL.GETLASTERROR) | WEBUTIL.GETLASTERROR |
| [SP-039](#SP-039--WEBUTIL.GETLASTERRORARGS) | WEBUTIL.GETLASTERRORARGS |
| [SP-040](#SP-040--WEBUTIL.GETNUMBER) | WEBUTIL.GETNUMBER |
| [SP-041](#SP-041--WEBUTIL.GETOSFAMILY) | WEBUTIL.GETOSFAMILY |
| [SP-042](#SP-042--WEBUTIL.GETOUTPUT) | WEBUTIL.GETOUTPUT |
| [SP-043](#SP-043--WEBUTIL.GETPROPERTY) | WEBUTIL.GETPROPERTY |
| [SP-044](#SP-044--WEBUTIL.GETSTRING) | WEBUTIL.GETSTRING |
| [SP-045](#SP-045--WEBUTIL.GETVAR) | WEBUTIL.GETVAR |
| [SP-046](#SP-046--WEBUTIL.GET_LINE) | WEBUTIL.GET_LINE |
| [SP-047](#SP-047--WEBUTIL.GET_RETURN_CODE) | WEBUTIL.GET_RETURN_CODE |
| [SP-048](#SP-048--WEBUTIL.GET_STANDARD_OUTPUT) | WEBUTIL.GET_STANDARD_OUTPUT |
| [SP-049](#SP-049--WEBUTIL.HOST) | WEBUTIL.HOST |
| [SP-050](#SP-050--WEBUTIL.ID_NULL) | WEBUTIL.ID_NULL |
| [SP-051](#SP-051--WEBUTIL.INIT) | WEBUTIL.INIT |
| [SP-052](#SP-052--WEBUTIL.INITWEBUTIL) | WEBUTIL.INITWEBUTIL |
| [SP-053](#SP-053--WEBUTIL.ISERROR) | WEBUTIL.ISERROR |
| [SP-054](#SP-054--WEBUTIL.IS_OPEN) | WEBUTIL.IS_OPEN |
| [SP-055](#SP-055--WEBUTIL.LENGTH) | WEBUTIL.LENGTH |
| [SP-056](#SP-056--WEBUTIL.LOG) | WEBUTIL.LOG |
| [SP-057](#SP-057--WEBUTIL.POPULATEPROPERTYBUNDLE) | WEBUTIL.POPULATEPROPERTYBUNDLE |
| [SP-058](#SP-058--WEBUTIL.PUTF) | WEBUTIL.PUTF |
| [SP-059](#SP-059--WEBUTIL.PUT_LINE) | WEBUTIL.PUT_LINE |
| [SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE) | WEBUTIL.READFROMPROPERTYBUNDLE |
| [SP-061](#SP-061--WEBUTIL.READTRANSFROMMSGBUNDLE) | WEBUTIL.READTRANSFROMMSGBUNDLE |
| [SP-062](#SP-062--WEBUTIL.REGISTERBEAN) | WEBUTIL.REGISTERBEAN |
| [SP-063](#SP-063--WEBUTIL.REGISTER_FUNCTION) | WEBUTIL.REGISTER_FUNCTION |
| [SP-064](#SP-064--WEBUTIL.RELEASE_PROCESS) | WEBUTIL.RELEASE_PROCESS |
| [SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING) | WEBUTIL.SETCLIENTSETTING |
| [SP-066](#SP-066--WEBUTIL.SETDATA) | WEBUTIL.SETDATA |
| [SP-067](#SP-067--WEBUTIL.SETPROPERTY) | WEBUTIL.SETPROPERTY |
| [SP-068](#SP-068--WEBUTIL.SHOWBEANS) | WEBUTIL.SHOWBEANS |
| [SP-069](#SP-069--WEBUTIL.URL_TO_CLIENT) | WEBUTIL.URL_TO_CLIENT |
| [SP-070](#SP-070--WEBUTIL.WRITEDATA) | WEBUTIL.WRITEDATA |
| [SP-071](#SP-071--WEBUTIL_CORE.CUSTOMEVENTHANDLER) | WEBUTIL_CORE.CUSTOMEVENTHANDLER |
| [SP-072](#SP-072--ADD_ERROR) | ADD_ERROR |
| [SP-073](#SP-073--ADD_EXTERNAL_ERRORS) | ADD_EXTERNAL_ERRORS |
| [SP-074](#SP-074--BOOLTOCHAR) | BOOLTOCHAR |
| [SP-075](#SP-075--CLEAN_ERROR_STACK) | CLEAN_ERROR_STACK |
| [SP-076](#SP-076--DEBUGLOG) | DEBUGLOG |
| [SP-077](#SP-077--GET_ENVIRONMENT_STRING) | GET_ENVIRONMENT_STRING |
| [SP-078](#SP-078--GET_TEMP_DIRECTORY) | GET_TEMP_DIRECTORY |
| [SP-079](#SP-079--GET_WINDOWS_DIRECTORY) | GET_WINDOWS_DIRECTORY |
| [SP-080](#SP-080--READ_REGISTRY) | READ_REGISTRY |
| [SP-081](#SP-081--REGISTER_FUNCTION_CALL) | REGISTER_FUNCTION_CALL |
| [SP-082](#SP-082--SETDEBUG) | SETDEBUG |
| [SP-083](#SP-083--STRIPDIRSEP) | STRIPDIRSEP |
| [SP-084](#SP-084--VIEW_EXCEL_REPORT_NEW) | VIEW_EXCEL_REPORT_NEW |
| [SP-085](#SP-085--WINDEBUG) | WINDEBUG |

---

### 21.2 Detailed Specifications

#### SP-001 - D2KWUTIL.ATTEMPT_DLL_LOAD

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Attempts to load a specified DLL into memory via ORA_FFI, optionally verifying that the file exists at the supplied directory path before loading. If a path is provided, the procedure normalises it by stripping any extraneous directory separators and appending a single trailing backslash, then confirms physical file presence before invoking the load. On a successful load the procedure increments the package-level DLL load counter and marks the API as enabled, returning the resulting library handle to the caller (REGISTER_FUNCTION_CALL). On any failure the API is flagged as disabled and a null handle is returned.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |
| TargetDLL | VARCHAR2 | IN |
| LoadCount | BOOLEAN | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| TargetPath | VARCHAR2 | IN OUT |

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- STRIPDIRSEP ([SP-083](#SP-083--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate whether TargetPath has been supplied by the caller.
- Step 2 - If TargetPath is not null, normalise it by calling STRIPDIRSEP to remove any existing trailing directory separator, then append a single backslash ('\'), ensuring a consistent path format regardless of how the caller supplied it.
- Step 3 - Attempt to open the file identified by the concatenation of the normalised TargetPath and TargetDLL using TEXT_IO.FOPEN in read mode to confirm the file physically exists at that location.
- Step 4 - If the file open succeeds, close the file handle immediately via TEXT_IO.FCLOSE; the check is complete and processing continues.
- Step 5 - If the file open raises any exception, invoke DEBUGLOG (severity 99, context 'Attempt_DLL_LOAD') to record that the DLL was not found at the specified location, then raise the BadLocation exception to halt further processing.
- Step 6 - Call ORA_FFI.LOAD_LIBRARY with TargetPath and TargetDLL to load the DLL into memory and capture the returned library handle in hDLL.
- Step 7 - If the LoadCount flag is TRUE, increment the package-level counter DLL_LOAD_COUNT by 1 and set the package-level flag API_ENABLED to TRUE.
- Step 8 - Return the library handle hDLL to the caller.
- Step 9 - If any unhandled exception occurs during the load phase, set API_ENABLED to FALSE and return the null hDLL handle to the caller.

---
**Decision Points**

DP-001

Condition: TargetPath IS NOT NULL

TRUE: Normalise TargetPath via STRIPDIRSEP and append a backslash, then perform the physical file-existence check before attempting the DLL load.

FALSE: Skip path normalisation and file-existence verification; proceed directly to ORA_FFI.LOAD_LIBRARY using the null path.

---

DP-002

Condition: TEXT_IO.FOPEN succeeds for the concatenated file path (TargetPath || TargetDLL)

TRUE: Close the file handle and continue to the ORA_FFI.LOAD_LIBRARY call.

FALSE: Log the missing-file condition via DEBUGLOG and raise BadLocation to abort the load attempt.

---

DP-003

Condition: LoadCount parameter is TRUE

TRUE: Increment DLL_LOAD_COUNT by 1 and set API_ENABLED to TRUE after a successful library load.

FALSE: Skip counter increment and API_ENABLED update; return the library handle without altering package-level state.

---

DP-004

Condition: An unhandled exception is raised during the ORA_FFI.LOAD_LIBRARY call or surrounding logic

TRUE: Set API_ENABLED to FALSE and return the null library handle to the caller.

FALSE: Normal execution path; the valid library handle is returned.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only the first directory path value is honoured; if multiple paths are embedded in TargetPath, STRIPDIRSEP is applied to sanitise the value and a single trailing backslash is enforced, discarding any additional path segments.
- BR-002 - A physical file-existence check must be performed before loading when TargetPath is supplied; a DLL that cannot be opened at the stated location must not be loaded and must trigger a BadLocation exception.
- BR-003 - Any failure to locate the DLL at the specified path must be recorded via DEBUGLOG at severity level 99, capturing the procedure context ('Attempt_DLL_LOAD') and the full qualified path that was attempted.
- BR-004 - The package-level DLL load counter (DLL_LOAD_COUNT) must be incremented and API_ENABLED must be set to TRUE only when the load succeeds and the LoadCount flag is TRUE, ensuring accurate tracking of successfully loaded libraries.
- BR-005 - If the DLL load fails for any reason, API_ENABLED must be set to FALSE and a null library handle must be returned, preventing the calling code from operating against an unavailable API.

---
**Implementation Logic**

```plsql

FUNCTION  Attempt_DLL_Load  (TargetPath in out VARCHAR2, TargetDLL in VARCHAR2, LoadCount in BOOLEAN DEFAULT TRUE) return ORA_FFI.LibHandleType is
  hDLL  ORA_FFI.LibHandleType;
  hFile TEXT_IO.FILE_TYPE;
begin 
    	
  if TargetPath is not null then 
    -- Watch out for folks who put multiple Paths in here 
    -- Oh yes it's happened! Just use the first & throw the rest away
    -- Add trailing Directory Sep if required
    TargetPath := StripDirSep(TargetPath)||'\';
    
    -- Check that there is actually a file there.
    begin 
  	  hFile := TEXT_IO.FOPEN(TargetPath||TargetDLL,'R');
  	  TEXT_IO.FCLOSE(hFile);
    exception
  	  when others then
  	    Win_API_Debug.DebugLog(99,'Attempt_DLL_LOAD',TargetDLL||' not found in the specified location of "'||TargetPath||'"'); 
  		  raise BadLocation;
    end;
  end if;
  
  hDLL := ORA_FFI.LOAD_LIBRARY(TargetPath, TargetDLL);
  if LoadCount then 
    DLL_LOAD_COUNT  := DLL_LOAD_COUNT + 1;
    API_ENABLED  := TRUE;
  end if;
  return hDLL;
exception
  when others then 
    API_ENABLED := FALSE;
    return hDLL; /* Will be null */
end Attempt_DLL_Load;
```

#### SP-002 - D2KWUTIL.CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a Windows file chooser dialog (Open or Save) to the user, allowing them to browse the client file system and select or specify a file path. This is a D2kwutil Windows API integration library function used to invoke the native Windows file-selection dialog from within Oracle Forms.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CalledBy | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| szTitle | VARCHAR2 | IN |
| szInitDir | VARCHAR2 | IN |
| szFileFilter | VARCHAR2 | IN |
| Flags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_CHOOSEFILE ([SP-004](#SP-004--D2KWUTIL.D2KWUTIL_CHOOSEFILE)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- D2KWUTIL.GET_ACTIVE_WINDOW ([SP-009](#SP-009--D2KWUTIL.GET_ACTIVE_WINDOW)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- GET_TEMP_DIRECTORY ([SP-078](#SP-078--GET_TEMP_DIRECTORY)) - matched by member name
- GET_WINDOWS_DIRECTORY ([SP-079](#SP-079--GET_WINDOWS_DIRECTORY)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Log debug information and clear the error stack.
- Step 2 - Determine the owner window handle: if modal, retrieve the active window handle; otherwise use 0 (no owner).
- Step 3 - If the Windows API is enabled, register the native file-chooser function call and resolve the initial directory (substituting the Windows or Temp directory if the caller passed the special tokens `$WINDIR$` or `$TEMP$`).
- Step 4 - Apply a default file filter if none was supplied, then invoke the native Windows file-chooser dialog via the registered function handle.
- Step 5 - Return the selected file path in the szBuffer output parameter and the Windows API return code to the caller; raise a NOT_AVAILABLE error if the Windows API is not accessible.

<!--
Generate one bullet for every logical processing step.
-->

---
**Decision Points**

DP-001

Condition: The Windows API is enabled (WIN_API.API_ENABLED).

TRUE: Register and invoke the native Windows file-chooser dialog.

FALSE: Raise WIN_API.NOT_AVAILABLE.

DP-002

Condition: The szInitDir parameter equals the special token `$WINDIR$` or `$TEMP$`.

TRUE: Substitute the actual Windows or Temp directory path obtained from the environment.

FALSE: Use the supplied szInitDir value directly.

<!--
Repeat the following structure for every decision.
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it delegates file selection to the native Windows operating system dialog.
- BR-002 - If the Windows API is not available (e.g., running on a non-Windows client), the function raises WIN_API.NOT_AVAILABLE and logs an error.

<!--
Generate one bullet for each business rule.
-->

---
**Implementation Logic**

```plsql
    
FUNCTION ChooseFile(  CalledBy      IN      VARCHAR2,
                      Modal         IN      BOOLEAN,
                      szTitle       IN      VARCHAR2,
                      szInitDir     IN      VARCHAR2,
                      szFileFilter  IN      VARCHAR2,
                      Flags         IN      PLS_INTEGER,
                      SepChar       IN      VARCHAR2,
                      szBuffer      IN OUT  VARCHAR2 ) RETURN PLS_INTEGER is
  hwndOwner  PLS_INTEGER;
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iRC        PLS_INTEGER;
  vcBuff1    VARCHAR2(255);
  vcBuff2    VARCHAR2(2000);
  vcBuff3    VARCHAR2(100);
  vcBuff4    VARCHAR2(1);
  vcBuff5    VARCHAR2(4096);
begin 
  Win_API_Debug.DebugLog(99,'ChooseFile','Args: CalledBy="'||CalledBy||', Modal='||win_api_debug.BoolToChar(Modal)||', szTitle="'||szTitle||'", szInitDir="'||szInitDir||'", szFileFilter="'||szFileFilter||'", Flags='||to_char(flags)||', SepChar="'||SepChar||'", szBuffer="'||szBuffer||'"');	
  Win_API.Clean_Error_Stack;
  iRC  := 0;
  if Modal then 
    hwndOwner := win_api_utility.get_active_window;
  else
    hwndOwner := 0;
  end if;

  if Win_API.API_ENABLED then 
      win_api.Register_function_call(iChooseFile,'d2kwutil_ChooseFile','INT','INT,SHORT,*CHAR,*CHAR,*CHAR,LONG,CHAR,*CHAR');

      if CalledBy = 'Open_File' then
        iBuff1     := 1;
      else
        iBuff1    := 2;
      end if;
      iBuff2    := Flags;
      vcBuff1    := szTitle;
      
      if upper(szInitDir) = '$WINDIR$' then 
        vcBuff2 := win_api_environment.get_windows_directory;
      elsif  upper(szInitDir) = '$TEMP$' then 
        vcBuff2 := win_api_environment.get_temp_directory;
      else 
        vcBuff2 := szInitDir;
      end if;
      
      if substr(vcBuff2,length(vcBuff2),1) <> '\' then 
        vcBuff2 := vcBuff2||'\';
      end if;
      
      if szFileFilter = NULL or szFileFilter = '' then 
        vcBuff3 := 'All files(*.*)|*.*|';
      else
        vcBuff3 := szFileFilter;
      end if;
      vcBuff4 := substr(SepChar,1,1);
      vcBuff5 := RPAD(szBuffer,4096,CHR(0)); 
      
      iRC := d2kwutil_choosefile (win_api.FunctionHandle(iChoosefile),iBuff1,hwndOwner,vcBuff1,vcBuff2,vcBuff3,iBuff2,vcBuff4,vcBuff5);
      Win_API_Debug.DebugLog(99,'ChooseFile','Result: RC='||to_char(iRC)||', szBuffer="'||vcBuff5||'"');
      szBuffer := vcBuff5;
      return iRC;
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error(CalledBy,Win_API.NoAPI);
    raise;
  when others then
    Win_API.Add_error(CalledBy, Win_API.UError||WIN_API.Add_External_errors); 
    raise;  
end Choosefile;
```

#### SP-003 - D2KWUTIL.D2KWUTIL_ACTIVEWIN

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Low-level D2kwutil Windows API stub that retrieves the handle of the currently active window on the client machine. This is a native Windows API wrapper function within the D2kwutil integration library; only its specification is available (no PL/SQL body found in the bundle).

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a registered native function handle.
- Step 2 - Invoke the underlying Windows API call to retrieve the active window handle.
- Step 3 - Return the window handle as a PLS_INTEGER to the caller.

<!--
Generate one bullet for every logical processing step.
-->

---
**Decision Points**

No conditional branches exist in this routine - it performs a direct Windows API call with no decision logic.

<!--
Repeat the following structure for every decision.
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; its internal implementation is a native system call (specification only - no body found in bundle).

<!--
Generate one bullet for each business rule.
-->

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
FUNCTION d2kwutil_ActiveWin(  hFunc          IN      ORA_FFI.funcHandleType) return PLS_INTEGER;
```

#### SP-004 - D2KWUTIL.D2KWUTIL_CHOOSEFILE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Low-level D2kwutil Windows API stub that invokes the native Windows common file-chooser dialog. It is the underlying native call delegated to by the higher-level D2KWUTIL.CHOOSEFILE function. Only the specification is available (no PL/SQL body in the bundle); it is a native API wrapper within the D2kwutil integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| dialog_type | PLS_INTEGER | IN |
| hwndOwner | PLS_INTEGER | IN |
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| AdvancedFlags | PLS_INTEGER | IN |
| SepChar | VARCHAR2 | IN |
| szBuffer | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| szTitle | VARCHAR2 | IN OUT |
| szInitDir | VARCHAR2 | IN OUT |
| szFileFilter | VARCHAR2 | IN OUT |
| szBuffer | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the registered function handle, dialog type, owner window, title, directory, file filter, flags, separator, and buffer parameters.
- Step 2 - Invoke the native Windows file-chooser dialog via the registered function handle.
- Step 3 - Return the selected file path in szBuffer and the result code to the caller.

<!--
Generate one bullet for every logical processing step.
-->

---
**Decision Points**

No conditional branches exist in this routine - it is a direct native API call wrapper (specification only - no body found in bundle).

<!--
Repeat the following structure for every decision.
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; its internal implementation is a native system call (specification only - no body found in bundle).

<!--
Generate one bullet for each business rule.
-->

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

 FUNCTION d2kwutil_ChooseFile (   hFunc         IN      ORA_FFI.funcHandleType,
                                  dialog_type   IN      PLS_INTEGER,
                                  hwndOwner     IN      PLS_INTEGER,
                                  szTitle       IN OUT  VARCHAR2,
                                  szInitDir     IN OUT  VARCHAR2,
                                  szFileFilter  IN OUT  VARCHAR2,
                                  AdvancedFlags IN      PLS_INTEGER,
                                  SepChar       IN      VARCHAR2,
                                  szBuffer      IN OUT  VARCHAR2) return PLS_INTEGER;
```

#### SP-005 - D2KWUTIL.D2KWUTIL_DEBUGSTRING

**Invoked From:**

- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level interface to an external C library function that outputs a debug string during Oracle Forms runtime. The procedure passes a function handle and a text message to the underlying C implementation via the ORA_FFI foreign-function interface, enabling diagnostic or trace output from within the D2KWUTIL utility library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the foreign-function handle (hFunc) that identifies the target C routine registered through ORA_FFI, and the debug text string (Text) to be output.
- Step 2 - Delegate execution directly to the external C function bound to the ORA_FFI pragma interface identifier 11265, passing both hFunc and Text as arguments.
- Step 3 - The external C function performs the debug string output operation; no return value or output parameter is produced back to the PL/SQL caller.

---
**Decision Points**

No decision points are present. The procedure contains no conditional logic; it unconditionally forwards its two input parameters to the external C function via the ORA_FFI pragma interface.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The procedure must be invoked with a valid ORA_FFI function handle (hFunc); the handle must correspond to the C function registered under pragma interface identifier 11265 within the D2KWUTIL library.
- BR-002 - The Text parameter carries the debug message to be emitted; no transformation, validation, or truncation of the text is performed before it is passed to the external C function.
- BR-003 - This procedure produces no formal output parameters and performs no database interactions; its sole effect is the side-effect of the external C debug-string call.
- BR-004 - Invocation is restricted to the WINDEBUG stored procedure within D2kwutil.pld; direct calls from other contexts are not supported by the documented invocation chain.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.
   
 PROCEDURE d2kwutil_DebugString (    hFunc       IN      ORA_FFI.funcHandleType,
                                     Text        IN      VARCHAR2);
 -- Pragmas
 PRAGMA INTERFACE(C,d2kwutil_DebugString,      11265);
```

#### SP-006 - D2KWUTIL.D2KWUTIL_GETDOSENV

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that retrieves a DOS/operating-system environment variable value. Given a function handle and a source environment variable name, the routine delegates execution to the underlying OS-level function via ORA_FFI and returns the expanded (resolved) environment variable string through the IN OUT parameters, along with an integer status code indicating the outcome of the call.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SourceStr | VARCHAR2 | IN OUT |
| ExpandStr | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the pre-registered OS-level environment-variable retrieval function.
- Step 2 - Accept the source environment variable name (SourceStr) as an IN OUT parameter to be passed to the foreign function.
- Step 3 - Accept the expansion buffer (ExpandStr) as an IN OUT parameter that will hold the resolved value of the environment variable upon return.
- Step 4 - Accept the input buffer length (InBuffLen) that constrains the maximum size of the data passed to the foreign function.
- Step 5 - Invoke the foreign function identified by hFunc, passing SourceStr, ExpandStr, and InBuffLen as arguments.
- Step 6 - Return a PLS_INTEGER status code to the caller (GET_ENVIRONMENT_STRING in D2kwutil.pld) indicating success or failure of the OS-level call.

---
**Decision Points**

No decision points are determinable from the available source. Only the function specification is present; no conditional logic is visible in the implementation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle must have been registered prior to calling this function, as no handle initialisation is performed within this routine.
- BR-002 - SourceStr and ExpandStr are IN OUT parameters; the caller is responsible for supplying an initialised SourceStr and an adequately sized ExpandStr buffer to receive the expanded environment variable value.
- BR-003 - InBuffLen must accurately reflect the allocated length of the buffer passed to the foreign function; incorrect sizing may result in truncation or an error at the OS level.
- BR-004 - This function is intended to be called exclusively from GET_ENVIRONMENT_STRING in D2kwutil.pld; direct invocation from other contexts is not supported by the documented invocation chain.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetDOSEnv (   hFunc          IN      ORA_FFI.funcHandleType,
                                SourceStr      IN OUT  VARCHAR2,
                                ExpandStr      IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-007 - D2KWUTIL.D2KWUTIL_GETREGKEY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

D2KWUTIL_GETREGKEY is a foreign-function interface (FFI) wrapper that retrieves a Windows registry key value. Given a registry root, path, and entry name, it calls the underlying native library function (referenced via the ORA_FFI function handle) and returns the resolved registry value string along with a PLS_INTEGER return code indicating the outcome of the retrieval.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| RegRoot | PLS_INTEGER | IN |
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |
| RegValueLength | PLS_INTEGER | IN |
| RegDontExpand | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN OUT |
| RegEntry | VARCHAR2 | IN OUT |
| RegValue | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the ORA_FFI function handle (hFunc) that references the pre-registered native library entry point for reading a Windows registry key.
- Step 2 - Accept the registry root identifier (RegRoot), which specifies the top-level hive (e.g., HKEY_LOCAL_MACHINE, HKEY_CURRENT_USER) to be queried.
- Step 3 - Accept the registry path (RegPath) and registry entry name (RegEntry) as IN OUT parameters identifying the specific key and value name to be read.
- Step 4 - Accept RegValueLength, which defines the maximum buffer length for the value to be returned, and RegDontExpand, which controls whether expandable string values (REG_EXPAND_SZ) are expanded before being returned.
- Step 5 - Delegate execution to the native OS registry API via the ORA_FFI mechanism using hFunc, passing all supplied parameters.
- Step 6 - Receive the registry value string back into RegValue (IN OUT) from the native call.
- Step 7 - Return a PLS_INTEGER result code to the caller (READ_REGISTRY in D2kwutil.pld) indicating success or failure of the registry read operation.

---
**Decision Points**

No decision points can be determined from the available source. Only the function specification is present; no PL/SQL body with conditional logic is available for analysis.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); this handle must be initialised by the caller (READ_REGISTRY) before calling this function, as the FFI mechanism depends on it to locate the native library entry point.
- BR-002 - RegPath, RegEntry, and RegValue are declared IN OUT; the caller must supply appropriately sized VARCHAR2 buffers, and the function may modify their contents upon return.
- BR-003 - RegValueLength must accurately reflect the maximum allowable length of the RegValue buffer to prevent truncation of the returned registry value.
- BR-004 - The RegDontExpand flag governs whether environment-variable references within REG_EXPAND_SZ registry values are expanded; the caller must set this flag explicitly to control expansion behaviour.
- BR-005 - The integer return code must be evaluated by the invoking routine (READ_REGISTRY) to determine whether the registry key was successfully retrieved or whether an error condition occurred.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_GetRegKey (    hFunc         IN      ORA_FFI.funcHandleType,
                                RegRoot        IN      PLS_INTEGER,
                                RegPath        IN OUT  VARCHAR2,
                                RegEntry       IN OUT  VARCHAR2,
                                RegValue       IN OUT  VARCHAR2,
                                RegValueLength IN      PLS_INTEGER,
                                RegDontExpand	 IN      PLS_INTEGER
                                ) return PLS_INTEGER;
```

#### SP-008 - D2KWUTIL.D2KWUTIL_WINDIR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Provides a low-level foreign-function interface (FFI) wrapper that calls an external Windows API function to retrieve a Windows directory path (either the Windows system directory or the temporary directory, depending on the function handle supplied by the caller). The function returns a PLS_INTEGER status code and populates the IN OUT buffer with the resolved directory path string.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| hFunc | ORA_FFI.funcHandleType | IN |
| WindowsDir | VARCHAR2 | IN OUT |
| InBuffLen | PLS_INTEGER | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| WindowsDir | VARCHAR2 | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the external function handle (hFunc) that identifies which Windows API entry point to invoke (e.g., GetWindowsDirectory or GetTempPath), the pre-allocated output buffer (WindowsDir), and the buffer length (InBuffLen).
- Step 2 - Delegate execution to the external Windows API function referenced by hFunc via the ORA_FFI foreign-function interface mechanism.
- Step 3 - Allow the external API call to populate the WindowsDir IN OUT parameter with the resolved directory path, up to the character limit specified by InBuffLen.
- Step 4 - Return a PLS_INTEGER result code to the caller (GET_TEMP_DIRECTORY or GET_WINDOWS_DIRECTORY) indicating the outcome of the external API call.

---
**Decision Points**

No conditional decision points are present in the available specification. The function acts as a direct FFI pass-through; branching on the returned status code or the contents of WindowsDir is the responsibility of the invoking procedures (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must be invoked with a valid ORA_FFI function handle (hFunc); the handle determines which Windows directory path is retrieved and must be initialised by the calling procedure before invocation.
- BR-002 - The caller is responsible for allocating the WindowsDir buffer and supplying its length via InBuffLen; the function writes the directory path into that buffer up to InBuffLen characters.
- BR-003 - The function returns a PLS_INTEGER status code; the calling procedures (GET_TEMP_DIRECTORY and GET_WINDOWS_DIRECTORY) are responsible for interpreting this value to determine success or failure of the external API call.
- BR-004 - This function has no direct database interactions; all processing is delegated to the external Windows API via ORA_FFI.

---
**Implementation Logic**

```plsql
-- NOTE: No PL/SQL body (implementation) was found for this routine in the available source - only its specification/declaration is shown below.

FUNCTION d2kwutil_WinDir (      hFunc          IN      ORA_FFI.funcHandleType,
                                WindowsDir     IN OUT  VARCHAR2,
                                InBuffLen      IN      PLS_INTEGER
                                ) RETURN PLS_INTEGER;
```

#### SP-009 - D2KWUTIL.GET_ACTIVE_WINDOW

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows handle of the currently active (foreground) window on the Oracle Forms client. This is a D2kwutil Windows API integration library function used to obtain the active window handle, which is then passed as the owner window when presenting modal file-chooser dialogs.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_ACTIVEWIN ([SP-003](#SP-003--D2KWUTIL.D2KWUTIL_ACTIVEWIN)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Clear the error stack and log debug information.
- Step 2 - If the Windows API is enabled, register the native active-window function call and invoke it to obtain the client's current active window handle.
- Step 3 - If the returned handle is zero (no window found), log an error and raise NO_DATA_FOUND if RaiseExceptions is TRUE.
- Step 4 - Return the active window handle to the caller.

<!--
Generate one bullet for every logical processing step.
-->

---
**Decision Points**

DP-001

Condition: The Windows API is enabled (WIN_API.API_ENABLED).

TRUE: Register and invoke the native active-window function to obtain the handle.

FALSE: Raise WIN_API.NOT_AVAILABLE.

DP-002

Condition: The returned window handle equals zero.

TRUE: Log an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE: Return the valid window handle to the caller.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it returns zero and logs an error if no active window can be obtained, rather than raising an exception by default.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

FUNCTION Get_Active_Window (RaiseExceptions IN  BOOLEAN DEFAULT FALSE) RETURN PLS_INTEGER is
  iRC    PLS_INTEGER := 0;
begin
  Win_API_Debug.DebugLog(99,'Get_Active_Window','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  			
  WIN_API.Clean_Error_Stack;
  if WIN_API.API_ENABLED then 
    win_api.Register_function_call(iActiveWin,'d2kwutil_ActiveWin','INT',NULL);
    iRC   := d2kwutil_ActiveWin(win_api.FunctionHandle(iActiveWin));
    Win_API_Debug.DebugLog(99,'Get_Active_Window','Result: RC='||to_char(iRC));        
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Active_Window','Unable to obtain active window handle');
    if RaiseExceptions then 
      raise NO_DATA_FOUND;
    end if;
  end if;
  return iRC;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Active_Window',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Active_Window',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Active_window;
```

#### SP-010 - D2KWUTIL.SAVE_FILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]
- webutil.pld [StoredProcedure: WEBUTIL.FILE_SELECTION_DIALOG_INT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a Windows Save As file dialog to the user, allowing them to specify a destination filename for the file export. This is a D2kwutil Windows API integration library function that delegates to the native Windows common dialog via CHOOSEFILE.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| SampleName | VARCHAR2 | IN |
| Title | VARCHAR2 | IN |
| StartDirectory | VARCHAR2 | IN |
| FileFilter | VARCHAR2 | IN |
| Modal | BOOLEAN | IN |
| AdvancedFlags | PLS_INTEGER | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- D2KWUTIL.CHOOSEFILE ([SP-002](#SP-002--D2KWUTIL.CHOOSEFILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Initialise the return file buffer with the supplied sample filename.
- Step 2 - Invoke D2KWUTIL.CHOOSEFILE in Save mode with the provided title, start directory, file filter, modal flag, and advanced flags.
- Step 3 - If the Windows API reports that no file was selected (return code = 1), log an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE.
- Step 4 - Return the selected file path to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

DP-001

Condition: The Windows common dialog return code equals 1 (no file selected).

TRUE: Log an error; raise NO_DATA_FOUND if RaiseExceptions is TRUE.

FALSE: Return the selected file path to the caller.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it provides a Save As file dialog to the Forms client.
- BR-002 - If the user cancels the dialog (no file selected), the behaviour depends on the RaiseExceptions parameter: silently return NULL or raise NO_DATA_FOUND.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
                    

FUNCTION Save_File (  SampleName       IN  VARCHAR2,
                      Title            IN  VARCHAR2     DEFAULT 'Save File As',
                      StartDirectory   IN  VARCHAR2     DEFAULT '$WINDIR$',
                      FileFilter       IN  VARCHAR2     DEFAULT 'All files(*.*)|*.*|',
                      Modal            IN  BOOLEAN      DEFAULT TRUE,
                      AdvancedFlags    IN  PLS_INTEGER  DEFAULT WIN_API.OFN_FLAG_DEFAULT,
                      RaiseExceptions  IN  BOOLEAN      DEFAULT FALSE
                    ) RETURN VARCHAR2 is
  vcReturnedFile  varchar2(4096);
  iLRC    pls_integer := 0;
begin 
  vcReturnedFile  := SampleName;
  iLRC := choosefile('Save_File',Modal,Title,StartDirectory,FileFilter,AdvancedFlags,' ',vcReturnedFile);
  
  if iLRC = 1 then 
    Win_API.Add_error('Save_File','No file was selected');
    if RaiseExceptions then 
      Raise NO_DATA_FOUND;
    end if;
  else
    return vcReturnedFile;
  end if;
end Save_File;
```

#### SP-011 - D2KWUTIL.TRANSLATETYPE

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Translates a string-based C data type name into its corresponding ORA_FFI integer constant. This function acts as a lookup utility supporting the registration of external function calls by converting human-readable type tokens (e.g., 'INT', '*CHAR') into the numeric type identifiers required by the ORA_FFI foreign-function interface layer.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DataType | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input DataType string and convert it to uppercase to ensure case-insensitive matching.
- Step 2 - Compare the normalised type string against each supported C data type token in sequence.
- Step 3 - Assign the matching ORA_FFI integer constant to the return variable (iRC) based on the matched token.
- Step 4 - Return the resolved ORA_FFI constant to the caller (REGISTER_FUNCTION_CALL).

---
**Decision Points**

DP-001

Condition: vcType = '*CHAR'

TRUE: iRC is set to ORA_FFI.C_CHAR_PTR (pointer to character type).

FALSE: Evaluation continues to the next condition.

---

DP-002

Condition: vcType = 'CHAR'

TRUE: iRC is set to ORA_FFI.C_CHAR (character type).

FALSE: Evaluation continues to the next condition.

---

DP-003

Condition: vcType = '*INT'

TRUE: iRC is set to ORA_FFI.C_INT_PTR (pointer to integer type).

FALSE: Evaluation continues to the next condition.

---

DP-004

Condition: vcType = 'INT'

TRUE: iRC is set to ORA_FFI.C_INT (integer type).

FALSE: Evaluation continues to the next condition.

---

DP-005

Condition: vcType = '*LONG'

TRUE: iRC is set to ORA_FFI.C_LONG_PTR (pointer to long type).

FALSE: Evaluation continues to the next condition.

---

DP-006

Condition: vcType = 'LONG'

TRUE: iRC is set to ORA_FFI.C_LONG (long type).

FALSE: Evaluation continues to the next condition.

---

DP-007

Condition: vcType = '*SHORT' OR vcType = '*BYTE'

TRUE: iRC is set to ORA_FFI.C_SHORT_PTR (pointer to short/byte type).

FALSE: Evaluation continues to the next condition.

---

DP-008

Condition: vcType = 'SHORT' OR vcType = 'BYTE'

TRUE: iRC is set to ORA_FFI.C_SHORT (short/byte type).

FALSE: Evaluation continues to the next condition.

---

DP-009

Condition: vcType = '*DOUBLE'

TRUE: iRC is set to ORA_FFI.C_DOUBLE_PTR (pointer to double type).

FALSE: Evaluation continues to the next condition.

---

DP-010

Condition: vcType = 'DOUBLE'

TRUE: iRC is set to ORA_FFI.C_DOUBLE (double type).

FALSE: Evaluation continues to the next condition.

---

DP-011

Condition: vcType = '*VOID'

TRUE: iRC is set to ORA_FFI.C_VOID_PTR (pointer to void type).

FALSE: No assignment is made; iRC remains NULL and is returned as-is.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input DataType value is converted to uppercase before matching, making type token resolution case-insensitive.
- BR-002 - Pointer variants of a type are denoted by prefixing the type token with an asterisk (e.g., '*INT' maps to ORA_FFI.C_INT_PTR; 'INT' maps to ORA_FFI.C_INT).
- BR-003 - The tokens 'SHORT' and 'BYTE' are treated as equivalent and both resolve to ORA_FFI.C_SHORT; likewise '*SHORT' and '*BYTE' both resolve to ORA_FFI.C_SHORT_PTR.
- BR-004 - If the supplied DataType token does not match any recognised value, the function returns NULL (no default or exception is raised).
- BR-005 - The function performs no database interactions; resolution is performed entirely through in-memory conditional logic.

---
**Implementation Logic**

```plsql
 
FUNCTION TranslateType(DataType in VARCHAR2) return PLS_INTEGER is
   -- Just a simple lookup of the types.
   vcType VARCHAR2(10) := UPPER(DataType);
   iRC    PLS_INTEGER;
begin 
  if vcType = '*CHAR' then 
    iRC := ORA_FFI.C_CHAR_PTR;
  elsif vcType = 'CHAR' then 
    iRC := ORA_FFI.C_CHAR;
  elsif vcType = '*INT' then 
    iRC := ORA_FFI.C_INT_PTR;
  elsif vcType = 'INT' then 
    iRC := ORA_FFI.C_INT;
  elsif vcType = '*LONG' then 
    iRC := ORA_FFI.C_LONG_PTR;
  elsif vcType = 'LONG' then 
    iRC := ORA_FFI.C_LONG;
  elsif vcType = '*SHORT' or vcType = '*BYTE'  then 
    iRC := ORA_FFI.C_SHORT_PTR;
  elsif vcType = 'SHORT' or vcType = 'BYTE' then 
    iRC := ORA_FFI.C_SHORT;
  elsif vcType = '*DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE_PTR;
  elsif vcType = 'DOUBLE' then 
    iRC := ORA_FFI.C_DOUBLE;  
  elsif vcType = '*VOID' then 
    iRC := ORA_FFI.C_VOID_PTR;      
  end if;
return iRC;
end TranslateType;
```

#### SP-012 - GENERAL.ASK_CONFIRM

**Invoked From:**

- vr_veh_wise_delay_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Displays a configurable confirmation alert (AL_CONFIRM) to the user and returns a numeric indicator reflecting the button pressed. The function allows calling screens to prompt the user for a yes/no confirmation before proceeding with an action, based on a dynamically supplied message.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| confirm_msg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the confirmation message text (confirm_msg) passed by the caller.
- Step 2 - Set the message text of the predefined alert AL_CONFIRM to the supplied confirm_msg value using set_alert_property.
- Step 3 - Display the AL_CONFIRM alert to the user via show_alert and capture the button pressed in p_albtn_pressed.
- Step 4 - Evaluate p_albtn_pressed: if the user pressed ALERT_BUTTON1, return 1 to indicate confirmation; otherwise return 0 to indicate rejection.

---
**Decision Points**

DP-001

Condition:
p_albtn_pressed equals ALERT_BUTTON1 (the first/affirmative button on the AL_CONFIRM alert).

TRUE:
Return 1, signalling to the caller that the user confirmed the action.

FALSE:
Return 0, signalling to the caller that the user did not confirm the action.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The confirmation alert used must be the predefined alert named AL_CONFIRM; no other alert is permitted within this function.
- BR-002 - The confirmation message displayed to the user is fully determined by the confirm_msg input parameter, allowing the caller to contextualise the prompt without altering the alert definition.
- BR-003 - A return value of 1 exclusively represents user confirmation (ALERT_BUTTON1 pressed); any other button response must yield a return value of 0, ensuring a binary confirmed/not-confirmed contract with the caller.

---
**Implementation Logic**

```plsql
FUNCTION ASK_CONFIRM( confirm_msg VARCHAR2)
                                      RETURN  NUMBER IS

    p_alert_name varchar2(10) := 'AL_CONFIRM' ;
    p_albtn_pressed number;
BEGIN
   set_alert_property(p_alert_name,alert_message_text,confirm_msg); 
   p_albtn_pressed := show_alert(p_alert_name);

   IF ( p_albtn_pressed = ALERT_BUTTON1 ) THEN
      return (1);
   ELSE
      return(0);
   END IF;
RETURN NULL; END;
```

#### SP-013 - GENERAL.CHECK_FORM_FAILURE

**Invoked From:**

- vr_veh_wise_delay_fmb.xml [Trigger: KEY-COMMIT]

---

**Screen:**

N/A

---

**Purpose**

Checks whether the most recent Oracle Forms operation completed successfully and, if not, surfaces the appropriate error message to the user before halting further processing. The procedure distinguishes between Oracle database errors (ORA) and Oracle Forms runtime errors (FRM), delegating message display to GENERAL.DISP_TEXT and then raising a form trigger failure to abort the current commit cycle.

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- GENERAL.DISP_TEXT ([SP-014](#SP-014--GENERAL.DISP_TEXT)) - matched by member name (package unresolved)

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the built-in Forms function FORM_SUCCESS to determine whether the preceding Forms operation completed without error.
- Step 2 - If FORM_SUCCESS returns FALSE (i.e., a failure has occurred), inspect the built-in ERROR_TYPE attribute to classify the error.
- Step 3 - If ERROR_TYPE is 'ORA' (an Oracle database-level error), call GENERAL.DISP_TEXT passing SQLERRM as the message text and 'Error' as the severity label to display the database error to the user.
- Step 4 - If ERROR_TYPE is 'FRM' (an Oracle Forms runtime error), call GENERAL.DISP_TEXT passing ERROR_TEXT as the message text and 'Error' as the severity label to display the Forms error to the user.
- Step 5 - After displaying the error message, raise FORM_TRIGGER_FAILURE to halt the KEY-COMMIT trigger and prevent the commit from proceeding.
- Step 6 - If FORM_SUCCESS returns TRUE, no action is taken and control returns normally to the calling trigger.

---
**Decision Points**

DP-001

Condition: FORM_SUCCESS evaluates to FALSE (the preceding Forms operation did not succeed).

TRUE: Proceed to classify the error type and display an error message, then raise FORM_TRIGGER_FAILURE.

FALSE: No error has occurred; the procedure exits without action and the commit cycle continues normally.

DP-002

Condition: ERROR_TYPE = 'ORA' (the failure originated at the Oracle database layer).

TRUE: Call GENERAL.DISP_TEXT with SQLERRM (the Oracle database error message) and severity label 'Error'.

FALSE: Evaluate whether ERROR_TYPE = 'FRM' (see DP-003).

DP-003

Condition: ERROR_TYPE = 'FRM' (the failure originated within the Oracle Forms runtime layer).

TRUE: Call GENERAL.DISP_TEXT with ERROR_TEXT (the Forms runtime error message) and severity label 'Error'.

FALSE: No matching error type is handled; execution proceeds to raise FORM_TRIGGER_FAILURE regardless.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A commit operation initiated via the KEY-COMMIT trigger must not proceed if the preceding Forms operation was unsuccessful; FORM_TRIGGER_FAILURE must be raised to abort the transaction.
- BR-002 - Oracle database errors (ERROR_TYPE = 'ORA') must be reported to the user using the Oracle-supplied SQLERRM message text.
- BR-003 - Oracle Forms runtime errors (ERROR_TYPE = 'FRM') must be reported to the user using the Forms-supplied ERROR_TEXT message text.
- BR-004 - All error notifications must be presented with severity label 'Error' via GENERAL.DISP_TEXT, ensuring consistent error display behaviour across the application.
- BR-005 - If FORM_SUCCESS is TRUE, the procedure must take no action, preserving normal commit processing flow.

---
**Implementation Logic**

```plsql
PROCEDURE CHECK_FORM_FAILURE IS
BEGIN
 IF (NOT form_success) THEN
     IF ERROR_TYPE = 'ORA' THEN
        GENERAL.disp_text(SQLERRM,'Error');
     ELSIF ERROR_TYPE = 'FRM' THEN
        GENERAL.disp_text(ERROR_TEXT,'Error');
     END IF;
     raise form_trigger_failure;
  END IF; 

END;
```

#### SP-014 - GENERAL.DISP_TEXT

**Invoked From:**

- DPL.pld [StoredProcedure: GENERAL.CHECK_FORM_FAILURE]
- vr_veh_wise_delay_fmb.xml [Trigger: ON-MESSAGE]

---

**Screen:**

N/A

---

**Purpose**

Displays a modal alert dialog to the user containing a provided message and title. The procedure selects the appropriate alert template ('AL_ERRINFO' for error-type messages, 'AL_NOTE' for all other message types), sets the alert's title and message text dynamically at runtime, and presents the dialog to the user. It is used as a centralised utility for surfacing informational or error notifications within the application.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| text_string | VARCHAR2 | IN |
| title_string | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message body (text_string) and the dialog title (title_string) as input parameters.
- Step 2 - Evaluate the title_string value (case-insensitive) to determine which alert template to use: if it equals 'ERROR', assign the alert name 'AL_ERRINFO'; otherwise assign 'AL_NOTE'.
- Step 3 - Set the TITLE property of the selected alert to the value of title_string using SET_ALERT_PROPERTY.
- Step 4 - Set the ALERT_MESSAGE_TEXT property of the selected alert to the value of text_string using SET_ALERT_PROPERTY.
- Step 5 - Display the configured alert to the user by calling SHOW_ALERT and capture the user's response in the local variable p_alert_id.

---
**Decision Points**

DP-001

Condition: UPPER(title_string) = 'ERROR'

TRUE: The alert template 'AL_ERRINFO' is selected, indicating an error-severity dialog is to be displayed.

FALSE: The alert template 'AL_NOTE' is selected, indicating a general informational or non-error dialog is to be displayed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The title_string parameter is evaluated case-insensitively; any casing variant of the word 'ERROR' routes to the error alert template 'AL_ERRINFO'.
- BR-002 - All non-error titles (i.e., any title_string value that is not 'ERROR') must use the informational alert template 'AL_NOTE'.
- BR-003 - The alert title and message text must be set dynamically at runtime via SET_ALERT_PROPERTY before the alert is shown, ensuring the displayed content reflects the values passed by the caller rather than any design-time defaults.
- BR-004 - The procedure does not return a value to the caller; the user's alert response (captured in p_alert_id) is not propagated, making this a fire-and-display notification mechanism only.

---
**Implementation Logic**

```plsql
PROCEDURE DISP_TEXT (text_string VARCHAR2,
                     title_string VARCHAR2 ) IS 
   p_alert_name varchar2(10) := 'AL_ERRINFO' ; 
   p_alert_id number;
BEGIN
   if upper(title_string)='ERROR' then
      p_alert_name := 'AL_ERRINFO' ; 
   else
      p_alert_name := 'AL_NOTE' ; 
   end if;
   set_alert_property(p_alert_name,TITLE,title_string);  
   set_alert_property(p_alert_name,alert_message_text,text_string);  
   p_alert_id := show_alert(p_alert_name); 
END;
```

#### SP-015 - PKG_VTS_BODYSHOP.SF_GET_DATE_NUM

**Invoked From:**

- PKG_VTS_BODYSHOP.pck [StoredProcedure: PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a time value expressed as a fractional number of hours (decimal) into a numeric representation used for date arithmetic within the VTS hold-time calculations. This is a utility function used internally by the hold-time calculation routines to standardise time representation across shift-schedule computations.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_time | number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept a numeric time value representing fractional hours.
- Step 2 - Convert the value to a date-arithmetic number suitable for use in Oracle date calculations (dividing by 24 to convert hours to the Oracle date fraction unit).
- Step 3 - Return the converted numeric value to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

No conditional branches exist in this function - it performs a direct arithmetic conversion with no decision logic.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function performs a direct arithmetic transformation; no business validation or constraint checking is performed.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  function sf_get_date_num(p_time number) RETURN NUMBER IS
    p_hr      number;
    p_min     number;
    p_hr_new  number;
    p_min_new number;
    p_hr_min  varchar2(20);
  begin
    p_hr     := p_time;
    p_hr_new := trunc(p_hr);
    if p_hr != p_hr_new then
      p_min    := ((p_hr - p_hr_new) / 60) * 100;
      p_hr_min := p_hr_new || lpad(p_min, 2, 0);
    else
      p_hr_min := p_hr_new;
    end if;
    return to_number(p_hr_min);
  end sf_get_date_num;
```

#### SP-016 - PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE

**Invoked From:**

- vr_veh_wise_delay_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Calculates the adjusted hold time, in working shift hours, for a single vehicle tracking hold-event line on a repair order. It retrieves the hold start and end timestamps, determines whether the hold spans a single day or multiple days, and accumulates the proportion of the applicable shift that falls within the hold period. For multi-day holds, it queries the holiday calendar to exclude non-working days from the total. The result is the net working-hours equivalent of the hold duration for that line.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |
| p_stage | varchar2 | IN |
| p_line | number | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- PKG_VTS_BODYSHOP.SF_GET_DATE_NUM ([SP-015](#SP-015--PKG_VTS_BODYSHOP.SF_GET_DATE_NUM)) - PKG_VTS_BODYSHOP.pck (or .pld)
- PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR ([SP-017](#SP-017--PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR)) - PKG_VTS_BODYSHOP.pck (or .pld)
- PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN ([SP-018](#SP-018--PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN)) - PKG_VTS_BODYSHOP.pck (or .pld)
- PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT ([SP-019](#SP-019--PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT)) - PKG_VTS_BODYSHOP.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - For each hold event record matching the specified repair order, stage, and serial number (retrieved in stage and serial order), initialise the hold time accumulator for the line to zero.
- Step 2 - If the hold start date and hold end date fall on the same calendar day: retrieve the applicable shift length, shift start time, and shift end time for the hold start date; calculate the hold duration as the proportion of the full shift consumed by the elapsed time between hold start and hold end; round to two decimal places.
- Step 3 - If the hold spans multiple calendar days: retrieve the applicable shift details for the end day and the start day separately. Calculate the portion of the start day consumed (from hold start time to shift end), and the portion of the end day consumed (from shift start to hold end time). For each intermediate calendar day between the start and end dates, check the holiday calendar; if a matching holiday record exists for that day, do not count it; if no holiday record exists, count it as one full working shift. Sum the start-day portion, the end-day portion, and the count of non-holiday intermediate days to derive the total hold time for the line.
- Step 4 - Add the line's computed hold time to the running total for the repair order.
- Step 5 - After processing all matching hold records, return the accumulated total hold time in working shift hours.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

DP-001

Condition: The hold event start date falls on the same calendar day as the hold end date.

TRUE: Apply single-day hold time calculation (proportional shift fraction from hold start to hold end).

FALSE: Apply multi-day hold time calculation (start-day remainder + non-holiday intermediate days + end-day elapsed portion).

DP-002

Condition: The number of intermediate calendar days between hold start and hold end exceeds zero.

TRUE: Loop through each intermediate day and check it against the holiday calendar.

FALSE: Skip the intermediate-day loop; no intermediate days to evaluate.

DP-003

Condition: A holiday record exists in the holiday calendar for a given intermediate day.

TRUE: The intermediate day is a non-working day - contribute zero to the hold time total.

FALSE: The intermediate day is a working day - contribute one full shift unit to the hold time total.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

- DB-001 - Read VT_VTS_HOLD - Reads data from VT_VTS_HOLD for lookup or validation.
- DB-002 - Read WD_BTN - Reads data from WD_BTN for lookup or validation.
**Business Rules**

- BR-001 - Single-day holds are calculated as a proportion of the applicable shift length, not as absolute clock hours; this ensures hold time is expressed in working-shift units.
- BR-002 - Multi-day holds are decomposed into the start-day remainder, any non-holiday intermediate working days, and the end-day elapsed portion; holidays recorded in the dealership's working-day calendar are excluded from the count.
- BR-003 - If no matching hold records are found for the specified inputs, the function returns zero; no error is raised.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  function sf_get_vts_holdtime_line(p_pgroup    varchar2,
                                    p_dealermap number,
                                    p_loc       varchar2,
                                    p_comp      varchar2,
                                    p_ronum     varchar2,
                                    p_stage     varchar2,
                                    p_line      number) RETURN NUMBER IS

    LV_STAG_HOLD_TIME NUMBER := 0;
    LV_FINAL_HOLD     NUMBER := 0;
    LV_START_DT       DATE;
    LV_END_DT         DATE;
    LV_START_END_DY   NUMBER := 0;
    LV_SHFT_END       NUMBER := 0;
    LV_SHFT_START     NUMBER := 0;
    LV_SHIFT          VARCHAR2(5);
    LV_SHFT_INT       NUMBER := 0;
    LV_INTER_START_DT DATE;
    LV_SHFT_INT_FINAL NUMBER := 0;
    LV_HOLIDAY_CNT    NUMBER := 0;
    LV_WORK_HR        NUMBER := 0;
    LV_TIME_IN        NUMBER := 0;
    LV_TIME_OUT       NUMBER := 0;

  BEGIN
    FOR REC_HOLD IN (SELECT *
                       FROM VT_VTS_HOLD
                      WHERE parent_group = p_pgroup
                        and dealer_map_cd = p_dealermap
                        and loc_cd = p_loc
                        and comp_fa = p_comp
                        and ro_NUM = p_ronum
                        and stage_id = NVL(p_stage, stage_id)
                        and SRL_NO = p_line
                      ORDER BY STAGE_ID, SRL_NO) LOOP

      LV_STAG_HOLD_TIME := 0;

      IF TRUNC(REC_HOLD.HOLD_START) = TRUNC(REC_HOLD.HOLD_END) THEN

        LV_WORK_HR  := PKG_VTS_BODYSHOP.time_shift_hour(REC_HOLD.PARENT_GROUP,
                                                        REC_HOLD.DEALER_MAP_CD,
                                                        REC_HOLD.LOC_CD,
                                                        REC_HOLD.COMP_FA,
                                                        REC_HOLD.Ro_Num,
                                                        REC_HOLD.HOLD_START);
        LV_TIME_IN  := PKG_VTS_BODYSHOP.time_shift_timein(REC_HOLD.PARENT_GROUP,
                                                          REC_HOLD.DEALER_MAP_CD,
                                                          REC_HOLD.LOC_CD,
                                                          REC_HOLD.COMP_FA,
                                                          REC_HOLD.Ro_Num,
                                                          REC_HOLD.HOLD_START);
        LV_TIME_OUT := PKG_VTS_BODYSHOP.time_shift_timeout(REC_HOLD.PARENT_GROUP,
                                                           REC_HOLD.DEALER_MAP_CD,
                                                           REC_HOLD.LOC_CD,
                                                           REC_HOLD.COMP_FA,
                                                           REC_HOLD.Ro_Num,
                                                           REC_HOLD.HOLD_START);

        LV_STAG_HOLD_TIME := round((((REC_HOLD.HOLD_END -
                                   REC_HOLD.HOLD_START) * 24) / LV_WORK_HR),
                                   2);

      ELSE

        LV_START_DT       := TRUNC(REC_HOLD.HOLD_START);
        LV_END_DT         := TRUNC(REC_HOLD.HOLD_END);
        LV_START_END_DY   := (TRUNC(REC_HOLD.HOLD_END -
                                    TRUNC(REC_HOLD.HOLD_START))) - 1;
        LV_INTER_START_DT := TRUNC(REC_HOLD.HOLD_START) + 1;
        LV_WORK_HR        := PKG_VTS_BODYSHOP.time_shift_hour(REC_HOLD.PARENT_GROUP,
                                                              REC_HOLD.DEALER_MAP_CD,
                                                              REC_HOLD.LOC_CD,
                                                              REC_HOLD.COMP_FA,
                                                              REC_HOLD.Ro_Num,
                                                              LV_END_DT);
        LV_TIME_IN        := PKG_VTS_BODYSHOP.time_shift_timein(REC_HOLD.PARENT_GROUP,
                                                                REC_HOLD.DEALER_MAP_CD,
                                                                REC_HOLD.LOC_CD,
                                                                REC_HOLD.COMP_FA,
                                                                REC_HOLD.Ro_Num,
                                                                LV_END_DT);
        LV_TIME_OUT       := PKG_VTS_BODYSHOP.time_shift_timeout(REC_HOLD.PARENT_GROUP,
                                                                 REC_HOLD.DEALER_MAP_CD,
                                                                 REC_HOLD.LOC_CD,
                                                                 REC_HOLD.COMP_FA,
                                                                 REC_HOLD.Ro_Num,
                                                                 LV_START_DT);

        LV_SHFT_END := round(((nvl(round(((trunc(REC_HOLD.HOLD_START) +
                                         (sf_get_date_num(LV_TIME_OUT) / 24)) -
                                         REC_HOLD.HOLD_START),
                                         2),
                                   0) * 24) / LV_WORK_HR),
                             2);

        IF LV_START_END_DY > 0 THEN
          LOOP
            LV_SHFT_INT       := 0;
            LV_SHFT_INT_FINAL := 0;
            EXIT WHEN LV_INTER_START_DT = TRUNC(REC_HOLD.HOLD_END);

            SELECT COUNT(*)
              INTO LV_HOLIDAY_CNT
              FROM WD_BTN
             where parent_group = REC_HOLD.PARENT_GROUP
               and dealer_map_cd = REC_HOLD.DEALER_MAP_CD
               and loc_cd = REC_HOLD.LOC_CD
               and LEAVE_DATE = LV_INTER_START_DT;

            IF LV_HOLIDAY_CNT > 0 THEN
              LV_SHFT_INT := 0;
            ELSE
              LV_SHFT_INT := 1;
            END IF;
            LV_SHFT_INT_FINAL := LV_SHFT_INT_FINAL + LV_SHFT_INT;
            LV_INTER_START_DT := LV_INTER_START_DT + 1;

          END LOOP;
        END IF;

        LV_SHFT_START := round(((nvl(round((REC_HOLD.HOLD_END -
                                           (trunc(REC_HOLD.HOLD_END) +
                                           (sf_get_date_num(LV_TIME_IN) / 24))),
                                           2),
                                     0) * 24) / LV_WORK_HR),
                               2);

        LV_STAG_HOLD_TIME := LV_SHFT_START + LV_SHFT_END +
                             LV_SHFT_INT_FINAL;

      END IF;

      LV_FINAL_HOLD := LV_FINAL_HOLD + LV_STAG_HOLD_TIME;

    END LOOP;
    RETURN LV_FINAL_HOLD;
  END sf_get_vts_holdtime_line;
```

#### SP-017 - PKG_VTS_BODYSHOP.TIME_SHIFT_HOUR

**Invoked From:**

- PKG_VTS_BODYSHOP.pck [StoredProcedure: PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the working shift duration (in hours) applicable to a given repair order and date. It queries the repair order's shift code from the VTS tracking table and looks up the corresponding shift length from the shift schedule; if no shift is found, it defaults to 12 hours.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |
| p_date | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query VT_VTS to retrieve the shift code assigned to the specified repair order.
- Step 2 - If no shift code is found, set the shift code to NULL.
- Step 3 - Query VM_DAY_SHIFT to retrieve the shift duration (TIME_OUT minus TIME_IN) for the shift code on the specified date.
- Step 4 - If no matching shift schedule record is found, default the shift duration to 12 hours.
- Step 5 - Return the shift duration to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

DP-001

Condition: A shift code is found for the repair order in VT_VTS.

TRUE: Use the retrieved shift code to look up the shift schedule.

FALSE: Set shift code to NULL; the shift schedule lookup will return no data and default to 12 hours.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
- DB-002 - Read VM_DAY_SHIFT - Reads data from VM_DAY_SHIFT for lookup or validation.
**Business Rules**

- BR-001 - If no shift schedule record is found for the repair order's shift code and date, the function defaults to a 12-hour shift duration to ensure hold-time calculations always produce a result.
- BR-002 - The shift duration is returned as the difference between TIME_OUT and TIME_IN from the shift schedule table.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  function time_shift_hour(p_pgroup    varchar2,
                           p_dealermap number,
                           p_loc       varchar2,
                           p_comp      varchar2,
                           p_ronum     varchar2,
                           p_date      date) return number is

    LV_SHIFT   VM_DAY_SHIFT.SHIFT_CD%type;
    LV_WORK_HR NUMBER := 0;

  begin
    begin
      select shift_cd
        INTO LV_SHIFT
        from vt_vts
       WHERE parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and ro_NUM = p_ronum
         and shift_cd is not null;
    EXCEPTION
      when no_data_found then
        LV_SHIFT := NULL;
    end;

    begin
      select TIME_OUT - TIME_IN
        INTO LV_WORK_HR
        from VM_DAY_SHIFT
       where parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and comp_fa = p_comp
         and SHIFT_CD = LV_SHIFT
         and TRUNC(p_date) BETWEEN FROM_DATE AND
             NVL(TO_DATE, TRUNC(SYSDATE));
    exception
      when no_data_found then
        LV_WORK_HR := 12;
    end;
    return LV_WORK_HR;
  end time_shift_hour;
```

#### SP-018 - PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEIN

**Invoked From:**

- PKG_VTS_BODYSHOP.pck [StoredProcedure: PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the shift start time (TIME_IN) for the work shift applicable to a given repair order and date. It queries the repair order's shift code from the VTS tracking table and looks up the shift start time from the shift schedule; if no shift is found, it defaults to 9 (09:00).

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |
| p_date | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query VT_VTS to retrieve the shift code assigned to the specified repair order.
- Step 2 - If no shift code is found, set the shift code to NULL.
- Step 3 - Query VM_DAY_SHIFT to retrieve the shift start time (TIME_IN) for the shift code on the specified date.
- Step 4 - If no matching shift schedule record is found, default the shift start time to 9 (09:00).
- Step 5 - Return the shift start time to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

DP-001

Condition: A shift code is found for the repair order in VT_VTS.

TRUE: Use the retrieved shift code to look up the shift schedule start time.

FALSE: Set shift code to NULL; the shift schedule lookup will return no data and default to 9 (09:00).

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
- DB-002 - Read VM_DAY_SHIFT - Reads data from VM_DAY_SHIFT for lookup or validation.
**Business Rules**

- BR-001 - If no shift schedule record is found for the repair order's shift code and date, the function defaults to a shift start time of 9 (09:00) to ensure hold-time calculations always produce a result.
- BR-002 - The returned value represents the shift start time in hours (numeric), not a full Oracle date value.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  function time_shift_timein(p_pgroup    varchar2,
                             p_dealermap number,
                             p_loc       varchar2,
                             p_comp      varchar2,
                             p_ronum     varchar2,
                             p_date      date) return number is

    LV_SHIFT    VM_DAY_SHIFT.SHIFT_CD%type;
    LV_SHIFT_IN NUMBER := 0;

  begin
    begin
      select shift_cd
        INTO LV_SHIFT
        from vt_vts
       WHERE parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and ro_NUM = p_ronum
         and shift_cd is not null;
    EXCEPTION
      when no_data_found then
        LV_SHIFT := NULL;
    end;

    begin
      select TIME_IN
        INTO LV_SHIFT_IN
        from VM_DAY_SHIFT
       where parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and comp_fa = p_comp
         and SHIFT_CD = LV_SHIFT
         and TRUNC(p_date) BETWEEN FROM_DATE AND
             NVL(TO_DATE, TRUNC(SYSDATE));
    exception
      when no_data_found then
        LV_SHIFT_IN := 9;
    end;
    return LV_SHIFT_IN;
  end time_shift_timein;
```

#### SP-019 - PKG_VTS_BODYSHOP.TIME_SHIFT_TIMEOUT

**Invoked From:**

- PKG_VTS_BODYSHOP.pck [StoredProcedure: PKG_VTS_BODYSHOP.SF_GET_VTS_HOLDTIME_LINE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the shift end time (TIME_OUT) for the work shift applicable to a given repair order and date. It queries the repair order's shift code from the VTS tracking table and looks up the shift end time from the shift schedule; if no shift is found, it defaults to 0.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_pgroup | varchar2 | IN |
| p_dealermap | number | IN |
| p_loc | varchar2 | IN |
| p_comp | varchar2 | IN |
| p_ronum | varchar2 | IN |
| p_date | date | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Query VT_VTS to retrieve the shift code assigned to the specified repair order.
- Step 2 - If no shift code is found, set the shift code to NULL.
- Step 3 - Query VM_DAY_SHIFT to retrieve the shift end time (TIME_OUT) for the shift code on the specified date.
- Step 4 - If no matching shift schedule record is found, default the shift end time to 0.
- Step 5 - Return the shift end time to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

DP-001

Condition: A shift code is found for the repair order in VT_VTS.

TRUE: Use the retrieved shift code to look up the shift schedule end time.

FALSE: Set shift code to NULL; the shift schedule lookup will return no data and default to 0.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

- DB-001 - Read VT_VTS - Reads data from VT_VTS for lookup or validation.
- DB-002 - Read VM_DAY_SHIFT - Reads data from VM_DAY_SHIFT for lookup or validation.
**Business Rules**

- BR-001 - If no shift schedule record is found for the repair order's shift code and date, the function defaults to a shift end time of 0 to ensure hold-time calculations always produce a result.
- BR-002 - The returned value represents the shift end time in hours (numeric), not a full Oracle date value.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  function time_shift_timeout(p_pgroup    varchar2,
                              p_dealermap number,
                              p_loc       varchar2,
                              p_comp      varchar2,
                              p_ronum     varchar2,
                              p_date      date) return number is

    LV_SHIFT     VM_DAY_SHIFT.SHIFT_CD%type;
    LV_SHIFT_OUT NUMBER := 0;

  begin
    begin
      select shift_cd
        INTO LV_SHIFT
        from vt_vts
       WHERE parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and ro_NUM = p_ronum
         and shift_cd is not null;
    EXCEPTION
      when no_data_found then
        LV_SHIFT := NULL;
    end;

    begin
      select TIME_OUT
        INTO LV_SHIFT_OUT
        from VM_DAY_SHIFT
       where parent_group = p_pgroup
         and dealer_map_cd = p_dealermap
         and loc_cd = p_loc
         and comp_fa = p_comp
         and SHIFT_CD = LV_SHIFT
         and TRUNC(p_date) BETWEEN FROM_DATE AND
             NVL(TO_DATE, TRUNC(SYSDATE));
    exception
      when no_data_found then
        LV_SHIFT_OUT := 21;
    end;
    return LV_SHIFT_OUT;
  end time_shift_timeout;
```

#### SP-020 - WEBUTIL.BLOCKING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Controls whether the WebUtil host command execution blocks the Oracle Forms session until the external process completes. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.EXECUTE ([SP-029](#SP-029--WEBUTIL.EXECUTE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  FUNCTION  Blocking(cmd in VARCHAR2) return PROCESS_ID is
  begin
    return Execute(cmd,BLOCKING_MODE);
  end Blocking;
```

#### SP-021 - WEBUTIL.CHECKLIBS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.CHECKLIBS verifies that all system libraries required by a given WebUtil package are present and up to date on the client machine. For each library defined in the property bundle for the package, the procedure compares the installed version against the expected version and, where a mismatch or absence is detected, downloads the library from the configured URL to the client system library location. It is called by WEBUTIL.REGISTERBEAN to satisfy library dependencies before bean registration proceeds.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READTRANSFROMMSGBUNDLE ([SP-061](#SP-061--WEBUTIL.READTRANSFROMMSGBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the package identifier (packageID) that determines which set of system libraries must be checked.
- Step 2 - Enter a loop that iterates over sequentially numbered library entries (starting at index 1) in the property bundle.
- Step 3 - For each iteration, call WEBUTIL.READFROMPROPERTYBUNDLE to retrieve the library specification using an OS-family- and architecture-specific key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>'). If no value is returned, retry with a less specific key that omits the architecture segment ('install.syslib.<OSFamily>.<packageID>.<index>').
- Step 4 - If both lookups return NULL, exit the loop; all library entries for the package have been processed.
- Step 5 - Parse the library specification string using pipe-delimited positions to extract: library file name (position 1), expected file size (position 2), expected version string (position 3), and a progress-display flag (position 4).
- Step 6 - Call WEBUTIL.GETCLIENTSETTING with the key 'syslib.<libName>' to retrieve the version of the library currently recorded as installed on the client.
- Step 7 - Compare the installed version to the expected version. If the installed version is NULL, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is set, proceed to download; otherwise skip to the next iteration.
- Step 8 - Resolve the download base URL by calling WEBUTIL.READFROMPROPERTYBUNDLE in order of decreasing specificity: first with OS-family and architecture ('install.syslib.location.<OSFamily>.<OSArch>'), then with OS-family only ('install.syslib.location.<OSFamily>'), then with the generic key ('install.syslib.location').
- Step 9 - Call WEBUTIL.DOWNLOADFROMURLINT with the resolved URL appended with the library file name, the expected file size, the progress flag, and progress dialog title and subtitle strings retrieved via WEBUTIL.READTRANSFROMMSGBUNDLE ('INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE').
- Step 10 - If the download succeeds, call WEBUTIL.SETCLIENTSETTING to record the newly installed version against the key 'syslib.<libName>' on the client.
- Step 11 - If the download fails, call WEBUTIL.LOG to record a failure message indicating which library could not be downloaded, flagging it as an error.
- Step 12 - Increment the library index counter and return to Step 3 to process the next library entry.

---
**Decision Points**

DP-001

Condition: The OS-family- and architecture-specific property bundle key ('install.syslib.<OSFamily>.<OSArch>.<packageID>.<index>') returns a non-NULL library specification.

TRUE: Use the returned specification for this library entry.

FALSE: Attempt the less specific OS-family-only key ('install.syslib.<OSFamily>.<packageID>.<index>').

---

DP-002

Condition: The OS-family-only property bundle key returns a non-NULL library specification.

TRUE: Use the returned specification for this library entry.

FALSE: Exit the loop; no further library entries exist for this package.

---

DP-003

Condition: The installed version retrieved via WEBUTIL.GETCLIENTSETTING is NULL, differs from the expected version, or the REDOWNLOAD_SYSLIB flag is TRUE.

TRUE: Proceed to resolve the download URL and download the library.

FALSE: Skip the download; the library is already installed at the correct version.

---

DP-004

Condition: The OS-family- and architecture-specific download location key ('install.syslib.location.<OSFamily>.<OSArch>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Attempt the OS-family-only download location key ('install.syslib.location.<OSFamily>').

---

DP-005

Condition: The OS-family-only download location key ('install.syslib.location.<OSFamily>') returns a non-NULL URL.

TRUE: Use this URL as the download base.

FALSE: Use the generic download location key ('install.syslib.location') as the final fallback.

---

DP-006

Condition: WEBUTIL.DOWNLOADFROMURLINT returns TRUE (download completed successfully).

TRUE: Call WEBUTIL.SETCLIENTSETTING to record the installed library version on the client.

FALSE: Call WEBUTIL.LOG to record a download failure error for the library.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Library specifications for a package must be stored in the property bundle under sequentially numbered keys beginning at index 1; the loop terminates as soon as an index returns no entry, so gaps in the sequence are not permitted.
- BR-002 - Library specifications must be pipe-delimited strings containing exactly four positional fields: file name, file size, version, and progress-display flag; any deviation will result in incorrect parsing.
- BR-003 - Version checking is performed by exact string equality; a library is considered outdated if its recorded client version does not exactly match the version defined in the property bundle.
- BR-004 - The REDOWNLOAD_SYSLIB flag, when TRUE, forces re-download of all system libraries regardless of whether the installed version matches the expected version.
- BR-005 - Download URL resolution follows a strict fallback hierarchy from most specific (OS family and architecture) to least specific (generic location); the first non-NULL value found is used.
- BR-006 - Upon successful download, the client setting 'syslib.<libName>' must be updated to the new version string so that subsequent invocations recognise the library as current.
- BR-007 - A failed download must be logged via WEBUTIL.LOG with the error flag set to TRUE; processing continues to the next library rather than aborting the entire check.
- BR-008 - Progress dialog labels displayed during download are sourced exclusively from the message bundle keys 'INST_PGRS_TITLE' and 'INST_PGRS_SUBTITLE', ensuring translatability of user-facing text.

---
**Implementation Logic**

```plsql
  
  PROCEDURE CheckLibs(packageID in VARCHAR2 ) is
    lib          PLS_INTEGER := 1;
    libSpec      VARCHAR2(200 char);
    libName      VARCHAR2(100 char);
    libSize      PLS_INTEGER;
    libVer       VARCHAR2(20 char);
    installedVer VARCHAR2(20 char);
    libProg      BOOLEAN := false;
    downloadURL  VARCHAR2(1000);
  BEGIN
    -- Read through the property bundle for 
    -- any libraries for this package
    LOOP
      libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             to_char(m_clientOSArch)||'.'||packageID||'.'||to_char(lib));
      if libSpec is null then
        libSpec := readFromPropertyBundle('install.syslib.'||to_char(m_clientOSFamily)||'.'||
             packageID||'.'||to_char(lib));
      end if;
      if libSpec is null then 
        exit;
      end if;
      lib := lib + 1;
      libName := Delimstr.getString(libSpec,1,true,'|');
      libSize := Delimstr.getNumber(libSpec,2,true,'|');
      libVer  := Delimstr.getString(libSpec,3,true,'|');
      libProg := (upper(Delimstr.getString(libSpec,4,true,'|'))='TRUE');

      -- OK we now have the library information
      -- let's check if it's installed
      installedVer := GetClientSetting('syslib.'||libname);
      if installedVer is null or installedVer <> libVer or REDOWNLOAD_SYSLIB then 
        -- need to download
        downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily) ||
                             '.' || to_char(m_clientOSArch));
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location' || '.' || to_char(m_clientOSFamily));
        end if;
        if downloadURL is null then
          downloadURL := readFromPropertyBundle('install.syslib.location');
        end if;
        if DownLoadFromURLInt(downloadURL||'/'||libName, 
                              libName,
                              1, -- syslib install download, special location
                              libSize,
                              libProg,
                              ReadTransFromMsgBundle('INST_PGRS_TITLE'),
                              ReadTransFromMsgBundle('INST_PGRS_SUBTITLE'),     
                              libName) then 
          SetClientSetting('syslib.'||libname,libVer);
        else
          log('Download of system library '||libName||' failed',true);
        end if;                          
      end if;
    END LOOP;
  END CheckLibs;
```

#### SP-022 - WEBUTIL.CLEARCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Clears the callback trigger name registered with WebUtil for receiving host command completion notifications. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE ClearCallbackTrigger(callbackKey in PLS_INTEGER) is
  begin
    if m_callbacks.exists(callbackKey) then 
      m_callbacks.delete(callbackKey);  
    end if;
  end ClearCallbackTrigger;
```

#### SP-023 - WEBUTIL.CLOSEBLOB

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open BLOB handle identified by a checksum value. The procedure delegates the close operation to the WebUtil_DB layer, releasing any resources associated with the BLOB session. It is invoked as part of the data-writing workflow managed by WEBUTIL.SETDATA.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| checksum | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the checksum (PLS_INTEGER) that uniquely identifies the open BLOB handle to be closed.
- Step 2 - Delegate the close operation to WebUtil_DB.CloseBlob, passing the checksum as the identifying key.
- Step 3 - Return the BOOLEAN result produced by WebUtil_DB.CloseBlob to the caller, indicating whether the BLOB was successfully closed.

---
**Decision Points**

DP-001

Condition: WebUtil_DB.CloseBlob returns TRUE or FALSE based on the outcome of the close operation for the given checksum.

TRUE: The BLOB handle was successfully located and closed; the function returns TRUE to the caller.

FALSE: The BLOB handle could not be closed (e.g., invalid or already-closed checksum); the function returns FALSE to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The checksum parameter must correspond to a previously opened BLOB handle; the validity and existence of the handle are enforced by WebUtil_DB.CloseBlob.
- BR-002 - The function must return the exact BOOLEAN result received from WebUtil_DB.CloseBlob without modification, ensuring the caller receives an accurate success or failure indicator.
- BR-003 - All resource-release logic is owned by the WebUtil_DB layer; WEBUTIL.CLOSEBLOB performs no independent cleanup beyond the delegation call.

---
**Implementation Logic**

```plsql

  FUNCTION  CloseBlob(checksum in PLS_INTEGER) return BOOLEAN is
  BEGIN
    return WebUtil_DB.CloseBlob(checksum);
  END CloseBlob;
```

#### SP-024 - WEBUTIL.CLOSEFILE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open file handle on the application server by invoking the native Java method closeFile on the AppServerFileReader object. This procedure is called by WEBUTIL.SETDATA to release the server-side file resource once file transfer operations are complete, returning a Boolean indicator of whether the close operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the Java object reference (obj) representing the open AppServerFileReader instance on the application server.
- Step 2 - Clear the argument list by setting args to NULL, ensuring no stale parameters are passed to the Java method.
- Step 3 - Invoke the Java native method closeFile on the AppServerFileReader class via JNI.CALL_BOOLEAN_METHOD, passing the object reference and an empty argument list.
- Step 4 - Return the Boolean result produced by the Java method, indicating whether the file was successfully closed on the application server.

---
**Decision Points**

DP-001

Condition: The JNI call to the AppServerFileReader closeFile Java method returns TRUE or FALSE.

TRUE: The file handle on the application server has been successfully closed; the Boolean value TRUE is returned to the caller (WEBUTIL.SETDATA).

FALSE: The file handle could not be closed by the Java layer; the Boolean value FALSE is returned to the caller, signalling that the close operation did not succeed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be reset to NULL before each invocation of the Java closeFile method to prevent unintended parameter carry-over from prior calls.
- BR-002 - The procedure must operate against the oracle/forms/webutil/fileTransfer/AppServerFileReader Java class exclusively; no alternative class or method may be substituted for closing the file.
- BR-003 - The success or failure of the close operation is determined solely by the Boolean return value of the underlying Java method; no additional server-side validation or retry logic is applied within this procedure.

---
**Implementation Logic**

```plsql
  FUNCTION closeFile(
    obj   ORA_JAVA.JOBJECT) RETURN BOOLEAN IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'closeFile', '()Z', args); 
  END;
```

#### SP-025 - WEBUTIL.DOWNLOADFROMURL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.URL_TO_CLIENT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Downloads a file from a URL to the Oracle Forms client machine. This is part of the WebUtil client-integration library for transferring files from the server to the client.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURLINT ([SP-026](#SP-026--WEBUTIL.DOWNLOADFROMURLINT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURL(sourceURL         in VARCHAR2, 
                           clientDestination in VARCHAR2, 
                           fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
    return DownLoadFromURLInt(sourceURL,
                              ClientDestination,
                              0,
                              fileSize,
                              false,
                              null,
                              null,
                              null);
  END DownLoadFromURL;
```

#### SP-026 - WEBUTIL.DOWNLOADFROMURLINT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.DOWNLOADFROMURL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal function that constructs and dispatches a URL-to-client-file download request to the WebUtil JavaBean via WebUtil_Core, then returns a BOOLEAN indicating whether the download succeeded. It is called exclusively by WEBUTIL.DOWNLOADFROMURL and WEBUTIL.CHECKLIBS and handles all parameter validation, submit-string assembly, and exception reporting before delegating to the client-side bean.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| specialDestination | PLS_INTEGER | IN |
| fileSize | PLS_INTEGER | IN |
| withProgress | BOOLEAN | IN |
| progressTitle | VARCHAR2 | IN |
| progressSubTitle | VARCHAR2 | IN |
| progressMessage | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive all eight input parameters: sourceURL, clientDestination, specialDestination, fileSize, withProgress, progressTitle, progressSubTitle, and progressMessage.
- Step 2 - Validate that sourceURL is not NULL; if it is, raise the URL_NULL user-defined exception.
- Step 3 - Validate that clientDestination is not NULL; if it is, raise the CLIENT_FILE_NULL user-defined exception.
- Step 4 - Evaluate specialDestination: if it is NULL, negative, or greater than 2, write '0' as the first segment of the pipe-delimited submit string; otherwise write its character representation.
- Step 5 - Evaluate fileSize: if it is NULL, append '0' to the submit string; otherwise append its character representation.
- Step 6 - Evaluate withProgress: if it is NULL or FALSE, append 'N' to the submit string; otherwise append 'Y'.
- Step 7 - Append sourceURL, clientDestination, and the three progress label parameters (defaulting each to a single space via NVL when NULL) to complete the pipe-delimited submit string.
- Step 8 - Invoke WebUtil_Core.setProperty with the WUC_PACKAGE constant, the property key 'WUC_URL_DOWNLOAD', the assembled submit string, and TRUE to dispatch the download request to the WebUtil JavaBean.
- Step 9 - Invoke WebUtil_Core.getProperty with the same package constant and property key to retrieve the bean's response into the local result variable.
- Step 10 - Return TRUE if the result equals the literal string 'TRUE'; otherwise return FALSE.

---
**Decision Points**

DP-001

Condition:
sourceURL IS NULL

TRUE:
Raise the URL_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 25 and the context label 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue processing to the next validation.

---

DP-002

Condition:
clientDestination IS NULL

TRUE:
Raise the CLIENT_FILE_NULL exception, which is caught in the EXCEPTION block; WebUtil_Core.Error is called with error code 130 and the context label 'WEBUTIL_CORE.DownloadFromURLInt', and the function returns FALSE.

FALSE:
Continue processing to the next validation.

---

DP-003

Condition:
specialDestination IS NULL OR specialDestination < 0 OR specialDestination > 2

TRUE:
Write the literal '0' as the specialDestination segment of the submit string.

FALSE:
Write the character representation of specialDestination as the first segment of the submit string.

---

DP-004

Condition:
fileSize IS NULL

TRUE:
Append '0' as the fileSize segment of the submit string.

FALSE:
Append the character representation of fileSize to the submit string.

---

DP-005

Condition:
withProgress IS NULL OR withProgress = FALSE

TRUE:
Append 'N' as the progress-indicator segment of the submit string.

FALSE:
Append 'Y' as the progress-indicator segment of the submit string.

---

DP-006

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception raised during setProperty or getProperty

TRUE:
Call WebUtil_Core.ErrorAlert to display a message indicating the implementing bean class was not found, then raise FORM_TRIGGER_FAILURE.

FALSE:
Not applicable; this branch is reached only when the exception fires.

---

DP-007

Condition:
WebUtil_Core.PROPERTY_ERROR exception raised during setProperty or getProperty

TRUE:
Raise FORM_TRIGGER_FAILURE immediately, aborting the calling trigger.

FALSE:
Not applicable; this branch is reached only when the exception fires.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A non-NULL sourceURL is mandatory; omitting it is a hard error that prevents any download attempt and causes the function to return FALSE after logging error code 25 via WebUtil_Core.Error.
- BR-002 - A non-NULL clientDestination is mandatory; omitting it is a hard error that prevents any download attempt and causes the function to return FALSE after logging error code 130 via WebUtil_Core.Error.
- BR-003 - The specialDestination value must be in the range 0-2 inclusive; any NULL, negative, or out-of-range value is silently normalised to 0 before the submit string is built.
- BR-004 - A NULL fileSize is treated as 0, ensuring the submit string always contains a valid numeric file-size token.
- BR-005 - Progress display is opt-in; a NULL or FALSE withProgress flag disables the progress indicator ('N'), while an explicit TRUE enables it ('Y').
- BR-006 - NULL progress label parameters (progressTitle, progressSubTitle, progressMessage) are substituted with a single space character via NVL so that the pipe-delimited submit string always contains the expected number of segments.
- BR-007 - The download request is dispatched to and acknowledged by the WebUtil JavaBean exclusively through WebUtil_Core.setProperty and WebUtil_Core.getProperty; the function's return value is derived solely from whether the bean responds with the string 'TRUE'.
- BR-008 - If the WebUtil JavaBean is not registered at runtime, the function raises FORM_TRIGGER_FAILURE after alerting the user, preventing silent failure of the download operation.
- BR-009 - A PROPERTY_ERROR from the WebUtil_Core layer causes an immediate FORM_TRIGGER_FAILURE, ensuring that bean communication errors are not silently swallowed.

---
**Implementation Logic**

```plsql
  
  FUNCTION DownLoadFromURLInt(sourceURL          in VARCHAR2, 
                              clientDestination  in VARCHAR2, 
                              specialDestination in PLS_INTEGER default 0,                             
                              fileSize           in PLS_INTEGER default 0, 
                              withProgress       in BOOLEAN default false,
                              progressTitle      in VARCHAR2 default null,
                              progressSubTitle   in VARCHAR2 default null,
                              progressMessage    in VARCHAR2 default null) return BOOLEAN is
    result       VARCHAR2(6) := 'FALSE';
    submitString VARCHAR2(4000 char);
    sep          VARCHAR2(1) := '|';
  BEGIN
    if sourceURL is null then
      raise URL_NULL;
    end if;
    if clientDestination is null then
      raise CLIENT_FILE_NULL;
    end if;

    if specialDestination is null or specialDestination < 0 or specialDestination > 2 then 
      submitString := '0'||sep;
    else
      submitString := to_char(specialDestination)||sep;
    end if;
    if fileSize is null then 
      submitString := submitString||'0'||sep;
    else
      submitString := submitString||to_char(fileSize)||sep;
    end if;
    if withProgress is null or not withProgress then 
      submitString := submitString||'N'||sep;
    else
      submitString := submitString||'Y'||sep;
    end if;    

    submitString := submitString||sourceURL
                    ||sep||clientDestination
                    ||sep||nvl(progressTitle,' ')
                    ||sep||nvl(progressSubTitle,' ')
                    ||sep||nvl(progressMessage,' ');                         
  WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD',submitString,true);
  result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_URL_DOWNLOAD');
  return (result='TRUE');
  EXCEPTION  
    when CLIENT_FILE_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE, 130, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;
    when URL_NULL then
      WebUtil_Core.Error(Webutil_Core.WUC_PACKAGE,25, 'WEBUTIL_CORE.DownloadFromURLInt');
      return false;

    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.DownloadFromURLInt will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;
  END DownLoadFromURLInt;
```

#### SP-027 - WEBUTIL.ERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records a WebUtil error condition into the internal error state. This is part of the WebUtil client-integration library error-handling mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |
| code | PLS_INTEGER | IN |
| pu_name | VARCHAR2 | IN |
| arg1 | VARCHAR2 | IN |
| arg2 | VARCHAR2 | IN |
| arg3 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE Error(packageID in PLS_INTEGER,
                  code      in PLS_INTEGER,
                  pu_name   in VARCHAR2,
                  arg1      in VARCHAR2 :=null,
                  arg2      in VARCHAR2 := null,
                  arg3      in VARCHAR2 := null
                 ) is
    errText varchar2(1024);
  begin 
    errText := 'ERROR'||lpad(to_char(code),3,'0') || '|' || pu_name;
    if arg1 is not null then
      errText := errText || '|' || arg1;
    end if;
    if arg2 is not null then
      errText := errText || '|' || arg2;
    end if;
    if arg3 is not null then
      errText := errText || '|' || arg3;
    end if;
    Webutil_Core.setProperty(packageID, 'WUC_ERROR_MSG', errText);
  end Error;
```

#### SP-028 - WEBUTIL.ERRORALERT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.POPULATEPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Displays a WebUtil error alert to the user when an error is detected. This is part of the WebUtil client-integration library error-handling mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| errText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE ErrorAlert(errText in VARCHAR2) is
    -- currently used for throwing a BEAN_NOT_REGISTERED or bean not found error.
    ignore integer;
  begin
    if not ID_NULL(m_errorAlert) then 
      --SET_ALERT_PROPERTY(m_errorAlert,TITLE,'WebUtil Error'); -- title already set in alert property
      SET_ALERT_PROPERTY(m_errorAlert,ALERT_MESSAGE_TEXT,errText);
      ignore := SHOW_ALERT(m_errorAlert);
    else
      message('WebUtil Error'||': '||errText);
    end if;
  end ErrorAlert;
```

#### SP-029 - WEBUTIL.EXECUTE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.BLOCKING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a command or external process on the Oracle Forms application server via WebUtil. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |
| exemode | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION Execute (cmd in VARCHAR2, exemode in PLS_INTEGER) return PROCESS_ID is
    procId PROCESS_ID;
  begin 
    if cmd is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTION_MODE',exemode);            
      WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE',cmd);      
      procId.handle := to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_EXECUTE'));
    end if;
    return procId;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Execute will not work');
  end Execute;
```

#### SP-030 - WEBUTIL.FCLOSE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Closes an open client-side file handle that was previously obtained through WebUtil file I/O operations. The procedure nullifies the file handle after issuing the close command to the WebUtil JavaBean, and raises a fatal tool error if the WebUtil bean is unavailable or if the close operation fails.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN OUT |

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETIMPLCLASS ([SP-037](#SP-037--WEBUTIL.GETIMPLCLASS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the IN OUT file parameter containing the client-side file handle to be closed.
- Step 2 - Check whether the file handle (file.handle) is not NULL; if it is NULL the file is already closed and no action is taken.
- Step 3 - Invoke WebUtil_Core.setProperty with the WUF_PACKAGE constant and the WUF_TEXTIO_CLOSE command, passing the current file handle to instruct the WebUtil JavaBean to close the file on the client.
- Step 4 - Set file.handle to NULL, marking the file object as closed and preventing further I/O operations against it.
- Step 5 - If a BEAN_NOT_REGISTERED exception is raised, call WEBUTIL.ERRORALERT (via WebUtil_Core.ErrorAlert) to display a message that identifies the implementation class retrieved by WEBUTIL.GETIMPLCLASS (via WebUtil_Core.getImplClass) and states that CLIENT_TEXT_IO.fclose will not work; then raise TOOL_ERR.TOOL_ERROR to abort the calling process.
- Step 6 - If a PROPERTY_ERROR exception is raised, raise TOOL_ERR.TOOL_ERROR directly to abort the calling process without displaying an additional alert.

---
**Decision Points**

DP-001

Condition:
file.handle IS NOT NULL

TRUE:
Proceed to close the file by calling WebUtil_Core.setProperty with the WUF_TEXTIO_CLOSE command and then set file.handle to NULL.

FALSE:
Skip all close logic; the procedure exits without performing any operation.

---

DP-002

Condition:
WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the close operation

TRUE:
Call WEBUTIL.ERRORALERT to display an alert message that includes the implementation class name returned by WEBUTIL.GETIMPLCLASS, then raise TOOL_ERR.TOOL_ERROR to terminate processing.

FALSE:
Exception is not raised; normal execution continues.

---

DP-003

Condition:
WebUtil_Core.PROPERTY_ERROR exception is raised during the close operation

TRUE:
Raise TOOL_ERR.TOOL_ERROR immediately to terminate processing; no alert is displayed.

FALSE:
Exception is not raised; normal execution continues.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A file handle that is already NULL must not be submitted to the WebUtil close command; the procedure silently skips the close operation when file.handle is NULL, preventing redundant or erroneous client-side calls.
- BR-002 - After a successful close, the file handle must be set to NULL to ensure the file object cannot be reused for further I/O without being reopened.
- BR-003 - If the WebUtil JavaBean is not registered on the client, WEBUTIL.ERRORALERT must be invoked to surface a descriptive error message that includes the expected implementation class name as returned by WEBUTIL.GETIMPLCLASS, before propagating a fatal TOOL_ERR.TOOL_ERROR.
- BR-004 - Any PROPERTY_ERROR encountered during the close operation must result in an immediate TOOL_ERR.TOOL_ERROR being raised, ensuring that a failed file-close does not allow the calling process to continue in an indeterminate state.
- BR-005 - This procedure operates exclusively on the Oracle Forms client tier through the WebUtil JavaBean; it performs no database interactions.

---
**Implementation Logic**

```plsql
 
  PROCEDURE fclose (file IN OUT file_type) is 
  BEGIN 
    if (file.handle IS NOT NULL) then 
      WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CLOSE',file.handle);        
      file.handle := NULL;
    end if;
 
 EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.fclose will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;
  END fclose;
```

#### SP-031 - WEBUTIL.FILE_SAVE_DIALOG

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Presents a native file Save As dialog on the Oracle Forms client to allow the user to specify a file save destination. This is part of the WebUtil client-integration library, delegating to D2KWUTIL.SAVE_FILE.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-010](#SP-010--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)
- WEBUTIL.FILE_SELECTION_DIALOG_INT ([SP-032](#SP-032--WEBUTIL.FILE_SELECTION_DIALOG_INT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
                                        
  FUNCTION FILE_SAVE_DIALOG(            directory_name Varchar2 := NULL,
                                        file_name      Varchar2 := NULL,
                                        file_filter    Varchar2 := NULL,
                                        title          Varchar2 := NULL) return Varchar2 is
  BEGIN
    RETURN FILE_SELECTION_DIALOG_INT(   directory_name,
                                        file_name,
                                        file_filter,
                                        title,
                                        SAVE_FILE,
                                        TRUE,
                                        FALSE); 
  END FILE_SAVE_DIALOG;
```

#### SP-032 - WEBUTIL.FILE_SELECTION_DIALOG_INT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FILE_SAVE_DIALOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Internal implementation of the WebUtil file-selection dialog, invoked by the higher-level file dialog routines. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| directory_name | Varchar2 | IN |
| file_name | Varchar2 | IN |
| file_filter | Varchar2 | IN |
| title | Varchar2 | IN |
| dialog_type | Number | IN |
| select_file | Boolean | IN |
| multiselect | Boolean | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- D2KWUTIL.SAVE_FILE ([SP-010](#SP-010--D2KWUTIL.SAVE_FILE)) - D2KWUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION FILE_SELECTION_DIALOG_INT(   directory_name Varchar2,
                                        file_name      Varchar2,
                                        file_filter    Varchar2,
                                        title          Varchar2,
                                        dialog_type    Number,
                                        select_file    Boolean,
                                        multiselect    Boolean) return Varchar2 is
    result varchar2(4000);     
    pos Number;
  BEGIN  
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_DIRNAME', directory_name);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',file_name, true);     
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILTER',  file_filter); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MESSAGE', title); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_MULTISELECT', multiselect,true);     
  
    if (dialog_type = SAVE_FILE) then 
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_SAVEFILE');
    elsif (not select_file) then
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENDIR');
    else
        result := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_GFN_OPENFILE');
    end if;
  
    -- handle the situation which we can get with JFileChooser with escaped "\"

    -- if string starts with '\\', replace it with '\\\\', 
    -- before running the original replace statement.
    pos := instr(result, '\\');

    -- concat '\\' in the begining of the string before calling the replace.
    if (pos = 1) then
        result := concat('\\', result);
    end if;

    result := replace(result,'\\','\');
    return result;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. WEBUTIL_FILE.FILE_SELECTION_DIALOG_INT will not work');
      RAISE FORM_TRIGGER_FAILURE;  
   when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
  END FILE_SELECTION_DIALOG_INT;
```

#### SP-033 - WEBUTIL.FOPEN

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Opens a file on the Oracle Forms client for reading or writing. This is part of the WebUtil client-integration library file I/O functions.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| spec | VARCHAR2 | IN |
| filemode | VARCHAR2 | IN |
| charSet | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETPROPERTY ([SP-043](#SP-043--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION fopen(spec VARCHAR2, filemode VARCHAR2, charSet VARCHAR2 := null) RETURN file_type is
    clientFile file_type;
    javaHandle VARCHAR2(6);
  BEGIN
    -- check the mode is valid
    if (lower(filemode) not in ('r','w','a')) then 
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- make sure a file name has been specified      
    if (spec is null) or (spec='') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;
      
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_FILENAME',spec, true);
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_FILEMODE',filemode, true);        
    if (charSet is null) then
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET','(null)', true);
    else
        WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_CHARSET',charSet, true);
    end if;
    javaHandle := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_OPEN');

    -- If the return is null then the file was not opened      
    if (javaHandle is null) or (javaHandle='') or (javaHandle='-1') then
      raise TOOL_ERR.TOOL_ERROR;
    end if;

    -- if we are this far convert the handle to the correct format and return it.      
    clientFile.handle := to_number(javaHandle);
    return clientFile;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.fopen will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                 
      return null;
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE;
    when VALUE_ERROR then
      RAISE TOOL_ERR.TOOL_ERROR; 
    when TOOL_ERR.TOOL_ERROR then 
      RAISE;
  END fopen;
```

#### SP-034 - WEBUTIL.GETCALLBACKTRIGGER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the name of a previously registered callback trigger associated with a given integer key. The function provides a lookup mechanism into the internal callbacks collection, allowing callers such as WEBUTIL.SETDATA to resolve which trigger name corresponds to a specific callback registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| callbackKey | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the integer key (callbackKey) that identifies a specific entry in the internal callbacks collection.
- Step 2 - Look up the entry in the package-level collection m_callbacks using callbackKey as the index.
- Step 3 - Return the VARCHAR2 trigger name stored at that index to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function performs a direct index lookup and returns the result unconditionally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The callbackKey parameter must correspond to a valid, pre-existing index in the m_callbacks collection; no bounds-checking or default handling is performed within this function, so the caller is responsible for supplying a key that was previously registered.
- BR-002 - The return value is the VARCHAR2 trigger name exactly as it was stored in m_callbacks at the specified index; no transformation or formatting is applied.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetCallbackTrigger(callbackKey in PLS_INTEGER) return VARCHAR2 is 
  begin 
    return m_callbacks(callbackKey);
  end GetCallbackTrigger;
```

#### SP-035 - WEBUTIL.GETCLIENTOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the operating system family (e.g., Windows) of the Oracle Forms client machine. This is part of the WebUtil client-integration library for client environment detection.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  FUNCTION GetClientOSFamily return PLS_INTEGER is 
  begin 
    return m_clientOSFamily;
  end GetClientOSFamily;
```

#### SP-036 - WEBUTIL.GETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named client-side configuration property value from the WebUtil Core bean. Given a property name, the function delegates to WebUtil_Core to set and then read back the local property, returning the resolved string value to the caller. It is used by WEBUTIL.CHECKLIBS and WEBUTIL.REGISTERBEAN to interrogate client environment settings at runtime.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input property name (propertyName) as a VARCHAR2 argument.
- Step 2 - Check whether propertyName is not null; if it is null, skip property retrieval and proceed directly to the return step.
- Step 3 - Invoke WebUtil_Core.setProperty, passing the constant WebUtil_Core.WUC_PACKAGE and the key 'WUC_GET_LOCAL_PROPERTY' together with the supplied propertyName, to request the client-side property lookup.
- Step 4 - Invoke WebUtil_Core.getProperty with the same package constant and key to retrieve the value resolved by the WebUtil Core bean, and store it in the local variable result.
- Step 5 - Return the result value (NULL if propertyName was null, otherwise the retrieved property string) to the caller.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Call WebUtil_Core.setProperty and WebUtil_Core.getProperty to retrieve the client-side property value and assign it to result.

FALSE: Skip the property retrieval block entirely; result remains NULL and is returned as-is.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during property access

TRUE: Display an error alert identifying the missing bean class (obtained via WebUtil_Core.getImplClass) and raise FORM_TRIGGER_FAILURE to halt form processing.

FALSE: No bean registration error; continue normal execution.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during property access

TRUE: Raise FORM_TRIGGER_FAILURE immediately to halt form processing without displaying an additional alert.

FALSE: No property error; continue normal execution.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName must not trigger any WebUtil_Core interaction; the function returns NULL silently without attempting a property lookup.
- BR-002 - The client property is retrieved by first writing the requested property name via WebUtil_Core.setProperty and then reading the resolved value via WebUtil_Core.getProperty, both scoped to the WebUtil_Core.WUC_PACKAGE constant with the key 'WUC_GET_LOCAL_PROPERTY'.
- BR-003 - If the WebUtil Core bean is not registered on the client at the time of invocation, the function must display a descriptive error alert (including the bean implementation class name) and terminate form processing by raising FORM_TRIGGER_FAILURE.
- BR-004 - If a property error occurs during retrieval, the function must raise FORM_TRIGGER_FAILURE immediately, preventing the caller from receiving an invalid or partial result.
- BR-005 - The returned property value is limited to 255 characters; any client setting value exceeding this length will be truncated to fit the declared result variable.

---
**Implementation Logic**

```plsql
  
  FUNCTION GetClientSetting(propertyName in VARCHAR2) return VARCHAR2 is 
    result VARCHAR2(255 char);
  BEGIN
    if propertyName is not null then 
    WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY', propertyName);
       result := WebUtil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_GET_LOCAL_PROPERTY');
    end if;
    return result;
  EXCEPTION  
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                            ||' bean not found. WEBUTIL_CORE.GetClientSetting will not work');
    RAISE FORM_TRIGGER_FAILURE;  
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE FORM_TRIGGER_FAILURE;       
  END GetClientSetting;
```

#### SP-037 - WEBUTIL.GETIMPLCLASS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FCLOSE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the WebUtil implementation class name for diagnostic or configuration purposes. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| packageID | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  FUNCTION getImplClass(packageID PLS_INTEGER) return VARCHAR2 is
  BEGIN 
    return WEBUTIL_JAVA_ROOT||m_implClasses(packageID);    
  END;
```

#### SP-038 - WEBUTIL.GETLASTERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the last error code recorded by the AppServerFileReader Java object. After a file-transfer or read operation has been performed, this function interrogates the underlying Java instance to surface any error condition as a numeric code, allowing the calling routine (WEBUTIL.SETDATA) to inspect and act on operation failures.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileReader Java object reference (obj) as the target instance to query.
- Step 2 - Clear the JNI argument list by setting args to NULL, ensuring no stale arguments are passed to the Java method call.
- Step 3 - Invoke the getLastError() method on the AppServerFileReader Java class via JNI.CALL_INT_METHOD, passing FALSE (non-virtual dispatch), the object reference, the fully qualified class name, the method name, and the method signature '()I' (no parameters, returns integer).
- Step 4 - Return the integer error code obtained from the Java method to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function unconditionally clears the argument list and delegates to the Java method, returning whatever numeric code the AppServerFileReader instance reports.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The argument list (args) must be set to NULL before invoking the Java method to prevent unintended parameter passing to the getLastError() call.
- BR-002 - The error code is retrieved exclusively from the AppServerFileReader Java class (oracle/forms/webutil/fileTransfer/AppServerFileReader); no alternative error source is consulted.
- BR-003 - The function returns a NUMBER representing the last error state of the supplied Java object; a return value of zero conventionally indicates no error, while any non-zero value signals a failure condition to the caller.
- BR-004 - The validity and interpretation of the returned error code depend entirely on the state of the AppServerFileReader instance passed in; the function performs no independent validation of the obj reference.

---
**Implementation Logic**

```plsql
  FUNCTION getLastError(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_INT_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastError', '()I', args); 
  END;
```

#### SP-039 - WEBUTIL.GETLASTERRORARGS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the argument string associated with the most recent error raised by the AppServerFileReader Java class. The function delegates to the JNI layer to invoke the native Java method and returns the error argument details as a VARCHAR2 string, enabling the caller (WEBUTIL.SETDATA) to obtain contextual information about the last file-transfer error.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the Java object reference (obj) that represents an instance of the AppServerFileReader class.
- Step 2 - Reset the local args variable to NULL to ensure no residual argument data from a prior call is carried forward.
- Step 3 - Invoke the Java instance method getLastErrorArgs on the supplied object via JNI.CALL_STRING_METHOD, targeting the oracle/forms/webutil/fileTransfer/AppServerFileReader class with the method signature ()Ljava/lang/String;.
- Step 4 - Return the VARCHAR2 string result produced by the JNI call to the caller, representing the error argument details from the last error encountered by AppServerFileReader.

---
**Decision Points**

No conditional decision points exist in this function. Execution follows a single, unconditional path: clear args, call the Java method via JNI, and return the result.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The args variable must be set to NULL before the JNI call to prevent stale argument data from influencing the method invocation.
- BR-002 - The function must target the exact Java class oracle/forms/webutil/fileTransfer/AppServerFileReader and method signature ()Ljava/lang/String; to correctly retrieve the last error argument string.
- BR-003 - The function is invoked as an instance method (FALSE flag on JNI.CALL_STRING_METHOD), meaning the supplied obj parameter must be a valid, non-null reference to an AppServerFileReader instance at the time of the call.
- BR-004 - The return value is a raw VARCHAR2 string sourced directly from the Java layer; no transformation or validation is applied before returning it to the caller.

---
**Implementation Logic**

```plsql
  FUNCTION getLastErrorArgs(
    obj   ORA_JAVA.JOBJECT) RETURN VARCHAR2 IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_STRING_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileReader', 'getLastErrorArgs', '()Ljava/lang/String;', args); 
  END;
```

#### SP-040 - WEBUTIL.GETNUMBER

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a delimited numeric field from a source string at a specified position by delegating string extraction to WEBUTIL.GETSTRING and converting the result to a number. This utility function supports parsing of structured, delimiter-separated string payloads received by the custom event handler.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETSTRING ([SP-044](#SP-044--WEBUTIL.GETSTRING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the target field position, an optional flag indicating whether the final field is unterminated, and an optional delimiter character (defaulting to comma).
- Step 2 - Invoke WEBUTIL.GETSTRING, passing all four parameters, to extract the raw text value located at the specified field position within the delimited source string.
- Step 3 - Apply TO_NUMBER to the string value returned by WEBUTIL.GETSTRING to convert it to a numeric data type.
- Step 4 - Return the resulting number to the caller.

---
**Decision Points**

DP-001

Condition: UnTerminated parameter is TRUE.

TRUE: WEBUTIL.GETSTRING treats the field at Field_position as the final, unterminated field in the source string (no closing delimiter expected); the extracted substring is passed to TO_NUMBER.

FALSE: WEBUTIL.GETSTRING treats the field as a standard delimited field bounded by the specified delimiter on both sides; the extracted substring is passed to TO_NUMBER.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Delimiter parameter defaults to a comma if not supplied; the same delimiter value is forwarded unchanged to WEBUTIL.GETSTRING for consistent tokenisation.
- BR-002 - The UnTerminated parameter defaults to FALSE if not supplied, meaning the source string is expected to be fully delimited; callers must explicitly pass TRUE only when the target field is the last field and has no trailing delimiter.
- BR-003 - The string value extracted by WEBUTIL.GETSTRING must be implicitly convertible to a number via TO_NUMBER; no internal exception handling is defined, so any non-numeric extracted value will propagate a runtime conversion error to the caller.
- BR-004 - Field position and delimiter interpretation are entirely delegated to WEBUTIL.GETSTRING; WEBUTIL.GETNUMBER imposes no independent positional or delimiter validation.

---
**Implementation Logic**

```plsql

    
  function  GetNumber (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return number is
                       iRc              pls_integer;
  begin 
    Return to_number(GetString(Source_string, Field_Position, UnTerminated, Delimiter));
  end GetNumber; /* Number Version */
```

#### SP-041 - WEBUTIL.GETOSFAMILY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Determines and caches the client operating system family by inspecting the supplied OS name string and mapping it to a predefined platform constant (e.g., Windows, Mac, Linux, Solaris, HP-UX, AIX, or Unknown). The resolved platform value is stored in the module-level variable m_clientOSFamily so that subsequent calls return the cached result without re-evaluating the OS name. This function is invoked by WEBUTIL.REGISTERBEAN to establish the client platform context required during WebUtil bean registration.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| osName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the raw OS name string (osName) as input and convert it to lowercase, storing the result in the local variable l_osName to enable case-insensitive matching.
- Step 2 - Initialise the local result variable to CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- Step 3 - Check whether the module-level cache variable m_clientOSFamily is NULL; if it is not NULL, skip all evaluation and proceed directly to Step 10 to return the cached value.
- Step 4 - If m_clientOSFamily IS NULL, evaluate l_osName for the substring 'windows'; if found, set result to CLIENT_PLATFORM_WIN32.
- Step 5 - If 'windows' is not found, evaluate l_osName for the substring 'mac'; if found, set result to CLIENT_PLATFORM_MAC.
- Step 6 - If 'mac' is not found, evaluate l_osName for the substring 'linux'; if found, set result to CLIENT_PLATFORM_LINUX.
- Step 7 - If 'linux' is not found, evaluate l_osName for the substrings 'solaris' or 'sunos'; if either is found, set result to CLIENT_PLATFORM_SOLARIS.
- Step 8 - If neither Solaris indicator is found, evaluate l_osName for the substring 'hp-ux'; if found, set result to CLIENT_PLATFORM_HP.
- Step 9 - If 'hp-ux' is not found, evaluate l_osName for the substring 'aix'; if found, set result to CLIENT_PLATFORM_AIX.
- Step 10 - Assign the resolved result value to m_clientOSFamily, persisting it as the cached platform for the session.
- Step 11 - Return m_clientOSFamily to the caller.

---
**Decision Points**

DP-001

Condition: m_clientOSFamily IS NULL

TRUE: Proceed with OS name evaluation (Steps 4-10) to determine and cache the platform constant.

FALSE: Skip all evaluation and return the already-cached value of m_clientOSFamily immediately.

---

DP-002

Condition: l_osName contains the substring 'windows'

TRUE: Set result to CLIENT_PLATFORM_WIN32.

FALSE: Continue to the next OS family check (DP-003).

---

DP-003

Condition: l_osName contains the substring 'mac'

TRUE: Set result to CLIENT_PLATFORM_MAC.

FALSE: Continue to the next OS family check (DP-004).

---

DP-004

Condition: l_osName contains the substring 'linux'

TRUE: Set result to CLIENT_PLATFORM_LINUX.

FALSE: Continue to the next OS family check (DP-005).

---

DP-005

Condition: l_osName contains the substring 'solaris' OR l_osName contains the substring 'sunos'

TRUE: Set result to CLIENT_PLATFORM_SOLARIS.

FALSE: Continue to the next OS family check (DP-006).

---

DP-006

Condition: l_osName contains the substring 'hp-ux'

TRUE: Set result to CLIENT_PLATFORM_HP.

FALSE: Continue to the next OS family check (DP-007).

---

DP-007

Condition: l_osName contains the substring 'aix'

TRUE: Set result to CLIENT_PLATFORM_AIX.

FALSE: result remains CLIENT_PLATFORM_UNKNOWN; no further OS checks are performed.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The OS name comparison is always performed case-insensitively; the input string is converted to lowercase before any substring matching occurs.
- BR-002 - Platform detection follows a strict precedence order: Windows -> Mac -> Linux -> Solaris/SunOS -> HP-UX -> AIX. The first matching condition wins and no further checks are performed.
- BR-003 - If the supplied OS name does not match any recognised platform substring, the function returns CLIENT_PLATFORM_UNKNOWN as the default platform constant.
- BR-004 - Solaris is identified by either the substring 'solaris' or 'sunos' in the OS name; both aliases must be treated as equivalent.
- BR-005 - The resolved platform constant is cached in the module-level variable m_clientOSFamily after the first successful evaluation; once cached, the function returns the cached value on all subsequent calls without re-evaluating the OS name, ensuring consistent platform identity within the session.

---
**Implementation Logic**

```plsql
 
  FUNCTION getOSFamily(osName in VARCHAR2) return PLS_INTEGER is
    l_osName VARCHAR2(30) := lower(osName);
    result   PLS_INTEGER  := CLIENT_PLATFORM_UNKNOWN;
  BEGIN
    if m_clientOSFamily  is null then 
      if (instr(l_osName,'windows') > 0) then 
           result := CLIENT_PLATFORM_WIN32;
      elsif instr(l_osName,'mac') > 0 then 
          result := CLIENT_PLATFORM_MAC;      
      elsif instr(l_osName,'linux') > 0 then 
          result := CLIENT_PLATFORM_LINUX;      
      elsif instr(l_osName,'solaris') > 0 OR instr(l_osName, 'sunos') > 0 then 
          result := CLIENT_PLATFORM_SOLARIS;       
      elsif instr(l_osName,'hp-ux') > 0 then 
          result := CLIENT_PLATFORM_HP; 
      elsif instr(l_osName,'aix') > 0 then 
          result := CLIENT_PLATFORM_AIX;                                                       
      end if;            
      m_clientOSFamily := result;
    end if;
    return m_clientOSFamily;
  END getOSFamily;
```

#### SP-042 - WEBUTIL.GETOUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GET_STANDARD_OUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output produced by a previously executed host command. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |
| prop | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INIT ([SP-051](#SP-051--WEBUTIL.INIT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  FUNCTION GetOutput(process in PROCESS_ID, prop in VARCHAR2) return OUTPUT_ARRAY is   
    lines  OUTPUT_ARRAY;
    i      PLS_INTEGER := 1;
    buffer VARCHAR2(257 char);
    status VARCHAR2(1) := 'X';
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    LOOP
      buffer := WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,prop);
      status := substr(buffer,1,1);
      -- Status can be Y: indicating more lines to follow,
      --               N: indicating that this is the last line
      --               X: indicating that the buffer was empty
      if status <> 'X' then 
        lines(i) := substr(buffer,2);
        i := i + 1;
      end if;
      exit when status <> 'Y';
    END LOOP;
    return lines;    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.GetOutput will not work');
  END GetOutput;  
  
BEGIN
    -- Ensure that Core is instanciated.
    Webutil_Core.Init;
END;

PACKAGE WEBUTIL_SEPARATEFRAME IS

/*********************************************************************************\
 * WEBUTIL_SEPARATEFRAME
 *   This Package contains routines to interact with the MDI frame when Forms
 *   is running with the parameter separateFrame=true
 *   The functions in this package will work with any client type - not just 
 *   Windows clients.
 *   The oracle.forms.webutil.browser.BrowserFunctions bean is needed in your 
 *   Form to use these functions
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   1.0.0 DRMILLS 25/MAY/2003 - Creation
 *   1.0.1 DRMILLS 27/MAY/2003 - Added call to get frame size 
 *
\*********************************************************************************/

  /**
   *  IsSeparateFrame - Allows you to check if the form 
   *                is running in separateFrame mode or not
   */
```

#### SP-043 - WEBUTIL.GETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.FOPEN]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named property value from the WebUtil property bundle. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION getProperty(
    a0    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'getProperty', '(Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-044 - WEBUTIL.GETSTRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETNUMBER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Extracts a single delimited token from a source string by ordinal position. Given a delimiter-separated string, the function locates the Nth field (identified by Field_position) and returns it as a VARCHAR2 value. It is called by WEBUTIL.GETNUMBER to isolate a positional substring before numeric conversion.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Source_string | varchar2 | IN |
| Field_position | number | IN |
| UnTerminated | Boolean | IN |
| Delimiter | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the source string, the 1-based field position to extract, an optional Boolean flag indicating whether the string lacks a trailing delimiter (UnTerminated), and an optional delimiter character (defaulting to comma).
- Step 2 - Create a working copy of the source string to avoid mutating the input.
- Step 3 - If UnTerminated is TRUE, append the delimiter to the working copy so that the final token is bounded on both sides and can be located consistently by subsequent INSTR calls.
- Step 4 - Determine the start position of the target token: if Field_position is greater than 1, locate the (Field_position - 1)th occurrence of the delimiter using INSTR and advance the pointer past the delimiter by adding the delimiter's length; otherwise, set the start pointer to 1 (beginning of the string).
- Step 5 - Determine the end position of the target token by locating the Field_positionth occurrence of the delimiter using INSTR.
- Step 6 - Extract and return the substring from the start pointer for a length equal to (end pointer - start pointer), isolating the requested token without including the surrounding delimiters.

---
**Decision Points**

DP-001

Condition: UnTerminated is TRUE.

TRUE: The delimiter is appended to the working copy of the source string before any parsing begins, ensuring the last token is bounded and detectable by INSTR.

FALSE: The source string is used as-is; no modification is made to the working copy.

---

DP-002

Condition: Field_position is greater than 1.

TRUE: The start pointer is calculated by finding the (Field_position - 1)th occurrence of the delimiter via INSTR and advancing past it by the length of the delimiter, positioning the pointer at the first character of the target token.

FALSE: The start pointer is set to 1, meaning extraction begins at the very start of the string (i.e., the first token is being requested).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Field_position is 1-based; a value of 1 targets the first token in the string, and the start pointer is unconditionally set to position 1 in that case.
- BR-002 - When the source string does not carry a trailing delimiter after its last token, the caller must pass UnTerminated = TRUE so the function appends the delimiter internally, ensuring the final token is correctly bounded and extractable.
- BR-003 - The delimiter defaults to a comma if not supplied, supporting standard CSV-style strings without requiring explicit parameterisation.
- BR-004 - The function uses the native PL/SQL INSTR and SUBSTR functions for all positional arithmetic; no custom length utility (such as WEBUTIL.LENGTH) is invoked within this function's own logic.
- BR-005 - The function returns only the content between the bounding delimiters; the delimiter characters themselves are never included in the returned value.

---
**Implementation Logic**

```plsql

  function  GetString (Source_string    in varchar2,
                       Field_position   in number,
                       UnTerminated     in Boolean  default FALSE,
                       Delimiter        in varchar2 default ',') return varchar2 is
                       iPtrEnd          pls_integer     := 0;
                       iPtrStart        pls_integer     := 0;
                       vcSourceStrCopy  varchar2(32000)     := Source_string;
  begin
    if UnTerminated then 
      vcSourceStrCopy := vcSourceStrCopy||Delimiter;
    end if;

    if Field_Position > 1 then 
      iPtrStart := instr(vcSourceStrCopy,Delimiter,1,Field_Position-1)+ length(Delimiter);
    else
      iPtrStart := 1;
    end if ; 

    iPtrEnd     := instr(vcSourceStrCopy,Delimiter,1,Field_Position);
    return substr(vcSourceStrCopy,iPtrStart,(iPtrEnd-iPtrStart));
  end GetString; /* String Version */
```

#### SP-045 - WEBUTIL.GETVAR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a named variable value from the WebUtil session context. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARNAME | VARCHAR2 | IN |
| VARVALUE | VARCHAR2 | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VARVALUE | VARCHAR2 | IN OUT |

---

**Dependencies**

- GET_ENVIRONMENT_STRING ([SP-077](#SP-077--GET_ENVIRONMENT_STRING)) - matched by member name
- READ_REGISTRY ([SP-080](#SP-080--READ_REGISTRY)) - matched by member name
- WEBUTIL.GETCLIENTOSFAMILY ([SP-035](#SP-035--WEBUTIL.GETCLIENTOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_STANDARD_OUTPUT ([SP-048](#SP-048--WEBUTIL.GET_STANDARD_OUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  PROCEDURE GETVAR(VARNAME IN VARCHAR2, VARVALUE IN OUT VARCHAR2) is
    unixOutput WebUtil_HOST.OUTPUT_ARRAY;
    hostHandle WebUtil_HOST.PROCESS_ID;
    varKey     VARCHAR2(100);
    iPos       PLS_INTEGER;
  BEGIN
    if WebUtil_Core.GetClientOSFamily = WebUtil_Core.CLIENT_PLATFORM_WIN32 then 
      -- read the client Registry
      VARVALUE := Client_Win_API_Environment.read_registry('HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE',VARNAME,false);
      if VARVALUE is null OR VARVALUE = '' then
        -- Could not get an Oracle variable in registry. Try to get from environment varialble
        -- java desupported System.getenv method until they supported it again in 1.5.
        -- We can still get the environment variables in windows using
        -- CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING
        VARVALUE := CLIENT_WIN_API_ENVIRONMENT.GET_ENVIRONMENT_STRING(VARNAME);
      end if;
    elsif WebUtil_Core.GetClientOSFamily in (WebUtil_Core.CLIENT_PLATFORM_MAC,WebUtil_Core.CLIENT_PLATFORM_UNKNOWN) then 
      -- do nothing 
      null;
    else
      -- Unix Ports - do a env to get the environment and parse that
      hostHandle := WebUtil_HOST.Blocking('env');
      unixOutput := WebUtil_HOST.Get_Standard_Output(hostHandle);
      WebUtil_HOST.Release_Process(hostHandle);
      for i in 1..unixOutput.count LOOP
        iPos := instr(unixOutput(i),'=');
        if iPos > 0 then 
          varKey := substr(unixOutput(i),1,iPos-1);
          if varKey = VARNAME then 
            VARVALUE := substr(unixOutput(i),iPos+1);
            EXIT;
          end if;
        end if;
      end LOOP;
    end if;

  exception
    when NO_DATA_FOUND then
      VARVALUE := null;
  END GETVAR;

END CLIENT_TOOL_ENV;

PACKAGE Client_Win_API IS
/*-------------------------------------------------------------------------------*\
 * WebUtil version of D2KWUTIL package WIN_API                                     
 * Note: Not all D2kWutil Functions are ported
 *********************************************************************************
 * Version 1.0.0
 *********************************************************************************
 * Change History
 *   DRMILLS 21/FEB/2003 - Port Creation
 *
 *********************************************************************************
 * WIN_API ->  This package defines the constants used throughout 
 *      the library as a whole, including versions of those 
 *      constants defined within WINDOWS.H/WINUSER.H that 
 *      we'll be using. Add more constants in here if required
 *      The package also contains Explicit Exception declarations,
 *      various status Flags and functions for Error Handling
 * NOTE:    In order to make this library portable across Forms
 *      and Reports we do not use any application 
 *      specific built-ins such as the Forms MESSAGE() 
 *      Built-in. Instead errors are recorded in a package
 *      variable which the programmer can examine if required
\*-------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------*\
 * Internal Version Number  ** Oracle Developer Release 6.0 Version
\*-------------------------------------------------------------------------------*/
  WIN_API_VERSION  CONSTANT  VARCHAR2(30) := '6.0.6.0 Production';
  DLL_NAME         CONSTANT  VARCHAR2(12) := 'd2kwut60.dll';
  DLL_PATH         VARCHAR2(256)          := NULL;

/*-------------------------------------------------------------------------------*\
 * General Window Classes of Common Applications for use with WIN_API_SESSION
 * ** WARNING ** These Window classes are out of our control and might change 
 *               when you upgrade the software in question,
\*-------------------------------------------------------------------------------*/

  -- Oracle Apps
  WINCLASS_DEVELOPER_2000_V1  CONSTANT  VARCHAR2(15)  := 'ui23MDIroot_W32';             /* Developer/2000 release 1.n / Toolkit 2.3 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V2  CONSTANT  VARCHAR2(15)  := 'ui25MDIroot_W32';             /* Developer/2000 Release 2.0 / Toolkit 2.5 Apps on 32 bit */
  WINCLASS_DEVELOPER_2000_V6  CONSTANT  VARCHAR2(15)  := 'ui60MDIroot_W32';             /* Developer/2000 Release 6.0 / Toolkit 6.0 Apps on 32 bit */  
  D2K_WINDOW_CLASS            CONSTANT  VARCHAR2(15)  := WINCLASS_DEVELOPER_2000_V6;    /* Set to the "current" version */  
  WINCLASS_INTEROFFICE_40     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:10008:6:5023b';/* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_INTEROFFICE_41     CONSTANT  VARCHAR2(28)  := 'Afx:10000000:b:1496:6:3a17';  /* Oracle Interoffice 4.0 Client 32 bit */
  WINCLASS_SQLPLUS            CONSTANT  VARCHAR2(13)  := 'SqlplusWClass';               /* Sql*Plus 32 bit */
  WINCLASS_REPORTSSERVER_V1   CONSTANT  VARCHAR2(15)  := 'R25SRV_WINCLASS';             /* Reports Server Reports 2.5 */
  WINCLASS_REPORTSSERVER_V2   CONSTANT  VARCHAR2(15)  := 'R30SRV_WINCLASS';             /* Reports Server Reports 3.0 */
  WINCLASS_REPORTSSERVER_V6   CONSTANT  VARCHAR2(14)  := 'RWRBE_WINCLASS';              /* Reports Server Reports 6.0 */

  -- Microsoft Office Apps - Office97
  WINCLASS_MSWORD_97         CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 97 */
  WINCLASS_MSEXCEL_97        CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 97 */
  WINCLASS_MSPOWERPOINT_97   CONSTANT  VARCHAR2(14):= 'PP97FrameClass';                 /* Microsoft Power Point 97 */

  -- Microsoft Office Apps - Office95
  WINCLASS_MSWORD_7          CONSTANT  VARCHAR2(7) := 'OpusApp';                        /* Microsoft Word 7 */
  WINCLASS_MSEXCEL_7         CONSTANT  VARCHAR2(6) := 'XLMAIN';                         /* Microsoft Excel 7 */
  WINCLASS_MSPOWERPOINT_7    CONSTANT  VARCHAR2(13):= 'PP7FrameClass';                  /* Microsoft Power Point 7 */
  WINCLASS_MSSCHEDULE_7      CONSTANT  VARCHAR2(23):= 'MS Schedule+ 32 Panesdi';        /* Microsoft Schedule 7 */
  WINCLASS_MSEXCHANGE_4      CONSTANT  VARCHAR2(29):= 'Microsoft Exchange 4.0 Viewer';  /* Microsoft Exchange 4 in-tray */

  -- Microsoft O/S Utilities
  WINCLASS_INETEXPLORER      CONSTANT  VARCHAR2(7):= 'IEFrame';                         /* Internet Explorer */
  WINCLASS_OUTLOOK_EXPRESS   CONSTANT  VARCHAR2(29):= 'Outlook Express Browser Class';  /* Outlook Express */
  WINCLASS_EXPLORER          CONSTANT  VARCHAR2(13):= 'ExploreWClass';                  /* Explorer */
  WINCLASS_MYCOMPUTER        CONSTANT  VARCHAR2(13):= 'CabinetWClass';                  /* My Computer & Network Neighborhood*/
  WINCLASS_CALCULATOR        CONSTANT  VARCHAR2(7) := 'SciCalc';                        /* Windows Calculator */
  WINCLASS_NOTEPAD           CONSTANT  VARCHAR2(7) := 'Notepad';                        /* Windows Notepad */
  WINCLASS_WORDPAD           CONSTANT  VARCHAR2(12):= 'WordPadClass';                   /* Windows Wordpad/Write */
  WINCLASS_DOS               CONSTANT  VARCHAR2(18):= 'ConsoleWindowClass';             /* Dos Window */

  -- Other
  WINCLASS_NETSCAPE_3        CONSTANT  VARCHAR2(27):= 'Afx:40000000:b:150e:6:38cfe';    /* Netscape Navigator 3.0 */
  WINCLASS_NETSCAPE_4        CONSTANT  VARCHAR2(28):= 'Afx:40000000:b:10008:6:6063e';   /* Netscape Communicator 4.0 */
  WINCLASS_PFE_7             CONSTANT  VARCHAR2(11):= 'PFE32_Frame';                    /* Programmers File Editor */
  WINCLASS_REGEDIT           CONSTANT  VARCHAR2(15):= 'RegEdit_RegEdit';                /* Registry Editor */

  -- Window Style Constants (from WINUSER.H)
  --  Any PU's that use these constants will explain 
  --  their use.  For further information consult the
  --  Windows SDK.

  SW_HIDE              CONSTANT  PLS_INTEGER := 0;
  SW_SHOWNORMAL        CONSTANT  PLS_INTEGER := 1;
  SW_SHOWMINIMIZED     CONSTANT  PLS_INTEGER := 2;
  SW_SHOWMAXIMIZED     CONSTANT  PLS_INTEGER := 3;
  SW_SHOWNOACTIVATE    CONSTANT  PLS_INTEGER := 4;
  SW_SHOW              CONSTANT  PLS_INTEGER := 5;
  SW_MINIMIZE          CONSTANT  PLS_INTEGER := 6;
  SW_SHOWMINNOACTIVE   CONSTANT  PLS_INTEGER := 7;
  SW_SHOWNA            CONSTANT  PLS_INTEGER := 8;
  SW_RESTORE           CONSTANT  PLS_INTEGER := 9;
  SW_SHOWDEFAULT       CONSTANT  PLS_INTEGER := 10;

  -- Help Access Constants (From WINUSER.H)
  --  See WIN_API_SHELL.WinHelp

  HELP_CONTEXT         CONSTANT  PLS_INTEGER := 1;   /* 0x0001L */
  HELP_QUIT            CONSTANT  PLS_INTEGER := 2;   /* 0x0002L */
  HELP_INDEX           CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_CONTENTS        CONSTANT  PLS_INTEGER := 3;   /* 0x0003L */
  HELP_HELPONHELP      CONSTANT  PLS_INTEGER := 4;   /* 0x0004L */
  HELP_SETINDEX        CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_SETCONTENTS     CONSTANT  PLS_INTEGER := 5;   /* 0x0005L */
  HELP_CONTEXTPOPUP    CONSTANT  PLS_INTEGER := 8;   /* 0x0008L */
  HELP_FORCEFILE       CONSTANT  PLS_INTEGER := 9;   /* 0x0009L */
  HELP_KEY             CONSTANT  PLS_INTEGER := 257; /* 0x0101L */
  HELP_COMMAND         CONSTANT  PLS_INTEGER := 258; /* 0x0102L */
  HELP_PARTIALKEY      CONSTANT  PLS_INTEGER := 261; /* 0x0105L */
  HELP_MULTIKEY        CONSTANT  PLS_INTEGER := 513; /* 0x0201L */
  HELP_SETWINPOS       CONSTANT  PLS_INTEGER := 515; /* 0x0203L */
  -- Windows 4+
  HELP_CONTEXTMENU     CONSTANT  PLS_INTEGER := 10;  /* 0x000a  */
  HELP_FINDER          CONSTANT  PLS_INTEGER := 11;  /* 0x000b  */
  HELP_WM_HELP         CONSTANT  PLS_INTEGER := 12;  /* 0x000c  */
  HELP_SETPOPUP_POS    CONSTANT  PLS_INTEGER := 13;  /* 0x000d  */

  -- Windows Messages for use with SendMessage
  -- DO NOT utilise the Windows Sendmessage interface without being conversant
  -- with the Windows message handling mechanism
  -- Refer to the Microsoft Windows SDK for Messages and Parameter values
  WM_SYSCOMMAND        CONSTANT  PLS_INTEGER := 274;   /* 0x0112 */
  WM_MDITILE           CONSTANT  PLS_INTEGER := 550;   /* 0x0226 */
  WM_MDICASCADE        CONSTANT  PLS_INTEGER := 551;   /* 0x0227 */
  WM_MDIICONARRANGE    CONSTANT  PLS_INTEGER := 552;   /* 0x0228 */      
  SC_RESTORE           CONSTANT  PLS_INTEGER := 61728; /* 0xF120 */
  SC_MINIMIZE          CONSTANT  PLS_INTEGER := 61472; /* 0xF020 */
  SC_MAXIMIZE          CONSTANT  PLS_INTEGER := 61488; /* 0xF030 */
  

  -- Flags for use with File Dialog boxes ("Save As" or "Open")
  -- Refer to your Microsoft documentation for details on the 
  -- Exact usage and dependancies of each option
  OFN_READONLY           CONSTANT  PLS_INTEGER := 1;        /* 0x00000001 */
  OFN_OVERWRITEPROMPT    CONSTANT  PLS_INTEGER := 2;        /* 0x00000002 */
  OFN_HIDEREADONLY       CONSTANT  PLS_INTEGER := 4;        /* 0x00000004 */
  OFN_NOCHANGEDIR        CONSTANT  PLS_INTEGER := 8;        /* 0x00000008 */
  OFN_SHOWHELP           CONSTANT  PLS_INTEGER := 16;       /* 0x00000010 */
  OFN_NOVALIDATE         CONSTANT  PLS_INTEGER := 256;      /* 0x00000100 */
  OFN_ALLOWMULTISELECT   CONSTANT  PLS_INTEGER := 512;      /* 0x00000200 */
  OFN_EXTENSIONDIFFERENT CONSTANT  PLS_INTEGER := 1024;     /* 0x00000400 */
  OFN_PATHMUSTEXIST      CONSTANT  PLS_INTEGER := 2048;     /* 0x00000800 */
  OFN_FILEMUSTEXIST      CONSTANT  PLS_INTEGER := 4096;     /* 0x00001000 */
  OFN_CREATEPROMPT       CONSTANT  PLS_INTEGER := 8192;     /* 0x00002000 */
  OFN_SHAREAWARE         CONSTANT  PLS_INTEGER := 16384;    /* 0x00004000 */
  OFN_NOREADONLYRETURN   CONSTANT  PLS_INTEGER := 32768;    /* 0x00008000 */
  OFN_NOTESTFILECREATE   CONSTANT  PLS_INTEGER := 65536;    /* 0x00010000 */
  OFN_NONETWORKBUTTON    CONSTANT  PLS_INTEGER := 131072;   /* 0x00020000 */
  OFN_NOLONGNAMES        CONSTANT  PLS_INTEGER := 262144;   /* 0x00040000 */
  OFN_EXPLORER           CONSTANT  PLS_INTEGER := 524288;   /* 0x00080000 */
  OFN_NODEREFERENCELINKS CONSTANT  PLS_INTEGER := 1048576;  /* 0x00100000 */
  OFN_LONGNAMES          CONSTANT  PLS_INTEGER := 2097152;  /* 0x00200000 */

  -- The defaults used here (WIN_API.OFN_PATHMUSTEXIST|WIN_API.OFN_FILEMUSTEXIST|WIN_API.OFN_HIDEREADONLY|WIN_API.OFN_NOCHANGEDIR|WIN_API.OFN_EXPLORER)
  OFN_FLAG_DEFAULT       CONSTANT  PLS_INTEGER :=  530444;
  
  
  -- Registry Data types for Write_RegistryEx
  REG_EXPAND_SZ          CONSTANT  PLS_INTEGER := 0;
  REG_SZ                 CONSTANT  PLS_INTEGER := 1;
  REG_DWORD              CONSTANT  PLS_INTEGER := 2;
  
  -- Compatibility Flags - Used where I have changed behaviour and you might not like the new version
  -- Change these at runtime to FALSE to revert to "old" behaviour
  COMPAT_EXPAND_REG_VALUES    BOOLEAN := TRUE;

  
  
  -- Types
  TYPE aFunctionHandle is table of WEBUTIL_C_API.FUNCTIONHANDLE index by BINARY_INTEGER;  
  SUBTYPE FILE_TYPE is PLS_INTEGER;

  -- Public Variables
  ERROR_ENCOUNTERED  BOOLEAN := FALSE;  /* The Last Call resulted in an error */
  ERROR_STACK        VARCHAR2(2000);    /* Holds Text of Last error(s) */ 
  API_ENABLED        BOOLEAN := FALSE;   /* Are API functions usable ?*/
  DLL_HANDLE         ORA_FFI.LibHandleType;
  FunctionHandle     aFunctionHandle;
   

  -- Public Exceptions
  NOT_AVAILABLE      EXCEPTION;  /* A call to the API was made but API functions not currently available (e.g. not on Windows) */
     
  -- Error Constants
  UError             CONSTANT  VARCHAR2(30) := ' Caused an unexpected error: ';
  NoAPI              CONSTANT  VARCHAR2(31) := 'API Functions are not Available';
  MaxDWord           CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 32 bits ';
  MaxWord            CONSTANT  VARCHAR2(33) := 'Integer Argument exceeds 16 bits ';
  MaxByte            CONSTANT  VARCHAR2(32) := 'Integer Argument exceeds 8 bits ';
  MinBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Small ';
  MaxBound           CONSTANT  VARCHAR2(27) := 'Integer Argument too Large ';
  NullArg            CONSTANT  VARCHAR2(24) := 'Argument cannot be NULL ';

  /*----------------------------------------------------------------------------*\
  * PreLoad ->  Loads the d2kwut60.dll from the jvm bin directory into memory
  \*----------------------------------------------------------------------------*/
```

#### SP-046 - WEBUTIL.GET_LINE

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads one line of text from a file opened on the Oracle Forms client. This is part of the WebUtil client-integration library file I/O functions.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| item | VARCHAR2 | OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  PROCEDURE get_line (file file_type, item OUT VARCHAR2) is
    buffer VARCHAR2(4000 char);
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);        
    buffer := WebUtil_Core.getProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_GETLINE');
    -- We can't easily tell the difference between an empty line and a line beyond then 
    -- end of the file so to get around this, the exception handling code in the PJC 
    -- places a newline into the buffer when the end of file is passed.
    -- The rational being that get_line would never normally return a newline because 
    -- it normally uses that to tell it where to read up *to*.
    if buffer = chr(10) then 
      raise NO_DATA_FOUND;
    else
      item := buffer;
    end if;

  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.get_line will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END get_line;
  
  /**
   * File writing functions
   */
```

#### SP-047 - WEBUTIL.GET_RETURN_CODE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the exit/return code from the most recently executed host command. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  
  FUNCTION Get_Return_Code(process in PROCESS_ID) return PLS_INTEGER is
  begin 
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_PROC_ID',process.handle);
    return to_number(WebUtil_Core.getProperty(WebUtil_Core.WUH_PACKAGE,'WUH_RC'));
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
       WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                               ||' bean not found. WEBUTIL_HOST.Get_Return_Code will not work');
  end Get_Return_Code;
```

#### SP-048 - WEBUTIL.GET_STANDARD_OUTPUT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the standard output stream content from the most recently executed host command. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.GETOUTPUT ([SP-042](#SP-042--WEBUTIL.GETOUTPUT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
    
  FUNCTION Get_Standard_Output(process in PROCESS_ID) return OUTPUT_ARRAY is  
  begin 
    return GetOutput(process,'WUH_STDOUT');
  end Get_Standard_Output;
```

#### SP-049 - WEBUTIL.HOST

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Executes a shell command on the Oracle Forms application server. This is part of the WebUtil client-integration library for invoking server-side host commands from Forms triggers.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| cmd | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.BLOCKING ([SP-020](#SP-020--WEBUTIL.BLOCKING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_RETURN_CODE ([SP-047](#SP-047--WEBUTIL.GET_RETURN_CODE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.RELEASE_PROCESS ([SP-064](#SP-064--WEBUTIL.RELEASE_PROCESS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION  Host(cmd in VARCHAR2) return PLS_INTEGER is
    procId PROCESS_ID;
    RC     PLS_INTEGER := -1;
  begin
    procId := Blocking(cmd);
    if not ID_NULL(procId) then
      RC := Get_Return_Code(procId);
      -- release the client side object
      Release_Process(procId);
    end if;
    return RC;
  end Host;
```

#### SP-050 - WEBUTIL.ID_NULL

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]
- webutil.pld [StoredProcedure: WEBUTIL.ERRORALERT]
- webutil.pld [StoredProcedure: WEBUTIL.HOST]
- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTER_FUNCTION]
- webutil.pld [StoredProcedure: WEBUTIL.SHOWBEANS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a given Oracle Forms record group or object handle is null (unallocated). This is part of the WebUtil client-integration library, wrapping the standard Forms ID_NULL built-in.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| handle | Pointer | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  FUNCTION ID_NULL(handle IN Pointer)        RETURN BOOLEAN is
  BEGIN
    if handle.hnd is null then 
      return TRUE;
    else
      return FALSE;
    end if;
  END ID_NULL;
```

#### SP-051 - WEBUTIL.INIT

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETOUTPUT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Initialises the WebUtil library and establishes the client-server communication channel. This is part of the WebUtil client-integration library and is called at form startup.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.INITWEBUTIL ([SP-052](#SP-052--WEBUTIL.INITWEBUTIL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE Init is
  begin 
    -- we don't need to do anything here - entering the package is enough to set it up.      
    null;
  end;      

BEGIN
  -- Initialise the Utility
  InitWebUtil;  
END WEBUTIL_CORE;

PACKAGE WEBUTIL_C_API IS
/*********************************************************************************\
 * WEBUTIL_C_API
 *   This Package provides a way of calling C functions in a shared library on the
 *   client PC. Currently only win32 is supported.
 *   The oracle.forms.webutil.cApi.CApiFunctions bean is needed in your Form to 
 *   use these functions
 *********************************************************************************
 * Version 1.0.5
 *********************************************************************************
 * Change History
 *   1.0.1 RVSUILIC 14/FEB/2003 - Creation 
 *   1.0.2 DRMILLS  27/FEB/2003 - Reset LONG to the same value as INT which is fine
 *                                for Windows & removed Tester proc
 *   1.0.3 DRMILLS  01/MAR/2003 - Re-worked the PL/SQL API
 *   1.0.4 DRMILLS  13/MAY/2003 - Added call to WebUtil_Core.Init
 *   1.0.5 RVSUILIC 21/MAY/2003 - Cleaned up some comments and formatting.
 *
\*********************************************************************************/

  /**
   *  Constants to represent PL/SQL IN, OUT and INOUT parameter qualifiers
   */
  PARAM_IN    CONSTANT PLS_INTEGER := 50;
  PARAM_INOUT CONSTANT PLS_INTEGER := 51;
  PARAM_OUT   CONSTANT PLS_INTEGER := 52;
  

  /**
   *  Constants to represent C atomic datatypes and pointers to atomic datatypes
   *  Note that to use OUT and INOUT qualifiers the C function in the DLL *must*
   *  use a pointer type to be able to pass information back.
   *
   *  The comments on the right indicate which types can be used for parameters
   *  and which for function return types.
   *
   *  c_ptr is used as a generic pointer. The onlys supported use for this is to
   *  save the pointer value from C into a PL/SQL variable, so that it may be 
   *  passed back later to C. No operations on the pointer are supported in PL/SQL.
   */
  c_void          CONSTANT PLS_INTEGER := 30;            /* - not used -   */
  c_char          CONSTANT PLS_INTEGER := 31;            /* param & return */
  c_short         CONSTANT PLS_INTEGER := 32;            /* param & return */
  c_int           CONSTANT PLS_INTEGER := 33;            /* param & return */
  c_long          CONSTANT PLS_INTEGER := 33;            /* param & return *//*DRM - same as INT */
  c_float         CONSTANT PLS_INTEGER := 35;            /* param & return */
  c_double        CONSTANT PLS_INTEGER := 36;            /* param & return */

  c_ptr           CONSTANT PLS_INTEGER := 64 + c_void;   /* param & return */
  c_char_ptr      CONSTANT PLS_INTEGER := 64 + c_char;   /* param          */
  c_short_ptr     CONSTANT PLS_INTEGER := 64 + c_short;  /* param          */
  c_int_ptr       CONSTANT PLS_INTEGER := 64 + c_int;    /* param          */
  c_long_ptr      CONSTANT PLS_INTEGER := 64 + c_long;   /* param          */
  c_float_ptr     CONSTANT PLS_INTEGER := 64 + c_float;  /* param          */
  c_double_ptr    CONSTANT PLS_INTEGER := 64 + c_double; /* param          */

  /**
   *  Abstracted types to be used for pointers and handles. The forms programmer
   *  should not attempt any manipulation on these types, but merely obtain them as
   *  a result of functions below, and pass them back in to other functions below.
   */
    SUBTYPE handleType   IS NUMBER;
    TYPE Pointer         IS RECORD (hnd handleType);   /* C pointer             */
    TYPE FunctionHandle  IS RECORD (hnd handleType);   /* function handle       */
    TYPE ParameterHandle IS RECORD (hnd handleType);   /* parameter handle      */
    TYPE ParameterList   IS RECORD (hnd handleType);   /* parameter list handle */

  /**
   *  IS_SUPPORTED - Check if the client is on a supported hardware platform.
   */
```

#### SP-052 - WEBUTIL.INITWEBUTIL

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INIT]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Performs the primary WebUtil initialisation by invoking the WebUtil bean and registering client-side callback triggers. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SHOWBEANS ([SP-068](#SP-068--WEBUTIL.SHOWBEANS)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE InitWebUtil is
    startPoint VARCHAR2(61 char) := NAME_IN('SYSTEM.CURSOR_FIELD');
    hDummy     ITEM              := FIND_ITEM(WEBUTIL_DUMMY_ITEM);
  BEGIN
    -- Set up the various package we know about.
    m_implClasses(WUC_PACKAGE) := 'common.VBeanCommon'; 
    m_implClasses(WUT_PACKAGE) := 'fileTransfer.FileTransfer'; 
    m_implClasses(WUF_PACKAGE) := 'file.FileFunctions'; 
    m_implClasses(WUI_PACKAGE) := 'clientInfo.GetClientInfo'; 
    m_implClasses(WUH_PACKAGE) := 'host.Host'; 
    m_implClasses(WUS_PACKAGE) := 'session.SessionFunctions'; 
    m_implClasses(WUB_PACKAGE) := 'browser.BrowserFunctions'; 
    m_implClasses(WUO_PACKAGE) := 'ole.OleFunctions'; 
    m_implClasses(WUU_PACKAGE) := '';      
    m_implClasses(WUL_PACKAGE) := 'cApi.CApiFunctions';                     
    
    -- Now check for the Webutil Object group which 
    -- contains the Beans etc.
          
    if id_null(m_errorAlert) then 
      -- The Webutil error alert is not around
      -- so the Code cannot operate 
      message('The WEBUTIL object group is not available in this Form.  WebUtil cannot work');
      pause;
    else
      -- Bug 2955789 - this navigation causes problems if they are in Enter-Query mode 
      -- Plus it's not really needed, except as a belt and braces kind of setup.
      -- So put a check to prevent this in E-Q mode and set a top level flag to bypass it 
      -- it all together which we can switch on or off if required as a furture W/A    
      if FLAG_EXPICIT_INSTANCIATE and name_in('SYSTEM.MODE') = 'NORMAL' then 
        if not ID_NULL(hDummy) then 
          -- they are using the standard Object Group
          GO_ITEM(hDummy);
          if GET_ITEM_PROPERTY(startPoint,BLOCK_NAME) = GET_ITEM_PROPERTY(hDummy,BLOCK_NAME) then 
            NEXT_BLOCK;
          else
            GO_ITEM(startPoint);
          end if;
          ShowBeans(false);        
        else
          -- do nothing assume that the programmer is doing their own thing.
          -- with regards to setting up the bean areas and making sure they are drawn
           null;      
        end if;
      end if;
    end if;
        
    -- Work out the server o/s informtion that we need
    if instr(upper(GET_APPLICATION_PROPERTY(OPERATING_SYSTEM)),'WIN') > 0 then 
      m_serverFileSep := '\';
    else
      m_serverFileSep := '/';
    end if;
  END InitWebUtil;
```

#### SP-053 - WEBUTIL.ISERROR

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Checks whether the most recent WebUtil operation resulted in an error. This is part of the WebUtil client-integration library error-handling mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION isError   return BOOLEAN is
  begin 
    return m_lastError <> 0;
  end;
```

#### SP-054 - WEBUTIL.IS_OPEN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Tests whether a file opened on the Oracle Forms client via WebUtil file I/O is still open. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  FUNCTION is_open(file file_type) RETURN BOOLEAN IS
  BEGIN
    IF file.handle IS NULL THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
  END is_open;
```

#### SP-055 - WEBUTIL.LENGTH

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: DEBUGLOG]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: STRIPDIRSEP]
- webutil.pld [StoredProcedure: WEBUTIL.GETSTRING]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the length of a string or file content retrieved from the Oracle Forms client. This is part of the WebUtil client-integration library utility functions.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION length(
    obj   ORA_JAVA.JOBJECT) RETURN NUMBER IS
  BEGIN
    args := NULL;
    RETURN JNI.CALL_LONG_METHOD(FALSE, obj, 'java/io/File', 'length', '()J', args); 
  END;
```

#### SP-056 - WEBUTIL.LOG

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]
- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a diagnostic log entry to the WebUtil log file. This is part of the WebUtil client-integration library logging mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| msg | VARCHAR2 | IN |
| isError | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ISERROR ([SP-053](#SP-053--WEBUTIL.ISERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.IS_OPEN ([SP-054](#SP-054--WEBUTIL.IS_OPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUT_LINE ([SP-059](#SP-059--WEBUTIL.PUT_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  

  PROCEDURE Log(msg in VARCHAR2, isError BOOLEAN) is
    logFile       TEXT_IO.FILE_TYPE;
    logFileName   VARCHAR2(1024 char);
    errorOnlyMode BOOLEAN;
  begin
    -- check to see if we should do anything
    if m_loggingAllowed is null then 
      -- set up the logging info Cache
      m_loggingAllowed    := (lower(ReadFromPropertyBundle('logging.enabled')) = 'true');
      m_loggingErrorsOnly := (lower(ReadFromPropertyBundle('logging.errorsonly')) = 'true');
      m_loggingFile       := ReadFromPropertyBundle('logging.file');
      if m_loggingAllowed then 
        if m_loggingFile is null then 
          -- no file == no logging
          m_loggingAllowed := false;
          if m_registeredPackages.FIRST is null then
            -- There is no bean registered yet. Throw error in English using alert
            ErrorAlert('WUC-008: Server side logging was requested but no log file was specified'
                       ||' - logging is disabled');
          else
            WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
            WebUtil_Core.error(WUC_PACKAGE,8,'WebUtil_Core.Log');
          end if;
        end if;
      end if;
      if m_registeredPackages.FIRST is not null then
        -- At least one bean is registered. Can call setProperty(WUC_PACKAGE)
        if m_loggingAllowed and m_loggingErrorsOnly then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','1',true);
        elsif  m_loggingAllowed then
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','2',true);
        else
          WebUtil_Core.setProperty(WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
        end if;
      end if;
    end if;
        
    -- now log if allowed to do so
    if m_loggingAllowed then
      if ((not m_loggingErrorsOnly) or (m_loggingErrorsOnly and isError)) then
        logFile := TEXT_IO.FOPEN(m_loggingFile,'A');
        if not TEXT_IO.IS_OPEN(logFile) then 
          raise NO_DATA_FOUND;
        end if;
        if m_clientIP is null then
        	TEXT_IO.PUT_LINE(logFile,msg);
        else
        	TEXT_IO.PUT_LINE(logFile,m_clientIP||':'||m_clientUserName||': '||msg);
        end if;
        TEXT_IO.FCLOSE(logFile);
      end if;    
    end if;
  EXCEPTION
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-007: Unable to write to WebUtil Logging File '|| m_loggingFile);
        else

          WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SRV_LOGGING','0',true);
          WebUtil_Core.error(WebUtil_Core.WUC_PACKAGE,7,'WebUtil_Core.Log',m_loggingFile);
        end if;
        m_loggingAllowed := false;
      else
        RAISE;
      end if;      
  end Log;
```

#### SP-057 - WEBUTIL.POPULATEPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.READFROMPROPERTYBUNDLE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Locates and reads the WebUtil configuration file, parses its key-value pairs into the in-memory property bundle (m_propertyBundle), and returns the value associated with the requested property key. The configuration file path is resolved by checking, in priority order, a Forms global variable, an environment variable, and a Forms parameter. This procedure supports the broader WebUtil client-integration framework by ensuring configuration properties are available before client operations are attempted.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERRORALERT ([SP-028](#SP-028--WEBUTIL.ERRORALERT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameter propertyKey (VARCHAR2), which identifies the configuration property whose value is to be retrieved.
- Step 2 - Attempt to read the WebUtil configuration file path from the Forms global variable WEBUTIL_CONFIG_GLOBAL using DEFAULT_VALUE and NAME_IN; if the global is set to '[NOTSET]', treat it as unset.
- Step 3 - If the global variable yields no path, call TOOL_ENV.GETVAR to read the path from the environment variable WEBUTIL_CONFIG_ENV.
- Step 4 - If the environment variable also yields no path, fall back to reading the path from the Forms parameter WEBUTIL_CONFIG_PARAM via NAME_IN.
- Step 5 - If all three sources fail to provide a path, raise NO_DATA_FOUND to trigger the exception handler.
- Step 6 - Persist the resolved configuration file path back into WEBUTIL_CONFIG_GLOBAL via COPY so that subsequent calls avoid re-resolution.
- Step 7 - Open the resolved configuration file for reading using TEXT_IO.FOPEN.
- Step 8 - Read the file line by line using TEXT_IO.GET_LINE in a loop; exit the loop when NO_DATA_FOUND is raised (end of file).
- Step 9 - For each line, skip lines whose first character is '#' (comment lines).
- Step 10 - For non-comment lines, locate the '=' delimiter using INSTR; skip lines that contain no '=' character.
- Step 11 - For valid key-value lines, increment the property index, store the trimmed, lower-cased key and the trimmed, carriage-return-stripped value into m_propertyBundle at the current index.
- Step 12 - If the stored key matches the lower-cased input propertyKey, capture the corresponding value into the result variable.
- Step 13 - After the loop, close the configuration file using TEXT_IO.FCLOSE and return the result value (NULL if the key was not found).
- Step 14 - On NO_DATA_FOUND exception (no configuration file path resolved): if no WebUtil bean is registered yet, call WEBUTIL.ERRORALERT to display error 'WUC-005: No WebUtil Configuration File specified'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL.
- Step 15 - On OTHERS exception with SQLCODE -302000 (file unreadable): if no bean is registered, call WEBUTIL.ERRORALERT to display 'WUC-006: Unable to read WebUtil Configuration File'; otherwise delegate to Webutil_Core.Error. Set m_config_error to TRUE and return NULL. For any other SQLCODE, re-raise the exception.

---
**Decision Points**

DP-001

Condition:
The value read from WEBUTIL_CONFIG_GLOBAL equals '[NOTSET]'.

TRUE:
Treat the global as unset; set configFile to NULL and proceed to attempt resolution via TOOL_ENV.GETVAR (DP-002).

FALSE:
Use the global variable value as the configuration file path; skip environment and parameter lookups.

---

DP-002

Condition:
configFile is NULL after the TOOL_ENV.GETVAR call.

TRUE:
Attempt to read the configuration file path from the Forms parameter WEBUTIL_CONFIG_PARAM (DP-003).

FALSE:
Use the environment variable value as the configuration file path.

---

DP-003

Condition:
configFile is NULL after reading WEBUTIL_CONFIG_PARAM.

TRUE:
Raise NO_DATA_FOUND; no configuration file path could be resolved.

FALSE:
Use the Forms parameter value as the configuration file path.

---

DP-004

Condition:
The first character of a line read from the configuration file is '#'.

TRUE:
Skip the line entirely; it is a comment.

FALSE:
Proceed to check for a key-value delimiter (DP-005).

---

DP-005

Condition:
The '=' character is found (pos > 0) within the current line.

TRUE:
Parse the line into a key-value pair, store it in m_propertyBundle, and check whether the key matches propertyKey (DP-006).

FALSE:
Skip the line; it does not represent a valid property entry.

---

DP-006

Condition:
The lower-cased stored key equals LOWER(propertyKey).

TRUE:
Assign the corresponding property value to the result variable.

FALSE:
Continue processing remaining lines without updating the result.

---

DP-007

Condition:
NO_DATA_FOUND exception is raised (no configuration file path was resolved) AND m_registeredPackages.FIRST IS NULL (no WebUtil bean registered).

TRUE:
Call WEBUTIL.ERRORALERT with message 'WUC-005: No WebUtil Configuration File specified' to display an English-language alert.

FALSE:
Delegate error reporting to Webutil_Core.Error with error code WUC_PACKAGE / 5.

---

DP-008

Condition:
OTHERS exception is raised with SQLCODE = -302000 (file cannot be read) AND m_registeredPackages.FIRST IS NULL.

TRUE:
Call WEBUTIL.ERRORALERT with message 'WUC-006: Unable to read WebUtil Configuration File'.

FALSE (bean registered):
Delegate error reporting to Webutil_Core.Error with error code WUC_PACKAGE / 6, passing configFile as context.

---

DP-009

Condition:
OTHERS exception is raised with SQLCODE other than -302000.

TRUE:
Re-raise the exception to the caller.

FALSE:
Not applicable (only SQLCODE = -302000 is handled silently).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The configuration file path must be resolvable from exactly one of three sources in strict priority order: (1) Forms global variable WEBUTIL_CONFIG_GLOBAL, (2) environment variable WEBUTIL_CONFIG_ENV via TOOL_ENV.GETVAR, (3) Forms parameter WEBUTIL_CONFIG_PARAM. If none provides a path, processing cannot continue.
- BR-002 - Once the configuration file path is successfully resolved, it must be written back to WEBUTIL_CONFIG_GLOBAL so that subsequent invocations can retrieve it without re-executing the three-source lookup.
- BR-003 - Lines in the configuration file that begin with '#' are treated as comments and must be ignored during parsing.
- BR-004 - Only lines containing an '=' character are treated as valid key-value property entries; lines without '=' are silently skipped.
- BR-005 - Property keys are stored and compared in lower-case with leading and trailing whitespace removed; property values are stored with leading and trailing whitespace removed and carriage-return characters (CHR(13)) stripped.
- BR-006 - All parsed key-value pairs are loaded into the shared in-memory collection m_propertyBundle regardless of whether they match the requested key, ensuring the bundle is fully populated for use by other callers such as WEBUTIL.READFROMPROPERTYBUNDLE.
- BR-007 - When a configuration error occurs (no file path found or file unreadable), the module-level flag m_config_error must be set to TRUE and NULL must be returned, preventing further configuration-dependent operations from proceeding silently.
- BR-008 - Error messaging strategy is conditional on bean registration state: if no WebUtil bean is registered (m_registeredPackages.FIRST IS NULL), WEBUTIL.ERRORALERT must be used to present a plain-English alert; otherwise, error reporting is delegated to the Webutil_Core.Error framework.
- BR-009 - A file-read failure identified by SQLCODE -302000 is a handled, recoverable error that sets m_config_error and returns NULL; all other unexpected exceptions are re-raised to the caller.

---
**Implementation Logic**

```plsql
      
  FUNCTION PopulatePropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is
    configFile   VARCHAR2(512 char);
    buffer       VARCHAR2(1000 char);
    result       VARCHAR2(1000 char);          
    propertyFile TEXT_IO.FILE_TYPE;
    pos          PLS_INTEGER;
    propIndex    PLS_INTEGER := 0;
  begin
    -- First of get the name of the cfg file 
    -- This could come in a global  or from the Environment
    default_value('[NOTSET]',WEBUTIL_CONFIG_GLOBAL);
    configFile := name_in(WEBUTIL_CONFIG_GLOBAL);
    if configFile = '[NOTSET]' then
      configFile := null; 
      -- Try the environment
      TOOL_ENV.GETVAR(WEBUTIL_CONFIG_ENV, configFile); 
      if configFile is null then 
        -- Finally try the Forms parameters
        configFile := name_in(WEBUTIL_CONFIG_PARAM);
        -- if that fails then we have to raise an error
        if configFile is null then 
          raise NO_DATA_FOUND;
        end if;    
      end if;
    end if;
    
    copy(configFile, WEBUTIL_CONFIG_GLOBAL);
      
    propertyFile := Text_IO.FOpen(configFile,'R');
    LOOP
      begin
        Text_IO.Get_Line(propertyFile,buffer);
      exception
        when NO_DATA_FOUND then EXIT;
      end;
        
      -- ignore lines which start with '#'
      if substr(buffer,1,1) <> '#' then 
        pos := instr(buffer,'=');
        -- only process lines with a name value pair
        if pos > 0 then 
          propIndex := propIndex + 1;
          m_propertyBundle(propIndex).propertyKey   := lower(ltrim(rtrim(substr(buffer,1,pos-1))));    
          m_propertyBundle(propIndex).propertyValue := ltrim(rtrim(replace(substr(buffer,pos+1),chr(13),'')));
          -- Check to see if this is the key we are looking for
          if  m_propertyBundle(propIndex).propertyKey = lower(propertyKey) then
            result := m_propertyBundle(propIndex).propertyValue;
          end if;
        end if;
      end if;
    end LOOP;
    Text_IO.FClose(propertyFile);
    return result;
  EXCEPTION
    when NO_DATA_FOUND then 
      if m_registeredPackages.FIRST is null then
        -- There is no bean registered yet. Throw error in English using alert
        ErrorAlert('WUC-005: No WebUtil Configuration File specified');
      else
        Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,5,'WebUtil_Core.PopulatePropertyBundle');
      end if;
      m_config_error := true;
      return null;
    when others then 
      if SQLCODE = '-302000' then
        if m_registeredPackages.FIRST is null then
          -- There is no bean registered yet. Throw error in English using alert
          ErrorAlert('WUC-006: Unable to read WebUtil Configuration File');
        else
          Webutil_Core.Error(Webutil_Core.WUC_PACKAGE,6,'WebUtil_Core.PopulatePropertyBundle', configFile);
        end if;
        m_config_error := true;
        return null;
      else
        RAISE;
      end if;      

  end PopulatePropertyBundle;
```

#### SP-058 - WEBUTIL.PUTF

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted string to a client-side text file by delegating two sequential property-set calls to the WebUtil_Core bean. The procedure is invoked during Excel report generation (VIEW_EXCEL_REPORT_NEW) to stream output content to an open client file handle.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| arg | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the open client file handle (file.handle) and the formatted string argument (arg) from the calling routine VIEW_EXCEL_REPORT_NEW.
- Step 2 - Transmit the file handle to the WebUtil_Core bean by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_HANDLE property key.
- Step 3 - Transmit the formatted string to the WebUtil_Core bean by calling WebUtil_Core.setProperty with the WUF_PACKAGE context and the WUF_TEXTIO_PUTF property key, instructing the bean to write the string to the identified file.
- Step 4 - If the WebUtil_Core bean is not registered (BEAN_NOT_REGISTERED exception), invoke WebUtil_Core.ErrorAlert to display a diagnostic message identifying the missing implementation class, then raise TOOL_ERR.TOOL_ERROR to abort processing.
- Step 5 - If a property-set operation fails (PROPERTY_ERROR exception), raise TOOL_ERR.TOOL_ERROR to abort processing without an additional alert.

---
**Decision Points**

DP-001

Condition:
WebUtil_Core raises BEAN_NOT_REGISTERED during either setProperty call (i.e., the WUF_PACKAGE bean is not available on the client).

TRUE:
WebUtil_Core.ErrorAlert is called with a message composed from WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE) indicating the bean was not found and that CLIENT_TEXT_IO.putf will not work; TOOL_ERR.TOOL_ERROR is then raised to halt execution.

FALSE:
Processing continues to the next setProperty call or completes normally.

DP-002

Condition:
WebUtil_Core raises PROPERTY_ERROR during either setProperty call (i.e., a property could not be set on the bean).

TRUE:
TOOL_ERR.TOOL_ERROR is raised immediately to halt execution; no alert is displayed.

FALSE:
Processing completes normally and control returns to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Both the file handle and the formatted string argument must be supplied; the procedure carries no defaulting logic and passes both values directly to the WebUtil_Core bean.
- BR-002 - The WUF_PACKAGE bean must be registered and available on the client before this procedure is called; absence of the bean is treated as a fatal error that prevents any write operation.
- BR-003 - The file handle is communicated to the bean as a discrete property (WUF_TEXTIO_HANDLE) before the write string property (WUF_TEXTIO_PUTF) is set, enforcing the required sequencing of client-side I/O context establishment prior to data transmission.
- BR-004 - Any failure in bean registration or property assignment results in TOOL_ERR.TOOL_ERROR being raised, ensuring the calling report generation process is notified of the failure and does not silently continue with incomplete file output.

---
**Implementation Logic**

```plsql
   
  
  
  procedure putf (file   file_type, 
                  arg    VARCHAR2) is 
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUTF',arg); 
  EXCEPTION
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                              ||' bean not found. CLIENT_TEXT_IO.putf will not work');
      RAISE TOOL_ERR.TOOL_ERROR;                                                                 
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE TOOL_ERR.TOOL_ERROR;  
  END putf;
```

#### SP-059 - WEBUTIL.PUT_LINE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.LOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a single line of text to a file opened on the Oracle Forms client. This is part of the WebUtil client-integration library file I/O functions.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| file | file_type | IN |
| item | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
    

  PROCEDURE put_line (file file_type, item VARCHAR2) is
  BEGIN 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_HANDLE',file.handle);              
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_PUT',item); 
    WebUtil_Core.setProperty(WebUtil_Core.WUF_PACKAGE,'WUF_TEXTIO_NEWLINE',1); 
  EXCEPTION
  when WebUtil_Core.BEAN_NOT_REGISTERED then 
    WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUF_PACKAGE)
                            ||' bean not found. CLIENT_TEXT_IO.put_line will not work');
    RAISE TOOL_ERR.TOOL_ERROR;                                                                 
  when WebUtil_Core.PROPERTY_ERROR then 
    RAISE TOOL_ERR.TOOL_ERROR;  
  END put_line;
```

#### SP-060 - WEBUTIL.READFROMPROPERTYBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.LOG]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a named property value from the loaded WebUtil property bundle. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.POPULATEPROPERTYBUNDLE ([SP-057](#SP-057--WEBUTIL.POPULATEPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadFromPropertyBundle(propertyKey in VARCHAR2) return VARCHAR2 is   
    result       VARCHAR2(1000 char);
    propCount    PLS_INTEGER := m_propertyBundle.COUNT;
  begin
    if m_config_error then
      -- already encountered problem reading the config file.
      return null;
    elsif (propCount = 0) then
      result := populatePropertyBundle(propertyKey);
    else
      for i in 1..propCount LOOP
        if m_propertyBundle(i).propertyKey = lower(propertyKey) then 
          result := m_propertyBundle(i).propertyValue;
          EXIT;
        end if;
      end LOOP;
    end if;
    return result;
  end ReadFromPropertyBundle;
```

#### SP-061 - WEBUTIL.READTRANSFROMMSGBUNDLE

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves a translated message string from the WebUtil message bundle by delegating to the WebUtil Core property mechanism. The function accepts a message property key and an optional arguments string, writes the lookup request to the WebUtil Core package property channel, and immediately reads back the resolved translation. It is currently used exclusively by WEBUTIL.CHECKLIBS to obtain the localised progress bar title.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyKey | VARCHAR2 | IN |
| args | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the message bundle property key (propertyKey) and an optional substitution arguments string (args).
- Step 2 - Concatenate propertyKey and args with a pipe delimiter ('|') to form the lookup payload.
- Step 3 - Write the lookup payload to the WebUtil Core package property slot identified by the constants WUC_PACKAGE and WUC_TRANS_MSG via Webutil_Core.setProperty.
- Step 4 - Read the resolved translated message string back from the same WebUtil Core property slot via Webutil_Core.getProperty.
- Step 5 - Return the retrieved translated message string to the caller.

---
**Decision Points**

No conditional decision points are present in the implementation logic. The function executes a fixed sequence of set and get operations against the WebUtil Core property channel without branching.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The property key and the optional arguments string must be combined using a pipe character ('|') as the delimiter before the lookup request is submitted to the WebUtil Core property channel.
- BR-002 - The args parameter is optional; when not supplied it defaults to NULL, resulting in a lookup payload of the form 'propertyKey|' (key followed by pipe and empty string).
- BR-003 - Message translation is resolved entirely through the Webutil_Core.setProperty / Webutil_Core.getProperty mechanism; no direct database query or independent translation table access is performed by this function.

---
**Implementation Logic**

```plsql
  
  FUNCTION ReadTransFromMsgBundle(propertyKey in VARCHAR2, args in VARCHAR2 := null) return VARCHAR2 is
    -- currently called from checkLibs only for getting progress bar title.
  begin 
    Webutil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG', propertyKey||'|'||args);
    return Webutil_Core.getProperty(WebUtil_Core.WUC_PACKAGE,'WUC_TRANS_MSG');
  end ReadTransFromMsgBundle;
```

#### SP-062 - WEBUTIL.REGISTERBEAN

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a WebUtil client-side bean with the Oracle Forms server-side runtime during session initialisation. On the first bean registration it captures client environment details (IP address, operating system, architecture, username, path/file separators, locale), resolves the system-library download directory, sets heartbeat and server-logging preferences on the client bean, and triggers library verification. On every subsequent bean registration it records the bean's trigger item and verifies the required client libraries for that specific package.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| clientInfo | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CHECKLIBS ([SP-021](#SP-021--WEBUTIL.CHECKLIBS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCLIENTSETTING ([SP-036](#SP-036--WEBUTIL.GETCLIENTSETTING)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETOSFAMILY ([SP-041](#SP-041--WEBUTIL.GETOSFAMILY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETPROPERTY ([SP-043](#SP-043--WEBUTIL.GETPROPERTY)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETVAR ([SP-045](#SP-045--WEBUTIL.GETVAR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.READFROMPROPERTYBUNDLE ([SP-060](#SP-060--WEBUTIL.READFROMPROPERTYBUNDLE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETCLIENTSETTING ([SP-065](#SP-065--WEBUTIL.SETCLIENTSETTING)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Extract the bean short name from the pipe-delimited clientInfo string (position 1) to identify which WebUtil package is being registered.
- Step 2 - Map the bean short name (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) to the corresponding WEBUTIL_CORE package-ID constant.
- Step 3 - Check whether the client IP address (m_clientIP) has already been populated. If it has not (i.e., this is the very first bean registration in the session), set the checkUserLibs flag to TRUE and parse the remaining clientInfo fields: IP address (position 2), OS name (position 3), OS architecture (position 4), username (position 5), path separator (position 6), file separator (position 7), and language code (position 8) into the corresponding module-level variables.
- Step 4 - Determine the OS family by calling WEBUTIL.GETOSFAMILY with the captured OS name, and set the 64-bit architecture flag (m_clientOSArch = 1) when the architecture string contains '64'.
- Step 5 - If the resolved packageID does not yet exist in the m_registeredPackages array, store the current SYSTEM.TRIGGER_ITEM value against that package ID and set the newPackage flag to TRUE, ensuring only the first instance of each bean type is registered.
- Step 6 - When checkUserLibs is TRUE, reset the REDOWNLOAD_SYSLIB flag to FALSE, then retrieve the server host name by calling WEBUTIL.GETVAR for 'COMPUTERNAME', falling back to 'HOST' if the first call returns null.
- Step 7 - Resolve the client system-library directory by calling WEBUTIL.READFROMPROPERTYBUNDLE with a key that incorporates the OS family and architecture; if no value is found, retry with the OS-family-only key.
- Step 8 - If no client library directory is configured, send the WUC_SYSLIB_DIR property to the WUC bean containing only the server host and application config, allowing the client JRE to handle placement. If a directory is configured, replace the '$(SERVERHOST)' token with the actual server host name, then send the full WUC_SYSLIB_DIR property value to the WUC bean.
- Step 9 - When a specific client library directory was configured, retrieve the previously stored directory via WEBUTIL.GETCLIENTSETTING ('install.syslib.dir'). If it differs from the newly resolved directory, persist the new value via WEBUTIL.SETCLIENTSETTING and set REDOWNLOAD_SYSLIB to TRUE.
- Step 10 - Retrieve and store the WebUtil bean version by calling WEBUTIL.GETPROPERTY for the WUC_BEAN_VERSION property.
- Step 11 - If the 'logging.connections' property bundle entry equals 'true' (case-insensitive), call WEBUTIL.LOG to record the connecting form name, client OS, and locale.
- Step 12 - If the newPackage flag is TRUE, call WEBUTIL.CHECKLIBS with the string representation of the package ID to verify and download any required package-specific client libraries.
- Step 13 - If checkUserLibs is TRUE, call WEBUTIL.LOG with a null message to initialise the m_loggingAllowed and m_loggingErrorsOnly flags.
- Step 14 - Read the 'BlockAllowHeartBeat' property bundle entry; if its lower-case value is 'true', 'yes', or '1', send WUC_BLOCK_ALLOW_HEART_BEAT = '1' to the client bean; otherwise send '0'.
- Step 15 - Evaluate the server-logging state: if both m_loggingAllowed and m_loggingErrorsOnly are TRUE send WUC_SRV_LOGGING = '1'; if only m_loggingAllowed is TRUE send '2'; otherwise send '0' to the client bean.
- Step 16 - If checkUserLibs is TRUE, call WEBUTIL.CHECKLIBS with the literal string 'user' to verify and download any user-defined client libraries.

---
**Decision Points**

DP-001
Condition: beanShortName matches one of the known constants (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL).
TRUE: packageID is set to the corresponding WEBUTIL_CORE package constant.
FALSE: packageID remains uninitialised; no package is registered for an unrecognised bean name.

DP-002
Condition: m_clientIP IS NULL (first bean registration in the session).
TRUE: checkUserLibs is set to TRUE and all client environment fields (IP, OS, OS family, architecture, username, path separator, file separator, language code) are parsed from clientInfo.
FALSE: Client environment fields are already populated; checkUserLibs remains FALSE and no re-parsing occurs.

DP-003
Condition: The OS architecture string contains '64'.
TRUE: m_clientOSArch is set to 1, indicating a 64-bit client.
FALSE: m_clientOSArch remains at its default value (non-64-bit client).

DP-004
Condition: m_registeredPackages does NOT already contain an entry for packageID.
TRUE: The current SYSTEM.TRIGGER_ITEM is stored for the package and newPackage is set to TRUE.
FALSE: The package was already registered (e.g., bean placed in a multi-row block); the existing registration is retained and newPackage remains FALSE.

DP-005
Condition: checkUserLibs is TRUE (first-registration path is active) - server host name retrieval.
TRUE: WEBUTIL.GETVAR is called for 'COMPUTERNAME'; if that returns null, WEBUTIL.GETVAR is called for 'HOST'.
FALSE: Server host name retrieval is skipped.

DP-006
Condition: clientLibDir resolved from WEBUTIL.READFROMPROPERTYBUNDLE (OS family + architecture key) IS NULL.
TRUE: WEBUTIL.READFROMPROPERTYBUNDLE is retried using the OS-family-only key.
FALSE: The architecture-specific directory value is used directly.

DP-007
Condition: clientLibDir (after both bundle lookups) IS NULL.
TRUE: WUC_SYSLIB_DIR is sent to the WUC bean containing only the server host and application config; the client JRE determines the placement directory.
FALSE: The configured directory is used; '$(SERVERHOST)' is replaced, WUC_SYSLIB_DIR is sent with the full path, and the stored client setting is compared.

DP-008
Condition: clientLibDirOld (from WEBUTIL.GETCLIENTSETTING) differs from the newly resolved clientLibDir.
TRUE: WEBUTIL.SETCLIENTSETTING persists the new directory and REDOWNLOAD_SYSLIB is set to TRUE.
FALSE: The directory is unchanged; REDOWNLOAD_SYSLIB remains FALSE.

DP-009
Condition: lower(WEBUTIL.READFROMPROPERTYBUNDLE('logging.connections')) = 'true'.
TRUE: WEBUTIL.LOG records the form name, client OS, and locale for the connection.
FALSE: No connection log entry is written.

DP-010
Condition: newPackage is TRUE.
TRUE: WEBUTIL.CHECKLIBS is called with the string package ID to verify package-specific client libraries.
FALSE: Library check for this package is skipped.

DP-011
Condition: lower(WEBUTIL.READFROMPROPERTYBUNDLE('BlockAllowHeartBeat')) is 'true', 'yes', or '1'.
TRUE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '1' to the client bean, instructing it to block the heartbeat.
FALSE: WUC_BLOCK_ALLOW_HEART_BEAT is sent as '0', allowing normal heartbeat behaviour.

DP-012
Condition: m_loggingAllowed is TRUE AND m_loggingErrorsOnly is TRUE.
TRUE: WUC_SRV_LOGGING is sent as '1' (errors-only logging).
FALSE: Evaluate next condition (DP-013).

DP-013
Condition: m_loggingAllowed is TRUE (and m_loggingErrorsOnly is FALSE).
TRUE: WUC_SRV_LOGGING is sent as '2' (full logging).
FALSE: WUC_SRV_LOGGING is sent as '0' (logging disabled on client).

DP-014
Condition: checkUserLibs is TRUE (end of procedure - user library check).
TRUE: WEBUTIL.CHECKLIBS is called with 'user' to verify and download user-defined client libraries.
FALSE: User library check is skipped.

---
**Database Interactions**

- DB-001 - Update THIS - Updates existing rows in THIS.
**Business Rules**

- BR-001 - Only the ten recognised bean short names (WUC, WUT, WUF, WUI, WUH, WUS, WUB, WUO, WUU, WUL) are mapped to package IDs; any unrecognised short name results in no package registration.
- BR-002 - Client environment metadata (IP address, OS, OS family, architecture, username, path separator, file separator, language code) is captured exactly once per session, on the first bean registration; subsequent registrations do not overwrite these values.
- BR-003 - Each bean type may be registered only once per form session; if the same bean type appears in multiple block rows, only the first instance (trigger item) is recorded.
- BR-004 - The system-library client directory is resolved in priority order: OS-family + architecture-specific key first, then OS-family-only key, then a fallback that delegates directory selection to the client JRE.
- BR-005 - The '$(SERVERHOST)' token in the configured client library directory must be replaced with the actual server host name before the value is transmitted to the client bean.
- BR-006 - If the resolved system-library directory differs from the value previously stored on the client, the new value is persisted via WEBUTIL.SETCLIENTSETTING and the REDOWNLOAD_SYSLIB flag is raised to trigger a re-download.
- BR-007 - Connection logging is conditional: a log entry is written only when the 'logging.connections' property bundle entry is explicitly set to 'true'.
- BR-008 - The heartbeat-blocking instruction sent to the client bean is controlled exclusively by the 'BlockAllowHeartBeat' configuration entry; accepted truthy values are 'true', 'yes', and '1' (case-insensitive).
- BR-009 - Server-side logging state must be communicated to the client bean (WUC_SRV_LOGGING: 0 = disabled, 1 = errors only, 2 = full) so the client avoids sending unnecessary log messages to the server.
- BR-010 - Package-specific library verification (WEBUTIL.CHECKLIBS) is performed only for newly registered packages, not for duplicate registrations of an already-known package.
- BR-011 - User library verification (WEBUTIL.CHECKLIBS with 'user') is performed once per session, after at least one bean has been registered, to ensure a handler bean exists to perform any required download.
- BR-012 - The logging initialisation call (WEBUTIL.LOG with null) must occur after the first bean is registered so that the m_loggingAllowed and m_loggingErrorsOnly flags are correctly set before any subsequent logging or property-bundle reads depend on them.

---
**Implementation Logic**

```plsql
  PROCEDURE registerBean(clientInfo in VARCHAR2) is  
    packageID       PLS_INTEGER;
    beanShortName   VARCHAR2(3 char);
    newPackage      BOOLEAN := false;
    checkUserLibs   BOOLEAN := false;
    clientLibDir    VARCHAR2(1000 char);
    clientLibDirOld VARCHAR2(1000 char);
    serverHost      VARCHAR2(100 char);
    blockAllowHeartBeat VARCHAR2(10 char);
    clientOSArch    VARCHAR2(30 char);
  begin
    beanShortName := DelimStr.getString(clientInfo,1,true,'|');

    -- To speed access up we crossmatch the Bean Name string
    -- with a constant - this constant is used to access the 
    -- registered package array efficently
    -- need to update this IF statement as we add new packages
    if beanShortName = 'WUC' then
       packageID := WEBUTIL_CORE.WUC_PACKAGE; 
    elsif beanShortName = 'WUT' then     
       packageID := WEBUTIL_CORE.WUT_PACKAGE; 
    elsif beanShortName = 'WUF' then 
       packageID := WEBUTIL_CORE.WUF_PACKAGE; 
    elsif beanShortName = 'WUI' then
        packageID := WEBUTIL_CORE.WUI_PACKAGE; 
    elsif beanShortName = 'WUH' then            
       packageID := WEBUTIL_CORE.WUH_PACKAGE;
    elsif beanShortName = 'WUS' then     
       packageID := WEBUTIL_CORE.WUS_PACKAGE;
    elsif beanShortName = 'WUB' then 
       packageID := WEBUTIL_CORE.WUB_PACKAGE;
    elsif beanShortName = 'WUO' then     
       packageID := WEBUTIL_CORE.WUO_PACKAGE;
    elsif beanShortName = 'WUU' then     
       packageID := WEBUTIL_CORE.WUU_PACKAGE;
    elsif beanShortName = 'WUL' then     
       packageID := WEBUTIL_CORE.WUL_PACKAGE;           
    end if;
    -- For the very first bean we can get a bit of useful information
    -- Only do this once
    if m_clientIP is null then 
      checkUserLibs := true;
      -- Format of the clientinfo packet is
      -- BeanName|IP|OSName|UserName|pathSep|filesep
      m_clientIP       := DelimStr.getString(clientInfo,2,true,'|');
      m_clientOS       := DelimStr.getString(clientInfo,3,true,'|');
      m_clientOSFamily := getOSFamily(m_clientOS);
      clientOSArch     := DelimStr.getString(clientInfo,4,true,'|');
      if instr(clientOSArch, '64') > 0 then
        m_clientOSArch := 1;
      end if;
      m_clientUserName := DelimStr.getString(clientInfo,5,true,'|');      
      m_clientPathSep  := DelimStr.getString(clientInfo,6,true,'|');
      m_clientFileSep  := DelimStr.getString(clientInfo,7,true,'|');
      m_clientLangCode := DelimStr.getString(clientInfo,8,true,'|'); 
    end if;
      
    -- I'd only expect one instance of each bean per form
    -- but just in case we only register the first 
    -- so if multiple copies are used - e.g. it's 
    -- placed in a multi-row block we just use the 
    -- first instance.
    if not m_registeredPackages.EXISTS(packageID) then 
      m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM');
      -- make sure all the required libraries are available
      -- on the client
      newPackage := true;
    end if;
      
    if checkUserLibs then
      -- checkUserLibs would be true if clientIP was null
      -- We can do whatever we want to do but not more than once
      REDOWNLOAD_SYSLIB := FALSE;
      -- We need to get the server host name using available built-ins. This looks lame,
      -- but it should work
      TOOL_ENV.GETVAR('COMPUTERNAME', serverHost);
      if serverHost is null then
        TOOL_ENV.GETVAR('HOST', serverHost);
      end if;
      clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily) ||
                                             '.' || to_char(m_clientOSArch));
      if clientLibDir is null then
        clientLibDir := readFromPropertyBundle('install.syslib.location.client.'||to_char(m_clientOSFamily));
      end if;
      if clientLibDir is null then
        -- client location when syslib download is not defined in webutil.cfg
        -- will be to client JRE. Send nothing and client will handle
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
      else
        -- webutil.cfg contains a specific client directory for syslib download
        -- Replace $(SERVERHOST), if exists, with server host name
        clientLibDir := replace(clientLibDir, '$(SERVERHOST)', serverHost);

        -- The following line makes a few things happen on client including
        -- client directory creation, when clientLibDir is not null
        WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SYSLIB_DIR',
                                 clientLibDir || ':' || serverHost || ':' || GET_APPLICATION_PROPERTY(CONFIG),
                                 true);
        clientLibDirOld := GetClientSetting('install.syslib.dir');

        if clientLibDirOld <> clientLibDir then
    	  SetClientSetting('install.syslib.dir', clientLibDir);
          REDOWNLOAD_SYSLIB := TRUE;
    	end if;
      end if;
      Webutil_Core.WEBUTIL_VERSION := getProperty(WUC_PACKAGE,'WUC_BEAN_VERSION');
      -- We want to write the connection record if it's required.
      -- Any call to ReadFromPropertyBundle or log should be preferably made after
      -- registering at least one bean. That is the reason why the following log
      -- comes after m_registeredPackages(packageID) := name_in('SYSTEM.TRIGGER_ITEM'); above
      if lower(ReadFromPropertyBundle('logging.connections')) = 'true' then 
        log('Connection from Form='||GET_APPLICATION_PROPERTY(CURRENT_FORM)||' Client O/S='||m_clientOS||' locale='||m_clientLangCode,false);
      end if;
    end if;
    if newPackage then  
            checkLibs(to_char(packageID));
    end if;

    if checkUserLibs then
      -- Call a dummy log to initialize m_loggingAllowed and m_loggingErrorsOnly
      log(null,false);
    end if;

    -- 5950737 - Introduce new configuration variable BlockAllowHeartBeat. 
    -- Valid values are true, yes and 1.
    -- If this is set then send a message to the client to behave accordingly.    
    blockAllowHeartBeat := lower(ReadFromPropertyBundle('BlockAllowHeartBeat'));
    if blockAllowHeartBeat = 'true' or blockAllowHeartBeat = 'yes' or blockAllowHeartBeat = '1' then 
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','1',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_BLOCK_ALLOW_HEART_BEAT','0',true);
    end if;

    -- Send server logging options to client bean so that the bean does not have
    -- to send message to server unnecessarily.
    if m_loggingAllowed and m_loggingErrorsOnly then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','1',true);
    elsif m_loggingAllowed then
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','2',true);
    else
      WebUtil_Core.setProperty(packageID,'WUC_SRV_LOGGING','0',true);
    end if;
      
    -- 2836929 - move the user library check after the first package is registered 
    -- so that a handler bean exists to do the download.     
    if checkUserLibs then 
      --Check for and download any user libs
      checkLibs('user');  
    end if;     
  end registerBean;
```

#### SP-063 - WEBUTIL.REGISTER_FUNCTION

**Invoked From:**

- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a native client-side function with the WebUtil framework so it can be called from Oracle Forms PL/SQL. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| libName | VARCHAR2 | IN |
| funcName | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  FUNCTION REGISTER_FUNCTION (libName IN VARCHAR2, funcName IN VARCHAR2) 
                              RETURN FunctionHandle IS
    strHnd  VARCHAR2(8);                            
    funcHnd FunctionHandle;
  BEGIN
    WebUtil_Core.setProperty(WebUtil_Core.WUL_PACKAGE,'WUL_FUNCTION_SPEC', libName || '|' || funcName);
    strHnd := WebUtil_Core.getProperty(WebUtil_Core.WUL_PACKAGE,'WUL_REGISTER_FUNCTION');
    funcHnd.hnd := TO_NUMBER (strHnd);
    if NOT ID_NULL(funcHnd) then
      m_funcHandleCount := m_funcHandleCount + 1;
    end if;

    RETURN funcHnd;
    
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUL_PACKAGE)
                              ||' bean not found. WEBUTIL_C_API.REGISTER_FUNCTION will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;  
    when VALUE_ERROR then
        RAISE TOOL_ERR.TOOL_ERROR; 
  END REGISTER_FUNCTION;
```

#### SP-064 - WEBUTIL.RELEASE_PROCESS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.HOST]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Releases the resources associated with a previously started host process by clearing the process handle on the WebUtil client-side JavaBean and nullifying the local handle reference. This procedure is invoked as a cleanup step within WEBUTIL.HOST to ensure that process state is properly discarded after the host operation completes.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

**Output Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| process | PROCESS_ID | IN OUT |

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the IN OUT parameter `process` (of type PROCESS_ID) from the calling routine WEBUTIL.HOST.
- Step 2 - Invoke `WebUtil_Core.setProperty` with the package constant `WebUtil_Core.WUH_PACKAGE`, the property key `WUH_CLEAR_PROC`, and `process.handle` to signal the WebUtil JavaBean to release the client-side process resource.
- Step 3 - Invoke `WebUtil_Core.ClearCallbackTrigger` passing `process.handle` to remove any callback trigger registered against this process handle on the WebUtil core layer.
- Step 4 - Set `process.handle` to `null`, invalidating the caller's reference to the now-released process.
- Step 5 - If a `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised at any point, display an error alert identifying the missing implementation class and informing the user that `WEBUTIL_HOST.Release_Process` will not function.

---
**Decision Points**

DP-001

Condition:
A `WebUtil_Core.BEAN_NOT_REGISTERED` exception is raised during execution (i.e., the WebUtil JavaBean identified by `WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)` is not registered on the client).

TRUE:
An error alert is displayed to the user stating that the bean was not found and that `WEBUTIL_HOST.Release_Process` will not work; no further cleanup steps are performed.

FALSE:
Execution completes normally: the process property is cleared on the bean, the callback trigger is removed, and `process.handle` is set to null.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The `process.handle` value must be a valid handle previously assigned by the WebUtil host framework; this procedure does not validate the handle before attempting to release it.
- BR-002 - Clearing the process on the JavaBean (`WebUtil_Core.setProperty` with `WUH_CLEAR_PROC`) and removing the callback trigger (`WebUtil_Core.ClearCallbackTrigger`) must both occur before the handle is nullified to ensure complete resource cleanup.
- BR-003 - After successful execution, `process.handle` is set to null, making the PROCESS_ID record unusable for any further WebUtil host operations; the caller must not reference the handle after invoking this procedure.
- BR-004 - If the required WebUtil JavaBean is not registered on the client, the procedure raises a user-facing error alert and does not attempt partial cleanup; the caller should treat this condition as a configuration or deployment fault.

---
**Implementation Logic**

```plsql
  
  PROCEDURE Release_Process(process in out PROCESS_ID) is  
  begin
    WebUtil_Core.setProperty(WebUtil_Core.WUH_PACKAGE,'WUH_CLEAR_PROC',process.handle);
    WebUtil_Core.ClearCallbackTrigger(process.handle);
    process.handle := null;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUH_PACKAGE)
                              ||' bean not found. WEBUTIL_HOST.Release_Process will not work');
  end Release_Process;
```

#### SP-065 - WEBUTIL.SETCLIENTSETTING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.CHECKLIBS]
- webutil.pld [StoredProcedure: WEBUTIL.REGISTERBEAN]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named client-side configuration property by delegating to the WebUtil Core bean. The procedure accepts a property name and value, concatenates them into a key=value string, and forwards the assignment to the WebUtil Core package using the WUC_SET_LOCAL_PROPERTY action. It is invoked during library checking (WEBUTIL.CHECKLIBS) and bean registration (WEBUTIL.REGISTERBEAN) to apply runtime client settings required for WebUtil operation.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| propertyName | VARCHAR2 | IN |
| propertyValue | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the property name (propertyName) and property value (propertyValue) as input parameters.
- Step 2 - Evaluate whether propertyName is not null; if null, the procedure takes no action and exits silently.
- Step 3 - If propertyName is not null, construct the assignment string by concatenating propertyName, a literal '=' character, and propertyValue.
- Step 4 - Invoke WebUtil_Core.setProperty, passing the WUC_PACKAGE constant as the target package identifier, the WUC_SET_LOCAL_PROPERTY constant as the action, and the constructed key=value string as the property payload.
- Step 5 - If the WebUtil Core bean has not been registered (BEAN_NOT_REGISTERED exception), display an error alert identifying the missing bean class and raise FORM_TRIGGER_FAILURE to halt form processing.
- Step 6 - If the property assignment fails within the bean (PROPERTY_ERROR exception), raise FORM_TRIGGER_FAILURE to halt form processing without an additional alert.

---
**Decision Points**

DP-001

Condition: propertyName IS NOT NULL

TRUE: Construct the key=value string and call WebUtil_Core.setProperty to apply the client setting.

FALSE: Skip all processing; the procedure exits without performing any action.

DP-002

Condition: WebUtil_Core.BEAN_NOT_REGISTERED exception is raised during the setProperty call

TRUE: Display an error alert identifying the missing WebUtil Core bean class and raise FORM_TRIGGER_FAILURE to abort the current form trigger.

FALSE: No exception of this type; processing continues normally.

DP-003

Condition: WebUtil_Core.PROPERTY_ERROR exception is raised during the setProperty call

TRUE: Raise FORM_TRIGGER_FAILURE to abort the current form trigger without displaying an additional alert.

FALSE: No exception of this type; the property is applied successfully and the procedure exits normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A null propertyName is silently ignored; no property assignment is attempted and no error is raised, ensuring the procedure is safe to call even when the property name is conditionally populated.
- BR-002 - The property payload passed to the WebUtil Core bean must follow the key=value format, formed by concatenating propertyName, '=', and propertyValue; no other format is accepted by the WUC_SET_LOCAL_PROPERTY action.
- BR-003 - The WebUtil Core bean identified by WUC_PACKAGE must be registered before this procedure is called; if it is absent, the form trigger is unconditionally aborted via FORM_TRIGGER_FAILURE after an error alert is displayed.
- BR-004 - A PROPERTY_ERROR returned by the bean constitutes a fatal condition; the form trigger is aborted via FORM_TRIGGER_FAILURE with no further user notification, preventing partial or inconsistent client-side state.

---
**Implementation Logic**

```plsql

  PROCEDURE SetClientSetting(propertyName  in VARCHAR2,
                             propertyValue in VARCHAR2) is
  BEGIN
    if propertyName is not null then 
      WebUtil_Core.setProperty(WebUtil_Core.WUC_PACKAGE,'WUC_SET_LOCAL_PROPERTY', propertyName||'='||propertyValue);
    end if;
  EXCEPTION  
    when WebUtil_Core.BEAN_NOT_REGISTERED then 
      WebUtil_Core.ErrorAlert(WebUtil_Core.getImplClass(WebUtil_Core.WUC_PACKAGE)
                              ||' bean not found. WEBUTIL_CORE.SetClientSetting will not work');
      RAISE FORM_TRIGGER_FAILURE;  
    when WebUtil_Core.PROPERTY_ERROR then 
      RAISE FORM_TRIGGER_FAILURE;       
  END SetClientSetting;
```

#### SP-066 - WEBUTIL.SETDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WEBUTIL.SETDATA receives a single chunk of upload data (as a VARCHAR2 string) during a file-transfer operation and writes it to the appropriate destination - either a database BLOB or a server-side file - depending on the active transfer mode. Once all expected chunks have been received, the procedure closes the destination resource, marks the upload as succeeded or failed, and fires any registered callback trigger to signal completion to the calling form.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| uploadData | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.CLEARCALLBACKTRIGGER ([SP-022](#SP-022--WEBUTIL.CLEARCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEBLOB ([SP-023](#SP-023--WEBUTIL.CLOSEBLOB)) - WEBUTIL.pck (or .pld)
- WEBUTIL.CLOSEFILE ([SP-024](#SP-024--WEBUTIL.CLOSEFILE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETCALLBACKTRIGGER ([SP-034](#SP-034--WEBUTIL.GETCALLBACKTRIGGER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERROR ([SP-038](#SP-038--WEBUTIL.GETLASTERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETLASTERRORARGS ([SP-039](#SP-039--WEBUTIL.GETLASTERRORARGS)) - WEBUTIL.pck (or .pld)
- WEBUTIL.WRITEDATA ([SP-070](#SP-070--WEBUTIL.WRITEDATA)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Validate the incoming chunk: if uploadData is NULL or empty, set the module-level flag m_uploadSucceeded to FALSE and exit; no further processing is performed.
- Step 2 - Determine the write destination using the module-level flag m_toDB.
- Step 3 (m_toDB = TRUE) - Delegate the chunk write to WebUtil_DB_LOCAL.WriteData, passing uploadData.
- Step 4 (m_toDB = FALSE) - Attempt to write the chunk via JAVA_APPSERV_WRITER.WriteData. If the write fails, retrieve the error code via JAVA_APPSERV_WRITER.getLastError and the error arguments via JAVA_APPSERV_WRITER.getLastErrorArgs, log the error through WebUtil_Core.Error, and raise the READWRITE_ERROR exception to abort processing.
- Step 5 - Decrement the module-level chunk counter m_chunks by 1.
- Step 6 - If m_chunks has reached 0 (all chunks received), proceed to close the destination resource.
- Step 7 (m_toDB = TRUE, closing) - Call WebUtil_DB_Local.CloseBlob passing m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the last error from WebUtil_DB_Local.getLastError, log it via WebUtil_Core.Error, and leave m_uploadSucceeded FALSE.
- Step 8 (m_toDB = FALSE, closing) - Call JAVA_APPSERV_WRITER.CloseFile passing m_persistObj and m_fileSize. If successful, set m_uploadSucceeded to TRUE; otherwise retrieve the error code and arguments, log the error via WebUtil_Core.Error, release the Java global reference via ORA_JAVA.DELETE_GLOBAL_REF, and raise READWRITE_ERROR.
- Step 9 - After the resource is closed, check whether a callback trigger is registered by calling WEBUTIL.GETCALLBACKTRIGGER(-1). If a trigger name is returned, execute it via EXECUTE_TRIGGER.
- Step 10 - Unconditionally clear the callback trigger registration by calling WEBUTIL.CLEARCALLBACKTRIGGER(-1), regardless of whether a trigger was fired.

---
**Decision Points**

DP-001
Condition: uploadData IS NULL or uploadData = '' (empty string).
TRUE: Set m_uploadSucceeded to FALSE and exit the procedure immediately without writing any data.
FALSE: Proceed to write the chunk to the designated destination.

DP-002
Condition: m_toDB is TRUE.
TRUE: Write the chunk using WebUtil_DB_LOCAL.WriteData (database BLOB path).
FALSE: Write the chunk using JAVA_APPSERV_WRITER.WriteData (server-side file path).

DP-003
Condition: JAVA_APPSERV_WRITER.WriteData returns FALSE (file-path write failed).
TRUE: Retrieve error details, log the error via WebUtil_Core.Error, and raise READWRITE_ERROR to abort.
FALSE: Continue to decrement the chunk counter.

DP-004
Condition: m_chunks equals 0 after decrement (all chunks have been received).
TRUE: Proceed to close the destination resource and evaluate upload success.
FALSE: Return without closing; further chunks are still expected.

DP-005
Condition: m_toDB is TRUE at close time.
TRUE: Close the BLOB via WebUtil_DB_Local.CloseBlob.
FALSE: Close the file via JAVA_APPSERV_WRITER.CloseFile.

DP-006
Condition: WebUtil_DB_Local.CloseBlob succeeds (m_toDB = TRUE path).
TRUE: Set m_uploadSucceeded to TRUE.
FALSE: Log the error via WebUtil_Core.Error; m_uploadSucceeded remains FALSE.

DP-007
Condition: JAVA_APPSERV_WRITER.CloseFile succeeds (m_toDB = FALSE path).
TRUE: Set m_uploadSucceeded to TRUE.
FALSE: Retrieve error details, log via WebUtil_Core.Error, delete the Java global reference, and raise READWRITE_ERROR.

DP-008
Condition: WEBUTIL.GETCALLBACKTRIGGER(-1) returns a non-null trigger name.
TRUE: Execute the registered callback trigger via EXECUTE_TRIGGER.
FALSE: Skip trigger execution; proceed directly to clearing the callback registration.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A NULL or empty uploadData chunk is treated as an error condition; the upload is immediately marked as failed and no data is written to any destination.
- BR-002 - Each call to SETDATA processes exactly one chunk; the procedure is designed to be invoked repeatedly until all chunks (tracked by m_chunks) have been received.
- BR-003 - The write destination (database BLOB vs. server-side file) is determined solely by the module-level flag m_toDB, which must be set before the first chunk is submitted.
- BR-004 - A write failure on the server-side file path (JAVA_APPSERV_WRITER.WriteData) is a fatal, non-recoverable error for that chunk; the procedure raises READWRITE_ERROR and does not attempt a retry.
- BR-005 - Resource closure (BLOB or file) is performed only after the final chunk is received (m_chunks = 0); partial transfers do not trigger closure.
- BR-006 - A failure to close the server-side file additionally requires the Java global reference (m_persistObj) to be explicitly released via ORA_JAVA.DELETE_GLOBAL_REF to prevent resource leaks.
- BR-007 - The upload success flag (m_uploadSucceeded) is set to TRUE only upon successful closure of the destination resource; any error during writing or closure leaves the flag FALSE.
- BR-008 - A callback trigger, if registered, is always fired after the final chunk is successfully closed, providing the calling form with a completion notification.
- BR-009 - WEBUTIL.CLEARCALLBACKTRIGGER(-1) is called unconditionally after the final chunk is processed, ensuring the callback registration is reset regardless of whether a trigger was executed.

---
**Implementation Logic**

```plsql
   
  PROCEDURE SetData(uploadData in VARCHAR2) is 
    lastErrorCode    PLS_INTEGER;
    lastErrorArgs    VARCHAR2(1000);   
  BEGIN
    if uploadData is null or uploadData = '' then 
      -- error condition!
      m_uploadSucceeded := false;
    else
      -- Write to the correct place    
      if m_toDB then 
        WebUtil_DB_LOCAL.WriteData(uploadData);
      else
        if not JAVA_APPSERV_WRITER.WriteData(m_persistObj,uploadData) then
          lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
          lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
          WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                             'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
          raise READWRITE_ERROR;
        end if;
      end if;
      m_chunks := m_chunks - 1;
      if m_chunks = 0 then 
        if m_toDB then 
          if WebUtil_DB_Local.CloseBlob(m_fileSize) then 
            m_uploadSucceeded := true;
          else
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE, WebUtil_DB_Local.getLastError,
                               'WEBUTIL_FILE_TRANSFER.SetData');
          end if; -- close
        else
          if JAVA_APPSERV_WRITER.CloseFile(m_persistObj,m_fileSize) then
            m_uploadSucceeded := true;
          else
            lastErrorCode := JAVA_APPSERV_WRITER.getLastError(m_persistObj);
            lastErrorArgs := JAVA_APPSERV_WRITER.getLastErrorArgs(m_persistObj) ;
            WebUtil_core.Error(Webutil_Core.WUT_PACKAGE,lastErrorCode,
                               'WEBUTIL_FILE_TRANSFER.SetData',lastErrorArgs);
            ORA_JAVA.DELETE_GLOBAL_REF(m_persistObj);
            raise READWRITE_ERROR;
          end if;    
        end if; -- toDB

        if WebUtil_Core.GetCallbackTrigger(-1) is not null then
          EXECUTE_TRIGGER(WebUtil_Core.GetCallbackTrigger(-1));
        end if;
        WebUtil_Core.ClearCallbackTrigger(-1);
      end if; -- chunks
    end if;
  end SetData;
```

#### SP-067 - WEBUTIL.SETPROPERTY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL_CORE.CUSTOMEVENTHANDLER]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Sets a named property value in the WebUtil session context. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| a0 | VARCHAR2 | IN |
| a1 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION setProperty(
    a0    VARCHAR2,
    a1    VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(2);
    JNI.ADD_STRING_ARG(args, a0);
    JNI.ADD_STRING_ARG(args, a1);
    RETURN JNI.CALL_STRING_METHOD(TRUE, NULL, 'java/lang/System', 'setProperty', '(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;', args); 
  END;
```

#### SP-068 - WEBUTIL.SHOWBEANS

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.INITWEBUTIL]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Triggers display or initialisation of the WebUtil JavaBean component in the Oracle Forms canvas. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| show | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  
  PROCEDURE ShowBeans(show BOOLEAN) is
    hWin WINDOW := FIND_WINDOW(WEBUTIL_HIDDEN_WINDOW);
  begin
    -- Bug 2955789 - don't attempt to do this when in Enter Query Mode
    if name_in('SYSTEM.MODE') = 'NORMAL' then 
      if not ID_NULL(hWin) then 
        if show then 
          m_infoFrom := FIND_ITEM(name_in('SYSTEM.CURSOR_ITEM'));
          SET_WINDOW_PROPERTY(hWin,TITLE,'WebUtil '||WEBUTIL_VERSION);
          SHOW_WINDOW(hWin);
          go_item(WEBUTIL_DUMMY_ITEM);
        else
          if not id_null(m_infoFrom) then 
              go_item(m_infoFrom);
          end if;
          HIDE_WINDOW(hWin);
        end if;
      end if;
    end if;
  end ShowBeans;
```

#### SP-069 - WEBUTIL.URL_TO_CLIENT

**Invoked From:**

- dms_excel_report.pld [StoredProcedure: VIEW_EXCEL_REPORT_NEW]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Transfers a file from a server-side URL to the Oracle Forms client machine, enabling file downloads. This is part of the WebUtil client-integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| sourceURL | VARCHAR2 | IN |
| clientDestination | VARCHAR2 | IN |
| fileSize | PLS_INTEGER | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.DOWNLOADFROMURL ([SP-025](#SP-025--WEBUTIL.DOWNLOADFROMURL)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling Oracle Forms trigger or library routine.
- Step 2 - Execute the WebUtil client-integration operation (delegate to the WebUtil JavaBean or underlying client API).
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

Decision logic within this routine cannot be verified from the available source bundle (EXTERNAL / NOT IN BUNDLE) or is not present in this specification-only entry.

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the WebUtil client-integration library; its internal business rules are governed by the Oracle WebUtil framework.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql
  FUNCTION URL_To_Client(sourceURL         in VARCHAR2, 
                         clientDestination in VARCHAR2, 
                         fileSize          in PLS_INTEGER default 0) return BOOLEAN is
  BEGIN
      return WebUtil_Core.DownLoadFromURL(sourceURL, 
                                        clientDestination, 
                                        fileSize);
  END URL_To_Client;
```

#### SP-070 - WEBUTIL.WRITEDATA

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.SETDATA]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Invokes the Java-layer WriteData method on an AppServerFileWriter object to write a string of data to a file on the application server. The procedure acts as a PL/SQL-to-Java bridge, passing the supplied data string to the underlying Java class and returning a Boolean indicating whether the write operation succeeded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| obj | ORA_JAVA.JOBJECT | IN |
| a0 | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the AppServerFileWriter Java object reference (obj) and the data string (a0) to be written.
- Step 2 - Create a JNI argument list sized for one argument by calling JNI.CREATE_ARG_LIST(1).
- Step 3 - Add the data string a0 to the argument list as a String argument via JNI.ADD_STRING_ARG.
- Step 4 - Invoke the Java method WriteData on the AppServerFileWriter class (oracle/forms/webutil/fileTransfer/AppServerFileWriter) using JNI.CALL_BOOLEAN_METHOD, passing the constructed argument list and specifying the method signature '(Ljava/lang/String;)Z'.
- Step 5 - Return the Boolean result received from the Java method to the caller, indicating success (TRUE) or failure (FALSE) of the write operation.

---
**Decision Points**

DP-001

Condition: The Java method WriteData on the AppServerFileWriter object returns a Boolean value.

TRUE: The data string was successfully written to the application server file; the function returns TRUE to the caller.

FALSE: The write operation failed at the Java layer; the function returns FALSE to the caller, signalling that the data was not written.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The data to be written must be supplied as a VARCHAR2 string (a0); no transformation or validation of the data content is performed within this procedure before passing it to the Java layer.
- BR-002 - A valid AppServerFileWriter Java object reference (obj) must be provided; the procedure does not instantiate or validate the object itself.
- BR-003 - The outcome of the write operation is determined solely by the Java method return value; the procedure returns this Boolean result unchanged to the caller, making the caller responsible for handling failure conditions.
- BR-004 - The JNI argument list is constructed for exactly one argument; only the single data string a0 is passed to the Java WriteData method.

---
**Implementation Logic**

```plsql
  FUNCTION WriteData(
    obj   ORA_JAVA.JOBJECT,
    a0    VARCHAR2) RETURN BOOLEAN IS
  BEGIN
    args := JNI.CREATE_ARG_LIST(1);
    JNI.ADD_STRING_ARG(args, a0);
    RETURN JNI.CALL_BOOLEAN_METHOD(FALSE, obj, 'oracle/forms/webutil/fileTransfer/AppServerFileWriter', 'WriteData', '(Ljava/lang/String;)Z', args); 
  END;
```

#### SP-071 - WEBUTIL_CORE.CUSTOMEVENTHANDLER

**Invoked From:**

- vr_veh_wise_delay_fmb.xml [Trigger: WHEN-CUSTOM-ITEM-EVENT]

---

**Screen:**

N/A

---

**Purpose**

Acts as the central dispatcher for custom item events raised by the WebUtil Java bean layer within the vr_veh_wise_delay form. When a WHEN-CUSTOM-ITEM-EVENT trigger fires, this procedure receives the event name and its serialised parameter string, extracts the data payload and multipart chunking metadata, and routes execution to the appropriate WebUtil handler routine (logging, error reporting, bean registration, host-command callback, or file-transfer notification). Events not belonging to the recognised WebUtil set are silently discarded.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| EventName | VARCHAR2 | IN |
| EventParameters | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.ERROR ([SP-027](#SP-027--WEBUTIL.ERROR)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GETNUMBER ([SP-040](#SP-040--WEBUTIL.GETNUMBER)) - WEBUTIL.pck (or .pld)
- WEBUTIL.LOG ([SP-056](#SP-056--WEBUTIL.LOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTERBEAN ([SP-062](#SP-062--WEBUTIL.REGISTERBEAN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETDATA ([SP-066](#SP-066--WEBUTIL.SETDATA)) - WEBUTIL.pck (or .pld)
- WEBUTIL.SETPROPERTY ([SP-067](#SP-067--WEBUTIL.SETPROPERTY)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Receive EventName and EventParameters from the calling WHEN-CUSTOM-ITEM-EVENT trigger.
- Step 2 - Validate that EventName is one of the five recognised WebUtil events ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT'); if not, raise the local 'unhandled' exception, which is caught and silently suppressed.
- Step 3 - Extract the data payload string from EventParameters by reading the 'WUC_DATA' attribute via the internal get_parameter_attr call, storing the result in dataPayload.
- Step 4 - Extract the multipart chunk descriptor from EventParameters by reading the 'WUC_DATA_MULTIPART' attribute, storing the result in dataMultiPart.
- Step 5 - Parse dataMultiPart using DelimStr.getNumber to derive chunkNumber (position 1) and PayloadChunks (position 2), separated by '/', establishing how many client messages compose the full payload.
- Step 6 - Route to the appropriate handler based on EventName:
  - If 'WUC_LOG_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the non-error flag (false).
  - If 'WUC_ERROR_EVENT': call WEBUTIL.LOG (WebUtil_Core.log) with dataPayload and the error flag (true).
  - If 'WUC_REGISTER': call WEBUTIL.REGISTERBEAN (registerBean) passing dataPayload to register the bean.
  - If 'WUH_CALLBACK_EVENT': convert dataPayload to a number and store it in m_lastCallback; if conversion fails, call WEBUTIL.ERROR (error) with package constant WUC_PACKAGE, error code 408, and the procedure identifier. If m_lastCallback is not null, execute the corresponding trigger stored in the m_callbacks collection; otherwise call WEBUTIL.LOG to record that no callback trigger was specified.
  - If 'WUT_TRANSFER_EVENT': call WEBUTIL.SETDATA (WebUtil_File_Transfer.setData) with dataPayload to deliver the file-transfer data, then call WEBUTIL.SETPROPERTY (WebUtil_Core.setProperty) to mark the WUT_TRANSFER_EVENT property as 'RECEIVED' on the WUT_PACKAGE.
- Step 7 - On any unhandled exception other than the local 'unhandled' exception, re-raise to the caller.

---
**Decision Points**

DP-001

Condition: EventName is not in the set ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT').

TRUE: Raise the local 'unhandled' exception; the exception handler catches it and performs no action (null), effectively discarding the unrecognised event.

FALSE: Continue processing to extract payload and route to the appropriate handler.

---

DP-002

Condition: EventName = 'WUC_LOG_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to false (informational log entry).

FALSE: Evaluate the next event condition (DP-003).

---

DP-003

Condition: EventName = 'WUC_ERROR_EVENT'.

TRUE: Call WEBUTIL.LOG with dataPayload and error flag set to true (error log entry).

FALSE: Evaluate the next event condition (DP-004).

---

DP-004

Condition: EventName = 'WUC_REGISTER'.

TRUE: Call WEBUTIL.REGISTERBEAN passing dataPayload to register the bean.

FALSE: Evaluate the next event condition (DP-005).

---

DP-005

Condition: EventName = 'WUH_CALLBACK_EVENT'.

TRUE: Attempt to convert dataPayload to a number (m_lastCallback); on INVALID_NUMBER call WEBUTIL.ERROR. If conversion succeeds and m_lastCallback is not null, execute the trigger in m_callbacks(m_lastCallback); if m_lastCallback is null, call WEBUTIL.LOG to record the missing callback trigger.

FALSE: Evaluate the next event condition (DP-006).

---

DP-006

Condition: EventName = 'WUT_TRANSFER_EVENT'.

TRUE: Call WEBUTIL.SETDATA with dataPayload, then call WEBUTIL.SETPROPERTY to set the transfer event status to 'RECEIVED'.

FALSE: No further branches; end of event routing.

---

DP-007

Condition: Conversion of dataPayload to number for 'WUH_CALLBACK_EVENT' raises INVALID_NUMBER.

TRUE: Call WEBUTIL.ERROR with WUC_PACKAGE, error code 408, and the procedure identifier 'WEBUTIL_CORE.CustomEventHandler'.

FALSE: Store the numeric value in m_lastCallback and proceed to callback execution.

---

DP-008

Condition: m_lastCallback is not null after successful numeric conversion in 'WUH_CALLBACK_EVENT' processing.

TRUE: Execute the trigger referenced by m_callbacks(m_lastCallback).

FALSE: Call WEBUTIL.LOG to record that the callback trigger for the host command was not specified.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Only events explicitly listed in the whitelist ('WUC_LOG_EVENT', 'WUC_ERROR_EVENT', 'WUC_REGISTER', 'WUH_CALLBACK_EVENT', 'WUT_TRANSFER_EVENT') are processed; all other event names are silently ignored without raising an error to the caller.
- BR-002 - Every processed event must carry a 'WUC_DATA' attribute and a 'WUC_DATA_MULTIPART' attribute within EventParameters; these are extracted unconditionally before event-specific routing begins.
- BR-003 - The multipart descriptor in 'WUC_DATA_MULTIPART' must be a slash-delimited string from which the current chunk number (position 1) and total chunk count (position 2) can be derived; this governs reassembly of multi-part payloads from the client.
- BR-004 - For 'WUH_CALLBACK_EVENT', the dataPayload must be convertible to a valid number representing a callback index; an unconvertible value is treated as an error condition and reported via WEBUTIL.ERROR with code 408.
- BR-005 - A 'WUH_CALLBACK_EVENT' with a null or unresolvable callback index must not silently succeed; the absence of a registered callback trigger is logged as an error via WEBUTIL.LOG.
- BR-006 - For 'WUT_TRANSFER_EVENT', the file-transfer data must be delivered to WEBUTIL.SETDATA before the transfer event property is marked 'RECEIVED' via WEBUTIL.SETPROPERTY, ensuring state is updated only after data is committed.
- BR-007 - Any exception other than the locally defined 'unhandled' exception is re-raised to the caller, preserving error visibility for unexpected runtime failures.

---
**Implementation Logic**

```plsql
  PROCEDURE CustomEventHandler(EventName       in VARCHAR2, 
                               EventParameters in VARCHAR2) is
    dataPayload   VARCHAR2(32767 char);   
    dataMultiPart VARCHAR2(61 char); /* should be enough! */ 
    chunkNumber   PLS_INTEGER;
    PayloadChunks PLS_INTEGER;
    dataType      PLS_INTEGER;
    unhandled     EXCEPTION;
  begin
    --Bug 2839033 - check for valid events only      
    if EventName not in ('WUC_LOG_EVENT',
                         'WUC_ERROR_EVENT', 
                         'WUC_REGISTER',
                         'WUH_CALLBACK_EVENT', 
                         'WUT_TRANSFER_EVENT') then  
      raise unhandled;
    end if;                        

    -- We're pretty much always going to need the data payload and 
    -- number of parts that make up that payload so get it now..
    get_parameter_attr(EventParameters,'WUC_DATA',dataType, dataPayload);
    get_parameter_attr(EventParameters,'WUC_DATA_MULTIPART',dataType, dataMultiPart);      
    -- split the MULTIPART info to work out how many messages from the 
    -- client are required to create the completed payload
    chunkNumber   := DelimStr.getNumber(dataMultiPart,1,true,'/');
    PayloadChunks := DelimStr.getNumber(dataMultiPart,2,true,'/');

    -- Now deal with the specific events that the client may dispatch
    -- This section will have to be extended for each new event that we 
    -- Add in order to hook the handler code for that message to the data 
    -- that is being sent - shame we can't subclass in PL/SQL :-)      
    if EventName = 'WUC_LOG_EVENT' then
        WebUtil_Core.log(dataPayload,false);
    elsif EventName = 'WUC_ERROR_EVENT' then
        WebUtil_Core.log(dataPayload,true);
    elsif EventName = 'WUC_REGISTER' then 
        registerBean(dataPayload);
    elsif EventName = 'WUH_CALLBACK_EVENT' then 
      begin 
        m_lastCallback := to_number(dataPayload);
      exception
          when INVALID_NUMBER then 
            error(WebUtil_Core.WUC_PACKAGE,408,'WEBUTIL_CORE.CustomEventHandler');
      end;
      if m_lastCallback is not null then 
          EXECUTE_TRIGGER(m_callbacks(m_lastCallback));
      else
            log('Callback trigger for host command not specified',true);
      end if;
    elsif EventName = 'WUT_TRANSFER_EVENT' then 
      WebUtil_File_Transfer.setData(dataPayload);
      WebUtil_Core.setProperty(WebUtil_Core.WUT_PACKAGE, 'WUT_TRANSFER_EVENT','RECEIVED');
    end if;
  exception
    when unhandled then
      null;
    when OTHERS then
      raise;
  end CustomEventHandler;
```

#### SP-072 - ADD_ERROR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.SAVE_FILE]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Records an error condition into the D2kwutil error stack by setting a global error flag and composing a formatted error message from the calling function name and error text. The composed message is immediately forwarded to the debug log via DEBUGLOG (SP-076), making the error available for subsequent retrieval and diagnostic reporting by any routine in the D2kwutil library.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| CallingFunction | VARCHAR2 | IN |
| SetErrorText | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Accept the calling function name (CallingFunction) and the error description text (SetErrorText) as input parameters.
- Step 2 - Set the global error flag ERROR_ENCOUNTERED to TRUE, signalling that an error condition is now active.
- Step 3 - Compose the ERROR_STACK value by concatenating CallingFunction, a colon-space separator, and the first 1,968 characters of SetErrorText, truncating any excess length to prevent overflow.
- Step 4 - Invoke DEBUGLOG (SP-076) at debug level 99, identifying the source as 'Add_Error' and passing the composed ERROR_STACK string for diagnostic logging.

---
**Decision Points**

No conditional branches exist in this routine. The error flag is set unconditionally, the error stack is composed unconditionally, and DEBUGLOG (SP-076) is called unconditionally on every invocation.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The error flag ERROR_ENCOUNTERED must be set to TRUE on every invocation; there is no conditional suppression of the error state.
- BR-002 - The error message stored in ERROR_STACK must be prefixed with the calling function name followed by a colon-space separator, ensuring traceability of the error origin.
- BR-003 - The error text contribution to ERROR_STACK is capped at 1,968 characters via SUBSTR to prevent stack overflow or storage errors.
- BR-004 - Every recorded error must be forwarded to DEBUGLOG (SP-076) at severity level 99, ensuring all errors are captured in the debug log regardless of the calling context.

---
**Implementation Logic**

```plsql

PROCEDURE Add_Error (CallingFunction in VARCHAR2, SetErrorText in VARCHAR2) is
begin 
  -- Just watch for value errors 
  ERROR_ENCOUNTERED  := TRUE;
  ERROR_STACK    := CallingFunction||': '||substr(SetErrorText,1,1968);
  Win_API_Debug.DebugLog(99,'Add_Error',ERROR_STACK);
end Add_Error;
```

#### SP-073 - ADD_EXTERNAL_ERRORS

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves and appends external (Windows API) error details to the current error stack. This is part of the D2kwutil Windows API integration library error-handling mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling routine.
- Step 2 - Perform the utility operation (error stack management, logging, or environment query) using the Windows API integration framework.
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

No conditional branches exist in this routine or decision logic cannot be verified (specification-only entry).

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it performs a direct utility operation with no configurable business rules.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

FUNCTION Add_External_Errors return varchar2 is
  iCounter   pls_integer;
  vcErrBuff  varchar2(1968);
begin 
  if tool_err.nerrors > 0 then 
    for iCounter in 1..tool_err.nerrors LOOP
      begin 
        vcErrBuff := vcErrBuff||chr(10)||tool_err.message;
      exception
        when VALUE_ERROR then 
          exit; /* String exceeds allowable buffer */
      end;
      tool_err.pop;
    end loop;
  elsif SQLERRM is not null then 
    vcErrBuff := chr(10)||SQLERRM; 
  end if;
  return vcErrBuff;
end Add_External_Errors;
```

#### SP-074 - BOOLTOCHAR

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Converts a PL/SQL BOOLEAN value to its VARCHAR2 character representation, returning the literal string 'TRUE' or 'FALSE'. The function serves as a utility helper within the D2kwutil Windows API integration library, enabling BOOLEAN values to be embedded in debug log messages and string contexts where a BOOLEAN type cannot be used directly. It is called by multiple D2KWUTIL stored procedures including CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, and READ_REGISTRY.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| ThisBoolean | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Receive the BOOLEAN input parameter ThisBoolean from the calling routine.
- Step 2 - Evaluate the value of ThisBoolean using a conditional check.
- Step 3 - If ThisBoolean evaluates to TRUE, return the VARCHAR2 literal 'TRUE' to the caller.
- Step 4 - If ThisBoolean evaluates to FALSE (or NULL resolves to the ELSE branch), return the VARCHAR2 literal 'FALSE' to the caller.

---
**Decision Points**

DP-001

Condition:
ThisBoolean IS TRUE

TRUE:
The function returns the VARCHAR2 string 'TRUE'.

FALSE:
The function returns the VARCHAR2 string 'FALSE'.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function accepts exactly one BOOLEAN input parameter and always returns a non-null VARCHAR2 value; no null or indeterminate output is produced.
- BR-002 - The only permissible return values are the exact string literals 'TRUE' and 'FALSE'; no other representations (e.g. '1'/'0', 'Y'/'N') are used.
- BR-003 - The function has no dependencies on other internal routines, database tables, or external packages; it performs a self-contained conditional mapping with no side effects.
- BR-004 - This function must be called wherever a BOOLEAN value needs to be expressed as a character string within the D2KWUTIL Windows API integration library routines (CHOOSEFILE, GET_ACTIVE_WINDOW, GET_ENVIRONMENT_STRING, GET_TEMP_DIRECTORY, GET_WINDOWS_DIRECTORY, READ_REGISTRY).

---
**Implementation Logic**

```plsql

  
  FUNCTION  BoolToChar(ThisBoolean IN BOOLEAN) return VARCHAR2 is
  begin
  	if ThisBoolean then 
  		RETURN 'TRUE';
  	else
  	    RETURN 'FALSE';
  	end if;
  end BoolToChar;

END;

PACKAGE WIN_API_DIALOG IS

/*-------------------------------------------------------------------------*\
 * WIN_API_DIALOG ->   This package is concerned with Displaying Common
 *      dialogs
 * Contents:
 *    Open_File    -> Open File Dialog
 *    Save_File    -> Save File Dialog
 *    Select_Printer    -> Printer Selection Dialog
 *    Choose_Font       -> Display the Font Selection Dialog
 *    Choose_Color      -> Display the Color Selection Dialog
 * Dependancies:
 *    WIN_API_ENVIRONMENT
 *    WIN_API
 *    WIN_API_DEBUG
\*-------------------------------------------------------------------------*/ 

/*-------------------------------------------------------------------------*\
 * Open_File        -> Displays the standard Open File dialog
 * Arguments: 
 *  Title           -> The Title for the Dialog Box
 *                     (Default -> 'Open File')
 *  StartDirectory  -> Where the dialog should start from
 *                     this should be in the format 'C:\TEMP'
 *                     (Default -> Windows Directory)
 *  FileFilter      ->  Restrict the list of files. The filter string 
 *                      should be in the format:
 *                      '<Description>|<filename>.<Extension>|'
 *                      typically this would be something like
 *                      'All files(*.*)|*.*|' or 'Text files(*.txt)|*.txt|'
 *                      "All Files" is the Default
 *  Modal           ->  Should the dialog be modal with respect to the 
 *                      application? 
 *                      default = TRUE
 *  AdvancedFlags   ->  (See list in WIN_API header) This option allows
 *                      you to change the attributes of the Open File 
 *                      dialog.  Here are some of the Flags that might
 *                      be of interest:
 *                      OFN_HIDEREADONLY  Hides the Read Only check box.
 *                      OFN_NONETWORKBUTTON  Hides the Network Button
 *                      OFN_EXPLORER    Display an Explorer style 
 *                        Dialog rather than the conventional one.
 *                      See your Microsoft docmentation for details on 
 *                      each flag.
 *                      To Set the Advanced_Flags varaible, just add the 
 *                      required flags together.  The default is:
 *                      WIN_API.OFN_PATHMUSTEXIST + WIN_API.OFN_FILEMUSTEXIST +
 *                      WIN_API.OFN_HIDEREADONLY + WIN_API.OFN_NOCHANGEDIR 
 *  RaiseExceptions ->  TRUE of FALSE(Default) If set to true, then if the 
 *                      command is not successful (e.g no filename is  
 *                      returned) then the explicit exception
 *                      NO_DATA_FOUND will be raised.
 *        
 * Returns:
 *  Path and name of the selected file
\*-------------------------------------------------------------------------*/
```

#### SP-075 - CLEAN_ERROR_STACK

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Clears all accumulated errors from the D2kwutil / Windows API error stack before a new operation. This is part of the D2kwutil Windows API integration library error-handling mechanism.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

No input parameters.

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

No internal or external dependencies detected.

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling routine.
- Step 2 - Perform the utility operation (error stack management, logging, or environment query) using the Windows API integration framework.
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

No conditional branches exist in this routine or decision logic cannot be verified (specification-only entry).

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it performs a direct utility operation with no configurable business rules.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

PROCEDURE Clean_Error_Stack is 
begin 
  -- just empty the variables
  ERROR_ENCOUNTERED  := FALSE;
  ERROR_STACK        := NULL;
end Clean_Error_Stack;
```

#### SP-076 - DEBUGLOG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: ADD_ERROR]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: REGISTER_FUNCTION_CALL]
- D2kwutil.pld [StoredProcedure: SETDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Writes a formatted debug message to the active debug output channel (Windows debugger via WINDEBUG or a flat log file) at a specified verbosity level. The routine is a core utility within the D2kwutil library, called by numerous internal procedures to record diagnostic information during execution. It relies on SETDEBUG to configure or switch the debug channel and on WINDEBUG (via win_api_debug.WinDebug) to post messages to the Windows debug output stream.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugLevel | PLS_INTEGER | IN |
| LoggingCall | VARCHAR2 | IN |
| LogString | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- SETDEBUG ([SP-082](#SP-082--SETDEBUG)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WINDEBUG ([SP-085](#SP-085--WINDEBUG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Evaluate the global debug state (iDebugState). If debugging is disabled (iDebugState = 0) or paused (bDebugPaused = TRUE), exit immediately without writing any output.
- Step 2 - Compare the requested DebugLevel against the active threshold (iDebugLevel). If DebugLevel exceeds iDebugLevel, exit immediately; the message is below the current verbosity threshold.
- Step 3 - If the bDebugTimeStamp flag is set, format the current system time (HH24:MI:SS) and append a '>' separator to use as a date-stamp prefix.
- Step 4 - Construct the full debug string: prefix the two-digit left-padded DebugLevel in angle brackets, append the optional timestamp, right-pad the LoggingCall label to 30 characters, then append as much of LogString as fits within the 2,000-character total limit.
- Step 5 - Determine the output channel. If iDebugState = 2 (Windows debugger mode), check whether DEBUG_API_ENABLED is TRUE.
- Step 6 - If DEBUG_API_ENABLED is TRUE under debugger mode, call WINDEBUG (win_api_debug.WinDebug) to post the formatted string to the Windows debug output stream.
- Step 7 - If DEBUG_API_ENABLED is FALSE under debugger mode, the Windows API is unavailable. Call SETDEBUG to switch the channel to file logging (using vcDebugFile, defaulting to 'd2kwutil.log'), log a channel-switch notice by recursively calling DEBUGLOG, re-log the original message, and set bDebugType2Required to TRUE to remember that debugger mode was requested but unavailable.
- Step 8 - If iDebugState is not 2 (file logging mode), check whether bDebugType2Required is TRUE and DEBUG_API_ENABLED has since become TRUE. If so, call SETDEBUG to reinstate debugger-mode logging, log a restoration notice recursively, reset bDebugType2Required to FALSE, and re-log the original message.
- Step 9 - If no channel-switch condition applies, open the log file in append mode using TEXT_IO, write the formatted debug string as a new line, and close the file.
- Step 10 - If any exception occurs during the above steps, suppress it silently and set iDebugState to 0 to disable further debug logging, preventing debug failures from disrupting the calling application.

---
**Decision Points**

DP-001

Condition:
iDebugState = 0

TRUE:
Debugging is disabled; procedure exits immediately with no output.

FALSE:
Proceed to check whether debugging is paused (DP-002).

---

DP-002

Condition:
bDebugPaused = TRUE

TRUE:
Debugging is temporarily paused; procedure exits immediately with no output.

FALSE:
Proceed to evaluate the verbosity threshold (DP-003).

---

DP-003

Condition:
DebugLevel > iDebugLevel

TRUE:
The requested message is below the active verbosity threshold; procedure exits immediately with no output.

FALSE:
Message qualifies for output; proceed to format the debug string.

---

DP-004

Condition:
bDebugTimeStamp = TRUE

TRUE:
Format the current system time (HH24:MI:SS) and include it as a prefix in the debug string.

FALSE:
No timestamp is prepended; vcDateStamp remains empty.

---

DP-005

Condition:
iDebugState = 2 (Windows debugger mode requested)

TRUE:
Attempt to write to the Windows debug output stream; evaluate API availability (DP-006).

FALSE:
Write to the log file; evaluate whether a deferred channel-switch back to debugger mode is pending (DP-007).

---

DP-006

Condition:
DEBUG_API_ENABLED = TRUE (within debugger-mode branch)

TRUE:
Call WINDEBUG to post the formatted string to the Windows debug output stream.

FALSE:
Windows API is unavailable; call SETDEBUG to switch to file logging, log a channel-switch notice, re-log the original message, and set bDebugType2Required to TRUE.

---

DP-007

Condition:
bDebugType2Required = TRUE AND DEBUG_API_ENABLED = TRUE (within file-logging branch)

TRUE:
The Windows API has become available again; call SETDEBUG to reinstate debugger-mode logging, log a restoration notice, reset bDebugType2Required to FALSE, and re-log the original message.

FALSE:
No pending channel switch; open the log file in append mode, write the formatted string, and close the file.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - Debug output is suppressed entirely when iDebugState is 0 (disabled) or bDebugPaused is TRUE; no log entry is created under either condition.
- BR-002 - A message is only written when its DebugLevel does not exceed the active verbosity threshold iDebugLevel; higher DebugLevel values represent lower-priority messages that are filtered out at lower threshold settings.
- BR-003 - The formatted debug string must not exceed 2,000 characters; LogString is truncated to fit within this limit after the fixed prefix (level indicator, optional timestamp, and padded call label) is accounted for.
- BR-004 - The LoggingCall label is always right-padded to exactly 30 characters in the output string, ensuring columnar alignment across log entries.
- BR-005 - When iDebugState = 2 and the Windows API (WINDEBUG) is unavailable, the routine automatically falls back to file logging by invoking SETDEBUG, records the channel-switch event, and sets bDebugType2Required to TRUE so that the transition back to debugger mode can be made as soon as the API becomes available.
- BR-006 - When file logging is active and bDebugType2Required is TRUE, the routine monitors DEBUG_API_ENABLED on each call; once the API is available, it invokes SETDEBUG to restore debugger-mode output without requiring external intervention.
- BR-007 - Any exception raised during debug logging is silently suppressed and iDebugState is set to 0, ensuring that debug instrumentation failures never propagate to or disrupt the calling business logic.

---
**Implementation Logic**

```plsql
   
PROCEDURE DebugLog (DebugLevel  IN PLS_INTEGER, 
                    LoggingCall IN VARCHAR2, 
                    LogString   IN VARCHAR2) is
 vcDateStamp   VARCHAR2(10);
 vcDebugString VARCHAR2(2000);
 hFile         TEXT_IO.FILE_TYPE;
begin
  if iDebugState = 0 then 
  	NULL;
  elsif bDebugPaused then 
  	NULL;
  elsif DebugLevel > iDebugLevel then 
  	NULL;
  else
  	-- Sort out the Datestamp	
  	if bDebugTimeStamp then 
  		vcDateStamp := to_char(SYSDATE,'HH24:MI:SS')||'> ';
  	end if;
  
  	-- Construct the final String
  	vcDebugString := '<'||lpad(to_char(DebugLevel),2,0)||'> '||vcDateStamp||rpad(LoggingCall||':',30);
    vcDebugString := vcDebugString||substr(LogString,1,(2000-length(vcDebugString)));
  
  	if iDebugState = 2 then
  		if DEBUG_API_ENABLED then 
  	   		win_api_debug.WinDebug(vcDebugString);
  		else
  			-- Can't use API calls if the API functions aren't there
	  		-- So Switch to File Logging to d2kwut$.log
	  		SetDebug(1,nvl(vcDebugFile,'d2kwutil.log'),iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Unable to Log to Debugger Switching to File');
			DebugLog(DebugLevel,LoggingCall,LogString);	  		
	  		bDebugType2Required := TRUE;
	  	end if;
  	else
     	if bDebugType2Required and DEBUG_API_ENABLED then
	     	-- API now Available - Reinstate Debugging to Debugger
	  		SetDebug(2,vcDebugFile,iDebugLevel,bDebugTimeStamp);
	  		DebugLog(0,'DebugLog','Restoring Logging to Debugger');
	  		bDebugType2Required := FALSE;
	  		DebugLog(Debuglevel,LoggingCall,LogString);
	
	  	else
		 	hFile := TEXT_IO.FOPEN(vcDebugFile,'A');
		 	TEXT_IO.PUT_LINE(hFile,vcDebugString);
		 	TEXT_IO.FCLOSE(hFile);
		end if;
  	end if;
  end if;
 exception
  	-- Don't let the debugging cause Problems of it's own
  	when others then 
  		iDebugState := 0;
 end DebugLog;
```

#### SP-077 - GET_ENVIRONMENT_STRING

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the value of a named environment variable from the Oracle Forms client operating system by delegating to the D2KWUTIL Windows API integration library (D2KWUTIL.D2KWUTIL_GETDOSENV). The function logs entry arguments and results via DEBUGLOG, manages the error stack, and returns the resolved variable value as a VARCHAR2 string to the caller (WEBUTIL.GETVAR). If the variable cannot be resolved, it either returns NULL or raises NO_DATA_FOUND depending on the RaiseExceptions flag.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| VariableName | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETDOSENV ([SP-006](#SP-006--D2KWUTIL.D2KWUTIL_GETDOSENV)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the incoming arguments (VariableName and the boolean RaiseExceptions flag, converted to a character representation via BOOLTOCHAR) at debug level 99 using DEBUGLOG.
- Step 2 - Clear the error stack by calling CLEAN_ERROR_STACK to ensure no stale errors influence subsequent processing.
- Step 3 - Check whether the Windows API integration layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the external function call for D2KWUTIL.D2KWUTIL_GETDOSENV via REGISTER_FUNCTION_CALL, specifying the function name and its parameter signature ('LONG','*CHAR,*CHAR,LONG').
- Step 5 - Prepare the input buffer by wrapping VariableName in percent signs (e.g. '%VariableName%') and initialise a 512-character output buffer padded with null characters.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_GETDOSENV with the function handle, the formatted variable name, the output buffer, and the buffer length; capture the integer return code (iRC) representing the length of the resolved value.
- Step 7 - Log the result (value length and resolved value) at debug level 99 using DEBUGLOG.
- Step 8 - Evaluate the return code and output buffer: if iRC equals 0 or the output buffer is unchanged (equals the input pattern), record an error via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 9 - If the variable was resolved successfully, return the populated output buffer (vcBuff2) to the caller.
- Step 10 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the no-API error via ADD_ERROR then re-raise; for all other exceptions, log a generic error combined with any external error details via ADD_ERROR and ADD_EXTERNAL_ERRORS, then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Proceed to register the external function call and invoke D2KWUTIL.D2KWUTIL_GETDOSENV to resolve the environment variable.

FALSE:
Raise the WIN_API.NOT_AVAILABLE exception, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
The return code (iRC) equals 0 OR the output buffer is unchanged (vcBuff2 = vcBuff1), indicating that the environment variable could not be resolved.

TRUE:
Log the failure via ADD_ERROR. Evaluate RaiseExceptions (see DP-003) to determine whether to raise NO_DATA_FOUND or return NULL.

FALSE:
Return the resolved environment variable value (vcBuff2) to the caller.

---

DP-003

Condition:
RaiseExceptions input parameter is TRUE (evaluated only when DP-002 is TRUE).

TRUE:
Raise the NO_DATA_FOUND exception, propagating the failure to the caller.

FALSE:
Return NULL to the caller, suppressing the exception.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function can only execute the environment variable lookup when the Windows API integration layer is active (WIN_API.API_ENABLED). If the layer is unavailable, the function must raise WIN_API.NOT_AVAILABLE and record the no-API error via ADD_ERROR; silent failure is not permitted in this path.
- BR-002 - The environment variable name must be submitted to D2KWUTIL.D2KWUTIL_GETDOSENV enclosed in percent signs (e.g. '%VariableName%'); this formatting is mandatory for the underlying DOS environment expansion to function correctly.
- BR-003 - A return code of 0 from D2KWUTIL.D2KWUTIL_GETDOSENV, or an output buffer that is identical to the formatted input pattern, is treated as a failed lookup; the function must not return an unresolved or empty buffer as a valid result.
- BR-004 - The caller controls error propagation behaviour through the RaiseExceptions flag. When FALSE (the default), a failed lookup returns NULL; when TRUE, a failed lookup raises NO_DATA_FOUND, allowing the calling routine to implement its own exception handling.
- BR-005 - All entry arguments and resolution results must be written to the debug log via DEBUGLOG at level 99 to support traceability of environment variable lookups at runtime.
- BR-006 - The error stack must be cleared at the start of each invocation via CLEAN_ERROR_STACK to prevent errors from prior calls contaminating the current operation's error context.

---
**Implementation Logic**

```plsql

FUNCTION Get_Environment_string (  VariableName      IN  VARCHAR2,
                                   RaiseExceptions   IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  iBuff1    PLS_INTEGER;
  iRC        PLS_INTEGER;
begin 
  Win_api_debug.DebugLog(99,'Get_Environment_String','Args: VariableName="'||VariableName||'", RaiseExceptions='||win_api_debug.BoolToChar(RaiseExceptions));
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iGetDOSEnv,'d2kwutil_GetDOSEnv','LONG','*CHAR,*CHAR,LONG');
    vcBuff1    := '%'||VariableName||'%';
    vcBuff2    := RPAD(' ',512,CHR(0));
    iBuff1    := 512;
    iRC   := d2kwutil_GetDOSEnv(win_api.FunctionHandle(iGetDOSEnv),vcBuff1,vcBuff2,iBuff1);
    Win_api_debug.DebugLog(99,'Get_Environment_String','Result: Value Length='||to_char(iRC)||', Value='||vcBuff2);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0  or vcBuff2 = vcBuff1 then 
    Win_API.Add_error('Get_Environment_String','Unable to get the value of the variable '||VariableName);
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return vcBuff2;
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Environment_String',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Environment_String',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Environment_String;
```

#### SP-078 - GET_TEMP_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Returns the path to the temporary files directory on the client machine by invoking the D2KWUTIL Windows API function D2KWUTIL_WINDIR. The function cleans the error stack before execution, logs entry and result via DEBUGLOG, strips any trailing directory separator from the retrieved path, and optionally raises an exception if no value is returned, depending on the RaiseExceptions flag supplied by the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-083](#SP-083--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the entry point and the value of the RaiseExceptions input parameter using DEBUGLOG.
- Step 2 - Clear the error stack by calling CLEAN_ERROR_STACK to ensure no stale errors influence subsequent processing.
- Step 3 - Check whether the Windows API is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the Windows API function call for the temporary-directory lookup using REGISTER_FUNCTION_CALL, binding the internal handle iTmpDir to the 'd2kwutil_TmpDir' entry point with the expected parameter signature.
- Step 5 - Initialise a 512-character output buffer padded with null characters to receive the directory path from the API.
- Step 6 - Invoke D2KWUTIL.D2KWUTIL_WINDIR, passing the registered function handle, the output buffer, and the buffer length (512), capturing the integer return code in iRC.
- Step 7 - Log the raw return code and the raw buffer contents using DEBUGLOG.
- Step 8 - Evaluate the return code: if iRC = 0 (no value returned), record the failure via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 9 - If iRC is non-zero, pass the populated buffer to STRIPDIRSEP to remove any trailing directory separator and return the cleaned path to the caller.
- Step 10 - In the exception block, re-raise NO_DATA_FOUND as-is; handle WIN_API.NOT_AVAILABLE by logging the no-API message via ADD_ERROR and re-raising; handle all other exceptions by logging via ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raising.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the Windows API integration layer is available at runtime.

TRUE:
Proceed to register the function call, allocate the buffer, and invoke D2KWUTIL.D2KWUTIL_WINDIR to retrieve the temporary directory path.

FALSE:
Raise WIN_API.NOT_AVAILABLE, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 - D2KWUTIL.D2KWUTIL_WINDIR returned a zero result code, indicating no directory value was retrieved.

TRUE:
Log the failure using ADD_ERROR and branch on the RaiseExceptions flag (see DP-003).

FALSE:
Strip the trailing directory separator from the buffer using STRIPDIRSEP and return the resulting path to the caller.

---

DP-003

Condition:
RaiseExceptions is TRUE - the caller has requested exception propagation when no value is returned (evaluated only when iRC = 0).

TRUE:
Raise NO_DATA_FOUND, which is immediately re-raised by the exception handler.

FALSE:
Return NULL to the caller silently.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must clean the error stack (CLEAN_ERROR_STACK) before invoking the Windows API, ensuring that error state from prior calls does not contaminate the result of this operation.
- BR-002 - The Windows API integration layer must be available (WIN_API.API_ENABLED) before any attempt is made to retrieve the temporary directory; if it is not available, the function raises WIN_API.NOT_AVAILABLE and records the no-API error message via ADD_ERROR.
- BR-003 - The caller controls error-propagation behaviour through the RaiseExceptions parameter: when TRUE, a failure to retrieve a directory path results in a NO_DATA_FOUND exception; when FALSE, NULL is returned silently, allowing the caller to handle the absence of a value without exception handling.
- BR-004 - The raw directory path returned by D2KWUTIL.D2KWUTIL_WINDIR must be normalised by STRIPDIRSEP before being returned, ensuring a consistent path format without a trailing directory separator.
- BR-005 - All entry, result, and error conditions must be recorded through DEBUGLOG (at debug level 99), providing a traceable audit of the API call inputs and outputs.
- BR-006 - Any unhandled exception is enriched with external error detail via ADD_EXTERNAL_ERRORS before being re-raised, ensuring complete diagnostic information is available to the calling context.

---
**Implementation Logic**

```plsql

FUNCTION Get_Temp_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iTmpDir,'d2kwutil_TmpDir','INT','*CHAR,INT');
    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iTmpDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Temp_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Temp_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Temp_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Temp_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Temp_Directory;
```

#### SP-079 - GET_WINDOWS_DIRECTORY

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Retrieves the Windows directory path from the Oracle Forms client machine by invoking the D2KWUTIL Windows API wrapper (D2KWUTIL.D2KWUTIL_WINDIR). The function returns the directory path as a VARCHAR2 string with any trailing directory separator stripped, or NULL if the API call returns no value and exception raising is suppressed. It is a utility function supporting client-side environment resolution within the D2KWUTIL integration framework.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_WINDIR ([SP-008](#SP-008--D2KWUTIL.D2KWUTIL_WINDIR)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name
- STRIPDIRSEP ([SP-083](#SP-083--STRIPDIRSEP)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log entry into the function, recording the value of the RaiseExceptions input parameter via DEBUGLOG (Win_API_Debug.DebugLog) and BOOLTOCHAR (win_api_debug.booltochar).
- Step 2 - Clear the error stack by calling CLEAN_ERROR_STACK (WIN_API.Clean_Error_Stack) to ensure no stale error state from prior calls influences this execution.
- Step 3 - Initialise the return-code variable iRC to 0.
- Step 4 - Check whether the Windows API is available (WIN_API.API_ENABLED). If available, proceed to Step 5; otherwise raise the WIN_API.NOT_AVAILABLE exception, which is handled in the exception block.
- Step 5 - Register the external function call for D2KWUTIL_WINDIR using REGISTER_FUNCTION_CALL (win_api.Register_function_call), binding the function handle iWinDir with its signature (INT return, *CHAR and INT arguments).
- Step 6 - Initialise a 512-character buffer (vcBuff1) padded with null characters to receive the directory path.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_WINDIR (d2kwutil_WinDir) via the registered function handle, passing the buffer and its length; capture the integer return code in iRC.
- Step 8 - Log the outcome, recording the return code and the raw buffer value via DEBUGLOG.
- Step 9 - Evaluate the return code iRC. If iRC = 0, the API returned no value; log the failure via ADD_ERROR and either raise NO_DATA_FOUND (when RaiseExceptions is TRUE) or return NULL (when RaiseExceptions is FALSE).
- Step 10 - If iRC is non-zero, strip any trailing directory separator from the buffer using STRIPDIRSEP (WIN_API.StripDirSep) and return the cleaned path to the caller.
- Step 11 - In the exception block: re-raise NO_DATA_FOUND as-is; for WIN_API.NOT_AVAILABLE, log the error via ADD_ERROR then re-raise; for all other exceptions, log a combined error message via ADD_ERROR and ADD_EXTERNAL_ERRORS then re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED - the Windows API integration layer is available on the client.

TRUE:
Register the external function, invoke D2KWUTIL.D2KWUTIL_WINDIR, and proceed to evaluate the return code.

FALSE:
Raise WIN_API.NOT_AVAILABLE, which is caught in the exception block, logged via ADD_ERROR, and re-raised to the caller.

---

DP-002

Condition:
iRC = 0 - the D2KWUTIL_WINDIR API call returned a zero return code, indicating no directory value was obtained.

TRUE:
Log the failure via ADD_ERROR ('No Value Returned') and evaluate RaiseExceptions (see DP-003).

FALSE:
Strip the trailing directory separator from the buffer using STRIPDIRSEP and return the resulting path.

---

DP-003

Condition:
RaiseExceptions is TRUE - the caller has requested that a missing result be surfaced as an exception.

TRUE:
Raise NO_DATA_FOUND, which propagates to the caller.

FALSE:
Return NULL silently to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The function must clear the error stack at the start of every invocation to prevent stale error state from prior calls affecting error reporting for this call.
- BR-002 - The Windows API integration layer must be active (WIN_API.API_ENABLED) before any attempt is made to invoke D2KWUTIL.D2KWUTIL_WINDIR; if the API is unavailable the function must not silently return and must propagate WIN_API.NOT_AVAILABLE to the caller.
- BR-003 - A zero return code from D2KWUTIL.D2KWUTIL_WINDIR is treated as a failure condition (no directory value returned) and must be recorded via ADD_ERROR regardless of whether an exception is subsequently raised.
- BR-004 - The caller controls error propagation behaviour: when RaiseExceptions is TRUE a missing result raises NO_DATA_FOUND; when FALSE the function returns NULL, allowing the caller to handle the absence of a value without exception handling.
- BR-005 - The returned directory path must always have its trailing directory separator removed via STRIPDIRSEP before being returned to the caller, ensuring a consistent path format.
- BR-006 - All exception paths (NO_DATA_FOUND, WIN_API.NOT_AVAILABLE, and unhandled exceptions) must be logged via ADD_ERROR or ADD_EXTERNAL_ERRORS before re-raising, ensuring the error stack is populated for upstream diagnostics.
- BR-007 - Diagnostic logging via DEBUGLOG must capture both the input parameter (RaiseExceptions, rendered by BOOLTOCHAR) on entry and the raw API result (return code and buffer value) after the D2KWUTIL.D2KWUTIL_WINDIR call, to support runtime tracing.

---
**Implementation Logic**

```plsql

FUNCTION Get_Windows_Directory (RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  iRC        PLS_INTEGER;
begin 
  Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Args: RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	 	
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iWinDir,'d2kwutil_WinDir','INT','*CHAR,INT');

    vcBuff1    := RPAD(' ',512,CHR(0));
    iRC   := d2kwutil_WinDir(win_api.FunctionHandle(iWinDir),vcBuff1,512);
    Win_API_Debug.DebugLog(99,'Get_Windows_Directory','Result:  RC='||to_char(iRC)||', vcBuff1="'||vcBuff1||'"');	      
  else
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = 0 then 
    Win_API.Add_error('Get_Windows_Directory','No Value Returned');
    if RaiseExceptions then
      raise NO_DATA_FOUND;
    else
      return NULL;
    end if;
  else
    return WIN_API.StripDirSep(vcBuff1);
  end if;
exception
  when NO_DATA_FOUND then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Get_Windows_Directory',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Get_Windows_Directory',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Get_Windows_Directory;
```

#### SP-080 - READ_REGISTRY

**Invoked From:**

- webutil.pld [StoredProcedure: WEBUTIL.GETVAR]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Reads a string value from the Windows registry on the Oracle Forms client machine and returns it to the caller. The function resolves the registry root hive from the supplied path, delegates the low-level read to D2KWUTIL.D2KWUTIL_GETREGKEY, and optionally raises a PL/SQL exception instead of returning NULL when the read fails. Debug progress and argument values are written to the diagnostic log via DEBUGLOG throughout execution.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| RegPath | VARCHAR2 | IN |
| RegEntry | VARCHAR2 | IN |
| RaiseExceptions | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- BOOLTOCHAR ([SP-074](#SP-074--BOOLTOCHAR)) - matched by member name
- CLEAN_ERROR_STACK ([SP-075](#SP-075--CLEAN_ERROR_STACK)) - matched by member name
- D2KWUTIL.D2KWUTIL_GETREGKEY ([SP-007](#SP-007--D2KWUTIL.D2KWUTIL_GETREGKEY)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Log the incoming arguments (RegPath, RegEntry, RaiseExceptions) to the diagnostic log using DEBUGLOG before any processing begins.
- Step 2 - Clear the error stack by calling CLEAN_ERROR_STACK to ensure no stale errors from prior calls affect this execution.
- Step 3 - Check whether the Windows API layer is available (WIN_API.API_ENABLED). If it is not available, raise the WIN_API.NOT_AVAILABLE exception immediately.
- Step 4 - Register the D2KWUTIL.D2KWUTIL_GETREGKEY function handle via REGISTER_FUNCTION_CALL, binding the external DLL entry point for the registry read operation.
- Step 5 - Parse the leading segment of RegPath (everything before the first backslash) to identify the registry root hive and map it to the corresponding integer constant (0 = HKEY_LOCAL_MACHINE, 1 = HKEY_CLASSES_ROOT, 2 = HKEY_CURRENT_USER, 3 = HKEY_USERS, 4 = HKEY_CURRENT_CONFIG). If the root segment does not match any known hive, record an error via ADD_ERROR and, if RaiseExceptions is TRUE, raise NO_DATA_FOUND.
- Step 6 - Prepare the call buffers: extract the sub-path (everything after the first backslash) into vcBuff1, place RegEntry into vcBuff2, initialise the 2000-byte result buffer vcBuff3, and set the environment-variable expansion flag (iBuff3) based on WIN_API.COMPAT_EXPAND_REG_VALUES; log a compatibility message via DEBUGLOG if expansion is suppressed.
- Step 7 - Invoke D2KWUTIL.D2KWUTIL_GETREGKEY with the function handle, root integer, sub-path, entry name, result buffer, buffer length, and expansion flag. Capture the integer return code in iRC.
- Step 8 - Log the return code and the raw result buffer value via DEBUGLOG.
- Step 9 - Evaluate iRC for error conditions: -1 (entry not found), -2 (unsupported data type), -3 (value exceeds buffer length), -4 (environment string expansion failure). For each error condition, record a descriptive message via ADD_ERROR, then either return NULL or raise the appropriate exception (NO_DATA_FOUND or VALUE_ERROR) depending on the RaiseExceptions flag.
- Step 10 - If iRC indicates success (no negative error code), return vcBuff3 containing the retrieved registry value string.
- Step 11 - In the exception block, re-raise NO_DATA_FOUND and VALUE_ERROR as-is; for WIN_API.NOT_AVAILABLE record the no-API error message via ADD_ERROR then re-raise; for all other exceptions record an error via ADD_ERROR combined with ADD_EXTERNAL_ERRORS and re-raise.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED is TRUE.

TRUE:
Processing continues; REGISTER_FUNCTION_CALL is invoked and the registry read proceeds.

FALSE:
WIN_API.NOT_AVAILABLE is raised immediately, bypassing all registry logic.

---

DP-002

Condition:
The root segment of RegPath matches one of the five known hive names (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG).

TRUE:
The corresponding integer constant is assigned to iBuff1 and processing continues.

FALSE:
ADD_ERROR is called with an 'Invalid Registry Key' message. If RaiseExceptions is TRUE, NO_DATA_FOUND is raised; otherwise execution falls through.

---

DP-003

Condition:
WIN_API.COMPAT_EXPAND_REG_VALUES is TRUE.

TRUE:
iBuff3 is set to 0, allowing the DLL to expand environment variable references within the registry value.

FALSE:
iBuff3 is set to 1, suppressing environment variable expansion; a compatibility warning is written via DEBUGLOG.

---

DP-004

Condition:
iRC returned from D2KWUTIL.D2KWUTIL_GETREGKEY equals -1 (entry not found).

TRUE:
ADD_ERROR is called. If RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.

FALSE:
Evaluation continues to the next return-code check.

---

DP-005

Condition:
iRC equals -2 (unsupported registry data type).

TRUE:
ADD_ERROR is called. If RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.

FALSE:
Evaluation continues to the next return-code check.

---

DP-006

Condition:
iRC equals -3 (registry value exceeds the 2000-byte buffer).

TRUE:
ADD_ERROR is called. If RaiseExceptions is FALSE, NULL is returned; if TRUE, VALUE_ERROR is raised.

FALSE:
Evaluation continues to the next return-code check.

---

DP-007

Condition:
iRC equals -4 (environment string expansion failed).

TRUE:
ADD_ERROR is called. If RaiseExceptions is FALSE, NULL is returned; if TRUE, NO_DATA_FOUND is raised.

FALSE:
No error condition applies; the retrieved value in vcBuff3 is returned to the caller.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The Windows API layer must be active (WIN_API.API_ENABLED) before any registry access is attempted; if it is unavailable the function raises WIN_API.NOT_AVAILABLE and no registry read is performed.
- BR-002 - The registry root hive must be one of the five supported constants (HKEY_LOCAL_MACHINE, HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_USERS, HKEY_CURRENT_CONFIG); any other root value is treated as an invalid key and an error is recorded.
- BR-003 - The result buffer is fixed at 2000 bytes; registry values longer than this limit produce return code -3, and the function either returns NULL or raises VALUE_ERROR depending on the RaiseExceptions flag.
- BR-004 - Environment variable expansion within registry values is controlled by the WIN_API.COMPAT_EXPAND_REG_VALUES compatibility flag; when the flag is FALSE expansion is suppressed and the raw value string is returned.
- BR-005 - The RaiseExceptions parameter governs error-handling behaviour for all retrieval failures (entry not found, unsupported type, buffer overflow, expansion failure): when FALSE the function returns NULL and records the error; when TRUE it raises the appropriate PL/SQL exception.
- BR-006 - All entry and exit points, argument values, and return codes are written to the diagnostic log via DEBUGLOG at verbosity level 99, providing a full audit trail of each registry read attempt.
- BR-007 - Errors encountered during execution are recorded through ADD_ERROR; unhandled exceptions additionally incorporate external error detail via ADD_EXTERNAL_ERRORS before being re-raised to the caller.

---
**Implementation Logic**

```plsql

FUNCTION Read_Registry (RegPath         IN  VARCHAR2,
                        RegEntry        IN  VARCHAR2, 
                        RaiseExceptions IN  BOOLEAN DEFAULT FALSE)  RETURN VARCHAR2 is
  vcBuff1    VARCHAR2(512);
  vcBuff2    VARCHAR2(512);
  vcBuff3    VARCHAR2(2000);
  vcBuff4    VARCHAR2(512);
  vcBuff5    VARCHAR2(512);                        
  vcRoot     VARCHAR2(20);
  iBuff1     PLS_INTEGER;
  iBuff2     PLS_INTEGER;
  iBuff3		 PLS_INTEGER;
  iRC        PLS_INTEGER;
begin
  Win_API_Debug.DebugLog(99,'Read_Registry','Args: RegPath="'||RegPath||'", RegEntry="'||RegEntry||'", RaiseExceptions='||win_api_debug.booltochar(RaiseExceptions));	  
  WIN_API.Clean_Error_Stack;
  iRC  := 0;
  if Win_API.API_ENABLED then 
    win_api.Register_function_call(iGetRegKey,'d2kwutil_GetRegKey','INT','INT,*CHAR,*CHAR,*CHAR,INT,INT');  
    -- Which Root?
    vcRoot  := upper(substr(RegPath,1,instr(RegPath,'\')-1));
    if      vcRoot =  'HKEY_LOCAL_MACHINE' then 
      iBuff1 := 0;
    elsif   vcRoot =  'HKEY_CLASSES_ROOT' then 
      iBuff1 := 1;
    elsif   vcRoot =  'HKEY_CURRENT_USER' then 
      iBuff1 := 2;
    elsif   vcRoot =  'HKEY_USERS' then
      iBuff1 := 3;
    elsif   vcRoot =  'HKEY_CURRENT_CONFIG' then
      iBuff1 := 4;      
    else
      WIN_API.Add_error('Read_Registry','Invalid Registry Key '||RegPath);
      if  RaiseExceptions then
        raise NO_DATA_FOUND;
      end if;  
    end if;

    iBuff2     := 2000; /* Length of buffer */
    vcBuff1    := substr(RegPath,instr(RegPath,'\')+1);
    vcBuff2    := RegEntry;
    vcBuff3    := RPAD(SUBSTR(NVL(vcBuff3,' '),1,2000),2000,CHR(0));
    if not WIN_API.COMPAT_EXPAND_REG_VALUES then 
    	iBuff3 := 1;
    	Win_API_Debug.DebugLog(99,'Read_Registry','Compatibility: Reg Value expansion supressed');	  
    else
    	iBuff3 := 0;
    end if;
    
    iRC        := d2kwutil_GetRegKey(win_api.FunctionHandle(iGetRegKey),iBuff1,vcBuff1,vcBuff2,vcBuff3,iBuff2,iBuff3);
    Win_API_Debug.DebugLog(99,'Read_Registry','Result:  RC='||to_char(iRC)||', vcBuff3="'||vcBuff3||'"');	      
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if;  
  if iRC = -1  then 
    Win_API.Add_error('Read_Registry','Cannot read  entry '||RegPath||'->'||RegEntry);
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -2 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' is an unsupported datatype');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;
  elsif iRC = -3 then
    Win_API.Add_error('Read_Registry',RegPath||'->'||RegEntry||' is longer than '||to_char(iBuff2)||' Bytes');
    if not RaiseExceptions then
      return NULL;
    else 
      raise VALUE_ERROR;
    end if;
  elsif iRC = -4 then
    Win_API.Add_error('Read_Registry', RegPath||'->'||RegEntry||' Failed to expand environment string');
    if not RaiseExceptions then
      return NULL;
    else 
      raise NO_DATA_FOUND;
    end if;    
  end if;
  return vcBuff3;
exception
  when NO_DATA_FOUND then 
    raise;
  when VALUE_ERROR then 
    raise;
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('Read_Registry',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('Read_Registry',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end Read_Registry;
```

#### SP-081 - REGISTER_FUNCTION_CALL

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.CHOOSEFILE]
- D2kwutil.pld [StoredProcedure: D2KWUTIL.GET_ACTIVE_WINDOW]
- D2kwutil.pld [StoredProcedure: GET_ENVIRONMENT_STRING]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]
- D2kwutil.pld [StoredProcedure: READ_REGISTRY]
- D2kwutil.pld [StoredProcedure: WINDEBUG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Registers a named Windows API function with the Oracle Foreign Function Interface (ORA_FFI) framework so that it can be called from Oracle Forms PL/SQL via the D2kwutil Windows API integration library. The procedure ensures the host DLL is loaded, registers the function handle and its typed parameters, and caches a load-count stamp to avoid redundant re-registration across DLL reloads. Errors encountered during DLL loading or FFI registration are surfaced through ADD_ERROR and ADD_EXTERNAL_ERRORS before aborting with NO_DATA_FOUND.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| FunctionID | PLS_INTEGER | IN |
| FunctionName | VARCHAR2 | IN |
| FunctionReturn | VARCHAR2 | IN |
| FunctionArgs | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.ATTEMPT_DLL_LOAD ([SP-001](#SP-001--D2KWUTIL.ATTEMPT_DLL_LOAD)) - D2KWUTIL.pck (or .pld)
- D2KWUTIL.TRANSLATETYPE ([SP-011](#SP-011--D2KWUTIL.TRANSLATETYPE)) - D2KWUTIL.pck (or .pld)
- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name
- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)
- WEBUTIL.REGISTER_FUNCTION ([SP-063](#SP-063--WEBUTIL.REGISTER_FUNCTION)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Attempt to locate the host DLL in the ORA_FFI library cache using ORA_FFI.FIND_LIBRARY; if the library is found the handle is stored in DLL_HANDLE and processing continues.
- Step 2 - If FIND_LIBRARY raises an FFI error (DLL not yet loaded), call D2KWUTIL.ATTEMPT_DLL_LOAD to load the DLL from its configured path and obtain a new handle.
- Step 3 - If ATTEMPT_DLL_LOAD also fails with an FFI error, set API_ENABLED to FALSE, call ADD_ERROR to record the 'DLL not found' message, and raise NO_DATA_FOUND to abort registration.
- Step 4 - Compare the cached load-count entry for FunctionID (FunctionLoad array) with the current DLL_LOAD_COUNT; if no entry exists or the counts differ, the function must be (re-)registered.
- Step 5 - Register the function with ORA_FFI using ORA_FFI.REGISTER_FUNCTION against the DLL handle, storing the result in FunctionHandle(FunctionID).
- Step 6 - If the function name is not 'd2kwutil_DebugString', call DEBUGLOG (via Win_API_Debug.DebugLog at level 99) to record either an initial registration or a re-registration event, including the DLL load count and, on re-registration, the previous load-count value.
- Step 7 - Parse the FunctionArgs string by appending a trailing comma delimiter and looping through comma-separated type tokens; for each token call D2KWUTIL.TRANSLATETYPE to convert the type name to its ORA_FFI constant, then call ORA_FFI.REGISTER_PARAMETER to bind it to the function handle. Loop terminates when the remaining argument string is NULL, a bare comma, or 'VOID,'.
- Step 8 - After parameter registration, if FunctionReturn is not 'VOID' and is not NULL, call D2KWUTIL.TRANSLATETYPE on the return-type token and register it with ORA_FFI.REGISTER_RETURN.
- Step 9 - Record the current DLL_LOAD_COUNT in FunctionLoad(FunctionID) to mark the function as registered for this DLL load cycle.
- Step 10 - In the outer exception handler, if any FFI error occurs during registration, call ADD_ERROR with the function name and the concatenated error detail from WEBUTIL.LENGTH-assisted Win_API.UError and ADD_EXTERNAL_ERRORS, then raise NO_DATA_FOUND.

---
**Decision Points**

DP-001

Condition:
ORA_FFI.FIND_LIBRARY raises an FFI error (DLL not currently loaded).

TRUE:
Call D2KWUTIL.ATTEMPT_DLL_LOAD to load the DLL; if that also fails, set API_ENABLED to FALSE, call ADD_ERROR, and raise NO_DATA_FOUND.

FALSE:
DLL handle is available; proceed to the registration check.

---

DP-002

Condition:
D2KWUTIL.ATTEMPT_DLL_LOAD raises an FFI error (DLL cannot be loaded from disk).

TRUE:
Set API_ENABLED to FALSE, call ADD_ERROR with 'DLL not found' message, and raise NO_DATA_FOUND.

FALSE:
DLL loaded successfully; DLL_HANDLE is set and processing continues.

---

DP-003

Condition:
FunctionLoad entry for FunctionID does not exist, OR FunctionLoad(FunctionID) differs from the current DLL_LOAD_COUNT.

TRUE:
Proceed with full function registration: register function handle, log via DEBUGLOG, register parameters, register return type, and update FunctionLoad(FunctionID).

FALSE:
Function is already registered for the current DLL load cycle; skip all registration steps.

---

DP-004

Condition:
FunctionName equals 'd2kwutil_DebugString'.

TRUE:
Skip the DEBUGLOG call to avoid recursive logging.

FALSE:
Call DEBUGLOG to record the registration event (initial or re-registration) with function name and DLL load count.

---

DP-005

Condition:
No prior FunctionLoad entry exists for FunctionID (within the DEBUGLOG branch).

TRUE:
Log the event as an initial registration.

FALSE:
Log the event as a re-registration, including the previous FunctionLoad count.

---

DP-006

Condition:
The remaining FunctionArgs string is NULL, equals ',', or equals 'VOID,' during parameter-parsing loop.

TRUE:
Exit the parameter-registration loop; no further parameters to register.

FALSE:
Extract the next comma-delimited type token, call D2KWUTIL.TRANSLATETYPE, and register the parameter with ORA_FFI.REGISTER_PARAMETER.

---

DP-007

Condition:
FunctionReturn is not 'VOID' (case-insensitive) AND FunctionReturn is not NULL.

TRUE:
Call D2KWUTIL.TRANSLATETYPE on FunctionReturn and register the return type with ORA_FFI.REGISTER_RETURN.

FALSE:
No return type is registered (procedure or void function).

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - A Windows API function may only be called from Oracle Forms PL/SQL after it has been registered via this procedure; any attempt to use an unregistered function will result in an FFI error.
- BR-002 - The host DLL must be locatable either in the ORA_FFI cache or on the configured DLL path; if neither succeeds, the entire Windows API integration is disabled (API_ENABLED = FALSE) and the calling routine receives NO_DATA_FOUND.
- BR-003 - Registration is skipped when the cached DLL load count for the function matches the current DLL_LOAD_COUNT, preventing unnecessary ORA_FFI overhead on repeated calls within the same DLL load cycle.
- BR-004 - When the DLL is reloaded (DLL_LOAD_COUNT changes), all previously registered function handles become stale and must be re-registered before use; this procedure enforces that rule automatically via the load-count comparison.
- BR-005 - Function argument types supplied in FunctionArgs must be expressed as comma-separated type-name tokens recognisable by D2KWUTIL.TRANSLATETYPE; 'VOID' as the sole argument token indicates a parameterless function and causes the parameter-registration loop to be skipped.
- BR-006 - A return type of 'VOID' or a NULL FunctionReturn value indicates a procedure (no return value); no ORA_FFI return-type registration is performed in that case.
- BR-007 - The internal debug function 'd2kwutil_DebugString' is explicitly excluded from DEBUGLOG calls during registration to prevent recursive logging.
- BR-008 - Any FFI error raised during the registration phase is captured, enriched with external error detail via ADD_EXTERNAL_ERRORS, reported through ADD_ERROR, and converted to NO_DATA_FOUND so that callers can handle the failure consistently.

---
**Implementation Logic**

```plsql

PROCEDURE Register_Function_Call ( FunctionID     in PLS_INTEGER, 
                                   FunctionName   in VARCHAR2,
                                   FunctionReturn in VARCHAR2, 
                                   FunctionArgs   in VARCHAR2) is
  vcArgs  VARCHAR2(200);
  vcFrag  VARCHAR2(10);
  iOffset PLS_INTEGER;   
begin 
   -- See if the DLL has been loaded at all.
   -- if this call to FIND_LIBRARY fails, we'll fall through to the Exception.
   begin
    DLL_HANDLE := ORA_FFI.find_library(DLL_NAME);
  exception
    when ora_ffi.ffi_error then 
      -- Attempt to load the DLL again in a subblock. If this fails
      -- then the API must be disabled and NOT_DATA_FOUND raised
      begin 
          DLL_HANDLE := Attempt_DLL_Load(DLL_Path, DLL_NAME);
      exception
          when ora_ffi.ffi_error then 
            API_ENABLED := FALSE;
              add_error('D2KWUTIL',DLL_NAME||' not found.');
            RAISE NO_DATA_FOUND;
      end;
  end;

  -- now compare the Cached value for this function's loadcount with 
  -- that for the DLL this tells us that the function has either not 
  -- been registered yet, or that the DLL has been reloaded in between 
  -- times.  This would not be healthy so we have to re-register in that case.
  if (not FunctionLoad.exists(FunctionId)) or (FunctionLoad(FunctionId)<> DLL_LOAD_COUNT) then
    -- We need to go through the registration process.      
    -- Register the function with the DLL
    FunctionHandle(FunctionId) := ora_ffi.register_function(Win_API.DLL_HANDLE,FunctionName,ORA_FFI.C_STD);
    if FunctionName <> 'd2kwutil_DebugString' then 
    	if not FunctionLoad.exists(FunctionId) then 
    		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Initial Reg');
    	else
       		Win_API_Debug.DebugLog(99,'Register_Function_Call','Ftn="'||FunctionName||'", DLL Count='||to_char(DLL_LOAD_COUNT)||', Re-Registration Count = '||to_char(FunctionLoad(FunctionId)));
       	end if;
    end if;
    
    -- Loop through and register the parameters
    vcArgs := FunctionArgs||',';
    while vcArgs is not null and vcArgs <> ',' and vcArgs <> 'VOID,' LOOP
      iOffset := instr(vcArgs,',');
      vcFrag := substr(vcArgs,1,iOffset-1);
      ora_ffi.register_parameter(FunctionHandle(FunctionId),TranslateType(vcFrag));
      if iOffset = length(vcArgs) then
        vcArgs := NULL;
      else
        vcArgs := substr(vcArgs,iOffset+1);
      end if;
    end LOOP;
    
    -- Register the return type IF this is a function
    if upper(FunctionReturn) <> 'VOID' and FunctionReturn is not NULL then 
      ora_ffi.register_return(FunctionHandle(FunctionId),TranslateType(FunctionReturn));
    end if;
    
    -- Now add this Function's Loadcount to the array to prevent un-nessary re-registration
    FunctionLoad(FunctionId) := DLL_LOAD_COUNT;
  end if;
exception
   when ora_ffi.ffi_error then
    Win_API.Add_error(FunctionName, Win_API.UError||WIN_API.Add_External_errors); 
    raise NO_DATA_FOUND;
end Register_Function_Call;
```

#### SP-082 - SETDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Configures the debug logging environment for the application session by setting the debug output type (file or message-based), the target log file, the verbosity level, and whether log entries should include a timestamp. Once configured, the procedure activates or deactivates the debug state and records an initialisation entry via DEBUGLOG.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| DebugType | PLS_INTEGER | IN |
| DebugFile | VARCHAR2 | IN |
| DebugLevel | PLS_INTEGER | IN |
| TimeStamp | BOOLEAN | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- DEBUGLOG ([SP-076](#SP-076--DEBUGLOG)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the four input parameters: DebugType (output destination), DebugFile (target file path, optional), DebugLevel (verbosity threshold, defaulting to 98), and TimeStamp (flag to include timestamps in log entries, defaulting to FALSE).
- Step 2 - Persist the TimeStamp flag to the package-level variable bDebugTimeStamp, making it available to subsequent logging calls within the session.
- Step 3 - Persist the DebugFile value to the package-level variable vcDebugFile, establishing the target file for any file-based log output.
- Step 4 - Persist the DebugLevel value to the package-level variable iDebugLevel, controlling the verbosity threshold for subsequent log entries.
- Step 5 - Evaluate DebugType to determine the logging mode to activate.
- Step 6 - If DebugType = 1, set the package-level state variable iDebugState to 1 (file logging) and call DEBUGLOG to record the message 'Logging to File' concatenated with the supplied DebugFile path.
- Step 7 - If DebugType = 2, set iDebugState to 2 (message-based logging) and call DEBUGLOG to record the message 'Logging Started'.
- Step 8 - For any other DebugType value, call DEBUGLOG to record the message 'Logging Stopped' and then set iDebugState to 0, disabling further debug output.

---
**Decision Points**

DP-001

Condition: DebugType = 1

TRUE: Set iDebugState to 1 (file-based logging mode) and invoke DEBUGLOG with message 'Logging to File' appended with the DebugFile path.

FALSE: Evaluate DP-002.

---

DP-002

Condition: DebugType = 2

TRUE: Set iDebugState to 2 (message-based logging mode) and invoke DEBUGLOG with message 'Logging Started'.

FALSE: Invoke DEBUGLOG with message 'Logging Stopped' and set iDebugState to 0, disabling debug output.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - DebugType must be supplied by the caller; a value of 1 activates file-based logging, a value of 2 activates message-based logging, and any other value disables logging entirely.
- BR-002 - DebugFile defaults to NULL when not supplied; it is stored unconditionally but is only meaningful when DebugType = 1 (file-based logging mode).
- BR-003 - DebugLevel defaults to 98 when not supplied, establishing a high-verbosity threshold unless the caller explicitly restricts it.
- BR-004 - TimeStamp defaults to FALSE when not supplied; setting it to TRUE causes subsequent DEBUGLOG calls to include a timestamp in each log entry.
- BR-005 - Every invocation of SETDEBUG must produce exactly one audit entry via DEBUGLOG, regardless of which debug mode is selected or deselected.
- BR-006 - The iDebugState variable must be set after the corresponding DEBUGLOG call when activating file-based logging (DebugType = 1), but before returning in all cases, ensuring the state is always consistent with the last configuration request.
- BR-007 - When logging is stopped (DebugType not 1 or 2), DEBUGLOG is called before iDebugState is set to 0, ensuring the stop event is recorded while the prior logging state is still active.

---
**Implementation Logic**

```plsql

PROCEDURE SetDebug( DebugType   IN PLS_INTEGER, 
                    DebugFile   IN VARCHAR2 DEFAULT NULL, 
                    DebugLevel  IN PLS_INTEGER DEFAULT 98,                        
                    TimeStamp   IN BOOLEAN DEFAULT FALSE) is
begin 
    bDebugTimeStamp := TimeStamp;
    vcDebugFile     := DebugFile;
    iDebugLevel     := DebugLevel;
	if DebugType = 1 then 
		iDebugState := 1;
		DebugLog(0,'SetDebug','Logging to File '||DebugFile);
	elsif DebugType = 2 then
		iDebugState := 2;
		DebugLog(0,'SetDebug','Logging Started');
	else 
        DebugLog(0,'SetDebug','Logging Stopped');
        iDebugState := 0;
	end if;
end SetDebug;
```

#### SP-083 - STRIPDIRSEP

**Invoked From:**

- D2kwutil.pld [StoredProcedure: D2KWUTIL.ATTEMPT_DLL_LOAD]
- D2kwutil.pld [StoredProcedure: GET_TEMP_DIRECTORY]
- D2kwutil.pld [StoredProcedure: GET_WINDOWS_DIRECTORY]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

Removes a trailing directory separator character (backslash) from a file path string. This is a utility function in the D2kwutil Windows API integration library.

<!--
Provide a concise business description of what this procedure accomplishes.
-->

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| InPath | varchar2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.LENGTH ([SP-055](#SP-055--WEBUTIL.LENGTH)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Accept the input parameters from the calling routine.
- Step 2 - Perform the utility operation (error stack management, logging, or environment query) using the Windows API integration framework.
- Step 3 - Return the result or status to the caller.

<!--
Generate one bullet for every logical processing step.

Example:

- Step 1 - Validate the input values.
- Step 2 - Retrieve the required business data.
- Step 3 - Apply business validations.
- Step 4 - Update the required records.
- Step 5 - Return the processing result.
-->

---
**Decision Points**

No conditional branches exist in this routine or decision logic cannot be verified (specification-only entry).

<!--
Repeat the following structure for every decision.

DP-001

Condition:
<Condition>

TRUE:
<Action performed when condition evaluates to TRUE>

FALSE:
<Action performed when condition evaluates to FALSE>
-->

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - This routine is part of the D2kwutil Windows API integration library; it performs a direct utility operation with no configurable business rules.

<!--
Generate one bullet for each business rule.

Example:

- BR-001 - <Business rule description>.
- BR-002 - <Business rule description>.
-->

---
**Implementation Logic**

```plsql

  

Function StripDirSep ( InPath in varchar2) return varchar2 is 
  vcPath  varchar2(500) := InPath;
begin 
  -- Check and Strip SemiColons, we take everything
  -- Before the first Semicolon as our path
  if instr(vcPath,';') > 0 then
    vcPath := substr(vcPath,1,instr(vcPath,';') -1);
  end if;

  -- Check and Strip '\'
  if substr(vcPath,-1,1) = '\' then 
    vcPath := substr(vcPath,1,length(vcPath)-1);
  end if;

  return vcPath;
end StripDirSep;
```

#### SP-084 - VIEW_EXCEL_REPORT_NEW

**Invoked From:**

- vr_veh_wise_delay_fmb.xml [Trigger: WHEN-BUTTON-PRESSED]

---

**Screen:**

N/A

---

**Purpose**

Generates and delivers a CSV export file to the end user for the vehicle-wise delay report. Depending on whether a report server is configured for the principal and application, the procedure either delegates CSV generation to a remote database procedure or builds the file locally from a Forms record group. In both paths it reads a server-side URL configuration file, transfers the resulting CSV to the client machine, and opens it via a host command.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| p_principal | number | IN |
| p_file_name | VARCHAR2 | IN |
| p_query | VARCHAR2 | IN |
| p_column_name | VARCHAR2 | IN |
| p_app_id | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- WEBUTIL.FCLOSE ([SP-030](#SP-030--WEBUTIL.FCLOSE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FILE_SAVE_DIALOG ([SP-031](#SP-031--WEBUTIL.FILE_SAVE_DIALOG)) - WEBUTIL.pck (or .pld)
- WEBUTIL.FOPEN ([SP-033](#SP-033--WEBUTIL.FOPEN)) - WEBUTIL.pck (or .pld)
- WEBUTIL.GET_LINE ([SP-046](#SP-046--WEBUTIL.GET_LINE)) - WEBUTIL.pck (or .pld)
- WEBUTIL.HOST ([SP-049](#SP-049--WEBUTIL.HOST)) - WEBUTIL.pck (or .pld)
- WEBUTIL.ID_NULL ([SP-050](#SP-050--WEBUTIL.ID_NULL)) - WEBUTIL.pck (or .pld)
- WEBUTIL.PUTF ([SP-058](#SP-058--WEBUTIL.PUTF)) - WEBUTIL.pck (or .pld)
- WEBUTIL.URL_TO_CLIENT ([SP-069](#SP-069--WEBUTIL.URL_TO_CLIENT)) - WEBUTIL.pck (or .pld)

---

**Step-by-Step Business Logic**

- Step 1 - Query EH_REPORTS to retrieve the report server identifier (rep_server) for the supplied principal (p_principal) and application identifier (p_app_id). If no matching row exists, rep_server is set to NULL.
- Step 2 - Evaluate whether rep_server is populated to determine which export path to follow (server-side generation vs. local Forms record-group generation).
- Step 3 (both paths) - Determine the output filename: if p_file_name is NULL, prompt the user with a file-save dialog (WEBUTIL.FILE_SAVE_DIALOG); otherwise use p_file_name directly, then append the '.csv' extension.
- Step 4 (both paths) - Validate that the resolved filename contains no spaces in its folder path. If spaces are detected, redirect the file to 'C:\' using only the base filename and display an informational message to the user.
- Step 5a (rep_server path) - Call the remote procedure sp_csv_report_generate via the database link dms1_db3_lnk, passing the filename and p_query, to generate the CSV on the remote server.
- Step 5b (rep_server path) - Execute a host shell command (WEBUTIL.HOST) to move the generated file from /utl_dir/ to the reports printer directory /iashome/ias/reports/printer/.
- Step 6a (no rep_server path) - Create a Forms record group from p_query (deleting any pre-existing group with the same name first), populate it, and obtain the row count.
- Step 6b (no rep_server path) - Open a server-side file for writing (WEBUTIL.FOPEN equivalent via TEXT_IO), iterate over every row in the record group, write the value of the column identified by p_column_name followed by a newline using WEBUTIL.PUTF, then close the file (WEBUTIL.FCLOSE).
- Step 7 (both paths) - Read the base URL from the configuration file /reports/DMS/excelpath.txt using WEBUTIL.GET_LINE, then close the file (WEBUTIL.FCLOSE).
- Step 8 (both paths) - Construct the full server URL by appending the base filename to the URL path, then transfer the file to the client using WEBUTIL.URL_TO_CLIENT. If the transfer fails, display a 'File Transfer failed' message and pause.
- Step 9 (both paths) - Open the transferred CSV file on the client workstation by issuing a 'cmd /c' host command via WEBUTIL.HOST.
- Step 10 - On any unhandled exception, display the Oracle error code and text, then raise FORM_TRIGGER_FAILURE to halt further processing.

---
**Decision Points**

DP-001

Condition:
lv_rep_server IS NOT NULL (a report server entry exists in EH_REPORTS for the given principal and application).

TRUE:
Delegate CSV generation to the remote procedure sp_csv_report_generate via database link, move the file with a shell command, then proceed to URL-based file transfer and client open.

FALSE:
Generate the CSV locally using a Forms record group populated from p_query, write rows to a server-side file, then proceed to URL-based file transfer and client open.

---

DP-002

Condition:
p_file_name IS NULL.

TRUE:
Prompt the user with WEBUTIL.FILE_SAVE_DIALOG to select a save location and filename.

FALSE:
Use the value supplied in p_file_name directly as the base filename.

---

DP-003

Condition:
INSTR(FILENAME, ' ') > 0 (the resolved filename path contains one or more space characters).

TRUE:
Override the path to 'C:\' using only the base filename component, and display a warning message informing the user that the file will be stored on the C drive.

FALSE:
Retain the resolved filename path as-is.

---

DP-004

Condition:
The Forms record group with name 'DataRecordSet' already exists (ID_NULL check via WEBUTIL.ID_NULL returns FALSE) - applicable only in the no-rep_server path.

TRUE:
Delete the existing record group before creating a new one from p_query.

FALSE:
Proceed directly to creating the record group from p_query.

---

DP-005

Condition:
file_transfer_bool is FALSE (WEBUTIL.URL_TO_CLIENT reports that the file transfer to the client failed).

TRUE:
Display the message 'File Transfer failed' and pause execution.

FALSE:
Continue to open the file on the client via WEBUTIL.HOST.

---
**Database Interactions**

- DB-001 - Read EH_REPORTS - Reads data from EH_REPORTS for lookup or validation.
**Business Rules**

- BR-001 - The procedure determines the CSV generation strategy by looking up EH_REPORTS using both p_principal and p_app_id; only when a non-null rep_server value is found is the remote (database-link) generation path used.
- BR-002 - The output file must always carry a '.csv' extension; the extension is appended unconditionally to the resolved filename regardless of any extension already present in p_file_name.
- BR-003 - Filenames whose folder path contains spaces are not permitted at the specified location; such files are automatically redirected to the root of the C drive and the user is notified.
- BR-004 - In the local generation path, only the single column identified by p_column_name is written to the CSV; each cell value is written as a separate line terminated by CHR(10).
- BR-005 - The base URL for file transfer is not hard-coded; it is read at runtime from the server-side configuration file /reports/DMS/excelpath.txt, allowing the URL to be changed without modifying the procedure.
- BR-006 - A failed client file transfer (WEBUTIL.URL_TO_CLIENT returns FALSE) is treated as a non-silent error: the user is notified and execution is paused, but no exception is raised at that point.
- BR-007 - Any unhandled exception causes the Oracle error code and error text to be displayed to the user, after which FORM_TRIGGER_FAILURE is raised to prevent further trigger processing.

---
**Implementation Logic**

```plsql
PROCEDURE view_excel_report_new(p_principal number,p_file_name VARCHAR2, p_query VARCHAR2,p_column_name VARCHAR2,p_app_id VARCHAR2) IS
	rg_name 				 		VARCHAR2(40) := 'DataRecordSet'; 
	rg_id 					 		RecordGroup; 
	gc_id 					 		GroupColumn; 
	errcode 				 		NUMBER; 
	the_rowcount 		 		NUMBER; 
  FILENAME			   		VARCHAR2(4000);
  MYFILE 					 		TEXT_IO.FILE_TYPE;
  urlFile 					 	TEXT_IO.FILE_TYPE;
  urlPath							VARCHAR2(5000);
	V_STRING 				 		VARCHAR2(4000);
	l_alert 				 		NUMBER;
	server_file      		VARCHAR2(2000);
	file_transfer_bool	BOOLEAN;
	formserverpath   		VARCHAR2(2000);
	lv_err_reas			varchar2(2000);
	lv_cmd	varchar2(1000);
	lv_rep_server	varchar2(50);

begin
			begin
				select rep_server into lv_rep_server from eh_reports
				where principal_map_cd=p_principal
				and   app_id=p_app_id;
			exception
				when others then
				 lv_rep_server:=null;
			end;	

if lv_rep_server is not null then
		
			If p_file_name is null then
				FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
			Else
			  FILENAME := p_file_name;
			End If;
  
  		FILENAME:=p_file_name||'.csv';
  
			 	If instr(FILENAME,' ') > 0 then
			 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
			 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
			 		message('  ');
			 	end if;
 	
			sp_csv_report_generate@dms1_db3_lnk(FILENAME,p_query,errcode,lv_err_reas);
			
			host('/bin/mv /utl_dir/'||FILENAME||' /iashome/ias/reports/printer/'||FILENAME);
			
			server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	
			urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
			Text_Io.Get_Line(urlFile,urlPath);
			Text_Io.Fclose(urlFile);
			formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);

 		file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	
	WebUtil_Host.HOST('cmd /c '||FILENAME);
	
else
  If p_file_name is null then
		FILENAME  := Webutil_file.FILE_SAVE_DIALOG;
  Else
    FILENAME := p_file_name;
  End If;
 	If instr(FILENAME,' ') > 0 then
 		FILENAME := 'C:\'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
 		Message('File cannot be saved in the specifed path, as it contains spaces in one of the folder names. File will be stored in C drive as default.');
 		message('  ');
 	end if;
	rg_id := Find_Group( rg_name ); 
	IF NOT Id_Null(rg_id) THEN 
		Delete_Group( rg_id ); 
	END IF; 
	rg_id := Create_Group_From_Query( rg_name, p_query ); 
	errcode := Populate_Group( rg_id ); 
	the_rowcount := Get_Group_Row_Count( rg_id );
	server_file := '/iashome/ias/reports/printer/'||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	urlFile := Text_Io.Fopen('/reports/DMS/excelpath.txt','R');
	Text_Io.Get_Line(urlFile,urlPath);
	Text_Io.Fclose(urlFile);
	formserverpath := urlPath||SUBSTR(FILENAME,INSTR(FILENAME,'\',-1,1)+1);
	MYFILE := TEXT_IO.FOPEN(server_file, 'W');
	gc_id := Find_Column( rg_name||'.'||p_column_name); 	
	for total_loop IN 1..the_rowcount
		loop
	  	V_STRING :=  GET_GROUP_CHAR_CELL(gc_id  , total_loop )||CHR(10); 
	  	TEXT_IO.PUTF(MYFILE,V_STRING);  
		end loop;
	 	TEXT_IO.FCLOSE(MYFILE);
	 	file_transfer_bool := WebUtil_File_Transfer.Url_To_Client(formserverpath,FILENAME);
	 	if not file_transfer_bool  then 
	 		message('File Transfer failed');pause;
	 	end if;
	 	WebUtil_Host.HOST('cmd /c '||FILENAME);	 		
	 		
end if;

exception
	when others then
	Message('Error  - '||ERROR_CODE|| ERROR_TEXT);
	Raise Form_trigger_failure;
end;
```

#### SP-085 - WINDEBUG

**Invoked From:**

- D2kwutil.pld [StoredProcedure: DEBUGLOG]

---

**Screen:**

-(Invoked indirectly - screen follows parent invocation site.)

---

**Purpose**

WINDEBUG provides a bridge between Oracle Forms and the D2KWUTIL Windows API debug facility. Given a text string, it registers the underlying debug function call through the WIN_API framework and then invokes D2KWUTIL_DEBUGSTRING to write the message to the external debug output. If the Windows API is unavailable or any other error occurs, the procedure records a structured error and re-raises the exception to the caller.

---
**Input Parameters**

| Parameter | Type | Direction |
|-----------|------|-----------|
| Text | VARCHAR2 | IN |

**Output Parameters**

No formal output parameters in source signature.

---

**Dependencies**

- ADD_ERROR ([SP-072](#SP-072--ADD_ERROR)) - matched by member name
- ADD_EXTERNAL_ERRORS ([SP-073](#SP-073--ADD_EXTERNAL_ERRORS)) - matched by member name
- D2KWUTIL.D2KWUTIL_DEBUGSTRING ([SP-005](#SP-005--D2KWUTIL.D2KWUTIL_DEBUGSTRING)) - D2KWUTIL.pck (or .pld) (specification only - no body found)
- REGISTER_FUNCTION_CALL ([SP-081](#SP-081--REGISTER_FUNCTION_CALL)) - matched by member name

---

**Step-by-Step Business Logic**

- Step 1 - Receive the input text string and append a newline character (CHR(10)) to form the debug buffer (vcBuff1).
- Step 2 - Check whether the Windows API integration is active by evaluating WIN_API.API_ENABLED.
- Step 3 - If the API is enabled, register the external function call for 'D2KWUTIL_DEBUGSTRING' against the debug-string function handle (iDebugString) using REGISTER_FUNCTION_CALL, declaring a single character-type parameter ('*CHAR') with no return value (NULL).
- Step 4 - Invoke D2KWUTIL.D2KWUTIL_DEBUGSTRING, passing the resolved function handle and the prepared buffer (vcBuff1), to write the debug message to the external Windows debug output.
- Step 5 - If WIN_API.API_ENABLED is FALSE, raise the WIN_API.NOT_AVAILABLE exception.
- Step 6 - In the NOT_AVAILABLE exception handler, call ADD_ERROR to log the error context ('WinDebug', WIN_API.NoAPI) and re-raise the exception to the caller.
- Step 7 - In the OTHERS exception handler, call ADD_ERROR to log the error context ('WinDebug', WIN_API.UError concatenated with the result of ADD_EXTERNAL_ERRORS) and re-raise the exception to the caller.

---
**Decision Points**

DP-001

Condition:
WIN_API.API_ENABLED evaluates to TRUE.

TRUE:
The procedure registers the function call via REGISTER_FUNCTION_CALL and forwards the debug message to the external Windows debug output via D2KWUTIL.D2KWUTIL_DEBUGSTRING.

FALSE:
The WIN_API.NOT_AVAILABLE exception is raised, which is caught by the dedicated exception handler; ADD_ERROR is called with the 'WinDebug' context and the WIN_API.NoAPI error code, and the exception is re-raised to the caller.

DP-002

Condition:
An unhandled exception other than WIN_API.NOT_AVAILABLE occurs during execution.

TRUE:
The OTHERS handler captures the exception; ADD_ERROR is called with the 'WinDebug' context and a composite error message built from WIN_API.UError and the output of ADD_EXTERNAL_ERRORS, and the exception is re-raised to the caller.

FALSE:
No additional error handling is triggered; execution completes normally.

---
**Database Interactions**

No database table interactions detected in the resolved source.
**Business Rules**

- BR-001 - The input text must be augmented with a newline character (CHR(10)) before being passed to the external debug function; raw text is never sent directly.
- BR-002 - The Windows API integration must be active (WIN_API.API_ENABLED = TRUE) before any attempt is made to invoke the external debug output; the procedure does not fall back to an alternative logging mechanism if the API is unavailable.
- BR-003 - The external function 'D2KWUTIL_DEBUGSTRING' must be formally registered via REGISTER_FUNCTION_CALL before it is invoked; direct invocation without prior registration is not permitted.
- BR-004 - All exceptions, whether caused by API unavailability or any other runtime error, must be logged through ADD_ERROR before being re-raised; silent failure is not permitted.
- BR-005 - When an unexpected error occurs, ADD_EXTERNAL_ERRORS must be appended to the WIN_API.UError message to ensure that any externally sourced error detail is captured in the error log entry.

---
**Implementation Logic**

```plsql
  

  
PROCEDURE WinDebug  (  Text  IN   VARCHAR2) is
  vcBuff1 VARCHAR2(2000) := Text||chr(10);
begin 
  --WIN_API.Clean_Error_Stack;
  if Win_API.API_ENABLED then
    win_api.Register_function_call(iDebugString,'d2kwutil_DebugString',NULL,'*CHAR');
    d2kwutil_DebugString(win_api.FunctionHandle(iDebugString),vcBuff1);
  else 
    raise WIN_API.NOT_AVAILABLE;
  end if; 
exception
  when WIN_API.NOT_AVAILABLE then
    Win_API.Add_error('WinDebug',Win_API.NoAPI);
    raise;
  when others then 
    Win_API.Add_error('WinDebug',Win_API.UError||WIN_API.Add_External_errors); 
    raise;
end WinDebug;
```

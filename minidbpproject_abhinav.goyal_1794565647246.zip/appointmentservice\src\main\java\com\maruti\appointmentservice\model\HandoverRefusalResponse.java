package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AppointmentStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * HandoverRefusalResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class HandoverRefusalResponse   {
  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("recordedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime recordedAt = null;

  @JsonProperty("exceptionFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean exceptionFlag = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;


  public HandoverRefusalResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment for which the refusal was logged.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment for which the refusal was logged.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public HandoverRefusalResponse recordedAt(OffsetDateTime recordedAt) { 

    this.recordedAt = recordedAt;
    return this;
  }

  /**
   * Timestamp when the refusal was recorded by the system.
   * @return recordedAt
   **/
  
  @Schema(description = "Timestamp when the refusal was recorded by the system.")
  
@Valid
  public OffsetDateTime getRecordedAt() {  
    return recordedAt;
  }



  public void setRecordedAt(OffsetDateTime recordedAt) { 
    this.recordedAt = recordedAt;
  }

  public HandoverRefusalResponse exceptionFlag(Boolean exceptionFlag) { 

    this.exceptionFlag = exceptionFlag;
    return this;
  }

  /**
   * Indicates whether the appointment has been flagged as an exception following the refusal.
   * @return exceptionFlag
   **/
  
  @Schema(description = "Indicates whether the appointment has been flagged as an exception following the refusal.")
  
  public Boolean isExceptionFlag() {  
    return exceptionFlag;
  }



  public void setExceptionFlag(Boolean exceptionFlag) { 
    this.exceptionFlag = exceptionFlag;
  }

  public HandoverRefusalResponse status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HandoverRefusalResponse handoverRefusalResponse = (HandoverRefusalResponse) o;
    return Objects.equals(this.appointmentId, handoverRefusalResponse.appointmentId) &&
        Objects.equals(this.recordedAt, handoverRefusalResponse.recordedAt) &&
        Objects.equals(this.exceptionFlag, handoverRefusalResponse.exceptionFlag) &&
        Objects.equals(this.status, handoverRefusalResponse.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentId, recordedAt, exceptionFlag, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HandoverRefusalResponse {\n");
    
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    recordedAt: ").append(toIndentedString(recordedAt)).append("\n");
    sb.append("    exceptionFlag: ").append(toIndentedString(exceptionFlag)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

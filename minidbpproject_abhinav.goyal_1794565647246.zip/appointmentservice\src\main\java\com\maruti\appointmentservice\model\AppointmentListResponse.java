package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AppointmentSummary;
import com.maruti.appointmentservice.model.Pagination;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AppointmentListResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AppointmentListResponse   {
  @JsonProperty("pagination")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Pagination pagination = null;

  @JsonProperty("data")
  @Valid
  private List<AppointmentSummary> data = null;

  public AppointmentListResponse pagination(Pagination pagination) { 

    this.pagination = pagination;
    return this;
  }

  /**
   * Get pagination
   * @return pagination
   **/
  
  @Schema(description = "")
  
@Valid
  public Pagination getPagination() {  
    return pagination;
  }



  public void setPagination(Pagination pagination) { 
    this.pagination = pagination;
  }

  public AppointmentListResponse data(List<AppointmentSummary> data) { 

    this.data = data;
    return this;
  }

  public AppointmentListResponse addDataItem(AppointmentSummary dataItem) {
    if (this.data == null) {
      this.data = new ArrayList<AppointmentSummary>();
    }
    this.data.add(dataItem);
    return this;
  }

  /**
   * Page of appointment summaries matching the applied filters.
   * @return data
   **/
  
  @Schema(description = "Page of appointment summaries matching the applied filters.")
  @Valid
  public List<AppointmentSummary> getData() {  
    return data;
  }



  public void setData(List<AppointmentSummary> data) { 
    this.data = data;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppointmentListResponse appointmentListResponse = (AppointmentListResponse) o;
    return Objects.equals(this.pagination, appointmentListResponse.pagination) &&
        Objects.equals(this.data, appointmentListResponse.data);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pagination, data);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppointmentListResponse {\n");
    
    sb.append("    pagination: ").append(toIndentedString(pagination)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

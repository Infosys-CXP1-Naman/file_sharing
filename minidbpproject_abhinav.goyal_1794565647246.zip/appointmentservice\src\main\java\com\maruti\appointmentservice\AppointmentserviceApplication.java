package com.maruti.appointmentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


	

/**
* @author ICNDP
* @version 1.0
*/


   
@SpringBootApplication
public class AppointmentserviceApplication {


	public static void main(String[] args) {
		SpringApplication.run(AppointmentserviceApplication.class, args);
	}




}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AllocationStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * DispatchAssignmentResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class DispatchAssignmentResponse   {
  @JsonProperty("dispatchedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime dispatchedAt = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("chauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurId = null;

  @JsonProperty("crmReferenceId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String crmReferenceId = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;


  public DispatchAssignmentResponse dispatchedAt(OffsetDateTime dispatchedAt) { 

    this.dispatchedAt = dispatchedAt;
    return this;
  }

  /**
   * Timestamp when the dispatch request was sent.
   * @return dispatchedAt
   **/
  
  @Schema(description = "Timestamp when the dispatch request was sent.")
  
@Valid
  public OffsetDateTime getDispatchedAt() {  
    return dispatchedAt;
  }



  public void setDispatchedAt(OffsetDateTime dispatchedAt) { 
    this.dispatchedAt = dispatchedAt;
  }

  public DispatchAssignmentResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment for which the dispatch was triggered.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment for which the dispatch was triggered.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public DispatchAssignmentResponse chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur to whom the assignment was dispatched.
   * @return chauffeurId
   **/
  
  @Schema(description = "Identifier of the chauffeur to whom the assignment was dispatched.")
  
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 
    this.chauffeurId = chauffeurId;
  }

  public DispatchAssignmentResponse crmReferenceId(String crmReferenceId) { 

    this.crmReferenceId = crmReferenceId;
    return this;
  }

  /**
   * Reference identifier returned by the CRM integration for tracking the dispatch notification.
   * @return crmReferenceId
   **/
  
  @Schema(description = "Reference identifier returned by the CRM integration for tracking the dispatch notification.")
  
  public String getCrmReferenceId() {  
    return crmReferenceId;
  }



  public void setCrmReferenceId(String crmReferenceId) { 
    this.crmReferenceId = crmReferenceId;
  }

  public DispatchAssignmentResponse allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DispatchAssignmentResponse dispatchAssignmentResponse = (DispatchAssignmentResponse) o;
    return Objects.equals(this.dispatchedAt, dispatchAssignmentResponse.dispatchedAt) &&
        Objects.equals(this.appointmentId, dispatchAssignmentResponse.appointmentId) &&
        Objects.equals(this.chauffeurId, dispatchAssignmentResponse.chauffeurId) &&
        Objects.equals(this.crmReferenceId, dispatchAssignmentResponse.crmReferenceId) &&
        Objects.equals(this.allocationStatus, dispatchAssignmentResponse.allocationStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dispatchedAt, appointmentId, chauffeurId, crmReferenceId, allocationStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DispatchAssignmentResponse {\n");
    
    sb.append("    dispatchedAt: ").append(toIndentedString(dispatchedAt)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    crmReferenceId: ").append(toIndentedString(crmReferenceId)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.maruti.appointmentservice.model.AppointmentStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * RescheduleResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class RescheduleResponse   {
  @JsonProperty("newPickupDateTime")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime newPickupDateTime = null;

  /**
   * The OTP step that was processed.
   */
  public enum OtpActionEnum {
    GENERATEOTP("GenerateOTP"),
    
    VALIDATEOTP("ValidateOTP");

    private String value;

    OtpActionEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OtpActionEnum fromValue(String text) {
      for (OtpActionEnum b : OtpActionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("otpAction")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OtpActionEnum otpAction = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  /**
   * Result of the OTP action.
   */
  public enum OtpStatusEnum {
    OTPSENT("OTPSent"),
    
    OTPVERIFIED("OTPVerified"),
    
    OTPINVALID("OTPInvalid"),
    
    OTPEXPIRED("OTPExpired");

    private String value;

    OtpStatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OtpStatusEnum fromValue(String text) {
      for (OtpStatusEnum b : OtpStatusEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("otpStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OtpStatusEnum otpStatus = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;

  @JsonProperty("updatedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime updatedAt = null;


  public RescheduleResponse newPickupDateTime(OffsetDateTime newPickupDateTime) { 

    this.newPickupDateTime = newPickupDateTime;
    return this;
  }

  /**
   * Confirmed new pickup date and time after successful OTP verification. Populated only when otpStatus is 'OTPVerified'.
   * @return newPickupDateTime
   **/
  
  @Schema(description = "Confirmed new pickup date and time after successful OTP verification. Populated only when otpStatus is 'OTPVerified'.")
  
@Valid
  public OffsetDateTime getNewPickupDateTime() {  
    return newPickupDateTime;
  }



  public void setNewPickupDateTime(OffsetDateTime newPickupDateTime) { 
    this.newPickupDateTime = newPickupDateTime;
  }

  public RescheduleResponse otpAction(OtpActionEnum otpAction) { 

    this.otpAction = otpAction;
    return this;
  }

  /**
   * The OTP step that was processed.
   * @return otpAction
   **/
  
  @Schema(description = "The OTP step that was processed.")
  
  public OtpActionEnum getOtpAction() {  
    return otpAction;
  }



  public void setOtpAction(OtpActionEnum otpAction) { 
    this.otpAction = otpAction;
  }

  public RescheduleResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the rescheduled appointment.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the rescheduled appointment.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public RescheduleResponse otpStatus(OtpStatusEnum otpStatus) { 

    this.otpStatus = otpStatus;
    return this;
  }

  /**
   * Result of the OTP action.
   * @return otpStatus
   **/
  
  @Schema(description = "Result of the OTP action.")
  
  public OtpStatusEnum getOtpStatus() {  
    return otpStatus;
  }



  public void setOtpStatus(OtpStatusEnum otpStatus) { 
    this.otpStatus = otpStatus;
  }

  public RescheduleResponse status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  public RescheduleResponse updatedAt(OffsetDateTime updatedAt) { 

    this.updatedAt = updatedAt;
    return this;
  }

  /**
   * Timestamp when the appointment slot was updated.
   * @return updatedAt
   **/
  
  @Schema(description = "Timestamp when the appointment slot was updated.")
  
@Valid
  public OffsetDateTime getUpdatedAt() {  
    return updatedAt;
  }



  public void setUpdatedAt(OffsetDateTime updatedAt) { 
    this.updatedAt = updatedAt;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RescheduleResponse rescheduleResponse = (RescheduleResponse) o;
    return Objects.equals(this.newPickupDateTime, rescheduleResponse.newPickupDateTime) &&
        Objects.equals(this.otpAction, rescheduleResponse.otpAction) &&
        Objects.equals(this.appointmentId, rescheduleResponse.appointmentId) &&
        Objects.equals(this.otpStatus, rescheduleResponse.otpStatus) &&
        Objects.equals(this.status, rescheduleResponse.status) &&
        Objects.equals(this.updatedAt, rescheduleResponse.updatedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(newPickupDateTime, otpAction, appointmentId, otpStatus, status, updatedAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RescheduleResponse {\n");
    
    sb.append("    newPickupDateTime: ").append(toIndentedString(newPickupDateTime)).append("\n");
    sb.append("    otpAction: ").append(toIndentedString(otpAction)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    otpStatus: ").append(toIndentedString(otpStatus)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

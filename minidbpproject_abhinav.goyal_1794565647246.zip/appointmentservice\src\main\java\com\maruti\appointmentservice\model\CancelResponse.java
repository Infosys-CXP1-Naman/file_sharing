package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AppointmentStatus;
import com.maruti.appointmentservice.model.CancellationRecord;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * CancelResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class CancelResponse   {
  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("cancellationRecord")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private CancellationRecord cancellationRecord = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;


  public CancelResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the cancelled appointment.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the cancelled appointment.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public CancelResponse cancellationRecord(CancellationRecord cancellationRecord) { 

    this.cancellationRecord = cancellationRecord;
    return this;
  }

  /**
   * Get cancellationRecord
   * @return cancellationRecord
   **/
  
  @Schema(description = "")
  
@Valid
  public CancellationRecord getCancellationRecord() {  
    return cancellationRecord;
  }



  public void setCancellationRecord(CancellationRecord cancellationRecord) { 
    this.cancellationRecord = cancellationRecord;
  }

  public CancelResponse status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CancelResponse cancelResponse = (CancelResponse) o;
    return Objects.equals(this.appointmentId, cancelResponse.appointmentId) &&
        Objects.equals(this.cancellationRecord, cancelResponse.cancellationRecord) &&
        Objects.equals(this.status, cancelResponse.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentId, cancellationRecord, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CancelResponse {\n");
    
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    cancellationRecord: ").append(toIndentedString(cancellationRecord)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AllocationStatus;
import com.maruti.appointmentservice.model.AppointmentStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AppointmentUpdateRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AppointmentUpdateRequest   {
  @JsonProperty("linkedJobCardId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String linkedJobCardId = null;

  @JsonProperty("eta")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime eta = null;

  @JsonProperty("exceptionFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean exceptionFlag = null;

  @JsonProperty("promisedDeliveryTime")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime promisedDeliveryTime = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;


  public AppointmentUpdateRequest linkedJobCardId(String linkedJobCardId) { 

    this.linkedJobCardId = linkedJobCardId;
    return this;
  }

  /**
   * Identifier of the Job Card (JC) linked to this appointment in the workshop management system.
   * @return linkedJobCardId
   **/
  
  @Schema(description = "Identifier of the Job Card (JC) linked to this appointment in the workshop management system.")
  
  public String getLinkedJobCardId() {  
    return linkedJobCardId;
  }



  public void setLinkedJobCardId(String linkedJobCardId) { 
    this.linkedJobCardId = linkedJobCardId;
  }

  public AppointmentUpdateRequest eta(OffsetDateTime eta) { 

    this.eta = eta;
    return this;
  }

  /**
   * Updated estimated time of arrival for the chauffeur at the pickup location.
   * @return eta
   **/
  
  @Schema(example = "2025-06-15T09:15+05:30", description = "Updated estimated time of arrival for the chauffeur at the pickup location.")
  
@Valid
  public OffsetDateTime getEta() {  
    return eta;
  }



  public void setEta(OffsetDateTime eta) { 
    this.eta = eta;
  }

  public AppointmentUpdateRequest exceptionFlag(Boolean exceptionFlag) { 

    this.exceptionFlag = exceptionFlag;
    return this;
  }

  /**
   * Indicates whether this appointment is currently flagged as an exception requiring coordinator attention.
   * @return exceptionFlag
   **/
  
  @Schema(description = "Indicates whether this appointment is currently flagged as an exception requiring coordinator attention.")
  
  public Boolean isExceptionFlag() {  
    return exceptionFlag;
  }



  public void setExceptionFlag(Boolean exceptionFlag) { 
    this.exceptionFlag = exceptionFlag;
  }

  public AppointmentUpdateRequest promisedDeliveryTime(OffsetDateTime promisedDeliveryTime) { 

    this.promisedDeliveryTime = promisedDeliveryTime;
    return this;
  }

  /**
   * Promised vehicle delivery time communicated to the customer.
   * @return promisedDeliveryTime
   **/
  
  @Schema(example = "2025-06-16T17:00+05:30", description = "Promised vehicle delivery time communicated to the customer.")
  
@Valid
  public OffsetDateTime getPromisedDeliveryTime() {  
    return promisedDeliveryTime;
  }



  public void setPromisedDeliveryTime(OffsetDateTime promisedDeliveryTime) { 
    this.promisedDeliveryTime = promisedDeliveryTime;
  }

  public AppointmentUpdateRequest allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  public AppointmentUpdateRequest status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppointmentUpdateRequest appointmentUpdateRequest = (AppointmentUpdateRequest) o;
    return Objects.equals(this.linkedJobCardId, appointmentUpdateRequest.linkedJobCardId) &&
        Objects.equals(this.eta, appointmentUpdateRequest.eta) &&
        Objects.equals(this.exceptionFlag, appointmentUpdateRequest.exceptionFlag) &&
        Objects.equals(this.promisedDeliveryTime, appointmentUpdateRequest.promisedDeliveryTime) &&
        Objects.equals(this.allocationStatus, appointmentUpdateRequest.allocationStatus) &&
        Objects.equals(this.status, appointmentUpdateRequest.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(linkedJobCardId, eta, exceptionFlag, promisedDeliveryTime, allocationStatus, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppointmentUpdateRequest {\n");
    
    sb.append("    linkedJobCardId: ").append(toIndentedString(linkedJobCardId)).append("\n");
    sb.append("    eta: ").append(toIndentedString(eta)).append("\n");
    sb.append("    exceptionFlag: ").append(toIndentedString(exceptionFlag)).append("\n");
    sb.append("    promisedDeliveryTime: ").append(toIndentedString(promisedDeliveryTime)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

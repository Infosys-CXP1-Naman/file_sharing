package com.maruti.appointmentservice.exception;



/**
* @author ICNDP
* @version 1.0
*/

public class EntityNotFoundException extends RuntimeException {
    
    private static final long serialVersionUID = 1463413981916388999L;
    public EntityNotFoundException(String e) {
        super(e);
    }   
    public EntityNotFoundException(Exception e)  {
        super(e);
    }
}

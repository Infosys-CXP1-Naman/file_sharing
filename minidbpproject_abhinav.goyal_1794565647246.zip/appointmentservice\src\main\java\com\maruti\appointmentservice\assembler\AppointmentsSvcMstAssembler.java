package com.maruti.appointmentservice.assembler;
import java.util.Optional;
import org.modelmapper.ModelMapper;
import com.maruti.appointmentservice.model.AppointmentsSvcMst;
import com.maruti.appointmentservice.dto.AppointmentsSvcMstDto;
import org.springframework.stereotype.Component;

/**
* @author ICNDP
* @version 1.0
*/




@Component
public class AppointmentsSvcMstAssembler {

    public AppointmentsSvcMstAssembler(){
		//do nothing

	}

	
	/**
	* @param appointmentssvcmst
	* @return AppointmentsSvcMstDto
	*/
    public AppointmentsSvcMstDto entityToDto(AppointmentsSvcMst appointmentssvcmst) {
	
		ModelMapper modelMapper = new ModelMapper();
		AppointmentsSvcMstDto appointmentssvcmstdto = modelMapper.map(appointmentssvcmst, AppointmentsSvcMstDto.class);
		return appointmentssvcmstdto;
	}

	/**
	* @param appointmentssvcmst
	* @return AppointmentsSvcMstDto
	*/
    public AppointmentsSvcMstDto entityToDto(Optional<AppointmentsSvcMst> appointmentssvcmst) {
	
		ModelMapper modelMapper = new ModelMapper();
		AppointmentsSvcMstDto appointmentssvcmstdto = modelMapper.map(appointmentssvcmst.isPresent() ? appointmentssvcmst.get(): null, AppointmentsSvcMstDto.class);
		return appointmentssvcmstdto;
	}
    
}




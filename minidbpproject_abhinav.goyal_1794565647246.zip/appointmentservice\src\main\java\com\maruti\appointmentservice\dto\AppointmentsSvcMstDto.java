package com.maruti.appointmentservice.dto;

import java.util.*;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import lombok.Data;

 


/**
* @author ICNDP
* @version 1.0
*/

@Data
public class AppointmentsSvcMstDto {

  
    private uuid id;

  
    private String customerName; 

  
    private String contactNumber; 

  
    private String registrationNumber; 

  
    private String vin; 

  
    private String pickUpLocation; 

  
    private Date pickUpDate;
    

  
    private LocalTime pickUpTime; 

  
    private String dropLocation; 

  
    private Date dropDate;
    

  
    private LocalTime dropTime; 

  
    private uuid assignedDriverId;

  
    private String status; 

  
    private uuid qrCodeId;

  
    private int reschedulingCount;

  
    private uuid cceUserId;

  
    private String dealershipCode; 

  
    private String notes; 

  
    private boolean isDeleted;

  
    private int version;

  
    private LocalDateTime createdAt; 

  
    private LocalDateTime updatedAt; 
}

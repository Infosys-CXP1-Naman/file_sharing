package com.maruti.appointmentservice.service;

import com.maruti.appointmentservice.dto.AppointmentsSvcMstDto;
import com.maruti.appointmentservice.repository.AppointmentsSvcMstRepository;
import com.maruti.appointmentservice.assembler.AppointmentsSvcMstAssembler;
import com.maruti.appointmentservice.model.AppointmentsSvcMst;
import java.util.*;
import java.math.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
* @author ICNDP
* @version 1.0
*/

@Service
public class AppointmentsSvcMstServiceImpl implements AppointmentsSvcMstService {
     @Autowired
     private AppointmentsSvcMstRepository appointmentssvcmstrepository;
     
     @Autowired
     private AppointmentsSvcMstAssembler appointmentssvcmstAssembler;

                                                                                                                                                                                
     @Override
     public Optional<AppointmentsSvcMstDto> getAppointments_svc_mst(Integer appointments_svc_mstidId) throws Exception {
      
        
         return Optional.of(appointmentssvcmstAssembler.entityToDto(appointmentssvcmstrepository.findById(appointments_svc_mstidId)));
     }

     

                                                                                                                                                                                
     @Override
     public List<AppointmentsSvcMst> getallAppointments_svc_mst() throws Exception {
      
        
         return (List<AppointmentsSvcMst>)appointmentssvcmstrepository.findAll();
     }

     

                                                                                                                                                                                
     @Override
     public AppointmentsSvcMstDto postAppointments_svc_mst(AppointmentsSvcMst appointments_svc_mstobject) throws Exception {
      return appointmentssvcmstAssembler.entityToDto(appointmentssvcmstrepository.save(appointments_svc_mstobject));
        
        
     }

     

                                                                                                                                                                                
     @Override
     public AppointmentsSvcMstDto putAppointments_svc_mst(AppointmentsSvcMst appointments_svc_mstobject) throws Exception {
      return appointmentssvcmstAssembler.entityToDto(appointmentssvcmstrepository.save(appointments_svc_mstobject));
        
        
     }

     

                                                                                                                                                                                
     @Override
     public void deleteAppointments_svc_mst(Integer appointments_svc_mstidId) throws Exception {
      
        appointmentssvcmstrepository.deleteById(appointments_svc_mstidId); 
        
     }

     
}

package com.maruti.appointmentservice.controller;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyInt;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.http.MediaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import static org.hamcrest.Matchers.hasSize;
import com.maruti.appointmentservice.dto.AppointmentsSvcMstDto;
import com.maruti.appointmentservice.model.AppointmentsSvcMst;
import com.maruti.appointmentservice.service.AppointmentsSvcMstService;
 

/**
* Test class for the AppointmentsSvcMst REST controller.
*
* @see AppointmentsSvcMst
* @author ICNDP
* @version 1.0
*/

@AutoConfigureMockMvc
@SpringBootTest(classes = AppointmentsSvcMstController.class)
public class AppointmentsSvcMstTest {
        
    @Autowired
    private MockMvc mockMvc;

    @Mock
    private AppointmentsSvcMstService appointmentssvcmstService;

    @InjectMocks
    private AppointmentsSvcMstController appointmentssvcmstController;


    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    

    /**
    * Test getAppointments_svc_mst
    */

      @Test
       void getAppointments_svc_mst() throws Exception {

          when(appointmentssvcmstService.getAppointments_svc_mst(anyInt())).thenReturn(Optional.of(new AppointmentsSvcMstDto()));
          mockMvc.perform(MockMvcRequestBuilders.get("/api/appointmentssvcmst/1")
                  .contentType(MediaType.APPLICATION_JSON))
                  .andExpect(MockMvcResultMatchers.status().isOk())
                  .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));
      }

    /**
    * Test getallAppointments_svc_mst
    */

      @Test
       void getallAppointments_svc_mst() throws Exception {

                List<AppointmentsSvcMst> appointmentssvcmstList = new ArrayList<>();
                when(appointmentssvcmstService.getallAppointments_svc_mst()).thenReturn(appointmentssvcmstList);
                mockMvc.perform(MockMvcRequestBuilders.get("/api/appointmentssvcmst")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(MockMvcResultMatchers.status().isOk())
                        .andExpect(MockMvcResultMatchers.jsonPath("$", hasSize(appointmentssvcmstList.size())));
      }

    /**
    * Test postAppointments_svc_mst
    */

      @Test
       void postAppointments_svc_mst() throws Exception {

          when(appointmentssvcmstService.postAppointments_svc_mst(any(AppointmentsSvcMst.class))).thenReturn(new AppointmentsSvcMstDto());

          mockMvc.perform(MockMvcRequestBuilders.post("/api/appointmentssvcmst")
                  .contentType(MediaType.APPLICATION_JSON)
                  .content(new ObjectMapper().writeValueAsString(new AppointmentsSvcMst())))
                  .andExpect(MockMvcResultMatchers.status().isCreated())
                  .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));
      }

    /**
    * Test putAppointments_svc_mst
    */

      @Test
       void putAppointments_svc_mst() throws Exception {

          when(appointmentssvcmstService.putAppointments_svc_mst(any(AppointmentsSvcMst.class))).thenReturn(new AppointmentsSvcMstDto());

          mockMvc.perform(MockMvcRequestBuilders.put("/api/appointmentssvcmst/1")
                  .contentType(MediaType.APPLICATION_JSON)
                  .content(new ObjectMapper().writeValueAsString(new AppointmentsSvcMst())))
                  .andExpect(MockMvcResultMatchers.status().isOk())
                  .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));
      }

    /**
    * Test deleteAppointments_svc_mst
    */

      @Test
       void deleteAppointments_svc_mst() throws Exception {

          mockMvc.perform(MockMvcRequestBuilders.delete("/api/appointmentssvcmst/1")
                  .contentType(MediaType.APPLICATION_JSON))
                  .andExpect(MockMvcResultMatchers.status().isNoContent());
      }



}

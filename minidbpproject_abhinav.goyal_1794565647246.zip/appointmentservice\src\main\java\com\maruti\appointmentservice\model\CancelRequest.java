package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * CancelRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class CancelRequest   {
  @JsonProperty("cancellationReason")

  private String cancellationReason = null;

  /**
   * Entity or channel that confirmed or initiated the cancellation.
   */
  public enum ConfirmationSourceEnum {
    CUSTOMER("Customer"),
    
    COORDINATOR("Coordinator"),
    
    SYSTEM("System"),
    
    DEALERSHIP("Dealership");

    private String value;

    ConfirmationSourceEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ConfirmationSourceEnum fromValue(String text) {
      for (ConfirmationSourceEnum b : ConfirmationSourceEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("confirmationSource")

  private ConfirmationSourceEnum confirmationSource = null;

  @JsonProperty("additionalNotes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String additionalNotes = null;


  public CancelRequest cancellationReason(String cancellationReason) { 

    this.cancellationReason = cancellationReason;
    return this;
  }

  /**
   * Reason for cancelling the appointment.
   * @return cancellationReason
   **/
  
  @Schema(required = true, description = "Reason for cancelling the appointment.")
  
  @NotNull
  public String getCancellationReason() {  
    return cancellationReason;
  }



  public void setCancellationReason(String cancellationReason) { 

    this.cancellationReason = cancellationReason;
  }

  public CancelRequest confirmationSource(ConfirmationSourceEnum confirmationSource) { 

    this.confirmationSource = confirmationSource;
    return this;
  }

  /**
   * Entity or channel that confirmed or initiated the cancellation.
   * @return confirmationSource
   **/
  
  @Schema(required = true, description = "Entity or channel that confirmed or initiated the cancellation.")
  
  @NotNull
  public ConfirmationSourceEnum getConfirmationSource() {  
    return confirmationSource;
  }



  public void setConfirmationSource(ConfirmationSourceEnum confirmationSource) { 

    this.confirmationSource = confirmationSource;
  }

  public CancelRequest additionalNotes(String additionalNotes) { 

    this.additionalNotes = additionalNotes;
    return this;
  }

  /**
   * Optional additional context about the cancellation.
   * @return additionalNotes
   **/
  
  @Schema(description = "Optional additional context about the cancellation.")
  
  public String getAdditionalNotes() {  
    return additionalNotes;
  }



  public void setAdditionalNotes(String additionalNotes) { 
    this.additionalNotes = additionalNotes;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CancelRequest cancelRequest = (CancelRequest) o;
    return Objects.equals(this.cancellationReason, cancelRequest.cancellationReason) &&
        Objects.equals(this.confirmationSource, cancelRequest.confirmationSource) &&
        Objects.equals(this.additionalNotes, cancelRequest.additionalNotes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(cancellationReason, confirmationSource, additionalNotes);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CancelRequest {\n");
    
    sb.append("    cancellationReason: ").append(toIndentedString(cancellationReason)).append("\n");
    sb.append("    confirmationSource: ").append(toIndentedString(confirmationSource)).append("\n");
    sb.append("    additionalNotes: ").append(toIndentedString(additionalNotes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

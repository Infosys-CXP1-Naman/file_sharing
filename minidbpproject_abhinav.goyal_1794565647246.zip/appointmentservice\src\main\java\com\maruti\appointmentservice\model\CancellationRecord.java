package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * CancellationRecord
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class CancellationRecord   {
  @JsonProperty("cancellationReason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String cancellationReason = null;

  @JsonProperty("confirmationSource")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String confirmationSource = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("cancelledAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime cancelledAt = null;

  @JsonProperty("cancelledBy")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String cancelledBy = null;

  @JsonProperty("cancellationId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String cancellationId = null;


  public CancellationRecord cancellationReason(String cancellationReason) { 

    this.cancellationReason = cancellationReason;
    return this;
  }

  /**
   * Reason recorded for the cancellation.
   * @return cancellationReason
   **/
  
  @Schema(description = "Reason recorded for the cancellation.")
  
  public String getCancellationReason() {  
    return cancellationReason;
  }



  public void setCancellationReason(String cancellationReason) { 
    this.cancellationReason = cancellationReason;
  }

  public CancellationRecord confirmationSource(String confirmationSource) { 

    this.confirmationSource = confirmationSource;
    return this;
  }

  /**
   * Entity or channel that confirmed the cancellation.
   * @return confirmationSource
   **/
  
  @Schema(description = "Entity or channel that confirmed the cancellation.")
  
  public String getConfirmationSource() {  
    return confirmationSource;
  }



  public void setConfirmationSource(String confirmationSource) { 
    this.confirmationSource = confirmationSource;
  }

  public CancellationRecord appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment that was cancelled.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment that was cancelled.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public CancellationRecord cancelledAt(OffsetDateTime cancelledAt) { 

    this.cancelledAt = cancelledAt;
    return this;
  }

  /**
   * Timestamp when the appointment was cancelled.
   * @return cancelledAt
   **/
  
  @Schema(description = "Timestamp when the appointment was cancelled.")
  
@Valid
  public OffsetDateTime getCancelledAt() {  
    return cancelledAt;
  }



  public void setCancelledAt(OffsetDateTime cancelledAt) { 
    this.cancelledAt = cancelledAt;
  }

  public CancellationRecord cancelledBy(String cancelledBy) { 

    this.cancelledBy = cancelledBy;
    return this;
  }

  /**
   * Identifier of the user or system actor who performed the cancellation.
   * @return cancelledBy
   **/
  
  @Schema(description = "Identifier of the user or system actor who performed the cancellation.")
  
  public String getCancelledBy() {  
    return cancelledBy;
  }



  public void setCancelledBy(String cancelledBy) { 
    this.cancelledBy = cancelledBy;
  }

  public CancellationRecord cancellationId(String cancellationId) { 

    this.cancellationId = cancellationId;
    return this;
  }

  /**
   * Unique identifier of the cancellation record.
   * @return cancellationId
   **/
  
  @Schema(description = "Unique identifier of the cancellation record.")
  
  public String getCancellationId() {  
    return cancellationId;
  }



  public void setCancellationId(String cancellationId) { 
    this.cancellationId = cancellationId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CancellationRecord cancellationRecord = (CancellationRecord) o;
    return Objects.equals(this.cancellationReason, cancellationRecord.cancellationReason) &&
        Objects.equals(this.confirmationSource, cancellationRecord.confirmationSource) &&
        Objects.equals(this.appointmentId, cancellationRecord.appointmentId) &&
        Objects.equals(this.cancelledAt, cancellationRecord.cancelledAt) &&
        Objects.equals(this.cancelledBy, cancellationRecord.cancelledBy) &&
        Objects.equals(this.cancellationId, cancellationRecord.cancellationId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(cancellationReason, confirmationSource, appointmentId, cancelledAt, cancelledBy, cancellationId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CancellationRecord {\n");
    
    sb.append("    cancellationReason: ").append(toIndentedString(cancellationReason)).append("\n");
    sb.append("    confirmationSource: ").append(toIndentedString(confirmationSource)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    cancelledAt: ").append(toIndentedString(cancelledAt)).append("\n");
    sb.append("    cancelledBy: ").append(toIndentedString(cancelledBy)).append("\n");
    sb.append("    cancellationId: ").append(toIndentedString(cancellationId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

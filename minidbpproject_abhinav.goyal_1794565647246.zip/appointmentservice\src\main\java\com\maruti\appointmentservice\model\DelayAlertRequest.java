package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * DelayAlertRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class DelayAlertRequest   {
  @JsonProperty("delayDurationMinutes")

  private Integer delayDurationMinutes = null;

  @JsonProperty("delayReason")

  private String delayReason = null;

  @JsonProperty("currentEta")

  private OffsetDateTime currentEta = null;


  public DelayAlertRequest delayDurationMinutes(Integer delayDurationMinutes) { 

    this.delayDurationMinutes = delayDurationMinutes;
    return this;
  }

  /**
   * Duration of the delay in minutes relative to the original scheduled pickup time.
   * @return delayDurationMinutes
   **/
  
  @Schema(example = "45", required = true, description = "Duration of the delay in minutes relative to the original scheduled pickup time.")
  
  @NotNull
  public Integer getDelayDurationMinutes() {  
    return delayDurationMinutes;
  }



  public void setDelayDurationMinutes(Integer delayDurationMinutes) { 

    this.delayDurationMinutes = delayDurationMinutes;
  }

  public DelayAlertRequest delayReason(String delayReason) { 

    this.delayReason = delayReason;
    return this;
  }

  /**
   * Coordinator-entered reason explaining the cause of the pre-pickup delay.
   * @return delayReason
   **/
  
  @Schema(required = true, description = "Coordinator-entered reason explaining the cause of the pre-pickup delay.")
  
  @NotNull
  public String getDelayReason() {  
    return delayReason;
  }



  public void setDelayReason(String delayReason) { 

    this.delayReason = delayReason;
  }

  public DelayAlertRequest currentEta(OffsetDateTime currentEta) { 

    this.currentEta = currentEta;
    return this;
  }

  /**
   * Revised estimated time of arrival for the chauffeur reflecting the detected delay.
   * @return currentEta
   **/
  
  @Schema(example = "2025-06-15T10:15+05:30", required = true, description = "Revised estimated time of arrival for the chauffeur reflecting the detected delay.")
  
@Valid
  @NotNull
  public OffsetDateTime getCurrentEta() {  
    return currentEta;
  }



  public void setCurrentEta(OffsetDateTime currentEta) { 

    this.currentEta = currentEta;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DelayAlertRequest delayAlertRequest = (DelayAlertRequest) o;
    return Objects.equals(this.delayDurationMinutes, delayAlertRequest.delayDurationMinutes) &&
        Objects.equals(this.delayReason, delayAlertRequest.delayReason) &&
        Objects.equals(this.currentEta, delayAlertRequest.currentEta);
  }

  @Override
  public int hashCode() {
    return Objects.hash(delayDurationMinutes, delayReason, currentEta);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DelayAlertRequest {\n");
    
    sb.append("    delayDurationMinutes: ").append(toIndentedString(delayDurationMinutes)).append("\n");
    sb.append("    delayReason: ").append(toIndentedString(delayReason)).append("\n");
    sb.append("    currentEta: ").append(toIndentedString(currentEta)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

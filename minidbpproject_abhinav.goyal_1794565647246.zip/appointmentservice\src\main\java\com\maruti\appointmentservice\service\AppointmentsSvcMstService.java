package com.maruti.appointmentservice.service;

import com.maruti.appointmentservice.dto.AppointmentsSvcMstDto;
import com.maruti.appointmentservice.model.AppointmentsSvcMst;
import java.util.*;
import java.math.*;


/**
* @author ICNDP
* @version 1.0
*/

public interface AppointmentsSvcMstService {
                                                                                                                                                                                
        /**
        * @param AppointmentsSvcMstIdentity
        * @return AppointmentsSvcMstDto
        * @throws Exception
        */
        public Optional<AppointmentsSvcMstDto> getAppointments_svc_mst(Integer appointments_svc_mstidId) throws Exception;
    
                                                                                                                                                                                
        /**
        
        
        * @throws Exception
        */
         public List<AppointmentsSvcMst> getallAppointments_svc_mst() throws Exception;
    
                                                                                                                                                                                
        /**
        * @param AppointmentsSvcMstObject
        * @return AppointmentsSvcMstDto
        * @throws Exception
        */
         public AppointmentsSvcMstDto postAppointments_svc_mst(AppointmentsSvcMst appointments_svc_mstobject) throws Exception;
    
                                                                                                                                                                                
        /**
        * @param AppointmentsSvcMstObject
        * @return AppointmentsSvcMstDto
        * @throws Exception
        */
         public AppointmentsSvcMstDto putAppointments_svc_mst(AppointmentsSvcMst appointments_svc_mstobject) throws Exception;
    
                                                                                                                                                                                
        /**
        * @param AppointmentsSvcMstIdentity
        * @return void
        * @throws Exception
        */
         public void deleteAppointments_svc_mst(Integer appointments_svc_mstidId) throws Exception;
    
}

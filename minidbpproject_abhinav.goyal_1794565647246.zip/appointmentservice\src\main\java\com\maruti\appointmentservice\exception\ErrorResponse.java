package com.maruti.appointmentservice.exception;

import java.io.Serializable;



/**
* @author ICNDP
* @version 1.0
*/

public class ErrorResponse implements Serializable {
   private static final long serialVersionUID = 1L;
   private final String message;
   private final String description;

   public ErrorResponse(String description, String message) {
       this.message = message;
       this.description = description;
   }

   /**
    * @return String
   */
   public String getMessage() {
       return message;
   }

   /**
    * @return String
   */
   public String getDescription() {
       return description;
   }
}

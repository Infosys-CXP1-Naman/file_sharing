package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ChauffeurSelectionRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ChauffeurSelectionRequest   {
  /**
   * Indicates whether the coordinator accepted the system recommendation or manually overrode it.
   */
  public enum SelectionTypeEnum {
    CONFIRMED("Confirmed"),
    
    OVERRIDDEN("Overridden");

    private String value;

    SelectionTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static SelectionTypeEnum fromValue(String text) {
      for (SelectionTypeEnum b : SelectionTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("selectionType")

  private SelectionTypeEnum selectionType = null;

  @JsonProperty("overrideReason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String overrideReason = null;

  @JsonProperty("chauffeurId")

  private String chauffeurId = null;


  public ChauffeurSelectionRequest selectionType(SelectionTypeEnum selectionType) { 

    this.selectionType = selectionType;
    return this;
  }

  /**
   * Indicates whether the coordinator accepted the system recommendation or manually overrode it.
   * @return selectionType
   **/
  
  @Schema(required = true, description = "Indicates whether the coordinator accepted the system recommendation or manually overrode it.")
  
  @NotNull
  public SelectionTypeEnum getSelectionType() {  
    return selectionType;
  }



  public void setSelectionType(SelectionTypeEnum selectionType) { 

    this.selectionType = selectionType;
  }

  public ChauffeurSelectionRequest overrideReason(String overrideReason) { 

    this.overrideReason = overrideReason;
    return this;
  }

  /**
   * Mandatory justification when selectionType is 'Overridden'; explains why the recommended chauffeur was not selected.
   * @return overrideReason
   **/
  
  @Schema(description = "Mandatory justification when selectionType is 'Overridden'; explains why the recommended chauffeur was not selected.")
  
  public String getOverrideReason() {  
    return overrideReason;
  }



  public void setOverrideReason(String overrideReason) { 
    this.overrideReason = overrideReason;
  }

  public ChauffeurSelectionRequest chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur being confirmed or selected as an override.
   * @return chauffeurId
   **/
  
  @Schema(required = true, description = "Identifier of the chauffeur being confirmed or selected as an override.")
  
  @NotNull
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChauffeurSelectionRequest chauffeurSelectionRequest = (ChauffeurSelectionRequest) o;
    return Objects.equals(this.selectionType, chauffeurSelectionRequest.selectionType) &&
        Objects.equals(this.overrideReason, chauffeurSelectionRequest.overrideReason) &&
        Objects.equals(this.chauffeurId, chauffeurSelectionRequest.chauffeurId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(selectionType, overrideReason, chauffeurId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChauffeurSelectionRequest {\n");
    
    sb.append("    selectionType: ").append(toIndentedString(selectionType)).append("\n");
    sb.append("    overrideReason: ").append(toIndentedString(overrideReason)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AssignmentHistoryEntry
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AssignmentHistoryEntry   {
  @JsonProperty("attemptNumber")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer attemptNumber = null;

  @JsonProperty("reason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String reason = null;

  /**
   * Type of actor who performed the action.
   */
  public enum ActorTypeEnum {
    SYSTEM("System"),
    
    COORDINATOR("Coordinator"),
    
    CHAUFFEUR("Chauffeur");

    private String value;

    ActorTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActorTypeEnum fromValue(String text) {
      for (ActorTypeEnum b : ActorTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("actorType")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ActorTypeEnum actorType = null;

  @JsonProperty("actorId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String actorId = null;

  @JsonProperty("chauffeurName")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurName = null;

  /**
   * Action taken at this step.
   */
  public enum ActionEnum {
    RECOMMENDED("Recommended"),
    
    CONFIRMEDBYCOORDINATOR("ConfirmedByCoordinator"),
    
    OVERRIDDEN("Overridden"),
    
    DISPATCHED("Dispatched"),
    
    ACCEPTED("Accepted"),
    
    REJECTED("Rejected"),
    
    REASSIGNED("Reassigned");

    private String value;

    ActionEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ActionEnum fromValue(String text) {
      for (ActionEnum b : ActionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("action")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ActionEnum action = null;

  @JsonProperty("chauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurId = null;

  @JsonProperty("timestamp")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime timestamp = null;


  public AssignmentHistoryEntry attemptNumber(Integer attemptNumber) { 

    this.attemptNumber = attemptNumber;
    return this;
  }

  /**
   * Sequential attempt number, starting from 1.
   * @return attemptNumber
   **/
  
  @Schema(description = "Sequential attempt number, starting from 1.")
  
  public Integer getAttemptNumber() {  
    return attemptNumber;
  }



  public void setAttemptNumber(Integer attemptNumber) { 
    this.attemptNumber = attemptNumber;
  }

  public AssignmentHistoryEntry reason(String reason) { 

    this.reason = reason;
    return this;
  }

  /**
   * Reason provided for the action, if applicable (e.g. override reason, rejection reason).
   * @return reason
   **/
  
  @Schema(description = "Reason provided for the action, if applicable (e.g. override reason, rejection reason).")
  
  public String getReason() {  
    return reason;
  }



  public void setReason(String reason) { 
    this.reason = reason;
  }

  public AssignmentHistoryEntry actorType(ActorTypeEnum actorType) { 

    this.actorType = actorType;
    return this;
  }

  /**
   * Type of actor who performed the action.
   * @return actorType
   **/
  
  @Schema(description = "Type of actor who performed the action.")
  
  public ActorTypeEnum getActorType() {  
    return actorType;
  }



  public void setActorType(ActorTypeEnum actorType) { 
    this.actorType = actorType;
  }

  public AssignmentHistoryEntry actorId(String actorId) { 

    this.actorId = actorId;
    return this;
  }

  /**
   * Identifier of the actor who performed the action.
   * @return actorId
   **/
  
  @Schema(description = "Identifier of the actor who performed the action.")
  
  public String getActorId() {  
    return actorId;
  }



  public void setActorId(String actorId) { 
    this.actorId = actorId;
  }

  public AssignmentHistoryEntry chauffeurName(String chauffeurName) { 

    this.chauffeurName = chauffeurName;
    return this;
  }

  /**
   * Name of the chauffeur involved in this assignment attempt.
   * @return chauffeurName
   **/
  
  @Schema(description = "Name of the chauffeur involved in this assignment attempt.")
  
  public String getChauffeurName() {  
    return chauffeurName;
  }



  public void setChauffeurName(String chauffeurName) { 
    this.chauffeurName = chauffeurName;
  }

  public AssignmentHistoryEntry action(ActionEnum action) { 

    this.action = action;
    return this;
  }

  /**
   * Action taken at this step.
   * @return action
   **/
  
  @Schema(description = "Action taken at this step.")
  
  public ActionEnum getAction() {  
    return action;
  }



  public void setAction(ActionEnum action) { 
    this.action = action;
  }

  public AssignmentHistoryEntry chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur involved in this assignment attempt.
   * @return chauffeurId
   **/
  
  @Schema(description = "Identifier of the chauffeur involved in this assignment attempt.")
  
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 
    this.chauffeurId = chauffeurId;
  }

  public AssignmentHistoryEntry timestamp(OffsetDateTime timestamp) { 

    this.timestamp = timestamp;
    return this;
  }

  /**
   * Timestamp when this assignment action occurred.
   * @return timestamp
   **/
  
  @Schema(description = "Timestamp when this assignment action occurred.")
  
@Valid
  public OffsetDateTime getTimestamp() {  
    return timestamp;
  }



  public void setTimestamp(OffsetDateTime timestamp) { 
    this.timestamp = timestamp;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AssignmentHistoryEntry assignmentHistoryEntry = (AssignmentHistoryEntry) o;
    return Objects.equals(this.attemptNumber, assignmentHistoryEntry.attemptNumber) &&
        Objects.equals(this.reason, assignmentHistoryEntry.reason) &&
        Objects.equals(this.actorType, assignmentHistoryEntry.actorType) &&
        Objects.equals(this.actorId, assignmentHistoryEntry.actorId) &&
        Objects.equals(this.chauffeurName, assignmentHistoryEntry.chauffeurName) &&
        Objects.equals(this.action, assignmentHistoryEntry.action) &&
        Objects.equals(this.chauffeurId, assignmentHistoryEntry.chauffeurId) &&
        Objects.equals(this.timestamp, assignmentHistoryEntry.timestamp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(attemptNumber, reason, actorType, actorId, chauffeurName, action, chauffeurId, timestamp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AssignmentHistoryEntry {\n");
    
    sb.append("    attemptNumber: ").append(toIndentedString(attemptNumber)).append("\n");
    sb.append("    reason: ").append(toIndentedString(reason)).append("\n");
    sb.append("    actorType: ").append(toIndentedString(actorType)).append("\n");
    sb.append("    actorId: ").append(toIndentedString(actorId)).append("\n");
    sb.append("    chauffeurName: ").append(toIndentedString(chauffeurName)).append("\n");
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

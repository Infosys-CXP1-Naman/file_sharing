package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AllocationStatus;
import com.maruti.appointmentservice.model.AppointmentStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AppointmentSummary
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AppointmentSummary   {
  @JsonProperty("pickupDateTime")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime pickupDateTime = null;

  @JsonProperty("createdAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime createdAt = null;

  @JsonProperty("assignedChauffeurName")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String assignedChauffeurName = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("customerId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String customerId = null;

  @JsonProperty("exceptionFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean exceptionFlag = null;

  @JsonProperty("vehicleId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String vehicleId = null;

  @JsonProperty("assignedChauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String assignedChauffeurId = null;

  @JsonProperty("vehicleRegistration")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String vehicleRegistration = null;

  @JsonProperty("customerName")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String customerName = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;


  public AppointmentSummary pickupDateTime(OffsetDateTime pickupDateTime) { 

    this.pickupDateTime = pickupDateTime;
    return this;
  }

  /**
   * Scheduled pickup date and time.
   * @return pickupDateTime
   **/
  
  @Schema(description = "Scheduled pickup date and time.")
  
@Valid
  public OffsetDateTime getPickupDateTime() {  
    return pickupDateTime;
  }



  public void setPickupDateTime(OffsetDateTime pickupDateTime) { 
    this.pickupDateTime = pickupDateTime;
  }

  public AppointmentSummary createdAt(OffsetDateTime createdAt) { 

    this.createdAt = createdAt;
    return this;
  }

  /**
   * Timestamp when the appointment record was created.
   * @return createdAt
   **/
  
  @Schema(description = "Timestamp when the appointment record was created.")
  
@Valid
  public OffsetDateTime getCreatedAt() {  
    return createdAt;
  }



  public void setCreatedAt(OffsetDateTime createdAt) { 
    this.createdAt = createdAt;
  }

  public AppointmentSummary assignedChauffeurName(String assignedChauffeurName) { 

    this.assignedChauffeurName = assignedChauffeurName;
    return this;
  }

  /**
   * Display name of the currently assigned chauffeur, if any.
   * @return assignedChauffeurName
   **/
  
  @Schema(description = "Display name of the currently assigned chauffeur, if any.")
  
  public String getAssignedChauffeurName() {  
    return assignedChauffeurName;
  }



  public void setAssignedChauffeurName(String assignedChauffeurName) { 
    this.assignedChauffeurName = assignedChauffeurName;
  }

  public AppointmentSummary appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Unique identifier of the appointment.
   * @return appointmentId
   **/
  
  @Schema(description = "Unique identifier of the appointment.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public AppointmentSummary customerId(String customerId) { 

    this.customerId = customerId;
    return this;
  }

  /**
   * Unique identifier of the customer.
   * @return customerId
   **/
  
  @Schema(description = "Unique identifier of the customer.")
  
  public String getCustomerId() {  
    return customerId;
  }



  public void setCustomerId(String customerId) { 
    this.customerId = customerId;
  }

  public AppointmentSummary exceptionFlag(Boolean exceptionFlag) { 

    this.exceptionFlag = exceptionFlag;
    return this;
  }

  /**
   * Indicates whether this appointment is flagged as an exception.
   * @return exceptionFlag
   **/
  
  @Schema(description = "Indicates whether this appointment is flagged as an exception.")
  
  public Boolean isExceptionFlag() {  
    return exceptionFlag;
  }



  public void setExceptionFlag(Boolean exceptionFlag) { 
    this.exceptionFlag = exceptionFlag;
  }

  public AppointmentSummary vehicleId(String vehicleId) { 

    this.vehicleId = vehicleId;
    return this;
  }

  /**
   * Unique identifier of the vehicle.
   * @return vehicleId
   **/
  
  @Schema(description = "Unique identifier of the vehicle.")
  
  public String getVehicleId() {  
    return vehicleId;
  }



  public void setVehicleId(String vehicleId) { 
    this.vehicleId = vehicleId;
  }

  public AppointmentSummary assignedChauffeurId(String assignedChauffeurId) { 

    this.assignedChauffeurId = assignedChauffeurId;
    return this;
  }

  /**
   * Identifier of the currently assigned chauffeur, if any.
   * @return assignedChauffeurId
   **/
  
  @Schema(description = "Identifier of the currently assigned chauffeur, if any.")
  
  public String getAssignedChauffeurId() {  
    return assignedChauffeurId;
  }



  public void setAssignedChauffeurId(String assignedChauffeurId) { 
    this.assignedChauffeurId = assignedChauffeurId;
  }

  public AppointmentSummary vehicleRegistration(String vehicleRegistration) { 

    this.vehicleRegistration = vehicleRegistration;
    return this;
  }

  /**
   * Vehicle registration number.
   * @return vehicleRegistration
   **/
  
  @Schema(example = "MH12AB1234", description = "Vehicle registration number.")
  
  public String getVehicleRegistration() {  
    return vehicleRegistration;
  }



  public void setVehicleRegistration(String vehicleRegistration) { 
    this.vehicleRegistration = vehicleRegistration;
  }

  public AppointmentSummary customerName(String customerName) { 

    this.customerName = customerName;
    return this;
  }

  /**
   * Full name of the customer.
   * @return customerName
   **/
  
  @Schema(description = "Full name of the customer.")
  
  public String getCustomerName() {  
    return customerName;
  }



  public void setCustomerName(String customerName) { 
    this.customerName = customerName;
  }

  public AppointmentSummary allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  public AppointmentSummary status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppointmentSummary appointmentSummary = (AppointmentSummary) o;
    return Objects.equals(this.pickupDateTime, appointmentSummary.pickupDateTime) &&
        Objects.equals(this.createdAt, appointmentSummary.createdAt) &&
        Objects.equals(this.assignedChauffeurName, appointmentSummary.assignedChauffeurName) &&
        Objects.equals(this.appointmentId, appointmentSummary.appointmentId) &&
        Objects.equals(this.customerId, appointmentSummary.customerId) &&
        Objects.equals(this.exceptionFlag, appointmentSummary.exceptionFlag) &&
        Objects.equals(this.vehicleId, appointmentSummary.vehicleId) &&
        Objects.equals(this.assignedChauffeurId, appointmentSummary.assignedChauffeurId) &&
        Objects.equals(this.vehicleRegistration, appointmentSummary.vehicleRegistration) &&
        Objects.equals(this.customerName, appointmentSummary.customerName) &&
        Objects.equals(this.allocationStatus, appointmentSummary.allocationStatus) &&
        Objects.equals(this.status, appointmentSummary.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pickupDateTime, createdAt, assignedChauffeurName, appointmentId, customerId, exceptionFlag, vehicleId, assignedChauffeurId, vehicleRegistration, customerName, allocationStatus, status);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppointmentSummary {\n");
    
    sb.append("    pickupDateTime: ").append(toIndentedString(pickupDateTime)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    assignedChauffeurName: ").append(toIndentedString(assignedChauffeurName)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    customerId: ").append(toIndentedString(customerId)).append("\n");
    sb.append("    exceptionFlag: ").append(toIndentedString(exceptionFlag)).append("\n");
    sb.append("    vehicleId: ").append(toIndentedString(vehicleId)).append("\n");
    sb.append("    assignedChauffeurId: ").append(toIndentedString(assignedChauffeurId)).append("\n");
    sb.append("    vehicleRegistration: ").append(toIndentedString(vehicleRegistration)).append("\n");
    sb.append("    customerName: ").append(toIndentedString(customerName)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import io.swagger.v3.oas.annotations.media.Schema;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Current chauffeur allocation state for the appointment.
 */
public enum AllocationStatus {
  UNALLOCATED("Unallocated"),
    RECOMMENDATIONPENDING("RecommendationPending"),
    RECOMMENDED("Recommended"),
    CONFIRMEDBYCOORDINATOR("ConfirmedByCoordinator"),
    DISPATCHED("Dispatched"),
    ACCEPTED("Accepted"),
    REJECTED("Rejected"),
    REASSIGNING("Reassigning"),
    ALLOCATED("Allocated");

  private String value;

  AllocationStatus(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static AllocationStatus fromValue(String text) {
    for (AllocationStatus b : AllocationStatus.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}

package com.maruti.appointmentservice.exception;



/**
* @author ICNDP
* @version 1.0
*/

public class GenericHandler extends RuntimeException {

   private static final long serialVersionUID = 1463413981916388999L;

   public GenericHandler(String e) {
       super(e);
   }

   public GenericHandler(Exception e) {
       super(e);
   }

}
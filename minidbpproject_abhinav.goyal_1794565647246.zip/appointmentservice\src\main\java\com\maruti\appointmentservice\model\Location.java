package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Location
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class Location   {
  @JsonProperty("pincode")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String pincode = null;

  @JsonProperty("city")

  private String city = null;

  @JsonProperty("latitude")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Double latitude = null;

  @JsonProperty("addressLine1")

  private String addressLine1 = null;

  @JsonProperty("addressLine2")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String addressLine2 = null;

  @JsonProperty("state")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String state = null;

  @JsonProperty("longitude")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Double longitude = null;


  public Location pincode(String pincode) { 

    this.pincode = pincode;
    return this;
  }

  /**
   * Postal or ZIP code.
   * @return pincode
   **/
  
  @Schema(example = "400001", description = "Postal or ZIP code.")
  
  public String getPincode() {  
    return pincode;
  }



  public void setPincode(String pincode) { 
    this.pincode = pincode;
  }

  public Location city(String city) { 

    this.city = city;
    return this;
  }

  /**
   * City name.
   * @return city
   **/
  
  @Schema(required = true, description = "City name.")
  
  @NotNull
  public String getCity() {  
    return city;
  }



  public void setCity(String city) { 

    this.city = city;
  }

  public Location latitude(Double latitude) { 

    this.latitude = latitude;
    return this;
  }

  /**
   * Geographic latitude coordinate.
   * @return latitude
   **/
  
  @Schema(example = "19.076", description = "Geographic latitude coordinate.")
  
  public Double getLatitude() {  
    return latitude;
  }



  public void setLatitude(Double latitude) { 
    this.latitude = latitude;
  }

  public Location addressLine1(String addressLine1) { 

    this.addressLine1 = addressLine1;
    return this;
  }

  /**
   * Primary street address line.
   * @return addressLine1
   **/
  
  @Schema(required = true, description = "Primary street address line.")
  
  @NotNull
  public String getAddressLine1() {  
    return addressLine1;
  }



  public void setAddressLine1(String addressLine1) { 

    this.addressLine1 = addressLine1;
  }

  public Location addressLine2(String addressLine2) { 

    this.addressLine2 = addressLine2;
    return this;
  }

  /**
   * Secondary address line (apartment, suite, landmark, etc.).
   * @return addressLine2
   **/
  
  @Schema(description = "Secondary address line (apartment, suite, landmark, etc.).")
  
  public String getAddressLine2() {  
    return addressLine2;
  }



  public void setAddressLine2(String addressLine2) { 
    this.addressLine2 = addressLine2;
  }

  public Location state(String state) { 

    this.state = state;
    return this;
  }

  /**
   * State or province name.
   * @return state
   **/
  
  @Schema(description = "State or province name.")
  
  public String getState() {  
    return state;
  }



  public void setState(String state) { 
    this.state = state;
  }

  public Location longitude(Double longitude) { 

    this.longitude = longitude;
    return this;
  }

  /**
   * Geographic longitude coordinate.
   * @return longitude
   **/
  
  @Schema(example = "72.8777", description = "Geographic longitude coordinate.")
  
  public Double getLongitude() {  
    return longitude;
  }



  public void setLongitude(Double longitude) { 
    this.longitude = longitude;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Location location = (Location) o;
    return Objects.equals(this.pincode, location.pincode) &&
        Objects.equals(this.city, location.city) &&
        Objects.equals(this.latitude, location.latitude) &&
        Objects.equals(this.addressLine1, location.addressLine1) &&
        Objects.equals(this.addressLine2, location.addressLine2) &&
        Objects.equals(this.state, location.state) &&
        Objects.equals(this.longitude, location.longitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pincode, city, latitude, addressLine1, addressLine2, state, longitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Location {\n");
    
    sb.append("    pincode: ").append(toIndentedString(pincode)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    addressLine1: ").append(toIndentedString(addressLine1)).append("\n");
    sb.append("    addressLine2: ").append(toIndentedString(addressLine2)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

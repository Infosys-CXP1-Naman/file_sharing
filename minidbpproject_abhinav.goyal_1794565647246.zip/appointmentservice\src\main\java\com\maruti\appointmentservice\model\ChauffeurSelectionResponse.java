package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.maruti.appointmentservice.model.AllocationStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ChauffeurSelectionResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ChauffeurSelectionResponse   {
  /**
   * Whether the selection was a confirmation or an override.
   */
  public enum SelectionTypeEnum {
    CONFIRMED("Confirmed"),
    
    OVERRIDDEN("Overridden");

    private String value;

    SelectionTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static SelectionTypeEnum fromValue(String text) {
      for (SelectionTypeEnum b : SelectionTypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("selectionType")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private SelectionTypeEnum selectionType = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("recordedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime recordedAt = null;

  @JsonProperty("chauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurId = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;


  public ChauffeurSelectionResponse selectionType(SelectionTypeEnum selectionType) { 

    this.selectionType = selectionType;
    return this;
  }

  /**
   * Whether the selection was a confirmation or an override.
   * @return selectionType
   **/
  
  @Schema(description = "Whether the selection was a confirmation or an override.")
  
  public SelectionTypeEnum getSelectionType() {  
    return selectionType;
  }



  public void setSelectionType(SelectionTypeEnum selectionType) { 
    this.selectionType = selectionType;
  }

  public ChauffeurSelectionResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment for which the chauffeur was selected.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment for which the chauffeur was selected.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public ChauffeurSelectionResponse recordedAt(OffsetDateTime recordedAt) { 

    this.recordedAt = recordedAt;
    return this;
  }

  /**
   * Timestamp when the coordinator's selection was recorded.
   * @return recordedAt
   **/
  
  @Schema(description = "Timestamp when the coordinator's selection was recorded.")
  
@Valid
  public OffsetDateTime getRecordedAt() {  
    return recordedAt;
  }



  public void setRecordedAt(OffsetDateTime recordedAt) { 
    this.recordedAt = recordedAt;
  }

  public ChauffeurSelectionResponse chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the confirmed or overridden chauffeur.
   * @return chauffeurId
   **/
  
  @Schema(description = "Identifier of the confirmed or overridden chauffeur.")
  
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 
    this.chauffeurId = chauffeurId;
  }

  public ChauffeurSelectionResponse allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChauffeurSelectionResponse chauffeurSelectionResponse = (ChauffeurSelectionResponse) o;
    return Objects.equals(this.selectionType, chauffeurSelectionResponse.selectionType) &&
        Objects.equals(this.appointmentId, chauffeurSelectionResponse.appointmentId) &&
        Objects.equals(this.recordedAt, chauffeurSelectionResponse.recordedAt) &&
        Objects.equals(this.chauffeurId, chauffeurSelectionResponse.chauffeurId) &&
        Objects.equals(this.allocationStatus, chauffeurSelectionResponse.allocationStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(selectionType, appointmentId, recordedAt, chauffeurId, allocationStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChauffeurSelectionResponse {\n");
    
    sb.append("    selectionType: ").append(toIndentedString(selectionType)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    recordedAt: ").append(toIndentedString(recordedAt)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;  
import com.maruti.appointmentservice.model.AppointmentsSvcMst;
import com.maruti.appointmentservice.service.AppointmentsSvcMstService;
import com.maruti.appointmentservice.dto.AppointmentsSvcMstDto;
import com.maruti.appointmentservice.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.Optional;
import java.util.List;
import java.util.UUID;
import java.util.Date;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;
import java.net.URI;
import java.net.URISyntaxException;
  



 

/**
* @author ICNDP
* @version 1.0
*/

@RequestMapping("/api/appointmentsSvcMst")
 
@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AppointmentsSvcMstController {
   
    static Logger log = LoggerFactory.getLogger(AppointmentsSvcMstController.class);


    @Autowired
    private AppointmentsSvcMstService appointmentsSvcMstService;





    /**
    * GETAPPOINTMENTS_SVC_MST getAppointments_svc_mst
    */
    /**
    * @param appointments_svc_mstid
    * @return AppointmentsSvcMstDto
    * @throws Exception
    */
  
    @GetMapping("/appointmentssvcmst/{appointments_svc_mstidId}")
    public ResponseEntity<Optional<AppointmentsSvcMstDto>> getAppointments_svc_mst(@PathVariable Integer appointments_svc_mstidId)  throws Exception {
      log.info("AppointmentsSvcMstController --> Inside getAppointments_svc_mst method.");
      return ResponseEntity.ok(appointmentsSvcMstService.getAppointments_svc_mst(appointments_svc_mstidId));
    }


    /**
    * GETALLAPPOINTMENTS_SVC_MST getallAppointments_svc_mst
    */
    /**
    * @param appointments_svc_mstid
    * @return AppointmentsSvcMstDto
    * @throws Exception
    */
  
     
    @GetMapping("/appointmentssvcmst")
    public List<AppointmentsSvcMst> getallAppointments_svc_mst()  throws Exception {
        log.info("REST request to get all AppointmentsSvcMstDto");
        return appointmentsSvcMstService.getallAppointments_svc_mst();
    }


    /**
    * POSTAPPOINTMENTS_SVC_MST postAppointments_svc_mst
    */
    /**
    * @param appointments_svc_mstobject
    * @return AppointmentsSvcMstDto
    * @throws Exception
    */
  
    @PostMapping("/appointmentssvcmst")
    public ResponseEntity<AppointmentsSvcMstDto> postAppointments_svc_mst(@RequestBody AppointmentsSvcMst appointments_svc_mstobject)  throws Exception {
      log.info("REST request to save AppointmentsSvcMstDto : {}", appointments_svc_mstobject);

        return new ResponseEntity<AppointmentsSvcMstDto>(appointmentsSvcMstService.postAppointments_svc_mst(appointments_svc_mstobject), HttpStatus.CREATED);
    }


    /**
    * PUTAPPOINTMENTS_SVC_MST putAppointments_svc_mst
    */
    /**
    * @param appointments_svc_mstobject
    * @param appointments_svc_mstobjectId
    * @return AppointmentsSvcMstDto
    * @throws Exception
    */
  
    @PutMapping("/appointmentssvcmst/{appointments_svc_mstobjectId}")
    public ResponseEntity<AppointmentsSvcMstDto> putAppointments_svc_mst(@RequestBody AppointmentsSvcMst appointments_svc_mstobject, @PathVariable Integer appointments_svc_mstobjectId)  throws Exception {
      log.info("REST request to update Customer : {}", appointments_svc_mstobject);
      Optional<AppointmentsSvcMstDto> appointments_svc_mstObj = appointmentsSvcMstService.getAppointments_svc_mst(appointments_svc_mstobjectId);
      if (!appointments_svc_mstObj.isPresent())
        return new ResponseEntity<AppointmentsSvcMstDto>(HttpStatus.NOT_FOUND);
     
        appointments_svc_mstobject.setId(appointments_svc_mstobject.getId());
        appointments_svc_mstobject.setCustomerName(appointments_svc_mstobject.getCustomerName());
        appointments_svc_mstobject.setContactNumber(appointments_svc_mstobject.getContactNumber());
        appointments_svc_mstobject.setRegistrationNumber(appointments_svc_mstobject.getRegistrationNumber());
        appointments_svc_mstobject.setVin(appointments_svc_mstobject.getVin());
        appointments_svc_mstobject.setPickUpLocation(appointments_svc_mstobject.getPickUpLocation());
        appointments_svc_mstobject.setPickUpDate(appointments_svc_mstobject.getPickUpDate());
        appointments_svc_mstobject.setPickUpTime(appointments_svc_mstobject.getPickUpTime());
        appointments_svc_mstobject.setDropLocation(appointments_svc_mstobject.getDropLocation());
        appointments_svc_mstobject.setDropDate(appointments_svc_mstobject.getDropDate());
        appointments_svc_mstobject.setDropTime(appointments_svc_mstobject.getDropTime());
        appointments_svc_mstobject.setAssignedDriverId(appointments_svc_mstobject.getAssignedDriverId());
        appointments_svc_mstobject.setStatus(appointments_svc_mstobject.getStatus());
        appointments_svc_mstobject.setQrCodeId(appointments_svc_mstobject.getQrCodeId());
        appointments_svc_mstobject.setReschedulingCount(appointments_svc_mstobject.getReschedulingCount());
        appointments_svc_mstobject.setCceUserId(appointments_svc_mstobject.getCceUserId());
        appointments_svc_mstobject.setDealershipCode(appointments_svc_mstobject.getDealershipCode());
        appointments_svc_mstobject.setNotes(appointments_svc_mstobject.getNotes());
        appointments_svc_mstobject.setIsDeleted(appointments_svc_mstobject.isIsDeleted());
        appointments_svc_mstobject.setVersion(appointments_svc_mstobject.getVersion());
        appointments_svc_mstobject.setCreatedAt(appointments_svc_mstobject.getCreatedAt());
        appointments_svc_mstobject.setUpdatedAt(appointments_svc_mstobject.getUpdatedAt());

      
        return new ResponseEntity<AppointmentsSvcMstDto>(appointmentsSvcMstService.putAppointments_svc_mst(appointments_svc_mstobject),HttpStatus.OK);
    }


    /**
    * DELETEAPPOINTMENTS_SVC_MST deleteAppointments_svc_mst
    */
    /**
    * @param appointments_svc_mstid
    * @return AppointmentsSvcMstDto
    * @throws Exception
    */
  
    @DeleteMapping("/appointmentssvcmst/{appointments_svc_mstidId}")
    public ResponseEntity<AppointmentsSvcMstDto> deleteAppointments_svc_mst(@PathVariable Integer appointments_svc_mstidId)  throws Exception {
      log.info("REST request to delete AppointmentsSvcMst : {}", appointments_svc_mstidId);
      appointmentsSvcMstService.deleteAppointments_svc_mst(appointments_svc_mstidId);
      return new ResponseEntity<AppointmentsSvcMstDto>(HttpStatus.NO_CONTENT);
    }
}

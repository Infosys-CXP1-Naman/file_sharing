package com.maruti.appointmentservice.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;


@Configuration
public class SwaggerConfig {

	@Value("${springdoc.info.title}")
	private String title;

	@Value("${springdoc.info.version}")
	private String version;

	@Value("${springdoc.info.description}")
	private String description;
	
	@Bean
	GroupedOpenApi publicApi() {
		return GroupedOpenApi.builder()
				.group("public-apis")
				.pathsToMatch("/**")
				.build();
	}
	
	@Bean
	OpenAPI customOpenAPI() {
		return new OpenAPI()
				.info(new Info().title(title).description(description).version(version));
		
	}
}
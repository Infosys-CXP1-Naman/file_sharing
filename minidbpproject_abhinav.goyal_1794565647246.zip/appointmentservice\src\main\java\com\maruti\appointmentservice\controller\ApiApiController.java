package com.maruti.appointmentservice.controller;

import com.maruti.appointmentservice.model.AllocationStatus;
import com.maruti.appointmentservice.model.AppointmentCreateRequest;
import com.maruti.appointmentservice.model.AppointmentDetail;
import com.maruti.appointmentservice.model.AppointmentListResponse;
import com.maruti.appointmentservice.model.AppointmentStatus;
import com.maruti.appointmentservice.model.AppointmentUpdateRequest;
import com.maruti.appointmentservice.model.AssignmentResponseRequest;
import com.maruti.appointmentservice.model.AssignmentResponseResult;
import com.maruti.appointmentservice.model.CancelRequest;
import com.maruti.appointmentservice.model.CancelResponse;
import com.maruti.appointmentservice.model.ChauffeurSelectionRequest;
import com.maruti.appointmentservice.model.ChauffeurSelectionResponse;
import com.maruti.appointmentservice.model.ContactOutcomeRequest;
import com.maruti.appointmentservice.model.ContactOutcomeResponse;
import com.maruti.appointmentservice.model.DelayAlertRequest;
import com.maruti.appointmentservice.model.DelayAlertResponse;
import com.maruti.appointmentservice.model.DispatchAssignmentRequest;
import com.maruti.appointmentservice.model.DispatchAssignmentResponse;
import com.maruti.appointmentservice.model.ErrorResponse;
import com.maruti.appointmentservice.model.HandoverRefusalRequest;
import com.maruti.appointmentservice.model.HandoverRefusalResponse;
import org.threeten.bp.OffsetDateTime;
import com.maruti.appointmentservice.model.ReassignRequest;
import com.maruti.appointmentservice.model.ReassignResponse;
import com.maruti.appointmentservice.model.RescheduleRequest;
import com.maruti.appointmentservice.model.RescheduleResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")
@RestController
public class ApiApiController implements ApiApi {

    private static final Logger log = LoggerFactory.getLogger(ApiApiController.class);

    private final ObjectMapper objectMapper;


private final HttpServletRequest request;
private final String Accept="Accept";

    @org.springframework.beans.factory.annotation.Autowired
    public ApiApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<CancelResponse> cancelAppointment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment to be cancelled.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Cancellation details including the mandatory reason and the entity or channel that confirmed the cancellation.", required=true, schema=@Schema()) @Valid @RequestBody CancelRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CancelResponse>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"cancellationRecord\" : {\r\n    \"cancellationReason\" : \"cancellationReason\",\r\n    \"confirmationSource\" : \"confirmationSource\",\r\n    \"appointmentId\" : \"appointmentId\",\r\n    \"cancelledAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"cancelledBy\" : \"cancelledBy\",\r\n    \"cancellationId\" : \"cancellationId\"\r\n  },\r\n  \"status\" : \"Scheduled\"\r\n}", CancelResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CancelResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CancelResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ChauffeurSelectionResponse> confirmChauffeurSelection(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which the chauffeur selection is being recorded.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Chauffeur selection payload. The selectionType must be provided. When selectionType is 'Overridden', overrideReason is required.", required=true, schema=@Schema()) @Valid @RequestBody ChauffeurSelectionRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ChauffeurSelectionResponse>(objectMapper.readValue("{\r\n  \"selectionType\" : \"Confirmed\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"recordedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"chauffeurId\" : \"chauffeurId\",\r\n  \"allocationStatus\" : \"Unallocated\"\r\n}", ChauffeurSelectionResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ChauffeurSelectionResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ChauffeurSelectionResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<AppointmentDetail> createAppointment(@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody AppointmentCreateRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AppointmentDetail>(objectMapper.readValue("{\r\n  \"linkedJobCardId\" : \"linkedJobCardId\",\r\n  \"notes\" : \"notes\",\r\n  \"pickupLocation\" : {\r\n    \"pincode\" : \"400001\",\r\n    \"city\" : \"city\",\r\n    \"latitude\" : 19.076,\r\n    \"addressLine1\" : \"addressLine1\",\r\n    \"addressLine2\" : \"addressLine2\",\r\n    \"state\" : \"state\",\r\n    \"longitude\" : 72.8777\r\n  },\r\n  \"promisedDeliveryTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"assignedChauffeur\" : {\r\n    \"phone\" : \"phone\",\r\n    \"name\" : \"name\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"employeeCode\" : \"employeeCode\"\r\n  },\r\n  \"customerName\" : \"customerName\",\r\n  \"pickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"createdAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"customerPhone\" : \"customerPhone\",\r\n  \"eta\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"vehicleMakeModel\" : \"Maruti Suzuki Swift\",\r\n  \"customerId\" : \"customerId\",\r\n  \"exceptionFlag\" : true,\r\n  \"vehicleId\" : \"vehicleId\",\r\n  \"vehicleRegistration\" : \"MH12AB1234\",\r\n  \"assignmentHistory\" : [ {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  }, {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  } ],\r\n  \"allocationStatus\" : \"Unallocated\",\r\n  \"status\" : \"Scheduled\",\r\n  \"updatedAt\" : \"2000-01-23T04:56:07.000+00:00\"\r\n}", AppointmentDetail.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AppointmentDetail>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AppointmentDetail>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<CancelResponse> deleteAppointment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment to cancel.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Cancellation reason and confirmation source required to process the soft-delete.", required=true, schema=@Schema()) @Valid @RequestBody CancelRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<CancelResponse>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"cancellationRecord\" : {\r\n    \"cancellationReason\" : \"cancellationReason\",\r\n    \"confirmationSource\" : \"confirmationSource\",\r\n    \"appointmentId\" : \"appointmentId\",\r\n    \"cancelledAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"cancelledBy\" : \"cancelledBy\",\r\n    \"cancellationId\" : \"cancellationId\"\r\n  },\r\n  \"status\" : \"Scheduled\"\r\n}", CancelResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<CancelResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<CancelResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<DispatchAssignmentResponse> dispatchChauffeurAssignment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which the chauffeur assignment is being dispatched.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Optional dispatch configuration. If omitted, the notification is sent via the default CRMApp channel with no additional instructions.", schema=@Schema()) @Valid @RequestBody DispatchAssignmentRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<DispatchAssignmentResponse>(objectMapper.readValue("{\r\n  \"dispatchedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"chauffeurId\" : \"chauffeurId\",\r\n  \"crmReferenceId\" : \"crmReferenceId\",\r\n  \"allocationStatus\" : \"Unallocated\"\r\n}", DispatchAssignmentResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<DispatchAssignmentResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<DispatchAssignmentResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<AppointmentDetail> getAppointment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment to retrieve.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AppointmentDetail>(objectMapper.readValue("{\r\n  \"linkedJobCardId\" : \"linkedJobCardId\",\r\n  \"notes\" : \"notes\",\r\n  \"pickupLocation\" : {\r\n    \"pincode\" : \"400001\",\r\n    \"city\" : \"city\",\r\n    \"latitude\" : 19.076,\r\n    \"addressLine1\" : \"addressLine1\",\r\n    \"addressLine2\" : \"addressLine2\",\r\n    \"state\" : \"state\",\r\n    \"longitude\" : 72.8777\r\n  },\r\n  \"promisedDeliveryTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"assignedChauffeur\" : {\r\n    \"phone\" : \"phone\",\r\n    \"name\" : \"name\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"employeeCode\" : \"employeeCode\"\r\n  },\r\n  \"customerName\" : \"customerName\",\r\n  \"pickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"createdAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"customerPhone\" : \"customerPhone\",\r\n  \"eta\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"vehicleMakeModel\" : \"Maruti Suzuki Swift\",\r\n  \"customerId\" : \"customerId\",\r\n  \"exceptionFlag\" : true,\r\n  \"vehicleId\" : \"vehicleId\",\r\n  \"vehicleRegistration\" : \"MH12AB1234\",\r\n  \"assignmentHistory\" : [ {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  }, {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  } ],\r\n  \"allocationStatus\" : \"Unallocated\",\r\n  \"status\" : \"Scheduled\",\r\n  \"updatedAt\" : \"2000-01-23T04:56:07.000+00:00\"\r\n}", AppointmentDetail.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AppointmentDetail>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AppointmentDetail>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<AppointmentListResponse> listAppointments(@Parameter(in = ParameterIn.QUERY, description = "Filter appointments by one or more lifecycle statuses. Repeat the parameter to supply multiple values." ,schema=@Schema()) @Valid @RequestParam(value = "status", required = false) List<AppointmentStatus> status
,@Parameter(in = ParameterIn.QUERY, description = "Filter appointments by one or more chauffeur allocation states. Repeat the parameter to supply multiple values." ,schema=@Schema()) @Valid @RequestParam(value = "allocationStatus", required = false) List<AllocationStatus> allocationStatus
,@Parameter(in = ParameterIn.QUERY, description = "When true, returns only appointments currently flagged as exceptions. When false, returns only non-exception appointments. Omit to return all." ,schema=@Schema()) @Valid @RequestParam(value = "exceptionFlag", required = false) Boolean exceptionFlag
,@Parameter(in = ParameterIn.QUERY, description = "Filter appointments by the identifier of the currently assigned chauffeur." ,schema=@Schema()) @Valid @RequestParam(value = "assignedChauffeurId", required = false) String assignedChauffeurId
,@Parameter(in = ParameterIn.QUERY, description = "Filter appointments belonging to a specific customer." ,schema=@Schema()) @Valid @RequestParam(value = "customerId", required = false) String customerId
,@Parameter(in = ParameterIn.QUERY, description = "Inclusive start of the scheduled pickup date range filter, in ISO 8601 date-time format." ,schema=@Schema()) @Valid @RequestParam(value = "pickupDateFrom", required = false) OffsetDateTime pickupDateFrom
,@Parameter(in = ParameterIn.QUERY, description = "Inclusive end of the scheduled pickup date range filter, in ISO 8601 date-time format." ,schema=@Schema()) @Valid @RequestParam(value = "pickupDateTo", required = false) OffsetDateTime pickupDateTo
,@Min(1)@Parameter(in = ParameterIn.QUERY, description = "1-based page number to retrieve. Defaults to 1 when omitted." ,schema=@Schema(allowableValues={ "1" }, minimum="1"
, defaultValue="1")) @Valid @RequestParam(value = "page", required = false, defaultValue="1") Integer page
,@Min(1) @Max(100) @Parameter(in = ParameterIn.QUERY, description = "Number of records to return per page. Defaults to 20 when omitted; maximum allowed value is 100." ,schema=@Schema(allowableValues={ "1", "100" }, minimum="1", maximum="100"
, defaultValue="20")) @Valid @RequestParam(value = "pageSize", required = false, defaultValue="20") Integer pageSize
,@Parameter(in = ParameterIn.QUERY, description = "Field by which to sort the results." ,schema=@Schema(allowableValues={ "pickupDateTime", "createdAt", "status", "allocationStatus" }
, defaultValue="pickupDateTime")) @Valid @RequestParam(value = "sortBy", required = false, defaultValue="pickupDateTime") String sortBy
,@Parameter(in = ParameterIn.QUERY, description = "Sort direction: ascending or descending." ,schema=@Schema(allowableValues={ "asc", "desc" }
, defaultValue="asc")) @Valid @RequestParam(value = "sortOrder", required = false, defaultValue="asc") String sortOrder
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AppointmentListResponse>(objectMapper.readValue("{\r\n  \"pagination\" : {\r\n    \"totalRecords\" : 0,\r\n    \"totalPages\" : 6,\r\n    \"pageSize\" : 1,\r\n    \"page\" : 5\r\n  },\r\n  \"data\" : [ {\r\n    \"pickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"createdAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"assignedChauffeurName\" : \"assignedChauffeurName\",\r\n    \"appointmentId\" : \"appointmentId\",\r\n    \"customerId\" : \"customerId\",\r\n    \"exceptionFlag\" : true,\r\n    \"vehicleId\" : \"vehicleId\",\r\n    \"assignedChauffeurId\" : \"assignedChauffeurId\",\r\n    \"vehicleRegistration\" : \"MH12AB1234\",\r\n    \"customerName\" : \"customerName\",\r\n    \"allocationStatus\" : \"Unallocated\",\r\n    \"status\" : \"Scheduled\"\r\n  }, {\r\n    \"pickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"createdAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n    \"assignedChauffeurName\" : \"assignedChauffeurName\",\r\n    \"appointmentId\" : \"appointmentId\",\r\n    \"customerId\" : \"customerId\",\r\n    \"exceptionFlag\" : true,\r\n    \"vehicleId\" : \"vehicleId\",\r\n    \"assignedChauffeurId\" : \"assignedChauffeurId\",\r\n    \"vehicleRegistration\" : \"MH12AB1234\",\r\n    \"customerName\" : \"customerName\",\r\n    \"allocationStatus\" : \"Unallocated\",\r\n    \"status\" : \"Scheduled\"\r\n  } ]\r\n}", AppointmentListResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AppointmentListResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AppointmentListResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<HandoverRefusalResponse> logHandoverRefusal(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which handover refusal is being logged.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody HandoverRefusalRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<HandoverRefusalResponse>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"recordedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"exceptionFlag\" : true,\r\n  \"status\" : \"Scheduled\"\r\n}", HandoverRefusalResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<HandoverRefusalResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<HandoverRefusalResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<AssignmentResponseResult> recordAssignmentResponse(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which the chauffeur is submitting a response.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Chauffeur response payload including the response value, responding chauffeur identifier, app-recorded timestamp, and an optional rejection reason.", required=true, schema=@Schema()) @Valid @RequestBody AssignmentResponseRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AssignmentResponseResult>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"response\" : \"Accepted\",\r\n  \"recordedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"chauffeurId\" : \"chauffeurId\",\r\n  \"nextAction\" : \"ProceedToPickup\",\r\n  \"allocationStatus\" : \"Unallocated\"\r\n}", AssignmentResponseResult.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AssignmentResponseResult>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AssignmentResponseResult>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ContactOutcomeResponse> recordContactOutcome(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which the contact outcome is being recorded.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody ContactOutcomeRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ContactOutcomeResponse>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"recordedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"nextAction\" : \"nextAction\",\r\n  \"outcome\" : \"outcome\"\r\n}", ContactOutcomeResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ContactOutcomeResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ContactOutcomeResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<DelayAlertResponse> recordDelayAlert(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which the delay alert is being recorded.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody DelayAlertRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<DelayAlertResponse>(objectMapper.readValue("{\r\n  \"delayDurationMinutes\" : 0,\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"recordedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"exceptionFlag\" : true,\r\n  \"currentEta\" : \"2000-01-23T04:56:07.000+00:00\"\r\n}", DelayAlertResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<DelayAlertResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<DelayAlertResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<RescheduleResponse> rescheduleAppointment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment to be rescheduled.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "", required=true, schema=@Schema()) @Valid @RequestBody RescheduleRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<RescheduleResponse>(objectMapper.readValue("{\r\n  \"newPickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"otpAction\" : \"GenerateOTP\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"otpStatus\" : \"OTPSent\",\r\n  \"status\" : \"Scheduled\",\r\n  \"updatedAt\" : \"2000-01-23T04:56:07.000+00:00\"\r\n}", RescheduleResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<RescheduleResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<RescheduleResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<ReassignResponse> triggerReassignment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment for which reassignment is being triggered.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Reassignment payload containing the coordinator's revised chauffeur selection. An overrideReason should be included when the coordinator selects a chauffeur other than the newly recommended one.", required=true, schema=@Schema()) @Valid @RequestBody ReassignRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<ReassignResponse>(objectMapper.readValue("{\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"reassignedAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"failedAttemptCount\" : 0,\r\n  \"newChauffeurId\" : \"newChauffeurId\",\r\n  \"allocationStatus\" : \"Unallocated\"\r\n}", ReassignResponse.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<ReassignResponse>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<ReassignResponse>(HttpStatus.NOT_IMPLEMENTED);
    }

    public ResponseEntity<AppointmentDetail> updateAppointment(@Parameter(in = ParameterIn.PATH, description = "Unique identifier of the appointment to update.", required=true, schema=@Schema()) @PathVariable("appointmentId") String appointmentId
,@Parameter(in = ParameterIn.DEFAULT, description = "Partial update payload containing one or more appointment fields to modify. At least one field must be provided.", required=true, schema=@Schema()) @Valid @RequestBody AppointmentUpdateRequest body
) {
String accept = request.getHeader(Accept);
        if (accept != null && accept.contains("application/json")) {
            try {
                return new ResponseEntity<AppointmentDetail>(objectMapper.readValue("{\r\n  \"linkedJobCardId\" : \"linkedJobCardId\",\r\n  \"notes\" : \"notes\",\r\n  \"pickupLocation\" : {\r\n    \"pincode\" : \"400001\",\r\n    \"city\" : \"city\",\r\n    \"latitude\" : 19.076,\r\n    \"addressLine1\" : \"addressLine1\",\r\n    \"addressLine2\" : \"addressLine2\",\r\n    \"state\" : \"state\",\r\n    \"longitude\" : 72.8777\r\n  },\r\n  \"promisedDeliveryTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"assignedChauffeur\" : {\r\n    \"phone\" : \"phone\",\r\n    \"name\" : \"name\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"employeeCode\" : \"employeeCode\"\r\n  },\r\n  \"customerName\" : \"customerName\",\r\n  \"pickupDateTime\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"createdAt\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"customerPhone\" : \"customerPhone\",\r\n  \"eta\" : \"2000-01-23T04:56:07.000+00:00\",\r\n  \"appointmentId\" : \"appointmentId\",\r\n  \"vehicleMakeModel\" : \"Maruti Suzuki Swift\",\r\n  \"customerId\" : \"customerId\",\r\n  \"exceptionFlag\" : true,\r\n  \"vehicleId\" : \"vehicleId\",\r\n  \"vehicleRegistration\" : \"MH12AB1234\",\r\n  \"assignmentHistory\" : [ {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  }, {\r\n    \"attemptNumber\" : 0,\r\n    \"reason\" : \"reason\",\r\n    \"actorType\" : \"System\",\r\n    \"actorId\" : \"actorId\",\r\n    \"chauffeurName\" : \"chauffeurName\",\r\n    \"action\" : \"Recommended\",\r\n    \"chauffeurId\" : \"chauffeurId\",\r\n    \"timestamp\" : \"2000-01-23T04:56:07.000+00:00\"\r\n  } ],\r\n  \"allocationStatus\" : \"Unallocated\",\r\n  \"status\" : \"Scheduled\",\r\n  \"updatedAt\" : \"2000-01-23T04:56:07.000+00:00\"\r\n}", AppointmentDetail.class), HttpStatus.NOT_IMPLEMENTED);
            } catch (IOException e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<AppointmentDetail>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<AppointmentDetail>(HttpStatus.NOT_IMPLEMENTED);
    }

}


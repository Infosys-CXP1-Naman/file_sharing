package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * DelayAlertResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class DelayAlertResponse   {
  @JsonProperty("delayDurationMinutes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer delayDurationMinutes = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("recordedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime recordedAt = null;

  @JsonProperty("exceptionFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean exceptionFlag = null;

  @JsonProperty("currentEta")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime currentEta = null;


  public DelayAlertResponse delayDurationMinutes(Integer delayDurationMinutes) { 

    this.delayDurationMinutes = delayDurationMinutes;
    return this;
  }

  /**
   * Recorded delay duration in minutes.
   * @return delayDurationMinutes
   **/
  
  @Schema(description = "Recorded delay duration in minutes.")
  
  public Integer getDelayDurationMinutes() {  
    return delayDurationMinutes;
  }



  public void setDelayDurationMinutes(Integer delayDurationMinutes) { 
    this.delayDurationMinutes = delayDurationMinutes;
  }

  public DelayAlertResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment for which the delay was recorded.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment for which the delay was recorded.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public DelayAlertResponse recordedAt(OffsetDateTime recordedAt) { 

    this.recordedAt = recordedAt;
    return this;
  }

  /**
   * Timestamp when the delay alert was recorded.
   * @return recordedAt
   **/
  
  @Schema(description = "Timestamp when the delay alert was recorded.")
  
@Valid
  public OffsetDateTime getRecordedAt() {  
    return recordedAt;
  }



  public void setRecordedAt(OffsetDateTime recordedAt) { 
    this.recordedAt = recordedAt;
  }

  public DelayAlertResponse exceptionFlag(Boolean exceptionFlag) { 

    this.exceptionFlag = exceptionFlag;
    return this;
  }

  /**
   * Indicates whether the appointment has been flagged as an exception as a result of the delay.
   * @return exceptionFlag
   **/
  
  @Schema(description = "Indicates whether the appointment has been flagged as an exception as a result of the delay.")
  
  public Boolean isExceptionFlag() {  
    return exceptionFlag;
  }



  public void setExceptionFlag(Boolean exceptionFlag) { 
    this.exceptionFlag = exceptionFlag;
  }

  public DelayAlertResponse currentEta(OffsetDateTime currentEta) { 

    this.currentEta = currentEta;
    return this;
  }

  /**
   * Updated ETA as recorded.
   * @return currentEta
   **/
  
  @Schema(description = "Updated ETA as recorded.")
  
@Valid
  public OffsetDateTime getCurrentEta() {  
    return currentEta;
  }



  public void setCurrentEta(OffsetDateTime currentEta) { 
    this.currentEta = currentEta;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DelayAlertResponse delayAlertResponse = (DelayAlertResponse) o;
    return Objects.equals(this.delayDurationMinutes, delayAlertResponse.delayDurationMinutes) &&
        Objects.equals(this.appointmentId, delayAlertResponse.appointmentId) &&
        Objects.equals(this.recordedAt, delayAlertResponse.recordedAt) &&
        Objects.equals(this.exceptionFlag, delayAlertResponse.exceptionFlag) &&
        Objects.equals(this.currentEta, delayAlertResponse.currentEta);
  }

  @Override
  public int hashCode() {
    return Objects.hash(delayDurationMinutes, appointmentId, recordedAt, exceptionFlag, currentEta);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DelayAlertResponse {\n");
    
    sb.append("    delayDurationMinutes: ").append(toIndentedString(delayDurationMinutes)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    recordedAt: ").append(toIndentedString(recordedAt)).append("\n");
    sb.append("    exceptionFlag: ").append(toIndentedString(exceptionFlag)).append("\n");
    sb.append("    currentEta: ").append(toIndentedString(currentEta)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ChauffeurSummary
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ChauffeurSummary   {
  @JsonProperty("phone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String phone = null;

  @JsonProperty("name")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String name = null;

  @JsonProperty("chauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurId = null;

  @JsonProperty("employeeCode")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String employeeCode = null;


  public ChauffeurSummary phone(String phone) { 

    this.phone = phone;
    return this;
  }

  /**
   * Contact phone number of the chauffeur.
   * @return phone
   **/
  
  @Schema(description = "Contact phone number of the chauffeur.")
  
  public String getPhone() {  
    return phone;
  }



  public void setPhone(String phone) { 
    this.phone = phone;
  }

  public ChauffeurSummary name(String name) { 

    this.name = name;
    return this;
  }

  /**
   * Full name of the chauffeur.
   * @return name
   **/
  
  @Schema(description = "Full name of the chauffeur.")
  
  public String getName() {  
    return name;
  }



  public void setName(String name) { 
    this.name = name;
  }

  public ChauffeurSummary chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Unique identifier of the chauffeur.
   * @return chauffeurId
   **/
  
  @Schema(description = "Unique identifier of the chauffeur.")
  
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 
    this.chauffeurId = chauffeurId;
  }

  public ChauffeurSummary employeeCode(String employeeCode) { 

    this.employeeCode = employeeCode;
    return this;
  }

  /**
   * Internal employee code assigned to the chauffeur.
   * @return employeeCode
   **/
  
  @Schema(description = "Internal employee code assigned to the chauffeur.")
  
  public String getEmployeeCode() {  
    return employeeCode;
  }



  public void setEmployeeCode(String employeeCode) { 
    this.employeeCode = employeeCode;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ChauffeurSummary chauffeurSummary = (ChauffeurSummary) o;
    return Objects.equals(this.phone, chauffeurSummary.phone) &&
        Objects.equals(this.name, chauffeurSummary.name) &&
        Objects.equals(this.chauffeurId, chauffeurSummary.chauffeurId) &&
        Objects.equals(this.employeeCode, chauffeurSummary.employeeCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(phone, name, chauffeurId, employeeCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ChauffeurSummary {\n");
    
    sb.append("    phone: ").append(toIndentedString(phone)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    employeeCode: ").append(toIndentedString(employeeCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

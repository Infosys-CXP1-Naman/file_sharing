 /*
  * ******************************************************************************
  *  * © 2022 - 2023 Infosys Limited, Bangalore, India. All Rights Reserved.
  *  * Version:
  *  *
  *  * Except for any free or open source software components embedded in this Infosys
  *  * proprietary software program (“Program”), this Program is protected by copyright
  *  * laws, international treaties and other pending or existing intellectual property
  *  * rights in India, the United States and other countries. Except as expressly permitted,
  *  * any unauthorized reproduction, storage, transmission in any form or by any means
  *  * (including without limitation electronic, mechanical, printing, photocopying, recording
  *  * or otherwise), or any distribution of this Program, or any portion of it, may result in
  *  * severe civil and criminal penalties, and will be prosecuted to the maximum extent
  *  * possible under the law.
  *  *****************************************************************************
  */
import java.net.*;
import java.io.*;
import java.nio.channels.*;
import java.util.Properties;
import org.apache.tika.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MavenWrapperDownloader {
    private static final Logger logger = LoggerFactory.getLogger(MavenWrapperDownloader.class);
    private static final String WRAPPER_VERSION = "0.5.4";
    /**
     * Default URL to download the maven-wrapper.jar from, if no 'downloadUrl' is provided.
     */
    private static final String DEFAULT_DOWNLOAD_URL = "https://repo.maven.apache.org/maven2/io/takari/maven-wrapper/"
        + WRAPPER_VERSION + "/maven-wrapper-" + WRAPPER_VERSION + " .jar";

    /**
     * Path to the maven-wrapper.properties file, which might contain a downloadUrl property to
     * use instead of the default one.
     */
    private static final String MAVEN_WRAPPER_PROPERTIES_PATH =
            ".mvn/wrapper/maven-wrapper.properties";

    /**
     * Path where the maven-wrapper.jar will be saved to.
     */
    private static final String MAVEN_WRAPPER_JAR_PATH =
            ".mvn/wrapper/maven-wrapper.jar";

    /**
     * Name of the property which should be used to override the default download url for the wrapper.
     */
    private static final String PROPERTY_NAME_WRAPPER_URL = "wrapperUrl";

    public static void main(String[] args) {
        logger.info("- Downloader started");
        String filePath = FilenameUtils.normalize(args[0]);
        File baseDirectory = new File(filePath);
        logger.info("- Using base directory: " + baseDirectory.getAbsolutePath());

        // If the maven-wrapper.properties exists, read it and check if it contains a custom
        // wrapperUrl parameter.
        File mavenWrapperPropertyFile = new File(baseDirectory, MAVEN_WRAPPER_PROPERTIES_PATH);
        String url = DEFAULT_DOWNLOAD_URL;
        if(mavenWrapperPropertyFile.exists()) {
            try (
                FileInputStream mavenWrapperPropertyFileInputStream = new FileInputStream(mavenWrapperPropertyFile);
                Properties mavenWrapperProperties = new Properties();
            )
            {
                
                mavenWrapperProperties.load(mavenWrapperPropertyFileInputStream);
                url = mavenWrapperProperties.getProperty(PROPERTY_NAME_WRAPPER_URL, url);
            } catch (IOException e) {
                logger.error("- ERROR loading '" + MAVEN_WRAPPER_PROPERTIES_PATH + "'");
            } finally {
                try {
                    if(mavenWrapperPropertyFileInputStream != null) {
                        mavenWrapperPropertyFileInputStream.close();
                    }
                } catch (IOException e) {
                    // Ignore ...
                }
            }
        }
        logger.info("- Downloading from: " + url);

        File outputFile = new File(baseDirectory.getAbsolutePath(), MAVEN_WRAPPER_JAR_PATH);
        if(!outputFile.getParentFile().exists() && !outputFile.getParentFile().mkdirs()) {
             {
                logger.error(
                        "- ERROR creating output directory '" + outputFile.getParentFile().getAbsolutePath() + "'");
            }
        }
        logger.info("- Downloading to: " + outputFile.getAbsolutePath());
        try {
            downloadFileFromURL(url, outputFile);
            logger.info("Done");
            System.exit(0);
        } catch (Exception e) {
            logger.error("- Error downloading");
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void downloadFileFromURL(String urlString, File destination) throws FileNotFoundException,IOException {
        if (System.getenv("MVNW_USERNAME") != null && System.getenv("MVNW_PASSWORD") != null) {
            String username = System.getenv("MVNW_USERNAME");
            char[] password = System.getenv("MVNW_PASSWORD").toCharArray();
            Authenticator.setDefault(new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, password);
                }
            });
        }
        URL website = new URL(urlString);
        try(
            ReadableByteChannel rbc = Channels.newChannel(website.openStream());
            FileOutputStream fos = new FileOutputStream(destination);

        ){
           
            if(fos!=null){
                fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
            }
            
        } finally {
            if (fos != null) {
                this.safeClose(fos);
            }
            if(rbc!= null){
                this.safeReadClose(rbc);
            }
            }
    }

    public static void safeClose(FileOutputStream fos) {
        if (fos != null) {
        try {
        fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }
       }
       public static void safeReadClose(ReadableByteChannel rbc) {
        if (rbc != null) {
        try {
        rbc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }
       }

}

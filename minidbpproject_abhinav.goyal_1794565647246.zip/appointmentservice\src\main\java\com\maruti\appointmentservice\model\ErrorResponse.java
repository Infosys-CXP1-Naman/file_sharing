package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.FieldError;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ErrorResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ErrorResponse   {
  @JsonProperty("traceId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String traceId = null;

  @JsonProperty("code")

  private String code = null;

  @JsonProperty("details")
  @Valid
  private List<FieldError> details = null;
  @JsonProperty("message")

  private String message = null;


  public ErrorResponse traceId(String traceId) { 

    this.traceId = traceId;
    return this;
  }

  /**
   * Unique trace identifier for correlating this error with server-side logs.
   * @return traceId
   **/
  
  @Schema(description = "Unique trace identifier for correlating this error with server-side logs.")
  
  public String getTraceId() {  
    return traceId;
  }



  public void setTraceId(String traceId) { 
    this.traceId = traceId;
  }

  public ErrorResponse code(String code) { 

    this.code = code;
    return this;
  }

  /**
   * Application-level error code identifying the error type.
   * @return code
   **/
  
  @Schema(example = "APPOINTMENT_NOT_FOUND", required = true, description = "Application-level error code identifying the error type.")
  
  @NotNull
  public String getCode() {  
    return code;
  }



  public void setCode(String code) { 

    this.code = code;
  }

  public ErrorResponse details(List<FieldError> details) { 

    this.details = details;
    return this;
  }

  public ErrorResponse addDetailsItem(FieldError detailsItem) {
    if (this.details == null) {
      this.details = new ArrayList<FieldError>();
    }
    this.details.add(detailsItem);
    return this;
  }

  /**
   * Optional list of field-level validation errors.
   * @return details
   **/
  
  @Schema(description = "Optional list of field-level validation errors.")
  @Valid
  public List<FieldError> getDetails() {  
    return details;
  }



  public void setDetails(List<FieldError> details) { 
    this.details = details;
  }

  public ErrorResponse message(String message) { 

    this.message = message;
    return this;
  }

  /**
   * Human-readable description of the error.
   * @return message
   **/
  
  @Schema(required = true, description = "Human-readable description of the error.")
  
  @NotNull
  public String getMessage() {  
    return message;
  }



  public void setMessage(String message) { 

    this.message = message;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ErrorResponse errorResponse = (ErrorResponse) o;
    return Objects.equals(this.traceId, errorResponse.traceId) &&
        Objects.equals(this.code, errorResponse.code) &&
        Objects.equals(this.details, errorResponse.details) &&
        Objects.equals(this.message, errorResponse.message);
  }

  @Override
  public int hashCode() {
    return Objects.hash(traceId, code, details, message);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ErrorResponse {\n");
    
    sb.append("    traceId: ").append(toIndentedString(traceId)).append("\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

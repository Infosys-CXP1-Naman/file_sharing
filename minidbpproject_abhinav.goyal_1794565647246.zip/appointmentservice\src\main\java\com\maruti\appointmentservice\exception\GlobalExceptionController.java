package com.maruti.appointmentservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;



/**
* @author ICNDP
* @version 1.0
*/

@ControllerAdvice
public class GlobalExceptionController {

	/**
    * @param exception
    * @return ErrorResponse
    */
	@ExceptionHandler(value = EntityNotFoundException.class)
	public ResponseEntity<ErrorResponse> exception(EntityNotFoundException exception) {
		ErrorResponse ex = new ErrorResponse(exception.getMessage(), "error");
		return new ResponseEntity<>(ex, HttpStatus.NOT_FOUND);
	}

	/**
    * @param exception
    * @return ErrorResponse
    */
	@ExceptionHandler(value = GenericHandler.class)
	public ResponseEntity<ErrorResponse> exception(GenericHandler exception) {
		ErrorResponse ex = new ErrorResponse(exception.getMessage(), "error");
		return new ResponseEntity<>(ex, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
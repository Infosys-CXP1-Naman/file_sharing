package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.GeoCoordinate;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * HandoverRefusalRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class HandoverRefusalRequest   {
  @JsonProperty("liveLocation")

  private GeoCoordinate liveLocation = null;

  @JsonProperty("refusedAt")

  private OffsetDateTime refusedAt = null;

  @JsonProperty("chauffeurId")

  private String chauffeurId = null;

  @JsonProperty("refusalReason")

  private String refusalReason = null;

  @JsonProperty("additionalNotes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String additionalNotes = null;


  public HandoverRefusalRequest liveLocation(GeoCoordinate liveLocation) { 

    this.liveLocation = liveLocation;
    return this;
  }

  /**
   * Get liveLocation
   * @return liveLocation
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public GeoCoordinate getLiveLocation() {  
    return liveLocation;
  }



  public void setLiveLocation(GeoCoordinate liveLocation) { 

    this.liveLocation = liveLocation;
  }

  public HandoverRefusalRequest refusedAt(OffsetDateTime refusedAt) { 

    this.refusedAt = refusedAt;
    return this;
  }

  /**
   * Timestamp at which the customer refused handover, as recorded by the Chauffeur app.
   * @return refusedAt
   **/
  
  @Schema(required = true, description = "Timestamp at which the customer refused handover, as recorded by the Chauffeur app.")
  
@Valid
  @NotNull
  public OffsetDateTime getRefusedAt() {  
    return refusedAt;
  }



  public void setRefusedAt(OffsetDateTime refusedAt) { 

    this.refusedAt = refusedAt;
  }

  public HandoverRefusalRequest chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur reporting the handover refusal.
   * @return chauffeurId
   **/
  
  @Schema(required = true, description = "Identifier of the chauffeur reporting the handover refusal.")
  
  @NotNull
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
  }

  public HandoverRefusalRequest refusalReason(String refusalReason) { 

    this.refusalReason = refusalReason;
    return this;
  }

  /**
   * Reason provided by the chauffeur or customer for refusing vehicle handover.
   * @return refusalReason
   **/
  
  @Schema(required = true, description = "Reason provided by the chauffeur or customer for refusing vehicle handover.")
  
  @NotNull
  public String getRefusalReason() {  
    return refusalReason;
  }



  public void setRefusalReason(String refusalReason) { 

    this.refusalReason = refusalReason;
  }

  public HandoverRefusalRequest additionalNotes(String additionalNotes) { 

    this.additionalNotes = additionalNotes;
    return this;
  }

  /**
   * Optional additional context or observations noted by the chauffeur at the time of refusal.
   * @return additionalNotes
   **/
  
  @Schema(description = "Optional additional context or observations noted by the chauffeur at the time of refusal.")
  
  public String getAdditionalNotes() {  
    return additionalNotes;
  }



  public void setAdditionalNotes(String additionalNotes) { 
    this.additionalNotes = additionalNotes;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    HandoverRefusalRequest handoverRefusalRequest = (HandoverRefusalRequest) o;
    return Objects.equals(this.liveLocation, handoverRefusalRequest.liveLocation) &&
        Objects.equals(this.refusedAt, handoverRefusalRequest.refusedAt) &&
        Objects.equals(this.chauffeurId, handoverRefusalRequest.chauffeurId) &&
        Objects.equals(this.refusalReason, handoverRefusalRequest.refusalReason) &&
        Objects.equals(this.additionalNotes, handoverRefusalRequest.additionalNotes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(liveLocation, refusedAt, chauffeurId, refusalReason, additionalNotes);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class HandoverRefusalRequest {\n");
    
    sb.append("    liveLocation: ").append(toIndentedString(liveLocation)).append("\n");
    sb.append("    refusedAt: ").append(toIndentedString(refusedAt)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    refusalReason: ").append(toIndentedString(refusalReason)).append("\n");
    sb.append("    additionalNotes: ").append(toIndentedString(additionalNotes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ReassignRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ReassignRequest   {
  @JsonProperty("overrideReason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String overrideReason = null;

  @JsonProperty("chauffeurId")

  private String chauffeurId = null;


  public ReassignRequest overrideReason(String overrideReason) { 

    this.overrideReason = overrideReason;
    return this;
  }

  /**
   * Reason if the coordinator chose a chauffeur other than the newly recommended one.
   * @return overrideReason
   **/
  
  @Schema(description = "Reason if the coordinator chose a chauffeur other than the newly recommended one.")
  
  public String getOverrideReason() {  
    return overrideReason;
  }



  public void setOverrideReason(String overrideReason) { 
    this.overrideReason = overrideReason;
  }

  public ReassignRequest chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the newly selected chauffeur for reassignment, as confirmed by the coordinator after re-running the recommendation.
   * @return chauffeurId
   **/
  
  @Schema(required = true, description = "Identifier of the newly selected chauffeur for reassignment, as confirmed by the coordinator after re-running the recommendation.")
  
  @NotNull
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReassignRequest reassignRequest = (ReassignRequest) o;
    return Objects.equals(this.overrideReason, reassignRequest.overrideReason) &&
        Objects.equals(this.chauffeurId, reassignRequest.chauffeurId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(overrideReason, chauffeurId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReassignRequest {\n");
    
    sb.append("    overrideReason: ").append(toIndentedString(overrideReason)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

package com.maruti.appointmentservice.model;

import java.util.Objects;
import io.swagger.v3.oas.annotations.media.Schema;
import com.fasterxml.jackson.annotation.JsonValue;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import com.fasterxml.jackson.annotation.JsonCreator;

/**
 * Lifecycle status of the appointment.
 */
public enum AppointmentStatus {
  SCHEDULED("Scheduled"),
    ALLOCATED("Allocated"),
    DISPATCHED("Dispatched"),
    ENROUTE("EnRoute"),
    ARRIVED("Arrived"),
    VEHICLEPICKEDUP("VehiclePickedUp"),
    DELAYED("Delayed"),
    RESCHEDULED("Rescheduled"),
    HANDOVERREFUSED("HandoverRefused"),
    CANCELLED("Cancelled"),
    COMPLETED("Completed");

  private String value;

  AppointmentStatus(String value) {
    this.value = value;
  }

  @Override
  @JsonValue
  public String toString() {
    return String.valueOf(value);
  }

  @JsonCreator
  public static AppointmentStatus fromValue(String text) {
    for (AppointmentStatus b : AppointmentStatus.values()) {
      if (String.valueOf(b.value).equals(text)) {
        return b;
      }
    }
    return null;
  }
}

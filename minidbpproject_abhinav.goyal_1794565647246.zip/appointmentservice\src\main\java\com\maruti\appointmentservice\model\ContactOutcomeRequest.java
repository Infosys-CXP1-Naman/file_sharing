package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ContactOutcomeRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ContactOutcomeRequest   {
  @JsonProperty("outcomeNotes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String outcomeNotes = null;

  @JsonProperty("contactAttemptedAt")

  private OffsetDateTime contactAttemptedAt = null;

  /**
   * Follow-up action determined by the coordinator based on the contact outcome.
   */
  public enum NextActionEnum {
    RESCHEDULE("Reschedule"),
    
    CANCEL("Cancel"),
    
    RETRY("Retry"),
    
    ESCALATE("Escalate"),
    
    RESOLVED("Resolved");

    private String value;

    NextActionEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static NextActionEnum fromValue(String text) {
      for (NextActionEnum b : NextActionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("nextAction")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private NextActionEnum nextAction = null;

  /**
   * Result of the contact attempt.
   */
  public enum OutcomeEnum {
    REACHED("Reached"),
    
    NOTREACHABLE("NotReachable"),
    
    CALLBACKREQUESTED("CallbackRequested"),
    
    RESOLVED("Resolved"),
    
    ESCALATIONREQUIRED("EscalationRequired");

    private String value;

    OutcomeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OutcomeEnum fromValue(String text) {
      for (OutcomeEnum b : OutcomeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("outcome")

  private OutcomeEnum outcome = null;


  public ContactOutcomeRequest outcomeNotes(String outcomeNotes) { 

    this.outcomeNotes = outcomeNotes;
    return this;
  }

  /**
   * Free-text notes describing the outcome of the contact attempt and any agreed next steps.
   * @return outcomeNotes
   **/
  
  @Schema(description = "Free-text notes describing the outcome of the contact attempt and any agreed next steps.")
  
  public String getOutcomeNotes() {  
    return outcomeNotes;
  }



  public void setOutcomeNotes(String outcomeNotes) { 
    this.outcomeNotes = outcomeNotes;
  }

  public ContactOutcomeRequest contactAttemptedAt(OffsetDateTime contactAttemptedAt) { 

    this.contactAttemptedAt = contactAttemptedAt;
    return this;
  }

  /**
   * Timestamp when the coordinator attempted to contact the customer.
   * @return contactAttemptedAt
   **/
  
  @Schema(required = true, description = "Timestamp when the coordinator attempted to contact the customer.")
  
@Valid
  @NotNull
  public OffsetDateTime getContactAttemptedAt() {  
    return contactAttemptedAt;
  }



  public void setContactAttemptedAt(OffsetDateTime contactAttemptedAt) { 

    this.contactAttemptedAt = contactAttemptedAt;
  }

  public ContactOutcomeRequest nextAction(NextActionEnum nextAction) { 

    this.nextAction = nextAction;
    return this;
  }

  /**
   * Follow-up action determined by the coordinator based on the contact outcome.
   * @return nextAction
   **/
  
  @Schema(description = "Follow-up action determined by the coordinator based on the contact outcome.")
  
  public NextActionEnum getNextAction() {  
    return nextAction;
  }



  public void setNextAction(NextActionEnum nextAction) { 
    this.nextAction = nextAction;
  }

  public ContactOutcomeRequest outcome(OutcomeEnum outcome) { 

    this.outcome = outcome;
    return this;
  }

  /**
   * Result of the contact attempt.
   * @return outcome
   **/
  
  @Schema(required = true, description = "Result of the contact attempt.")
  
  @NotNull
  public OutcomeEnum getOutcome() {  
    return outcome;
  }



  public void setOutcome(OutcomeEnum outcome) { 

    this.outcome = outcome;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContactOutcomeRequest contactOutcomeRequest = (ContactOutcomeRequest) o;
    return Objects.equals(this.outcomeNotes, contactOutcomeRequest.outcomeNotes) &&
        Objects.equals(this.contactAttemptedAt, contactOutcomeRequest.contactAttemptedAt) &&
        Objects.equals(this.nextAction, contactOutcomeRequest.nextAction) &&
        Objects.equals(this.outcome, contactOutcomeRequest.outcome);
  }

  @Override
  public int hashCode() {
    return Objects.hash(outcomeNotes, contactAttemptedAt, nextAction, outcome);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContactOutcomeRequest {\n");
    
    sb.append("    outcomeNotes: ").append(toIndentedString(outcomeNotes)).append("\n");
    sb.append("    contactAttemptedAt: ").append(toIndentedString(contactAttemptedAt)).append("\n");
    sb.append("    nextAction: ").append(toIndentedString(nextAction)).append("\n");
    sb.append("    outcome: ").append(toIndentedString(outcome)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

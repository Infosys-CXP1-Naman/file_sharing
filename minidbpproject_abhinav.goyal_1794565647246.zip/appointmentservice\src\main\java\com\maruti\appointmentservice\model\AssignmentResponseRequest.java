package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AssignmentResponseRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AssignmentResponseRequest   {
  @JsonProperty("responseTimestamp")

  private OffsetDateTime responseTimestamp = null;

  /**
   * Chauffeur's response to the assignment request.
   */
  public enum ResponseEnum {
    ACCEPTED("Accepted"),
    
    REJECTED("Rejected");

    private String value;

    ResponseEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ResponseEnum fromValue(String text) {
      for (ResponseEnum b : ResponseEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("response")

  private ResponseEnum response = null;

  @JsonProperty("chauffeurId")

  private String chauffeurId = null;

  @JsonProperty("rejectionReason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String rejectionReason = null;


  public AssignmentResponseRequest responseTimestamp(OffsetDateTime responseTimestamp) { 

    this.responseTimestamp = responseTimestamp;
    return this;
  }

  /**
   * Timestamp at which the chauffeur submitted the response, as recorded by the Chauffeur app.
   * @return responseTimestamp
   **/
  
  @Schema(required = true, description = "Timestamp at which the chauffeur submitted the response, as recorded by the Chauffeur app.")
  
@Valid
  @NotNull
  public OffsetDateTime getResponseTimestamp() {  
    return responseTimestamp;
  }



  public void setResponseTimestamp(OffsetDateTime responseTimestamp) { 

    this.responseTimestamp = responseTimestamp;
  }

  public AssignmentResponseRequest response(ResponseEnum response) { 

    this.response = response;
    return this;
  }

  /**
   * Chauffeur's response to the assignment request.
   * @return response
   **/
  
  @Schema(required = true, description = "Chauffeur's response to the assignment request.")
  
  @NotNull
  public ResponseEnum getResponse() {  
    return response;
  }



  public void setResponse(ResponseEnum response) { 

    this.response = response;
  }

  public AssignmentResponseRequest chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur submitting the response.
   * @return chauffeurId
   **/
  
  @Schema(required = true, description = "Identifier of the chauffeur submitting the response.")
  
  @NotNull
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
  }

  public AssignmentResponseRequest rejectionReason(String rejectionReason) { 

    this.rejectionReason = rejectionReason;
    return this;
  }

  /**
   * Reason provided by the chauffeur when rejecting the assignment. Required when response is 'Rejected'.
   * @return rejectionReason
   **/
  
  @Schema(description = "Reason provided by the chauffeur when rejecting the assignment. Required when response is 'Rejected'.")
  
  public String getRejectionReason() {  
    return rejectionReason;
  }



  public void setRejectionReason(String rejectionReason) { 
    this.rejectionReason = rejectionReason;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AssignmentResponseRequest assignmentResponseRequest = (AssignmentResponseRequest) o;
    return Objects.equals(this.responseTimestamp, assignmentResponseRequest.responseTimestamp) &&
        Objects.equals(this.response, assignmentResponseRequest.response) &&
        Objects.equals(this.chauffeurId, assignmentResponseRequest.chauffeurId) &&
        Objects.equals(this.rejectionReason, assignmentResponseRequest.rejectionReason);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseTimestamp, response, chauffeurId, rejectionReason);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AssignmentResponseRequest {\n");
    
    sb.append("    responseTimestamp: ").append(toIndentedString(responseTimestamp)).append("\n");
    sb.append("    response: ").append(toIndentedString(response)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    rejectionReason: ").append(toIndentedString(rejectionReason)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

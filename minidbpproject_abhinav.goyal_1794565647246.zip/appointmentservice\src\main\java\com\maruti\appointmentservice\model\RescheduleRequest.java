package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * RescheduleRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class RescheduleRequest   {
  @JsonProperty("rescheduleReason")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String rescheduleReason = null;

  @JsonProperty("newPickupDateTime")

  private OffsetDateTime newPickupDateTime = null;

  /**
   * Indicates the OTP step being performed in this request.
   */
  public enum OtpActionEnum {
    GENERATEOTP("GenerateOTP"),
    
    VALIDATEOTP("ValidateOTP");

    private String value;

    OtpActionEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static OtpActionEnum fromValue(String text) {
      for (OtpActionEnum b : OtpActionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("otpAction")

  private OtpActionEnum otpAction = null;

  @JsonProperty("otp")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String otp = null;


  public RescheduleRequest rescheduleReason(String rescheduleReason) { 

    this.rescheduleReason = rescheduleReason;
    return this;
  }

  /**
   * Optional reason provided for rescheduling the appointment.
   * @return rescheduleReason
   **/
  
  @Schema(description = "Optional reason provided for rescheduling the appointment.")
  
  public String getRescheduleReason() {  
    return rescheduleReason;
  }



  public void setRescheduleReason(String rescheduleReason) { 
    this.rescheduleReason = rescheduleReason;
  }

  public RescheduleRequest newPickupDateTime(OffsetDateTime newPickupDateTime) { 

    this.newPickupDateTime = newPickupDateTime;
    return this;
  }

  /**
   * Revised pickup date and time requested by the customer.
   * @return newPickupDateTime
   **/
  
  @Schema(example = "2025-06-16T11:00+05:30", required = true, description = "Revised pickup date and time requested by the customer.")
  
@Valid
  @NotNull
  public OffsetDateTime getNewPickupDateTime() {  
    return newPickupDateTime;
  }



  public void setNewPickupDateTime(OffsetDateTime newPickupDateTime) { 

    this.newPickupDateTime = newPickupDateTime;
  }

  public RescheduleRequest otpAction(OtpActionEnum otpAction) { 

    this.otpAction = otpAction;
    return this;
  }

  /**
   * Indicates the OTP step being performed in this request.
   * @return otpAction
   **/
  
  @Schema(required = true, description = "Indicates the OTP step being performed in this request.")
  
  @NotNull
  public OtpActionEnum getOtpAction() {  
    return otpAction;
  }



  public void setOtpAction(OtpActionEnum otpAction) { 

    this.otpAction = otpAction;
  }

  public RescheduleRequest otp(String otp) { 

    this.otp = otp;
    return this;
  }

  /**
   * One-time password entered by the customer for verification. Required when otpAction is 'ValidateOTP'.
   * @return otp
   **/
  
  @Schema(example = "482910", description = "One-time password entered by the customer for verification. Required when otpAction is 'ValidateOTP'.")
  
  public String getOtp() {  
    return otp;
  }



  public void setOtp(String otp) { 
    this.otp = otp;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RescheduleRequest rescheduleRequest = (RescheduleRequest) o;
    return Objects.equals(this.rescheduleReason, rescheduleRequest.rescheduleReason) &&
        Objects.equals(this.newPickupDateTime, rescheduleRequest.newPickupDateTime) &&
        Objects.equals(this.otpAction, rescheduleRequest.otpAction) &&
        Objects.equals(this.otp, rescheduleRequest.otp);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rescheduleReason, newPickupDateTime, otpAction, otp);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RescheduleRequest {\n");
    
    sb.append("    rescheduleReason: ").append(toIndentedString(rescheduleReason)).append("\n");
    sb.append("    newPickupDateTime: ").append(toIndentedString(newPickupDateTime)).append("\n");
    sb.append("    otpAction: ").append(toIndentedString(otpAction)).append("\n");
    sb.append("    otp: ").append(toIndentedString(otp)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

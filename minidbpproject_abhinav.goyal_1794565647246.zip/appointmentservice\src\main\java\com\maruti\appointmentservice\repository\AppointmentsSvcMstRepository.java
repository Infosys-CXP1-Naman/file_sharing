package com.maruti.appointmentservice.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.maruti.appointmentservice.model.AppointmentsSvcMst;


/**
* @author ICNDP
* @version 1.0
*/

@Repository
public interface AppointmentsSvcMstRepository extends CrudRepository<AppointmentsSvcMst, Integer>{

}


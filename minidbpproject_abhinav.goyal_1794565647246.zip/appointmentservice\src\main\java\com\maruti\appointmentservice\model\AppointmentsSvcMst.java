package com.maruti.appointmentservice.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.ManyToOne;

import java.sql.*;
import java.util.*;
import java.util.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.Instant;
import lombok.Data;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.InstantSerializer;



/**
* @author ICNDP
* @version 1.0
*/

@Data
@Entity
@Table(name = "appointments_svc_mst")
public class AppointmentsSvcMst {

  
    @Column(name = "id")
    private uuid id;

  
    @Column(name = "customer_name")
    private String customerName; 

  
    @Column(name = "contact_number")
    private String contactNumber; 

  
    @Column(name = "registration_number")
    private String registrationNumber; 

  
    @Column(name = "vin")
    private String vin; 

  
    @Column(name = "pick_up_location")
    private String pickUpLocation; 

  
    @Column(name = "pick_up_date")
    private Date pickUpDate;
    

  
    @Column(name = "pick_up_time")
    @JsonSerialize(using = InstantSerializer.class)
    private Instant pickUpTime; 

  
    @Column(name = "drop_location")
    private String dropLocation; 

  
    @Column(name = "drop_date")
    private Date dropDate;
    

  
    @Column(name = "drop_time")
    @JsonSerialize(using = InstantSerializer.class)
    private Instant dropTime; 

  
    @Column(name = "assigned_driver_id")
    private uuid assignedDriverId;

  
    @Column(name = "status")
    private String status; 

  
    @Column(name = "qr_code_id")
    private uuid qrCodeId;

  
    @Column(name = "rescheduling_count")
    private int reschedulingCount;

  
    @Column(name = "cce_user_id")
    private uuid cceUserId;

  
    @Column(name = "dealership_code")
    private String dealershipCode; 

  
    @Column(name = "notes")
    private String notes; 

  
    @Column(name = "is_deleted")
    private boolean isDeleted;

  
    @Column(name = "version")
    private int version;

  
    @Column(name = "created_at")
    private Date createdAt; 

  
    @Column(name = "updated_at")
    private Date updatedAt; 

  /*
	 * //Defines a single-valued association to another entity that has one-to-one multiplicity
	 * @OneToOne(cascade = CascadeType.ALL)
	 * //If @JoinColumn not specified will take default column name i.e the name of the entity_the name of the referenced primary key column.
	 * @JoinColumn(name = "<the name of the referenced primary key column>", unique = true)
	 * private <referenced entity> <referenced entity variable name>;
	
	 * //Defines a many-valued association with one-to-many multiplicity
	 * @OneToMany(cascade=CascadeType.ALL)
	 * @JoinColumn(name = "<the name of the referenced primary key column>")
	 * private List<<referenced entity>> <referenced entity variable name>;
	
   * //Defines a single-valued association to another entity class that has many-to-one multiplicity
   * @ManyToOne(cascade=CascadeType.ALL)
   * @JoinColumn(name="<the name of the referenced primary key column>")
   * private <referenced entity> <referenced entity variable name>;

	 * //Defines a many-valued association with many-to-many multiplicity.
	 * @ManyToMany
	 * //If @JoinTable not specified then default value will be taken i.e associated tables separated by underscore
	 * // @joinColumn attribute will connect to the owner side of the relationship, and @inverseJoinColumn to the other side
	 * @JoinTable(
	 * 		  name = "<name of the new joining table>", 
	 * 		  joinColumns = @JoinColumn(name = "<owner entity primary key>"), 
	 * 		  inverseJoinColumns = @JoinColumn(name = "<target entity primary key>"))
	 * private <<referenced entity>> <referenced entity variable name>; 
   */
   
}

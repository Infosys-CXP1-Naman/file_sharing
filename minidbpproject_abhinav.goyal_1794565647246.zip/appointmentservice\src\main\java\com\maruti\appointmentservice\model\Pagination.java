package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * Pagination
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class Pagination   {
  @JsonProperty("totalRecords")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer totalRecords = null;

  @JsonProperty("totalPages")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer totalPages = null;

  @JsonProperty("pageSize")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer pageSize = null;

  @JsonProperty("page")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer page = null;


  public Pagination totalRecords(Integer totalRecords) { 

    this.totalRecords = totalRecords;
    return this;
  }

  /**
   * Total number of records matching the applied filters.
   * @return totalRecords
   **/
  
  @Schema(description = "Total number of records matching the applied filters.")
  
  public Integer getTotalRecords() {  
    return totalRecords;
  }



  public void setTotalRecords(Integer totalRecords) { 
    this.totalRecords = totalRecords;
  }

  public Pagination totalPages(Integer totalPages) { 

    this.totalPages = totalPages;
    return this;
  }

  /**
   * Total number of pages available given the current page size.
   * @return totalPages
   **/
  
  @Schema(description = "Total number of pages available given the current page size.")
  
  public Integer getTotalPages() {  
    return totalPages;
  }



  public void setTotalPages(Integer totalPages) { 
    this.totalPages = totalPages;
  }

  public Pagination pageSize(Integer pageSize) { 

    this.pageSize = pageSize;
    return this;
  }

  /**
   * Number of records returned per page.
   * @return pageSize
   **/
  
  @Schema(description = "Number of records returned per page.")
  
  public Integer getPageSize() {  
    return pageSize;
  }



  public void setPageSize(Integer pageSize) { 
    this.pageSize = pageSize;
  }

  public Pagination page(Integer page) { 

    this.page = page;
    return this;
  }

  /**
   * Current page number (1-based).
   * @return page
   **/
  
  @Schema(description = "Current page number (1-based).")
  
  public Integer getPage() {  
    return page;
  }



  public void setPage(Integer page) { 
    this.page = page;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Pagination pagination = (Pagination) o;
    return Objects.equals(this.totalRecords, pagination.totalRecords) &&
        Objects.equals(this.totalPages, pagination.totalPages) &&
        Objects.equals(this.pageSize, pagination.pageSize) &&
        Objects.equals(this.page, pagination.page);
  }

  @Override
  public int hashCode() {
    return Objects.hash(totalRecords, totalPages, pageSize, page);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Pagination {\n");
    
    sb.append("    totalRecords: ").append(toIndentedString(totalRecords)).append("\n");
    sb.append("    totalPages: ").append(toIndentedString(totalPages)).append("\n");
    sb.append("    pageSize: ").append(toIndentedString(pageSize)).append("\n");
    sb.append("    page: ").append(toIndentedString(page)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

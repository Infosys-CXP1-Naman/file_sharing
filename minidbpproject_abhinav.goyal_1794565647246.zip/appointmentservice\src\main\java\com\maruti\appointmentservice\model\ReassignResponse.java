package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AllocationStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ReassignResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ReassignResponse   {
  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("reassignedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime reassignedAt = null;

  @JsonProperty("failedAttemptCount")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Integer failedAttemptCount = null;

  @JsonProperty("newChauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String newChauffeurId = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;


  public ReassignResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment being reassigned.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment being reassigned.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public ReassignResponse reassignedAt(OffsetDateTime reassignedAt) { 

    this.reassignedAt = reassignedAt;
    return this;
  }

  /**
   * Timestamp when the reassignment was initiated.
   * @return reassignedAt
   **/
  
  @Schema(description = "Timestamp when the reassignment was initiated.")
  
@Valid
  public OffsetDateTime getReassignedAt() {  
    return reassignedAt;
  }



  public void setReassignedAt(OffsetDateTime reassignedAt) { 
    this.reassignedAt = reassignedAt;
  }

  public ReassignResponse failedAttemptCount(Integer failedAttemptCount) { 

    this.failedAttemptCount = failedAttemptCount;
    return this;
  }

  /**
   * Total number of failed assignment attempts logged for this appointment up to and including the current failure.
   * @return failedAttemptCount
   **/
  
  @Schema(description = "Total number of failed assignment attempts logged for this appointment up to and including the current failure.")
  
  public Integer getFailedAttemptCount() {  
    return failedAttemptCount;
  }



  public void setFailedAttemptCount(Integer failedAttemptCount) { 
    this.failedAttemptCount = failedAttemptCount;
  }

  public ReassignResponse newChauffeurId(String newChauffeurId) { 

    this.newChauffeurId = newChauffeurId;
    return this;
  }

  /**
   * Identifier of the chauffeur selected for the new assignment attempt.
   * @return newChauffeurId
   **/
  
  @Schema(description = "Identifier of the chauffeur selected for the new assignment attempt.")
  
  public String getNewChauffeurId() {  
    return newChauffeurId;
  }



  public void setNewChauffeurId(String newChauffeurId) { 
    this.newChauffeurId = newChauffeurId;
  }

  public ReassignResponse allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ReassignResponse reassignResponse = (ReassignResponse) o;
    return Objects.equals(this.appointmentId, reassignResponse.appointmentId) &&
        Objects.equals(this.reassignedAt, reassignResponse.reassignedAt) &&
        Objects.equals(this.failedAttemptCount, reassignResponse.failedAttemptCount) &&
        Objects.equals(this.newChauffeurId, reassignResponse.newChauffeurId) &&
        Objects.equals(this.allocationStatus, reassignResponse.allocationStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentId, reassignedAt, failedAttemptCount, newChauffeurId, allocationStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ReassignResponse {\n");
    
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    reassignedAt: ").append(toIndentedString(reassignedAt)).append("\n");
    sb.append("    failedAttemptCount: ").append(toIndentedString(failedAttemptCount)).append("\n");
    sb.append("    newChauffeurId: ").append(toIndentedString(newChauffeurId)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

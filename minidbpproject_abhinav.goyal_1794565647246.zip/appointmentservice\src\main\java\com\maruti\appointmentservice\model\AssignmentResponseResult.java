package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.maruti.appointmentservice.model.AllocationStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AssignmentResponseResult
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AssignmentResponseResult   {
  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  /**
   * Recorded response from the chauffeur.
   */
  public enum ResponseEnum {
    ACCEPTED("Accepted"),
    
    REJECTED("Rejected");

    private String value;

    ResponseEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static ResponseEnum fromValue(String text) {
      for (ResponseEnum b : ResponseEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("response")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ResponseEnum response = null;

  @JsonProperty("recordedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime recordedAt = null;

  @JsonProperty("chauffeurId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String chauffeurId = null;

  /**
   * System-determined next step following the chauffeur's response.
   */
  public enum NextActionEnum {
    PROCEEDTOPICKUP("ProceedToPickup"),
    
    INITIATEREASSIGNMENT("InitiateReassignment");

    private String value;

    NextActionEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static NextActionEnum fromValue(String text) {
      for (NextActionEnum b : NextActionEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("nextAction")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private NextActionEnum nextAction = null;

  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;


  public AssignmentResponseResult appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public AssignmentResponseResult response(ResponseEnum response) { 

    this.response = response;
    return this;
  }

  /**
   * Recorded response from the chauffeur.
   * @return response
   **/
  
  @Schema(description = "Recorded response from the chauffeur.")
  
  public ResponseEnum getResponse() {  
    return response;
  }



  public void setResponse(ResponseEnum response) { 
    this.response = response;
  }

  public AssignmentResponseResult recordedAt(OffsetDateTime recordedAt) { 

    this.recordedAt = recordedAt;
    return this;
  }

  /**
   * Timestamp when the response was recorded by the system.
   * @return recordedAt
   **/
  
  @Schema(description = "Timestamp when the response was recorded by the system.")
  
@Valid
  public OffsetDateTime getRecordedAt() {  
    return recordedAt;
  }



  public void setRecordedAt(OffsetDateTime recordedAt) { 
    this.recordedAt = recordedAt;
  }

  public AssignmentResponseResult chauffeurId(String chauffeurId) { 

    this.chauffeurId = chauffeurId;
    return this;
  }

  /**
   * Identifier of the responding chauffeur.
   * @return chauffeurId
   **/
  
  @Schema(description = "Identifier of the responding chauffeur.")
  
  public String getChauffeurId() {  
    return chauffeurId;
  }



  public void setChauffeurId(String chauffeurId) { 
    this.chauffeurId = chauffeurId;
  }

  public AssignmentResponseResult nextAction(NextActionEnum nextAction) { 

    this.nextAction = nextAction;
    return this;
  }

  /**
   * System-determined next step following the chauffeur's response.
   * @return nextAction
   **/
  
  @Schema(description = "System-determined next step following the chauffeur's response.")
  
  public NextActionEnum getNextAction() {  
    return nextAction;
  }



  public void setNextAction(NextActionEnum nextAction) { 
    this.nextAction = nextAction;
  }

  public AssignmentResponseResult allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AssignmentResponseResult assignmentResponseResult = (AssignmentResponseResult) o;
    return Objects.equals(this.appointmentId, assignmentResponseResult.appointmentId) &&
        Objects.equals(this.response, assignmentResponseResult.response) &&
        Objects.equals(this.recordedAt, assignmentResponseResult.recordedAt) &&
        Objects.equals(this.chauffeurId, assignmentResponseResult.chauffeurId) &&
        Objects.equals(this.nextAction, assignmentResponseResult.nextAction) &&
        Objects.equals(this.allocationStatus, assignmentResponseResult.allocationStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentId, response, recordedAt, chauffeurId, nextAction, allocationStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AssignmentResponseResult {\n");
    
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    response: ").append(toIndentedString(response)).append("\n");
    sb.append("    recordedAt: ").append(toIndentedString(recordedAt)).append("\n");
    sb.append("    chauffeurId: ").append(toIndentedString(chauffeurId)).append("\n");
    sb.append("    nextAction: ").append(toIndentedString(nextAction)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

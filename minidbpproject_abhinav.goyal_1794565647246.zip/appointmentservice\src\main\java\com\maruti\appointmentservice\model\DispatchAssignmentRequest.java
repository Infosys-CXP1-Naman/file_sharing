package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * DispatchAssignmentRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class DispatchAssignmentRequest   {
  /**
   * Channel through which the dispatch notification is sent to the chauffeur.
   */
  public enum NotificationChannelEnum {
    CRMAPP("CRMApp"),
    
    SMS("SMS"),
    
    PUSH("Push");

    private String value;

    NotificationChannelEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static NotificationChannelEnum fromValue(String text) {
      for (NotificationChannelEnum b : NotificationChannelEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }
  @JsonProperty("notificationChannel")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private NotificationChannelEnum notificationChannel = NotificationChannelEnum.CRMAPP;

  @JsonProperty("additionalInstructions")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String additionalInstructions = null;


  public DispatchAssignmentRequest notificationChannel(NotificationChannelEnum notificationChannel) { 

    this.notificationChannel = notificationChannel;
    return this;
  }

  /**
   * Channel through which the dispatch notification is sent to the chauffeur.
   * @return notificationChannel
   **/
  
  @Schema(description = "Channel through which the dispatch notification is sent to the chauffeur.")
  
  public NotificationChannelEnum getNotificationChannel() {  
    return notificationChannel;
  }



  public void setNotificationChannel(NotificationChannelEnum notificationChannel) { 
    this.notificationChannel = notificationChannel;
  }

  public DispatchAssignmentRequest additionalInstructions(String additionalInstructions) { 

    this.additionalInstructions = additionalInstructions;
    return this;
  }

  /**
   * Optional additional instructions to include in the dispatch message sent to the chauffeur.
   * @return additionalInstructions
   **/
  
  @Schema(description = "Optional additional instructions to include in the dispatch message sent to the chauffeur.")
  
  public String getAdditionalInstructions() {  
    return additionalInstructions;
  }



  public void setAdditionalInstructions(String additionalInstructions) { 
    this.additionalInstructions = additionalInstructions;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DispatchAssignmentRequest dispatchAssignmentRequest = (DispatchAssignmentRequest) o;
    return Objects.equals(this.notificationChannel, dispatchAssignmentRequest.notificationChannel) &&
        Objects.equals(this.additionalInstructions, dispatchAssignmentRequest.additionalInstructions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(notificationChannel, additionalInstructions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DispatchAssignmentRequest {\n");
    
    sb.append("    notificationChannel: ").append(toIndentedString(notificationChannel)).append("\n");
    sb.append("    additionalInstructions: ").append(toIndentedString(additionalInstructions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

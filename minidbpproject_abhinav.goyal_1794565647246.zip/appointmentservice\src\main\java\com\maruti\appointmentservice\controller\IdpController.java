package com.maruti.appointmentservice.controller;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
* @author ICNDP
* @version 1.0
*/

@RestController
public class IdpController {

static Logger log = LoggerFactory.getLogger(IdpController.class);

/**
* @return String
* @throws Exception
*/
@GetMapping ("/")
@ResponseBody
public ResponseEntity<String> getAppTest() throws Exception {
return ResponseEntity.ok("Application is Up and Running :) ");

}

}
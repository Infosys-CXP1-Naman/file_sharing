package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * GeoCoordinate
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class GeoCoordinate   {
  @JsonProperty("latitude")

  private Double latitude = null;

  @JsonProperty("accuracy")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Float accuracy = null;

  @JsonProperty("capturedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime capturedAt = null;

  @JsonProperty("longitude")

  private Double longitude = null;


  public GeoCoordinate latitude(Double latitude) { 

    this.latitude = latitude;
    return this;
  }

  /**
   * Geographic latitude coordinate.
   * @return latitude
   **/
  
  @Schema(example = "19.076", required = true, description = "Geographic latitude coordinate.")
  
  @NotNull
  public Double getLatitude() {  
    return latitude;
  }



  public void setLatitude(Double latitude) { 

    this.latitude = latitude;
  }

  public GeoCoordinate accuracy(Float accuracy) { 

    this.accuracy = accuracy;
    return this;
  }

  /**
   * Accuracy of the GPS reading in metres.
   * @return accuracy
   **/
  
  @Schema(example = "10.5", description = "Accuracy of the GPS reading in metres.")
  
  public Float getAccuracy() {  
    return accuracy;
  }



  public void setAccuracy(Float accuracy) { 
    this.accuracy = accuracy;
  }

  public GeoCoordinate capturedAt(OffsetDateTime capturedAt) { 

    this.capturedAt = capturedAt;
    return this;
  }

  /**
   * Timestamp when the GPS coordinate was captured by the device.
   * @return capturedAt
   **/
  
  @Schema(description = "Timestamp when the GPS coordinate was captured by the device.")
  
@Valid
  public OffsetDateTime getCapturedAt() {  
    return capturedAt;
  }



  public void setCapturedAt(OffsetDateTime capturedAt) { 
    this.capturedAt = capturedAt;
  }

  public GeoCoordinate longitude(Double longitude) { 

    this.longitude = longitude;
    return this;
  }

  /**
   * Geographic longitude coordinate.
   * @return longitude
   **/
  
  @Schema(example = "72.8777", required = true, description = "Geographic longitude coordinate.")
  
  @NotNull
  public Double getLongitude() {  
    return longitude;
  }



  public void setLongitude(Double longitude) { 

    this.longitude = longitude;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GeoCoordinate geoCoordinate = (GeoCoordinate) o;
    return Objects.equals(this.latitude, geoCoordinate.latitude) &&
        Objects.equals(this.accuracy, geoCoordinate.accuracy) &&
        Objects.equals(this.capturedAt, geoCoordinate.capturedAt) &&
        Objects.equals(this.longitude, geoCoordinate.longitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(latitude, accuracy, capturedAt, longitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GeoCoordinate {\n");
    
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    accuracy: ").append(toIndentedString(accuracy)).append("\n");
    sb.append("    capturedAt: ").append(toIndentedString(capturedAt)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

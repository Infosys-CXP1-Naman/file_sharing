    #!/bin/bash
    set -o xtrace
    set -o errexit
    set -o nounset
    set -o pipefail  
    echo "Deploy_ENV Value is::" $Deploy_Env
    var_ns=""
    if [ $Deploy_Env == "intdev" ]
    then
    Cluster_login="oc login https://api.ocpintdev.lic-india.com"
    var_ns=""
    env_host="licdevportal.lic-india.com"
    fi
    sed -i "s/var_ns/$var_ns/g" $IDP_WS/appointmentservice/Orchestration/dev/deployment.yaml
    oc project minidbpproject-dev-apps
    oc apply -f Orchestration/dev/configmap.yaml
    oc apply -f Orchestration/dev/secrets.yaml
    oc apply -f Orchestration/dev/deployment.yaml
    oc apply -f Orchestration/dev/service.yaml
    oc apply -f Orchestration/dev/route.yaml
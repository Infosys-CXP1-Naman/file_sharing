package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.Location;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AppointmentCreateRequest
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AppointmentCreateRequest   {
  @JsonProperty("pickupDateTime")

  private OffsetDateTime pickupDateTime = null;

  @JsonProperty("notes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String notes = null;

  @JsonProperty("customerId")

  private String customerId = null;

  @JsonProperty("vehicleId")

  private String vehicleId = null;

  @JsonProperty("pickupLocation")

  private Location pickupLocation = null;


  public AppointmentCreateRequest pickupDateTime(OffsetDateTime pickupDateTime) { 

    this.pickupDateTime = pickupDateTime;
    return this;
  }

  /**
   * Scheduled pickup date and time in ISO 8601 format.
   * @return pickupDateTime
   **/
  
  @Schema(example = "2025-06-15T09:30+05:30", required = true, description = "Scheduled pickup date and time in ISO 8601 format.")
  
@Valid
  @NotNull
  public OffsetDateTime getPickupDateTime() {  
    return pickupDateTime;
  }



  public void setPickupDateTime(OffsetDateTime pickupDateTime) { 

    this.pickupDateTime = pickupDateTime;
  }

  public AppointmentCreateRequest notes(String notes) { 

    this.notes = notes;
    return this;
  }

  /**
   * Optional free-text notes or special instructions for the pickup.
   * @return notes
   **/
  
  @Schema(description = "Optional free-text notes or special instructions for the pickup.")
  
  public String getNotes() {  
    return notes;
  }



  public void setNotes(String notes) { 
    this.notes = notes;
  }

  public AppointmentCreateRequest customerId(String customerId) { 

    this.customerId = customerId;
    return this;
  }

  /**
   * Unique identifier of the customer for whom the appointment is being created.
   * @return customerId
   **/
  
  @Schema(required = true, description = "Unique identifier of the customer for whom the appointment is being created.")
  
  @NotNull
  public String getCustomerId() {  
    return customerId;
  }



  public void setCustomerId(String customerId) { 

    this.customerId = customerId;
  }

  public AppointmentCreateRequest vehicleId(String vehicleId) { 

    this.vehicleId = vehicleId;
    return this;
  }

  /**
   * Unique identifier of the vehicle to be picked up.
   * @return vehicleId
   **/
  
  @Schema(required = true, description = "Unique identifier of the vehicle to be picked up.")
  
  @NotNull
  public String getVehicleId() {  
    return vehicleId;
  }



  public void setVehicleId(String vehicleId) { 

    this.vehicleId = vehicleId;
  }

  public AppointmentCreateRequest pickupLocation(Location pickupLocation) { 

    this.pickupLocation = pickupLocation;
    return this;
  }

  /**
   * Get pickupLocation
   * @return pickupLocation
   **/
  
  @Schema(required = true, description = "")
  
@Valid
  @NotNull
  public Location getPickupLocation() {  
    return pickupLocation;
  }



  public void setPickupLocation(Location pickupLocation) { 

    this.pickupLocation = pickupLocation;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppointmentCreateRequest appointmentCreateRequest = (AppointmentCreateRequest) o;
    return Objects.equals(this.pickupDateTime, appointmentCreateRequest.pickupDateTime) &&
        Objects.equals(this.notes, appointmentCreateRequest.notes) &&
        Objects.equals(this.customerId, appointmentCreateRequest.customerId) &&
        Objects.equals(this.vehicleId, appointmentCreateRequest.vehicleId) &&
        Objects.equals(this.pickupLocation, appointmentCreateRequest.pickupLocation);
  }

  @Override
  public int hashCode() {
    return Objects.hash(pickupDateTime, notes, customerId, vehicleId, pickupLocation);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppointmentCreateRequest {\n");
    
    sb.append("    pickupDateTime: ").append(toIndentedString(pickupDateTime)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    customerId: ").append(toIndentedString(customerId)).append("\n");
    sb.append("    vehicleId: ").append(toIndentedString(vehicleId)).append("\n");
    sb.append("    pickupLocation: ").append(toIndentedString(pickupLocation)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

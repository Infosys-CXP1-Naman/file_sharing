package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.maruti.appointmentservice.model.AllocationStatus;
import com.maruti.appointmentservice.model.AppointmentStatus;
import com.maruti.appointmentservice.model.AssignmentHistoryEntry;
import com.maruti.appointmentservice.model.ChauffeurSummary;
import com.maruti.appointmentservice.model.Location;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * AppointmentDetail
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class AppointmentDetail   {
  @JsonProperty("linkedJobCardId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String linkedJobCardId = null;

  @JsonProperty("notes")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String notes = null;

  @JsonProperty("pickupLocation")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Location pickupLocation = null;

  @JsonProperty("promisedDeliveryTime")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime promisedDeliveryTime = null;

  @JsonProperty("assignedChauffeur")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private ChauffeurSummary assignedChauffeur = null;

  @JsonProperty("customerName")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String customerName = null;

  @JsonProperty("pickupDateTime")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime pickupDateTime = null;

  @JsonProperty("createdAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime createdAt = null;

  @JsonProperty("customerPhone")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String customerPhone = null;

  @JsonProperty("eta")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime eta = null;

  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("vehicleMakeModel")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String vehicleMakeModel = null;

  @JsonProperty("customerId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String customerId = null;

  @JsonProperty("exceptionFlag")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private Boolean exceptionFlag = null;

  @JsonProperty("vehicleId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String vehicleId = null;

  @JsonProperty("vehicleRegistration")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String vehicleRegistration = null;

  @JsonProperty("assignmentHistory")
  @Valid
  private List<AssignmentHistoryEntry> assignmentHistory = null;
  @JsonProperty("allocationStatus")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AllocationStatus allocationStatus = null;

  @JsonProperty("status")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private AppointmentStatus status = null;

  @JsonProperty("updatedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime updatedAt = null;


  public AppointmentDetail linkedJobCardId(String linkedJobCardId) { 

    this.linkedJobCardId = linkedJobCardId;
    return this;
  }

  /**
   * Identifier of the Job Card linked to this appointment.
   * @return linkedJobCardId
   **/
  
  @Schema(description = "Identifier of the Job Card linked to this appointment.")
  
  public String getLinkedJobCardId() {  
    return linkedJobCardId;
  }



  public void setLinkedJobCardId(String linkedJobCardId) { 
    this.linkedJobCardId = linkedJobCardId;
  }

  public AppointmentDetail notes(String notes) { 

    this.notes = notes;
    return this;
  }

  /**
   * Free-text notes or special instructions for the pickup.
   * @return notes
   **/
  
  @Schema(description = "Free-text notes or special instructions for the pickup.")
  
  public String getNotes() {  
    return notes;
  }



  public void setNotes(String notes) { 
    this.notes = notes;
  }

  public AppointmentDetail pickupLocation(Location pickupLocation) { 

    this.pickupLocation = pickupLocation;
    return this;
  }

  /**
   * Get pickupLocation
   * @return pickupLocation
   **/
  
  @Schema(description = "")
  
@Valid
  public Location getPickupLocation() {  
    return pickupLocation;
  }



  public void setPickupLocation(Location pickupLocation) { 
    this.pickupLocation = pickupLocation;
  }

  public AppointmentDetail promisedDeliveryTime(OffsetDateTime promisedDeliveryTime) { 

    this.promisedDeliveryTime = promisedDeliveryTime;
    return this;
  }

  /**
   * Promised vehicle delivery time communicated to the customer.
   * @return promisedDeliveryTime
   **/
  
  @Schema(description = "Promised vehicle delivery time communicated to the customer.")
  
@Valid
  public OffsetDateTime getPromisedDeliveryTime() {  
    return promisedDeliveryTime;
  }



  public void setPromisedDeliveryTime(OffsetDateTime promisedDeliveryTime) { 
    this.promisedDeliveryTime = promisedDeliveryTime;
  }

  public AppointmentDetail assignedChauffeur(ChauffeurSummary assignedChauffeur) { 

    this.assignedChauffeur = assignedChauffeur;
    return this;
  }

  /**
   * Get assignedChauffeur
   * @return assignedChauffeur
   **/
  
  @Schema(description = "")
  
@Valid
  public ChauffeurSummary getAssignedChauffeur() {  
    return assignedChauffeur;
  }



  public void setAssignedChauffeur(ChauffeurSummary assignedChauffeur) { 
    this.assignedChauffeur = assignedChauffeur;
  }

  public AppointmentDetail customerName(String customerName) { 

    this.customerName = customerName;
    return this;
  }

  /**
   * Full name of the customer.
   * @return customerName
   **/
  
  @Schema(description = "Full name of the customer.")
  
  public String getCustomerName() {  
    return customerName;
  }



  public void setCustomerName(String customerName) { 
    this.customerName = customerName;
  }

  public AppointmentDetail pickupDateTime(OffsetDateTime pickupDateTime) { 

    this.pickupDateTime = pickupDateTime;
    return this;
  }

  /**
   * Scheduled pickup date and time.
   * @return pickupDateTime
   **/
  
  @Schema(description = "Scheduled pickup date and time.")
  
@Valid
  public OffsetDateTime getPickupDateTime() {  
    return pickupDateTime;
  }



  public void setPickupDateTime(OffsetDateTime pickupDateTime) { 
    this.pickupDateTime = pickupDateTime;
  }

  public AppointmentDetail createdAt(OffsetDateTime createdAt) { 

    this.createdAt = createdAt;
    return this;
  }

  /**
   * Timestamp when the appointment record was created.
   * @return createdAt
   **/
  
  @Schema(description = "Timestamp when the appointment record was created.")
  
@Valid
  public OffsetDateTime getCreatedAt() {  
    return createdAt;
  }



  public void setCreatedAt(OffsetDateTime createdAt) { 
    this.createdAt = createdAt;
  }

  public AppointmentDetail customerPhone(String customerPhone) { 

    this.customerPhone = customerPhone;
    return this;
  }

  /**
   * Primary contact phone number of the customer.
   * @return customerPhone
   **/
  
  @Schema(description = "Primary contact phone number of the customer.")
  
  public String getCustomerPhone() {  
    return customerPhone;
  }



  public void setCustomerPhone(String customerPhone) { 
    this.customerPhone = customerPhone;
  }

  public AppointmentDetail eta(OffsetDateTime eta) { 

    this.eta = eta;
    return this;
  }

  /**
   * Current estimated time of arrival for the chauffeur at the pickup location.
   * @return eta
   **/
  
  @Schema(description = "Current estimated time of arrival for the chauffeur at the pickup location.")
  
@Valid
  public OffsetDateTime getEta() {  
    return eta;
  }



  public void setEta(OffsetDateTime eta) { 
    this.eta = eta;
  }

  public AppointmentDetail appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Unique identifier of the appointment.
   * @return appointmentId
   **/
  
  @Schema(description = "Unique identifier of the appointment.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public AppointmentDetail vehicleMakeModel(String vehicleMakeModel) { 

    this.vehicleMakeModel = vehicleMakeModel;
    return this;
  }

  /**
   * Make and model of the vehicle.
   * @return vehicleMakeModel
   **/
  
  @Schema(example = "Maruti Suzuki Swift", description = "Make and model of the vehicle.")
  
  public String getVehicleMakeModel() {  
    return vehicleMakeModel;
  }



  public void setVehicleMakeModel(String vehicleMakeModel) { 
    this.vehicleMakeModel = vehicleMakeModel;
  }

  public AppointmentDetail customerId(String customerId) { 

    this.customerId = customerId;
    return this;
  }

  /**
   * Unique identifier of the customer.
   * @return customerId
   **/
  
  @Schema(description = "Unique identifier of the customer.")
  
  public String getCustomerId() {  
    return customerId;
  }



  public void setCustomerId(String customerId) { 
    this.customerId = customerId;
  }

  public AppointmentDetail exceptionFlag(Boolean exceptionFlag) { 

    this.exceptionFlag = exceptionFlag;
    return this;
  }

  /**
   * Indicates whether this appointment is currently flagged as an exception.
   * @return exceptionFlag
   **/
  
  @Schema(description = "Indicates whether this appointment is currently flagged as an exception.")
  
  public Boolean isExceptionFlag() {  
    return exceptionFlag;
  }



  public void setExceptionFlag(Boolean exceptionFlag) { 
    this.exceptionFlag = exceptionFlag;
  }

  public AppointmentDetail vehicleId(String vehicleId) { 

    this.vehicleId = vehicleId;
    return this;
  }

  /**
   * Unique identifier of the vehicle.
   * @return vehicleId
   **/
  
  @Schema(description = "Unique identifier of the vehicle.")
  
  public String getVehicleId() {  
    return vehicleId;
  }



  public void setVehicleId(String vehicleId) { 
    this.vehicleId = vehicleId;
  }

  public AppointmentDetail vehicleRegistration(String vehicleRegistration) { 

    this.vehicleRegistration = vehicleRegistration;
    return this;
  }

  /**
   * Vehicle registration number.
   * @return vehicleRegistration
   **/
  
  @Schema(example = "MH12AB1234", description = "Vehicle registration number.")
  
  public String getVehicleRegistration() {  
    return vehicleRegistration;
  }



  public void setVehicleRegistration(String vehicleRegistration) { 
    this.vehicleRegistration = vehicleRegistration;
  }

  public AppointmentDetail assignmentHistory(List<AssignmentHistoryEntry> assignmentHistory) { 

    this.assignmentHistory = assignmentHistory;
    return this;
  }

  public AppointmentDetail addAssignmentHistoryItem(AssignmentHistoryEntry assignmentHistoryItem) {
    if (this.assignmentHistory == null) {
      this.assignmentHistory = new ArrayList<AssignmentHistoryEntry>();
    }
    this.assignmentHistory.add(assignmentHistoryItem);
    return this;
  }

  /**
   * Chronological list of all chauffeur assignment attempts for this appointment.
   * @return assignmentHistory
   **/
  
  @Schema(description = "Chronological list of all chauffeur assignment attempts for this appointment.")
  @Valid
  public List<AssignmentHistoryEntry> getAssignmentHistory() {  
    return assignmentHistory;
  }



  public void setAssignmentHistory(List<AssignmentHistoryEntry> assignmentHistory) { 
    this.assignmentHistory = assignmentHistory;
  }

  public AppointmentDetail allocationStatus(AllocationStatus allocationStatus) { 

    this.allocationStatus = allocationStatus;
    return this;
  }

  /**
   * Get allocationStatus
   * @return allocationStatus
   **/
  
  @Schema(description = "")
  
@Valid
  public AllocationStatus getAllocationStatus() {  
    return allocationStatus;
  }



  public void setAllocationStatus(AllocationStatus allocationStatus) { 
    this.allocationStatus = allocationStatus;
  }

  public AppointmentDetail status(AppointmentStatus status) { 

    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   **/
  
  @Schema(description = "")
  
@Valid
  public AppointmentStatus getStatus() {  
    return status;
  }



  public void setStatus(AppointmentStatus status) { 
    this.status = status;
  }

  public AppointmentDetail updatedAt(OffsetDateTime updatedAt) { 

    this.updatedAt = updatedAt;
    return this;
  }

  /**
   * Timestamp of the most recent update to the appointment record.
   * @return updatedAt
   **/
  
  @Schema(description = "Timestamp of the most recent update to the appointment record.")
  
@Valid
  public OffsetDateTime getUpdatedAt() {  
    return updatedAt;
  }



  public void setUpdatedAt(OffsetDateTime updatedAt) { 
    this.updatedAt = updatedAt;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AppointmentDetail appointmentDetail = (AppointmentDetail) o;
    return Objects.equals(this.linkedJobCardId, appointmentDetail.linkedJobCardId) &&
        Objects.equals(this.notes, appointmentDetail.notes) &&
        Objects.equals(this.pickupLocation, appointmentDetail.pickupLocation) &&
        Objects.equals(this.promisedDeliveryTime, appointmentDetail.promisedDeliveryTime) &&
        Objects.equals(this.assignedChauffeur, appointmentDetail.assignedChauffeur) &&
        Objects.equals(this.customerName, appointmentDetail.customerName) &&
        Objects.equals(this.pickupDateTime, appointmentDetail.pickupDateTime) &&
        Objects.equals(this.createdAt, appointmentDetail.createdAt) &&
        Objects.equals(this.customerPhone, appointmentDetail.customerPhone) &&
        Objects.equals(this.eta, appointmentDetail.eta) &&
        Objects.equals(this.appointmentId, appointmentDetail.appointmentId) &&
        Objects.equals(this.vehicleMakeModel, appointmentDetail.vehicleMakeModel) &&
        Objects.equals(this.customerId, appointmentDetail.customerId) &&
        Objects.equals(this.exceptionFlag, appointmentDetail.exceptionFlag) &&
        Objects.equals(this.vehicleId, appointmentDetail.vehicleId) &&
        Objects.equals(this.vehicleRegistration, appointmentDetail.vehicleRegistration) &&
        Objects.equals(this.assignmentHistory, appointmentDetail.assignmentHistory) &&
        Objects.equals(this.allocationStatus, appointmentDetail.allocationStatus) &&
        Objects.equals(this.status, appointmentDetail.status) &&
        Objects.equals(this.updatedAt, appointmentDetail.updatedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(linkedJobCardId, notes, pickupLocation, promisedDeliveryTime, assignedChauffeur, customerName, pickupDateTime, createdAt, customerPhone, eta, appointmentId, vehicleMakeModel, customerId, exceptionFlag, vehicleId, vehicleRegistration, assignmentHistory, allocationStatus, status, updatedAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AppointmentDetail {\n");
    
    sb.append("    linkedJobCardId: ").append(toIndentedString(linkedJobCardId)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    pickupLocation: ").append(toIndentedString(pickupLocation)).append("\n");
    sb.append("    promisedDeliveryTime: ").append(toIndentedString(promisedDeliveryTime)).append("\n");
    sb.append("    assignedChauffeur: ").append(toIndentedString(assignedChauffeur)).append("\n");
    sb.append("    customerName: ").append(toIndentedString(customerName)).append("\n");
    sb.append("    pickupDateTime: ").append(toIndentedString(pickupDateTime)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    customerPhone: ").append(toIndentedString(customerPhone)).append("\n");
    sb.append("    eta: ").append(toIndentedString(eta)).append("\n");
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    vehicleMakeModel: ").append(toIndentedString(vehicleMakeModel)).append("\n");
    sb.append("    customerId: ").append(toIndentedString(customerId)).append("\n");
    sb.append("    exceptionFlag: ").append(toIndentedString(exceptionFlag)).append("\n");
    sb.append("    vehicleId: ").append(toIndentedString(vehicleId)).append("\n");
    sb.append("    vehicleRegistration: ").append(toIndentedString(vehicleRegistration)).append("\n");
    sb.append("    assignmentHistory: ").append(toIndentedString(assignmentHistory)).append("\n");
    sb.append("    allocationStatus: ").append(toIndentedString(allocationStatus)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    updatedAt: ").append(toIndentedString(updatedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

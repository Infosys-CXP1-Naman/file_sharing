package com.maruti.appointmentservice.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.v3.oas.annotations.media.Schema;
import org.threeten.bp.OffsetDateTime;
import org.springframework.validation.annotation.Validated;
import org.openapitools.jackson.nullable.JsonNullable;
import io.swagger.configuration.NotUndefined;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

/**
 * ContactOutcomeResponse
 */
@Validated
@NotUndefined
@jakarta.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2026-11-13T10:27:18.665805500Z[Etc/UTC]")


public class ContactOutcomeResponse   {
  @JsonProperty("appointmentId")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String appointmentId = null;

  @JsonProperty("recordedAt")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private OffsetDateTime recordedAt = null;

  @JsonProperty("nextAction")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String nextAction = null;

  @JsonProperty("outcome")

  @JsonInclude(JsonInclude.Include.NON_ABSENT)  // Exclude from JSON if absent
  @JsonSetter(nulls = Nulls.FAIL)    // FAIL setting if the value is null
  private String outcome = null;


  public ContactOutcomeResponse appointmentId(String appointmentId) { 

    this.appointmentId = appointmentId;
    return this;
  }

  /**
   * Identifier of the appointment for which the contact outcome was recorded.
   * @return appointmentId
   **/
  
  @Schema(description = "Identifier of the appointment for which the contact outcome was recorded.")
  
  public String getAppointmentId() {  
    return appointmentId;
  }



  public void setAppointmentId(String appointmentId) { 
    this.appointmentId = appointmentId;
  }

  public ContactOutcomeResponse recordedAt(OffsetDateTime recordedAt) { 

    this.recordedAt = recordedAt;
    return this;
  }

  /**
   * Timestamp when the contact outcome was recorded.
   * @return recordedAt
   **/
  
  @Schema(description = "Timestamp when the contact outcome was recorded.")
  
@Valid
  public OffsetDateTime getRecordedAt() {  
    return recordedAt;
  }



  public void setRecordedAt(OffsetDateTime recordedAt) { 
    this.recordedAt = recordedAt;
  }

  public ContactOutcomeResponse nextAction(String nextAction) { 

    this.nextAction = nextAction;
    return this;
  }

  /**
   * Follow-up action recorded for this appointment.
   * @return nextAction
   **/
  
  @Schema(description = "Follow-up action recorded for this appointment.")
  
  public String getNextAction() {  
    return nextAction;
  }



  public void setNextAction(String nextAction) { 
    this.nextAction = nextAction;
  }

  public ContactOutcomeResponse outcome(String outcome) { 

    this.outcome = outcome;
    return this;
  }

  /**
   * Recorded outcome of the contact attempt.
   * @return outcome
   **/
  
  @Schema(description = "Recorded outcome of the contact attempt.")
  
  public String getOutcome() {  
    return outcome;
  }



  public void setOutcome(String outcome) { 
    this.outcome = outcome;
  }

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContactOutcomeResponse contactOutcomeResponse = (ContactOutcomeResponse) o;
    return Objects.equals(this.appointmentId, contactOutcomeResponse.appointmentId) &&
        Objects.equals(this.recordedAt, contactOutcomeResponse.recordedAt) &&
        Objects.equals(this.nextAction, contactOutcomeResponse.nextAction) &&
        Objects.equals(this.outcome, contactOutcomeResponse.outcome);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appointmentId, recordedAt, nextAction, outcome);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContactOutcomeResponse {\n");
    
    sb.append("    appointmentId: ").append(toIndentedString(appointmentId)).append("\n");
    sb.append("    recordedAt: ").append(toIndentedString(recordedAt)).append("\n");
    sb.append("    nextAction: ").append(toIndentedString(nextAction)).append("\n");
    sb.append("    outcome: ").append(toIndentedString(outcome)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
